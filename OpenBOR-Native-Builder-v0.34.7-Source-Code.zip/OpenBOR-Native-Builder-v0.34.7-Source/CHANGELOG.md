# Changelog

## v0.34.7 — Força e resistência de agarrão

- cantgrab deixa de ser tratado como alias booleano de nograb. Conforme o parser OpenBOR v7533, valor 2 define grab_force=-999999; outros valores definem grab_resistance=1. notgrab passa a usar a mesma interpretação.
- Força/resistência preservam a ordem dos comandos; antigrab/grabforce posteriores podem sobrescrever os valores. A proibição independente nograb mantém seu comportamento anterior.
- Comparação no agarrão nativo passa de força <= resistência para força < resistência. Igualdade permite agarrar, inclusive com valores negativos; força negativa não ignora resistência zero.
- Jogador fora da tolerância vertical, alvo no ar e movimento X/Z definido no frame impedem novo agarrão. Velocidade por script não é confundida com movimento de frame.
- getentityproperty expõe grabforce/grabresistance de jogador, cooperativo e entidade para helpers.
- 545 verificações PASS, zero falhas; Builder e runtime do Ghosts compilados para Windows x64, e inicialização dos dois ports verificada sem janela no Linux.
- Reanálise dos mesmos PAKs: Ghosts PARTIAL 369 → 364/UNKNOWN 0; Evil Dead PARTIAL 541 → 521/UNKNOWN 454 → 453. Apenas cantgrab/notgrab deixam de receber classificação incompleta; os demais ajustes de agarrão conservam seus limites.


## v0.34.6 — Vínculo de entidades em armas e agarrões

- Implementado bindentity no host: ajuste imediato de X/Z/altitude, offsets inteiros com X espelhado pelo alvo, direção preservada/igual/oposta/fixa/toward/away, axes omitidos/NULL e soltura por alvo NULL.
- Jogador, cooperativo e entidades podem ser alvo ou ator vinculado. Os vínculos são reaplicados após movimento e gravidade; cadeias são ajustadas em ordem de dependência. Remoção do alvo limpa o vínculo; ciclos e handles inválidos geram diagnóstico.
- Flags de animação/frame alvo e remoção por ausência de animação/frame foram implementadas. Flags de posição relativas ao nível preservam offsets anteriores conforme OpenBOR. Configs de animação/frame definidos e overrides avançados continuam incompletos e são registrados.
- Sort-id relativo é aplicado à ordenação dos atores por profundidade no desenho. Ordem padrão -1 e offset explícito são preservados; projéteis conservam a fila anterior.
- Analisador reconhece chamadas básicas de bindentity, mas conserva PARTIAL para flags avançadas ou configuração dinâmica não verificada.
- PAKs originais reanalisados com a mesma resolução de caminhos: Ghosts 378 → 369 PARTIAL; Evil Dead 543 → 541 PARTIAL. UNKNOWN permanece 0 e 454 respectivamente. As 93 chamadas do Ghosts com helper ausente permanecem PARTIAL.
- 517 verificações PASS, zero falhas. Testes de vínculo complementam a regressão, incluindo movimento real, cadeias, NULL, cooperativo, animação/frame e configurações avançadas. Não há certificação de jogabilidade completa no Windows.


## v0.34.5 — Correções a partir dos PAKs Ghosts e Evil Dead

- Entrada PAK normaliza nomes de arquivos para minúsculas, conservando o conteúdo; referências de modelos/fases e assets aceitam diferenças de caixa. Caminhos fora da raiz e correspondências ambíguas continuam rejeitados.
- Scanner e parsers localizam DATA/models/levels/video sem depender da caixa dos nomes. Os PAKs completos carregam 39 modelos/8 fases no Ghosts e 125 modelos/10 fases no Evil Dead.
- changeentityproperty(position/velocity) preserva eixos omitidos ou NULL. Velocidade vertical/tossv convertem entre o sinal ascendente do OpenBOR e o sinal interno do runtime.
- antigravity pode ser lida/alterada por ator e passa a afetar sua aceleração. O modelo compartilhado não é modificado; overrides são limpos na troca de fase/nova partida.
- killentity(NULL()) retorna zero sem atingir o ator do contexto; entidades removidas ficam invisíveis imediatamente. Razões avançadas de remoção recebem aviso próprio.
- effectvol retorna o ganho base usado pelos scripts; o volume escolhido nas opções continua aplicado uma vez pelo AudioSystem. rand preserva o inteiro de 32 bits com sinal, permitindo os dois sinais no resto da divisão usado por randSound2.
- Falta de animationscript mantém falha explícita, mas permite executar comandos independentes do frame. O Ghosts contém 93 chamadas cujo helper data/chars/gelcube/gelatinS.c não existe no PAK; não foi criado um substituto específico para esse jogo.
- Analisador percorre imports/includes aninhados com resolução segura de caminhos e caixa, identificando arquivos ausentes em vez de ignorá-los.
- Testes: 460 verificações PASS. Os dois ports foram gerados para validação; a execução do helper real randSound2 cobriu as seis escolhas e argumentos de áudio. Parciais finais: Ghosts 378/UNKNOWN 0; Evil Dead 543/UNKNOWN 454. As correções não certificam todos os helpers nem a jogabilidade completa.


## v0.34.4 — Consultas de terreno em scripts

- Implementadas checkhole/checkholeindex e checkwall/checkwallindex, usadas por helpers de animação e @cmd. APIs deixam de constar como funções não mapeadas.
- Parser/tabelas preservam nove parâmetros OpenBOR de wall/hole em float: origem, quatro cantos, profundidade, altura e tipo.
- Consulta interpola os lados inclinados, seleciona altura/índice conforme OpenBOR v7533 e suprime buraco coberto por parede. Índices de parede/buraco são independentes.
- Altitude de buraco usa tolerância T_WALKOFF=2; paredes usam a maior altura positiva abaixo do limite. Profundidade zero não produz divisão por zero.
- Formatos retangulares antigos do runtime conservam fallback com aviso terrain-legacy-rectangle. Física e plataformas completas ainda são lacunas separadas.
- Reanálise de Final Fight X mantém 258 PARTIAL e 139 UNKNOWN: checkwall foi resolvido no script.c, mas bindentity/projectile ainda mantêm o mesmo arquivo como parcial. Nenhum contador foi reduzido artificialmente.
- Acrescentada fixture/runtime de terreno com 23 verificações, incluindo execução por @cmd. Total do conjunto: 439 PASS, zero falhas.


## v0.34.3 — Execução e diagnóstico de @cmd

- @cmd mantém textos com espaços/#, escapes e chamadas aninhadas como um argumento, em vez de inserir vírgulas dentro deles.
- Corrigido consumo de operadores unários em ramos ignorados. && e || passam a respeitar curto-circuito sem executar chamadas do lado ignorado.
- Parâmetros e variáveis automáticas de funções auxiliares ficam isolados por chamada; setlocalvar continua persistindo no contexto do script.
- Protótipos não são mais confundidos com o corpo da função seguinte. Imports/helpers aceitam diferenças de maiúsculas/minúsculas, seguindo a convenção do OpenBOR/Windows.
- Corrigida a expansão de macros de função que deixava um parêntese extra; macros de objeto com valor entre parênteses deixam de ser confundidas com macros de função.
- Novo animation-command-audit.txt identifica cada função/helper e seu estado. Um subconjunto estreito de chamadas básicas verificadas deixa de receber PARTIAL genérico; helpers, APIs e argumentos não verificados conservam PARTIAL. O resumo inclui a divisão por estado, também em analysis.json.
- Logs de falha identificam modelo, animação, frame, helper e chamada, facilitando localizar o bloqueio real.
- Final Fight X reanalisado: @cmd 9 parciais → 6 chamadas básicas verificadas + 3 helpers parciais; PARTIAL total 264 → 258; UNKNOWN continua 139. Essa divisão é refinamento da análise; as correções do executor foram testadas separadamente.
- O relatório novo de Ghosts confirma 150 @cmd em 13 arquivos (93 em HARPYQ.TXT), mas não contém os corpos das chamadas/scripts. Não há redução medida das 150 neste bloco.


## v0.34.2 — Custos de energia e lançamento por script

- Parser e tabelas geradas preservam `energycost`, `mpcost`, `mponly` e `nocost` global de models.txt.
- Ativação de ataques, comandos, cancelamentos e `performattack` verifica e cobra MP/HP, com modos MP→HP, MP somente e HP somente. Sem energia suficiente, a animação não começa; o custo não é repartido entre os recursos.
- `nocost` adia a cobrança de ataques de contato até o fim/troca da animação, cobrando uma vez quando houve contato. Continua PARTIAL: projéteis, smartbomb e mudanças de recursos durante a animação não têm equivalência completa.
- `tossentity` altera velocidade planar e lançamento vertical no jogador, cooperativos e entidades. Lift zero preserva o movimento vertical existente; handles inválidos são rejeitados.
- Reanálise real do Final Fight X: UNKNOWN 155 → 139; PARTIAL 263 → 264. Quinze custos implementados e um `nocost` antes desconhecido agora explicitamente parcial. Não houve edição de contadores nem dos jogos.
- 387 verificações PASS (320 regressão, 25 energia/lançamento, 25 efeitos, 17 scripts/painéis/pouso); compilação do Builder e do port gerado para Windows x64.


## v0.34.1 — Efeitos de impacto e leitura de ataques

- Efeitos `hitflash`/`blockflash` preservados por frame, com aliases modernos do OpenBOR v7533. Corrigido o uso do último efeito da animação para todos os frames.
- Runtime cria efeitos de colisão, aplica `flash`/`bflash` do alvo, `noatflash`, `noflash` e `toflip`; expõe spawn type 9 e remove o efeito após a animação. Jogador, cooperativos, entidades e projéteis usam essa rota.
- Ataques com dano zero deixam de causar um ponto de dano artificial e continuam válidos para colisão, reação e efeitos.
- Parser aceita apenas sufixos numéricos como caixas `attackN`, deixando propriedades `attack.tag`, `attack.block.cost`, `attack.block.penetrate` e efeitos chegarem às suas próprias regras.
- Classificação de caixas numeradas corrigida depois da validação comportamental: a restrição antiga de controles padrão não era uma limitação dessas caixas de dano. `attackone` continua PARTIAL; prefixos arbitrários deixam de ser reconhecidos por engano.
- Mesmo Final Fight X original reanalisado: PARTIAL 362 → 263; UNKNOWN 175 → 155. 34 efeitos implementados, 65 ocorrências de caixas numéricas validadas e 20 comandos de efeito antes desconhecidos.
- Regressão e testes compilados do runtime: 358 verificações PASS, zero falhas.

## v0.34.0 — Scripts de frame, painéis e pouso

- Blocos `@script` preservam o corpo e executam por modelo/animação com `frame` e `animhandle`. O `main()` do `animationscript` executa mesmo sem `@cmd`, e não esconde mais os comandos gerados. APIs não implementadas continuam PARTIAL.
- Corrigido escape de múltiplas linhas no C++ gerado: vários `@cmd` no mesmo frame e blocos inline não quebram mais a compilação.
- `order` passa a interpretar letras, maiúsculas/minúsculas, repetições e diretivas cumulativas para a sequência de painéis, seguindo OpenBOR v7533. Sequências inválidas permanecem PARTIAL.
- `landframe` retoma o frame configurado sem retroceder quando já alcançado, preserva os delays restantes e cria o modelo de poeira uma vez, com spawn type 8 e remoção ao fim da animação.
- A duração dos ataques usa os delays reais dos frames, evitando cortar os últimos frames e seus scripts por um contador fixo.
- Reanálise real do Final Fight X original: PARTIAL 584 → 362; UNKNOWN 175 → 175. Não implica gameplay completo.
- Incluídos testes compilados de comportamento do runtime e fixtures, sem alterações nos jogos fornecidos.

## v0.33.8 — Movimento e direção do modelo

- `nomove` agora preserva os dois parâmetros independentes e cumulativos: bloquear deslocamento voluntário/por IA e impedir virada automática.
- O runtime gerado aplica esses limites ao jogador, cooperativos e entidades; o primeiro parâmetro também desativa a queda comum causada por golpes. Movimento de animação, scripts e recuo de impacto continua possível.
- Compatibilidade `PARTIAL`: exceções de queda no ar e outras rotas avançadas do OpenBOR ainda podem divergir. A prioridade veio das 11 ocorrências desconhecidas no relatório de Cyber Robot.

## v0.33.7 — Colisão com paredes por modelo

- `subject_to_wall` é lido do modelo e passa a controlar a colisão retangular com paredes para jogador, jogadores cooperativos e entidades do runtime.
- A classificação permanece `PARTIAL`, pois paredes com altura/profundidade e outras regras avançadas do OpenBOR não têm paridade completa.
- A mudança foi motivada pelos relatórios novos de Cyber Robot, sem alterar conteúdo de qualquer jogo.


## v0.33.6 — Três relatórios e ataque shock

- `shock` agora produz uma caixa de ataque de tipo elétrico e escolhe `spain` ou `shock` conforme a reação, com aviso PARTIAL para efeitos avançados.
- `antigrab` passa a alimentar a resistência de agarrão já usada pelo runtime.
- O tipo do golpe (`attack2`, `shock`, `burn` etc.) deixa de forçar queda por si só: a queda passa a seguir a flag `attack_drop` do golpe, como no parser do OpenBOR v7533. `blast` conserva sua queda especial.
- A correção é genérica para jogador, cooperativo, inimigos e projéteis; os três relatórios enviados orientaram a prioridade.


## v0.33.5 — Finalização do dano no pouso

- O parser reconhece tipos de ataque nomeados em `damageonlanding` (`attackN`, `blast`, `burn`, `freeze`, `shock`, `steal`) e usa o tipo `land` quando o terceiro argumento não aparece.
- O runtime mantém a animação de morte quando o dano no pouso é fatal, limpa o estado após o contato e continua simulando queda durante atordoamento cooperativo ou quando o contador de queda termina antes do contato com o chão.
- Teste de regressão cobre tipos nomeados e o tipo padrão; o runtime gerado compila para Linux. O EXE do Builder é compilado separadamente para Windows x64.

## v0.33.4 — Dano no pouso baseado no OpenBOR v7533

- `damageonlanding` passa a ser lido como propriedade da caixa de ataque, conforme o parser de `engine/openbor.c` na tag oficial `v7533`.
- A força do dano é preservada no C++ gerado e transferida à vítima após um golpe que derruba; o runtime aplica o dano uma vez quando ela toca o chão. Abrange jogador, jogadores cooperativos e entidades.
- A análise classifica o comando como `PARTIAL`: `blast` (modo de pouso), tipos de ataque por nome, scripts e todas as regras de defesa/morte do motor original ainda não têm paridade completa.
- Teste de regressão verifica parser, classificação e tabela C++ gerada.

## v0.33.0 — Faction, Group & Follow Parity

- `hostile` e `candamage`: suporte a máscaras textuais canônicas do OpenBOR e separação real entre seleção hostil e permissão de dano.
- `aggression`: valores assinados passam a ajustar o atraso de reação da IA.
- `group` e `wait`: fluxo de fase nativo para limite/refill de inimigos e bloqueio de avanço.
- `followanim`/`followcond`: transições após hit/block/lethal/grab usam o resultado real da colisão.
- `subentity`, `spawnframe`, `summonframe`, `unsummonframe` e `summonkill`: ciclo básico de child entities executado no runtime.
- ScriptVM ganhou `changeentityproperty(..., "position", x, z, a)` para helpers de spawn/movimento usados por scripts reais.
- Corrigido código gerado quando o jogo não possui `levels.txt`: o Stage sentinel agora inclui `rockMode` na posição correta e compila novamente.
- Novas regressões para máscaras textuais, aggression negativo e sentinel de zero stages.
- `remap/palette` permanece `PARTIAL` nos casos indexados/duplicados ainda não equivalentes ao OpenBOR.

## v0.31.0 — Registry, HUD & Cutscene parity

- Fixed `models.txt know <name> <path>` so known/lazy models are emitted into the generated native registry instead of being omitted.
- `animation` scene entries and `shadow` are now classified SUPPORTED after end-to-end runtime coverage.
- Added HUD icon palette inheritance (`icon ... 1`) and popup enemy/boss icon rendering.
- Added full parsing/generation for the main `lifebarstatus` fields: width, height, no-border, absolute/ratio mode and orientation; component Z-layer offsets remain explicitly PARTIAL.
- Reclassified only completed HUD commands (`icon`, `icondie`, `nolife`, `lifeposition`, `nameposition`, `iconposition`) while leaving `lifebarstatus` honest.
- Added regression coverage for know-only models and v0.31 registry/status behavior.

## v0.30.0 — Unknown-command parity + legacy runtime behavior

- Added real parsing/runtime paths for `seta`, `antigravity`, `nopain`, `nodrop`, `subject_to_hole`, `offscreenkill`, `noquake`, `quakeframe`, `hitfx` and `icondie`.
- Added parser coverage for `falldie`/`death`, `risetime`, `riseattacktype`, `nodieblink`, `fmap`, `remove`, `throw`, `no_adjust_base`, stage `order`, `lives`, `credits`, and `colourdepth`.
- `hitflash` and `2pitem` are now recognized as PARTIAL instead of UNKNOWN; their uncommon legacy behavior remains explicitly reported rather than overstated.
- Added regression coverage for the 25 commands that were UNKNOWN in the Ghosts'n Goblins Dragon Ball compatibility report.
- Runtime now honors model antigravity for player/co-op/enemy/projectile vertical physics, conditional hole interaction, no-pain/no-drop flags, offscreen removal, per-animation hit sounds, frame altitude, screen quake, dead HUD icons and rise timing/type metadata.


## v0.29.0 — Global block rules + stage motion parity

- `models.txt blockratio 1` agora fornece o fallback legado de 25% de chip damage quando o `defense` do modelo não declara um `blockratio` próprio.
- `models.txt mpblock 1` agora é usado quando `defense.blocktype` está ausente ou é `0`, consumindo MP primeiro e enviando o restante para HP.
- `models.txt nochipdeath 1` impede chip damage de reduzir HP abaixo de 1.
- O parser agora distingue `defense.blockratio`/`blocktype` **não declarados** de valores explicitamente definidos, evitando sobrescrever as regras globais por engano.
- `defense.blocktype -1` força HP, `1` usa MP e continua em HP, `2` atinge MP e HP; `0` herda `mpblock`.
- `rock 1`, `rock 2` e `rock 3` ganharam movimentos de palco distintos; HUD permanece estável enquanto cenário e entidades acompanham o balanço.
- `water` preserva o comportamento legado: `rock 0` usa onda senoidal e `rock 1` usa deslocamento/parallax animado com velocidade baseada em `warp`.
- Mantidas as correções de v0.28 para knockdown acumulado, bossmusic offset, defense e gameplay parity.

## Gameplay parity — defesa, knockdown, boss music e water

- `defense.blockratio` agora aplica chip damage real durante bloqueios.
- `defense.blocktype` passa a controlar o destino do chip: HP, MP primeiro com overflow para HP, ou HP+MP.
- Parser/modelo/runtime agora preservam `mp` por personagem e por jogador cooperativo.
- `knockdowncount` foi integrado ao runtime com medidor acumulado por personagem.
- `defense.knockdown` passa a escalar a força usada pelo sistema de knockdown, em vez de funcionar apenas como liga/desliga.
- `bossmusic` passa o offset legado ao backend de áudio como ponto de retorno do loop; para áudio decodificado, o byte do arquivo fonte é convertido proporcionalmente para a posição PCM.
- `water warp` agora controla velocidade do efeito sem inflar artificialmente sua amplitude.
- `rock` é parseado e gerado por fase; `rock 1` possui comportamento visual dedicado no runtime.
- Corrigida uma duplicação de `knockdownMeter` descoberta durante a compilação end-to-end do runtime gerado.
- Mantidas as correções de v0.27.1 para `blockpower`, `blockthreshold`, `pain` e knockdown zero.

### Validação

- Builder C++: compilação OK.
- CTest: 1/1 regressões aprovadas, 0 falhas.
- Fixture de conversão: 0 comandos UNKNOWN.
- Runtime C++ gerado: compilação 100% OK.
- Smoke test headless: exit code 0.

### Limites conhecidos

- Regras globais antigas de `mpblock`/`blockratio`/`nochipdeath` ainda são parciais em combinações menos comuns.
- Em música comprimida, `bossmusic offset` exige mapeamento proporcional entre bytes do arquivo original e PCM decodificado.
- `water` ainda não replica o warp por scanline/perspectiva do OpenBOR pixel a pixel; modos `rock` além do caso principal continuam parciais.

# OpenBOR Native Builder 0.27.1

## Gameplay hotfix

- Corrigida a regra de defesa que confundia `thold`/`defense.blockthreshold` com penetração de bloqueio.
- `defense.blockpower` agora é comparado com `attack` penetration/unblockable separadamente.
- `thold + defense.blockthreshold` agora usa o dano bruto do golpe como critério de bloqueio.
- `defense.pain` agora evita reação de dor abaixo do limite configurado.
- `defense.knockdown 0` agora impede knockdown daquele tipo de ataque.
- Mantidas as correções da 0.27.0 para scene/animation, blast/burn, shadow, diesound, lifespan/landframe, bossmusic, water e HUD legado.
- Adicionados testes de regressão específicos para as novas regras de defesa.
- Runtime gerado recompilado e executado em modo headless sem crash.

## Limites ainda honestamente parciais

- `defense.blockratio` e `defense.blocktype` ainda não reproduzem todos os casos de chip damage/MP do OpenBOR.
- `defense.knockdown` acima de zero ainda é tratado como habilitado; o runtime não possui ainda um contador de knockdown com força fracionária equivalente ao OpenBOR.
- O offset legado de `bossmusic` continua preservado para diagnóstico, mas o áudio inicia no começo da faixa.
- O efeito `water` continua aproximado, sem o warp de scanline completo do motor original.

# Changelog

## v0.34.1 — Efeitos de impacto e leitura de ataques

- Efeitos `hitflash`/`blockflash` preservados por frame, com aliases modernos do OpenBOR v7533. Corrigido o uso do último efeito da animação para todos os frames.
- Runtime cria efeitos de colisão, aplica `flash`/`bflash` do alvo, `noatflash`, `noflash` e `toflip`; expõe spawn type 9 e remove o efeito após a animação. Jogador, cooperativos, entidades e projéteis usam essa rota.
- Ataques com dano zero deixam de causar um ponto de dano artificial e continuam válidos para colisão, reação e efeitos.
- Parser aceita apenas sufixos numéricos como caixas `attackN`, deixando propriedades `attack.tag`, `attack.block.cost`, `attack.block.penetrate` e efeitos chegarem às suas próprias regras.
- Classificação de caixas numeradas corrigida depois da validação comportamental: a restrição antiga de controles padrão não era uma limitação dessas caixas de dano. `attackone` continua PARTIAL; prefixos arbitrários deixam de ser reconhecidos por engano.
- Mesmo Final Fight X original reanalisado: PARTIAL 362 → 263; UNKNOWN 175 → 155. 34 efeitos implementados, 65 ocorrências de caixas numéricas validadas e 20 comandos de efeito antes desconhecidos.
- Regressão e testes compilados do runtime: 358 verificações PASS, zero falhas.

## v0.34.0 — Scripts de frame, painéis e pouso

- Blocos `@script` preservam o corpo e executam por modelo/animação com `frame` e `animhandle`. O `main()` do `animationscript` executa mesmo sem `@cmd`, e não esconde mais os comandos gerados. APIs não implementadas continuam PARTIAL.
- Corrigido escape de múltiplas linhas no C++ gerado: vários `@cmd` no mesmo frame e blocos inline não quebram mais a compilação.
- `order` passa a interpretar letras, maiúsculas/minúsculas, repetições e diretivas cumulativas para a sequência de painéis, seguindo OpenBOR v7533. Sequências inválidas permanecem PARTIAL.
- `landframe` retoma o frame configurado sem retroceder quando já alcançado, preserva os delays restantes e cria o modelo de poeira uma vez, com spawn type 8 e remoção ao fim da animação.
- A duração dos ataques usa os delays reais dos frames, evitando cortar os últimos frames e seus scripts por um contador fixo.
- Reanálise real do Final Fight X original: PARTIAL 584 → 362; UNKNOWN 175 → 175. Não implica gameplay completo.
- Incluídos testes compilados de comportamento do runtime e fixtures, sem alterações nos jogos fornecidos.

## v0.33.8 — Movimento e direção do modelo

- `nomove` agora preserva os dois parâmetros independentes e cumulativos: bloquear deslocamento voluntário/por IA e impedir virada automática.
- O runtime gerado aplica esses limites ao jogador, cooperativos e entidades; o primeiro parâmetro também desativa a queda comum causada por golpes. Movimento de animação, scripts e recuo de impacto continua possível.
- Compatibilidade `PARTIAL`: exceções de queda no ar e outras rotas avançadas do OpenBOR ainda podem divergir. A prioridade veio das 11 ocorrências desconhecidas no relatório de Cyber Robot.

## v0.27.0 — Gameplay Parity

Foco desta versão: problemas reais de gameplay detectados pelos testes de conversão, sem regredir a base v0.26.x.

- `scene` + `animation`: cenas declaradas em `levels.txt` agora são associadas à fase seguinte e executadas como cutscene nativa; GIFs são decodificados frame a frame no Windows com timing WIC e suporte a skip/noskip.
- `blast` e `burn`: caixas legadas são convertidas em ataques nativos especiais; blast força knockdown e burn busca reações `bpain`/`burn`/`bdeath`.
- `shadow`: sombra 0–6 por modelo, usando `sprites/shadowN` quando disponível e fallback seguro.
- `diesound`: áudio de morte executado na derrota e também em expiração por lifespan.
- `lifespan`: entidades expiram em tempo nativo e entram no fluxo de morte/ondeath.
- `landframe`: frame de aterrissagem preservado e aplicado ao tocar o chão; dust é preservado como metadado (efeito exato ainda parcial).
- `defense`: fator de defesa por tipo (`all`, `normal`, `normalN`, `burn`, `blast`) aplicado ao dano; campos avançados de pain/knockdown/block continuam preservados para expansão.
- `bossmusic`: troca para a música de boss quando o primeiro boss é ativado; offset legado é preservado para diagnóstico, mas playback começa no início do arquivo.
- `water`: gráfico de água carregado na fase com warp visual leve; scanline warp idêntico ao OpenBOR continua parcial.
- HUD original: `icon`, `nolife`, `lifebarstatus`, `lifeposition`, `nameposition`, `iconposition` e `lbarsize` entram no runtime nativo.
- Mantido o hotfix da v0.26.1 para blocos inline `@script`/`@cmd`, evitando classificar código C interno como comandos de dados.

### Validação

A v0.27 adiciona regressões específicas para parser/gerador desses comandos e mantém a compilação do Builder e do runtime gerado como gate de entrega.

### Toolchain hotfix (Windows)
- Corrigido instalador que tratava `winget` sem atualizacao do CMake como falha.
- CMake existente agora e detectado antes de chamar `winget`.
- Corrigida deteccao do CMake embutido no Visual Studio 2022 Build Tools em `Program Files`.
- Se Visual Studio/Build Tools existir sem workload C++, o instalador usa o Visual Studio Installer para adicionar `Desktop development with C++`.
- Adicionado `VERIFICAR-FERRAMENTAS-WINDOWS.cmd` para diagnosticar CMake e MSVC antes do build.


## v0.26.0 — Dynamic Commands, Combo Branches, Child & AI

- `com/cmd`: histórico ampliado para 128 ticks com press/release, hold min/max, hold-trigger, chord grace e sequence grace.
- `cancel`: passa a usar o mesmo matcher temporal do sistema de comandos.
- `combostyle 1`: zeros do `atchain` são preservados como separadores e o runtime escolhe o ramo por `range`, `rangez` e `rangea`.
- Ranges de animação são preservados no código C++ gerado.
- Child follow/recall por eixo, offsets de recall, animação configurável e ajuste de direção.
- `modelflag no_basic` entra no overlay de weapon-model; `onmodelcopy` é tratado como hook runtime.
- IA pode procurar e coletar itens-arma compatíveis.
- Mantidos `weaploss`, drop counter, `shootnum`, `typeshot`, summon/unsummon, combo/counter/cancel, ScriptVM, palettes e entrada ZIP/PAK das versões anteriores.
- OGG/Vorbis embutido independente continua pendente e permanece explicitamente `PARTIAL`.

## v0.25.0 — Commands, Weapon Loss & Child Lifecycle

- `com/cmd` com histórico por jogador e comandos básicos de direção/botão/chord/release.
- Weapon-model fornece a lista de comandos ativa.
- `weaploss`, `weapon_loss_condition`, drop counter, `typeshot`/`shootnum` e item físico de arma no chão.
- `unsummonframe`, `summonkill`, follow/recall básico e vínculo pai-filho estável.
- Bridge adicional para IA legada chase/biker/arrow.

## v0.24.0 — Combos, counters, weapon-model e child-spawn

- `atchain`, `combodelay` e `combostyle` alimentam a cadeia nativa de ataques; estilo livre (`combostyle 2`) e sequência estática são executados no runtime.
- `followanim`/`followcond` redirecionam o atacante para `followN` a partir do resultado do golpe.
- `counterrange`/`counterframe` entram na resolução de combate com janela de frames, condição, direção/unblockable básica e opção de receber ou não o dano.
- `cancel` usa janela de frames, requisito de hits e inputs comuns para trocar para a animação alvo.
- `weapons`, `weapnum`, `shootnum`, `reload` e `weaponframe` possuem estado nativo e independente por jogador local.
- `subentity`, `custentity`, `spawnframe` e `summonframe` geram entidades-filhas nativas.

## v0.23.0 — Combate, IA, armas e projéteis

- Parser/runtime passaram a consumir `aggression`, `aiattack` e `aimove`; os modos comuns de perseguição, evitar, wander, no-move, ataques long/melee/noattack/always e dodge influenciam a IA nativa.
- `candamage`, `hostile` e `projectilehit` entram na filtragem de alvos de ataques e projéteis, com fallback para a regra legada quando o modelo não define máscara.
- Combos do player e coop descobrem `attackN` além de `attack3`; `attack4+` deixa de ficar apenas preservado como animação.
- `ondoattackscript` é disparado quando player, coop, inimigo ou `performattack()` inicia um ataque; `performattack()` passa a iniciar estado/cooldown/hit real em vez de trocar somente a animação.
- Grabs respeitam `nograb/cantgrab`, `grabforce` e resistência; arremessos consomem `throwdamage`, `throwdist` e `throwheight`.
- Projéteis consomem `subject_to_gravity`, `bounce` e `bouncefactor`, incluindo quique no chão e término/explosão ao esgotar os bounces.
- Armas/projéteis no coop ganharam estado por jogador: P2-P4 mantêm item equipado e estado de disparo próprios, sem reutilizar o estado global de P1.
- Novas constantes OpenBOR de `TYPE_*`, `AIMOVE*` e `AIATTACK*` foram mapeadas para scripts e para a lógica nativa de combate/IA.
- Regressão ampliada com fixture específico de IA/combate/attack4, filtros de facção, gravidade/bounce, `performattack`, `ondoattack` e isolamento de arma no coop.
- Entrada universal pasta/ZIP/PAK e todas as correções das versões anteriores foram preservadas.
- Runtime gerado não confunde flags CLI como `--headless` com a pasta raiz do port; persistência de `graphics.ini` continua apontando para a pasta do executável.

## v0.22.0 — Blocking, desenho por script e propriedades modernas

- Runtime ganhou bloqueio/guard nativo usando `blockodds`, `blockpain`, `thold`/`blockthreshold`, `guardpoints`, `guardrate`, `blockback`, guard cost, penetração, direção e contexto de `didblockscript`.
- Player, coop e inimigos podem bloquear durante a resolução real do ataque; `didhitscript` do atacante recebe informação de golpe bloqueado.
- `onblockwscript`, `onblockzscript`, `onblocksscript` e `onblockoscript` foram ligados a limites e obstáculos básicos; variantes A/Y/P continuam registradas como compatibilidade parcial.
- Parser/geração de ataque ganhou fall force, penetration, guard cost, juggle cost, pause time e tag.
- ScriptVM/host ganhou acesso moderno a propriedades de entidade/modelo/fase e novas constantes `ENTITY_PROPERTY_*`, `MODEL_PROPERTY_*`, `LEVEL_PROPERTY_*` e `BLOCK_STATE_*`.
- Fila de desenho por script implementada com `drawdot`, `drawline`, `drawbox`, `drawstring`, `drawsprite`, `loadsprite`/`freesprite`, `getgfxproperty` e `rgbcolor`; comandos são ordenados por `z` antes da apresentação.
- Scripts globais `update.c` e `updated.c` passam a executar no gameplay.
- `onkillscript` é disparado quando a entidade é efetivamente removida, separado do evento de morte; comando legado `script` funciona como alias de `updatescript`.
- Regressão ampliada para blocking/guard, hooks de bloqueio, APIs de desenho e propriedades modernas.
- Entrada universal pasta/ZIP/PAK e toda a compatibilidade de ScriptVM da v0.21 foram preservadas.
- OGG independente do codec do Windows **ainda não foi embutido**; essa limitação permanece explicitamente reportada.

## v0.21.0 — OpenBORScript, hooks e entidades estáveis

- Runtime passou a manter entidades em armazenamento com endereços estáveis, evitando invalidar handles usados por `self`, `getentity()` e scripts quando novos spawns são adicionados.
- ScriptVM/host ampliado com `getentity`, `getentityproperty`, `changeentityproperty`, `findtarget`, `checkrange`, entity vars, player properties, `openborconstant`, `setidle` e `updateframe`.
- Spawn por script ganhou `clearspawnentry`, `setspawnentry`, `spawn`/`spawnentity`; `spawnscript` é preservado e executado com contexto do spawn.
- `playerkeys()` passou a refletir estados held/new/released do teclado/XInput; `keyscript`, `key1.c`...`key4.c` e `keyall.c` são disparados no runtime, com `playkeys`/`disablekeys` integrados ao input nativo.
- Contextos de ScriptVM separados por jogador cooperativo, incluindo `self`, `player`, estados de tecla e velocidades impostas por script.
- `onmovexscript`, `onmovezscript` e `onentitycollision` passam a ser invocados pelo runtime; colisão avançada permanece parcial.
- Contexto dos hooks de combate foi ampliado: `takedamagescript`/`didhitscript` e reações subsequentes recebem atacante/alvo, dano, tipo de ataque, drop e campos auxiliares de bloqueio/juggle.
- `getentityproperty` cobre propriedades legadas comuns como `animpos`, `animationID`, `xdir`, `zdir`, `tossv`, vida, posição, direção, mapa e estado de ataque.
- Regressão nova cobre hooks de tecla/movimento/colisão/spawn/combate, APIs de entidade e estabilidade de handles.
- `BUILD-PORTABLE-WINDOWS.ps1` procura CMake portátil em `tools/cmake/bin` antes dos locais do sistema.
- Workflow `.github/workflows/build-portable-win64.yml` incluído para CTest e teste end-to-end do port em Windows x64.
- Toda a entrada universal ZIP/PAK, branch, palettes, áudio e combate numérico da v0.20 foi mantida.

## v0.20.0 — Paridade de campanha, scripts, áudio, palettes e combate

- `levels.txt` `branch <name>` agora é tratado como destino de campanha para o próximo `file`, em vez de ser confundido com evento interno da fase.
- `jumptobranch(name, immediate)` resolve esses destinos no runtime; salto imediato é aplicado num ponto seguro do frame e salto não imediato entra quando a fase termina.
- `openborvariant("current_branch")` e `openborvariant("current_level")` foram adicionados ao ScriptVM.
- Alterações de `z`/altura do background entre arquivos do mesmo set são preservadas por fase.
- Pré-processador do ScriptVM ganhou macros `#define NAME(args)` com expansão de macros objeto/função e limite contra recursão infinita.
- Windows: MP3/FLAC são decodificados por Media Foundation; OGG/OGA/AAC/M4A são tentados quando o codec está disponível no sistema; XAudio2 continua sendo o backend de reprodução.
- `palette`, `alternatepal`, `remap` e `map/colormap` entram no runtime: referências por imagem e arquivos Adobe/OpenBOR `.act` geram remapeamento de cor por entidade/player.
- Jogadores cooperativos usam mapas alternativos automaticamente quando disponíveis; spawns usam o `map/colormap` definido pelo jogo.
- Tipos numerados de ataque podem selecionar `painN`, `fallN` e `riseN`, com fallback para as animações genéricas.
- Entrada universal da v0.19 (pasta/ZIP/PAK/ZIP completo do OpenBOR com `Paks/*.pak`) e todas as proteções de caminho foram mantidas.
- Regressão ampliada para branch de campanha, `z` por arquivo, macros de função, palette/remap e geração dos novos backends.

## v0.19.0

- Novo `InputResolver`: pasta, ZIP e PAK usam o mesmo pipeline de análise/conversão.
- ZIPs aninhados têm a raiz OpenBOR `data/` detectada automaticamente.
- ZIPs completos do OpenBOR com `Paks/*.pak` são aceitos; o Builder extrai PAKs internamente e seleciona o melhor projeto detectado.
- Extrator PAK nativo com validação de assinatura `PACK`, índice, offsets/tamanhos, limites defensivos e proteção contra traversal.
- Workspace temporário RAII: extrações não alteram a origem e são limpas automaticamente.
- GUI Windows ganhou seletor de ZIP/PAK além do seletor de pasta.
- `bglayer`/`fglayer` corrigidos para ratios float, ordem correta de profundidade, offsets, spacing/repeat e renderização básica de múltiplas camadas.
- `levelscript` é parseado/gerado e executado na entrada da fase; APIs ainda não mapeadas continuam diagnosticadas como PARTIAL.
- `scrollspeed` passou a influenciar o avanço da câmera no runtime.
- Builder procura CMake no PATH, em `tools/cmake/bin` e instalações comuns do Visual Studio/CMake.
- Scripts Windows atualizados com diagnóstico de CMake/MSVC e instalador auxiliar via winget.
- Regressão ampliada com ZIP aninhado, PAK direto e ZIP estilo distribuição OpenBOR contendo `Paks/TestGame.pak`.
- Teste end-to-end validado: OpenBOR ZIP -> extração PAK -> análise -> conversão -> compilação do runtime -> pacote portátil -> smoke test headless.

## v0.18.0

- ScriptVM ampliado com `switch/case/default`, `do/while`, operador ternário, operadores bitwise/shift compostos e pré-processamento básico (`#define`, `#include`, `#import`, condicionais simples).
- Includes/imports passam por normalização e validação de caminho; macros de função continuam explicitamente diagnosticadas.
- Analisador de compatibilidade reconhece a sintaxe nova e funções declaradas em arquivos incluídos/importados.
- `animationscript` passa a rodar na entrada de frame, e não a cada tick; contexto recebe o índice do frame.
- `flipframe` é parseado, emitido no C++ gerado e aplicado por player, entidades, coop e projéteis.
- `wait`, `group` e `blockade` ganharam semântica de runtime mais próxima do OpenBOR; `group min/max` controla reposição e `blockade` cria piso de backtracking.
- Áudio passou a aceitar múltiplos efeitos simultâneos, loop/speed/gain por efeito e APIs de script para música/samples.
- Decoder WAV ampliado para PCM 8/16/24/32-bit e IEEE float32.
- OGG/MP3/FLAC continuam preservados e diagnosticados até a inclusão de decoders nativos.
- Fixtures/regressão ampliados para `flipframe`, `switch`, `do/while`, ternário e `#include`.

## v0.17.0

- `models.txt` virou registro autoritativo dos modelos; aliases externos e nomes internos agora são preservados separadamente.
- Runtime procura modelos por alias de registro e também por nome interno, eliminando spawns sem modelo quando `load X` e `name Y` diferem.
- `PortGenerator` grava `openbor-video.ini`; GUI e CLI passam a gerar a mesma resolução lógica.
- Runtime gerado usa a pasta do executável como raiz por padrão no Windows, removendo dependência do current working directory.
- `ProjectScanner` reconhece ports em `assets/openbor-data`; `test <port>` agora valida ports reais.
- `build` chama CMake e produz o executável nativo do port; `package` cria pacote ZIP portátil.
- CMake/CTest agora inclui `tests/regression.cpp` oficialmente.
- Testes falsos (`|| true` e traversal só por string) foram substituídos por verificações reais.
- Adicionado `SafePath` para normalização, contenção em `data/` e rejeição de traversal/caminhos absolutos.
- Cópia de assets ignora symlinks para impedir escapes da origem.
- `StageInstruction` preserva a ordem original entre spawns e eventos, incluindo `branch`, enquanto as tabelas ordenadas por `at` permanecem disponíveis para o runtime atual.
- Workflow Windows executa regressão + conversão/build/test/package end-to-end de um fixture.
- Versões/documentação/artifacts foram alinhados em 0.17.0.

## v0.16.0

- Registro central de comandos OpenBOR com parser/runtime separados.
- Resolução lógica detectada em `video.txt`.
- Spawns estáveis por `at` + id e correções de câmera/trigger.
- Eventos básicos de fase consumidos uma vez.
- Compatibilidade desconhecida registrada sem abortar conversão.
- Multiplayer local, remap de controles, HUD e save de grupo.

## v0.26.0 — Dynamic Commands, Combo Branches e Child/AI
- Matcher `com/cmd` com hold min/max, hold-trigger, release, chord grace e sequence grace.
- `combostyle 1` com seleção dinâmica de ramo por `range/rangez/rangea`.
- Follow/recall de filhos por eixo, offsets, animação e direção.
- `modelflag no_basic` no overlay de arma e `onmodelcopy` reconhecido como caminho runtime.
- IA procura/coleta armas compatíveis.
- OGG embutido permanece pendente; sem falsa marcação de compatibilidade completa.