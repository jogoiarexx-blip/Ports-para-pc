# Validação v0.34.7

Correção do Builder genérico a partir dos PAKs fornecidos e do código OpenBOR v7533: engine/openbor.c, CMD_MODEL_CANTGRAB/CMD_MODEL_NOTGRAB, check_cangrab, check_canbegrabbed, inair/inair_range. Os conteúdos dos jogos não foram alterados.

## Resultado nos mesmos PAKs

| Jogo | Modelos/fases | PARTIAL v0.34.6 | PARTIAL v0.34.7 | UNKNOWN antes → depois |
| --- | --- | ---: | ---: | --- |
| Ghosts’n Goblins Dragon Ball | 39 / 8 | 369 | 364 | 0 → 0 |
| Evil Dead v1.4.0 | 125 / 10 | 541 | 521 | 454 → 453 |

SUPPORTED: 8380 no Ghosts, 13399 no Evil Dead. A resolução de caminhos e o conjunto de modelos/fases são iguais aos da versão anterior. cantgrab aparece 5 vezes no Ghosts e 20 no Evil Dead. O alias notgrab encontrado no Evil Dead deixa de ser desconhecido.

## Semântica corrigida

No código fornecido, cantgrab/notgrab 2 ajusta a força do próprio modelo para -999999. Qualquer outro valor, incluindo 0 e 1, ajusta sua resistência para 1. Isso não equivale a nograb e pode ser sobrescrito por comandos posteriores. Um atacante com força 1 pode agarrar um defensor com resistência 1; com força 0, não pode. A decisão deixa de usar uma comparação que rejeitava igualdade.

A implementação segue especificamente o parser v7533 fornecido. Não presume que cantgrab 0 signifique desligar uma flag booleana em todas as versões históricas.

A leitura de grabforce/grabresistance por getentityproperty usa o modelo do ator correto. O agarrão manual do jogador principal rejeita alvo com diferença da base de pelo menos 0,1, jogador fora da tolerância de 2 e movimento planar definido no frame. A velocidade por script é independente desse bloqueio.

## Testes e limites

545 verificações PASS, zero falhas: 341 regressão, 21 agarrões, 53 vínculos, 21 comandos, 41 energia, 23 terreno, 25 efeitos, 17 compatibilidade e 3 do helper de áudio. Logs atuais em tests/validation-v0.34.7. Foram acrescentadas verificações de parsing/ordem de comandos e um runtime de agarrões com força/resistência zero, positiva e negativa, igualdade, nograb independente, limites de altura, movimento do frame, alcance e leituras por script.

Ainda não há paridade integral de agarrões: paingrab, todos os estados de vulnerabilidade/invencibilidade, IA, entradas de cooperativos e regras avançadas de armas permanecem lacunas separadas. A classificação SUPPORTED de cantgrab/notgrab certifica sua tradução de força/resistência; não certifica todo o sistema de agarrões. Demais comandos de agarrão continuam PARTIAL.

As 93 chamadas do Ghosts com helper ausente continuam PARTIAL. Os jogos não foram certificados como integralmente jogáveis no Windows. Para aplicar a correção, gere os ports novamente com o Builder atualizado.

O Builder e o runtime gerado do Ghosts compilaram para Windows x64. Os dois ports gerados compilaram e inicializaram em teste sem janela no Linux. Não houve partida interativa no Windows.
