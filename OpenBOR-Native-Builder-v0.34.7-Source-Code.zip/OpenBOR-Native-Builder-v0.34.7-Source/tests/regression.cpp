#include "LevelParser.hpp"
#include "CharacterParser.hpp"
#include "CompatibilityAnalyzer.hpp"
#include "ProjectScanner.hpp"
#include "CommandRegistry.hpp"
#include "PortGenerator.hpp"
#include "SafePath.hpp"
#include "InputResolver.hpp"
#include <filesystem>
#include <algorithm>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>
#include <cstdint>
#include <cmath>
#include <cstdlib>

static int gFails = 0;
#define CHECK(cond, msg) do { if(!(cond)){ std::cerr << "FAIL: " << msg << "\n"; ++gFails; } else { std::cout << "PASS: " << msg << "\n"; } } while(0)

static void writeU32(std::ofstream& f, std::uint32_t v){ char b[4]={(char)(v&255),(char)((v>>8)&255),(char)((v>>16)&255),(char)((v>>24)&255)}; f.write(b,4); }
static bool createTestPak(const std::filesystem::path& out){
    struct Entry{std::string name,data;std::uint32_t off=0;};
    std::vector<Entry> e={
      {"data/models.txt","know Hero\nload Hero data/chars/hero.txt\n"},
      {"data/levels.txt","set Test\nfile data/levels/stage.txt\n"},
      {"data/chars/hero.txt","name Hero\ntype player\nanim idle\ndelay 8\nframe none\n"},
      {"data/levels/stage.txt","direction right\nspawn Hero\ncoords 10 200 0\nat 0\n"}
    };
    std::ofstream f(out,std::ios::binary|std::ios::trunc);if(!f)return false;f.write("PACK",4);writeU32(f,0);
    for(auto& x:e){x.off=(std::uint32_t)f.tellp();f.write(x.data.data(),(std::streamsize)x.data.size());}
    auto index=(std::uint32_t)f.tellp();for(const auto& x:e){writeU32(f,(std::uint32_t)(12+x.name.size()+1));writeU32(f,x.off);writeU32(f,(std::uint32_t)x.data.size());f.write(x.name.c_str(),(std::streamsize)x.name.size()+1);}
    writeU32(f,index);return (bool)f;
}

int main(){
    namespace fs = std::filesystem;
#ifdef OBNB_SOURCE_DIR
    fs::path sourceDir = OBNB_SOURCE_DIR;
#else
    fs::path sourceDir = fs::current_path();
#endif
    fs::path fixtureA = sourceDir / "tests/fixtures/side_scroll";
    fs::path fixtureB = sourceDir / "tests/fixtures/wide_res";


    auto scanA = ProjectScanner::scan(fixtureA);
    CHECK(scanA.hasDataDir, "fixture A has data/");
    CHECK(scanA.hasModels && scanA.hasLevels && scanA.hasVideo, "fixture A detects models/levels/video");
    auto compA = CompatibilityAnalyzer::analyze(scanA);
    CHECK(compA.logicalWidth==320 && compA.logicalHeight==240, "fixture A resolution 320x240 from video.txt");
    CHECK(compA.models==3, "fixture A models == 3");
    CHECK(compA.stages==2, "fixture A stages == 2");
    CHECK(compA.animations>=6, "fixture A animations parsed");
    CHECK(compA.scripts>=1, "fixture A script counted");
    CHECK(true, "unknown-command accounting checked on fixture B below");

    auto stages = LevelParser::parseAll(scanA.dataDir, scanA.root);
    CHECK(stages.size()==2, "parseAll returns both stages");
    CHECK(stages[0].direction=="right", "stage1 direction");
    CHECK(stages[1].cameraType==1, "stage2 fixed camera from cameratype");
    CHECK(stages[1].direction=="up", "vertical/up direction preserved");
    bool sawBgLayer=false,sawFgLayer=false;
    for(const auto& l:stages[0].layers){
        if(l.kind=="bglayer" && std::abs(l.xRatio-0.25f)<0.001f && l.xSpacing==4 && l.xRepeat==3) sawBgLayer=true;
        if(l.kind=="fglayer" && l.zOrder==25 && std::abs(l.xRatio-0.75f)<0.001f && l.xOffset==5) sawFgLayer=true;
    }
    CHECK(sawBgLayer, "bglayer floating ratio/spacing/repeat parsed with OpenBOR argument order");
    CHECK(sawFgLayer, "fglayer Z depth and floating ratio parsed with correct OpenBOR argument order");
    CHECK(stages[0].levelScript=="scripts/level1.c", "levelscript path preserved");
    CHECK(!stages[0].spawns.empty(), "stage1 has spawns");
    // Sorted by `at`, then declaration id. The 600 spawn must come before boss 700 and late thug 1400.
    CHECK(stages[0].spawns.front().at <= stages[0].spawns.back().at, "spawns sorted by at");
    bool sawBossBeforeLate = false;
    int prevAt = -1;
    for(const auto& s: stages[0].spawns){
        CHECK(s.at>=prevAt, "spawn order is stable and non-decreasing");
        prevAt = s.at;
        if(s.boss && s.at==700) sawBossBeforeLate = true;
        if(s.at==1400) CHECK(sawBossBeforeLate, "boss at 700 is ordered before thug at 1400 even if declared earlier");
        if(s.model=="Boss" && s.at==700) CHECK(s.boss, "boss flag sticks to the boss spawn");
        if(s.alias=="EarlyThug"){ CHECK(s.item=="knife", "item drop stays on the spawn"); CHECK(s.map=="2", "colormap preserved"); }
    }
    bool sawWait=false, sawBlock=false;
    for(const auto& ev: stages[0].events){
        if(ev.kind=="wait") sawWait=true;
        if(ev.kind=="blockade") sawBlock=true;
        CHECK(ev.state==SpawnState::NotTriggered, "events start NOT_TRIGGERED");
    }
    CHECK(sawWait && sawBlock, "wait and blockade captured as one-shot events");

    // Canonical OpenBOR event form: wait/group/blockade can bind to the immediately
    // following `at`, while blockade keeps its own backtracking floor value.
    fs::path eventRoot="/tmp/obor-v018-event-fixture";
    fs::remove_all(eventRoot); fs::create_directories(eventRoot/"data/levels");
    {
        std::ofstream f(eventRoot/"data/levels/events.txt");
        f << "wait\n";
        f << "at 100\n";
        f << "group 2 5\n";
        f << "at 200\n";
        f << "blockade 150\n";
        f << "at 250\n";
    }
    LevelSetDef eventSet; eventSet.name="Events";
    auto eventStage=LevelParser::parseStage(eventRoot/"data/levels/events.txt",eventRoot,eventSet);
    bool canonicalWait=false, canonicalGroup=false, canonicalBlockade=false;
    for(const auto& ev:eventStage.events){
        if(ev.kind=="wait" && ev.hasAt && ev.at==100) canonicalWait=true;
        if(ev.kind=="group" && ev.hasAt && ev.at==200 && ev.value==2 && ev.group==5) canonicalGroup=true;
        if(ev.kind=="blockade" && ev.hasAt && ev.at==250 && ev.value==150) canonicalBlockade=true;
    }
    CHECK(canonicalWait, "canonical wait + at binding");
    CHECK(canonicalGroup, "canonical group min/max + at binding");
    CHECK(canonicalBlockade, "canonical blockade floor + distinct at binding");

    // v0.20 campaign branching: OpenBOR branch labels live in levels.txt and label
    // the next `file` entry. Per-file z settings must also follow the order list.
    fs::path branchRoot="/tmp/obor-v020-branch-fixture";
    fs::remove_all(branchRoot); fs::create_directories(branchRoot/"data/levels");
    {
        std::ofstream f(branchRoot/"data/levels.txt");
        f << "set Route\n";
        f << "branch start\n";
        f << "z 100 180 90\n";
        f << "file data/levels/a.txt\n";
        f << "z 210 300 170\n";
        f << "branch alternate\n";
        f << "file data/levels/b.txt\n";
    }
    {std::ofstream(branchRoot/"data/levels/a.txt") << "direction right\n"; std::ofstream(branchRoot/"data/levels/b.txt") << "direction right\n";}
    auto branchStages=LevelParser::parseAll(branchRoot/"data",branchRoot);
    CHECK(branchStages.size()==2, "levels.txt branch fixture parses both stages");
    if(branchStages.size()==2){
        CHECK(branchStages[0].branchName=="start", "branch label attaches to first following file");
        CHECK(branchStages[1].branchName=="alternate", "second branch label attaches to its following file");
        CHECK(branchStages[0].zMin==100 && branchStages[0].zMax==180 && branchStages[0].backgroundHeight==90, "per-level z metadata preserved for first branch");
        CHECK(branchStages[1].zMin==210 && branchStages[1].zMax==300 && branchStages[1].backgroundHeight==170, "per-level z metadata preserved after z change");
    }
    CHECK(!stages[0].instructions.empty(), "unified stage instruction stream generated");
    if(stages[0].instructions.size()>=5){
        for(std::size_t i=1;i<stages[0].instructions.size();++i) CHECK(stages[0].instructions[i-1].sequence < stages[0].instructions[i].sequence, "stage instruction order preserves source sequence");
        CHECK(stages[0].instructions[0].kind==0 && stages[0].instructions[1].kind==0 && stages[0].instructions[2].kind==1, "spawn/event cross-type order is preserved");
    }

    auto chars = CharacterParser::parseAll(scanA.dataDir, scanA.root);
    const CharacterDef* bossAlias=nullptr;
    for(const auto& c: chars) if(c.modelName=="Boss") bossAlias=&c;
    CHECK(bossAlias!=nullptr, "models.txt registry alias is preserved");
    if(bossAlias) CHECK(bossAlias->name=="BossGeneric", "registry alias can differ from internal model name");
    const CharacterDef* hero=nullptr;
    for(const auto& c: chars) if(c.type=="player") hero=&c;
    CHECK(hero!=nullptr, "player model detected by type, not by name");
    if(hero){
        CHECK(hero->health==120, "hero health");
        bool sawInfinite=false, sawNone=false, sawAttack=false;
        for(const auto& a: hero->animations){
            for(const auto& f: a.frames){
                if(f.delay<0) sawInfinite=true;
                if(f.sprite=="none") sawNone=true;
                if(f.hasAttack) sawAttack=true;
            }
        }
        CHECK(sawInfinite, "delay infinite");
        CHECK(sawNone, "frame none");
        CHECK(sawAttack, "per-frame attack box");
        CHECK(!hero->animationScript.empty(), "animationscript recorded");
        bool sawFlipFrame=false;
        for(const auto& a:hero->animations) if(a.name=="walk" && a.flipFrame==1) sawFlipFrame=true;
        CHECK(sawFlipFrame, "flipframe parsed into animation metadata");
    }


    // v0.20 palette/remap parsing: image- and ACT-based references are preserved
    // so the generated runtime can select per-entity/per-player color maps.
    fs::path paletteRoot="/tmp/obor-v020-palette-fixture";
    fs::remove_all(paletteRoot); fs::create_directories(paletteRoot/"data/chars");
    fs::path paletteModel=paletteRoot/"data/chars/colorhero.txt";
    {
        std::ofstream f(paletteModel);
        f << "name ColorHero\n";
        f << "type player\n";
        f << "palette data/palettes/base.act\n";
        f << "alternatepal data/palettes/blue.act\n";
        f << "remap data/palettes/source.gif data/palettes/red.gif\n";
        f << "anim idle\ndelay 8\nframe none\n";
    }
    { std::ofstream f(paletteRoot/"data/models.txt"); f << "load ColorHeroAlias data/chars/colorhero.txt\n"; }
    auto colorChars=CharacterParser::parseAll(paletteRoot/"data",paletteRoot);
    CHECK(colorChars.size()==1, "palette fixture model registered through models.txt");
    if(!colorChars.empty()){
        const auto& colorHero=colorChars.front();
        CHECK(colorHero.modelName=="ColorHeroAlias", "palette fixture keeps external model alias");
        CHECK(colorHero.palettePath=="palettes/base.act", "base palette path normalized relative to data/");
        CHECK(colorHero.alternatePalettes.size()==1 && colorHero.alternatePalettes[0]=="palettes/blue.act", "alternatepal parsed and normalized");
        CHECK(colorHero.paletteRemaps.size()==1 && colorHero.paletteRemaps[0].source=="palettes/source.gif" && colorHero.paletteRemaps[0].target=="palettes/red.gif", "remap source/target parsed and normalized");
    }

    auto info = CommandRegistry::lookup("animationscript");
    CHECK(info.parser && info.status==CommandStatus::Partial, "animationscript is PARTIAL (parser yes, runtime partial) not fake SUPPORTED");
    auto delay = CommandRegistry::lookup("delay");
    CHECK(delay.status==CommandStatus::Supported && delay.runtime, "delay is SUPPORTED with runtime");
    auto flipframe = CommandRegistry::lookup("flipframe");
    CHECK(flipframe.status==CommandStatus::Supported && flipframe.runtime, "flipframe is SUPPORTED with runtime");
    auto levelscript = CommandRegistry::lookup("levelscript");
    CHECK(levelscript.parser && levelscript.runtime && levelscript.status==CommandStatus::Partial, "levelscript is executed with ScriptVM and honestly marked PARTIAL");
    bool falseScriptWarning=false;
    for(const auto& issue:compA.issues) if(issue.command=="script-file") falseScriptWarning=true;
    CHECK(!falseScriptWarning, "supported switch/do/include script has no false script-file warning");
    fs::path macroRoot="/tmp/obor-v020-macro-fixture"; fs::remove_all(macroRoot); fs::create_directories(macroRoot/"data");
    {std::ofstream(macroRoot/"data/models.txt") << "load Hero data/hero.txt\n"; std::ofstream(macroRoot/"data/levels.txt") << "set T\nfile data/stage.txt\n"; std::ofstream(macroRoot/"data/hero.txt") << "name Hero\ntype player\nanim idle\nframe none\n"; std::ofstream(macroRoot/"data/stage.txt") << "levelscript data/test.c\n"; std::ofstream(macroRoot/"data/test.c") << "#define TWICE(x) ((x)+(x))\nvoid main(){ int a=TWICE(4); log(a); }\n";}
    auto macroScan=ProjectScanner::scan(macroRoot); auto macroComp=CompatibilityAnalyzer::analyze(macroScan); bool macroWarning=false; for(const auto&i:macroComp.issues) if(i.command=="script-file") macroWarning=true; CHECK(!macroWarning, "function-like #define is recognized by compatibility analyzer");
    // v0.21 script-event coverage: model key/move/collision hooks and spawn-entry scripts
    // are not only preserved; the generated runtime has dedicated firing paths for them.
    fs::path scriptRoot="/tmp/obor-v021-script-hooks";fs::remove_all(scriptRoot);fs::create_directories(scriptRoot/"data/chars");fs::create_directories(scriptRoot/"data/levels");fs::create_directories(scriptRoot/"data/scripts");
    {std::ofstream(scriptRoot/"data/models.txt") << "load HookHero data/chars/hookhero.txt\n";std::ofstream(scriptRoot/"data/levels.txt") << "set H\nfile data/levels/h.txt\n";
     std::ofstream(scriptRoot/"data/chars/hookhero.txt") << "name HookHero\ntype player\nkeyscript data/scripts/keymodel.c\nonmovexscript data/scripts/movex.c\nonmovezscript data/scripts/movez.c\nonentitycollision data/scripts/collision.c\ntakedamagescript data/scripts/take.c\ndidhitscript data/scripts/hit.c\nanim idle\ndelay 8\nframe none\n";
     std::ofstream(scriptRoot/"data/levels/h.txt") << "spawn HookHero\ncoords 40 200 0\nspawnscript data/scripts/spawn.c\nat 0\n";
     std::ofstream(scriptRoot/"data/scripts/keymodel.c") << "void main(){ int p=getlocalvar(\"player\"); if(playerkeys(p,1,\"attack\")){ void self=getlocalvar(\"self\"); setentityvar(self,\"pressed\",1); updateframe(self,0); } }\n";
     std::ofstream(scriptRoot/"data/scripts/movex.c") << "void main(){ void self=getlocalvar(\"self\"); changeentityproperty(self,\"velocity\",0,0,0); }\n";
     std::ofstream(scriptRoot/"data/scripts/movez.c") << "void main(){ void self=getlocalvar(\"self\"); setidle(self); }\n";
     std::ofstream(scriptRoot/"data/scripts/collision.c") << "void main(){ void self=getlocalvar(\"self\"); void target=findtarget(self); if(target && checkrange(self,target)){ setentityvar(self,\"near\",1); } }\n";
     std::ofstream(scriptRoot/"data/scripts/take.c") << "void main(){ void attacker=getlocalvar(\"attacker\"); int damage=getlocalvar(\"damage\"); log(damage); }\n";
     std::ofstream(scriptRoot/"data/scripts/hit.c") << "void main(){ void target=getlocalvar(\"damagetaker\"); int t=getlocalvar(\"attacktype\"); log(t); }\n";
     std::ofstream(scriptRoot/"data/scripts/spawn.c") << "void main(){ void self=getlocalvar(\"self\"); setentityvar(self,\"spawnx\",getlocalvar(\"spawnx\")); }\n";
     std::ofstream(scriptRoot/"data/scripts/key1.c") << "void main(){ setglobalvar(\"global_key_seen\",1); }\n";
     std::ofstream(scriptRoot/"data/scripts/keyall.c") << "void main(){ setglobalvar(\"keyall_seen\",1); }\n";}
    auto hookScan=ProjectScanner::scan(scriptRoot);auto hookChars=CharacterParser::parseAll(hookScan.dataDir,hookScan.root);auto hookStages=LevelParser::parseAll(hookScan.dataDir,hookScan.root);auto hookComp=CompatibilityAnalyzer::analyze(hookScan);
    CHECK(hookChars.size()==1 && hookChars[0].keyScript=="data/scripts/keymodel.c", "keyscript parsed for player model");
    CHECK(!hookChars.empty() && !hookChars[0].onMoveXScript.empty() && !hookChars[0].onMoveZScript.empty() && !hookChars[0].onEntityCollisionScript.empty(), "move/collision model hooks parsed");
    CHECK(!hookStages.empty() && !hookStages[0].spawns.empty() && hookStages[0].spawns[0].spawnScript=="scripts/spawn.c", "spawnscript parsed and normalized on spawn entry");
    auto keyInfo=CommandRegistry::lookup("keyscript"), spawnScriptInfo=CommandRegistry::lookup("spawnscript");
    CHECK(keyInfo.runtime && keyInfo.status==CommandStatus::Partial, "keyscript now has a runtime firing path");
    CHECK(spawnScriptInfo.runtime && spawnScriptInfo.status==CommandStatus::Partial, "spawnscript now has a runtime firing path");
    bool hookApiWarning=false;for(const auto&i:hookComp.issues)if(i.command=="script-file")hookApiWarning=true;CHECK(!hookApiWarning, "v0.21 supported script APIs do not produce false compatibility warnings");


    // v0.22 block/guard + direct drawing + modern property constants.
    fs::path blockRoot="/tmp/obor-v022-block-fixture";fs::remove_all(blockRoot);fs::create_directories(blockRoot/"data/chars");fs::create_directories(blockRoot/"data/levels");fs::create_directories(blockRoot/"data/scripts");
    {std::ofstream(blockRoot/"data/models.txt") << "load Guard data/chars/guard.txt\n";std::ofstream(blockRoot/"data/levels.txt") << "set B\nfile data/levels/b.txt\n";
     std::ofstream(blockRoot/"data/chars/guard.txt") << "name Guard\ntype enemy\nblockodds 3\nblockpain 12\nthold 4\nguardpoints 40\nguardrate 2\nblockback 1\ndidblockscript data/scripts/block.c\nonblockwscript data/scripts/wall.c\nanim idle\nframe none\nanim block\nframe none\n";
     std::ofstream(blockRoot/"data/levels/b.txt") << "spawn Guard\ncoords 80 200 0\nat 0\n";
     std::ofstream(blockRoot/"data/scripts/block.c") << "void main(){ void self=getlocalvar(\"self\"); void m=getentityproperty(self,openborconstant(\"ENTITY_PROPERTY_MODELDATA\")); int gp=getentityproperty(self,openborconstant(\"ENTITY_PROPERTY_GUARD_POINTS\")); drawbox(4,4,32,6,100,rgbcolor(30,200,80)); drawline(4,12,36,12,101,rgbcolor(255,255,255)); log(getmodelproperty(m,openborconstant(\"MODEL_PROPERTY_BLOCK_ODDS\"))); }\n";
     std::ofstream(blockRoot/"data/scripts/wall.c") << "void main(){ drawdot(1,1,100,rgbcolor(255,0,0)); }\n";}
    auto blockScan=ProjectScanner::scan(blockRoot);auto blockChars=CharacterParser::parseAll(blockScan.dataDir,blockScan.root);auto blockComp=CompatibilityAnalyzer::analyze(blockScan);
    CHECK(blockChars.size()==1, "v0.22 blocking fixture model parsed");
    if(!blockChars.empty()){CHECK(blockChars[0].blockOdds==3 && blockChars[0].blockPain==12 && blockChars[0].blockThreshold==4, "block odds/pain/threshold parsed");CHECK(blockChars[0].guardPoints==40 && blockChars[0].guardRate==2 && blockChars[0].blockBack, "guard points/rate/blockback parsed");CHECK(!blockChars[0].didBlockScript.empty() && !blockChars[0].onBlockWScript.empty(), "didblock and wall block hooks parsed");}
    CHECK(CommandRegistry::lookup("guardpoints").runtime, "guardpoints registered as runtime-supported");
    CHECK(CommandRegistry::lookup("didblockscript").runtime, "didblockscript has runtime firing path");
    bool blockApiWarning=false;for(const auto&i:blockComp.issues)if(i.command=="script-file")blockApiWarning=true;CHECK(!blockApiWarning, "v0.22 drawing/model-property APIs do not produce false warnings");

    // v0.27 gameplay parity: cutscene metadata, legacy blast/burn, shadows,
    // death/lifespan/landing, defense, boss music, water and original HUD metadata.
    fs::path gp27Root="/tmp/obor-v027-gameplay-fixture";fs::remove_all(gp27Root);fs::create_directories(gp27Root/"data/chars");fs::create_directories(gp27Root/"data/levels");fs::create_directories(gp27Root/"data/scenes");fs::create_directories(gp27Root/"data/scripts");
    {std::ofstream(gp27Root/"data/models.txt") << "blockratio 1\nmpblock 1\nnochipdeath 1\nload Hero27 data/chars/hero27.txt\n";
     std::ofstream(gp27Root/"data/levels.txt") << "set V27\nscene data/scenes/intro.txt\nfile data/levels/stage27.txt\n";
     std::ofstream(gp27Root/"data/chars/hero27.txt") << "name Hero27\ntype player\nmp 80\nknockdowncount 6\nshadow 4\ndiesound data/sounds/die.wav\nlifespan 2.5\ndefense all 0.75 0.8 0.9 2 3\nicon data/sprites/icon.gif\nnolife 0\nlifebarstatus 1\nlifeposition 12 14\nnameposition 16 18\niconposition 3 5\nanimationscript data/scripts/anim.c\nanim fall\nlandframe 1 1\ndelay 4\nframe none\ndelay 4\nframe none\nanim attack1\n@cmd stamp 7\nblast 0 0 20 20 12 1 1 9 14\nframe none\nanim attack2\nburn 0 0 20 20 7 2 1 1 8 11\nframe none\n";
     std::ofstream(gp27Root/"data/scripts/anim.c") << "void stamp(int x){ setlocalvar(\"stamp\", x); }\n";
     std::ofstream(gp27Root/"data/levels/stage27.txt") << "bossmusic data/music/boss.ogg 240\nwater data/sprites/water.gif 5\nrock 1\nspawn Hero27\ncoords 80 200 0\nboss 1\nat 0\n";
     std::ofstream(gp27Root/"data/scenes/intro.txt") << "music data/music/intro.ogg 1\nanimation data/scenes/intro.gif 0 0 1\n";}
    auto gp27Chars=CharacterParser::parseAll(gp27Root/"data",gp27Root);auto gp27Stages=LevelParser::parseAll(gp27Root/"data",gp27Root);
    CHECK(gp27Chars.size()==1, "v0.27 gameplay fixture character parsed");
    if(!gp27Chars.empty()){
        const auto& c=gp27Chars[0];
        CHECK(c.mp==80 && std::abs(c.knockdownCount-6.0f)<0.001f, "v0.28 mp/knockdowncount parsed");
        CHECK(c.globalBlockRatio && c.globalMpBlock && c.noChipDeath, "v0.29 models.txt global chip rules parsed");
        CHECK(c.shadow==4 && c.dieSound=="sounds/die.wav" && std::abs(c.lifespanSeconds-2.5f)<0.001f, "v0.27 shadow/diesound/lifespan parsed");
        CHECK(c.defenses.size()==1 && std::abs(c.defenses[0].factor-0.75f)<0.001f, "v0.27 defense parsed");
        CHECK(!c.defenses[0].blockRatioDefined && !c.defenses[0].blockTypeDefined, "v0.29 omitted defense chip fields fall back to models.txt globals");
        CHECK(c.iconPath=="sprites/icon.gif" && c.lifePositionX==12 && c.lifePositionY==14 && c.namePositionX==16 && c.namePositionY==18 && c.iconPositionX==3 && c.iconPositionY==5, "v0.27 original HUD metadata parsed");
        bool sawLand=false,sawBlast=false,sawBurn=false,sawCmd=false;
        for(const auto& a:c.animations){
            if(a.name=="fall" && a.landFrame==1 && a.landDust==1)sawLand=true;
            for(const auto& f:a.frames) if(f.hasAttack){
                if(f.attack.type==1001){sawBlast=f.attack.fallForce==1&&f.attack.penetration==1&&f.attack.noFlash==1&&f.attack.pauseTime==9&&f.attack.zDepth==14&&f.dropVx==2&&f.dropVy==-3;if(f.animationCommand.find("stamp(7);")!=std::string::npos)sawCmd=true;}
                if(f.attack.type==1002)sawBurn=f.attack.fallForce==2&&f.attack.penetration==1&&f.attack.noFlash==1&&f.attack.pauseTime==8&&f.attack.zDepth==11;
            }
        }
        CHECK(sawLand, "v0.27 landframe parsed");CHECK(sawBlast && sawBurn, "v0.32 blast/burn legacy parameter order and reactions parsed");
        CHECK(sawCmd, "v0.32 @cmd binds generated function call to the immediately following frame");
    }
    CHECK(gp27Stages.size()==1, "v0.27 gameplay fixture stage parsed");
    if(!gp27Stages.empty()){
        const auto& st=gp27Stages[0];
        CHECK(st.bossMusic=="music/boss.ogg" && st.bossMusicOffset==240, "v0.27 bossmusic parsed");
        CHECK(st.waterPath=="sprites/water.gif" && st.waterWarp==5 && st.rockMode==1, "v0.28 water/rock parsed");
        CHECK(!st.preSceneFile.empty() && st.sceneAnimations.size()==1 && st.sceneAnimations[0].path=="scenes/intro.gif", "v0.27 scene/animation cutscene parsed");
    }
    CHECK(CommandRegistry::lookup("blast").runtime && CommandRegistry::lookup("burn").runtime, "v0.27 blast/burn have runtime paths");
    CHECK(CommandRegistry::lookup("@cmd").runtime, "v0.32 @cmd has ScriptVM runtime path");
    CHECK(CommandRegistry::lookup("diesound").runtime && CommandRegistry::lookup("lifespan").runtime, "v0.27 diesound/lifespan have runtime paths");
    CHECK(CommandRegistry::lookup("defense").runtime && CommandRegistry::lookup("bossmusic").runtime && CommandRegistry::lookup("water").runtime && CommandRegistry::lookup("rock").runtime, "v0.28 defense/bossmusic/water/rock have runtime paths");
    CHECK(CommandRegistry::lookup("blockratio").runtime && CommandRegistry::lookup("mpblock").runtime && CommandRegistry::lookup("nochipdeath").runtime, "v0.29 global chip rules have runtime paths");

    // v0.23 advanced combat/AI/projectile model metadata.
    fs::path aiRoot="/tmp/obor-v023-ai-fixture";fs::remove_all(aiRoot);fs::create_directories(aiRoot/"data/chars");fs::create_directories(aiRoot/"data/levels");fs::create_directories(aiRoot/"data/scripts");
    {std::ofstream(aiRoot/"data/models.txt") << "load Hunter data/chars/hunter.txt\n";std::ofstream(aiRoot/"data/levels.txt") << "set AI\nfile data/levels/ai.txt\n";
     std::ofstream(aiRoot/"data/chars/hunter.txt") << "name Hunter\ntype enemy\naggression 42\naiattack 131081\naimove 65538\ncandamage 4\nhostile 4\nprojectilehit 8\nnograb 1\ngrabforce 5\ngrabresistance 7\nthrowdamage 33\nthrowdist 48\nthrowheight 6\nbounce 2\nbouncefactor 0.6\nsubject_to_gravity 1\nondoattackscript data/scripts/attack.c\nanim idle\nframe none\nanim attack1\nattack 0 0 20 20 5\nframe none\nanim attack4\nattack4 0 0 20 20 8\nframe none\n";
     std::ofstream(aiRoot/"data/levels/ai.txt") << "spawn Hunter\ncoords 80 200 0\nat 0\n";std::ofstream(aiRoot/"data/scripts/attack.c") << "void main(){ performattack(getlocalvar(\"self\"), \"attack4\"); }\n";}
    auto aiScan=ProjectScanner::scan(aiRoot);auto aiChars=CharacterParser::parseAll(aiScan.dataDir,aiScan.root);
    CHECK(aiChars.size()==1, "v0.23 AI fixture model parsed");
    if(!aiChars.empty()){const auto& c=aiChars[0];CHECK(c.aggression==42 && c.aiAttack==131081 && c.aiMove==65538, "aggression/aiattack/aimove parsed");CHECK(c.canDamageMask==4 && c.hostileMask==4 && c.projectileHitMask==8, "faction/projectile masks parsed");CHECK(c.noGrab && c.grabForce==5 && c.grabResistance==7, "grab restrictions parsed");CHECK(c.throwDamage==33 && std::abs(c.throwDistance-48.0f)<0.001f && std::abs(c.throwHeight-6.0f)<0.001f, "model throw tuning parsed");CHECK(c.bounce==2 && std::abs(c.bounceFactor-0.6f)<0.001f && c.subjectToGravity, "projectile gravity/bounce parsed");CHECK(!c.onDoAttackScript.empty(), "ondoattackscript preserved");}
    // v0.33 canonical textual faction masks and signed aggression.
    fs::path factionRoot="/tmp/obor-v033-faction-fixture";fs::remove_all(factionRoot);fs::create_directories(factionRoot/"data/chars");
    {std::ofstream(factionRoot/"data/models.txt") << "load MaskEnemy data/chars/mask.txt\n";
     std::ofstream(factionRoot/"data/chars/mask.txt") << "name MaskEnemy\ntype enemy\naggression -30\nhostile player npc\ncandamage player npc shot\nprojectilehit enemy obstacle\nanim idle\nframe none\n";}
    auto factionChars=CharacterParser::parseAll(factionRoot/"data",factionRoot);
    CHECK(factionChars.size()==1,"v0.33 textual faction fixture parsed");
    if(!factionChars.empty()){const auto&c=factionChars.front();CHECK(c.aggression==-30,"v0.33 negative aggression preserved");CHECK(c.hostileMask==((1<<2)|(1<<12)),"v0.33 hostile textual type mask parsed");CHECK(c.canDamageMask==((1<<2)|(1<<12)|(1<<8)),"v0.33 candamage textual type mask parsed");CHECK(c.projectileHitMask==((1<<3)|(1<<5)),"v0.33 projectilehit textual type mask parsed");}
    CHECK(CommandRegistry::lookup("hostile").status==CommandStatus::Supported && CommandRegistry::lookup("candamage").status==CommandStatus::Supported,"v0.33 hostile/candamage are supported after native faction split");
    CHECK(CommandRegistry::lookup("aggression").status==CommandStatus::Supported,"v0.33 signed aggression is supported");
    CHECK(CommandRegistry::lookup("followanim").status==CommandStatus::Supported && CommandRegistry::lookup("followcond").status==CommandStatus::Supported,"v0.33 followanim/followcond execute documented hit conditions");
    CHECK(CommandRegistry::lookup("subentity").status==CommandStatus::Supported && CommandRegistry::lookup("spawnframe").status==CommandStatus::Supported,"v0.33 basic child spawn lifecycle supported");
    CHECK(CommandRegistry::lookup("group").status==CommandStatus::Supported && CommandRegistry::lookup("wait").status==CommandStatus::Supported,"v0.33 group/wait stage flow supported");
    // No-level projects must still emit a compilable zero-stage sentinel.
    fs::path factionOut="/tmp/obor-v033-faction-port-reg";fs::remove_all(factionOut);auto factionScan=ProjectScanner::scan(factionRoot);auto factionComp=CompatibilityAnalyzer::analyze(factionScan);PortGenerator::generate(factionScan,factionComp,factionOut);
    {std::ifstream in(factionOut/"runtime/generated/GeneratedStages.cpp");std::string body((std::istreambuf_iterator<char>(in)),{});CHECK(body.find("\"\",0,0,\"\",\"\",false,nullptr,0")!=std::string::npos,"v0.33 zero-stage sentinel includes rockMode before cutscene fields");}

    CHECK(CommandRegistry::lookup("aiattack").runtime && CommandRegistry::lookup("aimove").runtime, "AI commands registered for runtime");
    CHECK(CommandRegistry::lookup("projectilehit").runtime && CommandRegistry::lookup("bouncefactor").runtime, "projectile behavior commands registered for runtime");
    CHECK(CommandRegistry::lookup("ondoattackscript").runtime, "ondoattackscript has runtime firing path");
    fs::path aiOut="/tmp/obor-v023-ai-port";fs::remove_all(aiOut);auto aiComp=CompatibilityAnalyzer::analyze(aiScan);PortGenerator::generate(aiScan,aiComp,aiOut);
    {std::ifstream in(aiOut/"runtime/src/Engine.cpp");std::string body((std::istreambuf_iterator<char>(in)),{});CHECK(body.find("AI_NOATTACK")!=std::string::npos && body.find("highestAttackIndex")!=std::string::npos, "generated runtime contains advanced AI and attack4+ combo logic");CHECK(body.find("Projectile bounce")!=std::string::npos && body.find("targetAllowed")!=std::string::npos, "generated runtime contains bounce/faction-aware projectile logic");CHECK(body.find("script-player-performattack")!=std::string::npos && body.find("entity-ondoattack")!=std::string::npos, "performattack/ondoattack are stateful runtime events");CHECK(body.find("cp.equippedWeapon")!=std::string::npos && body.find("tryPickupWeapon(cp)")!=std::string::npos, "coop players keep independent equipped-weapon/projectile state");}


    // v0.24 combo/cancel/follow/counter + weapon model + child spawn parity.
    fs::path comboRoot="/tmp/obor-v024-combo-fixture";fs::remove_all(comboRoot);fs::create_directories(comboRoot/"data/chars");fs::create_directories(comboRoot/"data/levels");
    {std::ofstream(comboRoot/"data/models.txt") << "load ComboHero data/chars/combo.txt\nload BladeGun data/chars/weapon.txt\nload Minion data/chars/minion.txt\nload Bullet data/chars/bullet.txt\n";
     std::ofstream(comboRoot/"data/levels.txt") << "set C\nfile data/levels/c.txt\n";
     std::ofstream(comboRoot/"data/chars/combo.txt") << "name ComboHero\ntype player\natchain 1 1 2 3\ncombostyle 2\ncombodelay 80\nweapons BladeGun\nsubentity Minion\nanim idle\nframe none\nanim attack1\nfollowanim 2\nfollowcond 3\ncounterrange 0 2 3 0\ncancel 0 2 1 a2 freespecial2\ncustentity Minion\nspawnframe 1 12 3 0 0\nweaponframe 1 1\nattack 0 0 20 20 5\nframe none\nframe none\nanim attack2\nattack 0 0 20 20 6\nframe none\nanim attack3\nattack 0 0 20 20 7\nframe none\nanim follow2\nattack 0 0 22 20 9\nframe none\nanim freespecial2\nattack 0 0 24 20 10\nframe none\n";
     std::ofstream(comboRoot/"data/chars/weapon.txt") << "name BladeGun\ntype none\nshootnum 3\nproject Bullet\nanim idle\nframe none\nanim attack1\nthrowframe 0 0 3 0\nframe none\n";
     std::ofstream(comboRoot/"data/chars/minion.txt") << "name Minion\ntype enemy\nanim idle\nframe none\n";
     std::ofstream(comboRoot/"data/chars/bullet.txt") << "name Bullet\ntype projectile\nanim idle\nattack 0 0 8 8 3\nframe none\n";
     std::ofstream(comboRoot/"data/levels/c.txt") << "spawn ComboHero\ncoords 60 200 0\nat 0\n";}
    auto comboScan=ProjectScanner::scan(comboRoot);auto comboChars=CharacterParser::parseAll(comboScan.dataDir,comboScan.root);const CharacterDef* comboHero=nullptr;const CharacterDef* weaponModel=nullptr;for(const auto&c:comboChars){if(c.modelName=="ComboHero")comboHero=&c;if(c.modelName=="BladeGun")weaponModel=&c;}
    CHECK(comboHero!=nullptr && weaponModel!=nullptr, "v0.24 combo/weapon fixture models parsed");
    if(comboHero){CHECK(comboHero->attackChain.size()==4 && comboHero->attackChain[0]==1 && comboHero->attackChain[2]==2 && comboHero->comboStyle==2 && comboHero->comboDelay==80, "atchain/combostyle/combodelay metadata preserved");CHECK(comboHero->weapons.size()==1 && comboHero->weapons[0]=="BladeGun" && comboHero->subEntityModel=="Minion", "weapon list and subentity metadata preserved");bool advancedAnim=false;for(const auto&a:comboHero->animations)if(a.name=="attack1"){advancedAnim=a.followAnim==2&&a.followCond==3&&a.counterStart==0&&a.counterEnd==2&&!a.counterTakesDamage&&!a.cancels.empty()&&a.spawnFrame==1&&a.weaponFrame==1;}CHECK(advancedAnim,"follow/counter/cancel/spawnframe/weaponframe parsed on animation");}
    if(weaponModel)CHECK(weaponModel->shootNum==3 && weaponModel->projectModel=="Bullet", "limited-use weapon model and projectile parsed");
    CHECK(CommandRegistry::lookup("atchain").runtime && CommandRegistry::lookup("cancel").runtime && CommandRegistry::lookup("counterrange").runtime, "combo/cancel/counter commands have runtime paths");
    CHECK(CommandRegistry::lookup("weapons").runtime && CommandRegistry::lookup("spawnframe").runtime && CommandRegistry::lookup("summonframe").runtime, "weapon/child-spawn commands have runtime paths");
    fs::path comboOut="/tmp/obor-v024-combo-port";fs::remove_all(comboOut);auto comboComp=CompatibilityAnalyzer::analyze(comboScan);PortGenerator::generate(comboScan,comboComp,comboOut);
    {std::ifstream in(comboOut/"runtime/src/Engine.cpp");std::string body((std::istreambuf_iterator<char>(in)),{});CHECK(body.find("cancelTarget")!=std::string::npos && body.find("counterFor")!=std::string::npos && body.find("followConditionPass")!=std::string::npos, "generated runtime contains cancel/counter/follow execution");CHECK(body.find("findActionAnimation")!=std::string::npos && body.find("weaponUses")!=std::string::npos, "generated runtime overlays weapon animations and limited uses");CHECK(body.find("summonedChild")!=std::string::npos && body.find("queueChildSpawn")!=std::string::npos, "generated runtime contains spawnframe/summonframe child lifecycle");}


    // v0.25 native command history + weapon loss/drop + child lifecycle/follow metadata.
    fs::path lifeRoot="/tmp/obor-v025-lifecycle-fixture";fs::remove_all(lifeRoot);fs::create_directories(lifeRoot/"data/chars");fs::create_directories(lifeRoot/"data/levels");
    {std::ofstream(lifeRoot/"data/models.txt") << "load LifeHero data/chars/hero.txt\nload GunModel data/chars/gun.txt\nload GunItem data/chars/item.txt\nload Pet data/chars/pet.txt\n";
     std::ofstream(lifeRoot/"data/levels.txt") << "set L\nfile data/levels/l.txt\n";
     std::ofstream(lifeRoot/"data/chars/hero.txt") << "name LifeHero\ntype player\nweapons GunModel LifeHero\nweaploss 1 0\ncom f a 1\nsubentity Pet\nsummonkill 1\nanim idle\nframe none\nanim attack1\nsummonframe 0 8 0 0 0\nunsummonframe 1\nframe none\nframe none\nanim freespecial1\nattack 0 0 20 20 9\nframe none\n";
     std::ofstream(lifeRoot/"data/chars/gun.txt") << "name GunModel\ntype none\nshootnum 2\ntypeshot 1\nweaploss 2 0\nanim idle\nframe none\nanim attack1\nframe none\n";
     std::ofstream(lifeRoot/"data/chars/item.txt") << "name GunItem\ntype item\nsubtype weapon\nweapnum 1\ncounter 3\nanim idle\nframe none\nanim respawn\nframe none\n";
     std::ofstream(lifeRoot/"data/chars/pet.txt") << "name Pet\ntype npc\nsubtype follow\nchild_follow_offset_x 18\nchild_follow_offset_z 4\nchild_follow_range_base_max 90\nchild_follow_range_recall_base_max 260\nanim idle\nframe none\nanim walk\nframe none\n";
     std::ofstream(lifeRoot/"data/levels/l.txt") << "spawn GunItem\ncoords 80 200 0\nat 0\n";}
    auto lifeScan=ProjectScanner::scan(lifeRoot);auto lifeChars=CharacterParser::parseAll(lifeScan.dataDir,lifeScan.root);const CharacterDef*lifeHero=nullptr,*gun=nullptr,*item=nullptr,*pet=nullptr;for(const auto&c:lifeChars){if(c.modelName=="LifeHero")lifeHero=&c;else if(c.modelName=="GunModel")gun=&c;else if(c.modelName=="GunItem")item=&c;else if(c.modelName=="Pet")pet=&c;}
    CHECK(lifeHero&&gun&&item&&pet,"v0.25 lifecycle fixture models parsed");
    if(lifeHero){CHECK(lifeHero->commands.size()==1&&lifeHero->commands[0].sequence=="f a"&&lifeHero->commands[0].targetAnimation=="1","com command sequence/target parsed");CHECK(lifeHero->weaponLossDefined&&lifeHero->weaponLossFlag==1&&lifeHero->summonKill==1,"base weaploss and summonkill parsed");bool lifeAnim=false;for(const auto&a:lifeHero->animations)if(a.name=="attack1")lifeAnim=a.summonFrame&&a.spawnFrame==0&&a.unsummonFrame==1;CHECK(lifeAnim,"summonframe + unsummonframe parsed");}
    if(gun)CHECK(gun->weaponLossDefined&&gun->weaponLossFlag==2&&gun->shootNum==2&&gun->typeShot,"weapon-specific weaploss overrides base and typeshot parsed");
    if(item)CHECK(item->weaponDropCounter==3&&item->weaponNumber==1,"weapon pickup drop counter/index parsed");
    if(pet)CHECK(std::abs(pet->childFollowOffsetX-18.0f)<0.01f&&std::abs(pet->childFollowRange-90.0f)<0.01f&&std::abs(pet->childRecallRange-260.0f)<0.01f,"child follow/recall tuning parsed");
    CHECK(CommandRegistry::lookup("com").runtime&&CommandRegistry::lookup("weaploss").runtime&&CommandRegistry::lookup("unsummonframe").runtime,"v0.25 command/weapon-loss/child-lifecycle registry paths active");
    fs::path lifeOut="/tmp/obor-v025-lifecycle-port";fs::remove_all(lifeOut);auto lifeComp=CompatibilityAnalyzer::analyze(lifeScan);PortGenerator::generate(lifeScan,lifeComp,lifeOut);
    {std::ifstream in(lifeOut/"runtime/src/Engine.cpp");std::string body((std::istreambuf_iterator<char>(in)),{});CHECK(body.find("commandTarget")!=std::string::npos&&body.find("recordInputHistory")!=std::string::npos,"generated runtime contains native COM input history matcher");CHECK(body.find("dropPlayerWeapon")!=std::string::npos&&body.find("flushWeaponDrops")!=std::string::npos,"generated runtime contains physical weapon loss/drop lifecycle");CHECK(body.find("unsummonChildren")!=std::string::npos&&body.find("updateChildFollowing")!=std::string::npos,"generated runtime contains unsummon and child follow/recall lifecycle");}


    // v0.26 timed commands, dynamic combostyle=1, per-axis child follow and model-copy flags.
    fs::path v26Root="/tmp/obor-v026-command-combo-fixture";fs::remove_all(v26Root);fs::create_directories(v26Root/"data/chars");fs::create_directories(v26Root/"data/levels");
    {std::ofstream(v26Root/"data/models.txt") << "load DynamicHero data/chars/hero.txt\nload NoBasicWeapon data/chars/weapon.txt\nload SmartPet data/chars/pet.txt\n";
     std::ofstream(v26Root/"data/levels.txt") << "set V26\nfile data/levels/l.txt\n";
     std::ofstream(v26Root/"data/chars/hero.txt") << "name DynamicHero\ntype player\natchain 1 2 5 0 3 3 6 0 4 0\ncombostyle 1\ncombodelay 90\nweapons NoBasicWeapon\ncom f[3][8] + a -> b +[2] -> ~a :[10] 1\nanim idle\nframe none\nanim attack1\nrange 0 20\nframe none\nanim attack2\nrange 0 28\nrangez 0 12\nframe none\nanim attack3\nrange 29 60\nframe none\nanim attack4\nrange 61 120\nframe none\nanim attack5\nframe none\nanim attack6\nframe none\nanim freespecial1\nframe none\n";
     std::ofstream(v26Root/"data/chars/weapon.txt") << "name NoBasicWeapon\ntype none\nmodelflag no_basic no_script\nanim attack1\nframe none\n";
     std::ofstream(v26Root/"data/chars/pet.txt") << "name SmartPet\ntype npc\nsubtype follow\nchild_follow_offset_x 10\nchild_follow_range_x_min -30\nchild_follow_range_x_max 40\nchild_follow_range_z_min -12\nchild_follow_range_z_max 12\nchild_follow_range_recall_x_min -150\nchild_follow_range_recall_x_max 170\nchild_follow_recall_offset_x 6\nchild_follow_recall_offset_z 3\nchild_follow_recall_animation spawn\nchild_follow_direction_adjust_config toward\nanim idle\nframe none\nanim walk\nframe none\nanim spawn\nframe none\n";
     std::ofstream(v26Root/"data/levels/l.txt") << "spawn SmartPet\ncoords 100 200 0\nat 0\n";}
    auto v26Scan=ProjectScanner::scan(v26Root);auto v26Chars=CharacterParser::parseAll(v26Scan.dataDir,v26Scan.root);const CharacterDef*dyn=nullptr,*noBasic=nullptr,*smartPet=nullptr;for(const auto&c:v26Chars){if(c.modelName=="DynamicHero")dyn=&c;else if(c.modelName=="NoBasicWeapon")noBasic=&c;else if(c.modelName=="SmartPet")smartPet=&c;}
    CHECK(dyn&&noBasic&&smartPet,"v0.26 dynamic command/combo fixture models parsed");
    if(dyn){CHECK(dyn->comboStyle==1&&dyn->attackChain.size()==10&&dyn->attackChain[3]==0,"combostyle=1 preserves zero-separated atchain branches");CHECK(dyn->commands.size()==1&&dyn->commands[0].sequence.find("f[3][8]")!=std::string::npos&&dyn->commands[0].sequence.find(":[10]")!=std::string::npos,"timed hold/chord/sequence command syntax preserved");bool range2=false,range3=false;for(const auto&a:dyn->animations){if(a.name=="attack2")range2=a.hasRangeX&&a.hasRangeZ&&std::abs(a.rangeXMax-28.0f)<0.01f;if(a.name=="attack3")range3=a.hasRangeX&&std::abs(a.rangeXMin-29.0f)<0.01f;}CHECK(range2&&range3,"range/rangez metadata parsed for dynamic combo branches");}
    if(noBasic)CHECK((noBasic->modelCopyFlags&1)!=0&&(noBasic->modelCopyFlags&4)!=0,"modelflag no_basic/no_script parsed");
    if(smartPet)CHECK(std::abs(smartPet->childFollowRangeXMin+30.0f)<0.01f&&std::abs(smartPet->childRecallRangeXMax-170.0f)<0.01f&&smartPet->childRecallAnimation=="spawn"&&smartPet->childDirectionAdjust==6,"per-axis child follow/recall/direction metadata parsed");
    CHECK(CommandRegistry::lookup("range").runtime&&CommandRegistry::lookup("modelflag").runtime,"v0.26 dynamic range/model-copy registry paths active");
    fs::path v26Out="/tmp/obor-v026-command-combo-port";fs::remove_all(v26Out);auto v26Comp=CompatibilityAnalyzer::analyze(v26Scan);PortGenerator::generate(v26Scan,v26Comp,v26Out);
    {std::ifstream in(v26Out/"runtime/src/Engine.cpp");std::string body((std::istreambuf_iterator<char>(in)),{});CHECK(body.find("ParsedCommandStep")!=std::string::npos&&body.find("holdTrigger")!=std::string::npos&&body.find("sequenceGrace")!=std::string::npos,"generated runtime contains timed OpenBOR command matcher");CHECK(body.find("dynamicChainAttackNumber")!=std::string::npos&&body.find("attackRangePass")!=std::string::npos,"generated runtime contains combostyle=1 range branch selection");CHECK(body.find("tryEntityPickupWeapon")!=std::string::npos,"generated runtime contains AI weapon seek/pickup path");CHECK(body.find("childRecallOffsetX")!=std::string::npos&&body.find("childDirectionAdjust")!=std::string::npos,"generated runtime contains advanced child follow/recall behavior");}

    auto mystery = CommandRegistry::lookup("customwave");
    CHECK(mystery.status==CommandStatus::Unknown, "customwave is UNKNOWN");

    auto scanB = ProjectScanner::scan(fixtureB);
    auto compB = CompatibilityAnalyzer::analyze(scanB);
    CHECK(compB.logicalWidth==480 && compB.logicalHeight==272, "fixture B resolution is not hardcoded 320x240");
    auto stagesB = LevelParser::parseAll(scanB.dataDir, scanB.root);
    CHECK(stagesB.size()==1, "fixture B one stage");
    CHECK(compB.unknownCommands>=1, "fixture B unknown customwave recorded");
    if(!stagesB.empty() && stagesB[0].spawns.size()>=2){
        CHECK(stagesB[0].spawns[0].at==50, "earlier `at` wins regardless of declaration order");
        CHECK(stagesB[0].spawns[0].alias=="SecondButEarlier", "alias preserved");
    }
    // Tab-indented model still parses.
    CHECK(compB.models==1, "tab-indented model parsed");

    fs::path outA = "/tmp/obor-port-a";
    fs::path outB = "/tmp/obor-port-b";
    fs::remove_all(outA); fs::remove_all(outB);
    PortGenerator::generate(scanA, compA, outA);
    PortGenerator::generate(scanB, compB, outB);
    CHECK(fs::exists(outA/"runtime"/"generated"/"GeneratedStages.cpp"), "port A stages generated");
    CHECK(fs::exists(outA/"runtime"/"src"/"Engine.cpp"), "port A engine generated");
    {
        std::ifstream in(outA/"runtime"/"generated"/"GeneratedStages.cpp");
        std::string body((std::istreambuf_iterator<char>(in)), {});
        CHECK(body.find("const Stage kStages[]")!=std::string::npos, "generated stage table present");
        CHECK(body.find("Boss")!=std::string::npos, "boss model name comes from data");
        // spawn order in generated table follows sorted at
        auto p50 = body.find("EarlyThug");
        auto pBoss = body.find("\"Boss\"");
        auto pLate = body.find("at=900");
        CHECK(pBoss!=std::string::npos, "boss spawn emitted");
        (void)p50; (void)pLate;
    }
    {
        std::ifstream in(outA/"runtime"/"generated"/"GeneratedCharacters.cpp");
        std::string body((std::istreambuf_iterator<char>(in)), {});
        CHECK(body.find("\"Boss\", \"BossGeneric\"")!=std::string::npos, "generated character keeps models.txt alias and internal name");
    }
    {
        std::ifstream in(outA/"runtime"/"generated"/"GeneratedCharacters.hpp");
        std::string body((std::istreambuf_iterator<char>(in)), {});
        CHECK(body.find("struct PaletteRemap")!=std::string::npos && body.find("alternatePalettes")!=std::string::npos, "generated character schema carries palette/remap metadata");
    }
    {
        std::ifstream in(outA/"runtime"/"src"/"Engine.cpp");
        std::string body((std::istreambuf_iterator<char>(in)), {});
        CHECK(body.find("cameraMaxX_")!=std::string::npos, "camera no longer rewinds (cameraMaxX_)");
        CHECK(body.find("spawnState_")!=std::string::npos, "spawn state machine emitted");
        CHECK(body.find("while(nextSpawn_") == std::string::npos, "old rewind-prone spawn cursor removed");
        CHECK(body.find("c.modelName")!=std::string::npos, "runtime resolves external model aliases");
        CHECK(body.find("groupMin_")!=std::string::npos && body.find("groupMax_")!=std::string::npos, "runtime emits group min/max wave control");
        CHECK(body.find("backtrackFloor_")!=std::string::npos, "runtime emits blockade backtrack floor");
        CHECK(body.find("player-animation-frame")!=std::string::npos, "animationscript is frame-entry driven");
        CHECK(body.find("loadsample")!=std::string::npos && body.find("playsample")!=std::string::npos, "script audio APIs emitted");
        CHECK(body.find("backgroundLayers_")!=std::string::npos && body.find("foregroundLayers_")!=std::string::npos, "runtime emits parallax background/foreground layer rendering");
        CHECK(body.find("levelscript")!=std::string::npos, "runtime executes per-level levelscript");
        CHECK(body.find("jumptobranch")!=std::string::npos && body.find("pendingBranchTarget_")!=std::string::npos, "runtime implements ScriptVM campaign branch jumps");
        CHECK(body.find("current_branch")!=std::string::npos, "runtime exposes current_branch to scripts");
        CHECK(body.find("previousCamera")!=std::string::npos && body.find("scrollSpeed")!=std::string::npos, "runtime applies stage scrollspeed to camera movement");
        CHECK(body.find("applyCharacterPalette")!=std::string::npos && body.find("loadPaletteColors")!=std::string::npos, "runtime emits image/ACT palette remapping");
        CHECK(body.find("reactionAnimation")!=std::string::npos, "runtime emits attack-type-specific pain/fall/rise reactions");
        CHECK(body.find("entityFromHandle")!=std::string::npos, "runtime validates script entity handles against stable runtime entities");
        CHECK(body.find("setentityvar")!=std::string::npos && body.find("findtarget")!=std::string::npos && body.find("setspawnentry")!=std::string::npos, "runtime emits expanded entity/target/spawn ScriptVM APIs");
        CHECK(body.find("modelIsHostileTo")!=std::string::npos && body.find("entity-didhit-entity")!=std::string::npos, "v0.33 runtime separates hostile targeting from candamage and supports entity-vs-entity combat");
        CHECK(body.find("k==\"position\"")!=std::string::npos, "v0.33 ScriptVM changeentityproperty position supports common spawn helper scripts");
        CHECK(body.find("global-key-all")!=std::string::npos && body.find("global-key-player")!=std::string::npos, "runtime fires global keyN.c and keyall.c scripts");
        CHECK(body.find("spawnscript")!=std::string::npos && body.find("spawnx")!=std::string::npos && body.find("spawnat")!=std::string::npos, "runtime fires spawnscript with spawn locals");
        CHECK(body.find("damagetaker")!=std::string::npos && body.find("attacker")!=std::string::npos && body.find("attacktype")!=std::string::npos, "runtime supplies combat event locals to didhit/takedamage hooks");
        CHECK(body.find("playerkeys")!=std::string::npos && body.find("updateframe")!=std::string::npos && body.find("setidle")!=std::string::npos, "runtime emits key-state, updateframe and setidle APIs");
        CHECK(body.find("tryBlockEntity")!=std::string::npos && body.find("tryBlockPlayer")!=std::string::npos, "generated runtime includes native block resolution");CHECK(body.find("blockPower<=penetration")!=std::string::npos, "v0.27.1 defense blockpower is compared against attack penetration");CHECK(body.find("threshold=m->blockThreshold+(d?d->blockThreshold:0)")!=std::string::npos, "v0.27.1 per-type blockthreshold combines with model thold");CHECK(body.find("defenseAllowsPain")!=std::string::npos && body.find("defenseAllowsKnockdown")!=std::string::npos, "v0.27.1 per-type pain and knockdown defense semantics emitted");CHECK(body.find("blockedChipDamage")!=std::string::npos && body.find("applyBlockedChip")!=std::string::npos, "v0.28 blockratio/blocktype chip damage emitted");CHECK(body.find("globalBlockRatio")!=std::string::npos && body.find("globalMpBlock")!=std::string::npos && body.find("noChipDeath")!=std::string::npos, "v0.29 global blockratio/mpblock/nochipdeath emitted");CHECK(body.find("blockRatioDefined")!=std::string::npos && body.find("blockTypeDefined")!=std::string::npos, "v0.29 per-defense chip settings preserve global fallback distinction");CHECK(body.find("resolveKnockdown")!=std::string::npos && body.find("knockdownCount")!=std::string::npos, "v0.28 knockdowncount/defense knockdown scaling emitted");CHECK(body.find("loop_offset_bytes")!=std::string::npos, "v0.28 bossmusic byte loop offset emitted");CHECK(body.find("stage_->rockMode")!=std::string::npos && body.find("phase=(double)tickCounter_*speed/60.0")!=std::string::npos, "v0.28 water warp speed/rock runtime emitted");CHECK(body.find("rockDx")!=std::string::npos && body.find("rockDy")!=std::string::npos, "v0.29 rock modes move stage while HUD stays outside offset path");
        CHECK(body.find("drawbox")!=std::string::npos && body.find("loadsprite")!=std::string::npos, "generated runtime includes direct-drawing APIs");
        CHECK(body.find("getmodelproperty")!=std::string::npos && body.find("getlevelproperty")!=std::string::npos, "generated runtime includes model/level property APIs");
    }
    {
        std::ifstream in(outA/"runtime"/"src"/"main.cpp");
        std::string body((std::istreambuf_iterator<char>(in)), {});
        CHECK(body.find("findPortRoot")!=std::string::npos && body.find("assets\"/\"openbor-data")!=std::string::npos, "v0.29 generated runtime auto-discovers port root from build subdirectories");
    }
    {
        std::ifstream in(outA/"runtime"/"include"/"Engine.hpp");
        std::string body((std::istreambuf_iterator<char>(in)), {});
        CHECK(body.find("std::deque<RuntimeEntity>")!=std::string::npos, "runtime uses stable entity storage for script self/entity handles");
    }
    {
        std::ifstream in(outA/"runtime"/"src"/"ScriptVM.cpp");
        std::string body((std::istreambuf_iterator<char>(in)), {});
        CHECK(body.find("switchStatement")!=std::string::npos, "ScriptVM emits switch support");
        CHECK(body.find("preprocessScript")!=std::string::npos, "ScriptVM emits preprocessor include/define support");
        CHECK(body.find("FunctionMacro")!=std::string::npos && body.find("expandFunctionMacros")!=std::string::npos, "ScriptVM emits function-like macro expansion");
        CHECK(body.find("expected while after do")!=std::string::npos, "ScriptVM emits do/while support");
    }
    {
        std::ifstream in(outA/"runtime"/"include"/"AudioSystem.hpp");
        std::string body((std::istreambuf_iterator<char>(in)), {});
        CHECK(body.find("effectVoices_")!=std::string::npos, "audio runtime supports overlapping active effects");
        CHECK(body.find("pauseMusic")!=std::string::npos, "audio runtime exposes music pause API");
    }
    {
        std::ifstream in(outA/"runtime"/"src"/"AudioDecoder.cpp");
        std::string body((std::istreambuf_iterator<char>(in)), {});
        CHECK(body.find("tag==3")!=std::string::npos, "WAV decoder includes IEEE float32 path");
        CHECK(body.find("bits==24")!=std::string::npos && body.find("bits==32")!=std::string::npos, "WAV decoder includes 24/32-bit PCM paths");
        CHECK(body.find("decodeMediaFoundation")!=std::string::npos && body.find("MFCreateSourceReaderFromURL")!=std::string::npos, "Windows runtime emits Media Foundation compressed-audio decoder");
    }
    {
        std::ifstream in(outB/"config"/"port.ini");
        std::string body((std::istreambuf_iterator<char>(in)), {});
        CHECK(body.find("logical_width=480")!=std::string::npos, "port B records 480 width");
        CHECK(body.find("logical_height=272")!=std::string::npos, "port B records 272 height");
    }
    {
        std::ifstream in(outB/"config"/"openbor-video.ini");
        std::string body((std::istreambuf_iterator<char>(in)), {});
        CHECK(body.find("logical_width=480")!=std::string::npos && body.find("logical_height=272")!=std::string::npos, "PortGenerator always writes detected video resolution");
    }
    {
        std::ifstream in(outA/"runtime"/"src"/"main.cpp");
        std::string body((std::istreambuf_iterator<char>(in)), {});
        CHECK(body.find("executableDir")!=std::string::npos, "generated runtime roots itself at executable directory");
        CHECK(body.find("argv[i][0]!=\'-\'")!=std::string::npos, "generated runtime does not mistake CLI flags such as --headless for the port root");
    }
    CompatibilityAnalyzer::writeReport(scanA, compA, outA/"reports");
    CHECK(fs::exists(outA/"reports"/"analysis.json"), "analysis.json");
    CHECK(fs::exists(outA/"reports"/"compatibility-report.txt"), "compatibility-report.txt");

    // Real traversal guard exercises the same helper used by parsers/generator input handling.
    CHECK(SafePath::resolveWithin(scanA.dataDir,"DATA/CHARS/HERO/HERO.TXT")==fs::weakly_canonical(scanA.dataDir/"chars/hero/hero.txt"),"mixed case model references resolve inside data");
    CHECK(SafePath::resolveWithin(scanA.dataDir, "../secret.txt").empty(), "path traversal outside data/ is rejected");
    CHECK(SafePath::resolveWithin(scanA.dataDir, "data/chars/hero/hero.txt") == fs::weakly_canonical(scanA.dataDir/"chars/hero/hero.txt"), "valid OpenBOR data path resolves inside data/");

    // A generated port is a valid input for the test/scan path.
    auto generatedScan = ProjectScanner::scan(outA);
    CHECK(generatedScan.hasDataDir && generatedScan.dataDir.filename()=="openbor-data", "generated port layout assets/openbor-data is recognized");
    auto generatedComp = CompatibilityAnalyzer::analyze(generatedScan);
    bool generatedFalseScriptWarning=false;
    for(const auto& issue:generatedComp.issues) if(issue.command=="script-file") generatedFalseScriptWarning=true;
    CHECK(!generatedFalseScriptWarning, "generated port include/import analysis has no false script warning");

    // v0.20 universal input: bare OpenBOR PAK and ZIP package are resolved without
    // requiring the user to unpack/rearrange the game first.
    fs::path pakPath="/tmp/obor-v020-test.pak";fs::remove(pakPath);CHECK(createTestPak(pakPath), "synthetic OpenBOR PAK fixture created");
    try{ auto pakInput=InputResolver::resolve(pakPath);auto pakScan=ProjectScanner::scan(pakInput.gameRoot);CHECK(pakInput.sourceKind=="pak", "bare .pak input recognized");CHECK(pakScan.hasModels&&pakScan.hasLevels, "bare .pak extracted into analyzable OpenBOR data/"); }catch(const std::exception&e){std::cerr<<"FAIL: PAK resolver exception: "<<e.what()<<"\n";++gFails;}

    fs::path zipSrc="/tmp/obor-v020-zip-src",zipPath="/tmp/obor-v020-game.zip";fs::remove_all(zipSrc);fs::remove(zipPath);fs::create_directories(zipSrc/"Bundle/MyGame");fs::copy(fixtureA,zipSrc/"Bundle/MyGame",fs::copy_options::recursive|fs::copy_options::overwrite_existing);
    {auto old=fs::current_path();fs::current_path(zipSrc);int rc=std::system((std::string("cmake -E tar cf ")+zipPath.string()+" --format=zip Bundle").c_str());fs::current_path(old);CHECK(rc==0&&fs::exists(zipPath), "ZIP fixture created");}
    try{ auto zipInput=InputResolver::resolve(zipPath);auto zipScan=ProjectScanner::scan(zipInput.gameRoot);CHECK(zipInput.sourceKind=="zip", "ZIP input recognized");CHECK(zipScan.hasModels&&zipScan.hasLevels, "nested ZIP game root auto-detected"); }catch(const std::exception&e){std::cerr<<"FAIL: ZIP resolver exception: "<<e.what()<<"\n";++gFails;}

    fs::path openborZipSrc="/tmp/obor-v020-openbor-zip-src",openborZip="/tmp/obor-v020-openbor-package.zip";fs::remove_all(openborZipSrc);fs::remove(openborZip);fs::create_directories(openborZipSrc/"OpenBOR/Paks");fs::copy_file(pakPath,openborZipSrc/"OpenBOR/Paks/TestGame.pak");
    {auto old=fs::current_path();fs::current_path(openborZipSrc);int rc=std::system((std::string("cmake -E tar cf ")+openborZip.string()+" --format=zip OpenBOR").c_str());fs::current_path(old);CHECK(rc==0&&fs::exists(openborZip), "OpenBOR engine-style ZIP with Paks/*.pak fixture created");}
    try{ auto packageInput=InputResolver::resolve(openborZip);auto packageScan=ProjectScanner::scan(packageInput.gameRoot);CHECK(packageInput.sourceKind=="openbor-package-zip", "OpenBOR ZIP containing Paks/*.pak recognized");CHECK(packageScan.hasModels&&packageScan.hasLevels, "PAK inside OpenBOR ZIP auto-extracted and analyzed"); }catch(const std::exception&e){std::cerr<<"FAIL: OpenBOR package ZIP resolver exception: "<<e.what()<<"\n";++gFails;}


    // v0.30 legacy unknown-command parity: these commands were present in the
    // Ghosts'n Goblins Dragon Ball compatibility report and must no longer fall
    // through as UNKNOWN. Runtime-backed commands stay honest about partial edges.
    {
        const char* cmds[]={"seta","antigravity","nopain","nodrop","nodieblink","noquake","subject_to_hole",
                            "offscreenkill","falldie","death","risetime","riseattacktype","fmap","remove","throw",
                            "no_adjust_base","quakeframe","hitfx","hitflash","icondie","order","2pitem","lives",
                            "credits","colourdepth"};
        for(const char* c:cmds) CHECK(CommandRegistry::lookup(c).status!=CommandStatus::Unknown, std::string("v0.30 registry recognizes ")+c);
    }
    fs::path legacyRoot="/tmp/obor-v030-legacy-fixture";fs::remove_all(legacyRoot);fs::create_directories(legacyRoot/"data/chars");fs::create_directories(legacyRoot/"data/levels");
    {
        std::ofstream(legacyRoot/"data/models.txt") << "load Legacy data/chars/legacy.txt\n";
        std::ofstream(legacyRoot/"data/levels.txt") << "set Legacy\nlives 5\ncredits 3\nfile data/levels/legacy.txt\n";
        std::ofstream(legacyRoot/"data/levels/legacy.txt") << "panel data/bgs/bg.gif\norder aaaaaaa\nbackground data/bgs/bg.gif\n";
        std::ofstream f(legacyRoot/"data/chars/legacy.txt");
        f << "name Legacy\n"
          << "type enemy\n"
          << "antigravity 100\n"
          << "nopain 1\n"
          << "nodrop 1\n"
          << "nodieblink 1\n"
          << "noquake 1\n"
          << "subject_to_hole 0\n"
          << "no_adjust_base 1\n"
          << "offscreenkill 120\n"
          << "falldie 2\n"
          << "risetime 20 -50\n"
          << "riseattacktype 1\n"
          << "fmap 2\n"
          << "remove 1\n"
          << "throw 1\n"
          << "icon data/sprites/icon.gif\n"
          << "icondie data/sprites/dead.gif\n"
          << "anim attack1\n"
          << "seta 24\n"
          << "quakeframe 0 2 3\n"
          << "hitfx data/sounds/hit.wav\n"
          << "hitflash Flash\n"
          << "attack 0 0 16 16 5\n"
          << "frame none\n";
    }
    auto legacyChars=CharacterParser::parseAll(legacyRoot/"data",legacyRoot);
    CHECK(legacyChars.size()==1,"v0.30 legacy fixture model parsed");
    if(!legacyChars.empty()){
        const auto& c=legacyChars[0];
        CHECK(std::abs(c.antigravity-1.0f)<0.001f && c.noPain && c.noDrop && c.noQuake,"v0.30 antigravity/nopain/nodrop/noquake parsed");
        CHECK(!c.subjectToHole && c.offscreenKill==120 && c.fallDie==2 && c.riseTime==20 && c.riseAttackType==1,"v0.30 hole/offscreen/death/rise metadata parsed");
        CHECK(c.iconDiePath=="sprites/dead.gif","v0.30 icondie parsed");
        CHECK(!c.animations.empty() && !c.animations[0].frames.empty() && c.animations[0].frames[0].hasSetA && std::abs(c.animations[0].frames[0].setA-24.0f)<0.001f,"v0.30 seta persists into committed frame");
        CHECK(c.animations[0].quakeFrame==0 && c.animations[0].quakeLoops==2 && c.animations[0].quakeIntensity==3,"v0.30 quakeframe parsed");
        CHECK(c.animations[0].hitFx=="sounds/hit.wav" && c.animations[0].hitFlash=="Flash","v0.30 hitfx/hitflash parsed");
    }
    auto legacySets=LevelParser::parseLevelSets(legacyRoot/"data/levels.txt");
    CHECK(!legacySets.empty() && legacySets[0].lives==5 && legacySets[0].credits==3,"v0.30 levels.txt lives/credits parsed");
    auto legacyStage=LevelParser::parseStage(legacyRoot/"data/levels/legacy.txt",legacyRoot,legacySets[0]);
    CHECK(legacyStage.panels.size()==7 && legacyStage.panelOrder=="aaaaaaa","v0.34.0 legacy order is a panel sequence rather than a stage number");
    fs::path legacyOut="/tmp/obor-v030-legacy-port";fs::remove_all(legacyOut);auto legacyScan=ProjectScanner::scan(legacyRoot);auto legacyComp=CompatibilityAnalyzer::analyze(legacyScan);PortGenerator::generate(legacyScan,legacyComp,legacyOut);
    {
        std::ifstream in(legacyOut/"runtime/src/Engine.cpp");std::string body((std::istreambuf_iterator<char>(in)),{});
        CHECK(body.find("triggerQuake")!=std::string::npos && body.find("playHitFx")!=std::string::npos,"v0.30 generated runtime includes quakeframe/hitfx execution");
        CHECK(body.find("antigravity")!=std::string::npos && body.find("subjectToHole")!=std::string::npos && body.find("offscreenKill")!=std::string::npos,"v0.30 generated runtime includes physics/hole/offscreen parity");
        CHECK(body.find("hudDeadIconCache_")!=std::string::npos && body.find("iconDiePath")!=std::string::npos,"v0.30 generated runtime includes icondie HUD path");
    }


    // v0.31 registry/HUD/cutscene parity. `know` is a real model-registry entry,
    // not merely a scanner hint, and completed presentation commands must be
    // reported as SUPPORTED while lifebarstatus keeps its remaining layer caveat.
    {
        const char* supported31[]={"know","animation","shadow","icon","icondie","nolife","lifeposition","nameposition","iconposition","subject_to_hole"};
        for(const char* c:supported31) CHECK(CommandRegistry::lookup(c).status==CommandStatus::Supported,std::string("v0.31 registry supports ")+c);
        CHECK(CommandRegistry::lookup("lifebarstatus").status==CommandStatus::Partial,"v0.31 lifebarstatus remains honest PARTIAL for legacy component Z layers");
    }
    fs::path v31Root="/tmp/obor-v031-registry-hud";fs::remove_all(v31Root);fs::create_directories(v31Root/"data/chars");fs::create_directories(v31Root/"data/levels");
    {
        std::ofstream(v31Root/"data/models.txt") << "load Hero data/chars/hero.txt\nknow LazyEnemy data/chars/lazy.txt\n";
        std::ofstream(v31Root/"data/levels.txt") << "set Test\nfile data/levels/stage.txt\n";
        std::ofstream(v31Root/"data/levels/stage.txt") << "spawn LazyEnemy\ncoords 80 200 0\nat 0\n";
        std::ofstream(v31Root/"data/chars/hero.txt") << "name Hero\ntype player\nanim idle\nframe none\n";
        std::ofstream f(v31Root/"data/chars/lazy.txt");
        f << "name LazyInternal\n"
          << "type enemy\n"
          << "shadow 4\n"
          << "icon data/sprites/lazy.gif 1\n"
          << "icondie data/sprites/lazy-dead.gif\n"
          << "nolife 1\n"
          << "lifebarstatus 280 7 1 1 1 -300 -299 -298 -297\n"
          << "lifeposition 18 218\n"
          << "nameposition 18 227\n"
          << "iconposition 0 218\n"
          << "anim idle\nframe none\n";
    }
    auto v31Chars=CharacterParser::parseAll(v31Root/"data",v31Root);
    CHECK(v31Chars.size()==2,"v0.31 load + know models both enter native registry");
    const CharacterDef* lazy31=nullptr;for(const auto&c:v31Chars)if(c.modelName=="LazyEnemy")lazy31=&c;
    CHECK(lazy31!=nullptr,"v0.31 know preserves external registry alias");
    if(lazy31){
        CHECK(lazy31->name=="LazyInternal" && lazy31->shadow==4,"v0.31 know model definition parsed normally");
        CHECK(lazy31->iconUsesPalette && lazy31->iconDiePath=="sprites/lazy-dead.gif" && lazy31->noLife,"v0.31 icon palette/death/nolife metadata parsed");
        CHECK(lazy31->lifeBarStatusDefined && lazy31->lifeBarWidth==280 && lazy31->lifeBarHeight==7 && lazy31->lifeBarNoBorder==1,"v0.31 lifebarstatus size/border parsed");
        CHECK(lazy31->lifeBarType==1 && lazy31->lifeBarOrientation==1 && lazy31->lifeBarBorderLayer==-300 && lazy31->lifeBarBackfillLayer==-297,"v0.31 lifebarstatus mode/orientation/layers preserved");
        CHECK(lazy31->lifePositionX==18 && lazy31->lifePositionY==218 && lazy31->namePositionY==227 && lazy31->iconPositionY==218,"v0.31 popup HUD positions parsed");
    }
    fs::path v31Out="/tmp/obor-v031-port";fs::remove_all(v31Out);auto v31Scan=ProjectScanner::scan(v31Root);auto v31Comp=CompatibilityAnalyzer::analyze(v31Scan);PortGenerator::generate(v31Scan,v31Comp,v31Out);
    {
        std::ifstream in(v31Out/"runtime/generated/GeneratedCharacters.cpp");std::string body((std::istreambuf_iterator<char>(in)),{});
        CHECK(body.find("LazyEnemy")!=std::string::npos,"v0.31 generated character table contains know-only model");
    }
    {
        std::ifstream in(v31Out/"runtime/src/Engine.cpp");std::string body((std::istreambuf_iterator<char>(in)),{});
        CHECK(body.find("iconUsesPalette")!=std::string::npos && body.find("lifeBarOrientation")!=std::string::npos,"v0.31 generated runtime includes HUD palette/orientation behavior");
    }

    // OpenBOR v7533 stores damageonlanding on the active attack box. It must
    // survive frame inheritance and reach the generated C++ attack table.
    fs::path landRoot="/tmp/obor-v0334-landing";fs::remove_all(landRoot);fs::create_directories(landRoot/"data/chars");
    {std::ofstream(landRoot/"data/models.txt") << "load LandingHero data/chars/hero.txt\n";
     std::ofstream(landRoot/"data/chars/hero.txt") << "name LandingHero\ntype player\nanim attack1\nattack 0 0 16 16 4 1\ndamageonlanding 7 0 attack2\nframe none\ndamageonlanding 8 0\nframe none\n";}
    auto landChars=CharacterParser::parseAll(landRoot/"data",landRoot);
    CHECK(landChars.size()==1 && !landChars[0].animations.empty() && !landChars[0].animations[0].frames.empty() && landChars[0].animations[0].frames[0].attack.landingDamage==7,"v0.33.4 landing damage preserved on the attack frame");
    if(landChars.size()==1 && !landChars[0].animations.empty() && landChars[0].animations[0].frames.size()==2)
        CHECK(landChars[0].animations[0].frames[0].attack.landingType==2 && landChars[0].animations[0].frames[1].attack.landingType==-1,"v0.33.5 named attack type and default landing type parsed");
    CHECK(CommandRegistry::lookup("damageonlanding").status==CommandStatus::Partial,"v0.33.4 reports limited landing-damage parity");
    auto landScan=ProjectScanner::scan(landRoot);auto landComp=CompatibilityAnalyzer::analyze(landScan);fs::path landOut="/tmp/obor-v0334-landing-port";fs::remove_all(landOut);PortGenerator::generate(landScan,landComp,landOut);
    {std::ifstream in(landOut/"runtime/generated/GeneratedCharacters.cpp");std::string body((std::istreambuf_iterator<char>(in)),{});CHECK(body.find(",7,2}, true")!=std::string::npos && body.find(",8,-1}, true")!=std::string::npos,"v0.33.5 generated attack table carries both landing types");}

    fs::path shockRoot="/tmp/obor-v0336-shock";fs::remove_all(shockRoot);fs::create_directories(shockRoot/"data/chars");
    {std::ofstream(shockRoot/"data/models.txt") << "load ShockEnemy data/chars/shock.txt\n";
     std::ofstream(shockRoot/"data/chars/shock.txt") << "name ShockEnemy\ntype enemy\nantigrab 5\nsubject_to_wall 0\nnomove 1 0\nnomove 0 1\nanim attack1\nshock 0 0 16 16 8 0\nframe none\nshock 0 0 16 16 8 1\nframe none\nattack2 0 0 16 16 8 0\nframe none\n";}
    auto shockChars=CharacterParser::parseAll(shockRoot/"data",shockRoot);
    CHECK(shockChars.size()==1 && shockChars[0].grabResistance==5,"v0.33.6 antigrab maps to native grab resistance");
    CHECK(shockChars.size()==1 && !shockChars[0].subjectToWall && CharacterDef{}.subjectToWall,"v0.33.7 wall collision flag respects explicit zero and defaults to enabled");
    CHECK(shockChars.size()==1 && shockChars[0].noMove && shockChars[0].noFlip && !CharacterDef{}.noMove && !CharacterDef{}.noFlip,"v0.33.8 nomove parameters independently set additive movement and facing constraints");
    if(shockChars.size()==1 && !shockChars[0].animations.empty() && shockChars[0].animations[0].frames.size()==3){const auto&frames=shockChars[0].animations[0].frames;
        CHECK(frames[0].attack.type==1004 && !frames[0].knockdown && frames[1].attack.type==1004 && frames[1].knockdown && frames[2].attack.type==2 && !frames[2].knockdown,"v0.33.6 shock and attack2 drop flag are independent of attack type");}
    CHECK(CommandRegistry::lookup("shock").status==CommandStatus::Partial && CommandRegistry::lookup("antigrab").status==CommandStatus::Partial,"v0.33.6 legacy combat directives are classified with their runtime limits");
    auto shockScan=ProjectScanner::scan(shockRoot);auto shockComp=CompatibilityAnalyzer::analyze(shockScan);fs::path shockOut="/tmp/obor-v0336-shock-port";fs::remove_all(shockOut);PortGenerator::generate(shockScan,shockComp,shockOut);
    {std::ifstream in(shockOut/"runtime/src/Engine.cpp");std::string body((std::istreambuf_iterator<char>(in)),{});CHECK(body.find("exactAnimation(c,\"spain\")")!=std::string::npos && body.find("attack.type>=2")==std::string::npos,"v0.33.6 generated runtime uses shock pain and explicit knockdown flag");}
    {std::ifstream in(shockOut/"runtime/src/Engine.cpp");std::string body((std::istreambuf_iterator<char>(in)),{});CHECK(body.find("playerModel_->subjectToWall")!=std::string::npos && body.find("cp.model->subjectToWall")!=std::string::npos && body.find("e.model->subjectToWall")!=std::string::npos,"v0.33.7 generated runtime gates wall collision for every actor kind");}
    CHECK(CommandRegistry::lookup("subject_to_wall").status==CommandStatus::Partial,"v0.33.7 wall collision is reported with its geometry limits");
    CHECK(CommandRegistry::lookup("nomove").status==CommandStatus::Partial,"v0.33.8 nomove is reported with advanced movement limits");
    {std::ifstream in(shockOut/"runtime/generated/GeneratedCharacters.cpp");std::string body((std::istreambuf_iterator<char>(in)),{});CHECK(body.find("false, true, true, false,")!=std::string::npos,"v0.33.8 generated model retains independent nomove flags");}
    {std::ifstream in(shockOut/"runtime/src/Engine.cpp");std::string body((std::istreambuf_iterator<char>(in)),{});CHECK(body.find("playerModel_->noMove")!=std::string::npos && body.find("cp.model->noMove")!=std::string::npos && body.find("e.model->noMove")!=std::string::npos && body.find("m->noMove")!=std::string::npos && body.find("e.model->noFlip")!=std::string::npos,"v0.33.8 generated runtime uses nomove for player, coop, AI and fall reaction");}

    const auto blocksRoot=fs::path(OBNB_SOURCE_DIR)/"tests/fixtures/runtime_blocks";
    auto blocksChars=CharacterParser::parseAll(blocksRoot/"data",blocksRoot);
    CHECK(blocksChars.size()==3 && blocksChars[0].animations.size()==2 && blocksChars[0].animations[1].inlineScript.find("frame==2")!=std::string::npos,"v0.34.0 preserves model and animation inline bodies");
    CHECK(blocksChars.size()==3 && blocksChars[1].animations[1].landDustModel=="Dust","v0.34.0 landframe preserves named landing effect");
    auto blocksStages=LevelParser::parseAll(blocksRoot/"data",blocksRoot);
    CHECK(blocksStages.size()==1 && blocksStages[0].panels.size()==6 && blocksStages[0].panels[3]=="bgs/b.gif","v0.34.0 letter panel order expands and concatenates");
    CHECK(CommandRegistry::lookup("order").status==CommandStatus::Supported && CommandRegistry::lookup("landframe").status==CommandStatus::Supported && CommandRegistry::lookup("@end_script").status==CommandStatus::Supported,"v0.34.0 closed command gaps leave PARTIAL");
    auto blocksScan=ProjectScanner::scan(blocksRoot);auto blocksComp=CompatibilityAnalyzer::analyze(blocksScan);fs::path blocksOut="/tmp/obor-v0340-runtime-port";fs::remove_all(blocksOut);PortGenerator::generate(blocksScan,blocksComp,blocksOut);

    fs::path invalidRoot="/tmp/obor-v0340-invalid";fs::remove_all(invalidRoot);fs::copy(blocksRoot,invalidRoot,fs::copy_options::recursive);
    {std::ofstream(invalidRoot/"data/levels/test.txt",std::ios::app)<<"\norder z\n";std::ofstream(invalidRoot/"data/chars/hero.txt",std::ios::app)<<"\n@script\nbindentity(0, 0, 0, 0, 0, 0, 16);\n@end_script\n";}
    auto invalidScan=ProjectScanner::scan(invalidRoot);auto invalidComp=CompatibilityAnalyzer::analyze(invalidScan);bool invalidOrder=false,inlineApi=false;
    for(const auto&issue:invalidComp.issues){if(issue.command=="order"&&issue.status==CommandStatus::Partial)invalidOrder=true;if(issue.command=="inline-script-api"&&issue.message.find("bindentity")!=std::string::npos)inlineApi=true;}
    CHECK(invalidOrder,"v0.34.0 invalid panel order remains partial");
    CHECK(inlineApi,"v0.34.0 unmapped inline APIs receive explicit partial diagnostics");

    const auto effectsRoot=sourceDir/"tests/fixtures/runtime_effects";
    auto effectsChars=CharacterParser::parseAll(effectsRoot/"data",effectsRoot);
    CHECK(effectsChars.size()==5 && effectsChars[0].animations[1].frames[0].hitFlash=="HitA" && effectsChars[0].animations[1].frames[1].hitFlash=="HitB","v0.34.1 hit flash overrides are preserved per frame");
    CHECK(effectsChars[0].animations[1].frames[0].attack.type==18 && effectsChars[0].animations[1].frames[0].attack.tag==73 && effectsChars[0].animations[1].frames[0].attack.guardCost==4 && effectsChars[0].animations[1].frames[0].attack.penetration==1,"v0.34.1 numeric attack parsing does not swallow dotted attack properties");
    CHECK(effectsChars[0].animations[2].frames[0].hitFlash=="HitB" && effectsChars[0].animations[2].frames[0].blockFlash=="GuardFx" && effectsChars[0].animations[2].frames[0].attack.noFlash==1,"v0.34.1 modern flash aliases are applied");
    CHECK(effectsChars[1].flashModel=="HitA" && effectsChars[1].blockFlashModel=="GuardFx" && effectsChars[3].flipFlash,"v0.34.1 model flash defaults and facing parsed");
    CHECK(CommandRegistry::lookup("attack18").status==CommandStatus::Supported && CommandRegistry::lookup("attackone").status==CommandStatus::Partial && CommandRegistry::lookup("attackgarbage").status==CommandStatus::Unknown,"v0.34.1 typed attack boxes are distinct from other attack directives");
    auto effectsScan=ProjectScanner::scan(effectsRoot);auto effectsComp=CompatibilityAnalyzer::analyze(effectsScan);fs::path effectsOut="/tmp/obor-v0341-effects-port";fs::remove_all(effectsOut);PortGenerator::generate(effectsScan,effectsComp,effectsOut);

    auto energyRoot=sourceDir/"tests/fixtures/runtime_energy";auto energyChars=CharacterParser::parseAll(energyRoot/"data",energyRoot);
    CHECK(energyChars[0].animations[1].energyCost==5 && energyChars[0].animations[2].energyMode==1 && energyChars[0].animations[3].energyCost==7 && energyChars[0].animations[3].energyMode==2 && energyChars[0].animations[4].energyDisable==-1,"v0.34.2 energycost aliases, modes and disable parsed");
    auto energyScan=ProjectScanner::scan(energyRoot);auto energyComp=CompatibilityAnalyzer::analyze(energyScan);fs::path energyOut="/tmp/obor-v0342-energy-port";fs::remove_all(energyOut);PortGenerator::generate(energyScan,energyComp,energyOut);
    CHECK(CommandRegistry::lookup("energycost").runtime && CommandRegistry::lookup("nocost").status==CommandStatus::Partial,"v0.34.2 energy execution and deferred-cost limits reported");

    fs::path energyGlobal="/tmp/obor-v0342-global";fs::remove_all(energyGlobal);fs::copy(energyRoot,energyGlobal,fs::copy_options::recursive);std::ofstream(energyGlobal/"data/models.txt",std::ios::app)<<"nocost 1\n";fs::create_directories(energyGlobal/"data/scripts");std::ofstream(energyGlobal/"data/scripts/toss.c")<<"void main(){tossentity(getlocalvar(\"self\"),3,2,1);}";
    auto energyGlobalChars=CharacterParser::parseAll(energyGlobal/"data",energyGlobal);CHECK(energyGlobalChars[0].globalNoCost,"v0.34.2 global nocost is propagated to models");auto globalComp=CompatibilityAnalyzer::analyze(ProjectScanner::scan(energyGlobal));bool tossWarning=false;for(const auto&issue:globalComp.issues)if(issue.message.find("api/function:tossentity")!=std::string::npos)tossWarning=true;CHECK(!tossWarning,"v0.34.2 implemented toss API is no longer reported as unmapped");

    auto commandRoot=sourceDir/"tests/fixtures/runtime_commands";
    auto commandChars=CharacterParser::parseAll(commandRoot/"data",commandRoot);
    const auto& generatedCmd=commandChars[0].animations[0].frames[0].animationCommand;
    CHECK(generatedCmd.find("collect(\"power # one\",getlocalvar( \"self\" ));")!=std::string::npos,"v0.34.3 cmd preserves quoted spaces, # and nested expressions");
    auto commandScan=ProjectScanner::scan(commandRoot);auto commandComp=CompatibilityAnalyzer::analyze(commandScan);
    CHECK(!commandComp.animationCommands.empty()&&commandComp.animationCommands[0].function=="collect"&&commandComp.animationCommands[0].helper=="DATA/SCRIPTS/helper.C","v0.34.3 cmd diagnostics resolve case-insensitive helper and identify function");
    fs::path commandOut="/tmp/obor-v0343-command-port";fs::remove_all(commandOut);PortGenerator::generate(commandScan,commandComp,commandOut);
    CompatibilityAnalyzer::writeReport(commandScan,commandComp,commandOut/"reports");
    CHECK(fs::exists(commandOut/"reports/animation-command-audit.txt"),"v0.34.3 conversion emits per-call cmd audit");
    fs::path commandAuditRoot="/tmp/obor-v0343-audit";fs::remove_all(commandAuditRoot);fs::create_directories(commandAuditRoot/"data/chars");
    std::ofstream(commandAuditRoot/"data/models.txt")<<"load Hero data/chars/hero.txt\n";
    std::ofstream(commandAuditRoot/"data/chars/hero.txt")<<"name Hero\ntype player\nanim idle\n@cmd setglobalvar \"one\" 2\n@cmd unknown_helper 4\nframe data/chars/a.gif\n@cmd setglobalvar \"one\"\nframe data/chars/a.gif\n@cmd setglobalvar \"orphan\" 1\n";
    auto audited=CompatibilityAnalyzer::analyze(ProjectScanner::scan(commandAuditRoot));
    CHECK(audited.animationCommands.size()==4&&audited.animationCommands[0].status==CommandStatus::Supported&&audited.animationCommands[1].status==CommandStatus::Partial,"v0.34.3 verifies core cmd while retaining unresolved helper");
    CHECK(audited.animationCommands[2].status==CommandStatus::Partial&&audited.animationCommands[3].detail.find("no following")!=std::string::npos,"v0.34.3 malformed argument count and orphan cmd are not certified");
    CHECK(audited.commandStatus.at("@cmd")==CommandStatus::Partial&&audited.commandStatusCounts.at("@cmd").at(CommandStatus::Supported)==1,"v0.34.3 mixed cmd summary preserves unresolved calls and exact counts");
    std::ofstream(commandAuditRoot/"data/chars/hero.txt")<<"name Hero\ntype player\nanim idle\n@cmd setglobalvar \"bad\" NULL(1)\nframe none\n";
    auto badNested=CompatibilityAnalyzer::analyze(ProjectScanner::scan(commandAuditRoot));CHECK(badNested.animationCommands[0].status==CommandStatus::Partial,"v0.34.3 malformed nested cmd API arguments remain partial");

    fs::path bindingAuditRoot="/tmp/obor-v0346-binding-audit";fs::remove_all(bindingAuditRoot);fs::create_directories(bindingAuditRoot/"data/scripts");
    std::ofstream(bindingAuditRoot/"data/models.txt")<<"";
    auto bindingIssue=[&](const std::string& body){std::ofstream(bindingAuditRoot/"data/scripts/bind.c")<<body;auto report=CompatibilityAnalyzer::analyze(ProjectScanner::scan(bindingAuditRoot));return std::any_of(report.issues.begin(),report.issues.end(),[](const auto&i){return i.command=="script-file";});};
    CHECK(!bindingIssue("void main(){bindentity(getlocalvar(\"self\"),NULL());}"),"v0.34.6 basic unbind is mapped in script analysis");
    CHECK(!bindingIssue("void main(){bindentity(getlocalvar(\"self\"),getlocalvar(\"other\"),1,2,3,1,4);}"),"v0.34.6 literal supported binding flags are mapped");
    CHECK(bindingIssue("void main(){bindentity(getlocalvar(\"self\"),getlocalvar(\"other\"),1,2,3,1,16);}"),"v0.34.6 defined animation binding remains partial");
    CHECK(bindingIssue("void main(){bindentity(getlocalvar(\"self\"),getlocalvar(\"other\"),1,2,3,1,getglobalvar(\"flags\"));}"),"v0.34.6 dynamic binding config remains partial");
    fs::path legacyGrabFile="/tmp/obor-v0347-grab.txt";
    auto parseLegacyGrab=[&](const std::string& commands){std::ofstream(legacyGrabFile)<<"name GrabTest\ntype enemy\n"<<commands<<"\nanim idle\nframe none\n";return CharacterParser::parse(legacyGrabFile,legacyGrabFile.parent_path());};
    auto grabOne=parseLegacyGrab("cantgrab 1");CHECK(!grabOne.noGrab&&grabOne.grabResistance==1&&grabOne.grabForce==0,"v0.34.7 cantgrab 1 sets resistance without absolute immunity");
    auto grabTwo=parseLegacyGrab("cantgrab 2");CHECK(!grabTwo.noGrab&&grabTwo.grabForce==-999999&&grabTwo.grabResistance==0,"v0.34.7 cantgrab 2 reduces attacker force without defending immunity");
    CHECK(parseLegacyGrab("cantgrab 0").grabResistance==1,"v0.34.7 cantgrab 0 follows supplied v7533 legacy branch");
    CHECK(parseLegacyGrab("notgrab 2").grabForce==-999999,"v0.34.7 notgrab alias follows cantgrab mapping");
    auto grabOrder=parseLegacyGrab("cantgrab 2\ngrabforce 5\ncantgrab 1\nantigrab 7");CHECK(grabOrder.grabForce==5&&grabOrder.grabResistance==7,"v0.34.7 grab tuning respects later directives");
    CHECK(parseLegacyGrab("antigrab 7\ncantgrab 1").grabResistance==1,"v0.34.7 cantgrab overwrites earlier resistance");
    CHECK(CommandRegistry::lookup("cantgrab").status==CommandStatus::Supported&&CommandRegistry::lookup("notgrab").status==CommandStatus::Supported,"v0.34.7 verified legacy grab commands are supported");
    auto terrainRoot=sourceDir/"tests/fixtures/runtime_terrain";auto terrainScan=ProjectScanner::scan(terrainRoot);auto terrainStages=LevelParser::parseAll(terrainRoot/"data",terrainRoot);
    CHECK(terrainStages[0].geometry[0].openborShape&&std::fabs(terrainStages[0].geometry[0].shape[0]-100.25f)<0.001f&&terrainStages[0].geometry[0].shape[6]==40,"v0.34.4 terrain preserves float origins and four corners/depth");
    auto terrainComp=CompatibilityAnalyzer::analyze(terrainScan);bool terrainWarning=false;for(const auto&issue:terrainComp.issues)if(issue.command=="script-file"&&issue.message.find("checkhole")!=std::string::npos)terrainWarning=true;
    CHECK(!terrainWarning,"v0.34.4 implemented terrain queries are no longer unmapped script APIs");
    fs::path terrainOut="/tmp/obor-v0344-terrain-port";fs::remove_all(terrainOut);PortGenerator::generate(terrainScan,terrainComp,terrainOut);

    std::cout << (gFails? "REGRESSION FAIL " : "REGRESSION PASS ") << gFails << " failures\n";
    return gFails?1:0;
}
