#include "Engine.hpp"
#include <iostream>
#include <stdexcept>

struct RuntimeCompatibilityTest {
  static void check(bool ok,const char* message){if(!ok)throw std::runtime_error(message);std::cout<<"PASS: "<<message<<"\n";}
  static double global(const Engine& e,const char* key){auto it=e.scriptVm_.globals().find(key);if(it==e.scriptVm_.globals().end())return 0;auto n=std::get_if<double>(&it->second);return n?*n:0;}
  static void run(const std::filesystem::path& root){
    Engine e;check(e.initialize(root),"generated runtime initializes");e.config_.autoPreviewMusic=false;e.tickCounter_=1;
    check(e.stage_->panelCount==6,"panel order expands repetitions");
    check(std::string(e.stage_->panels[0])=="bgs/a.gif"&&std::string(e.stage_->panels[1])=="bgs/b.gif"&&std::string(e.stage_->panels[3])=="bgs/b.gif","panel order preserves letters and directive order");
    e.loadCurrentPlayerSprite();check(global(e,"helperFrames")==1,"animationscript main runs even without cmd");
    check(global(e,"shared")==1,"model inline script executes on frame entry");
    e.startPlayerAttack();e.loadCurrentPlayerSprite();
    for(int i=0;i<45;++i){e.updatePlayer();e.loadCurrentPlayerSprite();}
    check(e.playerAttackTicks_>0&&e.player_.frameIndex()==2,"long attack reaches its last frame before ending");
    check(global(e,"lastAttackFrame")==1&&global(e,"stamp")==9,"inline script and multiple cmd calls execute once in frame order");
    check(global(e,"helperFrames")==4,"helper main coexists with generated inline and cmd code");
    for(int i=0;i<17;++i){e.updatePlayer();e.loadCurrentPlayerSprite();}
    check(e.playerAttackTicks_==0&&std::string(e.player_.animation()->name)=="idle","attack returns to idle after actual frame delays");
    RuntimeEntity victim;victim.model=e.findCharacter("Enemy");victim.animation.setAnimation(e.findAnimation(victim.model,"fall"));victim.worldX=120;victim.z=200;victim.altitude=-0.1f;victim.verticalVelocity=1;victim.fallTicks=28;e.entities_.push_back(victim);
    e.updateEntities();check(e.entities_[0].animation.frameIndex()==1&&e.entities_[0].recoveryTicks>=16,"landing resumes the requested frame for its remaining duration");
    check(e.pendingChildSpawns_.size()==1&&e.pendingChildSpawns_[0].model==e.findCharacter("Dust"),"landing queues the named dust model once");e.applyLandFrame(e.entities_[0].animation,120,200,1);check(e.pendingChildSpawns_.size()==1,"landframe does not rewind or spawn again at its landing frame");e.flushChildSpawns();
    check(e.entities_.size()==2&&e.entities_[1].animationEffect,"landing dust enters runtime as a temporary animation effect");
    auto spawnType=std::get_if<double>(&e.entities_[1].scriptCtx.local["spawn_type"]);check(spawnType&&*spawnType==8,"landing effect exposes the OpenBOR dust-land spawn type");
    for(int i=0;i<7;++i)e.updateEntities();
    check(!e.entities_[1].visible&&!e.entities_[1].alive,"landing dust disappears when its animation finishes");
    check(e.pendingChildSpawns_.empty(),"ground contact does not repeatedly create landing dust");
    check(std::string(e.entities_[0].animation.animation()->name)=="fall","landing frames are not cut off after four ticks");
  }
};
int main(int argc,char** argv){try{if(argc!=2)return 2;RuntimeCompatibilityTest::run(argv[1]);std::cout<<"RUNTIME COMPATIBILITY PASS\n";return 0;}catch(const std::exception& error){std::cerr<<"FAIL: "<<error.what()<<"\n";return 1;}}
