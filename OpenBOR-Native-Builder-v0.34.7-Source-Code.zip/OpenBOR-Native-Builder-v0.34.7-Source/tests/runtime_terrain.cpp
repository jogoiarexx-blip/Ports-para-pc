#include "Engine.hpp"
#include <iostream>
#include <stdexcept>
struct RuntimeCompatibilityTest {
 static void check(bool ok,const char* label){if(!ok)throw std::runtime_error(label);std::cout<<"PASS: "<<label<<"\n";}
 static void run(const std::filesystem::path& root){
  Engine e;check(e.initialize(root),"terrain fixture initializes");e.config_.autoPreviewMusic=false;
  std::vector<std::string> missing;
  auto query=[&](const char* name,std::vector<ScriptValue> args){missing.clear();auto v=e.callScriptFunction(name,args,e.playerScriptCtx_,missing);auto p=std::get_if<double>(&v);if(!p)throw std::runtime_error("terrain result must be numeric");return *p;};
  check(query("checkhole",{140.0,180.0})==1&&missing.empty(),"point inside trapezoid detects hole without unmapped warning");
  check(query("checkhole",{105.0,160.5})==0,"sloped upper boundary excludes point inside old bounding rectangle");
  check(query("checkhole",{100.25,200.5})==1,"float coordinates and bottom boundary are inclusive");
  check(query("checkhole",{140.0,160.499})==0&&query("checkhole",{140.0,200.501})==0,"points beyond depth bounds do not hit hole");
  check(query("checkholeindex",{140.0,180.0})==0,"two-argument query returns first hole index");
  check(query("checkholeindex",{140.0,180.0,1.0})==1,"altitude query selects highest eligible overlapping hole");
  check(query("checkhole",{140.0,180.0,22.0})==1&&query("checkhole",{140.0,180.0,22.01})==0,"hole altitude uses OpenBOR two-unit walkoff tolerance");
  check(query("checkholeindex",{140.0,180.0,22.01})==-1,"no eligible hole returns negative index");
  check(query("checkhole",{125.0,185.0})==0&&query("checkholeindex",{125.0,185.0,0.0})==-1,"overlapping wall suppresses hole even above query altitude");
  check(query("checkwall",{230.0,180.0})==30&&missing.empty(),"wall query returns highest overlapping height");
  check(query("checkwall",{230.0,180.0,15.0})==10,"wall query respects maximum altitude");
  check(query("checkwall",{230.0,180.0,30.0})==30,"wall height equal to query altitude is eligible");
  check(query("checkwall",{230.0,180.0,9.0})==0&&query("checkwallindex",{230.0,180.0,9.0})==-1,"walls above requested altitude do not count");
  check(query("checkwallindex",{230.0,180.0})==1&&query("checkwallindex",{230.0,180.0,15.0})==0,"wall index counts walls independently of holes and platform entries");
  check(query("checkwall",{201.0,160.0})==10&&query("checkwall",{220.0,160.0})==30,"sloped wall sides use interpolated corner offsets");
  check(query("checkwall",{1000.0,180.0})==0&&query("checkwallindex",{1000.0,180.0})==-1,"empty terrain returns zero height and negative index");
  check(query("checkwall",{410.0,200.0})==0,"zero-depth shape does not divide by zero or invent a wall");
  check(query("checkwall",{460.0,190.0})==0&&query("checkwallindex",{460.0,190.0})==-1,"zero-height wall follows original highest-wall selection");
  query("checkwall",{615.0,185.0});check(missing.size()==1&&missing[0]=="terrain-legacy-rectangle","legacy rectangle fallback is explicitly logged as incomplete");
  e.loadCurrentPlayerSprite();auto&g=e.scriptVm_.globals();check(std::get<double>(g.at("holeProbe"))==1&&std::get<double>(g.at("wallProbe"))==30,"actual @cmd helper receives hole and wall results through ScriptVM");
  query("checkwall",{1.0});check(missing.size()==1&&missing[0]=="checkwall-arguments","missing coordinates produce a visible argument diagnostic");
  auto stage=e.stage_;e.stage_=nullptr;check(query("checkhole",{0.0,0.0})==0&&query("checkholeindex",{0.0,0.0})==-1&&query("checkwall",{0.0,0.0})==0,"absent stage returns neutral terrain values");e.stage_=stage;
 }
};
int main(int argc,char**argv){try{if(argc!=2)return 2;RuntimeCompatibilityTest::run(argv[1]);std::cout<<"RUNTIME TERRAIN PASS\n";return 0;}catch(const std::exception&e){std::cerr<<"FAIL: "<<e.what()<<"\n";return 1;}}
