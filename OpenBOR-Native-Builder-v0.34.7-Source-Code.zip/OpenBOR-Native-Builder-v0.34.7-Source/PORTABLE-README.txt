OpenBOR Native Builder v0.32.0

Versão portátil do conversor/portador genérico OpenBOR -> runtime C++ nativo.
Aceita pasta, ZIP, PAK e ZIP completo do OpenBOR com Paks/*.pak.

Para compilar o Builder no Windows, use BUILD-PORTABLE-WINDOWS.cmd.
Se CMake/Build Tools não estiverem disponíveis, execute INSTALAR-FERRAMENTAS-WINDOWS.cmd.

Consulte README.md para compatibilidade e limitações atuais.
