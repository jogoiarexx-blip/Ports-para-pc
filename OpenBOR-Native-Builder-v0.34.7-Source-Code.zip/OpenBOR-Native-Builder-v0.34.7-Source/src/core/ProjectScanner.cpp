#include "ProjectScanner.hpp"
#include "SafePath.hpp"
#include <algorithm>
#include <cctype>

namespace {
std::string lower(std::string s) {
    std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c){ return static_cast<char>(std::tolower(c)); });
    return s;
}
bool isOneOf(const std::string& ext, std::initializer_list<const char*> list) {
    for (auto* v : list) if (ext == v) return true;
    return false;
}
}

ScanReport ProjectScanner::scan(const std::filesystem::path& root) {
    ScanReport r;
    std::error_code ec;
    r.root = std::filesystem::weakly_canonical(std::filesystem::absolute(root), ec);
    if(ec) r.root = std::filesystem::absolute(root).lexically_normal();
    r.dataDir = SafePath::resolveWithin(r.root,"data");
    if(!std::filesystem::is_directory(r.dataDir) && std::filesystem::is_directory(r.root / "assets" / "openbor-data")) {
        // Generated ports keep the original OpenBOR data here. Supporting this layout makes
        // `test <port-folder>` validate real generated ports rather than expecting port/data/.
        r.dataDir = r.root / "assets" / "openbor-data";
    }
    r.hasDataDir = std::filesystem::is_directory(r.dataDir);
    if (!r.hasDataDir) {
        r.warnings.push_back("Pasta data/ nao encontrada.");
        return r;
    }
    r.hasModels = std::filesystem::exists(SafePath::resolveWithin(r.dataDir,"models.txt"));
    r.hasLevels = std::filesystem::exists(SafePath::resolveWithin(r.dataDir,"levels.txt"));
    r.hasMenu = std::filesystem::exists(SafePath::resolveWithin(r.dataDir,"menu.txt"));
    r.hasVideo = std::filesystem::exists(SafePath::resolveWithin(r.dataDir,"video.txt"));
    r.hasLifebar = std::filesystem::exists(SafePath::resolveWithin(r.dataDir,"lifebar.txt"));
    r.hasScriptConfig = std::filesystem::exists(SafePath::resolveWithin(r.dataDir,"script.txt"));
    auto hasEither=[&](const std::filesystem::path& base){ return std::filesystem::exists(base.string()+".gif") || std::filesystem::exists(base.string()+".png") || std::filesystem::exists(base.string()+".bmp"); };
    r.hasTitleBackground = hasEither(r.dataDir / "bgs" / "title");
    r.hasSelectBackground = hasEither(r.dataDir / "bgs" / "select");
    r.hasLoadingBackground = hasEither(r.dataDir / "bgs" / "loading") || hasEither(r.dataDir / "bgs" / "loading2");
    if (!r.hasModels) r.warnings.push_back("models.txt nao encontrado.");
    if (!r.hasLevels) r.warnings.push_back("levels.txt nao encontrado.");

    for (const auto& e : std::filesystem::recursive_directory_iterator(r.dataDir)) {
        if (!e.is_regular_file()) continue;
        ++r.files;
        auto ext = lower(e.path().extension().string());
        if (isOneOf(ext, {".png", ".gif", ".bmp", ".jpg", ".jpeg", ".webp", ".pcx"})) ++r.images;
        else if (isOneOf(ext, {".wav", ".ogg", ".mp3", ".flac", ".bor"})) ++r.audio;
        else if (isOneOf(ext, {".txt", ".c", ".h", ".cfg"})) ++r.text;
    }
    return r;
}
