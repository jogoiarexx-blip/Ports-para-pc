#include "TextDatabase.hpp"
#include <fstream>
#include <sstream>
#include <algorithm>
#include <cctype>

namespace {
std::string trim(std::string s) {
    auto notSpace = [](unsigned char c){ return !std::isspace(c); };
    s.erase(s.begin(), std::find_if(s.begin(), s.end(), notSpace));
    s.erase(std::find_if(s.rbegin(), s.rend(), notSpace).base(), s.end());
    return s;
}
}

std::vector<TextEntry> TextDatabase::parse(const std::filesystem::path& file) {
    std::ifstream in(file);
    std::vector<TextEntry> out;
    if (!in) return out;
    std::string line;
    std::size_t lineNo = 0;
    bool inInlineScript = false;
    std::size_t scriptEntry = 0;
    while (std::getline(in, line)) {
        ++lineNo;
        if(!line.empty() && line.back()=='\r') line.pop_back();
        const std::string rawLine=line;
        line = trim(line);
        if (line.empty()) continue;
        std::istringstream probe(line);
        std::string first; probe >> first;
        std::string firstLower=first; std::transform(firstLower.begin(),firstLower.end(),firstLower.begin(),[](unsigned char c){return (char)std::tolower(c);});
        // v0.26.1 hotfix retained in v0.27: OpenBOR inline script bodies are not data commands.
        // Keep the script delimiters/@cmd visible to compatibility analysis, but skip C-like body lines.
        if(inInlineScript && firstLower!="@end_script") { out[scriptEntry].scriptBody+=rawLine+'\n'; continue; }
        if(firstLower=="@script") { inInlineScript=true; scriptEntry=out.size(); }
        if(firstLower=="@end_script") inInlineScript=false;
        // @cmd arguments are script expressions: quoted spaces, # and nested
        // calls must survive until the generated function call is assembled.
        if(firstLower=="@cmd") {
            TextEntry e; e.line=lineNo; e.key=first;
            std::string arg; char quote=0; int depth=0;
            for(std::size_t i=first.size();i<line.size();++i){
                char c=line[i];
                if(quote){arg+=c;if(c=='\\'&&i+1<line.size())arg+=line[++i];else if(c==quote)quote=0;continue;}
                if(c=='"'||c=='\''){quote=c;arg+=c;continue;}
                if(c=='#'&&depth==0)break;
                if(c=='(')++depth;else if(c==')')--depth;
                if(std::isspace((unsigned char)c)&&depth==0){if(!arg.empty()){e.values.push_back(arg);arg.clear();}}else arg+=c;
            }
            if(!arg.empty())e.values.push_back(arg);
            out.push_back(std::move(e));continue;
        }
        auto semi = line.find('#');
        if (semi != std::string::npos) line.resize(semi);
        line = trim(line);
        if (line.empty()) continue;
        std::istringstream ss(line);
        TextEntry e;
        e.line = lineNo;
        ss >> e.key;
        std::string v;
        while (ss >> v) e.values.push_back(v);
        if (!e.key.empty()) out.push_back(std::move(e));
    }
    return out;
}
