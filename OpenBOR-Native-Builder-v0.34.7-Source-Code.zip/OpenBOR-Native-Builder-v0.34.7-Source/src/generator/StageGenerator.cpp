#include "StageGenerator.hpp"
#include <fstream>
#include <sstream>
#include <iomanip>

namespace {
std::string esc(const std::string& s){
    std::string o; o.reserve(s.size()+8);
    for(char c:s){
        if(c=='\\'||c=='\"') o.push_back('\\');
        if(c=='\n') o += "\\n"; else o.push_back(c);
    }
    return o;
}
std::string floatLiteral(float v){
    std::ostringstream o; o<<std::setprecision(8)<<v; auto s=o.str();
    if(s.find_first_of(".eE")==std::string::npos) s += ".0";
    return s + "f";
}
}

void StageGenerator::generate(const std::vector<StageDef>& stages, const std::filesystem::path& outDir){
    auto gen=outDir/"runtime"/"generated";
    std::filesystem::create_directories(gen);
    std::ofstream h(gen/"GeneratedStages.hpp");
    h << R"CPP(#pragma once
#include <cstddef>
namespace generated {
struct Spawn { int id; const char* model; const char* alias; const char* item; const char* map; const char* spawnScript; int x,z,a,y,at,health,score,spawnType; bool boss; bool flip; bool hasAt; };
struct Geometry { const char* kind; int x,z,w,h,depth,altitude; bool openborShape; float shape[9]; };
struct Layer { const char* kind; const char* path; float xRatio,zRatio; int xOffset,zOffset,xSpacing,zSpacing,xRepeat,zRepeat,zOrder; };
struct StageEvent { int id; const char* kind; int at,value,group; bool hasAt; const char* text; };
struct StageInstruction { int sequence,kind,refId; };
struct CutsceneAnimation { const char* path; int x,y,skip,noSkip,durationTicks; };
struct Stage {
  const char* sourceFile;
  const char* setName;
  const char* direction;
  const char* typeName;
  const char* background;
  const char* music;
  bool musicLoop;
  bool endLevel;
  int order,setOrder,cameraType,scrollSpeed;
  int zMin,zMax,backgroundHeight;
  int playerStartX,playerStartZ,playerStartA;
  const char* const* panels;
  std::size_t panelCount;
  const Layer* layers;
  std::size_t layerCount;
  const Spawn* spawns;
  std::size_t spawnCount;
  const Geometry* geometry;
  std::size_t geometryCount;
  const StageEvent* events;
  std::size_t eventCount;
  const StageInstruction* instructions;
  std::size_t instructionCount;
  const char* branchName;
  const char* nextStage;
  const char* branchStage;
  const char* levelScript;
  const char* bossMusic; int bossMusicOffset; const char* waterPath; int waterWarp; int rockMode;
  const char* preSceneFile; const char* sceneMusic; bool sceneMusicLoop; const CutsceneAnimation* sceneAnimations; std::size_t sceneAnimationCount;
};
extern const Stage kStages[];
extern const std::size_t kStageCount;
}
)CPP";

    std::ofstream cpp(gen/"GeneratedStages.cpp");
    cpp << "#include \"GeneratedStages.hpp\"\nnamespace generated {\n";
    for(std::size_t i=0;i<stages.size();++i){
        cpp << "static const char* s"<<i<<"_panels[] = {";
        if(stages[i].panels.empty()) cpp << "nullptr";
        for(std::size_t p=0;p<stages[i].panels.size();++p){
            if(p) cpp << ',';
            cpp << "\""<<esc(stages[i].panels[p])<<"\"";
        }
        cpp << "};\n";
        cpp << "static const Layer s"<<i<<"_layers[] = {\n";
        if(stages[i].layers.empty()) cpp << "  {\"\",\"\",0.5f,0.5f,0,0,0,0,0,0,0},\n";
        for(const auto& l:stages[i].layers){
            cpp << "  {\""<<esc(l.kind)<<"\",\""<<esc(l.path)<<"\","<<floatLiteral(l.xRatio)<<","<<floatLiteral(l.zRatio)<<","<<l.xOffset<<','<<l.zOffset<<','<<l.xSpacing<<','<<l.zSpacing<<','<<l.xRepeat<<','<<l.zRepeat<<','<<l.zOrder<<"},\n";
        }
        cpp << "};\n";
        cpp << "static const Spawn s"<<i<<"_spawns[] = {\n";
        if(stages[i].spawns.empty()) cpp << "  {-1,\"\",\"\",\"\",\"\",\"\",0,0,0,0,0,-1,0,0,false,false,false},\n";
        for(const auto& s:stages[i].spawns){
            cpp << "  {"<<s.id<<",\""<<esc(s.model)<<"\",\""<<esc(s.alias)<<"\",\""<<esc(s.item)<<"\",\""<<esc(s.map)<<"\",\""<<esc(s.spawnScript)<<"\","
                <<s.x<<','<<s.z<<','<<s.a<<','<<s.y<<','<<s.at<<','<<s.health<<','<<s.score<<','<<s.spawnType<<','
                <<(s.boss?"true":"false")<<','<<(s.flip?"true":"false")<<','<<(s.hasAt?"true":"false")<<"},\n";
        }
        cpp << "};\n";
        cpp << "static const Geometry s"<<i<<"_geometry[] = {\n";
        if(stages[i].geometry.empty()) cpp << "  {\"\",0,0,0,0,0,0},\n";
        for(const auto& g:stages[i].geometry){
            cpp << "  {\""<<esc(g.kind)<<"\","<<g.x<<','<<g.z<<','<<g.w<<','<<g.h<<','<<g.depth<<','<<g.altitude<<','<<(g.openborShape?"true":"false")<<",{";
            for(int n=0;n<9;++n){if(n)cpp<<',';cpp<<std::setprecision(9)<<std::showpoint<<g.shape[n]<<std::noshowpoint<<'f';}cpp<<"}},\n";
        }
        cpp << "};\n";
        cpp << "static const StageEvent s"<<i<<"_events[] = {\n";
        if(stages[i].events.empty()) cpp << "  {-1,\"\",0,0,0,false,\"\"},\n";
        for(const auto& ev:stages[i].events){
            cpp << "  {"<<ev.id<<",\""<<esc(ev.kind)<<"\","<<ev.at<<','<<ev.value<<','<<ev.group<<','<<(ev.hasAt?"true":"false")<<",\""<<esc(ev.text)<<"\"},\n";
        }
        cpp << "};\n";
        cpp << "static const StageInstruction s"<<i<<"_instructions[] = {\n";
        if(stages[i].instructions.empty()) cpp << "  {-1,-1,-1},\n";
        for(const auto& ins:stages[i].instructions) cpp << "  {"<<ins.sequence<<','<<ins.kind<<','<<ins.refId<<"},\n";
        cpp << "};\n";
        cpp << "static const CutsceneAnimation s"<<i<<"_scene[] = {\n";
        if(stages[i].sceneAnimations.empty()) cpp << "  {\"\",0,0,1,0,180},\n";
        for(const auto& a:stages[i].sceneAnimations) cpp << "  {\""<<esc(a.path)<<"\","<<a.x<<','<<a.y<<','<<a.skip<<','<<a.noSkip<<','<<a.durationTicks<<"},\n";
        cpp << "};\n";
    }
    cpp << "const Stage kStages[] = {\n";
    if(stages.empty()) cpp << "  {\"\",\"\",\"right\",\"\",\"\",\"\",false,false,0,0,0,0,160,232,160,80,200,0,nullptr,0,nullptr,0,nullptr,0,nullptr,0,nullptr,0,nullptr,0,\"\",\"\",\"\",\"\",\"\",0,\"\",0,0,\"\",\"\",false,nullptr,0},\n";
    for(std::size_t i=0;i<stages.size();++i){
        const auto& s=stages[i];
        cpp << "  {\""<<esc(s.sourceFile)<<"\",\""<<esc(s.setName)<<"\",\""<<esc(s.direction)<<"\",\""<<esc(s.type)<<"\",\""<<esc(s.background)<<"\",\""<<esc(s.music)<<"\","
            <<(s.musicLoop?"true":"false")<<','<<(s.endLevel?"true":"false")<<','
            <<s.order<<','<<s.setOrder<<','<<s.cameraType<<','<<s.scrollSpeed<<','
            <<s.zMin<<','<<s.zMax<<','<<s.backgroundHeight<<','<<s.playerStartX<<','<<s.playerStartZ<<','<<s.playerStartA
            <<",s"<<i<<"_panels,"<<s.panels.size()
            <<",s"<<i<<"_layers,"<<s.layers.size()
            <<",s"<<i<<"_spawns,"<<s.spawns.size()
            <<",s"<<i<<"_geometry,"<<s.geometry.size()
            <<",s"<<i<<"_events,"<<s.events.size()
            <<",s"<<i<<"_instructions,"<<s.instructions.size()
            <<",\""<<esc(s.branchName)<<"\",\""<<esc(s.nextStage)<<"\",\""<<esc(s.branchStage)<<"\",\""<<esc(s.levelScript)<<"\",\""<<esc(s.bossMusic)<<"\","<<s.bossMusicOffset<<",\""<<esc(s.waterPath)<<"\","<<s.waterWarp<<","<<s.rockMode<<",\""<<esc(s.preSceneFile)<<"\",\""<<esc(s.sceneMusic)<<"\","<<(s.sceneMusicLoop?"true":"false")<<",s"<<i<<"_scene,"<<s.sceneAnimations.size()<<"},\n";
    }
    cpp << "};\nconst std::size_t kStageCount="<<stages.size()<<";\n}\n";

    std::ofstream json(outDir/"reports"/"stage-data.json");
    json << "{\n  \"stages\": [\n";
    for(std::size_t i=0;i<stages.size();++i){
        const auto& s=stages[i];
        json << "    {\"source\":\""<<esc(s.sourceFile)<<"\",\"set\":\""<<esc(s.setName)<<"\",\"order\":"<<s.order
             <<",\"branch\":\""<<esc(s.branchName)<<"\",\"direction\":\""<<esc(s.direction)<<"\",\"cameraType\":"<<s.cameraType
             <<",\"background\":\""<<esc(s.background)<<"\",\"music\":\""<<esc(s.music)<<"\",\"bossmusic\":\""<<esc(s.bossMusic)<<"\",\"water\":\""<<esc(s.waterPath)<<"\",\"scene\":\""<<esc(s.preSceneFile)<<"\",\"z\":["<<s.zMin<<','<<s.zMax<<"],\"panels\":[";
        for(std::size_t p=0;p<s.panels.size();++p) json << "\""<<esc(s.panels[p])<<"\""<<(p+1<s.panels.size()?",":"");
        json << "],\"layers\":[";
        for(std::size_t p=0;p<s.layers.size();++p) json << "{\"kind\":\""<<esc(s.layers[p].kind)<<"\",\"path\":\""<<esc(s.layers[p].path)<<"\",\"xRatio\":"<<s.layers[p].xRatio<<",\"zRatio\":"<<s.layers[p].zRatio<<",\"zOrder\":"<<s.layers[p].zOrder<<"}"<<(p+1<s.layers.size()?",":"");
        json << "],\"levelScript\":\""<<esc(s.levelScript)<<"\",\"spawns\":[";
        for(std::size_t j=0;j<s.spawns.size();++j){
            const auto& p=s.spawns[j];
            json << "{\"id\":"<<p.id<<",\"model\":\""<<esc(p.model)<<"\",\"spawnScript\":\""<<esc(p.spawnScript)<<"\",\"coords\":["<<p.x<<','<<p.z<<','<<p.a<<"],\"at\":"<<p.at<<",\"hasAt\":"<<(p.hasAt?"true":"false")<<",\"boss\":"<<(p.boss?"true":"false")<<",\"type\":"<<p.spawnType<<"}"<<(j+1<s.spawns.size()?",":"");
        }
        json << "],\"events\":[";
        for(std::size_t j=0;j<s.events.size();++j){
            const auto& ev=s.events[j];
            json << "{\"id\":"<<ev.id<<",\"kind\":\""<<esc(ev.kind)<<"\",\"at\":"<<ev.at<<",\"value\":"<<ev.value<<"}"<<(j+1<s.events.size()?",":"");
        }
        json << "],\"instructions\":[";
        for(std::size_t j=0;j<s.instructions.size();++j){ const auto& ins=s.instructions[j]; json << "{\"sequence\":"<<ins.sequence<<",\"kind\":"<<ins.kind<<",\"refId\":"<<ins.refId<<"}"<<(j+1<s.instructions.size()?",":""); }
        json << "],\"geometry\":[";
        for(std::size_t g=0;g<s.geometry.size();++g){ const auto& q=s.geometry[g]; json<<"{\"kind\":\""<<esc(q.kind)<<"\",\"rect\":["<<q.x<<","<<q.z<<","<<q.w<<","<<q.h<<"]}"<<(g+1<s.geometry.size()?",":""); }
        json << "]}" << (i+1<stages.size()?",":"") << "\n";
    }
    json << "  ]\n}\n";
}