# OpenBOR Native Builder v0.34.7

A v0.34.7 corrige cantgrab/notgrab conforme o OpenBOR v7533, preservando força e resistência como valores distintos. Agarrões deixam de rejeitar igualdade entre esses valores e passam a respeitar limites de altura e movimento do frame. Consulte [VALIDACAO-v0.34.7.md](VALIDACAO-v0.34.7.md) para testes e resultados nos PAKs.

## v0.33 — factions, stage groups, follow e ScriptVM

- `hostile` e `candamage` aceitam máscaras OpenBOR textuais (`player`, `enemy`, `npc`, `shot`, `obstacle`, etc.) e são aplicadas separadamente a seleção de alvo e permissão de dano.
- `aggression` preserva valores positivos e negativos e influencia o tempo de reação da IA nativa.
- `group min max` mantém a janela de inimigos ativa durante a fase; `wait` segura o avanço até os inimigos ativos terminarem.
- `followanim`/`followcond` usam resultados reais de hit, block, lethal e alvo agarrável para trocar animação.
- `subentity`/`spawnframe`/`summonframe`/`unsummonframe` executam o ciclo básico de entidades-filhas no runtime.
- ScriptVM: `changeentityproperty(..., "position", x, z, a)` agora altera posição de players e entidades, cobrindo helpers de spawn comuns chamados por `@cmd`.
- Corrigido o sentinel de estágio vazio: projetos sem `levels.txt` voltam a gerar runtime C++ compilável após a adição de `rockMode`.
- `remap/palette` continua conservadoramente `PARTIAL`: aplicação por imagem/ACT já existe, mas casos de paleta indexada/cores duplicadas ainda não são equivalentes pixel a pixel.

## v0.31 — registry `know`, cutscene e HUD

- `models.txt know <name> <path>` agora entra no registro gerado exatamente como `load`, preservando a diferença apenas no momento de carregamento de assets; isso evita inimigos/itens conhecidos sumirem do port.
- `animation` em arquivos de cutscene passa a ser classificado como `SUPPORTED`: caminho, posição, skip/noskip e timing decodificado já são executados pelo player nativo.
- `shadow 0..6` passa a `SUPPORTED` usando o sprite original quando presente e fallback nativo quando ausente.
- HUD: `icon` (incluindo flag de paleta), `icondie`, `nolife`, `lifeposition`, `nameposition` e `iconposition` executam no runtime. `lifebarstatus` ganhou largura, altura, modo absoluto/ratio e orientação, mas permanece `PARTIAL` por causa dos offsets históricos de camada.
- O relatório continua conservador: scripts `@cmd/@script`, `blast/burn`, `remap`, AI/factions, `water` e outras semânticas incompletas continuam `PARTIAL`.

## v0.30 — compatibilidade de comandos legados

- Regras globais de bloqueio de `models.txt`: `blockratio`, `mpblock` e `nochipdeath` agora entram no runtime.
- `defense.blockratio` e `defense.blocktype` preservam a diferença entre valor ausente e override explícito.
- `blocktype 0` herda `mpblock`; `-1` força HP; `1` usa MP→HP; `2` atinge ambos.
- `rock 1/2/3` possuem movimentos de estágio distintos e o HUD não balança junto com o cenário.
- `water` mantém onda em `rock 0` e parallax animado em `rock 1`.


Conversor/portador genérico em C++ para projetos OpenBOR. Aceita pasta, ZIP, PAK ou um ZIP completo do OpenBOR contendo `Paks/*.pak`, localiza o jogo, preserva os assets, gera dados/C++ e cria um runtime nativo próprio. Não há correções hardcoded por jogo.

## Fluxo

```text
PASTA / ZIP / PAK OPENBOR
  -> detecção/extração segura
  -> ProjectScanner + CompatibilityAnalyzer
  -> parsers de models/levels/scripts/assets
  -> geração de runtime C++
  -> build nativo
  -> test
  -> pacote portátil
```

`CONVERT SUCCESS`, `NATIVE BUILD SUCCESS` e `GAME COMPATIBILITY` são resultados diferentes. Um executável compilado não implica paridade total de gameplay.

## CLI

```text
openbor-native-builder analyze <pasta|jogo.zip|jogo.pak> [saida]
openbor-native-builder convert <pasta|jogo.zip|jogo.pak> [saida]
openbor-native-builder build <pasta|jogo.zip|jogo.pak> <saida>
openbor-native-builder scan <pasta|jogo.zip|jogo.pak>
openbor-native-builder audit <pasta|jogo.zip|jogo.pak>
openbor-native-builder repair <pasta|jogo.zip|jogo.pak> <saida>
openbor-native-builder test <port>
openbor-native-builder package <port>
```

No Windows, abrir o Builder sem argumentos permite escolher pasta, ZIP ou PAK. O script `BUILD-PORTABLE-WINDOWS.cmd` procura CMake no PATH, Visual Studio/Build Tools, `C:\Program Files\CMake` e `tools/cmake/bin`.

## Destaques da v0.28

- `defense.blockratio` passou a causar chip damage real durante o bloqueio, em vez de ficar apenas preservado como metadado.
- `defense.blocktype` roteia esse dano para HP/MP; `blocktype 1` consome MP antes de HP e `blocktype 2` atinge ambos.
- O parser agora lê `mp` por personagem e o runtime mantém MP independente para P1, coop e entidades.
- `knockdowncount` e o multiplicador `defense.knockdown` entram na resolução nativa de queda com acumulador por personagem.
- `bossmusic <arquivo> <offset>` usa o offset como ponto de retorno do loop; no backend decodificado o byte legado é mapeado proporcionalmente para amostras PCM.
- `water` agora separa velocidade (`warp`) da amplitude do efeito e lê `rock`; `rock 1` recebe deslocamento/balanço próprio.
- Mantidas as correções v0.27/v0.27.1 para cutscenes `scene/animation`, `blast/burn`, sombras, `diesound`, `lifespan/landframe`, HUD legado e regras de defesa.

## Compatibilidade atual

O Builder já é funcional como conversor, mas não é uma reimplementação 100% completa do OpenBOR. Continuam `PARTIAL`, entre outros:

- layouts históricos raros de `combostyle 1`/command buffer;
- model-copy completo para `modelflag no_weapon/no_script` e todos os campos legados;
- bind avançado independente do sistema parent/child e algumas APIs modernas de child;
- alguns estilos históricos de IA, armas e comportamento de drop;
- subscreens, blending/drawmethod e efeitos de layer especializados;
- casos históricos de palette indexada/remap e UIs/cutscenes específicas;
- OGG/OGA sem decoder do sistema: no Windows ainda é tentado via Media Foundation. Um decoder Vorbis realmente embutido continua pendente.

## Build portátil no Windows

**Atalho recomendado:** execute `GERAR-PORTATIL-WINDOWS.cmd` para preparar as ferramentas e compilar em uma unica etapa.

1. Extraia o projeto.
2. Se necessário, execute `INSTALAR-FERRAMENTAS-WINDOWS.cmd`. O instalador primeiro detecta CMake/MSVC e só instala o que estiver faltando; ele não trata "nenhuma atualização disponível" como erro.
3. Opcionalmente execute `VERIFICAR-FERRAMENTAS-WINDOWS.cmd` para confirmar CMake + workload C++.
4. Execute `BUILD-PORTABLE-WINDOWS.cmd`.
5. O Builder portátil será criado em `dist-portable`.

Depois de compilado, o Builder/port gerado não precisa do OpenBOR original para executar o runtime convertido.


## v0.28 gameplay parity

Esta revisão fecha mais lacunas de combate e fase detectadas após a v0.27.1. A suíte de regressão passa sem falhas; um port de teste foi regenerado, o runtime C++ compilou até 100% e executou em modo headless com código de saída 0.

### Limites conhecidos

- Fallbacks globais de `models.txt` como `mpblock`, `blockratio` e `nochipdeath` ainda não cobrem todas as combinações históricas.
- O offset de `bossmusic` é definido em bytes no OpenBOR; depois da decodificação para PCM, o runtime usa uma conversão proporcional quando não existe correspondência byte-a-byte do formato comprimido.
- O `water` nativo ainda aproxima o efeito; o warp de scanline/perspectiva exato e todos os modos `rock` históricos permanecem parciais.
- A VM OpenBORScript continua intencionalmente incremental: APIs não mapeadas são reportadas como `PARTIAL`.