# v0.40.1 — Windows MSVC build hotfix

- Renomeia a variavel interna `LINK` para `LINKOPTS`. `LINK` e interpretada automaticamente pelo MSVC linker e estava contaminando compilacoes posteriores.
- Limpa `LINK` no inicio dos scripts Windows para neutralizar opcoes herdadas do shell.
- Builds de ferramentas e testes usam explicitamente `/SUBSYSTEM:CONSOLE`; os tres frontends Win32 usam `/SUBSYSTEM:WINDOWS`.
- Corrige o `LNK2019`/`LNK1120` de `CrashGameplayTool.exe` procurando `WinMain`.
- Elimina o `LNK4044: opcao nao reconhecida '/link'` observado no linker.
- Atualiza `ABRIR-JOGO.cmd` e a identificacao visual para v0.40.1.

Nenhuma logica de gameplay da v0.40.0 foi removida ou refatorada neste hotfix.
