@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Crash Native v0.41.0 - Build Windows x64
set "VSCMD_SKIP_SENDTELEMETRY=1"
rem LINK e uma variavel especial lida automaticamente pelo link.exe.
rem Limpe qualquer valor herdado para impedir que /SUBSYSTEM:WINDOWS vaze para ferramentas de console.
set "LINK="

where cl >nul 2>nul
if not errorlevel 1 goto :compiler_ok

for %%V in (
  "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat"
  "C:\Program Files\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat"
  "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat"
  "C:\Program Files\Microsoft Visual Studio\2022\Professional\VC\Auxiliary\Build\vcvars64.bat"
  "C:\Program Files\Microsoft Visual Studio\2022\Enterprise\VC\Auxiliary\Build\vcvars64.bat"
) do if exist "%%~V" (
  echo Carregando ambiente C++: %%~V
  call "%%~V" >nul
  goto :compiler_check
)

:compiler_check
where cl >nul 2>nul
if not errorlevel 1 goto :compiler_ok

echo.
echo ERRO: compilador C++ do Visual Studio 2022 nao encontrado.
echo Instale "Desktop development with C++" no Visual Studio Build Tools.
echo Depois execute este arquivo novamente.
pause
exit /b 1

:compiler_ok
echo ============================================
echo  Crash Native v0.41.0 - Windows x64
cl 2>&1 | findstr /i "Version" 
echo ============================================

call :buildwin CrashNative.exe "src\game_win32.cpp src\png.cpp" "/link /SUBSYSTEM:WINDOWS user32.lib gdi32.lib winmm.lib" || goto :erro
call :build CrashGameplayTool.exe src\gameplay_tool.cpp || goto :erro
call :build CrashMoverTool.exe src\mover_tool.cpp || goto :erro
call :build CrashEnemyTool.exe src\enemy_tool.cpp || goto :erro
call :build CrashPlantTool.exe src\plant_tool.cpp || goto :erro
call :build CrashUnderwaterTool.exe src\underwater_tool.cpp || goto :erro
call :build CrashEnemyCoverageTool.exe src\enemy_coverage_tool.cpp || goto :erro
call :build CrashChildEffectTool.exe src\child_effect_tool.cpp || goto :erro
call :build CrashDingodileTool.exe src\dingodile_tool.cpp || goto :erro
call :build CrashTinyTool.exe src\tiny_tool.cpp || goto :erro
call :build CrashCortexTool.exe src\cortex_tool.cpp || goto :erro
call :build CrashMegaMixTool.exe src\mega_mix_tool.cpp || goto :erro
call :build CrashRouteTool.exe src\route_tool.cpp || goto :erro
call :build CrashCategoryTool.exe src\category_tool.cpp || goto :erro
call :build CrashPolarTool.exe src\polar_tool.cpp || goto :erro
call :build CrashJetpackTool.exe src\jetpack_tool.cpp || goto :erro
call :build CrashAirshipTool.exe src\airship_tool.cpp || goto :erro
call :build CrashHovercraftTool.exe src\hovercraft_tool.cpp || goto :erro
call :build CrashFrontendTool.exe src\frontend_tool.cpp || goto :erro
call :build CrashGaxTool.exe src\gax_tool.cpp || goto :erro
call :build TestPlayer.exe tests\test_player.cpp || goto :erro
call :build TestEntities.exe tests\test_entities.cpp || goto :erro
call :build TestCategory.exe tests\test_category.cpp || goto :erro
call :build TestRunState.exe tests\test_run_state.cpp || goto :erro
call :build TestFrontend.exe tests\test_frontend.cpp || goto :erro
call :build TestAudio.exe tests\test_audio.cpp || goto :erro
call :buildwin CrashNative-Scene.exe "src\scene_win32.cpp" "/link /SUBSYSTEM:WINDOWS user32.lib gdi32.lib" || goto :erro
call :build CrashSceneTool.exe src\scene_tool.cpp || goto :erro
call :buildwin CrashNative-Inspector.exe "src\viewer_win32.cpp" "/link /SUBSYSTEM:WINDOWS user32.lib gdi32.lib" || goto :erro
call :build CrashRomTool.exe src\inspect.cpp || goto :erro
call :build TestCore.exe tests\test_core.cpp || goto :erro
call :build CrashHDTool.exe "src\hd_tool.cpp src\png.cpp" || goto :erro
call :build TestHD.exe "tests\test_hd.cpp src\png.cpp" || goto :erro

echo.
echo Executando testes...
call "%~dp0TESTAR.cmd" /nopause || goto :erro
".\CrashEnemyCoverageTool.exe" input\crash.gba || goto :erro

echo v0.41.0>BUILD-WINDOWS-VERSION.txt
echo.
echo OK: CrashNative.exe v0.41.0 foi gerado e os testes passaram.
echo Agora execute ABRIR-JOGO.cmd.
pause
exit /b 0

:build
set "OUT=%~1"
set "SRC=%~2"
echo [C++] %OUT%
if exist "%OUT%" del /q "%OUT%" >nul 2>nul
cl /nologo /std:c++17 /EHsc /O2 /MT %SRC% /Fe"%OUT%" /link /SUBSYSTEM:CONSOLE
if errorlevel 1 exit /b %errorlevel%
if not exist "%OUT%" (
  echo ERRO: o compilador terminou sem gerar "%OUT%".
  echo Verifique se o Windows Defender/antivirus bloqueou ou removeu o arquivo.
  exit /b 2
)
exit /b 0

:buildwin
set "OUT=%~1"
set "SRC=%~2"
set "LINKOPTS=%~3"
echo [C++] %OUT%
if exist "%OUT%" del /q "%OUT%" >nul 2>nul
cl /nologo /std:c++17 /EHsc /O2 /MT %SRC% /Fe"%OUT%" %LINKOPTS%
if errorlevel 1 exit /b %errorlevel%
if not exist "%OUT%" (
  echo ERRO: o compilador terminou sem gerar "%OUT%".
  echo Verifique se o Windows Defender/antivirus bloqueou ou removeu o arquivo.
  exit /b 2
)
exit /b 0

:erro
echo.
echo FALHA ao compilar/testar a v0.41.0.
echo Copie a mensagem de erro exibida acima para eu corrigir.
pause
exit /b 1
