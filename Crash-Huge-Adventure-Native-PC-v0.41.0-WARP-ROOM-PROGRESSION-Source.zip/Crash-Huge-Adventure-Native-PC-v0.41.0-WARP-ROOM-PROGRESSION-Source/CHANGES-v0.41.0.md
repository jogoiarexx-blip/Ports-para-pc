# v0.41.0 — Warp Room / progressão fiel aos IDs da ROM

- Corrige o mapeamento estrutural do level-select: IDs 0–19 são as 20 fases normais; IDs 20–23 são Dingodile, N. Gin, Tiny e Cortex; 24 é a fase secreta.
- Cada Warp Room mostra 5 fases normais + o boss correspondente, sem inventar IDs intercalados.
- As cinco fases normais de um Warp Room ficam disponíveis juntas; o boss abre apenas depois das cinco concluídas.
- O Warp Room seguinte abre depois da vitória no boss anterior.
- Poderes permanentes agora são concedidos pelos bosses reais: 20 Super Body Slam, 21 Double Jump, 22 Tornado Spin, 23 Turbo Run.
- Save sobe para v8. Saves v1–v7 continuam aceitos; v7 e anteriores têm os bits de poder reconstruídos a partir dos bosses reais para remover concessões incorretas da v0.40.
- Ao concluir uma fase, o retorno ao mapa escolhe a próxima fase ainda não concluída do mesmo Warp Room, depois o boss, e só então o próximo mundo.
- Nomes da interface foram realinhados aos IDs reais da tabela da ROM.
- Mantém o hotfix MSVC da v0.40.1 e todo o gameplay já implementado.
