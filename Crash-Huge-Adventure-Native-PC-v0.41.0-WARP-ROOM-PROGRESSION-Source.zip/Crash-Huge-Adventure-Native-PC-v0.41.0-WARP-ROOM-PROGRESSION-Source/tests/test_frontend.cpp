#include "../src/frontend.hpp"
#include <cassert>
#include <iostream>
int main(){using namespace crash;RunState s;auto p=renderLevelMap(s,0);assert(p.size()==240u*160u);
assert(s.levelUnlocked(0)&&s.levelUnlocked(1)&&s.levelUnlocked(2)&&s.levelUnlocked(3)&&s.levelUnlocked(4));
assert(!s.levelUnlocked(5)&&!s.levelUnlocked(20));
assert(warpRoomOf(0)==0&&warpSlotOf(4)==4&&warpRoomOf(5)==1&&warpRoomOf(20)==0&&warpSlotOf(20)==5&&warpLevel(0,5)==20&&warpLevel(3,5)==23&&warpLevel(4,3)==24);
for(int i=0;i<5;i++){s.finishLevel(i);}
assert(s.levelUnlocked(20)&&!s.levelUnlocked(5));
s.finishLevel(20);
assert(s.levelUnlocked(5)&&s.levelUnlocked(9)&&!s.levelUnlocked(21));
assert((s.powerFlags&Player::SuperBodySlamPower)!=0);
auto q=renderLevelMap(s,5);assert(q.size()==p.size()&&q!=p);auto t=renderTitleScreen(true,0);auto t2=renderTitleScreen(true,1);assert(t.size()==240u*160u&&t!=t2);auto up=scaleUi(q,4);assert(up.size()==960u*640u);
assert(std::string(levelNames()[0])=="JUNGLE JAM"&&std::string(levelNames()[5])=="SNOW CRASH"&&std::string(levelNames()[20])=="DINGODILE"&&std::string(levelNames()[23])=="NEO CORTEX");
auto rom=read("input/crash.gba");auto art=loadRomUiArt(rom);assert(art.valid()&&art.menuSkyValid()&&art.pauseMenuValid());auto original=renderLevelMap(s,5,&art);assert(original.size()==q.size()&&original!=q);size_t opaque=0;for(auto c:art.levelSelectPlatform)if(c>>24)++opaque;assert(opaque>10000);auto pause=renderPauseScreen(&art,5);assert(pause.size()==240u*160u);assert(pause!=p);std::cout<<"Frontend checks passed: ROM level IDs, 5+boss warp grouping, boss-gated worlds, original menu art and scaling.\n";return 0;}
