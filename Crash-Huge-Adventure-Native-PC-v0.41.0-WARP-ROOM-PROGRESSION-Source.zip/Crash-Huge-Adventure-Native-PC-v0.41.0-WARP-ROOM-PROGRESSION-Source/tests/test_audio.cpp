#include "../src/gax_rom.hpp"
#include <cassert>
#include <cmath>
#include <iostream>

int main(){try{using namespace crash;
    auto rom=read("input/crash.gba");auto version=gaxVersion(rom);auto tracks=scanGaxTracks(rom);
    assert(version.find("GAX Sound Engine 2.01D")!=std::string::npos);assert(tracks.size()==19);
    size_t table=0;auto songs=parseGaxSongs(rom,&table);assert(songs.size()==19);assert(table==0x16a560);
    assert(songs[0].title=="jungle"&&songs[0].channels==4&&songs[0].patternRows==16&&songs[0].orderCount==28&&songs[0].mixRate==18158);
    assert(songs[11].title=="main menu europe"&&songs[11].channels==7&&songs[16].title=="warp room"&&songs[16].channels==7);
    assert(songs[0].dspPrimaryChannels==0&&songs[0].dspTaps[0].delayMs==0);
    assert(songs[11].dspPrimaryChannels==6&&songs[11].dspTaps[0].delayMs==25&&songs[11].dspTaps[0].gainQ4==8);
    assert(songs[13].dspPrimaryChannels==3&&songs[13].dspTaps[0].delayMs==23&&songs[13].dspTaps[0].gainQ4==8);
    assert(songs[16].dspPrimaryChannels==3&&songs[16].dspTaps[0].delayMs==20&&songs[16].dspTaps[0].gainQ4==9);
    assert(songs[17].dspPrimaryChannels==2&&songs[17].dspTaps[0].delayMs==29&&songs[17].dspTaps[0].gainQ4==8);
    auto waves=parseWaveTable(rom,songs[0].waveTablePtr,30);assert(waves.size()==30&&waves[1].length>1000&&waves[29].length>1000);
    auto musicBank=parseInstrumentBank(rom,songs[0].instrumentTablePtr,52);auto ms=gaxBankStats(musicBank);
    assert(ms.valid==52&&ms.envelopes==52&&ms.vibrato==7&&ms.multiSequence==6&&ms.loopRows==31&&ms.pingPongRows==9&&ms.sweepRows==6);
    size_t periodOff=findGaxPeriodTableOffset(rom);assert(periodOff==0x5a4300);assert(u32(rom,periodOff)==0x00105A02u&&u32(rom,periodOff+0xEF3u*4u)>0x10000000u);
    auto sfx=parseGaxSfxTable(rom,table);assert(sfx.size()==99);assert(sfx[0x46].slotId==0x3f&&sfx[0x49].slotId==0x11&&sfx[8].slotId==0x1f);assert(originalSfxId(SfxCue::Jump)==0x0d&&originalSfxId(SfxCue::Spin)==0x0a&&originalSfxId(SfxCue::Cancel)==0x49&&originalSfxId(SfxCue::Checkpoint)==0x17&&originalSfxId(SfxCue::MapNavigate)==0x48&&originalSfxId(SfxCue::MapConfirm)==0x52&&originalSfxId(SfxCue::MapOpen)==0x51&&originalSfxId(SfxCue::Shot)==0x24&&originalSfxVolumeParam(SfxCue::Shot)==0xA0&&originalSfxVoice(SfxCue::Shot)==2);
    uint32_t sfxData=findGaxSfxSongData(rom,songs[0]);assert(sfxData!=0);uint32_t sfxInstTable=gaxU32(rom,sfxData+0x10);assert(gaxPtr(rom,sfxInstTable,88*4));auto sfxBank=parseInstrumentBank(rom,sfxInstTable,88);auto ss=gaxBankStats(sfxBank);assert(ss.valid==88&&ss.envelopes==88);
    GaxLitePlayer player;assert(player.load(rom)&&player.ready());assert(player.periodTableOffset()==periodOff&&player.periodValue(0)==0x00105A02u);
    const MusicCue cues[]={MusicCue::Jungle,MusicCue::Underwater,MusicCue::Arctic,MusicCue::Sewers,MusicCue::Future,MusicCue::Rocket,MusicCue::Bonus,MusicCue::Dingodile,MusicCue::NGin,MusicCue::Tiny,MusicCue::Cortex,MusicCue::MainMenu,MusicCue::WarpRoom};
    for(auto cue:cues){player.select(cue);double energy=0;for(int i=0;i<12000;i++){double v=player.next();assert(std::isfinite(v)&&v>=-1.0&&v<=1.0);energy+=std::abs(v);}assert(energy>0.1);}
    player.select(MusicCue::Silence);for(int i=0;i<1000;i++)player.next();player.playSfx(SfxCue::MapConfirm);double fxEnergy=0;for(int i=0;i<12000;i++){double v=player.next();assert(std::isfinite(v));fxEnergy+=std::abs(v);}assert(fxEnergy>0.1);
    assert(gaxResampleContribution(127,256)==127&&gaxResampleContribution(-128,256)==-128&&gaxDownmix8(127,7)==119&&gaxDownmix8(-128,7)==-120);
    player.select(MusicCue::Silence);player.playSfx(SfxCue::Shot);double shotEnergy=0;for(int i=0;i<8000;i++)shotEnergy+=std::abs(player.next());assert(shotEnergy>0.05);
    // Exact callback path used by actor-category gameplay: arbitrary original GAX SFX IDs preserve volume/voice metadata.
    assert(player.playSfxId(0x2e));assert(player.playSfxId(0x37,48));assert(player.playSfxId(0x3e));assert(player.playSfxId(0x45));assert(player.playSfxId(0x24,0xA0,2));assert(!player.playSfxId(999));double exactFxEnergy=0;for(int i=0;i<8000;i++)exactFxEnergy+=std::abs(player.next());assert(exactFxEnergy>0.05);
    assert(levelMusic(20)==MusicCue::Dingodile&&levelMusic(21)==MusicCue::NGin&&levelMusic(22)==MusicCue::Tiny&&levelMusic(23)==MusicCue::Cortex);
    assert(levelMusic(5)==MusicCue::Arctic&&levelMusic(11)==MusicCue::Rocket&&levelMusic(17)==MusicCue::Rocket&&levelMusic(19)==MusicCue::Future);
    AudioCounters a,b;b.wumpa=1;b.crates=1;b.hazards=1;b.gems=1;b.shots=1;b.complete=true;auto d=audioDelta(a,b);assert(d.size()==6);
    std::cout<<"Audio checks passed: GAX2 2.01D, exact ROM period table, 19 songs, 52 music instruments, 88 SFX instruments, envelopes, vibrato, sequences, portamento, loop/ping-pong/sweep PCM, original-rate Q11 nearest-neighbor resample, ARM-style 16-bit accumulation/downmix, per-channel GAX echo taps, 3-voice ambient Jetpack shot, arbitrary original-ID actor callbacks and level-select SFX routing.\n";return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
