# Changelog

## 1.6.0

- Regra configurável de `published_in`: data da APR, data da exportação ou data manual.
- `reference_date` permanece sempre ligado à data da APR.
- `Export ID` registrado no SQL e no manifest.
- Novo `RESUMO_EXPORTACAO.txt` em cada pacote.
- Novo `CHECKSUMS.sha256` para prova de integridade dos arquivos gerados.
- Novo botão **Verificar pacote** na interface.
- CSV, HTML e manifest registram `reference_date_sql` e `published_in_sql` separadamente.
- CLI ganhou opções de `published_in` e verificação automática dos checksums.
- Testes de integridade e adulteração do pacote adicionados.

## 1.5.0

Revisão de segurança baseada na auditoria do fluxo 1.4.0: perfis atômicos e recuperação de corrupção, exportações isoladas, SQL idempotente, histórico GERADO/CONFIRMADO, CNPJ obrigatório/aprendizado confirmado, parser de APR endurecido, thread/UI segura, RapidOCR 3.x, fallback pypdfium2, cache, rechecagem de hash, exportação apenas das válidas, persistência de exclusão de perfis, proteção CSV, logs, LOCALAPPDATA e build mais robusto.
