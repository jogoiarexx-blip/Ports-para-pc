# APR Manager 1.6.0

Aplicativo Windows para validar lotes de APR, conferir a empresa/RPPS e gerar com segurança os arquivos usados na publicação na tabela `transparencies`.

## O que mudou na v1.6.0

A v1.6.0 adiciona uma etapa de **pré-publicação auditável** e resolve a dúvida de negócio do campo `published_in` sem alterar `reference_date`.

- Nova configuração visual de `published_in` antes da exportação:
  - **Mesma data da APR** (compatibilidade com o fluxo anterior);
  - **Data da exportação**;
  - **Data manual** escolhida no calendário.
- `reference_date` continua sempre baseado na data encontrada na APR.
- O SQL registra no cabeçalho a regra usada em `published_in`, a versão do aplicativo e o `Export ID`.
- Cada pacote agora inclui `RESUMO_EXPORTACAO.txt` com empresa, IDs, CNPJ, totais, quantidade incluída no SQL e regra de `published_in`.
- Cada pacote inclui `CHECKSUMS.sha256` com o SHA-256 dos arquivos gerados.
- Novo botão **Verificar pacote**, que recalcula os hashes e detecta alteração, corrupção ou ausência de arquivo depois da exportação.
- `manifest_apr.json`, CSV e HTML passam a registrar separadamente `reference_date_sql` e `published_in_sql`.
- A CLI ganhou `--published-in apr|export|manual` e `--published-in-date`.
- A CLI verifica automaticamente a integridade do pacote gerado antes de finalizar.
- Testes automatizados ampliados para cobrir as três políticas de `published_in`, geração de checksums e detecção de adulteração do pacote.

## Fluxo recomendado

1. Selecione a empresa.
2. Confira o `company_id` automático.
3. Informe ou ajuste `user_id` e `transparency_type_detail_id`.
4. Adicione os PDFs e clique em **Validar tudo**.
5. Confira CNPJ, Nº/ANO, data, unidade, OCR, histórico e mensagens.
6. Escolha a regra de `published_in`:
   - **Mesma data da APR** se esse for o comportamento esperado pelo portal;
   - **Data da exportação** se `published_in` representar a publicação;
   - **Data manual** quando precisar informar uma data específica.
7. Clique em **Gerar SQL + relatórios**.
8. Abra o pacote e confira `RESUMO_EXPORTACAO.txt`.
9. Use **Verificar pacote** para conferir os hashes SHA-256.
10. Execute o SQL no banco.
11. Somente depois do sucesso, clique em **Confirmar SQL executado**.

## Arquivos gerados

Cada exportação cria uma pasta exclusiva, por exemplo:

```text
2026-09-26_121500_PITANPREV/
```

Ela pode conter:

- `inserts_transparencies.sql`
- `relatorio_apr.csv`
- `relatorio_apr.html`
- `manifest_apr.json`
- `RESUMO_EXPORTACAO.txt`
- `CHECKSUMS.sha256`

Se houver erros e **SQL apenas das válidas** não estiver selecionado, os relatórios e o resumo continuam sendo gerados, mas o SQL fica bloqueado.

## Segurança do SQL

O SQL usa `START TRANSACTION` / `COMMIT` e `INSERT ... SELECT ... WHERE NOT EXISTS` com:

```text
company_id
+ transparency_type_detail_id
+ slug
+ deleted_at IS NULL
```

Isso reduz o risco de duplicar a APR quando o mesmo SQL é executado novamente. Se o banco tiver outra regra de unicidade, ajuste esse critério antes do uso definitivo.

## `reference_date` e `published_in`

A partir da v1.6.0 os campos são tratados separadamente:

- `reference_date`: sempre a **data da APR**;
- `published_in`: definido no momento da exportação.

O modo padrão continua sendo **Mesma data da APR**, para preservar compatibilidade com o comportamento original do projeto.

## Integridade do pacote

`CHECKSUMS.sha256` contém o SHA-256 dos arquivos gerados. O botão **Verificar pacote** confere esses valores novamente.

Se alguém editar o SQL, CSV, HTML, manifest ou resumo depois da exportação, a verificação acusa **hash divergente**. Se um arquivo for apagado, acusa **arquivo ausente**.

## Perfis, histórico e OCR

As proteções da v1.5.0 continuam presentes:

- perfis salvos atomicamente e recuperação de JSON corrompido;
- CNPJ obrigatório/confirmado antes de liberar SQL;
- histórico `GERADO` e `CONFIRMADO`;
- SQL apenas das válidas;
- rechecagem de tamanho, `mtime` e SHA-256 do PDF antes da exportação;
- OCR local com RapidOCR 3.x;
- fallback de extração com `pypdfium2`;
- cache de validação;
- logs rotativos em `%LOCALAPPDATA%\APRManager\logs`.

## Executar no Windows

Dê duplo clique em:

```text
executar.bat
```

O instalador de dependências prefere Python 3.12 e interrompe corretamente se o `pip` falhar.

## Criar o EXE

```powershell
powershell -ExecutionPolicy Bypass -File .\build_windows.ps1
```

O executável é criado em `dist\APR Manager\APR Manager.exe`. Se o Inno Setup estiver disponível, o instalador também é criado.

## Linha de comando

Perfil salvo:

```bat
python gerar_inserts_apr.py .\apr --profile-id 5
```

Usando a data da exportação em `published_in`:

```bat
python gerar_inserts_apr.py .\apr --profile-id 5 --published-in export
```

Data manual:

```bat
python gerar_inserts_apr.py .\apr --profile-id 5 --published-in manual --published-in-date 26/09/2026
```

## Limites atuais

- A confirmação da execução do SQL ainda é manual; o aplicativo não consulta o banco.
- Não há upload FTP/SFTP automático nesta etapa.
- Não há assinatura digital de código incluída; isso depende de certificado do publicador.
- O aplicativo ainda não altera dados reconhecidos manualmente dentro da APR; essa é uma evolução futura planejada.
