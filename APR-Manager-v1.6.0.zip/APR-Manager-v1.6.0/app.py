from __future__ import annotations

import sys

from PySide6.QtWidgets import QApplication

from core.logging_setup import install_excepthook, setup_logging
from core.version import APP_NAME, APP_VERSION
from ui.main_window import MainWindow
from ui.theme import APP_STYLESHEET


def main() -> int:
    setup_logging()
    install_excepthook()
    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setApplicationVersion(APP_VERSION)
    app.setOrganizationName(APP_NAME)
    app.setStyleSheet(APP_STYLESHEET)
    window = MainWindow()
    window.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
