from __future__ import annotations

import importlib.util
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable


@dataclass
class OCRPageResult:
    page_number: int
    text: str
    confidence: float


@dataclass
class OCRResult:
    text: str
    confidence: float
    provider: str
    pages: list[OCRPageResult] = field(default_factory=list)
    truncated: bool = False


class OCRUnavailable(RuntimeError):
    """OCR opcional não está disponível nesta instalação."""


class OCRCancelled(RuntimeError):
    """OCR cancelado pelo usuário."""


_ENGINE = None


def ocr_available() -> tuple[bool, str]:
    """Verificação leve: não importa onnxruntime/engine na thread da interface."""
    missing = []
    for module in ("pypdfium2", "rapidocr"):
        if importlib.util.find_spec(module) is None:
            missing.append(module)
    if missing:
        return False, "faltando: " + ", ".join(missing)
    return True, "RapidOCR 3.x"


def _get_engine():
    global _ENGINE
    if _ENGINE is None:
        try:
            from rapidocr import RapidOCR
        except Exception as exc:  # pragma: no cover - depende do ambiente
            raise OCRUnavailable(
                "RapidOCR não está instalado. Instale as dependências de OCR do APR Manager."
            ) from exc
        _ENGINE = RapidOCR()
    return _ENGINE


def _parse_rapidocr_result(result) -> tuple[str, float]:
    """Aceita saídas do RapidOCR 3.x e formatos antigos usados nos testes."""
    if result is None:
        return "", 0.0

    # RapidOCR 3.x: objeto com txts/scores.
    txts = getattr(result, "txts", None)
    scores = getattr(result, "scores", None)
    if txts is not None:
        texts = [str(x).strip() for x in list(txts or [])]
        score_values = list(scores or [])
        lines: list[str] = []
        weighted = 0.0
        weight_total = 0
        for idx, text in enumerate(texts):
            if not text:
                continue
            try:
                score = float(score_values[idx]) if idx < len(score_values) else 0.0
            except Exception:
                score = 0.0
            lines.append(text)
            weight = max(1, len(text))
            weighted += max(0.0, min(1.0, score)) * weight
            weight_total += weight
        return "\n".join(lines), (weighted / weight_total if weight_total else 0.0)

    # Alguns releases retornam (output, elapsed) ou lista direta.
    if isinstance(result, tuple) and len(result) == 2 and not isinstance(result[0], (str, bytes)):
        first = result[0]
        if first is not result:
            parsed = _parse_rapidocr_result(first)
            if parsed[0] or parsed[1]:
                return parsed

    if not isinstance(result, (list, tuple)):
        return "", 0.0

    lines: list[str] = []
    weighted = 0.0
    weight_total = 0
    for item in result:
        try:
            text = str(item[1]).strip()
            score = float(item[2])
        except Exception:
            continue
        if not text:
            continue
        lines.append(text)
        weight = max(1, len(text))
        weighted += max(0.0, min(1.0, score)) * weight
        weight_total += weight

    return "\n".join(lines), (weighted / weight_total if weight_total else 0.0)


def extract_text_with_ocr(
    pdf_path: Path,
    *,
    scale: float = 2.4,
    max_pages: int | None = None,
    cancel_check: Callable[[], bool] | None = None,
) -> OCRResult:
    """Renderiza páginas e aplica OCR local.

    Por padrão não corta páginas. Se max_pages for explicitamente informado, o
    resultado informa `truncated=True`, de modo que a validação não silencie o corte.
    """
    try:
        import pypdfium2 as pdfium
    except Exception as exc:  # pragma: no cover - depende do ambiente
        raise OCRUnavailable(
            "pypdfium2 não está instalado. Instale as dependências de OCR do APR Manager."
        ) from exc

    engine = _get_engine()
    pages: list[OCRPageResult] = []
    pdf = None
    truncated = False
    try:
        pdf = pdfium.PdfDocument(str(pdf_path))
        total = len(pdf)
        count = total if max_pages is None else min(total, max_pages)
        truncated = max_pages is not None and total > count
        for index in range(count):
            if cancel_check and cancel_check():
                raise OCRCancelled("OCR cancelado")
            page = pdf[index]
            try:
                bitmap = page.render(scale=scale)
                try:
                    image = bitmap.to_numpy()
                except Exception:
                    image = bitmap.to_pil()
                raw = engine(image)
                text, confidence = _parse_rapidocr_result(raw)
                pages.append(OCRPageResult(index + 1, text, confidence))
            finally:
                try:
                    page.close()
                except Exception:
                    pass
    except (OCRUnavailable, OCRCancelled):
        raise
    except Exception as exc:
        raise RuntimeError(f"falha no OCR local: {exc}") from exc
    finally:
        if pdf is not None:
            try:
                pdf.close()
            except Exception:
                pass

    useful_pages = [p for p in pages if p.text.strip()]
    combined = "\n\n".join(p.text for p in useful_pages)
    weights = [max(1, len(p.text)) for p in useful_pages]
    confidence = (
        sum(p.confidence * w for p, w in zip(useful_pages, weights)) / sum(weights)
        if weights else 0.0
    )

    return OCRResult(
        text=combined,
        confidence=confidence,
        provider="RapidOCR 3.x",
        pages=pages,
        truncated=truncated,
    )
