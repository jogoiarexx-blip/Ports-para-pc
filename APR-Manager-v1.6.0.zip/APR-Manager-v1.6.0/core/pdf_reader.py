from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from pypdf import PdfReader

from .ocr import OCRCancelled, OCRUnavailable, extract_text_with_ocr


@dataclass
class PDFContent:
    text: str
    page_count: int
    probably_scanned: bool
    text_source: str = "PDF"
    ocr_used: bool = False
    ocr_provider: str = ""
    ocr_confidence: float = 0.0
    ocr_error: str = ""
    ocr_truncated: bool = False


class ExtractionCancelled(RuntimeError):
    pass


def _is_low_text(text: str, minimum_alnum: int = 80) -> bool:
    useful = "".join(ch for ch in text if ch.isalnum())
    return len(useful) < minimum_alnum


def _looks_structurally_weak(text: str) -> bool:
    """Detecta camada de texto longa, porém inútil/ruim de scanner."""
    up = re.sub(r"\s+", " ", text.upper())
    markers = [
        re.search(r"\bAPR\b", up) is not None,
        "UNIDADE GESTORA" in up,
        re.search(r"\bN\s*[º°O]?\s*/\s*ANO\b", up) is not None,
        re.search(r"\bDATA(?:\s+DA\s+OPERA[ÇC][ÃA]O)?\s*:", up) is not None,
    ]
    return sum(markers) < 2


def _extract_pdfium_text(pdf_path: Path, cancel_check: Callable[[], bool] | None = None) -> tuple[str, int]:
    try:
        import pypdfium2 as pdfium
    except Exception:
        return "", 0
    pdf = None
    parts: list[str] = []
    try:
        pdf = pdfium.PdfDocument(str(pdf_path))
        for idx in range(len(pdf)):
            if cancel_check and cancel_check():
                raise ExtractionCancelled("extração cancelada")
            page = pdf[idx]
            textpage = None
            try:
                textpage = page.get_textpage()
                parts.append(textpage.get_text_range() or "")
            except Exception:
                parts.append("")
            finally:
                try:
                    if textpage is not None:
                        textpage.close()
                except Exception:
                    pass
                try:
                    page.close()
                except Exception:
                    pass
        return "\n".join(parts), len(pdf)
    finally:
        if pdf is not None:
            try:
                pdf.close()
            except Exception:
                pass


def extract_pdf_content(
    pdf_path: Path,
    *,
    enable_ocr: bool = True,
    cancel_check: Callable[[], bool] | None = None,
) -> PDFContent:
    if cancel_check and cancel_check():
        raise ExtractionCancelled("extração cancelada")

    page_count = 0
    pypdf_parts: list[str] = []
    pypdf_failed_pages = 0
    pypdf_error = ""
    try:
        reader = PdfReader(str(pdf_path), strict=False)
        if reader.is_encrypted:
            try:
                result = reader.decrypt("")
                if result == 0:
                    raise ValueError("PDF protegido por senha")
            except Exception as exc:
                raise ValueError("PDF protegido por senha; não foi possível ler o conteúdo") from exc

        page_count = len(reader.pages)
        for page_no, page in enumerate(reader.pages, start=1):
            if cancel_check and cancel_check():
                raise ExtractionCancelled("extração cancelada")
            try:
                pypdf_parts.append(page.extract_text() or "")
            except Exception as exc:
                pypdf_failed_pages += 1
                pypdf_parts.append("")
                pypdf_error = f"pypdf falhou na página {page_no}: {exc}"
    except ExtractionCancelled:
        raise
    except Exception as exc:
        # Se o pypdf falhar no documento, ainda tentamos o extrator do pdfium.
        pypdf_error = str(exc)

    pypdf_text = "\n".join(pypdf_parts)
    text = pypdf_text
    source = "PDF"

    need_pdfium = not text.strip() or pypdf_failed_pages > 0 or _looks_structurally_weak(text)
    if need_pdfium:
        try:
            pdfium_text, pdfium_pages = _extract_pdfium_text(pdf_path, cancel_check)
        except ExtractionCancelled:
            raise
        if pdfium_text and (len(pdfium_text.strip()) > len(text.strip()) or _looks_structurally_weak(text)):
            text = pdfium_text
            source = "PDFium"
            page_count = page_count or pdfium_pages

    scanned = _is_low_text(text) or _looks_structurally_weak(text)
    content = PDFContent(text=text, page_count=page_count, probably_scanned=scanned, text_source=source)

    if scanned and enable_ocr:
        try:
            ocr = extract_text_with_ocr(pdf_path, cancel_check=cancel_check)
            content.ocr_used = True
            content.ocr_provider = ocr.provider
            content.ocr_confidence = ocr.confidence
            content.ocr_truncated = ocr.truncated
            if not _is_low_text(ocr.text) and not _looks_structurally_weak(ocr.text):
                content.text = ocr.text
                content.probably_scanned = False
                content.text_source = "OCR"
            else:
                content.ocr_error = "OCR executado, mas não encontrou texto estruturado suficiente"
        except OCRCancelled as exc:
            raise ExtractionCancelled(str(exc)) from exc
        except OCRUnavailable as exc:
            content.ocr_error = str(exc)
        except Exception as exc:
            content.ocr_error = str(exc)

    if not content.text.strip() and pypdf_error and not content.ocr_error:
        content.ocr_error = pypdf_error
    return content
