from __future__ import annotations

import json
import os
from datetime import datetime
from pathlib import Path

from .company_catalog import CatalogCompany, company_catalog
from .models import CompanyProfile
from .utils import atomic_write_text

APP_DIR_NAME = "APRManager"
PROFILE_FORMAT_VERSION = 2
_LAST_LOAD_WARNING = ""
_DELETED_CATALOG_IDS: set[str] = set()


def app_data_dir() -> Path:
    """Configuração que pode acompanhar o usuário no Windows (Roaming)."""
    if os.name == "nt":
        base = Path(os.getenv("APPDATA") or Path.home())
    else:
        base = Path(os.getenv("XDG_CONFIG_HOME") or (Path.home() / ".config"))
    path = base / APP_DIR_NAME
    path.mkdir(parents=True, exist_ok=True)
    return path


def local_app_data_dir() -> Path:
    """Dados locais/cache/histórico que não devem ir para Roaming."""
    if os.name == "nt":
        base = Path(os.getenv("LOCALAPPDATA") or os.getenv("APPDATA") or Path.home())
    else:
        base = Path(os.getenv("XDG_STATE_HOME") or (Path.home() / ".local" / "state"))
    path = base / APP_DIR_NAME
    path.mkdir(parents=True, exist_ok=True)
    return path


def profiles_path() -> Path:
    return app_data_dir() / "profiles.json"


def pop_profile_load_warning() -> str:
    global _LAST_LOAD_WARNING
    value = _LAST_LOAD_WARNING
    _LAST_LOAD_WARNING = ""
    return value


def profile_from_catalog(company: CatalogCompany) -> CompanyProfile:
    unit = company.db_name if company.db_name and "..." not in company.db_name else company.display_name
    return CompanyProfile(
        name=company.display_name,
        company_id=company.company_id,
        user_id="",
        transparency_type_detail_id="",
        unit_name=unit,
        catalog_db_name=company.db_name,
        catalog_sub_title=company.sub_title,
    )


def merge_catalog_profiles(
    profiles: list[CompanyProfile], deleted_catalog_ids: set[str] | None = None
) -> tuple[list[CompanyProfile], bool]:
    deleted_catalog_ids = deleted_catalog_ids or set()
    merged = list(profiles)
    known_ids = {p.company_id for p in merged if p.company_id}
    changed = False
    for company in company_catalog():
        if company.company_id in deleted_catalog_ids:
            continue
        if company.company_id not in known_ids:
            merged.append(profile_from_catalog(company))
            known_ids.add(company.company_id)
            changed = True
    merged.sort(key=lambda p: (int(p.company_id) if p.company_id.isdigit() else 10**9, p.name.casefold()))
    return merged, changed


def _parse_profile_payload(data) -> tuple[list[CompanyProfile], set[str]]:
    # Compatibilidade com v1.0-v1.4: profiles.json era uma lista simples.
    if isinstance(data, list):
        return [CompanyProfile.from_dict(item) for item in data if isinstance(item, dict)], set()
    if not isinstance(data, dict):
        raise ValueError("formato raiz do profiles.json inválido")
    raw_profiles = data.get("profiles", [])
    raw_deleted = data.get("deleted_catalog_company_ids", [])
    if not isinstance(raw_profiles, list) or not isinstance(raw_deleted, list):
        raise ValueError("estrutura do profiles.json inválida")
    profiles = [CompanyProfile.from_dict(item) for item in raw_profiles if isinstance(item, dict)]
    deleted = {str(x).strip() for x in raw_deleted if str(x).strip()}
    return profiles, deleted


def load_profiles() -> list[CompanyProfile]:
    global _LAST_LOAD_WARNING, _DELETED_CATALOG_IDS
    path = profiles_path()
    profiles: list[CompanyProfile] = []
    deleted: set[str] = set()
    existed = path.exists()

    if existed:
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            profiles, deleted = _parse_profile_payload(data)
        except Exception as exc:
            stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
            corrupt = path.with_name(f"{path.stem}.corrupt-{stamp}{path.suffix}")
            try:
                path.replace(corrupt)
                _LAST_LOAD_WARNING = (
                    "O arquivo de perfis estava corrompido e NÃO foi sobrescrito. "
                    f"Uma cópia foi preservada em:\n{corrupt}\n\nDetalhe: {exc}"
                )
            except OSError as rename_exc:
                _LAST_LOAD_WARNING = (
                    "O arquivo de perfis parece corrompido. O APR Manager não conseguiu movê-lo para backup, "
                    "portanto não gravou um novo profiles.json automaticamente.\n\n"
                    f"Arquivo: {path}\nErro original: {exc}\nErro ao criar backup: {rename_exc}"
                )
                # Não salvar automaticamente por cima do arquivo danificado.
                profiles, deleted = [], set()
                _DELETED_CATALOG_IDS = deleted
                merged, _ = merge_catalog_profiles(profiles, deleted)
                return merged
            profiles, deleted = [], set()
            existed = False

    _DELETED_CATALOG_IDS = set(deleted)
    profiles, changed = merge_catalog_profiles(profiles, _DELETED_CATALOG_IDS)
    if changed or not existed:
        try:
            save_profiles(profiles)
        except OSError:
            pass
    return profiles


def save_profiles(profiles: list[CompanyProfile]) -> None:
    payload = {
        "format_version": PROFILE_FORMAT_VERSION,
        "profiles": [p.to_dict() for p in profiles],
        "deleted_catalog_company_ids": sorted(_DELETED_CATALOG_IDS, key=lambda x: int(x) if x.isdigit() else 10**9),
    }
    atomic_write_text(profiles_path(), json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def mark_catalog_company_deleted(company_id: str) -> None:
    company_id = str(company_id).strip()
    if any(c.company_id == company_id for c in company_catalog()):
        _DELETED_CATALOG_IDS.add(company_id)


def restore_catalog_company(company_id: str) -> None:
    _DELETED_CATALOG_IDS.discard(str(company_id).strip())
