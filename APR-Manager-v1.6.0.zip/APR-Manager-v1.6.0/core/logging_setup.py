from __future__ import annotations

import logging
import sys
import traceback
from logging.handlers import RotatingFileHandler

from .profiles import local_app_data_dir


def setup_logging() -> logging.Logger:
    log_dir = local_app_data_dir() / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger("apr_manager")
    logger.setLevel(logging.INFO)
    if not logger.handlers:
        handler = RotatingFileHandler(
            log_dir / "apr-manager.log", maxBytes=2_000_000, backupCount=4, encoding="utf-8"
        )
        handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s"))
        logger.addHandler(handler)
    return logger


def install_excepthook() -> None:
    logger = setup_logging()

    def hook(exc_type, exc_value, exc_tb):
        if issubclass(exc_type, KeyboardInterrupt):
            sys.__excepthook__(exc_type, exc_value, exc_tb)
            return
        detail = "".join(traceback.format_exception(exc_type, exc_value, exc_tb))
        logger.critical("Exceção não tratada:\n%s", detail)
        try:
            from PySide6.QtWidgets import QApplication, QMessageBox
            if QApplication.instance() is not None:
                QMessageBox.critical(
                    None,
                    "Erro inesperado",
                    "O APR Manager encontrou um erro inesperado. Um log foi salvo em:\n"
                    f"{local_app_data_dir() / 'logs' / 'apr-manager.log'}",
                )
        except Exception:
            pass

    sys.excepthook = hook
