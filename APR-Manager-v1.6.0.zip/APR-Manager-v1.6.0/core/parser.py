from __future__ import annotations

import re
from datetime import datetime
from pathlib import Path
from typing import Iterable, Optional

from .models import ParsedNumber
from .utils import normalize_cnpj


FULL_DATE_RE = re.compile(r"(?<!\d)(\d{1,2})\s*[./-]\s*(\d{1,2})\s*[./-]\s*(\d{2,4})(?!\d)")
PAIR_RE = re.compile(r"(?<!\d)(?P<num>\d{1,6})\s*[.\-_/]\s*(?P<year>\d{2}|\d{4})(?!\d)")

# Padrões fortes: trazem contexto específico de APR/Nº-ANO.
PDF_NUMBER_STRONG_PATTERNS = [
    re.compile(r"\bN\s*[º°oO]?\s*/\s*ANO\s*[:\-]?\s*(\d{1,6})\s*/\s*(\d{2,4})\b", re.I),
    re.compile(r"\bN\s*[º°oO]?\s*ANO\s*[:\-]?\s*(\d{1,6})\s*/\s*(\d{2,4})\b", re.I),
    re.compile(r"\bAPR\s*N\s*[º°oO]?\s*[:\-]?\s*(\d{1,6})\s*(?:/|DE)\s*(\d{2,4})\b", re.I),
]
# Fallback deliberadamente mais fraco. Só é usado se nenhum padrão forte casar.
PDF_NUMBER_FALLBACK_RE = re.compile(
    r"\bN\s*[º°oO]?\s*[:\-]?\s*(\d{1,6})\s*/\s*(\d{2,4})\b", re.I
)
POLICY_LINE_RE = re.compile(
    r"\b(?:RESOLU[ÇC][ÃA]O|PORTARIA|DECRETO|LEI|MPS|CMN|ART(?:IGO)?\.?|INSTRU[ÇC][ÃA]O)\b", re.I
)

DATE_OPERATION_RE = re.compile(
    r"\bDATA\s+DA\s+(?:OPERA[ÇC][ÃA]O|MOVIMENTA[ÇC][ÃA]O)\s*[:\-]?\s*(\d{1,2})\s*/\s*(\d{1,2})\s*/\s*(\d{4})\b",
    re.I,
)
DATE_APR_RE = re.compile(
    r"\bDATA\s*(?:DA\s+APR\s*)?[:\-]?\s*(\d{1,2})\s*/\s*(\d{1,2})\s*/\s*(\d{4})\b",
    re.I,
)

CNPJ_RE = re.compile(r"\b\d{2}\.\d{3}\.\d{3}/\d{4}-\d{2}\b")
AMOUNT_RE = re.compile(r"VALOR\s*\(R\$\)\s*[:\-]?\s*([\d\.]+,\d{2})", re.I)
OPERATION_RE = re.compile(
    r"TIPO\s+DE\s+OPERA[ÇC][ÃA]O\s*[:\-]?\s*(.+?)(?=\s+(?:Dispositivos|Enquadramento|HIST[ÓO]RICO|DESCRI[ÇC][ÃA]O)\b|[\n\r]|$)",
    re.I | re.S,
)
# Limita a captura a uma linha/trecho curto, evitando engolir parágrafos quando o CNPJ não vem logo depois.
UNIT_RE = re.compile(r"Unidade\s+gestora\s+do\s+RPPS\s*:\s*([^\n\r]{1,200})", re.I)


def normalize_year4(year: str) -> int:
    year = year.strip()
    y = int(year)
    if len(year) == 2:
        return 2000 + y if y <= 79 else 1900 + y
    return y


def make_number(num: str, year: str) -> ParsedNumber:
    return ParsedNumber(num_raw=num.strip(), year_raw=year.strip(), num_int=int(num), year4=normalize_year4(year))


def _unique_numbers(values: Iterable[ParsedNumber]) -> list[ParsedNumber]:
    out: list[ParsedNumber] = []
    seen: set[str] = set()
    for value in values:
        if value.canonical not in seen:
            seen.add(value.canonical)
            out.append(value)
    return out


def numbers_from_filename(pdf_path: Path) -> list[ParsedNumber]:
    stem = pdf_path.stem
    date_spans = [m.span() for m in FULL_DATE_RE.finditer(stem)]
    results: list[ParsedNumber] = []

    for m in PAIR_RE.finditer(stem):
        span = m.span()
        if any(span[0] >= d0 and span[1] <= d1 for d0, d1 in date_spans):
            continue
        try:
            candidate = make_number(m.group("num"), m.group("year"))
        except ValueError:
            continue
        if 1900 <= candidate.year4 <= 2199:
            results.append(candidate)

    return _unique_numbers(results)


def _numbers_from_patterns(text: str, patterns: list[re.Pattern[str]]) -> list[ParsedNumber]:
    found: list[ParsedNumber] = []
    for pat in patterns:
        for m in pat.finditer(text):
            try:
                candidate = make_number(m.group(1), m.group(2))
            except ValueError:
                continue
            if 1900 <= candidate.year4 <= 2199:
                found.append(candidate)
    return _unique_numbers(found)


def numbers_from_pdf(text: str) -> list[ParsedNumber]:
    compact = re.sub(r"[\t\r]+", " ", text)
    strong = _numbers_from_patterns(compact, PDF_NUMBER_STRONG_PATTERNS)
    if strong:
        return strong

    # Último recurso: procura Nº: 52/26, mas ignora linhas de legislação/resoluções.
    found: list[ParsedNumber] = []
    for line in text.splitlines():
        if POLICY_LINE_RE.search(line):
            continue
        for m in PDF_NUMBER_FALLBACK_RE.finditer(line):
            try:
                candidate = make_number(m.group(1), m.group(2))
            except ValueError:
                continue
            if 1900 <= candidate.year4 <= 2199:
                found.append(candidate)
    return _unique_numbers(found)


def _dates_for_pattern(text: str, pattern: re.Pattern[str]) -> list[datetime]:
    found: list[datetime] = []
    seen: set[str] = set()
    for m in pattern.finditer(text):
        d, mo, y = map(int, m.groups())
        try:
            value = datetime(y, mo, d)
        except ValueError:
            continue
        key = value.strftime("%Y-%m-%d")
        if key not in seen:
            seen.add(key)
            found.append(value)
    return found


def dates_from_pdf(text: str) -> list[datetime]:
    compact = re.sub(r"[\t\r]+", " ", text)
    operation_dates = _dates_for_pattern(compact, DATE_OPERATION_RE)
    if operation_dates:
        return operation_dates
    return _dates_for_pattern(compact, DATE_APR_RE)


def extract_cnpj(text: str) -> str:
    """Extrai preferencialmente o CNPJ associado à Unidade gestora do RPPS."""
    unit_anchor = re.search(r"Unidade\s+gestora\s+do\s+RPPS", text, re.I)
    if unit_anchor:
        window = text[unit_anchor.start(): unit_anchor.start() + 1800]
        explicit = re.search(r"CNPJ\s*:?\s*(\d{2}\.\d{3}\.\d{3}/\d{4}-\d{2})", window, re.I)
        if explicit:
            return normalize_cnpj(explicit.group(1))
        nearby = CNPJ_RE.search(window)
        if nearby:
            return normalize_cnpj(nearby.group(0))

    head = text[: max(3000, len(text) // 3)]
    matches = list(CNPJ_RE.finditer(head)) or list(CNPJ_RE.finditer(text))
    return normalize_cnpj(matches[0].group(0)) if matches else ""


def extract_unit_name(text: str) -> str:
    anchor = re.search(r"Unidade\s+gestora\s+do\s+RPPS\s*:\s*", text, re.I)
    if not anchor:
        return ""
    # Janela curta e no máximo duas linhas: aceita cabeçalho quebrado em PDF sem
    # engolir o restante do documento quando o CNPJ não vem imediatamente.
    window = text[anchor.end(): anchor.end() + 260]
    window = re.split(r"\bCNPJ\s*:", window, maxsplit=1, flags=re.I)[0]
    lines = [re.sub(r"\s+", " ", line).strip(" :-\t") for line in window.splitlines()]
    parts: list[str] = []
    for line in lines:
        if not line:
            continue
        if parts and re.match(r"^[A-ZÁÉÍÓÚÂÊÔÃÕÇ][^:]{0,50}:$", line):
            break
        parts.append(line)
        if len(parts) >= 2:
            break
    return " ".join(parts).strip()[:200]


def extract_amount(text: str) -> str:
    m = AMOUNT_RE.search(text)
    return m.group(1).strip() if m else ""


def extract_operation_type(text: str) -> str:
    m = OPERATION_RE.search(text)
    if not m:
        return ""
    return re.sub(r"\s+", " ", m.group(1)).strip()


def document_signature_score(text: str) -> int:
    up = re.sub(r"\s+", " ", text.upper())
    checks = [
        "AUTORIZAÇÃO DE APLICAÇÃO" in up or "AUTORIZACAO DE APLICACAO" in up,
        re.search(r"\bAPR\b", up) is not None,
        "UNIDADE GESTORA DO RPPS" in up,
        "Nº / ANO" in up or "N° / ANO" in up or "N / ANO" in up,
        "TIPO DE OPERAÇÃO" in up or "TIPO DE OPERACAO" in up,
    ]
    return sum(1 for x in checks if x)


def choose_filename_number(
    candidates: list[ParsedNumber], pdf_number: Optional[ParsedNumber]
) -> tuple[Optional[ParsedNumber], list[str], list[str]]:
    warnings: list[str] = []
    errors: list[str] = []
    if not candidates:
        return None, warnings, errors
    if len(candidates) == 1:
        return candidates[0], warnings, errors
    if pdf_number:
        matches = [c for c in candidates if c.canonical == pdf_number.canonical]
        if len(matches) == 1:
            warnings.append("nome do arquivo contém mais de um Nº/ANO possível; foi escolhido o que coincide com o PDF")
            return matches[0], warnings, errors
    errors.append("nome do arquivo contém mais de um Nº/ANO possível e não foi possível decidir com segurança")
    return None, warnings, errors
