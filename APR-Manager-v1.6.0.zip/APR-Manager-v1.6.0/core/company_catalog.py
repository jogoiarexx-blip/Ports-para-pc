from __future__ import annotations

from dataclasses import asdict, dataclass


@dataclass(frozen=True)
class CatalogCompany:
    company_id: str
    display_name: str
    preview: str = ""
    db_name: str = ""
    sub_title: str = ""

    def to_dict(self) -> dict[str, str]:
        return asdict(self)


# Catálogo importado da tabela `companies` fornecida pelo usuário.
# Quando o texto da captura estava truncado, preservamos o trecho visível em db_name
# e usamos preview/sub_title como nome de exibição quando isso era mais claro.
COMPANY_CATALOG: tuple[CatalogCompany, ...] = (
    CatalogCompany("1", "teste 3", "", "teste 3", ""),
    CatalogCompany("2", "São João Prev", "É o responsável pela concessão e manutenção de ben...", "São João Prev", ""),
    CatalogCompany("3", "BiriguiPrev", "É o responsável pela concessão e manutenção de ben...", "BiriguiPrev", "Regime Próprio de Previdência Social de Birigui"),
    CatalogCompany("4", "NaviraíPrev", "A NAVIRAÍPREV é o responsável pela concessão e man...", "NaviraíPrev", ""),
    CatalogCompany("5", "PITANPREV", "O PITANPREV tem por finalidade assegurar aos seus ...", "PITANPREV", "PITANPREV"),
    CatalogCompany("6", "IPA", "IPA", "IPA - INSTITUTO DE PREVIDÊNCIA DOS SERVIDORES MUNI...", "IPA"),
    CatalogCompany("7", "PinheiralPrevi", "Órgão responsável pela concessão e manutenção de b...", "Fundo de Previdência Social do Município de Pinhei...", "PinheiralPrevi"),
    CatalogCompany("8", "PREVIGARAPAVA", "PREVIGARAPAVA - INSTITUTO DE PREVIDÊNCIA MUNICIPAL...", "PREVIGARAPAVA", "PREVIGARAPAVA"),
    CatalogCompany("9", "PREVIPORÃ", "PREVIPORÃ - Instituto de Previdência dos Servidore...", "PREVIPORÃ", "PREVIPORÃ"),
    CatalogCompany("10", "IPREMO", "Ipremo", "Ipremo", "IPREMO"),
    CatalogCompany("11", "IPMO", "IPMO - Ourinhos", "IPMO - Instituto de Previdência dos Servidores Púb...", "IPMO"),
    CatalogCompany("12", "IMSS", "IMSS - INSTITUTO MUNICIPAL DE SEGURIDADE SOCIAL DE...", "IMSS - INSTITUTO MUNICIPAL DE SEGURIDADE SOCIAL DE...", "IMSS"),
    CatalogCompany("15", "IMP", "O IMP é o responsável pela concessão e manutenção ...", "IMP - INSTITUTO MUNICIPAL DE PREVIDÊNCIA", "IMP"),
    CatalogCompany("16", "FUNPREVMAR", "Criado em 13/08/1993, por meio da Lei Municipal 1....", "PREVMMAR", "FUNPREVMAR"),
    CatalogCompany("17", "Câmara Municipal de Morro Agudo-SP", "Câmara Municipal de Morro Agudo-SP", "Câmara Municipal de Morro Agudo-SP", ""),
    CatalogCompany("19", "PREVBOMJESUS", "Prev Bom Jesus", "PREVBOMJESUS", "PREVBOMJESUS"),
    CatalogCompany("20", "IPSEMP", "", "IPSEMP - Instituto de Previdência Social do Municí...", "IPSEMP"),
    CatalogCompany("21", "Previna", "PREVINA", "Previna", "Previna"),
    CatalogCompany("22", "Previpar", "Previpar", "Previpar", "Previpar"),
    CatalogCompany("23", "Prev Brilhante", "Estimado servidor! Aqui você encontra os principa...", "Prev Brilhante", "Prev Brilhante"),
    CatalogCompany("24", "JUSSARAPREV", "JUSSARAPREV", "JUSSARAPREV", "JUSSARAPREV"),
    CatalogCompany("25", "Aquidauana Prev", "Aquidauana Prev", "AQUIDAUANA PREV - INSTITUTO DE PREVIDÊNCIA DOS SER...", "Aquidauana Prev"),
    CatalogCompany("26", "RegiPrev", "RegiPrev", "REGISTRO PREVIDÊNCIA", "RegiPrev"),
    CatalogCompany("27", "Orlandiaprev", "Orlandiaprev", "Orlandiaprev", "Orlandiaprev"),
    CatalogCompany("28", "SGOPREV", "SGO Prev", "Instituto de Previdência Social dos Servidores Mun...", "SGOPREV"),
    CatalogCompany("29", "IPMH", "IPMH", "Instituto de Previdência de Holambra", "IPMH"),
    CatalogCompany("30", "ISSEM", "ISSEM", "ISSEM - INSTITUTO DE SEGURIDADE SOCIAL DOS SERVIDO...", "ISSEM"),
    CatalogCompany("31", "BODOPREV", "BODOPREV", "INSTITUTO MUNICIPAL DE PREVIDÊNCIA SOCIAL DOS SERV...", "BODOPREV"),
    CatalogCompany("33", "Água Clara Previdência", "Água Clara Previdência", "INSTITUTO DE PREVIDÊNCIA SOCIAL DOS SERVIDORES DO ...", ""),
    CatalogCompany("34", "IPRERINE", "IPRERINE", "Instituto de Previdência Social dos Servidores Púb...", ""),
    CatalogCompany("37", "RPPS MIRA ESTRELA", "RPPS MIRA ESTRELA", "Fundo de Previdência Municipal de Mira Estrela", ""),
    CatalogCompany("40", "FAASSAMONTE", "FAASSAMONTE", "FAAS - Fundo de Assistência e Aposentadoria dos S...", ""),
    CatalogCompany("42", "VicentinópolisPrev", "", "Instituto de Previdência Social de Vicentinópolis-...", "VicentinópolisPrev"),
    CatalogCompany("43", "IPREMT", "IPREMT", "Instituto de Previdência Municipal de Taquaritinga...", ""),
    CatalogCompany("45", "PREVIBAI", "Estimado servidor! Aqui você encontra os principa...", "Previdência dos Servidores Municipais de Amambai", "PREVIBAI"),
    CatalogCompany("46", "Dina Prev", "DINAPREV", "Instituto Municipal de Previdência Social dos Serv...", "Dina Prev"),
    CatalogCompany("47", "FPMM", "FPMM", "FUNDO DE PREVIDÊNCIA DO MUNICÍPIO DE MARIÓPOLIS - ...", ""),
    CatalogCompany("48", "Teixeira Soares Prev", "Estimado servidor! Aqui você encontra os principa...", "FUNDO FINANCEIRO MUNICIPAL DE TEIXEIRA SOARES", "Teixeira Soares Prev"),
)


def company_catalog() -> list[CatalogCompany]:
    return list(COMPANY_CATALOG)


def company_by_id(company_id: str) -> CatalogCompany | None:
    key = str(company_id).strip()
    return next((c for c in COMPANY_CATALOG if c.company_id == key), None)
