from __future__ import annotations

import re
from pathlib import Path
from typing import Callable

from .history import HistoryStore
from .models import APRRecord, CompanyProfile
from .parser import (
    choose_filename_number,
    dates_from_pdf,
    document_signature_score,
    extract_amount,
    extract_cnpj,
    extract_operation_type,
    extract_unit_name,
    numbers_from_filename,
    numbers_from_pdf,
)
from .pdf_reader import ExtractionCancelled, extract_pdf_content
from .utils import (
    cnpj_is_valid,
    normalize_cnpj,
    only_digits,
    sha256_file,
    token_similarity,
)

CONTROL_CHARS_RE = re.compile(r"[\x00-\x1f\x7f]")
UNRESOLVED_PLACEHOLDER_RE = re.compile(r"\{[^{}]+\}")


def build_file_path(template: str, profile: CompanyProfile, year4: int, filename: str) -> str:
    try:
        value = template.format(
            company_id=profile.company_id,
            year=year4,
            year4=year4,
            filename=filename,
        )
    except KeyError as exc:
        raise ValueError(f"placeholder desconhecido no template do campo file: {exc}") from exc
    return value.replace("\\", "/")


def validate_db_path(file_db: str, exact_filename: str) -> list[str]:
    errors: list[str] = []
    if not file_db:
        return ["campo file ficou vazio"]
    if CONTROL_CHARS_RE.search(file_db):
        errors.append("campo file contém caractere de controle")
    if UNRESOLVED_PLACEHOLDER_RE.search(file_db):
        errors.append("campo file contém placeholder não resolvido")
    if not file_db.startswith("/"):
        errors.append("campo file deve começar com '/'")
    if ".." in file_db.split("/"):
        errors.append("campo file contém segmento '..'")
    if not file_db.endswith("/" + exact_filename):
        errors.append(f"campo file não termina com o nome exato do PDF: esperado '{exact_filename}'")
    if "//" in file_db[1:]:
        errors.append("campo file contém '//' no meio do caminho")
    return errors


def validate_profile_draft(profile: CompanyProfile) -> list[str]:
    """Valida campos já informados e permite perfil incompleto."""
    errors: list[str] = []
    if not re.fullmatch(r"\d+", profile.company_id or ""):
        errors.append("company_id deve conter apenas números")
    for value, label in [
        (profile.user_id, "user_id"),
        (profile.transparency_type_detail_id, "transparency_type_detail_id"),
    ]:
        if value and not re.fullmatch(r"\d+", value):
            errors.append(f"{label} deve conter apenas números quando informado")
    if profile.cnpj and not cnpj_is_valid(profile.cnpj):
        errors.append("CNPJ configurado no perfil é inválido")
    if profile.db_port and not re.fullmatch(r"\d{1,5}", profile.db_port):
        errors.append("porta do banco deve conter apenas números")
    if profile.upload_port and not re.fullmatch(r"\d{1,5}", profile.upload_port):
        errors.append("porta de upload deve conter apenas números")
    if profile.upload_protocol and profile.upload_protocol not in {"SFTP", "FTPS", "FTP"}:
        errors.append("protocolo de upload deve ser SFTP, FTPS ou FTP")
    if "{filename}" not in profile.file_template:
        errors.append("template do campo file precisa conter {filename}")
    if "{company_id}" not in profile.file_template:
        errors.append("template do campo file precisa conter {company_id}")
    if "{year4}" not in profile.file_template and "{year}" not in profile.file_template:
        errors.append("template do campo file precisa conter {year4} ou {year}")
    return errors


def validate_profile_for_validation(profile: CompanyProfile) -> list[str]:
    """Requisitos para ler/validar PDFs. CNPJ pode ser aprendido após a leitura."""
    errors = validate_profile_draft(profile)
    if not profile.user_id:
        errors.append("user_id ainda não foi cadastrado")
    if not profile.transparency_type_detail_id:
        errors.append("transparency_type_detail_id ainda não foi cadastrado")
    return errors


def validate_profile(profile: CompanyProfile) -> list[str]:
    """Requisitos estritos para liberar SQL."""
    errors = validate_profile_for_validation(profile)
    if not profile.cnpj:
        errors.append("CNPJ da empresa ainda não foi cadastrado/confirmado")
    return errors


def validate_one(
    pdf_path: Path,
    profile: CompanyProfile,
    *,
    enable_ocr: bool = True,
    cancel_check: Callable[[], bool] | None = None,
) -> APRRecord:
    row = APRRecord(pdf=pdf_path)
    try:
        st = pdf_path.stat()
        row.size_bytes = st.st_size
        row.mtime_ns = st.st_mtime_ns
    except OSError:
        row.size_bytes = 0
        row.mtime_ns = 0

    try:
        row.sha256 = sha256_file(pdf_path)
    except Exception as exc:
        row.errors.append(f"não foi possível calcular SHA-256: {exc}")

    try:
        content = extract_pdf_content(pdf_path, enable_ocr=enable_ocr, cancel_check=cancel_check)
    except ExtractionCancelled:
        raise
    except Exception as exc:
        row.errors.append(f"não foi possível ler o PDF: {exc}")
        return row

    row.extracted_text = content.text
    row.page_count = content.page_count
    row.is_probably_scanned = content.probably_scanned
    row.text_source = content.text_source
    row.ocr_used = content.ocr_used
    row.ocr_provider = content.ocr_provider
    row.ocr_confidence = content.ocr_confidence
    row.ocr_error = content.ocr_error
    row.ocr_truncated = content.ocr_truncated

    if row.ocr_truncated:
        row.errors.append("OCR não processou todas as páginas; validação incompleta")

    if row.is_probably_scanned:
        if enable_ocr:
            detail = f" ({row.ocr_error})" if row.ocr_error else ""
            row.errors.append(
                "PDF sem texto suficiente e o OCR automático não conseguiu recuperar o conteúdo" + detail
            )
        else:
            row.errors.append("PDF sem texto suficiente; OCR automático está desativado")
        return row

    row.signature_score = document_signature_score(row.extracted_text)
    if row.signature_score < 3:
        row.errors.append("o documento não possui elementos suficientes para ser confirmado como APR")

    pdf_numbers = numbers_from_pdf(row.extracted_text)
    if len(pdf_numbers) == 0:
        row.errors.append("não foi possível localizar Nº/ANO dentro do PDF")
    elif len(pdf_numbers) > 1:
        values = ", ".join(n.display for n in pdf_numbers)
        row.errors.append(f"PDF contém Nº/ANO conflitantes: {values}")
    else:
        row.pdf_number = pdf_numbers[0]

    filename_candidates = numbers_from_filename(pdf_path)
    row.filename_number, warns, errs = choose_filename_number(filename_candidates, row.pdf_number)
    row.warnings.extend(warns)
    row.errors.extend(errs)

    date_candidates = dates_from_pdf(row.extracted_text)
    if len(date_candidates) == 0:
        row.errors.append("não foi possível localizar uma DATA válida da APR")
    elif len(date_candidates) > 1:
        values = ", ".join(d.strftime("%d/%m/%Y") for d in date_candidates)
        row.errors.append(f"PDF contém datas de APR conflitantes: {values}")
    else:
        row.apr_date = date_candidates[0]

    row.cnpj = extract_cnpj(row.extracted_text)
    row.unit_name = extract_unit_name(row.extracted_text)
    row.amount = extract_amount(row.extracted_text)
    row.operation_type = extract_operation_type(row.extracted_text)

    if row.ocr_used:
        pct = int(round(row.ocr_confidence * 100))
        if row.ocr_confidence < 0.65:
            row.errors.append(f"OCR com confiança baixa ({pct}%); confira o documento antes de gerar SQL")
        elif row.ocr_confidence < 0.85:
            row.warnings.append(f"OCR com confiança moderada ({pct}%); confira os campos críticos")
        else:
            row.warnings.append(f"texto obtido por OCR automático ({pct}% de confiança)")
        # Sem número no nome, o Nº/ANO dependeria exclusivamente do OCR.
        if not row.filename_number and row.pdf_number:
            row.errors.append(
                "Nº/ANO foi obtido somente por OCR e não existe no nome do arquivo; renomeie o PDF ou confirme manualmente"
            )

    if not row.cnpj:
        row.warnings.append("CNPJ da unidade gestora não foi localizado")
    elif not cnpj_is_valid(row.cnpj):
        row.warnings.append(f"CNPJ encontrado no PDF não passou na validação matemática: {row.cnpj}")

    if profile.cnpj and row.cnpj and only_digits(profile.cnpj) != only_digits(row.cnpj):
        row.errors.append(
            f"CNPJ divergente: perfil='{normalize_cnpj(profile.cnpj)}' x PDF='{normalize_cnpj(row.cnpj)}'"
        )

    if profile.unit_name and row.unit_name:
        similarity = token_similarity(profile.unit_name, row.unit_name)
        if similarity < 0.34:
            row.warnings.append(
                f"nome da unidade gestora difere do perfil (similaridade por palavras: {int(similarity * 100)}%)"
            )

    if row.filename_number and row.pdf_number and row.filename_number.canonical != row.pdf_number.canonical:
        row.errors.append(
            f"Nº/ANO divergente: arquivo='{row.filename_number.display}' x PDF='{row.pdf_number.display}'"
        )

    if row.filename_number:
        row.name = row.filename_number.display
        row.source_name = "arquivo"
    elif row.pdf_number:
        row.name = row.pdf_number.display
        row.source_name = "pdf"
        row.warnings.append("Nº/ANO não estava no nome do arquivo; name foi obtido do PDF")

    if row.name:
        row.slug = re.sub(r"\D", "", row.name)
        if not row.slug:
            row.errors.append("slug ficou vazio")

    if row.apr_date:
        row.date_sql = row.apr_date.strftime("%Y-%m-%d 00:00:00")

    effective_number = row.pdf_number or row.filename_number
    if effective_number and row.apr_date:
        if effective_number.year4 != row.apr_date.year:
            row.errors.append(
                f"ano divergente: Nº/ANO indica {effective_number.year4}, mas DATA indica {row.apr_date.year}"
            )
        row.year4 = row.apr_date.year
    elif row.apr_date:
        row.year4 = row.apr_date.year
    elif effective_number:
        row.year4 = effective_number.year4

    if row.year4 is not None:
        try:
            row.file_db = build_file_path(profile.file_template, profile, row.year4, pdf_path.name)
            row.errors.extend(validate_db_path(row.file_db, pdf_path.name))
        except Exception as exc:
            row.errors.append(f"erro ao montar campo file: {exc}")

    return row


def add_batch_duplicate_errors(rows: list[APRRecord]) -> None:
    """Mantém a primeira ocorrência como original e marca apenas as repetições."""
    checks = [
        (lambda r: r.canonical_number, "APR canônica"),
        (lambda r: r.slug, "slug"),
        (lambda r: r.file_db.casefold() if r.file_db else "", "campo file"),
        (lambda r: r.sha256, "conteúdo do PDF (SHA-256)"),
    ]
    for getter, label in checks:
        seen: dict[str, APRRecord] = {}
        for row in rows:
            value = getter(row)
            if not value:
                continue
            original = seen.get(value)
            if original is None:
                seen[value] = row
                continue
            message = f"duplicidade de {label}: repete '{original.pdf.name}'"
            if message not in row.errors:
                row.errors.append(message)


def validate_batch(
    paths: list[Path],
    profile: CompanyProfile,
    history_store: HistoryStore | None = None,
    *,
    enable_ocr: bool = True,
) -> list[APRRecord]:
    rows = [validate_one(p, profile, enable_ocr=enable_ocr) for p in paths]
    add_batch_duplicate_errors(rows)
    if history_store is not None:
        history_store.apply_checks(rows, profile)
    return rows


def verify_files_unchanged(rows: list[APRRecord]) -> list[str]:
    """Recalcula o hash antes da exportação para eliminar TOCTOU do arquivo."""
    errors: list[str] = []
    for row in rows:
        try:
            st = row.pdf.stat()
        except OSError as exc:
            errors.append(f"{row.pdf.name}: arquivo indisponível antes da exportação ({exc})")
            continue
        if st.st_size != row.size_bytes or st.st_mtime_ns != row.mtime_ns:
            errors.append(f"{row.pdf.name}: arquivo foi alterado depois da validação")
            continue
        try:
            current_hash = sha256_file(row.pdf)
        except Exception as exc:
            errors.append(f"{row.pdf.name}: não foi possível recalcular SHA-256 ({exc})")
            continue
        if current_hash != row.sha256:
            errors.append(f"{row.pdf.name}: conteúdo mudou depois da validação (SHA-256 divergente)")
    return errors
