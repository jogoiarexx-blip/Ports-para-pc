from __future__ import annotations

import csv
import html
import json
import os
import re
import tempfile
from datetime import datetime
from pathlib import Path

from .models import APRRecord, CompanyProfile
from .utils import atomic_write_text, csv_safe, sha256_file, sql_quote
from .version import APP_NAME, APP_VERSION

PUBLISHED_IN_MODES = {"apr", "export", "manual"}


def _normalize_manual_date(value: str | None) -> str:
    if not value:
        raise ValueError("data manual de published_in não informada")
    value = value.strip()
    for fmt in ("%Y-%m-%d", "%d/%m/%Y"):
        try:
            return datetime.strptime(value, fmt).strftime("%Y-%m-%d 00:00:00")
        except ValueError:
            pass
    raise ValueError("data manual de published_in deve estar em YYYY-MM-DD ou DD/MM/YYYY")


def resolve_published_in(
    row: APRRecord,
    mode: str = "apr",
    manual_date: str | None = None,
    export_datetime: datetime | None = None,
) -> str:
    """Resolve o valor final de published_in para uma APR.

    - apr: mesma data de reference_date/APR (comportamento legado)
    - export: data do dia da exportação, às 00:00:00
    - manual: data informada explicitamente, às 00:00:00
    """
    mode = (mode or "apr").strip().lower()
    if mode not in PUBLISHED_IN_MODES:
        raise ValueError(f"modo de published_in inválido: {mode}")
    if mode == "apr":
        if not row.date_sql:
            raise ValueError(f"APR sem data válida para published_in: {row.pdf.name}")
        return row.date_sql
    if mode == "export":
        when = export_datetime or datetime.now()
        return when.strftime("%Y-%m-%d 00:00:00")
    return _normalize_manual_date(manual_date)


def _published_mode_label(mode: str) -> str:
    return {
        "apr": "DATA DA APR",
        "export": "DATA DA EXPORTAÇÃO",
        "manual": "DATA MANUAL",
    }.get(mode, mode.upper())


def _row_dict(row: APRRecord, published_in_sql: str = "") -> dict[str, str]:
    return {
        "arquivo": row.pdf.name,
        "status": row.status,
        "numero_arquivo": row.filename_number.display if row.filename_number else "",
        "numero_pdf": row.pdf_number.display if row.pdf_number else "",
        "numero_canonico": row.canonical_number,
        "data_pdf": row.apr_date.strftime("%d/%m/%Y") if row.apr_date else "",
        "reference_date_sql": row.date_sql,
        "published_in_sql": published_in_sql,
        "name": row.name,
        "slug": row.slug,
        "cnpj": row.cnpj,
        "unidade_gestora": row.unit_name,
        "valor": row.amount,
        "tipo_operacao": row.operation_type,
        "file_db": row.file_db,
        "sha256": row.sha256,
        "tamanho_bytes": str(row.size_bytes),
        "paginas": str(row.page_count),
        "origem_name": row.source_name,
        "fonte_texto": row.text_source,
        "ocr_usado": "SIM" if row.ocr_used else "NÃO",
        "ocr_provedor": row.ocr_provider,
        "ocr_confianca": f"{row.ocr_confidence:.4f}" if row.ocr_used else "",
        "ocr_erro": row.ocr_error,
        "historico_status": row.history_status,
        "historico_mensagem": row.history_message,
        "status_exportacao": row.export_status,
        "avisos": " | ".join(row.warnings),
        "erros": " | ".join(row.errors),
    }


def _sanitize_folder_name(value: str) -> str:
    value = re.sub(r"[^A-Za-z0-9._-]+", "_", value.strip())
    return value.strip("._-") or "EMPRESA"


def create_export_dir(base_dir: Path, profile: CompanyProfile, now: datetime | None = None) -> Path:
    now = now or datetime.now()
    stem = f"{now:%Y-%m-%d_%H%M%S}_{_sanitize_folder_name(profile.name)}"
    candidate = base_dir / stem
    n = 2
    while candidate.exists():
        candidate = base_dir / f"{stem}_{n}"
        n += 1
    candidate.mkdir(parents=True, exist_ok=False)
    return candidate


def build_insert(
    row: APRRecord,
    profile: CompanyProfile,
    created_at: str,
    *,
    published_in_sql: str | None = None,
) -> str:
    """INSERT idempotente para APR ativa com mesma empresa/tipo/slug."""
    published_in_sql = published_in_sql or row.date_sql
    cols = (
        "id, company_id, user_id, transparency_type_detail_id, name, slug, "
        "reference_date, published_in, file, description, status, created_at, updated_at, deleted_at"
    )
    vals = [
        "NULL",
        sql_quote(profile.company_id),
        sql_quote(profile.user_id),
        sql_quote(profile.transparency_type_detail_id),
        sql_quote(row.name),
        sql_quote(row.slug),
        sql_quote(row.date_sql),
        sql_quote(published_in_sql),
        sql_quote(row.file_db),
        "NULL",
        sql_quote("1"),
        sql_quote(created_at),
        sql_quote(created_at),
        "NULL",
    ]
    where = (
        "NOT EXISTS (SELECT 1 FROM transparencies "
        f"WHERE company_id = {sql_quote(profile.company_id)} "
        f"AND transparency_type_detail_id = {sql_quote(profile.transparency_type_detail_id)} "
        f"AND slug = {sql_quote(row.slug)} AND deleted_at IS NULL)"
    )
    return (
        f"INSERT INTO transparencies ({cols})\n"
        f"SELECT {', '.join(vals)}\n"
        f"WHERE {where};"
    )


def _row_can_export(row: APRRecord, allow_history_override: bool) -> bool:
    if row.errors:
        return False
    if row.history_blocking:
        return bool(allow_history_override and row.history_override_allowed)
    return True


def build_sql(
    rows: list[APRRecord],
    profile: CompanyProfile,
    created_at: str | None = None,
    *,
    allow_history_override: bool = False,
    published_in_mode: str = "apr",
    published_in_date: str | None = None,
    export_id: str = "",
) -> str:
    created_at = created_at or datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    created_dt = datetime.strptime(created_at, "%Y-%m-%d %H:%M:%S")
    invalid = [r for r in rows if not _row_can_export(r, allow_history_override)]
    if invalid:
        raise ValueError("há registros com erro/bloqueio; SQL bloqueado")
    if not rows:
        raise ValueError("nenhuma APR válida selecionada para o SQL")

    # Resolve uma vez para validar a política antes de montar qualquer INSERT.
    published_values = [
        resolve_published_in(r, published_in_mode, published_in_date, created_dt)
        for r in rows
    ]
    header = [
        f"-- {APP_NAME} {APP_VERSION}",
        f"-- Export ID: {export_id or '-'}",
        f"-- Gerado em: {created_at}",
        f"-- Perfil: {profile.name}",
        f"-- company_id: {profile.company_id}",
        f"-- user_id: {profile.user_id}",
        f"-- transparency_type_detail_id: {profile.transparency_type_detail_id}",
        f"-- Quantidade de APRs: {len(rows)}",
        "-- INSERTs idempotentes: não inserem APR ativa já existente para company_id + tipo + slug.",
        f"-- published_in: {_published_mode_label(published_in_mode)}"
        + (f" ({published_values[0]})" if published_in_mode in {"export", "manual"} else ""),
        "",
        "START TRANSACTION;",
        "",
    ]
    inserts = [
        build_insert(r, profile, created_at, published_in_sql=published)
        for r, published in zip(rows, published_values)
    ]
    footer = ["", "COMMIT;", ""]
    return "\n".join(header + inserts + footer)


def _published_for_rows(
    rows: list[APRRecord],
    mode: str,
    manual_date: str | None,
    export_datetime: datetime,
) -> dict[str, str]:
    values: dict[str, str] = {}
    # Relatórios devem continuar sendo gerados mesmo para uma APR inválida/sem data.
    # A validação estrita ocorre em build_sql() somente para as linhas efetivamente exportadas.
    for row in rows:
        try:
            values[str(row.pdf)] = resolve_published_in(row, mode, manual_date, export_datetime)
        except ValueError:
            values[str(row.pdf)] = ""
    return values


def write_csv(
    path: Path,
    rows: list[APRRecord],
    *,
    published_values: dict[str, str] | None = None,
) -> None:
    published_values = published_values or {}
    sample = _row_dict(rows[0], published_values.get(str(rows[0].pdf), "")) if rows else {"arquivo": "", "status": ""}
    fieldnames = list(sample.keys())
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8-sig", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames, delimiter=";")
            writer.writeheader()
            for row in rows:
                data = _row_dict(row, published_values.get(str(row.pdf), ""))
                writer.writerow({k: csv_safe(v) for k, v in data.items()})
            f.flush()
            os.fsync(f.fileno())
        os.replace(temp_name, path)
    except Exception:
        try:
            os.remove(temp_name)
        except OSError:
            pass
        raise


def write_manifest(
    path: Path,
    rows: list[APRRecord],
    profile: CompanyProfile,
    *,
    export_id: str = "",
    published_in_mode: str = "apr",
    published_in_date: str | None = None,
    export_datetime: datetime | None = None,
    published_values: dict[str, str] | None = None,
) -> None:
    export_datetime = export_datetime or datetime.now()
    published_values = published_values or _published_for_rows(rows, published_in_mode, published_in_date, export_datetime)
    payload = {
        "generated_at": export_datetime.isoformat(timespec="seconds"),
        "app_version": APP_VERSION,
        "export": {
            "export_id": export_id,
            "published_in_mode": published_in_mode,
            "published_in_mode_label": _published_mode_label(published_in_mode),
            "published_in_manual_date": published_in_date or "",
        },
        "profile": profile.to_manifest_dict(),
        "summary": {
            "total": len(rows),
            "ok": sum(r.status == "OK" for r in rows),
            "warnings": sum(r.status == "AVISO" for r in rows),
            "errors": sum(r.status == "ERRO" for r in rows),
        },
        "documents": [
            _row_dict(r, published_values.get(str(r.pdf), ""))
            for r in rows
        ],
    }
    atomic_write_text(path, json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def write_html(
    path: Path,
    rows: list[APRRecord],
    *,
    published_values: dict[str, str] | None = None,
) -> None:
    published_values = published_values or {}
    ok = sum(r.status == "OK" for r in rows)
    warn = sum(r.status == "AVISO" for r in rows)
    err = sum(r.status == "ERRO" for r in rows)

    body = []
    for row in rows:
        d = _row_dict(row, published_values.get(str(row.pdf), ""))
        cls = "err" if row.status == "ERRO" else "warn" if row.status == "AVISO" else "ok"
        body.append(
            f"<tr class='{cls}'>"
            + "".join(
                f"<td>{html.escape(d[k])}</td>"
                for k in [
                    "status", "arquivo", "numero_arquivo", "numero_pdf", "data_pdf",
                    "reference_date_sql", "published_in_sql", "cnpj", "unidade_gestora",
                    "valor", "tipo_operacao", "fonte_texto", "ocr_confianca",
                    "historico_status", "historico_mensagem", "file_db", "sha256", "avisos", "erros"
                ]
            )
            + "</tr>"
        )

    doc = f"""<!doctype html>
<html lang='pt-BR'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>
<title>APR Manager - Relatório</title>
<style>
body{{font-family:Segoe UI,Arial,sans-serif;margin:24px;color:#1f2937;background:#f8fafc}}h1{{margin:0 0 8px}}
.summary{{background:white;padding:16px;border-radius:12px;margin:16px 0;box-shadow:0 1px 4px #0001}}
table{{border-collapse:collapse;width:100%;background:white;font-size:12px}}th,td{{border:1px solid #d1d5db;padding:7px;vertical-align:top}}th{{position:sticky;top:0;background:#e5e7eb}}tr.err{{background:#fee2e2}}tr.warn{{background:#fef3c7}}tr.ok td:first-child{{color:#166534;font-weight:700}}tr.err td:first-child{{color:#991b1b;font-weight:700}}tr.warn td:first-child{{color:#92400e;font-weight:700}}
</style></head><body><h1>APR Manager</h1><div class='summary'>Total: <b>{len(rows)}</b> &nbsp; OK: <b>{ok}</b> &nbsp; Avisos: <b>{warn}</b> &nbsp; Erros: <b>{err}</b></div>
<table><thead><tr><th>Status</th><th>Arquivo</th><th>Nº/ANO arquivo</th><th>Nº/ANO PDF</th><th>Data</th><th>reference_date</th><th>published_in</th><th>CNPJ</th><th>Unidade gestora</th><th>Valor</th><th>Operação</th><th>Fonte texto</th><th>Confiança OCR</th><th>Histórico</th><th>Detalhe histórico</th><th>file</th><th>SHA-256</th><th>Avisos</th><th>Erros</th></tr></thead><tbody>{''.join(body)}</tbody></table></body></html>"""
    atomic_write_text(path, doc)


def _write_export_summary(
    path: Path,
    *,
    export_id: str,
    profile: CompanyProfile,
    rows: list[APRRecord],
    sql_rows: list[APRRecord],
    created_at: str,
    published_in_mode: str,
    published_in_date: str | None,
    sql_created: bool,
) -> None:
    ok = sum(r.status == "OK" for r in rows)
    warn = sum(r.status == "AVISO" for r in rows)
    err = sum(r.status == "ERRO" for r in rows)
    published_note = _published_mode_label(published_in_mode)
    if published_in_mode == "manual":
        published_note += f" ({_normalize_manual_date(published_in_date)})"
    elif published_in_mode == "export":
        published_note += f" ({created_at[:10]} 00:00:00)"

    text = f"""{APP_NAME} {APP_VERSION} - RESUMO DA EXPORTAÇÃO

Export ID: {export_id}
Gerado em: {created_at}
Empresa: {profile.name}
company_id: {profile.company_id}
user_id: {profile.user_id}
transparency_type_detail_id: {profile.transparency_type_detail_id}
CNPJ confirmado: {profile.cnpj}

Lote:
- Total validado: {len(rows)}
- OK: {ok}
- Avisos: {warn}
- Erros: {err}
- APRs incluídas no SQL: {len(sql_rows)}
- SQL criado: {'SIM' if sql_created else 'NÃO'}
- Regra de published_in: {published_note}

Arquivos do pacote:
- relatorio_apr.csv
- relatorio_apr.html
- manifest_apr.json
- {'inserts_transparencies.sql' if sql_created else '(SQL não criado)'}
- CHECKSUMS.sha256

IMPORTANTE:
1. Confira os relatórios antes de executar o SQL.
2. CHECKSUMS.sha256 permite verificar se algum arquivo do pacote foi alterado depois da exportação.
3. No APR Manager, marque como CONFIRMADO somente depois de executar o SQL com sucesso no banco.
"""
    atomic_write_text(path, text)


def _write_checksums(output_dir: Path, file_names: list[str]) -> Path:
    lines: list[str] = []
    for name in sorted(file_names):
        path = output_dir / name
        if path.exists() and path.is_file():
            lines.append(f"{sha256_file(path)}  {name}")
    checksum_path = output_dir / "CHECKSUMS.sha256"
    atomic_write_text(checksum_path, "\n".join(lines) + ("\n" if lines else ""))
    return checksum_path


def verify_export_package(output_dir: Path) -> tuple[bool, list[str]]:
    """Confere os hashes registrados em CHECKSUMS.sha256.

    Retorna (ok, mensagens). Não confia apenas na existência dos arquivos.
    """
    output_dir = Path(output_dir)
    checksum_path = output_dir / "CHECKSUMS.sha256"
    if not checksum_path.exists():
        return False, ["CHECKSUMS.sha256 não encontrado"]
    problems: list[str] = []
    checked = 0
    for lineno, raw in enumerate(checksum_path.read_text(encoding="utf-8").splitlines(), start=1):
        raw = raw.strip()
        if not raw:
            continue
        m = re.fullmatch(r"([0-9a-fA-F]{64})\s{2}(.+)", raw)
        if not m:
            problems.append(f"linha {lineno} inválida em CHECKSUMS.sha256")
            continue
        expected, name = m.group(1).lower(), m.group(2)
        # O arquivo de checksums nunca deve apontar para fora da pasta exportada.
        if Path(name).name != name or name in {".", ".."}:
            problems.append(f"nome de arquivo inseguro em CHECKSUMS.sha256: {name}")
            continue
        target = output_dir / name
        if not target.exists() or not target.is_file():
            problems.append(f"arquivo ausente: {name}")
            continue
        actual = sha256_file(target)
        checked += 1
        if actual.lower() != expected:
            problems.append(f"hash divergente: {name}")
    if checked == 0 and not problems:
        problems.append("nenhum arquivo listado em CHECKSUMS.sha256")
    return not problems, problems or [f"{checked} arquivo(s) conferido(s) com sucesso"]


def export_package(
    base_output_dir: Path,
    rows: list[APRRecord],
    profile: CompanyProfile,
    *,
    sql_rows: list[APRRecord] | None = None,
    allow_history_override: bool = False,
    published_in_mode: str = "apr",
    published_in_date: str | None = None,
) -> dict[str, Path | str]:
    """Cria uma pasta exclusiva por exportação e adiciona prova de integridade."""
    base_output_dir.mkdir(parents=True, exist_ok=True)
    export_datetime = datetime.now()
    created_at = export_datetime.strftime("%Y-%m-%d %H:%M:%S")
    output_dir = create_export_dir(base_output_dir, profile, export_datetime)
    export_id = output_dir.name
    sql_rows = list(rows if sql_rows is None else sql_rows)

    # Valida a política mesmo quando não houver SQL, para que relatórios/manifest
    # representem exatamente o que seria publicado.
    published_values = _published_for_rows(rows, published_in_mode, published_in_date, export_datetime)

    csv_path = output_dir / "relatorio_apr.csv"
    html_path = output_dir / "relatorio_apr.html"
    manifest_path = output_dir / "manifest_apr.json"
    sql_path = output_dir / "inserts_transparencies.sql"
    summary_path = output_dir / "RESUMO_EXPORTACAO.txt"

    write_csv(csv_path, rows, published_values=published_values)
    write_html(html_path, rows, published_values=published_values)
    write_manifest(
        manifest_path,
        rows,
        profile,
        export_id=export_id,
        published_in_mode=published_in_mode,
        published_in_date=published_in_date,
        export_datetime=export_datetime,
        published_values=published_values,
    )

    sql_created = False
    if sql_rows:
        atomic_write_text(
            sql_path,
            build_sql(
                sql_rows,
                profile,
                created_at=created_at,
                allow_history_override=allow_history_override,
                published_in_mode=published_in_mode,
                published_in_date=published_in_date,
                export_id=export_id,
            ),
            encoding="utf-8",
        )
        sql_created = True

    _write_export_summary(
        summary_path,
        export_id=export_id,
        profile=profile,
        rows=rows,
        sql_rows=sql_rows,
        created_at=created_at,
        published_in_mode=published_in_mode,
        published_in_date=published_in_date,
        sql_created=sql_created,
    )

    checksum_inputs = ["relatorio_apr.csv", "relatorio_apr.html", "manifest_apr.json", "RESUMO_EXPORTACAO.txt"]
    if sql_created:
        checksum_inputs.append("inserts_transparencies.sql")
    checksum_path = _write_checksums(output_dir, checksum_inputs)

    return {
        "output_dir": output_dir,
        "csv": csv_path,
        "html": html_path,
        "manifest": manifest_path,
        "summary": summary_path,
        "checksums": checksum_path,
        "sql": sql_path if sql_created else Path(),
        "export_id": export_id,
    }
