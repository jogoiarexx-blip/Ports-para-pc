@echo off
cd /d "%~dp0"
echo ========================================
echo        APR Manager - Criar EXE
echo ========================================
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0build_windows.ps1"
if errorlevel 1 (
  echo.
  echo Falha ao criar o EXE.
  pause
  exit /b 1
)
echo.
echo Pronto. Veja a pasta dist\APR Manager.
pause
