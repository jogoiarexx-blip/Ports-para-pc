$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

function Invoke-Checked([scriptblock]$Command, [string]$Label) {
    & $Command
    if ($LASTEXITCODE -ne 0) { throw "$Label falhou com codigo $LASTEXITCODE" }
}

$pythonArgs = @("-3.12")
& py @pythonArgs -V *> $null
if ($LASTEXITCODE -ne 0) {
    $pythonArgs = @()
    & py -V *> $null
    if ($LASTEXITCODE -ne 0) { throw "Python launcher (py) nao encontrado." }
}

if (-not (Test-Path ".venv-build\Scripts\python.exe")) {
    Invoke-Checked { py @pythonArgs -m venv .venv-build } "Criacao do ambiente de build"
}

Invoke-Checked { & .\.venv-build\Scripts\python.exe -m pip install --upgrade pip } "Atualizacao do pip"
Invoke-Checked { & .\.venv-build\Scripts\python.exe -m pip install -r requirements-build.txt } "Instalacao das dependencias"
Invoke-Checked { & .\.venv-build\Scripts\python.exe -c "import PySide6,pypdf,pypdfium2,rapidocr,onnxruntime" } "Teste das dependencias"

if (Test-Path "build") { Remove-Item "build" -Recurse -Force }
if (Test-Path "dist") { Remove-Item "dist" -Recurse -Force }

$pyinstallerArgs = @(
  "--noconfirm", "--clean", "--windowed", "--onedir",
  "--name", "APR Manager",
  "--collect-all", "pypdfium2",
  "--collect-all", "rapidocr",
  "--collect-all", "onnxruntime",
  "--hidden-import", "PySide6.QtPdf",
  "--hidden-import", "PySide6.QtPdfWidgets",
  "app.py"
)
if (Test-Path "assets\apr-manager.ico") {
    $pyinstallerArgs = @("--icon", "assets\apr-manager.ico") + $pyinstallerArgs
}
Invoke-Checked { & .\.venv-build\Scripts\pyinstaller.exe @pyinstallerArgs } "PyInstaller"

Write-Host ""
Write-Host "Build concluido: $PSScriptRoot\dist\APR Manager\APR Manager.exe" -ForegroundColor Green

$versionLine = Select-String -Path "core\version.py" -Pattern '^APP_VERSION\s*=\s*"([^"]+)"$'
if (-not $versionLine) { throw "Nao foi possivel ler APP_VERSION de core/version.py" }
$version = $versionLine.Matches[0].Groups[1].Value

$inno = @(
  "$env:ProgramFiles(x86)\Inno Setup 6\ISCC.exe",
  "$env:ProgramFiles\Inno Setup 6\ISCC.exe"
) | Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1

if ($inno) {
    Invoke-Checked { & $inno "/DMyAppVersion=$version" "installer\APR-Manager.iss" } "Inno Setup"
    Write-Host "Instalador criado na pasta installer-output." -ForegroundColor Green
} else {
    Write-Host "Inno Setup nao encontrado. O app portavel ja esta pronto em dist." -ForegroundColor Yellow
}
