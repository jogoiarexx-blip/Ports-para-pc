#ifndef MyAppVersion
  #define MyAppVersion "dev"
#endif
#define MyAppName "APR Manager"
#define MyAppExeName "APR Manager.exe"

[Setup]
AppId={{A26F1E48-6A8D-4F1B-B9E5-1EAB44A59C18}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
DefaultDirName={autopf}\APR Manager
DefaultGroupName=APR Manager
OutputDir=..\installer-output
OutputBaseFilename=APR-Manager-Setup-{#MyAppVersion}
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible

[Files]
Source: "..\dist\APR Manager\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{autoprograms}\APR Manager"; Filename: "{app}\{#MyAppExeName}"
Name: "{autodesktop}\APR Manager"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Tasks]
Name: "desktopicon"; Description: "Criar atalho na Area de Trabalho"; GroupDescription: "Atalhos:"; Flags: unchecked

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Abrir APR Manager"; Flags: nowait postinstall skipifsilent
