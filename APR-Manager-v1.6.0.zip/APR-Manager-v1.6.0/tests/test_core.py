from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from core.models import APRRecord, CompanyProfile, ParsedNumber
from core.parser import (
    dates_from_pdf,
    document_signature_score,
    extract_cnpj,
    extract_unit_name,
    numbers_from_filename,
    numbers_from_pdf,
)
from core.reporting import build_sql, export_package, write_manifest, resolve_published_in, verify_export_package
from core.utils import cnpj_is_valid, csv_safe
from core.validator import (
    add_batch_duplicate_errors,
    validate_one,
    validate_profile,
    validate_profile_draft,
    validate_profile_for_validation,
    verify_files_unchanged,
)


class ParserTests(unittest.TestCase):
    def test_filename_does_not_treat_date_as_apr(self):
        values = numbers_from_filename(Path("APR 11-06-2026 52.26.pdf"))
        self.assertEqual([v.canonical for v in values], ["2026:52"])

    def test_pdf_number(self):
        values = numbers_from_pdf("Nº / ANO: 52/26")
        self.assertEqual([v.canonical for v in values], ["2026:52"])

    def test_regulation_number_is_ignored_when_strong_apr_number_exists(self):
        text = "Resolução CMN 4963/21\nMPS nº 402/2008\nNº / ANO: 52/26"
        values = numbers_from_pdf(text)
        self.assertEqual([v.canonical for v in values], ["2026:52"])

    def test_fallback_ignores_policy_line(self):
        text = "MPS nº 402/2008\nNº: 52/26"
        values = numbers_from_pdf(text)
        self.assertEqual([v.canonical for v in values], ["2026:52"])

    def test_date_variants(self):
        self.assertEqual(dates_from_pdf("DATA DA OPERAÇÃO: 11/06/2026")[0].strftime("%Y-%m-%d"), "2026-06-11")
        self.assertEqual(dates_from_pdf("DATA: 11/06/2026")[0].strftime("%Y-%m-%d"), "2026-06-11")

    def test_operation_date_has_priority(self):
        values = dates_from_pdf("DATA: 10/06/2026\nDATA DA OPERAÇÃO: 11/06/2026")
        self.assertEqual([x.strftime("%Y-%m-%d") for x in values], ["2026-06-11"])

    def test_cnpj(self):
        self.assertTrue(cnpj_is_valid("05.360.812/0001-61"))

    def test_cnpj_prefers_rpps_unit_block(self):
        text = (
            "CNPJ de outro bloco: 00.360.305/0001-04\n"
            "Unidade gestora do RPPS: INSTITUTO EXEMPLO\n"
            "CNPJ: 05.360.812/0001-61\n"
            "CNPJ Administrador: 11.111.111/0001-11"
        )
        self.assertEqual(extract_cnpj(text), "05.360.812/0001-61")

    def test_unit_name_accepts_two_lines_but_is_bounded(self):
        text = (
            "Unidade gestora do RPPS: INSTITUTO DE PREVIDÊNCIA DOS\n"
            "SERVIDORES PÚBLICOS MUNICIPAIS DE PITANGUEIRAS\n"
            "CNPJ: 05.360.812/0001-61\n" + "X" * 500
        )
        unit = extract_unit_name(text)
        self.assertIn("PITANGUEIRAS", unit)
        self.assertLessEqual(len(unit), 200)

    def test_signature_does_not_count_apresentacao_as_apr(self):
        weak = "APRESENTAÇÃO APROVADO Unidade gestora do RPPS"
        self.assertLess(document_signature_score(weak), 3)

    def test_year_is_normalized_to_two_digits_for_bank_name(self):
        values = numbers_from_filename(Path("APR 052.2026.pdf"))
        self.assertEqual(values[0].display, "052/26")
        self.assertEqual(values[0].canonical, "2026:52")


class SQLTests(unittest.TestCase):
    def _row(self):
        return APRRecord(
            pdf=Path("APR 52.26.pdf"),
            name="52/26",
            slug="5226",
            date_sql="2026-06-11 00:00:00",
            file_db="/dist/uploads/files/5/aplicacoes-e-investimentos/apr/2026/APR 52.26.pdf",
        )

    def test_sql_transaction_and_idempotency(self):
        p = CompanyProfile("x", "5", "892", "77", cnpj="05.360.812/0001-61")
        sql = build_sql([self._row()], p, "2026-09-23 10:00:00")
        self.assertIn("START TRANSACTION;", sql)
        self.assertIn("COMMIT;", sql)
        self.assertIn("WHERE NOT EXISTS", sql)
        self.assertIn("deleted_at IS NULL", sql)
        self.assertIn("published_in: DATA DA APR", sql)

    def test_each_export_gets_unique_subfolder(self):
        p = CompanyProfile("PITANPREV", "5", "892", "77", cnpj="05.360.812/0001-61")
        r = self._row()
        with tempfile.TemporaryDirectory() as tmp:
            one = export_package(Path(tmp), [r], p)["output_dir"]
            two = export_package(Path(tmp), [r], p)["output_dir"]
            self.assertNotEqual(one, two)
            self.assertTrue((one / "inserts_transparencies.sql").exists())
            self.assertTrue((two / "inserts_transparencies.sql").exists())


    def test_published_in_export_date(self):
        p = CompanyProfile("x", "5", "892", "77", cnpj="05.360.812/0001-61")
        sql = build_sql(
            [self._row()], p, "2026-09-24 15:30:00",
            published_in_mode="export", export_id="exp-1",
        )
        self.assertIn("'2026-09-24 00:00:00'", sql)
        self.assertIn("Export ID: exp-1", sql)
        self.assertIn("published_in: DATA DA EXPORTAÇÃO", sql)

    def test_published_in_manual_date(self):
        p = CompanyProfile("x", "5", "892", "77", cnpj="05.360.812/0001-61")
        sql = build_sql(
            [self._row()], p, "2026-09-24 15:30:00",
            published_in_mode="manual", published_in_date="25/09/2026",
        )
        self.assertIn("'2026-09-25 00:00:00'", sql)
        self.assertEqual(
            resolve_published_in(self._row(), "manual", "2026-09-25"),
            "2026-09-25 00:00:00",
        )

    def test_export_package_contains_checksums_and_summary(self):
        p = CompanyProfile("PITANPREV", "5", "892", "77", cnpj="05.360.812/0001-61")
        r = self._row()
        with tempfile.TemporaryDirectory() as tmp:
            result = export_package(Path(tmp), [r], p)
            out = result["output_dir"]
            self.assertTrue((out / "CHECKSUMS.sha256").exists())
            self.assertTrue((out / "RESUMO_EXPORTACAO.txt").exists())
            ok, messages = verify_export_package(out)
            self.assertTrue(ok, messages)

    def test_package_integrity_detects_tampering(self):
        p = CompanyProfile("PITANPREV", "5", "892", "77", cnpj="05.360.812/0001-61")
        r = self._row()
        with tempfile.TemporaryDirectory() as tmp:
            result = export_package(Path(tmp), [r], p)
            out = result["output_dir"]
            sql_path = out / "inserts_transparencies.sql"
            sql_path.write_text(sql_path.read_text(encoding="utf-8") + "\n-- alterado", encoding="utf-8")
            ok, messages = verify_export_package(out)
            self.assertFalse(ok)
            self.assertTrue(any("hash divergente" in m for m in messages))


    def test_reports_still_export_when_invalid_row_has_no_date(self):
        p = CompanyProfile("PITANPREV", "5", "892", "77", cnpj="05.360.812/0001-61")
        bad = APRRecord(pdf=Path("sem-data.pdf"), errors=["data ausente"])
        with tempfile.TemporaryDirectory() as tmp:
            result = export_package(Path(tmp), [bad], p, sql_rows=[])
            out = result["output_dir"]
            self.assertTrue((out / "relatorio_apr.csv").exists())
            self.assertTrue((out / "relatorio_apr.html").exists())
            self.assertFalse((out / "inserts_transparencies.sql").exists())
            ok, messages = verify_export_package(out)
            self.assertTrue(ok, messages)

    def test_manifest_does_not_expose_hosts(self):
        p = CompanyProfile(
            "PITANPREV", "5", "892", "77", cnpj="05.360.812/0001-61",
            db_host="10.0.0.1", upload_host="10.0.0.2"
        )
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "manifest.json"
            write_manifest(path, [self._row()], p)
            data = json.loads(path.read_text(encoding="utf-8"))
            self.assertNotIn("db_host", data["profile"])
            self.assertNotIn("upload_host", data["profile"])


class ProfileTests(unittest.TestCase):
    def test_draft_profile_can_be_saved_incomplete(self):
        p = CompanyProfile("PITANPREV", "5", "", "")
        self.assertEqual(validate_profile_draft(p), [])
        self.assertTrue(any("user_id" in e for e in validate_profile_for_validation(p)))

    def test_export_requires_cnpj(self):
        p = CompanyProfile("PITANPREV", "5", "892", "77")
        self.assertTrue(any("CNPJ" in e for e in validate_profile(p)))

    def test_corrupt_profiles_are_backed_up_not_overwritten(self):
        import core.profiles as profiles_mod
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "profiles.json"
            path.write_text('{"profiles": [', encoding="utf-8")
            with patch.object(profiles_mod, "profiles_path", return_value=path):
                loaded = profiles_mod.load_profiles()
                warning = profiles_mod.pop_profile_load_warning()
            self.assertTrue(loaded)
            self.assertTrue(warning)
            self.assertTrue(path.exists())
            json.loads(path.read_text(encoding="utf-8"))
            self.assertTrue(list(Path(tmp).glob("profiles.corrupt-*.json")))

    def test_catalog_deletion_tombstone_persists(self):
        import core.profiles as profiles_mod
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "profiles.json"
            with patch.object(profiles_mod, "profiles_path", return_value=path):
                profiles = profiles_mod.load_profiles()
                profiles_mod.mark_catalog_company_deleted("5")
                profiles = [p for p in profiles if p.company_id != "5"]
                profiles_mod.save_profiles(profiles)
                reloaded = profiles_mod.load_profiles()
            self.assertNotIn("5", {p.company_id for p in reloaded})


class CompanyCatalogTests(unittest.TestCase):
    def test_company_catalog_has_38_unique_ids(self):
        from core.company_catalog import company_catalog
        companies = company_catalog()
        self.assertEqual(len(companies), 38)
        ids = [c.company_id for c in companies]
        self.assertEqual(len(ids), len(set(ids)))
        self.assertIn("5", ids)
        self.assertIn("48", ids)

    def test_catalog_contains_known_company(self):
        from core.company_catalog import company_by_id
        company = company_by_id("5")
        self.assertIsNotNone(company)
        self.assertEqual(company.display_name, "PITANPREV")


class HistoryTests(unittest.TestCase):
    def _record(self, sha="a" * 64):
        number = ParsedNumber("52", "26", 52, 2026)
        return APRRecord(
            pdf=Path("APR 52.26.pdf"), pdf_number=number, name="52/26", slug="5226", sha256=sha,
            date_sql="2026-06-11 00:00:00",
            file_db="/dist/uploads/files/5/aplicacoes-e-investimentos/apr/2026/APR 52.26.pdf",
        )

    def test_generated_history_warns_but_does_not_block(self):
        from core.history import HistoryStore
        with tempfile.TemporaryDirectory() as tmp:
            store = HistoryStore(Path(tmp) / "history.sqlite3")
            profile = CompanyProfile("PITANPREV", "5", "892", "77")
            store.record_export([self._record()], profile, Path(tmp) / "export1")
            second = self._record()
            store.apply_checks([second], profile)
            self.assertEqual(second.history_status, "JÁ GERADO")
            self.assertFalse(second.history_blocking)
            self.assertTrue(second.warnings)

    def test_confirmed_history_blocks_but_allows_explicit_override(self):
        from core.history import HistoryStore
        with tempfile.TemporaryDirectory() as tmp:
            store = HistoryStore(Path(tmp) / "history.sqlite3")
            profile = CompanyProfile("PITANPREV", "5", "892", "77")
            output = Path(tmp) / "export1"
            store.record_export([self._record()], profile, output)
            store.confirm_export(output)
            second = self._record()
            store.apply_checks([second], profile)
            self.assertEqual(second.history_status, "CONFIRMADO")
            self.assertTrue(second.history_blocking)
            self.assertTrue(second.history_override_allowed)

    def test_same_pdf_in_other_company_is_blocking_and_not_overridable(self):
        from core.history import HistoryStore
        with tempfile.TemporaryDirectory() as tmp:
            store = HistoryStore(Path(tmp) / "history.sqlite3")
            source_profile = CompanyProfile("Empresa A", "5", "892", "77")
            target_profile = CompanyProfile("Empresa B", "6", "893", "78")
            store.record_export([self._record("c" * 64)], source_profile, Path(tmp) / "export")
            target = self._record("c" * 64)
            store.apply_checks([target], target_profile)
            self.assertEqual(target.history_status, "OUTRA EMPRESA")
            self.assertTrue(target.history_blocking)
            self.assertFalse(target.history_override_allowed)

    def test_same_apr_different_hash_is_revision(self):
        from core.history import HistoryStore
        with tempfile.TemporaryDirectory() as tmp:
            store = HistoryStore(Path(tmp) / "history.sqlite3")
            profile = CompanyProfile("PITANPREV", "5", "892", "77")
            store.record_export([self._record("a" * 64)], profile, Path(tmp) / "export")
            revised = self._record("b" * 64)
            store.apply_checks([revised], profile)
            self.assertEqual(revised.history_status, "POSSÍVEL REVISÃO")
            self.assertFalse(revised.history_blocking)


class BatchTests(unittest.TestCase):
    def test_only_repeated_duplicate_is_marked(self):
        one = APRRecord(pdf=Path("a.pdf"), slug="5226")
        two = APRRecord(pdf=Path("b.pdf"), slug="5226")
        add_batch_duplicate_errors([one, two])
        self.assertFalse(one.errors)
        self.assertTrue(two.errors)

    def test_file_change_is_detected_before_export(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "x.pdf"
            path.write_bytes(b"one")
            st = path.stat()
            row = APRRecord(pdf=path, size_bytes=st.st_size, mtime_ns=st.st_mtime_ns)
            from core.utils import sha256_file
            row.sha256 = sha256_file(path)
            path.write_bytes(b"two-two")
            self.assertTrue(verify_files_unchanged([row]))


class OCRTests(unittest.TestCase):
    SAMPLE_TEXT = (
        "AUTORIZAÇÃO DE APLICAÇÃO E RESGATE - APR\n"
        "Unidade gestora do RPPS: INSTITUTO EXEMPLO\n"
        "CNPJ: 05.360.812/0001-61\n"
        "Nº / ANO: 52/26\n"
        "DATA: 11/06/2026\n"
        "VALOR (R$): 2.215.000,00\n"
        "TIPO DE OPERAÇÃO: Aplicação\n"
    )

    def test_rapidocr_result_parser_old_shape(self):
        from core.ocr import _parse_rapidocr_result
        result = [
            [[[0, 0], [1, 0], [1, 1], [0, 1]], "Nº / ANO: 52/26", 0.95],
            [[[0, 2], [1, 2], [1, 3], [0, 3]], "DATA: 11/06/2026", 0.90],
        ]
        text, confidence = _parse_rapidocr_result(result)
        self.assertIn("52/26", text)
        self.assertGreater(confidence, 0.90)

    def test_ocr_only_number_without_filename_is_blocked(self):
        from core.pdf_reader import PDFContent
        with tempfile.TemporaryDirectory() as tmp:
            pdf = Path(tmp) / "documento.pdf"
            pdf.write_bytes(b"fake")
            profile = CompanyProfile("Teste", "5", "892", "77", cnpj="05.360.812/0001-61")
            content = PDFContent(
                text=self.SAMPLE_TEXT, page_count=1, probably_scanned=False, text_source="OCR",
                ocr_used=True, ocr_provider="RapidOCR 3.x", ocr_confidence=0.95,
            )
            with patch("core.validator.extract_pdf_content", return_value=content):
                row = validate_one(pdf, profile, enable_ocr=True)
            self.assertTrue(any("somente por OCR" in e for e in row.errors))

    def test_high_confidence_ocr_with_filename_is_allowed_with_warning(self):
        from core.pdf_reader import PDFContent
        with tempfile.TemporaryDirectory() as tmp:
            pdf = Path(tmp) / "APR 52.26.pdf"
            pdf.write_bytes(b"fake")
            profile = CompanyProfile("Teste", "5", "892", "77", cnpj="05.360.812/0001-61")
            content = PDFContent(
                text=self.SAMPLE_TEXT, page_count=1, probably_scanned=False, text_source="OCR",
                ocr_used=True, ocr_provider="RapidOCR 3.x", ocr_confidence=0.92,
            )
            with patch("core.validator.extract_pdf_content", return_value=content):
                row = validate_one(pdf, profile, enable_ocr=True)
            self.assertFalse(row.errors)
            self.assertTrue(row.warnings)


class CSVSecurityTests(unittest.TestCase):
    def test_formula_injection_is_neutralized(self):
        self.assertEqual(csv_safe("=HYPERLINK('x')"), "'=HYPERLINK('x')")
        self.assertEqual(csv_safe("@cmd"), "'@cmd")
        self.assertEqual(csv_safe("normal"), "normal")


class RealPDFIntegrationTests(unittest.TestCase):
    def _make_pdf(self, path: Path):
        from pypdf import PdfWriter
        from pypdf.generic import DictionaryObject, NameObject, DecodedStreamObject

        writer = PdfWriter()
        page = writer.add_blank_page(width=595, height=842)
        font = DictionaryObject({
            NameObject("/Type"): NameObject("/Font"),
            NameObject("/Subtype"): NameObject("/Type1"),
            NameObject("/BaseFont"): NameObject("/Helvetica"),
        })
        font_ref = writer._add_object(font)
        resources = DictionaryObject({NameObject("/Font"): DictionaryObject({NameObject("/F1"): font_ref})})
        page[NameObject("/Resources")] = resources
        lines = [
            "AUTORIZACAO DE APLICACAO E RESGATE - APR",
            "Unidade gestora do RPPS: INSTITUTO TESTE",
            "CNPJ: 05.360.812/0001-61",
            "No / ANO: 52/26",
            "DATA: 11/06/2026",
            "TIPO DE OPERACAO: Aplicacao",
        ]
        commands = ["BT", "/F1 11 Tf", "60 780 Td"]
        for idx, line in enumerate(lines):
            escaped = line.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")
            if idx:
                commands.append("0 -18 Td")
            commands.append(f"({escaped}) Tj")
        commands.append("ET")
        stream = DecodedStreamObject()
        stream.set_data("\n".join(commands).encode("latin-1"))
        page[NameObject("/Contents")] = writer._add_object(stream)
        with path.open("wb") as f:
            writer.write(f)

    def test_real_text_pdf_is_parsed(self):
        with tempfile.TemporaryDirectory() as tmp:
            pdf = Path(tmp) / "APR 52.26.pdf"
            self._make_pdf(pdf)
            profile = CompanyProfile("Teste", "5", "892", "77", cnpj="05.360.812/0001-61")
            row = validate_one(pdf, profile, enable_ocr=False)
            self.assertEqual(row.name, "52/26")
            self.assertEqual(row.cnpj, "05.360.812/0001-61")
            self.assertFalse(row.errors, row.errors)


if __name__ == "__main__":
    unittest.main()
