from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import QSize, Qt, QTimer
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import (
    QFrame,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QScrollArea,
    QSpinBox,
    QVBoxLayout,
    QWidget,
)

try:
    from PySide6.QtPdf import QPdfDocument
    _QT_PDF_AVAILABLE = True
except Exception:  # pragma: no cover - depende da distribuição Qt instalada
    QPdfDocument = None  # type: ignore[assignment]
    _QT_PDF_AVAILABLE = False


class PDFPreviewWidget(QWidget):
    """Visualizador leve usando o QtPdf que acompanha o PySide6.

    Não altera o PDF e não depende de navegador externo. Se o módulo QtPdf não
    estiver disponível, o restante do aplicativo continua funcionando.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self._path: Path | None = None
        self._page = 0
        self._zoom = 1.0
        self._fit_width = True
        self._page_count = 0
        self._render_pending = False

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        toolbar = QFrame()
        toolbar.setStyleSheet("QFrame{background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px}")
        tl = QHBoxLayout(toolbar)
        tl.setContentsMargins(6, 4, 6, 4)

        self.prev_btn = QPushButton("◀")
        self.prev_btn.setToolTip("Página anterior")
        self.next_btn = QPushButton("▶")
        self.next_btn.setToolTip("Próxima página")
        self.page_spin = QSpinBox()
        self.page_spin.setMinimum(1)
        self.page_spin.setMaximum(1)
        self.page_spin.setMaximumWidth(70)
        self.page_total = QLabel("/ 0")
        self.zoom_out_btn = QPushButton("−")
        self.zoom_in_btn = QPushButton("+")
        self.fit_btn = QPushButton("Ajustar largura")
        self.zoom_label = QLabel("100%")
        self.zoom_label.setMinimumWidth(48)

        tl.addWidget(self.prev_btn)
        tl.addWidget(self.next_btn)
        tl.addWidget(QLabel("Página"))
        tl.addWidget(self.page_spin)
        tl.addWidget(self.page_total)
        tl.addSpacing(8)
        tl.addWidget(self.zoom_out_btn)
        tl.addWidget(self.zoom_in_btn)
        tl.addWidget(self.fit_btn)
        tl.addWidget(self.zoom_label)
        tl.addStretch(1)
        layout.addWidget(toolbar)

        self.scroll = QScrollArea()
        self.scroll.setAlignment(Qt.AlignCenter)
        self.scroll.setWidgetResizable(False)
        self.image_label = QLabel("Selecione uma APR para visualizar o PDF.")
        self.image_label.setAlignment(Qt.AlignTop | Qt.AlignHCenter)
        self.image_label.setStyleSheet("QLabel{background:white;color:#64748b;padding:12px}")
        self.image_label.setMinimumSize(320, 260)
        self.scroll.setWidget(self.image_label)
        layout.addWidget(self.scroll, 1)

        self.prev_btn.clicked.connect(self.previous_page)
        self.next_btn.clicked.connect(self.next_page)
        self.page_spin.valueChanged.connect(self._page_spin_changed)
        self.zoom_out_btn.clicked.connect(lambda: self.change_zoom(0.85))
        self.zoom_in_btn.clicked.connect(lambda: self.change_zoom(1.18))
        self.fit_btn.clicked.connect(self.fit_width)

        self.document = None
        if _QT_PDF_AVAILABLE:
            self.document = QPdfDocument(self)
            self.document.statusChanged.connect(self._document_status_changed)
        else:
            self.image_label.setText(
                "Visualização interna indisponível nesta instalação do Qt.\n"
                "O PDF ainda pode ser aberto pelo botão 'Abrir PDF selecionado'."
            )

        self._update_controls()

    @property
    def current_path(self) -> Path | None:
        return self._path

    def clear(self):
        self._path = None
        self._page = 0
        self._page_count = 0
        if self.document is not None:
            try:
                self.document.close()
            except Exception:
                pass
        self.image_label.clear()
        self.image_label.setText("Selecione uma APR para visualizar o PDF.")
        self.image_label.adjustSize()
        self._update_controls()

    def load_pdf(self, path: Path | str | None):
        if not path:
            self.clear()
            return
        pdf_path = Path(path)
        if self._path == pdf_path and self._page_count > 0:
            return
        self._path = pdf_path
        self._page = 0
        self._page_count = 0
        self._zoom = 1.0
        self._fit_width = True
        self.image_label.setText(f"Carregando {pdf_path.name}...")
        self.image_label.adjustSize()
        self._update_controls()

        if self.document is None:
            self.image_label.setText(
                f"{pdf_path.name}\n\nVisualização interna indisponível.\n"
                "Use 'Abrir PDF selecionado'."
            )
            return
        if not pdf_path.exists():
            self.image_label.setText("Arquivo PDF não encontrado no disco.")
            return
        try:
            self.document.close()
        except Exception:
            pass
        try:
            self.document.load(str(pdf_path))
            # Em arquivos pequenos o status pode chegar a Ready antes do evento.
            QTimer.singleShot(0, self._refresh_document_state)
        except Exception as exc:
            self.image_label.setText(f"Não foi possível visualizar o PDF:\n{exc}")

    def _refresh_document_state(self):
        if self.document is None:
            return
        try:
            status = self.document.status()
            self._document_status_changed(status)
        except Exception:
            pass

    def _document_status_changed(self, status):
        if self.document is None or not _QT_PDF_AVAILABLE:
            return
        try:
            ready = status == QPdfDocument.Status.Ready
            error = status == QPdfDocument.Status.Error
        except Exception:
            ready = False
            error = False

        if ready:
            self._page_count = max(0, int(self.document.pageCount()))
            self._page = min(self._page, max(0, self._page_count - 1))
            self.page_spin.blockSignals(True)
            self.page_spin.setMaximum(max(1, self._page_count))
            self.page_spin.setValue(self._page + 1)
            self.page_spin.blockSignals(False)
            self._update_controls()
            self.fit_width()
        elif error:
            self._page_count = 0
            self.image_label.setText("QtPdf não conseguiu renderizar este documento.")
            self._update_controls()

    def _update_controls(self):
        has_doc = self._page_count > 0
        self.prev_btn.setEnabled(has_doc and self._page > 0)
        self.next_btn.setEnabled(has_doc and self._page + 1 < self._page_count)
        self.page_spin.setEnabled(has_doc)
        self.zoom_in_btn.setEnabled(has_doc)
        self.zoom_out_btn.setEnabled(has_doc)
        self.fit_btn.setEnabled(has_doc)
        self.page_total.setText(f"/ {self._page_count}")
        self.zoom_label.setText(f"{int(self._zoom * 100)}%")

    def _page_spin_changed(self, value: int):
        if self._page_count <= 0:
            return
        self._page = max(0, min(value - 1, self._page_count - 1))
        self.render_page()

    def previous_page(self):
        if self._page > 0:
            self._page -= 1
            self.page_spin.setValue(self._page + 1)

    def next_page(self):
        if self._page + 1 < self._page_count:
            self._page += 1
            self.page_spin.setValue(self._page + 1)

    def change_zoom(self, multiplier: float):
        if self._page_count <= 0:
            return
        self._fit_width = False
        self._zoom = max(0.25, min(4.0, self._zoom * multiplier))
        self.render_page()

    def fit_width(self):
        if self.document is None or self._page_count <= 0:
            return
        try:
            page_size = self.document.pagePointSize(self._page)
            point_width = float(page_size.width())
            if point_width <= 0:
                return
            base_pixel_width = point_width * (96.0 / 72.0)
            available = max(320, self.scroll.viewport().width() - 28)
            self._zoom = max(0.25, min(4.0, available / base_pixel_width))
            self._fit_width = True
        except Exception:
            self._zoom = 1.0
        self.render_page()

    def render_page(self):
        if self.document is None or self._page_count <= 0:
            return
        if self._render_pending:
            return
        self._render_pending = True
        try:
            page_size = self.document.pagePointSize(self._page)
            width = max(1, int(float(page_size.width()) * (96.0 / 72.0) * self._zoom))
            height = max(1, int(float(page_size.height()) * (96.0 / 72.0) * self._zoom))
            # Limite defensivo para evitar consumo excessivo de memória em PDFs anormais.
            if width > 4200:
                ratio = 4200 / width
                width = 4200
                height = max(1, int(height * ratio))
            if height > 6000:
                ratio = 6000 / height
                height = 6000
                width = max(1, int(width * ratio))
            image = self.document.render(self._page, QSize(width, height))
            if image.isNull():
                self.image_label.setText("Não foi possível renderizar esta página.")
            else:
                self.image_label.setPixmap(QPixmap.fromImage(image))
                self.image_label.resize(image.size())
            self.page_spin.blockSignals(True)
            self.page_spin.setValue(self._page + 1)
            self.page_spin.blockSignals(False)
            self._update_controls()
        except Exception as exc:
            self.image_label.setText(f"Falha ao renderizar a página:\n{exc}")
        finally:
            self._render_pending = False

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if self._fit_width and self._page_count > 0:
            QTimer.singleShot(80, self.fit_width)
