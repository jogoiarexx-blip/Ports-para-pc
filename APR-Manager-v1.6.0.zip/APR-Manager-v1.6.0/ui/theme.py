APP_STYLESHEET = r"""
QMainWindow, QDialog {
    background: #f3f6fb;
    color: #172033;
    font-family: "Segoe UI";
    font-size: 10pt;
}
QWidget { color: #172033; font-family: "Segoe UI"; font-size: 10pt; }
QLabel { background: transparent; }
QMenuBar { background: #ffffff; border-bottom: 1px solid #dfe6f1; }
QMenuBar::item:selected { background: #edf3ff; }
QMenu { background: #ffffff; border: 1px solid #dfe6f1; }
QMenu::item:selected { background: #edf3ff; }
QFrame#hero, QFrame#panel, QFrame#quickPanel, QFrame#summaryCard {
    background: #ffffff;
    border: 1px solid #dfe6f1;
    border-radius: 12px;
}
QFrame#hero { border-radius: 14px; }
QLabel#heroTitle { font-size: 20pt; font-weight: 700; color: #12213f; }
QLabel#heroSubtitle { color: #64748b; font-size: 10pt; }
QLabel#cardTitle { color: #64748b; font-size: 9pt; font-weight: 600; }
QLabel#cardValue { color: #12213f; font-size: 20pt; font-weight: 700; }
QLabel#cardHint { color: #94a3b8; font-size: 8pt; }
QPushButton {
    background: #ffffff;
    border: 1px solid #cfd9e8;
    border-radius: 8px;
    padding: 7px 12px;
    font-weight: 600;
}
QPushButton:hover { background: #f5f8fd; border-color: #9fb3d4; }
QPushButton:pressed { background: #eaf0fa; }
QPushButton:disabled { color: #9aa7b8; background: #f1f4f8; border-color: #e2e8f0; }
QPushButton#primaryButton { background: #2563eb; color: #ffffff; border-color: #2563eb; }
QPushButton#primaryButton:hover { background: #1d4ed8; }
QPushButton#dangerButton { color: #b91c1c; border-color: #fecaca; }
QLineEdit, QComboBox, QPlainTextEdit, QTableWidget, QSpinBox, QListWidget {
    background: #ffffff;
    border: 1px solid #cfd9e8;
    border-radius: 7px;
    padding: 5px;
    selection-background-color: #dbeafe;
    selection-color: #172033;
}
QLineEdit:focus, QComboBox:focus, QPlainTextEdit:focus, QTableWidget:focus, QListWidget:focus {
    border: 1px solid #6b9df5;
}
QTableWidget { gridline-color: #e6ebf2; alternate-background-color: #f8fafc; }
QHeaderView::section {
    background: #eef3f9;
    color: #46556d;
    border: 0;
    border-bottom: 1px solid #d8e0eb;
    padding: 8px 6px;
    font-weight: 700;
}
QProgressBar {
    background: #e9eef6;
    border: 0;
    border-radius: 6px;
    text-align: center;
    min-height: 20px;
}
QProgressBar::chunk { background: #3b82f6; border-radius: 6px; }
QCheckBox { spacing: 7px; }
QStatusBar { background: #ffffff; border-top: 1px solid #dfe6f1; color: #5c6b81; }
QSplitter::handle { background: #dde5f0; }
"""
