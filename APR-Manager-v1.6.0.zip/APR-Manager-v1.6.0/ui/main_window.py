from __future__ import annotations

from pathlib import Path
from copy import deepcopy

from PySide6.QtCore import QObject, QThread, Qt, Signal, Slot, QUrl, QTimer, QDate
from PySide6.QtGui import QAction, QColor, QDesktopServices, QIntValidator
from PySide6.QtWidgets import (
    QAbstractItemView,
    QCheckBox,
    QComboBox,
    QDateEdit,
    QFileDialog,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMessageBox,
    QPlainTextEdit,
    QProgressBar,
    QPushButton,
    QSplitter,
    QStatusBar,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from core.history import HistoryStore
from core.ocr import ocr_available
from core.models import APRRecord, CompanyProfile
from core.profiles import load_profiles, pop_profile_load_warning, save_profiles
from core.reporting import export_package, verify_export_package
from core.validator import (
    add_batch_duplicate_errors, validate_one, validate_profile, validate_profile_for_validation,
    verify_files_unchanged,
)
from core.version import APP_NAME, APP_VERSION
from core.utils import cnpj_is_valid
from .history_dialog import HistoryDialog
from .pdf_preview import PDFPreviewWidget
from .profile_dialog import ProfileDialog
from core.pdf_reader import ExtractionCancelled


class DropArea(QFrame):
    filesDropped = Signal(list)

    def __init__(self):
        super().__init__()
        self.setAcceptDrops(True)
        self.setFrameShape(QFrame.StyledPanel)
        self.setStyleSheet(
            "QFrame{border:2px dashed #9ca3af;border-radius:12px;padding:18px;background:#f8fafc} "
            "QFrame:hover{border-color:#2563eb}"
        )
        layout = QVBoxLayout(self)
        label = QLabel("Arraste PDFs ou uma pasta de APRs aqui")
        label.setAlignment(Qt.AlignCenter)
        label.setStyleSheet("font-size:16px;font-weight:600;border:0;background:transparent")
        sub = QLabel("Também é possível usar os botões abaixo")
        sub.setAlignment(Qt.AlignCenter)
        sub.setStyleSheet("color:#64748b;border:0;background:transparent")
        layout.addWidget(label)
        layout.addWidget(sub)

    @Slot()
    def _validation_thread_finished(self):
        self.worker = None
        self.thread = None

    def set_busy(self, busy: bool):
        self.setAcceptDrops(not busy)
        self.setEnabled(not busy)

    def dragEnterEvent(self, event):
        if self.isEnabled() and event.mimeData().hasUrls():
            event.acceptProposedAction()

    def dropEvent(self, event):
        paths = [Path(url.toLocalFile()) for url in event.mimeData().urls() if url.isLocalFile()]
        self.filesDropped.emit(paths)
        event.acceptProposedAction()


class ValidationWorker(QObject):
    finished = Signal(object)
    failed = Signal(str)
    cancelled = Signal()
    progress = Signal(int, int, str)

    def __init__(
        self,
        paths: list[Path],
        profile: CompanyProfile,
        history_store: HistoryStore | None = None,
        *,
        enable_ocr: bool = True,
        cache: dict | None = None,
        profile_signature: tuple | None = None,
    ):
        super().__init__()
        self.paths = paths
        self.profile = profile
        self.history_store = history_store
        self.enable_ocr = enable_ocr
        self.cache = cache if cache is not None else {}
        self.profile_signature = profile_signature or ()
        self._cancel_requested = False

    def request_cancel(self):
        self._cancel_requested = True

    @Slot()
    def run(self):
        try:
            rows: list[APRRecord] = []
            total = len(self.paths)
            for index, path in enumerate(self.paths, start=1):
                if self._cancel_requested:
                    self.cancelled.emit()
                    return
                self.progress.emit(index - 1, total, path.name)
                try:
                    st = path.stat()
                    key = (str(path.resolve()).casefold(), st.st_mtime_ns, st.st_size, self.profile_signature, self.enable_ocr)
                except OSError:
                    key = (str(path).casefold(), 0, 0, self.profile_signature, self.enable_ocr)
                cached = self.cache.get(key)
                if cached is not None:
                    row = deepcopy(cached)
                else:
                    row = validate_one(
                        path, self.profile, enable_ocr=self.enable_ocr, cancel_check=lambda: self._cancel_requested
                    )
                    self.cache[key] = deepcopy(row)
                rows.append(row)
                self.progress.emit(index, total, path.name)
            if self._cancel_requested:
                self.cancelled.emit()
                return
            add_batch_duplicate_errors(rows)
            if self.history_store is not None:
                self.history_store.apply_checks(rows, self.profile)
            self.finished.emit(rows)
        except ExtractionCancelled:
            self.cancelled.emit()
        except Exception as exc:
            self.failed.emit(str(exc))


class SummaryCard(QFrame):
    def __init__(self, title: str, hint: str = ""):
        super().__init__()
        self.setObjectName("summaryCard")
        box = QVBoxLayout(self)
        box.setContentsMargins(14, 10, 14, 10)
        box.setSpacing(2)
        self.title = QLabel(title)
        self.title.setObjectName("cardTitle")
        self.value = QLabel("0")
        self.value.setObjectName("cardValue")
        self.hint = QLabel(hint)
        self.hint.setObjectName("cardHint")
        box.addWidget(self.title)
        box.addWidget(self.value)
        box.addWidget(self.hint)

    def set_value(self, value: int | str, hint: str | None = None):
        self.value.setText(str(value))
        if hint is not None:
            self.hint.setText(hint)


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(f"{APP_NAME} {APP_VERSION}")
        self.resize(1480, 900)
        self.paths: list[Path] = []
        self.rows: list[APRRecord] = []
        self.profiles = load_profiles()
        self.profile_load_warning = pop_profile_load_warning()
        self.validation_cache: dict = {}
        self.thread: QThread | None = None
        self.worker: ValidationWorker | None = None
        self.last_output_dir: Path | None = None
        self.validation_signature: tuple[str, str, str, str] | None = None
        self._loading_quick_ids = False
        self._quick_ids_dirty = False
        self.history_store: HistoryStore | None = None
        self.history_error = ""
        try:
            self.history_store = HistoryStore()
        except Exception as exc:
            self.history_error = str(exc)

        self._build_ui()
        self._build_menu()
        self._refresh_profiles()
        self._update_summary()
        if self.profile_load_warning:
            QTimer.singleShot(0, lambda: QMessageBox.warning(self, "Perfis recuperados", self.profile_load_warning))

    def _published_mode_changed(self):
        mode = self.published_mode_combo.currentData() if hasattr(self, "published_mode_combo") else "apr"
        self.published_date_edit.setEnabled(mode == "manual")

    def _published_export_settings(self) -> tuple[str, str | None]:
        mode = self.published_mode_combo.currentData() or "apr"
        manual = None
        if mode == "manual":
            manual = self.published_date_edit.date().toString("yyyy-MM-dd")
        return str(mode), manual

    def _build_menu(self):
        menu = self.menuBar().addMenu("Arquivo")
        self.profiles_action = QAction("Perfis de RPPS", self)
        self.profiles_action.triggered.connect(self.manage_profiles)
        menu.addAction(self.profiles_action)
        self.history_action = QAction("Histórico local", self)
        self.history_action.triggered.connect(self.open_history)
        menu.addAction(self.history_action)
        menu.addSeparator()
        self.exit_action = QAction("Sair", self)
        self.exit_action.triggered.connect(self.close)
        menu.addAction(self.exit_action)

    def _build_ui(self):
        root = QWidget()
        self.setCentralWidget(root)
        layout = QVBoxLayout(root)
        layout.setContentsMargins(18, 16, 18, 14)
        layout.setSpacing(10)

        hero = QFrame()
        hero.setObjectName("hero")
        hero_layout = QHBoxLayout(hero)
        hero_layout.setContentsMargins(18, 14, 18, 14)
        hero_text = QVBoxLayout()
        hero_title = QLabel("APR Manager")
        hero_title.setObjectName("heroTitle")
        hero_subtitle = QLabel("Validação, conferência e geração segura de INSERTs de APR")
        hero_subtitle.setObjectName("heroSubtitle")
        hero_text.addWidget(hero_title)
        hero_text.addWidget(hero_subtitle)
        hero_layout.addLayout(hero_text)
        hero_layout.addStretch(1)
        version_label = QLabel(f"v{APP_VERSION}")
        version_label.setStyleSheet("color:#64748b;font-weight:700;padding:6px 10px")
        hero_layout.addWidget(version_label)
        layout.addWidget(hero)

        top = QHBoxLayout()
        top.addWidget(QLabel("Empresa / perfil:"))
        self.profile_combo = QComboBox()
        self.profile_combo.setMinimumWidth(380)
        self.profile_combo.currentIndexChanged.connect(self.profile_changed)
        top.addWidget(self.profile_combo)
        self.profile_btn = QPushButton("Gerenciar perfis")
        self.profile_btn.clicked.connect(self.manage_profiles)
        top.addWidget(self.profile_btn)
        top.addStretch(1)
        self.summary = QLabel()
        self.summary.setStyleSheet("font-weight:600")
        top.addWidget(self.summary)
        layout.addLayout(top)

        # Edição rápida dos IDs usados nos INSERTs. company_id vem do catálogo e fica bloqueado.
        quick = QFrame()
        quick.setObjectName("quickPanel")
        ql = QHBoxLayout(quick)
        ql.addWidget(QLabel("company_id:"))
        self.company_id_edit = QLineEdit()
        self.company_id_edit.setReadOnly(True)
        self.company_id_edit.setMaximumWidth(90)
        self.company_id_edit.setToolTip("Definido pela empresa selecionada no catálogo")
        ql.addWidget(self.company_id_edit)
        ql.addWidget(QLabel("user_id:"))
        self.user_id_edit = QLineEdit()
        self.user_id_edit.setValidator(QIntValidator(0, 2_147_483_647, self))
        self.user_id_edit.setMaximumWidth(130)
        ql.addWidget(self.user_id_edit)
        ql.addWidget(QLabel("transparency_type_detail_id:"))
        self.type_id_edit = QLineEdit()
        self.type_id_edit.setValidator(QIntValidator(0, 2_147_483_647, self))
        self.type_id_edit.setMaximumWidth(160)
        ql.addWidget(self.type_id_edit)
        self.save_ids_btn = QPushButton("Salvar IDs nesta empresa")
        self.save_ids_btn.clicked.connect(self.save_quick_ids)
        ql.addWidget(self.save_ids_btn)
        self.quick_status = QLabel()
        self.quick_status.setMinimumWidth(145)
        ql.addWidget(self.quick_status)
        ql.addStretch(1)
        layout.addWidget(quick)

        export_cfg = QFrame()
        export_cfg.setObjectName("quickPanel")
        ec = QHBoxLayout(export_cfg)
        ec.addWidget(QLabel("published_in:"))
        self.published_mode_combo = QComboBox()
        self.published_mode_combo.addItem("Mesma data da APR", "apr")
        self.published_mode_combo.addItem("Data da exportação", "export")
        self.published_mode_combo.addItem("Data manual", "manual")
        self.published_mode_combo.setToolTip(
            "Define somente o campo published_in do SQL. reference_date continua sendo a data da APR."
        )
        ec.addWidget(self.published_mode_combo)
        self.published_date_edit = QDateEdit()
        self.published_date_edit.setDisplayFormat("dd/MM/yyyy")
        self.published_date_edit.setCalendarPopup(True)
        self.published_date_edit.setDate(QDate.currentDate())
        self.published_date_edit.setEnabled(False)
        self.published_date_edit.setToolTip("Usada apenas quando published_in estiver em Data manual")
        ec.addWidget(self.published_date_edit)
        self.published_help = QLabel("reference_date sempre usa a data encontrada na APR")
        self.published_help.setStyleSheet("color:#64748b")
        ec.addWidget(self.published_help)
        ec.addStretch(1)
        self.published_mode_combo.currentIndexChanged.connect(self._published_mode_changed)
        layout.addWidget(export_cfg)

        cards = QGridLayout()
        cards.setHorizontalSpacing(10)
        self.card_loaded = SummaryCard("Carregadas", "PDFs na lista")
        self.card_new = SummaryCard("Novas", "Ainda não processadas")
        self.card_revision = SummaryCard("Revisões", "Mesmo Nº/ANO, conteúdo novo")
        self.card_processed = SummaryCard("Já processadas", "Bloqueadas pelo histórico")
        self.card_errors = SummaryCard("Erros", "Precisam de correção")
        self.card_ocr = SummaryCard("OCR", "Documentos lidos por OCR")
        for col, card in enumerate([
            self.card_loaded, self.card_new, self.card_revision, self.card_processed, self.card_errors, self.card_ocr
        ]):
            cards.addWidget(card, 0, col)
        layout.addLayout(cards)

        self.user_id_edit.textChanged.connect(self.quick_ids_changed)
        self.type_id_edit.textChanged.connect(self.quick_ids_changed)

        self.drop = DropArea()
        self.drop.setMaximumHeight(105)
        self.drop.filesDropped.connect(self.add_paths)
        layout.addWidget(self.drop)

        actions = QHBoxLayout()
        self.files_btn = QPushButton("Adicionar PDFs")
        self.folder_btn = QPushButton("Adicionar pasta")
        self.remove_btn = QPushButton("Remover selecionados")
        self.clear_btn = QPushButton("Limpar lista")
        self.open_pdf_btn = QPushButton("Abrir PDF selecionado")
        self.history_btn = QPushButton("Histórico")
        self.ocr_checkbox = QCheckBox("OCR automático")
        self.ocr_checkbox.setChecked(True)
        available, ocr_detail = ocr_available()
        self.ocr_checkbox.setToolTip(
            "OCR local para PDFs digitalizados. Nenhum documento é enviado para a internet.\n"
            + (f"Disponível: {ocr_detail}" if available else f"Dependência ainda indisponível: {ocr_detail}")
        )
        self.validate_btn = QPushButton("Validar tudo")
        self.validate_btn.setObjectName("primaryButton")
        self.cancel_btn = QPushButton("Cancelar")
        self.cancel_btn.setObjectName("dangerButton")
        self.cancel_btn.setEnabled(False)
        self.valid_only_checkbox = QCheckBox("SQL apenas das válidas")
        self.valid_only_checkbox.setToolTip("Mantém o relatório completo, mas inclui no SQL somente APRs sem erro/bloqueio.")
        self.export_btn = QPushButton("Gerar SQL + relatórios")
        self.export_btn.setObjectName("primaryButton")
        self.reexport_btn = QPushButton("Reexportar mesmo assim")
        self.reexport_btn.setToolTip("Permite reexportar APR já CONFIRMADA para a mesma empresa, após confirmação explícita.")
        self.reexport_btn.setEnabled(False)
        self.confirm_btn = QPushButton("Confirmar SQL executado")
        self.confirm_btn.setEnabled(False)
        self.open_output_btn = QPushButton("Abrir saída")
        self.verify_output_btn = QPushButton("Verificar pacote")
        self.verify_output_btn.setToolTip("Confere os SHA-256 do último pacote exportado.")
        self.verify_output_btn.setEnabled(False)
        self.export_btn.setEnabled(False)
        self.open_output_btn.setEnabled(False)
        actions.addWidget(self.files_btn)
        actions.addWidget(self.folder_btn)
        actions.addWidget(self.remove_btn)
        actions.addWidget(self.clear_btn)
        actions.addWidget(self.open_pdf_btn)
        actions.addWidget(self.history_btn)
        actions.addWidget(self.ocr_checkbox)
        actions.addWidget(self.valid_only_checkbox)
        actions.addStretch(1)
        actions.addWidget(self.cancel_btn)
        actions.addWidget(self.validate_btn)
        actions.addWidget(self.export_btn)
        actions.addWidget(self.reexport_btn)
        actions.addWidget(self.confirm_btn)
        actions.addWidget(self.open_output_btn)
        actions.addWidget(self.verify_output_btn)
        layout.addLayout(actions)

        self.files_btn.clicked.connect(self.pick_files)
        self.folder_btn.clicked.connect(self.pick_folder)
        self.remove_btn.clicked.connect(self.remove_selected)
        self.clear_btn.clicked.connect(self.clear_all)
        self.open_pdf_btn.clicked.connect(self.open_selected_pdf)
        self.history_btn.clicked.connect(self.open_history)
        self.ocr_checkbox.stateChanged.connect(self.ocr_setting_changed)
        self.cancel_btn.clicked.connect(self.cancel_validation)
        self.validate_btn.clicked.connect(self.start_validation)
        self.export_btn.clicked.connect(lambda: self.export_results(False))
        self.reexport_btn.clicked.connect(lambda: self.export_results(True))
        self.confirm_btn.clicked.connect(self.confirm_last_export)
        self.open_output_btn.clicked.connect(self.open_output)
        self.verify_output_btn.clicked.connect(self.verify_last_output)

        self.progress = QProgressBar()
        self.progress.setRange(0, 1)
        self.progress.setValue(0)
        self.progress.setTextVisible(True)
        self.progress.setFormat("Pronto")
        layout.addWidget(self.progress)

        filter_bar = QHBoxLayout()
        filter_bar.addWidget(QLabel("Filtrar:"))
        self.search_edit = QLineEdit()
        self.search_edit.setPlaceholderText("arquivo, nº/ano, CNPJ, unidade, mensagem...")
        self.search_edit.textChanged.connect(self.apply_filters)
        filter_bar.addWidget(self.search_edit, 1)
        self.status_filter = QComboBox()
        self.status_filter.addItems(["Todos", "OK", "AVISO", "ERRO", "PENDENTE"])
        self.status_filter.currentTextChanged.connect(self.apply_filters)
        filter_bar.addWidget(self.status_filter)
        layout.addLayout(filter_bar)

        splitter = QSplitter(Qt.Vertical)
        layout.addWidget(splitter, 1)

        self.table = QTableWidget(0, 13)
        self.table.setHorizontalHeaderLabels([
            "Status", "Arquivo", "Nº/ANO arquivo", "Nº/ANO PDF", "Data", "CNPJ",
            "Valor", "Operação", "Unidade gestora", "Fonte", "Histórico", "Caminho no banco", "Mensagem"
        ])
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.verticalHeader().setVisible(False)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(8, QHeaderView.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(9, QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(10, QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(11, QHeaderView.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(12, QHeaderView.Stretch)
        self.table.setAlternatingRowColors(True)
        self.table.itemSelectionChanged.connect(self.show_details)
        self.table.itemDoubleClicked.connect(lambda _item: self.open_selected_pdf())
        splitter.addWidget(self.table)

        lower = QSplitter(Qt.Horizontal)
        self.pdf_preview = PDFPreviewWidget()
        lower.addWidget(self.pdf_preview)

        self.details = QPlainTextEdit()
        self.details.setReadOnly(True)
        self.details.setPlaceholderText("Selecione uma APR para ver os detalhes e o texto extraído do PDF.")
        lower.addWidget(self.details)
        lower.setSizes([760, 520])
        splitter.addWidget(lower)
        splitter.setSizes([500, 360])

        self.setStatusBar(QStatusBar())
        self.statusBar().showMessage("Pronto")

    def current_profile(self) -> CompanyProfile | None:
        idx = self.profile_combo.currentIndex()
        if idx < 0 or idx >= len(self.profiles):
            return None
        p = self.profiles[idx]
        # Os dois IDs podem ser alterados na hora sem precisar abrir o editor completo.
        p.user_id = self.user_id_edit.text().strip()
        p.transparency_type_detail_id = self.type_id_edit.text().strip()
        return p

    @staticmethod
    def _profile_validation_signature(profile: CompanyProfile) -> tuple[str, str, str, str]:
        """Campos que afetam leitura/validação e o caminho file_db."""
        return (
            profile.company_id.strip(),
            profile.cnpj.strip(),
            profile.unit_name.strip(),
            profile.file_template.strip(),
        )

    def _refresh_profiles(self):
        current_id = self.profile_combo.currentData()
        self.profile_combo.blockSignals(True)
        self.profile_combo.clear()
        for p in self.profiles:
            pending = "" if not validate_profile(p) else " [PENDENTE]"
            self.profile_combo.addItem(f"ID {p.company_id} — {p.name}{pending}", p.company_id)
        if current_id:
            idx = self.profile_combo.findData(current_id)
            if idx >= 0:
                self.profile_combo.setCurrentIndex(idx)
        self.profile_combo.blockSignals(False)
        self.profile_changed(self.profile_combo.currentIndex())
        self.validate_btn.setEnabled(bool(self.profiles) and bool(self.paths))

    @Slot(int)
    def profile_changed(self, _index: int):
        profile = None
        idx = self.profile_combo.currentIndex()
        if 0 <= idx < len(self.profiles):
            profile = self.profiles[idx]

        self._loading_quick_ids = True
        try:
            self.company_id_edit.setText(profile.company_id if profile else "")
            self.user_id_edit.setText(profile.user_id if profile else "")
            self.type_id_edit.setText(profile.transparency_type_detail_id if profile else "")
        finally:
            self._loading_quick_ids = False
        self._quick_ids_dirty = False
        self._update_quick_status()

        # Trocar de empresa torna uma validação anterior insegura, pois CNPJ e file_db
        # pertencem ao perfil usado na validação.
        if self.rows and profile and self.validation_signature != self._profile_validation_signature(profile):
            self.invalidate_validation("Empresa/perfil alterado. Valide os PDFs novamente.")

    @Slot(str)
    def quick_ids_changed(self, _value: str):
        if self._loading_quick_ids:
            return
        idx = self.profile_combo.currentIndex()
        if 0 <= idx < len(self.profiles):
            self.profiles[idx].user_id = self.user_id_edit.text().strip()
            self.profiles[idx].transparency_type_detail_id = self.type_id_edit.text().strip()
            self._quick_ids_dirty = True
        self._update_quick_status()

    def _update_quick_status(self):
        p = self.current_profile()
        if not p:
            self.quick_status.setText("Sem empresa")
            self.quick_status.setStyleSheet("color:#991b1b;font-weight:600")
            return
        errors = validate_profile(p)
        if errors:
            self.quick_status.setText("Perfil pendente")
            self.quick_status.setStyleSheet("color:#b45309;font-weight:600")
        elif self._quick_ids_dirty:
            self.quick_status.setText("Pronto • não salvo")
            self.quick_status.setStyleSheet("color:#1d4ed8;font-weight:600")
        else:
            self.quick_status.setText("Pronto")
            self.quick_status.setStyleSheet("color:#166534;font-weight:600")

    def save_quick_ids(self):
        p = self.current_profile()
        if not p:
            return
        errors = validate_profile_for_validation(p)
        if errors:
            QMessageBox.warning(self, "IDs inválidos", "\n".join(f"• {e}" for e in errors))
            return
        try:
            save_profiles(self.profiles)
            self._quick_ids_dirty = False
            self._update_quick_status()
            self._refresh_profile_label_only()
            self.statusBar().showMessage(f"IDs salvos para {p.name}", 4000)
        except Exception as exc:
            QMessageBox.critical(self, "Falha ao salvar", str(exc))

    def _refresh_profile_label_only(self):
        idx = self.profile_combo.currentIndex()
        if not (0 <= idx < len(self.profiles)):
            return
        p = self.profiles[idx]
        pending = "" if not validate_profile(p) else " [PENDENTE]"
        self.profile_combo.setItemText(idx, f"ID {p.company_id} — {p.name}{pending}")

    def manage_profiles(self):
        before = self.current_profile()
        old_sig = self._profile_validation_signature(before) if before else None
        dlg = ProfileDialog(self.profiles, self)
        dlg.exec()
        self._refresh_profiles()
        after = self.current_profile()
        new_sig = self._profile_validation_signature(after) if after else None
        if self.rows and old_sig != new_sig:
            self.invalidate_validation("Dados do perfil alterados. Valide os PDFs novamente.")

    def collect_from_paths(self, items: list[Path]) -> list[Path]:
        out: list[Path] = []
        for p in items:
            if p.is_file() and p.suffix.lower() == ".pdf":
                out.append(p.resolve())
            elif p.is_dir():
                out.extend(x.resolve() for x in p.glob("*.pdf"))
        return out

    @Slot(list)
    def add_paths(self, items: list[Path]):
        if self.thread is not None and self.thread.isRunning():
            self.statusBar().showMessage("Aguarde ou cancele a validação antes de alterar a lista.", 5000)
            return
        found = self.collect_from_paths(items)
        if not found:
            self.statusBar().showMessage("Nenhum PDF válido foi adicionado; a validação atual foi preservada.", 5000)
            return
        existing = {str(p).casefold() for p in self.paths}
        for p in found:
            if str(p).casefold() not in existing:
                self.paths.append(p)
                existing.add(str(p).casefold())
        self.paths.sort(key=lambda p: p.name.casefold())
        self.rows = []
        self.validation_signature = None
        self.render_pending()
        self.export_btn.setEnabled(False)
        self.reexport_btn.setEnabled(False)
        self.confirm_btn.setEnabled(False)
        self.validate_btn.setEnabled(bool(self.profiles) and bool(self.paths))
        self._update_summary()

    def pick_files(self):
        names, _ = QFileDialog.getOpenFileNames(self, "Selecionar APRs", "", "PDF (*.pdf)")
        if names:
            self.add_paths([Path(x) for x in names])

    def pick_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "Selecionar pasta de APRs")
        if folder:
            self.add_paths([Path(folder)])

    def render_pending(self):
        self.table.setRowCount(len(self.paths))
        for i, p in enumerate(self.paths):
            values = ["PENDENTE", p.name, "", "", "", "", "", "", "", "—", "—", "", "Aguardando validação"]
            for c, value in enumerate(values):
                self.table.setItem(i, c, QTableWidgetItem(value))
        self.apply_filters()

    def remove_selected(self):
        selected = sorted({idx.row() for idx in self.table.selectionModel().selectedRows()}, reverse=True)
        for row in selected:
            if row < len(self.paths):
                del self.paths[row]
        self.rows = []
        self.validation_signature = None
        self.render_pending()
        self.export_btn.setEnabled(False)
        self.reexport_btn.setEnabled(False)
        self.confirm_btn.setEnabled(False)
        self._update_summary()

    def clear_all(self):
        self.paths.clear()
        self.rows.clear()
        self.validation_signature = None
        self.table.setRowCount(0)
        self.details.clear()
        self.pdf_preview.clear()
        self.export_btn.setEnabled(False)
        self.reexport_btn.setEnabled(False)
        self.confirm_btn.setEnabled(False)
        self.validate_btn.setEnabled(False)
        self._update_summary()

    def invalidate_validation(self, message: str):
        self.rows = []
        self.validation_signature = None
        self.render_pending()
        self.export_btn.setEnabled(False)
        self.reexport_btn.setEnabled(False)
        self.confirm_btn.setEnabled(False)
        self.statusBar().showMessage(message, 7000)
        self._update_summary()

    @Slot(int)
    def ocr_setting_changed(self, _state: int):
        if self.rows:
            self.invalidate_validation("Configuração de OCR alterada. Valide os PDFs novamente.")
        mode = "ativado" if self.ocr_checkbox.isChecked() else "desativado"
        self.statusBar().showMessage(f"OCR automático {mode}", 4000)

    def cancel_validation(self):
        if self.worker is not None:
            self.worker.request_cancel()
            self.cancel_btn.setEnabled(False)
            self.progress.setFormat("Cancelando após o PDF atual...")
            self.statusBar().showMessage("Cancelando validação...")

    def start_validation(self):
        profile = self.current_profile()
        if not profile:
            QMessageBox.warning(self, "Perfil", "Selecione uma empresa primeiro.")
            return
        errors = validate_profile_for_validation(profile)
        if errors:
            QMessageBox.warning(
                self,
                "Complete os IDs",
                "Antes de validar, informe na tela principal:\n\n" + "\n".join(f"• {e}" for e in errors),
            )
            return
        if not self.paths:
            return

        self.validation_signature = self._profile_validation_signature(profile)
        self.rows = []
        self.render_pending()
        self._update_summary()
        self.set_busy(True)
        self.thread = QThread(self)
        self.worker = ValidationWorker(
            list(self.paths), profile, self.history_store, enable_ocr=self.ocr_checkbox.isChecked(),
            cache=self.validation_cache, profile_signature=self._profile_validation_signature(profile),
        )
        self.worker.moveToThread(self.thread)
        self.thread.started.connect(self.worker.run)
        self.worker.progress.connect(self.validation_progress)
        self.worker.finished.connect(self.validation_finished)
        self.worker.failed.connect(self.validation_failed)
        self.worker.cancelled.connect(self.validation_cancelled)
        self.worker.finished.connect(self.thread.quit)
        self.worker.failed.connect(self.thread.quit)
        self.worker.cancelled.connect(self.thread.quit)
        self.thread.finished.connect(self._validation_thread_finished)
        self.thread.finished.connect(self.thread.deleteLater)
        self.thread.start()

    @Slot()
    def _validation_thread_finished(self):
        self.worker = None
        self.thread = None

    def set_busy(self, busy: bool):
        widgets = [
            self.files_btn, self.folder_btn, self.remove_btn, self.clear_btn, self.validate_btn,
            self.profile_btn, self.profile_combo, self.company_id_edit, self.user_id_edit,
            self.type_id_edit, self.save_ids_btn, self.ocr_checkbox, self.history_btn,
            self.open_pdf_btn, self.valid_only_checkbox, self.published_mode_combo, self.published_date_edit,
        ]
        for w in widgets:
            w.setEnabled(not busy)
        self.drop.set_busy(busy)
        self.profiles_action.setEnabled(not busy)
        self.history_action.setEnabled(not busy)
        self.cancel_btn.setEnabled(busy)
        self.verify_output_btn.setEnabled((not busy) and self.last_output_dir is not None)
        self.export_btn.setEnabled(False if busy else bool(self.rows))
        if busy:
            self.reexport_btn.setEnabled(False)
            self.confirm_btn.setEnabled(False)
        if busy:
            self.progress.setRange(0, max(1, len(self.paths)))
            self.progress.setValue(0)
            self.progress.setFormat("Iniciando validação...")
            self.statusBar().showMessage("Validando PDFs...")
        else:
            self.progress.setRange(0, max(1, len(self.paths)))
            self.progress.setValue(len(self.paths) if self.rows else 0)
            self.progress.setFormat("Concluído" if self.rows else "Pronto")

    @Slot(int, int, str)
    def validation_progress(self, current: int, total: int, filename: str):
        self.progress.setRange(0, max(1, total))
        self.progress.setValue(current)
        self.progress.setFormat(f"{current}/{total} • {filename}")
        self.statusBar().showMessage(f"Validando {current}/{total}: {filename}")

    @Slot(object)
    def validation_finished(self, rows):
        self.rows = list(rows)
        self.set_busy(False)
        self.render_rows()
        self._update_summary()
        has_errors = any(r.status == "ERRO" for r in self.rows)
        self.export_btn.setEnabled(bool(self.rows))
        self.reexport_btn.setEnabled(any(r.history_override_allowed for r in self.rows))
        self.confirm_btn.setEnabled(False)
        self.progress.setValue(len(self.rows))
        self.progress.setFormat(f"{len(self.rows)}/{len(self.rows)} • concluído")
        self.statusBar().showMessage("Validação concluída" if not has_errors else "Validação concluída com erros")

    @Slot()
    def validation_cancelled(self):
        self.rows = []
        self.validation_signature = None
        self.set_busy(False)
        self.export_btn.setEnabled(False)
        self.reexport_btn.setEnabled(False)
        self.confirm_btn.setEnabled(False)
        self.render_pending()
        self._update_summary()
        self.progress.setValue(0)
        self.progress.setFormat("Validação cancelada")
        self.statusBar().showMessage("Validação cancelada", 5000)

    @Slot(str)
    def validation_failed(self, message: str):
        self.set_busy(False)
        self.validation_signature = None
        self.export_btn.setEnabled(False)
        self.reexport_btn.setEnabled(False)
        self.confirm_btn.setEnabled(False)
        QMessageBox.critical(self, "Erro na validação", message)
        self.statusBar().showMessage("Falha na validação")

    def render_rows(self):
        self.table.setRowCount(len(self.rows))
        for i, r in enumerate(self.rows):
            values = [
                r.status,
                r.pdf.name,
                r.filename_number.display if r.filename_number else "",
                r.pdf_number.display if r.pdf_number else "",
                r.apr_date.strftime("%d/%m/%Y") if r.apr_date else "",
                r.cnpj,
                r.amount,
                r.operation_type,
                r.unit_name,
                (f"OCR {int(round(r.ocr_confidence * 100))}%" if r.ocr_used else "PDF"),
                r.history_status or "NOVO",
                r.file_db,
                r.messages,
            ]
            for c, value in enumerate(values):
                item = QTableWidgetItem(value)
                if c == 0:
                    if r.status == "ERRO":
                        item.setBackground(QColor("#fee2e2"))
                        item.setForeground(QColor("#991b1b"))
                    elif r.status == "AVISO":
                        item.setBackground(QColor("#fef3c7"))
                        item.setForeground(QColor("#92400e"))
                    else:
                        item.setBackground(QColor("#dcfce7"))
                        item.setForeground(QColor("#166534"))
                elif c == 10:
                    if r.history_status in {"JÁ PROCESSADO", "OUTRA EMPRESA"}:
                        item.setBackground(QColor("#fee2e2"))
                        item.setForeground(QColor("#991b1b"))
                    elif r.history_status == "POSSÍVEL REVISÃO":
                        item.setBackground(QColor("#fef3c7"))
                        item.setForeground(QColor("#92400e"))
                self.table.setItem(i, c, item)
        self.apply_filters()

    def apply_filters(self):
        text = self.search_edit.text().strip().casefold() if hasattr(self, "search_edit") else ""
        status = self.status_filter.currentText() if hasattr(self, "status_filter") else "Todos"
        for row in range(self.table.rowCount()):
            row_status = self.table.item(row, 0).text() if self.table.item(row, 0) else ""
            combined = " ".join(
                self.table.item(row, col).text() for col in range(self.table.columnCount()) if self.table.item(row, col)
            ).casefold()
            visible = (status == "Todos" or row_status == status) and (not text or text in combined)
            self.table.setRowHidden(row, not visible)

    def _update_summary(self):
        loaded = len(self.paths)
        if not self.rows:
            self.summary.setText(f"{loaded} PDF(s) carregado(s)")
            self.card_loaded.set_value(loaded)
            self.card_new.set_value(loaded if loaded else 0, "Aguardando validação" if loaded else "PDFs na lista")
            self.card_revision.set_value(0)
            self.card_processed.set_value(0)
            self.card_errors.set_value(0)
            self.card_ocr.set_value(0)
            return

        ok = sum(r.status == "OK" for r in self.rows)
        warn = sum(r.status == "AVISO" for r in self.rows)
        err = sum(r.status == "ERRO" for r in self.rows)
        new_count = sum((r.history_status or "NOVO") == "NOVO" for r in self.rows)
        revisions = sum(r.history_status == "POSSÍVEL REVISÃO" for r in self.rows)
        processed = sum(r.history_status == "JÁ PROCESSADO" for r in self.rows)
        ocr_count = sum(r.ocr_used for r in self.rows)

        self.summary.setText(f"Total {len(self.rows)}  •  OK {ok}  •  Avisos {warn}  •  Erros {err}")
        self.card_loaded.set_value(len(self.rows), "Documentos validados")
        self.card_new.set_value(new_count, "Ainda não processadas")
        self.card_revision.set_value(revisions)
        self.card_processed.set_value(processed)
        self.card_errors.set_value(err)
        self.card_ocr.set_value(ocr_count, "Texto recuperado localmente")

    def show_details(self):
        selected = self.table.selectionModel().selectedRows()
        if not selected:
            return
        idx = selected[0].row()
        if idx >= len(self.rows):
            if idx < len(self.paths):
                self.details.setPlainText(str(self.paths[idx]))
                self.pdf_preview.load_pdf(self.paths[idx])
            return
        r = self.rows[idx]
        self.pdf_preview.load_pdf(r.pdf)
        header = [
            f"Arquivo: {r.pdf}",
            f"Status: {r.status}",
            f"SHA-256: {r.sha256}",
            f"Páginas: {r.page_count}",
            f"Fonte do texto: {r.text_source}",
            f"OCR: {'sim' if r.ocr_used else 'não'}",
            f"Provedor OCR: {r.ocr_provider or '-'}",
            f"Confiança OCR: {int(round(r.ocr_confidence * 100)) if r.ocr_used else '-'}{'%' if r.ocr_used else ''}",
            f"Tamanho: {r.size_bytes} bytes",
            f"Nº/ANO: {r.name or '-'}",
            f"Data: {r.apr_date.strftime('%d/%m/%Y') if r.apr_date else '-'}",
            f"CNPJ: {r.cnpj or '-'}",
            f"Unidade: {r.unit_name or '-'}",
            f"Caminho: {r.file_db or '-'}",
            f"Histórico: {r.history_status or 'NOVO'}",
            f"Detalhe histórico: {r.history_message or '-'}",
            "",
            "ERROS:", *(f"• {x}" for x in r.errors),
            "",
            "AVISOS:", *(f"• {x}" for x in r.warnings),
            "",
            "TEXTO EXTRAÍDO:",
            r.extracted_text,
        ]
        self.details.setPlainText("\n".join(header))

    def selected_pdf_path(self) -> Path | None:
        selected = self.table.selectionModel().selectedRows()
        if not selected:
            return None
        idx = selected[0].row()
        if self.rows and idx < len(self.rows):
            return self.rows[idx].pdf
        if idx < len(self.paths):
            return self.paths[idx]
        return None

    def open_selected_pdf(self):
        path = self.selected_pdf_path()
        if not path:
            QMessageBox.information(self, "Abrir PDF", "Selecione uma APR na tabela.")
            return
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(path)))

    def _learn_cnpj_if_needed(self, profile: CompanyProfile) -> bool:
        if profile.cnpj:
            return True
        candidates = sorted({r.cnpj for r in self.rows if r.cnpj and not r.errors and cnpj_is_valid(r.cnpj)})
        if len(candidates) != 1:
            QMessageBox.warning(
                self,
                "CNPJ obrigatório",
                "O CNPJ do perfil ainda não foi confirmado e não foi possível aprender um único CNPJ com segurança. "
                "Abra Perfis de RPPS e informe o CNPJ correto antes de gerar SQL.",
            )
            return False
        cnpj = candidates[0]
        if QMessageBox.question(
            self,
            "Confirmar CNPJ da empresa",
            f"O perfil '{profile.name}' ainda não possui CNPJ.\n\n"
            f"Todas as APRs válidas apontam para: {cnpj}\n\n"
            "Confirmar e salvar este CNPJ para esta empresa?",
        ) != QMessageBox.Yes:
            return False
        profile.cnpj = cnpj
        try:
            save_profiles(self.profiles)
        except Exception as exc:
            QMessageBox.critical(self, "CNPJ", f"Não foi possível salvar o CNPJ no perfil:\n{exc}")
            return False
        # Os PDFs já foram lidos e todos os CNPJs válidos coincidem; atualizamos a assinatura
        # sem obrigar uma segunda extração/OCR desnecessária.
        self.validation_signature = self._profile_validation_signature(profile)
        self._refresh_profile_label_only()
        return True

    def _sql_rows_for_export(self, allow_history_override: bool) -> list[APRRecord]:
        candidates: list[APRRecord] = []
        for row in self.rows:
            if row.errors:
                continue
            if row.history_blocking and not (allow_history_override and row.history_override_allowed):
                continue
            candidates.append(row)
        if self.valid_only_checkbox.isChecked():
            return candidates
        # Sem a opção "apenas válidas", qualquer erro/bloqueio impede o SQL inteiro.
        if len(candidates) != len(self.rows):
            return []
        return candidates

    def export_results(self, allow_history_override: bool = False):
        if not self.rows:
            return
        profile = self.current_profile()
        if not profile:
            return
        if not self._learn_cnpj_if_needed(profile):
            return
        profile_errors = validate_profile(profile)
        if profile_errors:
            QMessageBox.warning(self, "Perfil incompleto", "\n".join(f"• {e}" for e in profile_errors))
            return
        if self.validation_signature != self._profile_validation_signature(profile):
            QMessageBox.warning(
                self, "Validação desatualizada",
                "Os dados da empresa que afetam a validação foram alterados. Valide os PDFs novamente.",
            )
            self.export_btn.setEnabled(False)
            return

        if allow_history_override:
            overridable = [r for r in self.rows if r.history_override_allowed]
            if not overridable:
                QMessageBox.information(self, "Reexportar", "Não há APR confirmada elegível para reexportação.")
                return
            if QMessageBox.question(
                self, "Reexportação excepcional",
                "Você está prestes a reexportar uma APR que já foi marcada como CONFIRMADA no histórico local.\n\n"
                "O SQL é idempotente e tentará não duplicar a APR ativa, mas confirme apenas se realmente precisa gerar o pacote novamente.\n\nContinuar?",
            ) != QMessageBox.Yes:
                return

        sql_rows = self._sql_rows_for_export(allow_history_override)
        published_mode, published_date = self._published_export_settings()
        identity_errors = verify_files_unchanged(sql_rows or [r for r in self.rows if not r.errors])
        if identity_errors:
            QMessageBox.critical(
                self, "Arquivos alterados após a validação",
                "A exportação foi bloqueada porque arquivos mudaram após a validação:\n\n" + "\n".join(f"• {e}" for e in identity_errors),
            )
            self.invalidate_validation("Arquivos alterados. Valide novamente.")
            return

        ok = sum(r.status == "OK" for r in self.rows)
        warn = sum(r.status == "AVISO" for r in self.rows)
        err = sum(r.status == "ERRO" for r in self.rows)
        sql_note = f"SQL: {len(sql_rows)} APR(s)" if sql_rows else "SQL ficará bloqueado; somente relatórios serão gerados"
        message = (
            f"Empresa: {profile.name}\ncompany_id: {profile.company_id}\nuser_id: {profile.user_id}\n"
            f"transparency_type_detail_id: {profile.transparency_type_detail_id}\nCNPJ: {profile.cnpj}\n\n"
            f"APRs: {len(self.rows)} | OK: {ok} | Avisos: {warn} | Erros: {err}\n{sql_note}\n"
            f"published_in: {self.published_mode_combo.currentText()}"
            + (f" ({self.published_date_edit.date().toString('dd/MM/yyyy')})" if published_mode == "manual" else "")
            + "\n\nContinuar?"
        )
        if QMessageBox.question(self, "Conferência antes da exportação", message) != QMessageBox.Yes:
            return

        folder = QFileDialog.getExistingDirectory(self, "Pasta-base para salvar a nova exportação")
        if not folder:
            return
        try:
            result = export_package(
                Path(folder), self.rows, profile, sql_rows=sql_rows, allow_history_override=allow_history_override,
                published_in_mode=published_mode, published_in_date=published_date,
            )
            out_dir = result["output_dir"]
            self.last_output_dir = out_dir
            self.open_output_btn.setEnabled(True)
            self.verify_output_btn.setEnabled(True)
            if sql_rows:
                for row in sql_rows:
                    row.export_status = "GERADO"
                history_warning = ""
                history_recorded = False
                if self.history_store is not None:
                    try:
                        self.history_store.record_export(sql_rows, profile, out_dir)
                        history_recorded = True
                    except Exception as hist_exc:
                        history_warning = (
                            "\n\nATENÇÃO: o pacote foi criado, mas não foi possível registrar o histórico local: "
                            f"{hist_exc}"
                        )
                self.confirm_btn.setEnabled(history_recorded)
                self.statusBar().showMessage(
                    "Pacote gerado. Confirme o SQL somente depois de executá-lo no banco."
                    if history_recorded else
                    "Pacote gerado, mas houve falha ao registrar o histórico local.",
                    8000,
                )
                QMessageBox.information(
                    self, "Exportação concluída",
                    f"Nova pasta de exportação criada em:\n{out_dir}\n\n"
                    "O pacote inclui CHECKSUMS.sha256 para conferência de integridade.\n\n"
                    + (
                        "O histórico está como GERADO. Depois de executar o SQL com sucesso, clique em 'Confirmar SQL executado'."
                        if history_recorded else
                        "Os arquivos foram gerados, mas o histórico local NÃO foi atualizado. Não descarte esta pasta."
                    )
                    + history_warning,
                )
            else:
                QMessageBox.warning(
                    self, "Relatórios gerados — SQL bloqueado",
                    f"CSV, HTML e manifest foram criados em:\n{out_dir}\n\nO SQL não foi criado porque há erros/bloqueios.",
                )
            self.render_rows()
        except Exception as exc:
            QMessageBox.critical(self, "Falha ao exportar", str(exc))

    def verify_last_output(self):
        if self.last_output_dir is None:
            QMessageBox.information(self, "Verificar pacote", "Nenhum pacote foi exportado nesta sessão.")
            return
        try:
            ok, messages = verify_export_package(self.last_output_dir)
            if ok:
                QMessageBox.information(
                    self, "Pacote íntegro",
                    "A verificação SHA-256 foi concluída com sucesso.\n\n" + "\n".join(messages),
                )
                self.statusBar().showMessage("Pacote exportado íntegro", 5000)
            else:
                QMessageBox.critical(
                    self, "Pacote alterado",
                    "A verificação encontrou problemas:\n\n" + "\n".join(f"• {m}" for m in messages),
                )
                self.statusBar().showMessage("Falha na integridade do pacote", 5000)
        except Exception as exc:
            QMessageBox.critical(self, "Verificar pacote", str(exc))

    def confirm_last_export(self):
        if self.history_store is None or self.last_output_dir is None:
            return
        if QMessageBox.question(
            self, "Confirmar execução",
            "Confirme somente se o arquivo SQL desta última exportação foi executado com sucesso no banco.\n\nMarcar como CONFIRMADO?",
        ) != QMessageBox.Yes:
            return
        try:
            count = self.history_store.confirm_export(self.last_output_dir)
            for row in self.rows:
                if row.export_status == "GERADO":
                    row.export_status = "CONFIRMADO"
                    row.history_status = "CONFIRMADO"
                    row.history_message = "Execução do SQL confirmada pelo usuário"
                    row.history_blocking = True
                    row.history_override_allowed = True
            self.confirm_btn.setEnabled(False)
            self.reexport_btn.setEnabled(any(r.history_override_allowed for r in self.rows))
            self.render_rows()
            QMessageBox.information(self, "Histórico", f"{count} APR(s) marcadas como CONFIRMADAS.")
        except Exception as exc:
            QMessageBox.critical(self, "Histórico", str(exc))

    def closeEvent(self, event):
        if self.thread is not None and self.thread.isRunning():
            QMessageBox.information(
                self, "Validação em andamento",
                "A validação/OCR ainda está em execução. Clique em Cancelar e aguarde o encerramento antes de fechar o APR Manager.",
            )
            event.ignore()
            return
        event.accept()

    def open_history(self):
        if self.history_store is None:
            QMessageBox.warning(
                self,
                "Histórico indisponível",
                "Não foi possível inicializar o histórico local.\n\n" + (self.history_error or "Erro desconhecido"),
            )
            return
        dlg = HistoryDialog(self.history_store, self)
        dlg.exec()

    def open_output(self):
        if self.last_output_dir and self.last_output_dir.exists():
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(self.last_output_dir)))
