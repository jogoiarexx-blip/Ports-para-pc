#!/usr/bin/env python3
from __future__ import annotations

import argparse
import sys
from pathlib import Path

from core.history import HistoryStore
from core.models import CompanyProfile
from core.profiles import load_profiles
from core.reporting import export_package, verify_export_package
from core.validator import validate_batch, validate_profile, verify_files_unchanged


def collect_pdfs(path: Path, recursive: bool) -> list[Path]:
    if path.is_file():
        return [path] if path.suffix.lower() == ".pdf" else []
    if not path.is_dir():
        return []
    pattern = "**/*.pdf" if recursive else "*.pdf"
    return sorted(path.glob(pattern), key=lambda p: p.name.casefold())


def profile_from_args(args) -> CompanyProfile | None:
    if args.profile_id:
        profiles = load_profiles()
        found = next((p for p in profiles if p.company_id == args.profile_id), None)
        if found is None:
            print(f"ERRO: perfil company_id={args.profile_id} não encontrado", file=sys.stderr)
            return None
        # Permite sobrescrever IDs no momento da execução.
        if args.user_id:
            found.user_id = args.user_id
        if args.type_detail_id:
            found.transparency_type_detail_id = args.type_detail_id
        if args.cnpj:
            found.cnpj = args.cnpj
        if args.unit_name:
            found.unit_name = args.unit_name
        if args.file_template:
            found.file_template = args.file_template
        return found

    missing = [
        name for value, name in [
            (args.company_id, "--company-id"), (args.user_id, "--user-id"),
            (args.type_detail_id, "--type-detail-id"),
        ] if not value
    ]
    if missing:
        print("ERRO: informe --profile-id ou os campos " + ", ".join(missing), file=sys.stderr)
        return None
    return CompanyProfile(
        name="CLI",
        company_id=args.company_id,
        user_id=args.user_id,
        transparency_type_detail_id=args.type_detail_id,
        cnpj=args.cnpj,
        unit_name=args.unit_name or "",
        file_template=args.file_template or "/dist/uploads/files/{company_id}/aplicacoes-e-investimentos/apr/{year4}/{filename}",
    )


def main() -> int:
    ap = argparse.ArgumentParser(description="APR Manager - modo linha de comando")
    ap.add_argument("entrada")
    ap.add_argument("--profile-id", help="Usa um perfil salvo pelo company_id")
    ap.add_argument("--company-id")
    ap.add_argument("--user-id")
    ap.add_argument("--type-detail-id")
    ap.add_argument("--cnpj", default="")
    ap.add_argument("--unit-name", default="")
    ap.add_argument("--file-template", default="")
    ap.add_argument("--output-dir", default="saida_apr", help="Pasta-base; cada exportação ganha uma subpasta própria")
    ap.add_argument("--recursive", action="store_true")
    ap.add_argument("--no-history", action="store_true", help="Não consulta nem grava o histórico local")
    ap.add_argument("--no-ocr", action="store_true", help="Desativa o OCR automático para PDFs escaneados")
    ap.add_argument("--valid-only", action="store_true", help="Gera SQL somente das APRs válidas; relatórios continuam contendo o lote inteiro")
    ap.add_argument(
        "--published-in", choices=["apr", "export", "manual"], default="apr",
        help="Regra de published_in: apr (data da APR), export (data da exportação) ou manual",
    )
    ap.add_argument("--published-in-date", default="", help="Data manual de published_in em DD/MM/YYYY ou YYYY-MM-DD")
    args = ap.parse_args()

    profile = profile_from_args(args)
    if profile is None:
        return 2
    profile_errors = validate_profile(profile)
    if profile_errors:
        for e in profile_errors:
            print(f"ERRO: {e}", file=sys.stderr)
        return 2

    pdfs = collect_pdfs(Path(args.entrada), args.recursive)
    if not pdfs:
        print("ERRO: nenhum PDF encontrado", file=sys.stderr)
        return 2

    history_store = None if args.no_history else HistoryStore()
    rows = validate_batch(pdfs, profile, history_store, enable_ocr=not args.no_ocr)
    sql_rows = [r for r in rows if r.status != "ERRO"] if args.valid_only else ([] if any(r.status == "ERRO" for r in rows) else rows)

    changed = verify_files_unchanged(sql_rows)
    if changed:
        for e in changed:
            print(f"ERRO: {e}", file=sys.stderr)
        return 2

    if args.published_in == "manual" and not args.published_in_date:
        print("ERRO: --published-in manual exige --published-in-date", file=sys.stderr)
        return 2

    result = export_package(
        Path(args.output_dir), rows, profile, sql_rows=sql_rows,
        published_in_mode=args.published_in,
        published_in_date=args.published_in_date or None,
    )
    out_dir = result["output_dir"]
    if history_store is not None and sql_rows:
        history_store.record_export(sql_rows, profile, out_dir)

    ok = sum(r.status == "OK" for r in rows)
    warn = sum(r.status == "AVISO" for r in rows)
    err = sum(r.status == "ERRO" for r in rows)
    print(f"PDFs: {len(rows)} | OK: {ok} | AVISOS: {warn} | ERROS: {err}")
    print(f"Saída: {out_dir.resolve()}")
    integrity_ok, integrity_messages = verify_export_package(out_dir)
    print("Integridade do pacote: " + ("OK" if integrity_ok else "FALHOU"))
    if not integrity_ok:
        for msg in integrity_messages:
            print(f"ERRO: {msg}", file=sys.stderr)
        return 2
    if not sql_rows:
        print("SQL BLOQUEADO. Abra relatorio_apr.html para ver os erros.")
        return 1
    print("SQL gerado com sucesso. Histórico marcado como GERADO; confirme no app após executar no banco.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
