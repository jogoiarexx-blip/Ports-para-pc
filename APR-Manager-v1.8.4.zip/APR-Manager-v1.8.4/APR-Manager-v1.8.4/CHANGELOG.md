# Changelog

## 1.8.4

- Corrigido excesso de AVISOS em APRs válidas processadas por OCR de alta confiança.
- OCR >=95% agora é informação de origem, não aviso.
- Nº/ANO obtido do PDF quando o arquivo não contém ano agora é comportamento esperado, não aviso.
- Relatórios e detalhes ganharam campo `Informações` separado de `Avisos`.
- OCR 85-94% continua como aviso acionável; baixa confiança continua bloqueante.


## 1.8.3

- Adicionado PyMuPDF/Fitz 1.26.7 como extrator/renderizador acelerado.
- Cadeia de extração: MuPDF/Fitz → pypdf → PDFium → OCR somente quando necessário.
- Corrigido falso ERRO para arquivos como `APR 33.pdf`: Nº/ANO vindo de OCR de alta confiança passa a ser aceito quando o nome não possui ano.
- Cabeçalho parcialmente reconhecido por OCR deixa de bloquear quando metadados críticos são coerentes.
- OCR adaptativo com passada rápida e retry em resolução maior somente quando necessário.
- Early-stop de OCR em multipágina quando campos críticos já foram obtidos com boa confiança.
- Correção no parser de saídas RapidOCR com arrays NumPy.
- CNPJ e Nº/ANO mais tolerantes a pequenas perdas de pontuação causadas por OCR.
- Coluna Fonte identifica MuPDF/Fitz, pypdf, PDFium ou OCR.
- Exceções ao renderizar resultados/detalhes passam a ser capturadas e registradas sem acionar apenas o popup global.
- Build atualizado para empacotar PyMuPDF.
- 47 testes automatizados passando.

## 1.8.2

- Tela principal passa a usar QScrollArea externa com rolagem vertical/horizontal.
- Janela inicial reduzida para 1080x680 e tamanho mínimo para 760x500.
- Modo compacto automático baseado em largura/altura da janela.
- Cards responsivos: 6x1 em largura normal e 3x2 abaixo de 1000 px.
- Subtítulo, dicas e textos auxiliares secundários são ocultados no modo compacto.
- Painéis de empresa, IDs e published_in reorganizados em QGridLayout.
- Barras de Arquivos/Processamento reorganizadas para não estourar a largura.
- Área de drag-and-drop, tabela e visualizador receberam dimensões mínimas menores.
- Diálogos de Perfis e Histórico agora abrem menores e continuam redimensionáveis.
- Campo de data manual de published_in volta corretamente ao estado habilitado/desabilitado após validação.
- Mantidas todas as validações e regras de negócio da v1.8.1.
- 45 testes automatizados do núcleo continuam passando.

## 1.8.1

- CNPJ passa a ser opcional para validação e geração do SQL.
- Mantida a conferência de CNPJ quando o perfil possui um CNPJ cadastrado.
- Perfis sem CNPJ deixam de aparecer como pendentes apenas por esse motivo.
- Removido o bloqueio/fluxo obrigatório de aprendizado de CNPJ antes da exportação.
- Conferência pré-exportação passa a mostrar `CNPJ (opcional)`.
- OCR de baixa confiança pode ser liberado após revisão manual de Nº/ANO e Data; CNPJ não é mais exigido.
- CLI deixa de exigir `--cnpj`.
- Rótulos e documentação atualizados para deixar clara a função do CNPJ como validação extra.

## 1.8.0

- Redesign das barras de ação em etapas Arquivos/Processamento.
- Tema visual modernizado e cards de resumo com identificação por categoria.
- Tabela otimizada: removido `ResizeToContents` global, dimensões iniciais fixas/ajustáveis e linhas mais compactas.
- Renderização da tabela passa a suspender sinais e repaint durante atualizações em lote.
- Pesquisa com debounce e índice textual pré-calculado, evitando reconstruir o texto de todas as células a cada tecla.
- Contador de linhas exibidas no filtro.
- Painel de detalhes dividido em Resumo e Texto extraído; texto integral é carregado somente quando solicitado.
- Visualizador de PDF com debounce, cache LRU de até 8 renderizações e resize agrupado.
- Cache de validação em memória limitado a 120 entradas para controlar consumo de RAM.
- Indicador de reaproveitamento do cache após a validação.
- SHA-256 passa a usar blocos de 4 MiB para reduzir overhead de I/O.
- Novos atalhos de teclado para abrir PDFs/pastas, validar, exportar, pesquisar e remover linhas.
- Regras de negócio, auditoria, SQL idempotente e revisão manual permanecem compatíveis com a v1.7.0.

## 1.7.0

- Nova tela **Revisar/corrigir selecionada** para Nº/ANO, Data e CNPJ.
- Comparação lado a lado entre valores detectados e valores efetivos.
- Correções exigem confirmação visual e motivo de auditoria.
- Registro de revisor, data/hora, ação (`confirmed`/`corrected`) e método `manual_visual_pdf`.
- PDF original e SHA-256 permanecem inalterados.
- Recalcula `name`, `slug`, `reference_date`, ano e caminho `file` após correção.
- Reexecuta duplicidades e histórico após revisão manual.
- Pacote anterior da sessão é marcado como obsoleto para confirmação quando há revisão posterior.
- OCR de baixa confiança só pode ser superado após conferência manual dos três campos críticos.
- CSV/HTML/manifest passam a diferenciar valores detectados e valores efetivos.
- Novo `AUDITORIA_REVISAO.json` incluído no pacote e nos checksums.
- SQL registra a quantidade de APRs revisadas manualmente.
- Testes automatizados ampliados para 44 casos, incluindo revisão manual e auditoria.

## 1.6.0

- Regra configurável de `published_in`: data da APR, data da exportação ou data manual.
- `reference_date` permanece sempre ligado à data da APR.
- `Export ID` registrado no SQL e no manifest.
- Novo `RESUMO_EXPORTACAO.txt` em cada pacote.
- Novo `CHECKSUMS.sha256` para prova de integridade dos arquivos gerados.
- Novo botão **Verificar pacote** na interface.
- CSV, HTML e manifest registram `reference_date_sql` e `published_in_sql` separadamente.
- CLI ganhou opções de `published_in` e verificação automática dos checksums.
- Testes de integridade e adulteração do pacote adicionados.

## 1.5.0

Revisão de segurança baseada na auditoria do fluxo 1.4.0: perfis atômicos e recuperação de corrupção, exportações isoladas, SQL idempotente, histórico GERADO/CONFIRMADO, CNPJ obrigatório/aprendizado confirmado, parser de APR endurecido, thread/UI segura, RapidOCR 3.x, fallback pypdfium2, cache, rechecagem de hash, exportação apenas das válidas, persistência de exclusão de perfis, proteção CSV, logs, LOCALAPPDATA e build mais robusto.
