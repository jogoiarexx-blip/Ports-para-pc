from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QMessageBox,
    QPushButton,
    QScrollArea,
    QSplitter,
    QVBoxLayout,
    QWidget,
)

from core.company_catalog import company_catalog
from core.models import CompanyProfile
from core.profiles import mark_catalog_company_deleted, restore_catalog_company, save_profiles
from core.validator import validate_profile, validate_profile_draft


class ProfileDialog(QDialog):
    def __init__(self, profiles: list[CompanyProfile], parent=None):
        super().__init__(parent)
        self.setWindowTitle("Empresas / Perfis de RPPS")
        self.resize(960, 620)
        self.setMinimumSize(740, 500)
        self.profiles = profiles
        self.catalog = company_catalog()

        root = QVBoxLayout(self)
        splitter = QSplitter(Qt.Horizontal)
        root.addWidget(splitter, 1)

        left = QWidget()
        left_layout = QVBoxLayout(left)
        left_layout.addWidget(QLabel(f"Empresas cadastradas ({len(self.profiles)})"))
        self.list = QListWidget()
        left_layout.addWidget(self.list, 1)
        btns = QHBoxLayout()
        self.new_btn = QPushButton("Novo")
        self.delete_btn = QPushButton("Excluir")
        btns.addWidget(self.new_btn)
        btns.addWidget(self.delete_btn)
        left_layout.addLayout(btns)
        splitter.addWidget(left)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        right = QWidget()
        right_layout = QVBoxLayout(right)

        catalog_group = QGroupBox("Catálogo importado da tabela companies")
        catalog_form = QFormLayout(catalog_group)
        catalog_row = QHBoxLayout()
        self.catalog_combo = QComboBox()
        for c in self.catalog:
            self.catalog_combo.addItem(f"ID {c.company_id} — {c.display_name}", c.company_id)
        self.catalog_apply = QPushButton("Aplicar cadastro")
        catalog_row.addWidget(self.catalog_combo, 1)
        catalog_row.addWidget(self.catalog_apply)
        catalog_form.addRow("Empresa:", catalog_row)
        self.catalog_source = QLabel("38 registros pré-carregados. Os IDs de usuário/tipo e IPs podem ser completados depois.")
        self.catalog_source.setWordWrap(True)
        catalog_form.addRow("Fonte:", self.catalog_source)
        right_layout.addWidget(catalog_group)

        basic_group = QGroupBox("Identificação e banco")
        form = QFormLayout(basic_group)
        self.name = QLineEdit()
        self.company = QLineEdit()
        self.user = QLineEdit()
        self.type_id = QLineEdit()
        self.cnpj = QLineEdit()
        self.unit = QLineEdit()
        self.db_name = QLineEdit()
        self.db_name.setReadOnly(True)
        self.sub_title = QLineEdit()
        self.sub_title.setReadOnly(True)
        self.template = QLineEdit()
        self.template.setText("/dist/uploads/files/{company_id}/aplicacoes-e-investimentos/apr/{year4}/{filename}")
        form.addRow("Nome do perfil:", self.name)
        form.addRow("company_id:", self.company)
        form.addRow("user_id:", self.user)
        form.addRow("transparency_type_detail_id:", self.type_id)
        form.addRow("CNPJ esperado (opcional):", self.cnpj)
        form.addRow("Unidade gestora:", self.unit)
        form.addRow("Nome na tabela companies:", self.db_name)
        form.addRow("sub_title da companies:", self.sub_title)
        form.addRow("Template do campo file:", self.template)
        right_layout.addWidget(basic_group)

        conn_group = QGroupBox("Conexões (preparado para a próxima etapa)")
        conn = QFormLayout(conn_group)
        self.db_host = QLineEdit()
        self.db_port = QLineEdit("3306")
        self.upload_host = QLineEdit()
        self.upload_port = QLineEdit("22")
        self.upload_protocol = QComboBox()
        self.upload_protocol.addItems(["SFTP", "FTPS", "FTP"])
        self.remote_template = QLineEdit()
        self.remote_template.setPlaceholderText("Ex.: /public_html/dist/uploads/files/{company_id}/.../{filename}")
        conn.addRow("IP/host do banco:", self.db_host)
        conn.addRow("Porta do banco:", self.db_port)
        conn.addRow("IP/host do upload:", self.upload_host)
        conn.addRow("Porta do upload:", self.upload_port)
        conn.addRow("Protocolo:", self.upload_protocol)
        conn.addRow("Caminho remoto (opcional):", self.remote_template)
        note = QLabel("Senhas não são armazenadas neste perfil. Quando a conexão for ativada, as credenciais serão tratadas separadamente.")
        note.setWordWrap(True)
        conn.addRow("Segurança:", note)
        right_layout.addWidget(conn_group)

        self.profile_status = QLabel()
        self.profile_status.setWordWrap(True)
        right_layout.addWidget(self.profile_status)
        self.save_btn = QPushButton("Salvar perfil")
        right_layout.addWidget(self.save_btn)
        right_layout.addStretch(1)
        scroll.setWidget(right)
        splitter.addWidget(scroll)
        splitter.setStretchFactor(1, 2)

        buttons = QDialogButtonBox(QDialogButtonBox.Close)
        buttons.rejected.connect(self.reject)
        root.addWidget(buttons)

        self.list.currentRowChanged.connect(self.load_row)
        self.new_btn.clicked.connect(self.new_profile)
        self.delete_btn.clicked.connect(self.delete_profile)
        self.save_btn.clicked.connect(self.save_profile)
        self.catalog_apply.clicked.connect(self.apply_catalog_company)
        self.refresh_list()

    def _is_complete(self, p: CompanyProfile) -> bool:
        return not validate_profile(p)

    def refresh_list(self):
        current = self.list.currentRow()
        self.list.clear()
        for p in self.profiles:
            state = "OK" if self._is_complete(p) else "PENDENTE"
            self.list.addItem(f"[{state}] ID {p.company_id or '?'} — {p.name or '(sem nome)'}")
        if self.profiles:
            self.list.setCurrentRow(max(0, min(current, len(self.profiles) - 1)))

    def load_row(self, row: int):
        if row < 0 or row >= len(self.profiles):
            return
        p = self.profiles[row]
        self.name.setText(p.name)
        self.company.setText(p.company_id)
        self.user.setText(p.user_id)
        self.type_id.setText(p.transparency_type_detail_id)
        self.cnpj.setText(p.cnpj)
        self.unit.setText(p.unit_name)
        self.db_name.setText(p.catalog_db_name)
        self.sub_title.setText(p.catalog_sub_title)
        self.template.setText(p.file_template)
        self.db_host.setText(p.db_host)
        self.db_port.setText(p.db_port or "3306")
        self.upload_host.setText(p.upload_host)
        self.upload_port.setText(p.upload_port or "22")
        idx = self.upload_protocol.findText(p.upload_protocol or "SFTP")
        self.upload_protocol.setCurrentIndex(max(0, idx))
        self.remote_template.setText(p.remote_template)
        idx = self.catalog_combo.findData(p.company_id)
        if idx >= 0:
            self.catalog_combo.setCurrentIndex(idx)
        self._update_status(p)

    def _update_status(self, p: CompanyProfile):
        errors = validate_profile(p)
        if errors:
            self.profile_status.setText("Perfil pendente: " + " • ".join(errors))
            self.profile_status.setStyleSheet("color:#9a6700;font-weight:600")
        else:
            self.profile_status.setText("Perfil pronto para validar APRs. CNPJ é opcional e serve como conferência extra.")
            self.profile_status.setStyleSheet("color:#137333;font-weight:600")

    def new_profile(self):
        self.list.setCurrentRow(-1)
        for w in [self.name, self.company, self.user, self.type_id, self.cnpj, self.unit, self.db_name, self.sub_title, self.db_host, self.upload_host, self.remote_template]:
            w.clear()
        self.db_port.setText("3306")
        self.upload_port.setText("22")
        self.upload_protocol.setCurrentText("SFTP")
        self.template.setText("/dist/uploads/files/{company_id}/aplicacoes-e-investimentos/apr/{year4}/{filename}")
        self.profile_status.clear()
        self.name.setFocus()

    def apply_catalog_company(self):
        company_id = self.catalog_combo.currentData()
        c = next((x for x in self.catalog if x.company_id == company_id), None)
        if not c:
            return
        self.company.setText(c.company_id)
        self.name.setText(c.display_name)
        self.db_name.setText(c.db_name)
        self.sub_title.setText(c.sub_title)
        if c.db_name and "..." not in c.db_name:
            self.unit.setText(c.db_name)
        elif not self.unit.text().strip():
            self.unit.setText(c.display_name)

    def delete_profile(self):
        row = self.list.currentRow()
        if row < 0:
            return
        if QMessageBox.question(self, "Excluir perfil", f"Excluir '{self.profiles[row].name}'?") != QMessageBox.Yes:
            return
        deleted = self.profiles[row]
        del self.profiles[row]
        mark_catalog_company_deleted(deleted.company_id)
        save_profiles(self.profiles)
        self.refresh_list()

    def _build_profile_from_form(self) -> CompanyProfile:
        return CompanyProfile(
            name=self.name.text().strip(),
            company_id=self.company.text().strip(),
            user_id=self.user.text().strip(),
            transparency_type_detail_id=self.type_id.text().strip(),
            cnpj=self.cnpj.text().strip(),
            unit_name=self.unit.text().strip(),
            catalog_db_name=self.db_name.text().strip(),
            catalog_sub_title=self.sub_title.text().strip(),
            db_host=self.db_host.text().strip(),
            db_port=self.db_port.text().strip() or "3306",
            upload_host=self.upload_host.text().strip(),
            upload_port=self.upload_port.text().strip() or "22",
            upload_protocol=self.upload_protocol.currentText().strip().upper() or "SFTP",
            remote_template=self.remote_template.text().strip(),
            file_template=self.template.text().strip(),
        )

    def save_profile(self):
        p = self._build_profile_from_form()
        if not p.name:
            QMessageBox.warning(self, "Perfil", "Informe um nome para o perfil.")
            return
        errors = validate_profile_draft(p)
        if errors:
            QMessageBox.warning(self, "Perfil inválido", "\n".join(f"• {e}" for e in errors))
            return

        row = self.list.currentRow()
        # company_id deve ser único também ao EDITAR um perfil existente.
        duplicate_idx = next(
            (i for i, x in enumerate(self.profiles) if x.company_id == p.company_id and i != row),
            None,
        )
        if duplicate_idx is not None:
            QMessageBox.warning(
                self,
                "company_id duplicado",
                f"Já existe outro perfil usando company_id {p.company_id}: '{self.profiles[duplicate_idx].name}'.",
            )
            return

        if row >= 0:
            old_id = self.profiles[row].company_id
            self.profiles[row] = p
            if old_id != p.company_id:
                mark_catalog_company_deleted(old_id)
        else:
            self.profiles.append(p)
            row = len(self.profiles) - 1

        restore_catalog_company(p.company_id)
        self.profiles.sort(key=lambda x: (int(x.company_id) if x.company_id.isdigit() else 10**9, x.name.casefold()))
        save_profiles(self.profiles)
        self.refresh_list()
        for i, item in enumerate(self.profiles):
            if item.company_id == p.company_id:
                self.list.setCurrentRow(i)
                self._update_status(item)
                break
