from __future__ import annotations

from pathlib import Path
from copy import deepcopy
from collections import OrderedDict
import logging

from PySide6.QtCore import QObject, QThread, Qt, Signal, Slot, QUrl, QTimer, QDate
from PySide6.QtGui import QAction, QColor, QDesktopServices, QIntValidator, QKeySequence, QShortcut
from PySide6.QtWidgets import (
    QAbstractItemView,
    QCheckBox,
    QComboBox,
    QDateEdit,
    QFileDialog,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMessageBox,
    QPlainTextEdit,
    QProgressBar,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QSplitter,
    QStatusBar,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QStyle,
    QVBoxLayout,
    QWidget,
)

from core.history import HistoryStore
from core.ocr import ocr_available
from core.models import APRRecord, CompanyProfile
from core.manual_review import apply_manual_review
from core.profiles import load_profiles, pop_profile_load_warning, save_profiles
from core.reporting import export_package, verify_export_package
from core.validator import (
    add_batch_duplicate_errors, refresh_batch_checks, validate_one, validate_profile, validate_profile_for_validation,
    verify_files_unchanged,
)
from core.version import APP_NAME, APP_VERSION
from .history_dialog import HistoryDialog
from .pdf_preview import PDFPreviewWidget
from .profile_dialog import ProfileDialog
from .review_dialog import ManualReviewDialog
from core.pdf_reader import ExtractionCancelled

LOGGER = logging.getLogger("apr_manager")


class DropArea(QFrame):
    filesDropped = Signal(list)

    def __init__(self):
        super().__init__()
        self.setAcceptDrops(True)
        self.setFrameShape(QFrame.StyledPanel)
        self.setObjectName("dropArea")
        layout = QVBoxLayout(self)
        label = QLabel("Arraste PDFs ou uma pasta de APRs aqui")
        label.setObjectName("dropTitle")
        label.setAlignment(Qt.AlignCenter)
        sub = QLabel("ou use os botões Adicionar PDFs / Adicionar pasta")
        sub.setObjectName("dropSubtitle")
        sub.setAlignment(Qt.AlignCenter)
        layout.addWidget(label)
        layout.addWidget(sub)

    @Slot()
    def _validation_thread_finished(self):
        self.worker = None
        self.thread = None

    def set_busy(self, busy: bool):
        self.setAcceptDrops(not busy)
        self.setEnabled(not busy)

    def dragEnterEvent(self, event):
        if self.isEnabled() and event.mimeData().hasUrls():
            event.acceptProposedAction()

    def dropEvent(self, event):
        paths = [Path(url.toLocalFile()) for url in event.mimeData().urls() if url.isLocalFile()]
        self.filesDropped.emit(paths)
        event.acceptProposedAction()


class ValidationWorker(QObject):
    finished = Signal(object)
    failed = Signal(str)
    cancelled = Signal()
    progress = Signal(int, int, str)
    stats = Signal(int)

    def __init__(
        self,
        paths: list[Path],
        profile: CompanyProfile,
        history_store: HistoryStore | None = None,
        *,
        enable_ocr: bool = True,
        cache: dict | None = None,
        profile_signature: tuple | None = None,
    ):
        super().__init__()
        self.paths = paths
        self.profile = profile
        self.history_store = history_store
        self.enable_ocr = enable_ocr
        self.cache = cache if cache is not None else {}
        self.profile_signature = profile_signature or ()
        self._cancel_requested = False

    def request_cancel(self):
        self._cancel_requested = True

    @Slot()
    def run(self):
        try:
            rows: list[APRRecord] = []
            total = len(self.paths)
            cache_hits = 0
            for index, path in enumerate(self.paths, start=1):
                if self._cancel_requested:
                    self.cancelled.emit()
                    return
                self.progress.emit(index - 1, total, path.name)
                try:
                    st = path.stat()
                    key = (str(path.resolve()).casefold(), st.st_mtime_ns, st.st_size, self.profile_signature, self.enable_ocr)
                except OSError:
                    key = (str(path).casefold(), 0, 0, self.profile_signature, self.enable_ocr)
                cached = self.cache.get(key)
                if cached is not None:
                    cache_hits += 1
                    row = deepcopy(cached)
                    if hasattr(self.cache, "move_to_end"):
                        self.cache.move_to_end(key)
                else:
                    row = validate_one(
                        path, self.profile, enable_ocr=self.enable_ocr, cancel_check=lambda: self._cancel_requested
                    )
                    self.cache[key] = deepcopy(row)
                    # O texto extraído pode ser grande; mantenha um cache de sessão limitado.
                    if hasattr(self.cache, "popitem"):
                        while len(self.cache) > 120:
                            try:
                                self.cache.popitem(last=False)
                            except TypeError:
                                break
                rows.append(row)
                self.progress.emit(index, total, path.name)
            if self._cancel_requested:
                self.cancelled.emit()
                return
            add_batch_duplicate_errors(rows)
            if self.history_store is not None:
                self.history_store.apply_checks(rows, self.profile)
            self.stats.emit(cache_hits)
            self.finished.emit(rows)
        except ExtractionCancelled:
            self.cancelled.emit()
        except Exception as exc:
            self.failed.emit(str(exc))


class SummaryCard(QFrame):
    def __init__(self, title: str, hint: str = "", tone: str = "neutral"):
        super().__init__()
        self.setObjectName("summaryCard")
        self.setProperty("tone", tone)
        box = QVBoxLayout(self)
        box.setContentsMargins(14, 10, 14, 10)
        box.setSpacing(2)
        self.title = QLabel(title)
        self.title.setObjectName("cardTitle")
        self.value = QLabel("0")
        self.value.setObjectName("cardValue")
        self.hint = QLabel(hint)
        self.hint.setObjectName("cardHint")
        box.addWidget(self.title)
        box.addWidget(self.value)
        box.addWidget(self.hint)

    def set_value(self, value: int | str, hint: str | None = None):
        self.value.setText(str(value))
        if hint is not None:
            self.hint.setText(hint)


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(f"{APP_NAME} {APP_VERSION}")
        # Janela inicial menor e compatível com notebooks/monitores abaixo de 1080p.
        # O conteúdo principal possui rolagem, então nada fica inacessível em telas menores.
        self.resize(1080, 680)
        self.setMinimumSize(760, 500)
        self.paths: list[Path] = []
        self.rows: list[APRRecord] = []
        self.profiles = load_profiles()
        self.profile_load_warning = pop_profile_load_warning()
        self.validation_cache: OrderedDict = OrderedDict()
        self.thread: QThread | None = None
        self.worker: ValidationWorker | None = None
        self.last_output_dir: Path | None = None
        self.validation_signature: tuple[str, str, str, str] | None = None
        self._loading_quick_ids = False
        self._quick_ids_dirty = False
        self._filter_blobs: list[str] = []
        self._selected_detail_index: int | None = None
        self._last_cache_hits = 0
        self._filter_timer = QTimer(self)
        self._filter_timer.setSingleShot(True)
        self._filter_timer.setInterval(160)
        self._filter_timer.timeout.connect(self.apply_filters)
        self.history_store: HistoryStore | None = None
        self.history_error = ""
        try:
            self.history_store = HistoryStore()
        except Exception as exc:
            self.history_error = str(exc)

        self._build_ui()
        self._build_menu()
        self._install_shortcuts()
        self._refresh_profiles()
        self._update_summary()
        if self.profile_load_warning:
            QTimer.singleShot(0, lambda: QMessageBox.warning(self, "Perfis recuperados", self.profile_load_warning))

    def _published_mode_changed(self):
        mode = self.published_mode_combo.currentData() if hasattr(self, "published_mode_combo") else "apr"
        self.published_date_edit.setEnabled(mode == "manual")

    def _published_export_settings(self) -> tuple[str, str | None]:
        mode = self.published_mode_combo.currentData() or "apr"
        manual = None
        if mode == "manual":
            manual = self.published_date_edit.date().toString("yyyy-MM-dd")
        return str(mode), manual

    def _install_shortcuts(self):
        self._shortcuts: list[QShortcut] = []
        bindings = [
            ("Ctrl+O", self.pick_files),
            ("Ctrl+Shift+O", self.pick_folder),
            ("F5", self.start_validation),
            ("Ctrl+Return", self.start_validation),
            ("Ctrl+E", lambda: self.export_results(False)),
            ("Ctrl+F", lambda: (self.search_edit.setFocus(), self.search_edit.selectAll())),
            ("Delete", self.remove_selected),
        ]
        for sequence, callback in bindings:
            shortcut = QShortcut(QKeySequence(sequence), self)
            shortcut.activated.connect(callback)
            self._shortcuts.append(shortcut)

    def _build_menu(self):
        menu = self.menuBar().addMenu("Arquivo")
        self.profiles_action = QAction("Perfis de RPPS", self)
        self.profiles_action.triggered.connect(self.manage_profiles)
        menu.addAction(self.profiles_action)
        self.history_action = QAction("Histórico local", self)
        self.history_action.triggered.connect(self.open_history)
        menu.addAction(self.history_action)
        menu.addSeparator()
        self.exit_action = QAction("Sair", self)
        self.exit_action.triggered.connect(self.close)
        menu.addAction(self.exit_action)

    def _build_ui(self):
        # A janela usa uma QScrollArea externa. Isso evita cortar botões/controles
        # em notebooks 1366x768, acesso remoto e telas com escala do Windows > 100%.
        root = QWidget()
        self.setCentralWidget(root)
        outer = QVBoxLayout(root)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        self.main_scroll = QScrollArea()
        self.main_scroll.setObjectName("mainScroll")
        self.main_scroll.setWidgetResizable(True)
        self.main_scroll.setFrameShape(QFrame.NoFrame)
        self.main_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.main_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        outer.addWidget(self.main_scroll)

        content = QWidget()
        content.setObjectName("mainContent")
        content.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.MinimumExpanding)
        self.main_scroll.setWidget(content)
        layout = QVBoxLayout(content)
        self.main_layout = layout
        layout.setContentsMargins(14, 12, 14, 12)
        layout.setSpacing(8)

        hero = QFrame()
        hero.setObjectName("hero")
        hero_layout = QHBoxLayout(hero)
        hero_layout.setContentsMargins(14, 9, 14, 9)
        hero_text = QVBoxLayout()
        hero_text.setSpacing(1)
        hero_title = QLabel("APR Manager")
        hero_title.setObjectName("heroTitle")
        self.hero_subtitle = QLabel("Validação, conferência e geração segura de INSERTs de APR")
        self.hero_subtitle.setObjectName("heroSubtitle")
        hero_text.addWidget(hero_title)
        hero_text.addWidget(self.hero_subtitle)
        hero_layout.addLayout(hero_text)
        hero_layout.addStretch(1)
        version_label = QLabel(f"v{APP_VERSION}")
        version_label.setStyleSheet("color:#64748b;font-weight:700;padding:4px 8px")
        hero_layout.addWidget(version_label)
        layout.addWidget(hero)

        # Empresa/perfil em painel próprio, sem uma linha horizontal gigante.
        profile_panel = QFrame()
        profile_panel.setObjectName("quickPanel")
        top = QGridLayout(profile_panel)
        top.setContentsMargins(10, 7, 10, 7)
        top.setHorizontalSpacing(8)
        top.setVerticalSpacing(5)
        top.addWidget(QLabel("Empresa / perfil:"), 0, 0)
        self.profile_combo = QComboBox()
        self.profile_combo.setMinimumWidth(220)
        self.profile_combo.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.profile_combo.currentIndexChanged.connect(self.profile_changed)
        top.addWidget(self.profile_combo, 0, 1)
        self.profile_btn = QPushButton("Gerenciar perfis")
        self.profile_btn.clicked.connect(self.manage_profiles)
        top.addWidget(self.profile_btn, 0, 2)
        self.summary = QLabel()
        self.summary.setStyleSheet("font-weight:600;color:#64748b")
        self.summary.setWordWrap(True)
        top.addWidget(self.summary, 1, 0, 1, 3)
        top.setColumnStretch(1, 1)
        layout.addWidget(profile_panel)

        # IDs em duas linhas para caber melhor em largura reduzida.
        quick = QFrame()
        quick.setObjectName("quickPanel")
        ql = QGridLayout(quick)
        ql.setContentsMargins(10, 7, 10, 7)
        ql.setHorizontalSpacing(7)
        ql.setVerticalSpacing(5)
        ql.addWidget(QLabel("company_id:"), 0, 0)
        self.company_id_edit = QLineEdit()
        self.company_id_edit.setReadOnly(True)
        self.company_id_edit.setMaximumWidth(95)
        self.company_id_edit.setToolTip("Definido pela empresa selecionada no catálogo")
        ql.addWidget(self.company_id_edit, 0, 1)
        ql.addWidget(QLabel("user_id:"), 0, 2)
        self.user_id_edit = QLineEdit()
        self.user_id_edit.setValidator(QIntValidator(0, 2_147_483_647, self))
        self.user_id_edit.setMaximumWidth(135)
        ql.addWidget(self.user_id_edit, 0, 3)
        ql.addWidget(QLabel("transparency_type_detail_id:"), 1, 0)
        self.type_id_edit = QLineEdit()
        self.type_id_edit.setValidator(QIntValidator(0, 2_147_483_647, self))
        self.type_id_edit.setMaximumWidth(165)
        ql.addWidget(self.type_id_edit, 1, 1)
        self.save_ids_btn = QPushButton("Salvar IDs nesta empresa")
        self.save_ids_btn.clicked.connect(self.save_quick_ids)
        ql.addWidget(self.save_ids_btn, 1, 2)
        self.quick_status = QLabel()
        self.quick_status.setWordWrap(True)
        ql.addWidget(self.quick_status, 1, 3)
        ql.setColumnStretch(3, 1)
        layout.addWidget(quick)

        export_cfg = QFrame()
        export_cfg.setObjectName("quickPanel")
        ec = QGridLayout(export_cfg)
        ec.setContentsMargins(10, 7, 10, 7)
        ec.setHorizontalSpacing(7)
        ec.setVerticalSpacing(4)
        ec.addWidget(QLabel("published_in:"), 0, 0)
        self.published_mode_combo = QComboBox()
        self.published_mode_combo.addItem("Mesma data da APR", "apr")
        self.published_mode_combo.addItem("Data da exportação", "export")
        self.published_mode_combo.addItem("Data manual", "manual")
        self.published_mode_combo.setToolTip(
            "Define somente o campo published_in do SQL. reference_date continua sendo a data da APR."
        )
        ec.addWidget(self.published_mode_combo, 0, 1)
        self.published_date_edit = QDateEdit()
        self.published_date_edit.setDisplayFormat("dd/MM/yyyy")
        self.published_date_edit.setCalendarPopup(True)
        self.published_date_edit.setDate(QDate.currentDate())
        self.published_date_edit.setEnabled(False)
        self.published_date_edit.setToolTip("Usada apenas quando published_in estiver em Data manual")
        ec.addWidget(self.published_date_edit, 0, 2)
        self.published_help = QLabel("reference_date sempre usa a data encontrada na APR")
        self.published_help.setStyleSheet("color:#64748b")
        self.published_help.setWordWrap(True)
        ec.addWidget(self.published_help, 1, 0, 1, 3)
        ec.setColumnStretch(1, 1)
        self.published_mode_combo.currentIndexChanged.connect(self._published_mode_changed)
        layout.addWidget(export_cfg)

        # Cards em 3x2, não 6 em uma única linha. Isso reduz muito a largura mínima.
        cards = QGridLayout()
        cards.setHorizontalSpacing(7)
        cards.setVerticalSpacing(7)
        self.card_loaded = SummaryCard("Carregadas", "PDFs na lista", "blue")
        self.card_new = SummaryCard("Novas", "Ainda não processadas", "green")
        self.card_revision = SummaryCard("Revisões", "Mesmo Nº/ANO, conteúdo novo", "amber")
        self.card_processed = SummaryCard("Já processadas", "Bloqueadas pelo histórico", "slate")
        self.card_errors = SummaryCard("Erros", "Precisam de correção", "red")
        self.card_ocr = SummaryCard("OCR", "Fallback para PDFs escaneados", "violet")
        self.summary_cards = [
            self.card_loaded, self.card_new, self.card_revision,
            self.card_processed, self.card_errors, self.card_ocr,
        ]
        self.cards_layout = cards
        for idx, card in enumerate(self.summary_cards):
            cards.addWidget(card, 0, idx)
        layout.addLayout(cards)

        self.user_id_edit.textChanged.connect(self.quick_ids_changed)
        self.type_id_edit.textChanged.connect(self.quick_ids_changed)

        self.drop = DropArea()
        self.drop.setMaximumHeight(78)
        self.drop.setMinimumHeight(58)
        self.drop.filesDropped.connect(self.add_paths)
        layout.addWidget(self.drop)

        # Ações em grade: evitam que os botões saiam da tela em resoluções menores.
        file_bar = QFrame()
        file_bar.setObjectName("actionBar")
        file_actions = QGridLayout(file_bar)
        file_actions.setContentsMargins(9, 6, 9, 6)
        file_actions.setHorizontalSpacing(6)
        file_actions.setVerticalSpacing(5)
        file_label = QLabel("ARQUIVOS")
        file_label.setObjectName("sectionLabel")
        file_actions.addWidget(file_label, 0, 0)

        self.files_btn = QPushButton("Adicionar PDFs")
        self.files_btn.setIcon(self.style().standardIcon(QStyle.StandardPixmap.SP_DialogOpenButton))
        self.folder_btn = QPushButton("Adicionar pasta")
        self.folder_btn.setIcon(self.style().standardIcon(QStyle.StandardPixmap.SP_DirOpenIcon))
        self.remove_btn = QPushButton("Remover")
        self.clear_btn = QPushButton("Limpar")
        self.open_pdf_btn = QPushButton("Abrir PDF")
        self.review_btn = QPushButton("Revisar / corrigir")
        self.review_btn.setToolTip("Corrige Nº/ANO, data ou CNPJ após conferência visual e registra a auditoria.")
        self.review_btn.setEnabled(False)
        self.history_btn = QPushButton("Histórico")

        file_buttons = [self.files_btn, self.folder_btn, self.remove_btn, self.clear_btn, self.open_pdf_btn, self.review_btn, self.history_btn]
        for idx, w in enumerate(file_buttons):
            row = 0 if idx < 4 else 1
            col = idx + 1 if idx < 4 else idx - 3
            file_actions.addWidget(w, row, col)
        for col in range(1, 5):
            file_actions.setColumnStretch(col, 1)
        layout.addWidget(file_bar)

        process_bar = QFrame()
        process_bar.setObjectName("actionBar")
        process_actions = QGridLayout(process_bar)
        process_actions.setContentsMargins(9, 6, 9, 6)
        process_actions.setHorizontalSpacing(6)
        process_actions.setVerticalSpacing(5)
        process_label = QLabel("PROCESSAMENTO")
        process_label.setObjectName("sectionLabel")
        process_actions.addWidget(process_label, 0, 0)

        self.ocr_checkbox = QCheckBox("OCR automático (só quando necessário)")
        self.ocr_checkbox.setChecked(True)
        available, ocr_detail = ocr_available()
        self.ocr_checkbox.setToolTip(
            "OCR local para PDFs digitalizados. Nenhum documento é enviado para a internet.\n"
            + (f"Disponível: {ocr_detail}" if available else f"Dependência ainda indisponível: {ocr_detail}")
        )
        self.valid_only_checkbox = QCheckBox("SQL só das válidas")
        self.valid_only_checkbox.setToolTip("Mantém o relatório completo, mas inclui no SQL somente APRs sem erro/bloqueio.")
        process_actions.addWidget(self.ocr_checkbox, 0, 1)
        process_actions.addWidget(self.valid_only_checkbox, 0, 2)

        self.cancel_btn = QPushButton("Cancelar")
        self.cancel_btn.setObjectName("dangerButton")
        self.cancel_btn.setEnabled(False)
        self.validate_btn = QPushButton("Validar")
        self.validate_btn.setObjectName("primaryButton")
        self.validate_btn.setIcon(self.style().standardIcon(QStyle.StandardPixmap.SP_DialogApplyButton))
        self.export_btn = QPushButton("Gerar pacote")
        self.export_btn.setObjectName("primaryButton")
        self.export_btn.setIcon(self.style().standardIcon(QStyle.StandardPixmap.SP_DialogSaveButton))
        self.reexport_btn = QPushButton("Reexportar")
        self.reexport_btn.setToolTip("Permite reexportar APR já CONFIRMADA para a mesma empresa, após confirmação explícita.")
        self.reexport_btn.setEnabled(False)
        self.confirm_btn = QPushButton("Confirmar execução")
        self.confirm_btn.setEnabled(False)
        self.open_output_btn = QPushButton("Abrir saída")
        self.verify_output_btn = QPushButton("Verificar pacote")
        self.verify_output_btn.setToolTip("Confere os SHA-256 do último pacote exportado.")
        self.verify_output_btn.setEnabled(False)
        self.export_btn.setEnabled(False)
        self.open_output_btn.setEnabled(False)

        process_buttons = [
            self.cancel_btn, self.validate_btn, self.export_btn, self.reexport_btn,
            self.confirm_btn, self.open_output_btn, self.verify_output_btn,
        ]
        for idx, w in enumerate(process_buttons):
            row = 1 if idx < 4 else 2
            col = idx if idx < 4 else idx - 4
            process_actions.addWidget(w, row, col)
        for col in range(4):
            process_actions.setColumnStretch(col, 1)
        layout.addWidget(process_bar)

        self.files_btn.clicked.connect(self.pick_files)
        self.folder_btn.clicked.connect(self.pick_folder)
        self.remove_btn.clicked.connect(self.remove_selected)
        self.clear_btn.clicked.connect(self.clear_all)
        self.open_pdf_btn.clicked.connect(self.open_selected_pdf)
        self.review_btn.clicked.connect(self.review_selected)
        self.history_btn.clicked.connect(self.open_history)
        self.ocr_checkbox.stateChanged.connect(self.ocr_setting_changed)
        self.cancel_btn.clicked.connect(self.cancel_validation)
        self.validate_btn.clicked.connect(self.start_validation)
        self.export_btn.clicked.connect(lambda: self.export_results(False))
        self.reexport_btn.clicked.connect(lambda: self.export_results(True))
        self.confirm_btn.clicked.connect(self.confirm_last_export)
        self.open_output_btn.clicked.connect(self.open_output)
        self.verify_output_btn.clicked.connect(self.verify_last_output)

        self.progress = QProgressBar()
        self.progress.setRange(0, 1)
        self.progress.setValue(0)
        self.progress.setTextVisible(True)
        self.progress.setFormat("Pronto")
        layout.addWidget(self.progress)

        filter_panel = QFrame()
        filter_panel.setObjectName("filterPanel")
        filter_bar = QGridLayout(filter_panel)
        filter_bar.setContentsMargins(0, 0, 0, 0)
        filter_bar.setHorizontalSpacing(7)
        filter_bar.addWidget(QLabel("Filtrar:"), 0, 0)
        self.search_edit = QLineEdit()
        self.search_edit.setPlaceholderText("arquivo, nº/ano, CNPJ, unidade, mensagem...")
        self.search_edit.textChanged.connect(self.schedule_filter)
        filter_bar.addWidget(self.search_edit, 0, 1)
        self.status_filter = QComboBox()
        self.status_filter.addItems(["Todos", "OK", "AVISO", "ERRO", "PENDENTE"])
        self.status_filter.currentTextChanged.connect(self.apply_filters)
        filter_bar.addWidget(self.status_filter, 0, 2)
        self.filter_count = QLabel("0 exibidos")
        self.filter_count.setObjectName("filterCount")
        filter_bar.addWidget(self.filter_count, 1, 1, 1, 2)
        filter_bar.setColumnStretch(1, 1)
        layout.addWidget(filter_panel)

        splitter = QSplitter(Qt.Vertical)
        splitter.setChildrenCollapsible(False)
        splitter.setMinimumHeight(440)
        layout.addWidget(splitter)

        self.table = QTableWidget(0, 13)
        self.table.setMinimumHeight(200)
        self.table.setHorizontalHeaderLabels([
            "Status", "Arquivo", "Nº/ANO arquivo", "Nº/ANO efetivo", "Data efetiva", "CNPJ efetivo",
            "Valor", "Operação", "Unidade gestora", "Fonte", "Histórico", "Caminho no banco", "Mensagem"
        ])
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.verticalHeader().setVisible(False)
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.Interactive)
        header.setStretchLastSection(True)
        widths = [82, 185, 105, 105, 98, 140, 105, 110, 230, 105, 120, 300, 330]
        for col, width in enumerate(widths):
            self.table.setColumnWidth(col, width)
        self.table.verticalHeader().setDefaultSectionSize(28)
        self.table.setWordWrap(False)
        self.table.setTextElideMode(Qt.ElideRight)
        self.table.setAlternatingRowColors(True)
        self.table.setSortingEnabled(False)
        self.table.itemSelectionChanged.connect(self.show_details)
        self.table.itemDoubleClicked.connect(lambda _item: self.open_selected_pdf())
        splitter.addWidget(self.table)

        lower = QSplitter(Qt.Horizontal)
        lower.setChildrenCollapsible(False)
        lower.setMinimumHeight(220)
        self.pdf_preview = PDFPreviewWidget()
        lower.addWidget(self.pdf_preview)

        self.info_tabs = QTabWidget()
        self.info_tabs.setObjectName("inspectorTabs")
        self.details = QPlainTextEdit()
        self.details.setReadOnly(True)
        self.details.setPlaceholderText("Selecione uma APR para ver os detalhes da validação.")
        self.extracted_text_view = QPlainTextEdit()
        self.extracted_text_view.setReadOnly(True)
        self.extracted_text_view.setPlaceholderText("O texto extraído será carregado quando esta aba for aberta.")
        self.info_tabs.addTab(self.details, "Resumo")
        self.info_tabs.addTab(self.extracted_text_view, "Texto extraído")
        self.info_tabs.currentChanged.connect(self._details_tab_changed)
        lower.addWidget(self.info_tabs)
        lower.setSizes([620, 420])
        splitter.addWidget(lower)
        splitter.setSizes([285, 285])

        self.setStatusBar(QStatusBar())
        self.statusBar().showMessage("Pronto")
        self._apply_compact_mode()

    def _apply_compact_mode(self):
        """Adapta densidade visual para telas menores sem esconder funcionalidades."""
        compact = self.width() < 1180 or self.height() < 820
        very_compact = self.width() < 960 or self.height() < 680
        if hasattr(self, "hero_subtitle"):
            self.hero_subtitle.setVisible(not very_compact)
        cards = getattr(self, "summary_cards", [])
        for card in cards:
            card.hint.setVisible(not compact)
        # Em largura normal os 6 cards ficam em uma única linha (menos altura).
        # Abaixo de 1000 px eles passam para 3x2 para não forçar largura excessiva.
        if hasattr(self, "cards_layout"):
            for idx, card in enumerate(cards):
                if self.width() < 1000:
                    self.cards_layout.addWidget(card, idx // 3, idx % 3)
                else:
                    self.cards_layout.addWidget(card, 0, idx)
        if hasattr(self, "published_help"):
            self.published_help.setVisible(not very_compact)
        if hasattr(self, "drop"):
            self.drop.setMaximumHeight(66 if compact else 78)
        if hasattr(self, "main_layout"):
            self.main_layout.setSpacing(6 if compact else 8)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._apply_compact_mode()

    def current_profile(self) -> CompanyProfile | None:
        idx = self.profile_combo.currentIndex()
        if idx < 0 or idx >= len(self.profiles):
            return None
        p = self.profiles[idx]
        # Os dois IDs podem ser alterados na hora sem precisar abrir o editor completo.
        p.user_id = self.user_id_edit.text().strip()
        p.transparency_type_detail_id = self.type_id_edit.text().strip()
        return p

    @staticmethod
    def _profile_validation_signature(profile: CompanyProfile) -> tuple[str, str, str, str]:
        """Campos que afetam leitura/validação e o caminho file_db."""
        return (
            profile.company_id.strip(),
            profile.cnpj.strip(),
            profile.unit_name.strip(),
            profile.file_template.strip(),
        )

    def _refresh_profiles(self):
        current_id = self.profile_combo.currentData()
        self.profile_combo.blockSignals(True)
        self.profile_combo.clear()
        for p in self.profiles:
            pending = "" if not validate_profile(p) else " [PENDENTE]"
            self.profile_combo.addItem(f"ID {p.company_id} — {p.name}{pending}", p.company_id)
        if current_id:
            idx = self.profile_combo.findData(current_id)
            if idx >= 0:
                self.profile_combo.setCurrentIndex(idx)
        self.profile_combo.blockSignals(False)
        self.profile_changed(self.profile_combo.currentIndex())
        self.validate_btn.setEnabled(bool(self.profiles) and bool(self.paths))

    @Slot(int)
    def profile_changed(self, _index: int):
        profile = None
        idx = self.profile_combo.currentIndex()
        if 0 <= idx < len(self.profiles):
            profile = self.profiles[idx]

        self._loading_quick_ids = True
        try:
            self.company_id_edit.setText(profile.company_id if profile else "")
            self.user_id_edit.setText(profile.user_id if profile else "")
            self.type_id_edit.setText(profile.transparency_type_detail_id if profile else "")
        finally:
            self._loading_quick_ids = False
        self._quick_ids_dirty = False
        self._update_quick_status()

        # Trocar de empresa torna uma validação anterior insegura, pois CNPJ e file_db
        # pertencem ao perfil usado na validação.
        if self.rows and profile and self.validation_signature != self._profile_validation_signature(profile):
            self.invalidate_validation("Empresa/perfil alterado. Valide os PDFs novamente.")

    @Slot(str)
    def quick_ids_changed(self, _value: str):
        if self._loading_quick_ids:
            return
        idx = self.profile_combo.currentIndex()
        if 0 <= idx < len(self.profiles):
            self.profiles[idx].user_id = self.user_id_edit.text().strip()
            self.profiles[idx].transparency_type_detail_id = self.type_id_edit.text().strip()
            self._quick_ids_dirty = True
        self._update_quick_status()

    def _update_quick_status(self):
        p = self.current_profile()
        if not p:
            self.quick_status.setText("Sem empresa")
            self.quick_status.setStyleSheet("color:#991b1b;font-weight:600")
            return
        errors = validate_profile(p)
        if errors:
            self.quick_status.setText("Perfil pendente")
            self.quick_status.setStyleSheet("color:#b45309;font-weight:600")
        elif self._quick_ids_dirty:
            self.quick_status.setText("Pronto • não salvo")
            self.quick_status.setStyleSheet("color:#1d4ed8;font-weight:600")
        else:
            self.quick_status.setText("Pronto")
            self.quick_status.setStyleSheet("color:#166534;font-weight:600")

    def save_quick_ids(self):
        p = self.current_profile()
        if not p:
            return
        errors = validate_profile_for_validation(p)
        if errors:
            QMessageBox.warning(self, "IDs inválidos", "\n".join(f"• {e}" for e in errors))
            return
        try:
            save_profiles(self.profiles)
            self._quick_ids_dirty = False
            self._update_quick_status()
            self._refresh_profile_label_only()
            self.statusBar().showMessage(f"IDs salvos para {p.name}", 4000)
        except Exception as exc:
            QMessageBox.critical(self, "Falha ao salvar", str(exc))

    def _refresh_profile_label_only(self):
        idx = self.profile_combo.currentIndex()
        if not (0 <= idx < len(self.profiles)):
            return
        p = self.profiles[idx]
        pending = "" if not validate_profile(p) else " [PENDENTE]"
        self.profile_combo.setItemText(idx, f"ID {p.company_id} — {p.name}{pending}")

    def manage_profiles(self):
        before = self.current_profile()
        old_sig = self._profile_validation_signature(before) if before else None
        dlg = ProfileDialog(self.profiles, self)
        dlg.exec()
        self._refresh_profiles()
        after = self.current_profile()
        new_sig = self._profile_validation_signature(after) if after else None
        if self.rows and old_sig != new_sig:
            self.invalidate_validation("Dados do perfil alterados. Valide os PDFs novamente.")

    def collect_from_paths(self, items: list[Path]) -> list[Path]:
        out: list[Path] = []
        for p in items:
            if p.is_file() and p.suffix.lower() == ".pdf":
                out.append(p.resolve())
            elif p.is_dir():
                out.extend(x.resolve() for x in p.glob("*.pdf"))
        return out

    @Slot(list)
    def add_paths(self, items: list[Path]):
        if self.thread is not None and self.thread.isRunning():
            self.statusBar().showMessage("Aguarde ou cancele a validação antes de alterar a lista.", 5000)
            return
        found = self.collect_from_paths(items)
        if not found:
            self.statusBar().showMessage("Nenhum PDF válido foi adicionado; a validação atual foi preservada.", 5000)
            return
        existing = {str(p).casefold() for p in self.paths}
        for p in found:
            if str(p).casefold() not in existing:
                self.paths.append(p)
                existing.add(str(p).casefold())
        self.paths.sort(key=lambda p: p.name.casefold())
        self.rows = []
        self.validation_signature = None
        self.render_pending()
        self.export_btn.setEnabled(False)
        self.reexport_btn.setEnabled(False)
        self.confirm_btn.setEnabled(False)
        self.review_btn.setEnabled(False)
        self.validate_btn.setEnabled(bool(self.profiles) and bool(self.paths))
        self._update_summary()

    def pick_files(self):
        if self.thread is not None and self.thread.isRunning():
            return
        names, _ = QFileDialog.getOpenFileNames(self, "Selecionar APRs", "", "PDF (*.pdf)")
        if names:
            self.add_paths([Path(x) for x in names])

    def pick_folder(self):
        if self.thread is not None and self.thread.isRunning():
            return
        folder = QFileDialog.getExistingDirectory(self, "Selecionar pasta de APRs")
        if folder:
            self.add_paths([Path(folder)])

    def render_pending(self):
        self.table.setUpdatesEnabled(False)
        self.table.blockSignals(True)
        try:
            self.table.setRowCount(len(self.paths))
            self._filter_blobs = []
            for i, p in enumerate(self.paths):
                values = ["PENDENTE", p.name, "", "", "", "", "", "", "", "—", "—", "", "Aguardando validação"]
                self._filter_blobs.append(" ".join(values).casefold())
                for c, value in enumerate(values):
                    item = QTableWidgetItem(value)
                    if c == 0:
                        item.setTextAlignment(Qt.AlignCenter)
                        font = item.font()
                        font.setBold(True)
                        item.setFont(font)
                    self.table.setItem(i, c, item)
        finally:
            self.table.blockSignals(False)
            self.table.setUpdatesEnabled(True)
        self.apply_filters()

    def remove_selected(self):
        if self.thread is not None and self.thread.isRunning():
            return
        selected = sorted({idx.row() for idx in self.table.selectionModel().selectedRows()}, reverse=True)
        for row in selected:
            if row < len(self.paths):
                del self.paths[row]
        self.rows = []
        self.validation_signature = None
        self.render_pending()
        self.export_btn.setEnabled(False)
        self.reexport_btn.setEnabled(False)
        self.confirm_btn.setEnabled(False)
        self.review_btn.setEnabled(False)
        self._update_summary()

    def clear_all(self):
        if self.thread is not None and self.thread.isRunning():
            return
        self.paths.clear()
        self.rows.clear()
        self.validation_signature = None
        self.table.setRowCount(0)
        self._filter_blobs = []
        self._selected_detail_index = None
        self.details.clear()
        self.extracted_text_view.clear()
        self.extracted_text_view.setProperty("row_index", -1)
        self.pdf_preview.clear()
        self.export_btn.setEnabled(False)
        self.reexport_btn.setEnabled(False)
        self.confirm_btn.setEnabled(False)
        self.review_btn.setEnabled(False)
        self.validate_btn.setEnabled(False)
        self._update_summary()

    def invalidate_validation(self, message: str):
        self.rows = []
        self.validation_signature = None
        self.render_pending()
        self.export_btn.setEnabled(False)
        self.reexport_btn.setEnabled(False)
        self.confirm_btn.setEnabled(False)
        self.review_btn.setEnabled(False)
        self.statusBar().showMessage(message, 7000)
        self._update_summary()

    @Slot(int)
    def ocr_setting_changed(self, _state: int):
        if self.rows:
            self.invalidate_validation("Configuração de OCR alterada. Valide os PDFs novamente.")
        mode = "ativado" if self.ocr_checkbox.isChecked() else "desativado"
        self.statusBar().showMessage(f"OCR automático {mode}", 4000)

    def cancel_validation(self):
        if self.worker is not None:
            self.worker.request_cancel()
            self.cancel_btn.setEnabled(False)
            self.progress.setFormat("Cancelando após o PDF atual...")
            self.statusBar().showMessage("Cancelando validação...")

    def start_validation(self):
        if self.thread is not None and self.thread.isRunning():
            return
        profile = self.current_profile()
        if not profile:
            QMessageBox.warning(self, "Perfil", "Selecione uma empresa primeiro.")
            return
        errors = validate_profile_for_validation(profile)
        if errors:
            QMessageBox.warning(
                self,
                "Complete os IDs",
                "Antes de validar, informe na tela principal:\n\n" + "\n".join(f"• {e}" for e in errors),
            )
            return
        if not self.paths:
            return

        self.validation_signature = self._profile_validation_signature(profile)
        self.rows = []
        self._last_cache_hits = 0
        self.render_pending()
        self._update_summary()
        self.set_busy(True)
        self.thread = QThread(self)
        self.worker = ValidationWorker(
            list(self.paths), profile, self.history_store, enable_ocr=self.ocr_checkbox.isChecked(),
            cache=self.validation_cache, profile_signature=self._profile_validation_signature(profile),
        )
        self.worker.moveToThread(self.thread)
        self.thread.started.connect(self.worker.run)
        self.worker.progress.connect(self.validation_progress)
        self.worker.stats.connect(self.validation_cache_stats)
        self.worker.finished.connect(self.validation_finished)
        self.worker.failed.connect(self.validation_failed)
        self.worker.cancelled.connect(self.validation_cancelled)
        self.worker.finished.connect(self.thread.quit)
        self.worker.failed.connect(self.thread.quit)
        self.worker.cancelled.connect(self.thread.quit)
        self.thread.finished.connect(self._validation_thread_finished)
        self.thread.finished.connect(self.thread.deleteLater)
        self.thread.start()

    @Slot()
    def _validation_thread_finished(self):
        self.worker = None
        self.thread = None

    def set_busy(self, busy: bool):
        widgets = [
            self.files_btn, self.folder_btn, self.remove_btn, self.clear_btn, self.validate_btn,
            self.profile_btn, self.profile_combo, self.company_id_edit, self.user_id_edit,
            self.type_id_edit, self.save_ids_btn, self.ocr_checkbox, self.history_btn,
            self.open_pdf_btn, self.review_btn, self.valid_only_checkbox, self.published_mode_combo, self.published_date_edit,
        ]
        for w in widgets:
            w.setEnabled(not busy)
        self.drop.set_busy(busy)
        self.profiles_action.setEnabled(not busy)
        self.history_action.setEnabled(not busy)
        self.cancel_btn.setEnabled(busy)
        self.verify_output_btn.setEnabled((not busy) and self.last_output_dir is not None)
        self.export_btn.setEnabled(False if busy else bool(self.rows))
        if not busy:
            self._published_mode_changed()
        if busy:
            self.reexport_btn.setEnabled(False)
            self.confirm_btn.setEnabled(False)
        if busy:
            self.progress.setRange(0, max(1, len(self.paths)))
            self.progress.setValue(0)
            self.progress.setFormat("Iniciando validação...")
            self.statusBar().showMessage("Validando PDFs...")
        else:
            self.progress.setRange(0, max(1, len(self.paths)))
            self.progress.setValue(len(self.paths) if self.rows else 0)
            self.progress.setFormat("Concluído" if self.rows else "Pronto")

    @Slot(int, int, str)
    def validation_progress(self, current: int, total: int, filename: str):
        self.progress.setRange(0, max(1, total))
        self.progress.setValue(current)
        self.progress.setFormat(f"{current}/{total} • {filename}")
        self.statusBar().showMessage(f"Validando {current}/{total}: {filename}")

    @Slot(int)
    def validation_cache_stats(self, hits: int):
        self._last_cache_hits = max(0, int(hits))

    @Slot(object)
    def validation_finished(self, rows):
        # Nunca deixe uma falha de apresentação derrubar a thread/mostrar somente o
        # excepthook global. Os resultados validados são preservados e o detalhe vai
        # para o log para diagnóstico.
        try:
            self.rows = list(rows)
            self.set_busy(False)
            self.render_rows()
            self._update_summary()
            has_errors = any(r.status == "ERRO" for r in self.rows)
            self.export_btn.setEnabled(bool(self.rows))
            self.reexport_btn.setEnabled(any(r.history_override_allowed for r in self.rows))
            self.review_btn.setEnabled(bool(self.rows))
            self.confirm_btn.setEnabled(False)
            self.progress.setValue(len(self.rows))
            self.progress.setFormat(f"{len(self.rows)}/{len(self.rows)} • concluído")
            cache_note = f" • {self._last_cache_hits} reaproveitada(s) do cache" if self._last_cache_hits else ""
            self.statusBar().showMessage(("Validação concluída" if not has_errors else "Validação concluída com erros") + cache_note)
        except Exception as exc:
            LOGGER.exception("Falha ao apresentar resultados da validação")
            self.set_busy(False)
            self.statusBar().showMessage("Validação terminou, mas houve falha ao atualizar a tela")
            QMessageBox.critical(
                self,
                "Falha ao atualizar a tela",
                f"Os PDFs foram processados, mas a interface encontrou um erro ao exibir os resultados:\n\n{exc}\n\n"
                "O detalhe técnico foi salvo no log do APR Manager.",
            )

    @Slot()
    def validation_cancelled(self):
        self.rows = []
        self.validation_signature = None
        self.set_busy(False)
        self.export_btn.setEnabled(False)
        self.reexport_btn.setEnabled(False)
        self.confirm_btn.setEnabled(False)
        self.review_btn.setEnabled(False)
        self.render_pending()
        self._update_summary()
        self.progress.setValue(0)
        self.progress.setFormat("Validação cancelada")
        self.statusBar().showMessage("Validação cancelada", 5000)

    @Slot(str)
    def validation_failed(self, message: str):
        self.set_busy(False)
        self.validation_signature = None
        self.export_btn.setEnabled(False)
        self.reexport_btn.setEnabled(False)
        self.confirm_btn.setEnabled(False)
        self.review_btn.setEnabled(False)
        QMessageBox.critical(self, "Erro na validação", message)
        self.statusBar().showMessage("Falha na validação")

    def render_rows(self):
        self.table.setUpdatesEnabled(False)
        self.table.blockSignals(True)
        try:
            self.table.setRowCount(len(self.rows))
            self._filter_blobs = []
            for i, r in enumerate(self.rows):
                values = [
                    r.status,
                    r.pdf.name,
                    r.filename_number.display if r.filename_number else "",
                    r.effective_number.display if r.effective_number else "",
                    r.effective_apr_date.strftime("%d/%m/%Y") if r.effective_apr_date else "",
                    r.effective_cnpj,
                    r.amount,
                    r.operation_type,
                    r.unit_name,
                    ((f"OCR {int(round(r.ocr_confidence * 100))}%" if r.ocr_used else (r.text_source or "PDF"))
                     + (f" + MANUAL ({r.manual_review_summary})" if r.manually_reviewed else "")),
                    r.history_status or "NOVO",
                    r.file_db,
                    r.messages,
                ]
                self._filter_blobs.append(" ".join(str(v) for v in values).casefold())
                for c, value in enumerate(values):
                    item = QTableWidgetItem(value)
                    if c == 0:
                        item.setTextAlignment(Qt.AlignCenter)
                        font = item.font()
                        font.setBold(True)
                        item.setFont(font)
                        if r.status == "ERRO":
                            item.setBackground(QColor("#fee2e2"))
                            item.setForeground(QColor("#991b1b"))
                        elif r.status == "AVISO":
                            item.setBackground(QColor("#fef3c7"))
                            item.setForeground(QColor("#92400e"))
                        else:
                            item.setBackground(QColor("#dcfce7"))
                            item.setForeground(QColor("#166534"))
                    elif c == 10:
                        if r.history_status in {"JÁ PROCESSADO", "CONFIRMADO", "OUTRA EMPRESA"}:
                            item.setBackground(QColor("#fee2e2"))
                            item.setForeground(QColor("#991b1b"))
                        elif r.history_status == "POSSÍVEL REVISÃO":
                            item.setBackground(QColor("#fef3c7"))
                            item.setForeground(QColor("#92400e"))
                    self.table.setItem(i, c, item)
        finally:
            self.table.blockSignals(False)
            self.table.setUpdatesEnabled(True)
        self.apply_filters()

    def schedule_filter(self, _text: str = ""):
        self._filter_timer.start()

    def apply_filters(self):
        text = self.search_edit.text().strip().casefold() if hasattr(self, "search_edit") else ""
        status = self.status_filter.currentText() if hasattr(self, "status_filter") else "Todos"
        self.table.setUpdatesEnabled(False)
        visible_count = 0
        try:
            for row in range(self.table.rowCount()):
                row_status = self.table.item(row, 0).text() if self.table.item(row, 0) else ""
                combined = self._filter_blobs[row] if row < len(self._filter_blobs) else ""
                visible = (status == "Todos" or row_status == status) and (not text or text in combined)
                self.table.setRowHidden(row, not visible)
                visible_count += int(visible)
        finally:
            self.table.setUpdatesEnabled(True)
        if hasattr(self, "filter_count"):
            total = self.table.rowCount()
            self.filter_count.setText(f"{visible_count} de {total} exibidos")

    def _update_summary(self):
        loaded = len(self.paths)
        if not self.rows:
            self.summary.setText(f"{loaded} PDF(s) carregado(s)")
            self.card_loaded.set_value(loaded)
            self.card_new.set_value(loaded if loaded else 0, "Aguardando validação" if loaded else "PDFs na lista")
            self.card_revision.set_value(0)
            self.card_processed.set_value(0)
            self.card_errors.set_value(0)
            self.card_ocr.set_value(0)
            return

        ok = sum(r.status == "OK" for r in self.rows)
        warn = sum(r.status == "AVISO" for r in self.rows)
        err = sum(r.status == "ERRO" for r in self.rows)
        new_count = sum((r.history_status or "NOVO") == "NOVO" for r in self.rows)
        revisions = sum(r.history_status == "POSSÍVEL REVISÃO" for r in self.rows)
        processed = sum(r.history_status == "JÁ PROCESSADO" for r in self.rows)
        ocr_count = sum(r.ocr_used for r in self.rows)
        manual_count = sum(r.manually_reviewed for r in self.rows)

        self.summary.setText(f"Total {len(self.rows)}  •  OK {ok}  •  Avisos {warn}  •  Erros {err}  •  Revisadas manualmente {manual_count}")
        self.card_loaded.set_value(len(self.rows), "Documentos validados")
        self.card_new.set_value(new_count, "Ainda não processadas")
        self.card_revision.set_value(revisions)
        self.card_processed.set_value(processed)
        self.card_errors.set_value(err)
        self.card_ocr.set_value(ocr_count, "Texto recuperado localmente")

    def _details_tab_changed(self, _index: int):
        self._load_extracted_text_if_needed()

    def _load_extracted_text_if_needed(self):
        if not hasattr(self, "info_tabs") or self.info_tabs.currentIndex() != 1:
            return
        idx = self._selected_detail_index
        if idx is None or idx < 0 or idx >= len(self.rows):
            self.extracted_text_view.clear()
            return
        r = self.rows[idx]
        current_key = self.extracted_text_view.property("row_index")
        if current_key == idx:
            return
        text = r.extracted_text or "(nenhum texto extraído)"
        self.extracted_text_view.setPlainText(text)
        self.extracted_text_view.setProperty("row_index", idx)

    @Slot()
    def show_details(self):
        try:
            self._show_details_impl()
        except Exception as exc:
            LOGGER.exception("Falha ao exibir detalhes da APR selecionada")
            self.statusBar().showMessage(f"Não foi possível abrir os detalhes: {exc}", 7000)

    def _show_details_impl(self):
        selected = self.table.selectionModel().selectedRows()
        if not selected:
            self._selected_detail_index = None
            self.review_btn.setEnabled(False)
            return
        idx = selected[0].row()
        self._selected_detail_index = idx if idx < len(self.rows) else None
        self.extracted_text_view.setProperty("row_index", -1)
        self.extracted_text_view.clear()
        if idx >= len(self.rows):
            if idx < len(self.paths):
                self.details.setPlainText(str(self.paths[idx]))
                self.pdf_preview.load_pdf(self.paths[idx])
            self.review_btn.setEnabled(False)
            return
        r = self.rows[idx]
        self.review_btn.setEnabled(True)
        self.pdf_preview.load_pdf(r.pdf)
        header = [
            f"Arquivo: {r.pdf}",
            f"Status: {r.status}",
            f"SHA-256: {r.sha256}",
            f"Páginas: {r.page_count}",
            f"Fonte do texto: {r.text_source}",
            f"OCR: {'sim' if r.ocr_used else 'não'}",
            f"Provedor OCR: {r.ocr_provider or '-'}",
            f"Confiança OCR: {int(round(r.ocr_confidence * 100)) if r.ocr_used else '-'}{'%' if r.ocr_used else ''}",
            f"Tamanho: {r.size_bytes} bytes",
            "",
            "DADOS DA APR",
            f"Nº/ANO efetivo: {r.name or '-'}",
            f"Nº/ANO detectado no PDF: {r.pdf_number.display if r.pdf_number else '-'}",
            f"Nº/ANO detectado no arquivo: {r.filename_number.display if r.filename_number else '-'}",
            f"Data efetiva: {r.effective_apr_date.strftime('%d/%m/%Y') if r.effective_apr_date else '-'}",
            f"Data detectada no PDF: {r.apr_date.strftime('%d/%m/%Y') if r.apr_date else '-'}",
            f"CNPJ efetivo: {r.effective_cnpj or '-'}",
            f"CNPJ detectado no PDF: {r.cnpj or '-'}",
            f"Unidade: {r.unit_name or '-'}",
            f"Valor: {r.amount or '-'}",
            f"Operação: {r.operation_type or '-'}",
            f"Caminho no banco: {r.file_db or '-'}",
            "",
            "HISTÓRICO / AUDITORIA",
            f"Histórico: {r.history_status or 'NOVO'}",
            f"Detalhe histórico: {r.history_message or '-'}",
            f"Revisão manual: {'SIM - ' + r.manual_review_summary if r.manually_reviewed else 'NÃO'}",
            *([
                f"• {c.applied_at} | {c.reviewer} | {c.field} | {c.action}/{c.method} | {c.original or '-'} -> {c.corrected or '-'} | {c.reason}"
                for c in r.manual_corrections
            ] if r.manual_corrections else ["• nenhuma correção manual nesta sessão"]),
            "",
            "ERROS",
            *(f"• {x}" for x in r.errors),
            *( ["• nenhum"] if not r.errors else [] ),
            "",
            "INFORMAÇÕES",
            *(f"• {x}" for x in r.infos),
            *( ["• nenhuma"] if not r.infos else [] ),
            "",
            "AVISOS",
            *(f"• {x}" for x in r.warnings),
            *( ["• nenhum"] if not r.warnings else [] ),
            "",
            "O texto integral foi movido para a aba 'Texto extraído' para manter a interface rápida.",
        ]
        self.details.setPlainText("\n".join(header))
        self._load_extracted_text_if_needed()

    def selected_pdf_path(self) -> Path | None:
        selected = self.table.selectionModel().selectedRows()
        if not selected:
            return None
        idx = selected[0].row()
        if self.rows and idx < len(self.rows):
            return self.rows[idx].pdf
        if idx < len(self.paths):
            return self.paths[idx]
        return None

    def open_selected_pdf(self):
        path = self.selected_pdf_path()
        if not path:
            QMessageBox.information(self, "Abrir PDF", "Selecione uma APR na tabela.")
            return
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(path)))

    def _selected_row_index(self) -> int | None:
        selected = self.table.selectionModel().selectedRows()
        if not selected:
            return None
        idx = selected[0].row()
        return idx if 0 <= idx < len(self.rows) else None

    def _invalidate_last_export_after_review(self):
        # Uma correção posterior torna qualquer pacote anterior desta sessão obsoleto.
        for row in self.rows:
            row.export_status = ""
        self.last_output_dir = None
        self.confirm_btn.setEnabled(False)
        self.open_output_btn.setEnabled(False)
        self.verify_output_btn.setEnabled(False)

    def _restore_automatic_row(self, idx: int, profile: CompanyProfile) -> APRRecord:
        path = self.rows[idx].pdf
        try:
            st = path.stat()
            key = (
                str(path.resolve()).casefold(), st.st_mtime_ns, st.st_size,
                self._profile_validation_signature(profile), self.ocr_checkbox.isChecked(),
            )
        except OSError:
            key = (str(path).casefold(), 0, 0, self._profile_validation_signature(profile), self.ocr_checkbox.isChecked())
        cached = self.validation_cache.get(key)
        if cached is not None:
            return deepcopy(cached)
        row = validate_one(path, profile, enable_ocr=self.ocr_checkbox.isChecked())
        self.validation_cache[key] = deepcopy(row)
        return row

    def review_selected(self):
        idx = self._selected_row_index()
        if idx is None:
            QMessageBox.information(self, "Revisão manual", "Selecione uma APR validada na tabela.")
            return
        profile = self.current_profile()
        if not profile:
            return
        dlg = ManualReviewDialog(self.rows[idx], self)
        if dlg.exec() != dlg.Accepted:
            return
        try:
            if dlg.reset_requested:
                self.rows[idx] = self._restore_automatic_row(idx, profile)
            else:
                values = dlg.selected_values()
                apply_manual_review(self.rows[idx], profile, **values)
            refresh_batch_checks(self.rows, profile, self.history_store)
            self._invalidate_last_export_after_review()
            self.render_rows()
            self._update_summary()
            self.table.selectRow(idx)
            self.show_details()
            self.export_btn.setEnabled(bool(self.rows))
            self.reexport_btn.setEnabled(any(r.history_override_allowed for r in self.rows))
            self.statusBar().showMessage(
                "Revisão manual aplicada e lote rechecado." if not dlg.reset_requested else "Leitura automática restaurada e lote rechecado.",
                6000,
            )
        except Exception as exc:
            QMessageBox.warning(self, "Revisão manual", str(exc))

    def _sql_rows_for_export(self, allow_history_override: bool) -> list[APRRecord]:
        candidates: list[APRRecord] = []
        for row in self.rows:
            if row.errors:
                continue
            if row.history_blocking and not (allow_history_override and row.history_override_allowed):
                continue
            candidates.append(row)
        if self.valid_only_checkbox.isChecked():
            return candidates
        # Sem a opção "apenas válidas", qualquer erro/bloqueio impede o SQL inteiro.
        if len(candidates) != len(self.rows):
            return []
        return candidates

    def export_results(self, allow_history_override: bool = False):
        if not self.rows:
            return
        profile = self.current_profile()
        if not profile:
            return
        profile_errors = validate_profile(profile)
        if profile_errors:
            QMessageBox.warning(self, "Perfil incompleto", "\n".join(f"• {e}" for e in profile_errors))
            return
        if self.validation_signature != self._profile_validation_signature(profile):
            QMessageBox.warning(
                self, "Validação desatualizada",
                "Os dados da empresa que afetam a validação foram alterados. Valide os PDFs novamente.",
            )
            self.export_btn.setEnabled(False)
            return

        if allow_history_override:
            overridable = [r for r in self.rows if r.history_override_allowed]
            if not overridable:
                QMessageBox.information(self, "Reexportar", "Não há APR confirmada elegível para reexportação.")
                return
            if QMessageBox.question(
                self, "Reexportação excepcional",
                "Você está prestes a reexportar uma APR que já foi marcada como CONFIRMADA no histórico local.\n\n"
                "O SQL é idempotente e tentará não duplicar a APR ativa, mas confirme apenas se realmente precisa gerar o pacote novamente.\n\nContinuar?",
            ) != QMessageBox.Yes:
                return

        sql_rows = self._sql_rows_for_export(allow_history_override)
        published_mode, published_date = self._published_export_settings()
        identity_errors = verify_files_unchanged(sql_rows or [r for r in self.rows if not r.errors])
        if identity_errors:
            QMessageBox.critical(
                self, "Arquivos alterados após a validação",
                "A exportação foi bloqueada porque arquivos mudaram após a validação:\n\n" + "\n".join(f"• {e}" for e in identity_errors),
            )
            self.invalidate_validation("Arquivos alterados. Valide novamente.")
            return

        ok = sum(r.status == "OK" for r in self.rows)
        warn = sum(r.status == "AVISO" for r in self.rows)
        err = sum(r.status == "ERRO" for r in self.rows)
        sql_note = f"SQL: {len(sql_rows)} APR(s)" if sql_rows else "SQL ficará bloqueado; somente relatórios serão gerados"
        message = (
            f"Empresa: {profile.name}\ncompany_id: {profile.company_id}\nuser_id: {profile.user_id}\n"
            f"transparency_type_detail_id: {profile.transparency_type_detail_id}\n"
            f"CNPJ (opcional): {profile.cnpj or 'não cadastrado'}\n\n"
            f"APRs: {len(self.rows)} | OK: {ok} | Avisos: {warn} | Erros: {err}\n{sql_note}\n"
            f"published_in: {self.published_mode_combo.currentText()}"
            + (f" ({self.published_date_edit.date().toString('dd/MM/yyyy')})" if published_mode == "manual" else "")
            + "\n\nContinuar?"
        )
        if QMessageBox.question(self, "Conferência antes da exportação", message) != QMessageBox.Yes:
            return

        folder = QFileDialog.getExistingDirectory(self, "Pasta-base para salvar a nova exportação")
        if not folder:
            return
        try:
            result = export_package(
                Path(folder), self.rows, profile, sql_rows=sql_rows, allow_history_override=allow_history_override,
                published_in_mode=published_mode, published_in_date=published_date,
            )
            out_dir = result["output_dir"]
            self.last_output_dir = out_dir
            self.open_output_btn.setEnabled(True)
            self.verify_output_btn.setEnabled(True)
            if sql_rows:
                for row in sql_rows:
                    row.export_status = "GERADO"
                history_warning = ""
                history_recorded = False
                if self.history_store is not None:
                    try:
                        self.history_store.record_export(sql_rows, profile, out_dir)
                        history_recorded = True
                    except Exception as hist_exc:
                        history_warning = (
                            "\n\nATENÇÃO: o pacote foi criado, mas não foi possível registrar o histórico local: "
                            f"{hist_exc}"
                        )
                self.confirm_btn.setEnabled(history_recorded)
                self.statusBar().showMessage(
                    "Pacote gerado. Confirme o SQL somente depois de executá-lo no banco."
                    if history_recorded else
                    "Pacote gerado, mas houve falha ao registrar o histórico local.",
                    8000,
                )
                QMessageBox.information(
                    self, "Exportação concluída",
                    f"Nova pasta de exportação criada em:\n{out_dir}\n\n"
                    "O pacote inclui CHECKSUMS.sha256 para conferência de integridade.\n\n"
                    + (
                        "O histórico está como GERADO. Depois de executar o SQL com sucesso, clique em 'Confirmar SQL executado'."
                        if history_recorded else
                        "Os arquivos foram gerados, mas o histórico local NÃO foi atualizado. Não descarte esta pasta."
                    )
                    + history_warning,
                )
            else:
                QMessageBox.warning(
                    self, "Relatórios gerados — SQL bloqueado",
                    f"CSV, HTML e manifest foram criados em:\n{out_dir}\n\nO SQL não foi criado porque há erros/bloqueios.",
                )
            self.render_rows()
        except Exception as exc:
            QMessageBox.critical(self, "Falha ao exportar", str(exc))

    def verify_last_output(self):
        if self.last_output_dir is None:
            QMessageBox.information(self, "Verificar pacote", "Nenhum pacote foi exportado nesta sessão.")
            return
        try:
            ok, messages = verify_export_package(self.last_output_dir)
            if ok:
                QMessageBox.information(
                    self, "Pacote íntegro",
                    "A verificação SHA-256 foi concluída com sucesso.\n\n" + "\n".join(messages),
                )
                self.statusBar().showMessage("Pacote exportado íntegro", 5000)
            else:
                QMessageBox.critical(
                    self, "Pacote alterado",
                    "A verificação encontrou problemas:\n\n" + "\n".join(f"• {m}" for m in messages),
                )
                self.statusBar().showMessage("Falha na integridade do pacote", 5000)
        except Exception as exc:
            QMessageBox.critical(self, "Verificar pacote", str(exc))

    def confirm_last_export(self):
        if self.history_store is None or self.last_output_dir is None:
            return
        if QMessageBox.question(
            self, "Confirmar execução",
            "Confirme somente se o arquivo SQL desta última exportação foi executado com sucesso no banco.\n\nMarcar como CONFIRMADO?",
        ) != QMessageBox.Yes:
            return
        try:
            count = self.history_store.confirm_export(self.last_output_dir)
            for row in self.rows:
                if row.export_status == "GERADO":
                    row.export_status = "CONFIRMADO"
                    row.history_status = "CONFIRMADO"
                    row.history_message = "Execução do SQL confirmada pelo usuário"
                    row.history_blocking = True
                    row.history_override_allowed = True
            self.confirm_btn.setEnabled(False)
            self.reexport_btn.setEnabled(any(r.history_override_allowed for r in self.rows))
            self.render_rows()
            QMessageBox.information(self, "Histórico", f"{count} APR(s) marcadas como CONFIRMADAS.")
        except Exception as exc:
            QMessageBox.critical(self, "Histórico", str(exc))

    def closeEvent(self, event):
        if self.thread is not None and self.thread.isRunning():
            QMessageBox.information(
                self, "Validação em andamento",
                "A validação/OCR ainda está em execução. Clique em Cancelar e aguarde o encerramento antes de fechar o APR Manager.",
            )
            event.ignore()
            return
        event.accept()

    def open_history(self):
        if self.history_store is None:
            QMessageBox.warning(
                self,
                "Histórico indisponível",
                "Não foi possível inicializar o histórico local.\n\n" + (self.history_error or "Erro desconhecido"),
            )
            return
        dlg = HistoryDialog(self.history_store, self)
        dlg.exec()

    def open_output(self):
        if self.last_output_dir and self.last_output_dir.exists():
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(self.last_output_dir)))
