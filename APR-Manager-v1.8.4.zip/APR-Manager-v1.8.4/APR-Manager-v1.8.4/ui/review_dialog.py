from __future__ import annotations

import getpass

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QCheckBox,
    QDialog,
    QDialogButtonBox,
    QFormLayout,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QVBoxLayout,
)

from core.manual_review import effective_snapshot, source_snapshot
from core.models import APRRecord


class ManualReviewDialog(QDialog):
    """Revisão assistida dos campos críticos sem alterar o PDF original."""

    def __init__(self, row: APRRecord, parent=None):
        super().__init__(parent)
        self.row = row
        self.reset_requested = False
        self.setWindowTitle("Revisão manual assistida")
        self.setMinimumWidth(680)

        root = QVBoxLayout(self)
        title = QLabel(f"Revisar: {row.pdf.name}")
        title.setStyleSheet("font-size:18px;font-weight:700")
        root.addWidget(title)

        help_text = QLabel(
            "Use esta tela somente depois de conferir visualmente o PDF. "
            "O arquivo original e o SHA-256 não são alterados; toda correção fica registrada no manifest e nos relatórios."
        )
        help_text.setWordWrap(True)
        help_text.setStyleSheet("color:#475569")
        root.addWidget(help_text)

        source = source_snapshot(row)
        effective = effective_snapshot(row)

        compare = QGroupBox("Detectado x valor efetivo")
        grid = QGridLayout(compare)
        grid.addWidget(QLabel("Campo"), 0, 0)
        grid.addWidget(QLabel("Detectado no documento/arquivo"), 0, 1)
        grid.addWidget(QLabel("Valor efetivo atual"), 0, 2)
        labels = [("Nº/ANO", "number"), ("Data da APR", "date"), ("CNPJ", "cnpj")]
        for i, (label, key) in enumerate(labels, start=1):
            grid.addWidget(QLabel(label), i, 0)
            grid.addWidget(QLabel(source.get(key) or "—"), i, 1)
            eff = QLabel(effective.get(key) or "—")
            if row.manually_reviewed and effective.get(key) != source.get(key):
                eff.setStyleSheet("font-weight:700;color:#1d4ed8")
            grid.addWidget(eff, i, 2)
        root.addWidget(compare)

        edit_box = QGroupBox("Correções desta revisão")
        form = QFormLayout(edit_box)

        self.number_check = QCheckBox("Corrigir Nº/ANO")
        self.number_edit = QLineEdit(effective["number"])
        self.number_edit.setPlaceholderText("Ex.: 52/26")
        self._add_field(form, self.number_check, self.number_edit)

        self.date_check = QCheckBox("Corrigir data")
        self.date_edit = QLineEdit(effective["date"])
        self.date_edit.setPlaceholderText("DD/MM/AAAA")
        self._add_field(form, self.date_check, self.date_edit)

        self.cnpj_check = QCheckBox("Corrigir CNPJ (opcional)")
        self.cnpj_edit = QLineEdit(effective["cnpj"])
        self.cnpj_edit.setPlaceholderText("00.000.000/0000-00")
        self._add_field(form, self.cnpj_check, self.cnpj_edit)

        self.reason_edit = QLineEdit("Conferido visualmente no PDF")
        self.reason_edit.setPlaceholderText("Motivo/observação obrigatória")
        form.addRow("Motivo da revisão:", self.reason_edit)
        self.reviewer_edit = QLineEdit(getpass.getuser() or "Usuário local")
        self.reviewer_edit.setPlaceholderText("Responsável pela conferência")
        form.addRow("Revisor:", self.reviewer_edit)
        root.addWidget(edit_box)

        if row.manual_corrections:
            audit = QLabel(
                f"Esta APR já possui {len(row.manual_corrections)} registro(s) de correção nesta sessão. "
                "Uma nova alteração será acrescentada à trilha de auditoria."
            )
            audit.setWordWrap(True)
            audit.setStyleSheet("color:#92400e")
            root.addWidget(audit)

        self.confirm_check = QCheckBox("Confirmo que conferi os valores diretamente no PDF exibido no APR Manager.")
        self.confirm_check.setStyleSheet("font-weight:600")
        root.addWidget(self.confirm_check)

        buttons = QHBoxLayout()
        self.reset_btn = QPushButton("Restaurar leitura automática")
        self.reset_btn.setEnabled(row.manually_reviewed)
        self.reset_btn.clicked.connect(self._reset)
        buttons.addWidget(self.reset_btn)
        buttons.addStretch(1)
        box = QDialogButtonBox(QDialogButtonBox.Cancel | QDialogButtonBox.Save)
        box.button(QDialogButtonBox.Save).setText("Aplicar revisão")
        box.accepted.connect(self._accept_checked)
        box.rejected.connect(self.reject)
        buttons.addWidget(box)
        root.addLayout(buttons)

    @staticmethod
    def _add_field(form: QFormLayout, checkbox: QCheckBox, edit: QLineEdit) -> None:
        wrap = QHBoxLayout()
        wrap.addWidget(checkbox)
        wrap.addWidget(edit, 1)
        form.addRow(wrap)
        edit.textEdited.connect(lambda _text, c=checkbox: c.setChecked(True))

    def _accept_checked(self):
        if not (self.number_check.isChecked() or self.date_check.isChecked() or self.cnpj_check.isChecked()):
            QMessageBox.information(self, "Revisão", "Marque pelo menos um campo para corrigir.")
            return
        if not self.confirm_check.isChecked():
            QMessageBox.warning(self, "Confirmação necessária", "Confirme que os valores foram conferidos no PDF.")
            return
        if len(self.reason_edit.text().strip()) < 3:
            QMessageBox.warning(self, "Motivo", "Informe um motivo/observação para a trilha de auditoria.")
            return
        self.accept()

    def _reset(self):
        if QMessageBox.question(
            self,
            "Restaurar leitura automática",
            "Remover as correções manuais atuais desta APR e voltar a validar o documento pela leitura automática?\n\n"
            "A APR será relida para reconstruir exatamente os erros e avisos originais.",
        ) != QMessageBox.Yes:
            return
        self.reset_requested = True
        self.accept()

    def selected_values(self) -> dict[str, str | None]:
        return {
            "number_text": self.number_edit.text().strip() if self.number_check.isChecked() else None,
            "date_text": self.date_edit.text().strip() if self.date_check.isChecked() else None,
            "cnpj_text": self.cnpj_edit.text().strip() if self.cnpj_check.isChecked() else None,
            "reason": self.reason_edit.text().strip(),
            "reviewer": self.reviewer_edit.text().strip() or "Usuário local",
        }
