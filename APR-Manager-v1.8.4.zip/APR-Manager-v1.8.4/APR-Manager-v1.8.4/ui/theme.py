APP_STYLESHEET = r"""
QMainWindow, QDialog {
    background: #f4f7fb;
    color: #172033;
    font-family: "Segoe UI";
    font-size: 10pt;
}
QWidget {
    color: #172033;
    font-family: "Segoe UI";
    font-size: 10pt;
}
QLabel { background: transparent; }
QToolTip {
    background: #172033;
    color: #ffffff;
    border: 0;
    padding: 6px 8px;
    border-radius: 5px;
}
QMenuBar {
    background: #ffffff;
    border-bottom: 1px solid #dfe6f1;
    padding: 2px;
}
QMenuBar::item { padding: 6px 10px; border-radius: 5px; }
QMenuBar::item:selected { background: #edf4ff; }
QMenu { background: #ffffff; border: 1px solid #dfe6f1; padding: 5px; }
QMenu::item { padding: 7px 26px 7px 10px; border-radius: 5px; }
QMenu::item:selected { background: #edf4ff; }


QScrollArea#mainScroll {
    background: #f4f7fb;
    border: 0;
}
QWidget#mainContent { background: #f4f7fb; }
QFrame#filterPanel { background: transparent; border: 0; }

QFrame#hero, QFrame#panel, QFrame#quickPanel, QFrame#actionBar, QFrame#summaryCard {
    background: #ffffff;
    border: 1px solid #dfe6f1;
    border-radius: 12px;
}
QFrame#hero {
    border-radius: 15px;
    border-left: 4px solid #2563eb;
}
QFrame#actionBar { background: #fbfcfe; }

QFrame#dropArea {
    background: #f8fbff;
    border: 2px dashed #b7c7dc;
    border-radius: 12px;
}
QFrame#dropArea:hover { background: #f2f7ff; border-color: #60a5fa; }
QLabel#dropTitle { color: #233654; font-size: 12pt; font-weight: 700; }
QLabel#dropSubtitle { color: #7a8ba3; font-size: 9pt; }
QLabel#heroTitle { font-size: 18pt; font-weight: 750; color: #10213f; }
QLabel#heroSubtitle { color: #64748b; font-size: 10pt; }
QLabel#filterCount { color: #64748b; font-size: 9pt; padding-left: 6px; }
QLabel#sectionLabel {
    color: #64748b;
    font-size: 8pt;
    font-weight: 750;
    letter-spacing: 1px;
    padding-right: 5px;
}
QLabel#cardTitle { color: #64748b; font-size: 9pt; font-weight: 650; }
QLabel#cardValue { color: #12213f; font-size: 18pt; font-weight: 750; }
QLabel#cardHint { color: #94a3b8; font-size: 8pt; }
QFrame#summaryCard[tone="blue"] { border-top: 3px solid #3b82f6; }
QFrame#summaryCard[tone="green"] { border-top: 3px solid #22c55e; }
QFrame#summaryCard[tone="amber"] { border-top: 3px solid #f59e0b; }
QFrame#summaryCard[tone="slate"] { border-top: 3px solid #64748b; }
QFrame#summaryCard[tone="red"] { border-top: 3px solid #ef4444; }
QFrame#summaryCard[tone="violet"] { border-top: 3px solid #8b5cf6; }

QPushButton {
    background: #ffffff;
    border: 1px solid #cfd9e8;
    border-radius: 8px;
    padding: 6px 9px;
    font-weight: 600;
    min-height: 16px;
}
QPushButton:hover { background: #f5f8fd; border-color: #9bb4dc; }
QPushButton:pressed { background: #eaf0fa; }
QPushButton:disabled { color: #9aa7b8; background: #f1f4f8; border-color: #e2e8f0; }
QPushButton#primaryButton {
    background: #2563eb;
    color: #ffffff;
    border-color: #2563eb;
    padding-left: 13px;
    padding-right: 13px;
}
QPushButton#primaryButton:hover { background: #1d4ed8; border-color: #1d4ed8; }
QPushButton#primaryButton:pressed { background: #1e40af; }
QPushButton#dangerButton { color: #b91c1c; border-color: #fecaca; background: #fffafa; }
QPushButton#dangerButton:hover { background: #fef2f2; border-color: #fca5a5; }

QLineEdit, QComboBox, QPlainTextEdit, QTableWidget, QSpinBox, QDateEdit, QListWidget {
    background: #ffffff;
    border: 1px solid #cfd9e8;
    border-radius: 7px;
    padding: 5px 7px;
    selection-background-color: #dbeafe;
    selection-color: #172033;
}
QLineEdit:focus, QComboBox:focus, QPlainTextEdit:focus, QTableWidget:focus,
QListWidget:focus, QSpinBox:focus, QDateEdit:focus {
    border: 1px solid #6b9df5;
}
QLineEdit[readOnly="true"] { background: #f5f7fa; color: #5f6f85; }
QComboBox::drop-down { border: 0; width: 24px; }

QTableWidget {
    gridline-color: #e8edf4;
    alternate-background-color: #f9fbfd;
    border-radius: 10px;
}
QTableWidget::item { padding: 5px 6px; border-bottom: 1px solid #f0f3f7; }
QTableWidget::item:selected { background: #dceaff; color: #10213f; }
QHeaderView::section {
    background: #eef3f9;
    color: #46556d;
    border: 0;
    border-right: 1px solid #e1e7f0;
    border-bottom: 1px solid #d8e0eb;
    padding: 8px 6px;
    font-weight: 700;
}

QTabWidget#inspectorTabs::pane {
    border: 1px solid #dfe6f1;
    border-radius: 9px;
    background: #ffffff;
    top: -1px;
}
QTabBar::tab {
    background: #eaf0f7;
    color: #5c6b81;
    border: 1px solid #dfe6f1;
    border-bottom: 0;
    padding: 7px 14px;
    margin-right: 2px;
    border-top-left-radius: 7px;
    border-top-right-radius: 7px;
}
QTabBar::tab:selected { background: #ffffff; color: #1d4ed8; font-weight: 700; }

QFrame#pdfToolbar {
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 8px;
}
QScrollArea#pdfScroll { background: #e9eef5; border: 1px solid #dfe6f1; border-radius: 8px; }
QLabel#pdfPage { background: #ffffff; color: #64748b; padding: 12px; }

QProgressBar {
    background: #e8edf5;
    border: 0;
    border-radius: 6px;
    text-align: center;
    min-height: 20px;
    color: #334155;
}
QProgressBar::chunk { background: #3b82f6; border-radius: 6px; }
QCheckBox { spacing: 7px; }
QStatusBar { background: #ffffff; border-top: 1px solid #dfe6f1; color: #5c6b81; }
QSplitter::handle { background: #dfe6f1; width: 2px; height: 2px; }
QScrollBar:vertical { background: #f4f7fb; width: 11px; margin: 0; }
QScrollBar::handle:vertical { background: #cbd5e1; min-height: 28px; border-radius: 5px; }
QScrollBar::handle:vertical:hover { background: #94a3b8; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
QScrollBar:horizontal { background: #f4f7fb; height: 11px; margin: 0; }
QScrollBar::handle:horizontal { background: #cbd5e1; min-width: 28px; border-radius: 5px; }
QScrollBar::handle:horizontal:hover { background: #94a3b8; }
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal { width: 0; }
"""
