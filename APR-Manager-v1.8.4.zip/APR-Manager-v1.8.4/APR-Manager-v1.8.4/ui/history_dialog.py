from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt, QUrl
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import (
    QAbstractItemView,
    QDialog,
    QFileDialog,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
)

from core.history import HistoryEntry, HistoryStore


class HistoryDialog(QDialog):
    def __init__(self, store: HistoryStore, parent=None):
        super().__init__(parent)
        self.store = store
        self.entries: list[HistoryEntry] = []
        self.setWindowTitle("Histórico local de APRs")
        self.resize(1040, 620)
        self.setMinimumSize(760, 480)
        self._build_ui()
        self.reload()

    def _build_ui(self):
        layout = QVBoxLayout(self)

        top = QHBoxLayout()
        self.summary = QLabel()
        self.summary.setStyleSheet("font-weight:600")
        top.addWidget(self.summary)
        top.addStretch(1)
        self.search = QLineEdit()
        self.search.setPlaceholderText("Pesquisar empresa, APR, arquivo, CNPJ, SHA-256...")
        self.search.setMinimumWidth(360)
        self.search.textChanged.connect(self.apply_filter)
        top.addWidget(self.search)
        layout.addLayout(top)

        self.table = QTableWidget(0, 13)
        self.table.setHorizontalHeaderLabels([
            "Último processamento", "Estado", "Confirmado em", "Empresa", "company_id", "APR", "Data APR", "Arquivo",
            "CNPJ", "SHA-256", "Vezes", "Versão", "Pasta de saída"
        ])
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.verticalHeader().setVisible(False)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(3, QHeaderView.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(7, QHeaderView.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(12, QHeaderView.Stretch)
        layout.addWidget(self.table, 1)

        buttons = QHBoxLayout()
        self.refresh_btn = QPushButton("Atualizar")
        self.export_btn = QPushButton("Exportar histórico CSV")
        self.open_folder_btn = QPushButton("Abrir pasta de saída")
        self.confirm_btn = QPushButton("Marcar como confirmado")
        self.remove_btn = QPushButton("Remover registro selecionado")
        self.close_btn = QPushButton("Fechar")
        buttons.addWidget(self.refresh_btn)
        buttons.addWidget(self.export_btn)
        buttons.addWidget(self.open_folder_btn)
        buttons.addStretch(1)
        buttons.addWidget(self.confirm_btn)
        buttons.addWidget(self.remove_btn)
        buttons.addWidget(self.close_btn)
        layout.addLayout(buttons)

        self.refresh_btn.clicked.connect(self.reload)
        self.export_btn.clicked.connect(self.export_csv)
        self.open_folder_btn.clicked.connect(self.open_output_folder)
        self.confirm_btn.clicked.connect(self.confirm_selected)
        self.remove_btn.clicked.connect(self.remove_selected)
        self.close_btn.clicked.connect(self.accept)

    def reload(self):
        try:
            self.entries = self.store.list_entries()
        except Exception as exc:
            QMessageBox.critical(self, "Histórico", f"Não foi possível abrir o histórico local:\n{exc}")
            self.entries = []
        self.table.setRowCount(len(self.entries))
        for i, e in enumerate(self.entries):
            values = [
                e.last_processed_at,
                e.state.upper(),
                e.confirmed_at,
                e.company_name,
                e.company_id,
                e.apr_name or e.canonical_number,
                e.apr_date,
                e.filename,
                e.cnpj,
                e.sha256,
                str(e.process_count),
                e.app_version,
                e.output_dir,
            ]
            for c, value in enumerate(values):
                item = QTableWidgetItem(value)
                item.setData(Qt.UserRole, e.id)
                self.table.setItem(i, c, item)
        self.summary.setText(f"{len(self.entries)} APR(s) registradas no histórico local")
        self.apply_filter()

    def apply_filter(self):
        term = self.search.text().strip().casefold()
        for row in range(self.table.rowCount()):
            text = " ".join(
                self.table.item(row, col).text()
                for col in range(self.table.columnCount())
                if self.table.item(row, col)
            ).casefold()
            self.table.setRowHidden(row, bool(term) and term not in text)

    def _selected_entry(self) -> HistoryEntry | None:
        rows = self.table.selectionModel().selectedRows()
        if not rows:
            return None
        row = rows[0].row()
        item = self.table.item(row, 0)
        if not item:
            return None
        entry_id = item.data(Qt.UserRole)
        for e in self.entries:
            if e.id == entry_id:
                return e
        return None

    def open_output_folder(self):
        entry = self._selected_entry()
        if not entry:
            QMessageBox.information(self, "Histórico", "Selecione um registro.")
            return
        path = Path(entry.output_dir)
        if not path.exists():
            QMessageBox.warning(self, "Histórico", "A pasta de saída registrada não existe mais neste computador.")
            return
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(path)))

    def confirm_selected(self):
        entry = self._selected_entry()
        if not entry:
            QMessageBox.information(self, "Histórico", "Selecione um registro.")
            return
        if entry.state == "confirmed":
            QMessageBox.information(self, "Histórico", "Este registro já está confirmado.")
            return
        if QMessageBox.question(
            self, "Confirmar SQL executado",
            f"Marcar como CONFIRMADO?\n\nEmpresa: {entry.company_name or entry.company_id}\n"
            f"APR: {entry.apr_name or entry.canonical_number}\nArquivo: {entry.filename}",
        ) != QMessageBox.Yes:
            return
        try:
            self.store.confirm_entry(entry.id)
            self.reload()
        except Exception as exc:
            QMessageBox.critical(self, "Histórico", str(exc))

    def remove_selected(self):
        entry = self._selected_entry()
        if not entry:
            QMessageBox.information(self, "Histórico", "Selecione um registro.")
            return
        msg = (
            f"Remover do histórico local?\n\n"
            f"Empresa: {entry.company_name or entry.company_id}\n"
            f"APR: {entry.apr_name or entry.canonical_number}\n"
            f"Arquivo: {entry.filename}\n\n"
            "Isso NÃO apaga PDF, SQL, FTP ou registros do banco do RPPS. "
            "Apenas remove a proteção local contra reprocessamento."
        )
        if QMessageBox.question(self, "Remover do histórico", msg) != QMessageBox.Yes:
            return
        try:
            self.store.remove_entry(entry.id)
            self.reload()
        except Exception as exc:
            QMessageBox.critical(self, "Histórico", str(exc))

    def export_csv(self):
        filename, _ = QFileDialog.getSaveFileName(
            self,
            "Exportar histórico",
            "historico_apr_manager.csv",
            "CSV (*.csv)",
        )
        if not filename:
            return
        path = Path(filename)
        if path.suffix.lower() != ".csv":
            path = path.with_suffix(".csv")
        try:
            self.store.export_csv(path)
            QMessageBox.information(self, "Histórico", f"Histórico exportado em:\n{path}")
        except Exception as exc:
            QMessageBox.critical(self, "Histórico", f"Falha ao exportar:\n{exc}")
