from __future__ import annotations

import csv
import sqlite3
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Iterable

from .models import APRRecord, CompanyProfile
from .profiles import local_app_data_dir
from .utils import csv_safe
from .version import APP_VERSION


@dataclass
class HistoryEntry:
    id: int
    company_id: str
    company_name: str
    user_id: str
    transparency_type_detail_id: str
    canonical_number: str
    apr_name: str
    apr_date: str
    cnpj: str
    filename: str
    sha256: str
    file_db: str
    output_dir: str
    first_processed_at: str
    last_processed_at: str
    process_count: int
    app_version: str
    state: str = "generated"
    confirmed_at: str = ""
    export_id: str = ""


class HistoryStore:
    """Histórico local com estados GENERATED/CONFIRMED.

    Gerar um SQL não significa que ele foi executado no banco. Por isso a
    proteção forte só é aplicada a registros confirmados pelo usuário.
    """

    def __init__(self, db_path: Path | None = None):
        self.db_path = Path(db_path) if db_path else local_app_data_dir() / "history.sqlite3"
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._ensure_schema()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        conn.execute("PRAGMA journal_mode = WAL")
        conn.execute("PRAGMA synchronous = NORMAL")
        return conn


    @contextmanager
    def _connection(self):
        conn = self._connect()
        try:
            with conn:
                yield conn
        finally:
            conn.close()

    def _ensure_schema(self) -> None:
        with self._connection() as conn:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS processed_aprs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    company_id TEXT NOT NULL,
                    company_name TEXT NOT NULL DEFAULT '',
                    user_id TEXT NOT NULL DEFAULT '',
                    transparency_type_detail_id TEXT NOT NULL DEFAULT '',
                    canonical_number TEXT NOT NULL DEFAULT '',
                    apr_name TEXT NOT NULL DEFAULT '',
                    apr_date TEXT NOT NULL DEFAULT '',
                    cnpj TEXT NOT NULL DEFAULT '',
                    filename TEXT NOT NULL DEFAULT '',
                    sha256 TEXT NOT NULL,
                    file_db TEXT NOT NULL DEFAULT '',
                    output_dir TEXT NOT NULL DEFAULT '',
                    first_processed_at TEXT NOT NULL,
                    last_processed_at TEXT NOT NULL,
                    process_count INTEGER NOT NULL DEFAULT 1,
                    app_version TEXT NOT NULL DEFAULT '',
                    state TEXT NOT NULL DEFAULT 'generated',
                    confirmed_at TEXT NOT NULL DEFAULT '',
                    export_id TEXT NOT NULL DEFAULT '',
                    UNIQUE(company_id, sha256)
                );
                CREATE INDEX IF NOT EXISTS idx_processed_aprs_company_canonical
                    ON processed_aprs(company_id, canonical_number);
                CREATE INDEX IF NOT EXISTS idx_processed_aprs_sha256
                    ON processed_aprs(sha256);
                CREATE INDEX IF NOT EXISTS idx_processed_aprs_last_processed
                    ON processed_aprs(last_processed_at DESC);
                """
            )
            cols = {r[1] for r in conn.execute("PRAGMA table_info(processed_aprs)").fetchall()}
            migrations = {
                "state": "ALTER TABLE processed_aprs ADD COLUMN state TEXT NOT NULL DEFAULT 'generated'",
                "confirmed_at": "ALTER TABLE processed_aprs ADD COLUMN confirmed_at TEXT NOT NULL DEFAULT ''",
                "export_id": "ALTER TABLE processed_aprs ADD COLUMN export_id TEXT NOT NULL DEFAULT ''",
            }
            for name, sql in migrations.items():
                if name not in cols:
                    conn.execute(sql)

    @staticmethod
    def _row_to_entry(row: sqlite3.Row | None) -> HistoryEntry | None:
        if row is None:
            return None
        keys = set(row.keys())
        return HistoryEntry(
            id=int(row["id"]),
            company_id=str(row["company_id"]),
            company_name=str(row["company_name"]),
            user_id=str(row["user_id"]),
            transparency_type_detail_id=str(row["transparency_type_detail_id"]),
            canonical_number=str(row["canonical_number"]),
            apr_name=str(row["apr_name"]),
            apr_date=str(row["apr_date"]),
            cnpj=str(row["cnpj"]),
            filename=str(row["filename"]),
            sha256=str(row["sha256"]),
            file_db=str(row["file_db"]),
            output_dir=str(row["output_dir"]),
            first_processed_at=str(row["first_processed_at"]),
            last_processed_at=str(row["last_processed_at"]),
            process_count=int(row["process_count"]),
            app_version=str(row["app_version"]),
            state=str(row["state"]) if "state" in keys else "generated",
            confirmed_at=str(row["confirmed_at"]) if "confirmed_at" in keys else "",
            export_id=str(row["export_id"]) if "export_id" in keys else "",
        )

    def find_same_hash(self, sha256: str, company_id: str | None = None) -> list[HistoryEntry]:
        if not sha256:
            return []
        with self._connection() as conn:
            if company_id is None:
                rows = conn.execute(
                    "SELECT * FROM processed_aprs WHERE sha256 = ? ORDER BY last_processed_at DESC", (sha256,)
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM processed_aprs WHERE sha256 = ? AND company_id = ? ORDER BY last_processed_at DESC",
                    (sha256, company_id),
                ).fetchall()
        return [self._row_to_entry(r) for r in rows if r is not None]  # type: ignore[list-item]

    def find_same_canonical(self, company_id: str, canonical_number: str) -> list[HistoryEntry]:
        if not company_id or not canonical_number:
            return []
        with self._connection() as conn:
            rows = conn.execute(
                "SELECT * FROM processed_aprs WHERE company_id = ? AND canonical_number = ? ORDER BY last_processed_at DESC",
                (company_id, canonical_number),
            ).fetchall()
        return [self._row_to_entry(r) for r in rows if r is not None]  # type: ignore[list-item]

    def apply_checks(self, rows: list[APRRecord], profile: CompanyProfile) -> None:
        """Consulta o histórico em lote, evitando duas conexões/queries por APR."""
        history_warning_prefixes = (
            "este PDF já foi exportado antes",
            "APR ",
        )
        for row in rows:
            row.warnings[:] = [
                w for w in row.warnings
                if not (w.startswith(history_warning_prefixes[0]) or (w.startswith("APR ") and "histórico" in w))
            ]
            row.history_status = "NOVO"
            row.history_message = "Não encontrado no histórico local"
            row.history_blocking = False
            row.history_override_allowed = False

        hashes = sorted({r.sha256 for r in rows if r.sha256})
        canonicals = sorted({r.canonical_number for r in rows if r.canonical_number})
        by_hash: dict[str, list[HistoryEntry]] = {}
        by_canonical: dict[str, list[HistoryEntry]] = {}

        with self._connection() as conn:
            if hashes:
                qs = ",".join("?" for _ in hashes)
                found = conn.execute(
                    f"SELECT * FROM processed_aprs WHERE sha256 IN ({qs}) ORDER BY last_processed_at DESC", hashes
                ).fetchall()
                for raw in found:
                    e = self._row_to_entry(raw)
                    if e:
                        by_hash.setdefault(e.sha256, []).append(e)
            if canonicals:
                qs = ",".join("?" for _ in canonicals)
                params = [profile.company_id, *canonicals]
                found = conn.execute(
                    f"SELECT * FROM processed_aprs WHERE company_id = ? AND canonical_number IN ({qs}) ORDER BY last_processed_at DESC",
                    params,
                ).fetchall()
                for raw in found:
                    e = self._row_to_entry(raw)
                    if e:
                        by_canonical.setdefault(e.canonical_number, []).append(e)

        for row in rows:
            same_hash = by_hash.get(row.sha256, []) if row.sha256 else []
            same_company = [e for e in same_hash if e.company_id == profile.company_id]
            other_company = [e for e in same_hash if e.company_id != profile.company_id]

            if same_company:
                entry = same_company[0]
                if entry.state == "confirmed":
                    row.history_status = "CONFIRMADO"
                    row.history_message = (
                        f"Mesmo PDF confirmado em {entry.confirmed_at or entry.last_processed_at} "
                        f"para {entry.company_name or entry.company_id}"
                    )
                    row.history_blocking = True
                    row.history_override_allowed = True
                else:
                    row.history_status = "JÁ GERADO"
                    row.history_message = (
                        f"Mesmo PDF já teve SQL gerado em {entry.last_processed_at}, mas a execução não foi confirmada"
                    )
                    row.warnings.append(
                        "este PDF já foi exportado antes, porém ainda não foi marcado como executado no banco"
                    )
                continue

            if other_company:
                entry = other_company[0]
                row.history_status = "OUTRA EMPRESA"
                row.history_message = (
                    f"Mesmo conteúdo consta na empresa {entry.company_name or entry.company_id} "
                    f"({entry.state}) em {entry.last_processed_at}"
                )
                row.history_blocking = True
                row.history_override_allowed = False
                continue

            same_canonical = by_canonical.get(row.canonical_number, []) if row.canonical_number else []
            if same_canonical:
                entry = same_canonical[0]
                row.history_status = "POSSÍVEL REVISÃO"
                row.history_message = (
                    f"APR {row.name or row.canonical_number} já teve outro PDF exportado em {entry.last_processed_at}"
                )
                msg = (
                    f"APR {row.name or row.canonical_number} já aparece no histórico com outro conteúdo; "
                    "confira se este arquivo é uma revisão/substituição"
                )
                if msg not in row.warnings:
                    row.warnings.append(msg)

    def record_export(self, rows: Iterable[APRRecord], profile: CompanyProfile, output_dir: Path) -> None:
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        export_id = Path(output_dir).name
        payload = []
        for row in rows:
            if row.errors or not row.sha256:
                continue
            payload.append(
                (
                    profile.company_id, profile.name, profile.user_id, profile.transparency_type_detail_id,
                    row.canonical_number, row.name,
                    row.effective_apr_date.strftime("%Y-%m-%d") if row.effective_apr_date else "",
                    row.effective_cnpj, row.pdf.name, row.sha256, row.file_db,
                    str(Path(output_dir).resolve()), now, now, APP_VERSION, "generated", "", export_id,
                )
            )
        if not payload:
            return
        with self._connection() as conn:
            conn.executemany(
                """
                INSERT INTO processed_aprs (
                    company_id, company_name, user_id, transparency_type_detail_id,
                    canonical_number, apr_name, apr_date, cnpj, filename, sha256,
                    file_db, output_dir, first_processed_at, last_processed_at, app_version,
                    state, confirmed_at, export_id
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(company_id, sha256) DO UPDATE SET
                    company_name = excluded.company_name,
                    user_id = excluded.user_id,
                    transparency_type_detail_id = excluded.transparency_type_detail_id,
                    canonical_number = excluded.canonical_number,
                    apr_name = excluded.apr_name,
                    apr_date = excluded.apr_date,
                    cnpj = excluded.cnpj,
                    filename = excluded.filename,
                    file_db = excluded.file_db,
                    output_dir = excluded.output_dir,
                    last_processed_at = excluded.last_processed_at,
                    process_count = processed_aprs.process_count + 1,
                    app_version = excluded.app_version,
                    state = CASE WHEN processed_aprs.state = 'confirmed' THEN 'confirmed' ELSE 'generated' END,
                    confirmed_at = CASE WHEN processed_aprs.state = 'confirmed' THEN processed_aprs.confirmed_at ELSE '' END,
                    export_id = excluded.export_id
                """,
                payload,
            )

    def confirm_export(self, output_dir: Path) -> int:
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        path = str(Path(output_dir).resolve())
        with self._connection() as conn:
            cur = conn.execute(
                "UPDATE processed_aprs SET state='confirmed', confirmed_at=?, last_processed_at=? WHERE output_dir=?",
                (now, now, path),
            )
            return cur.rowcount

    def confirm_entry(self, entry_id: int) -> bool:
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with self._connection() as conn:
            cur = conn.execute(
                "UPDATE processed_aprs SET state='confirmed', confirmed_at=?, last_processed_at=? WHERE id=?",
                (now, now, int(entry_id)),
            )
            return cur.rowcount > 0

    def list_entries(self, limit: int = 5000) -> list[HistoryEntry]:
        with self._connection() as conn:
            rows = conn.execute(
                "SELECT * FROM processed_aprs ORDER BY last_processed_at DESC, id DESC LIMIT ?", (max(1, int(limit)),)
            ).fetchall()
        return [self._row_to_entry(r) for r in rows if r is not None]  # type: ignore[list-item]

    def remove_entry(self, entry_id: int) -> bool:
        with self._connection() as conn:
            cur = conn.execute("DELETE FROM processed_aprs WHERE id = ?", (int(entry_id),))
            return cur.rowcount > 0

    def clear(self) -> None:
        with self._connection() as conn:
            conn.execute("DELETE FROM processed_aprs")

    def export_csv(self, path: Path) -> None:
        entries = self.list_entries()
        path.parent.mkdir(parents=True, exist_ok=True)
        fields = [
            "id", "last_processed_at", "state", "confirmed_at", "company_id", "company_name", "user_id",
            "transparency_type_detail_id", "canonical_number", "apr_name", "apr_date", "cnpj", "filename",
            "sha256", "file_db", "output_dir", "export_id", "process_count", "app_version",
        ]
        with path.open("w", encoding="utf-8-sig", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fields, delimiter=";")
            writer.writeheader()
            for e in entries:
                writer.writerow({name: csv_safe(getattr(e, name)) for name in fields})
