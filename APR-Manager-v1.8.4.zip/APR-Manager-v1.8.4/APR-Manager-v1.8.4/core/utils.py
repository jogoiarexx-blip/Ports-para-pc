from __future__ import annotations

import hashlib
import os
import re
import tempfile
import unicodedata
from pathlib import Path

CNPJ_DIGITS_RE = re.compile(r"\D+")
CSV_FORMULA_PREFIXES = ("=", "+", "-", "@")


def only_digits(value: str) -> str:
    return re.sub(r"\D", "", value or "")


def normalize_cnpj(value: str) -> str:
    digits = only_digits(value)
    if len(digits) != 14:
        return digits
    return f"{digits[:2]}.{digits[2:5]}.{digits[5:8]}/{digits[8:12]}-{digits[12:]}"


def cnpj_is_valid(value: str) -> bool:
    digits = only_digits(value)
    if len(digits) != 14 or len(set(digits)) == 1:
        return False

    def calc(base: str, weights: list[int]) -> str:
        total = sum(int(d) * w for d, w in zip(base, weights))
        rem = total % 11
        return str(0 if rem < 2 else 11 - rem)

    d1 = calc(digits[:12], [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2])
    d2 = calc(digits[:12] + d1, [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2])
    return digits[-2:] == d1 + d2


def sha256_file(path: Path, chunk_size: int = 4 * 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as f:
        while chunk := f.read(chunk_size):
            digest.update(chunk)
    return digest.hexdigest()


def sql_quote(value: str) -> str:
    return "'" + str(value).replace("\\", "/").replace("'", "''") + "'"


def atomic_write_text(path: Path, content: str, encoding: str = "utf-8") -> None:
    """Escreve em arquivo temporário e troca o destino atomicamente.

    Evita deixar JSON/SQL/relatórios truncados quando o processo é interrompido.
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding=encoding, newline="") as f:
            f.write(content)
            f.flush()
            os.fsync(f.fileno())
        os.replace(temp_name, path)
    except Exception:
        try:
            os.remove(temp_name)
        except OSError:
            pass
        raise


def csv_safe(value: object) -> str:
    """Evita interpretação como fórmula em Excel/LibreOffice."""
    text = "" if value is None else str(value)
    stripped = text.lstrip()
    if stripped.startswith(CSV_FORMULA_PREFIXES):
        # Apostrofo é interpretado por planilhas como texto e preserva o valor visual.
        return "'" + text
    return text


def normalize_words(value: str) -> set[str]:
    """Tokenização simples, acento-insensível, para comparar nomes de entidades."""
    normalized = unicodedata.normalize("NFKD", value or "")
    normalized = "".join(ch for ch in normalized if not unicodedata.combining(ch)).casefold()
    tokens = set(re.findall(r"[a-z0-9]{3,}", normalized))
    stop = {
        "dos", "das", "de", "da", "do", "e", "municipal", "municipais", "municipio",
        "publico", "publicos", "servidor", "servidores", "instituto", "previdencia", "rpps",
    }
    return {t for t in tokens if t not in stop}


def token_similarity(a: str, b: str) -> float:
    ta, tb = normalize_words(a), normalize_words(b)
    if not ta or not tb:
        return 0.0
    return len(ta & tb) / len(ta | tb)
