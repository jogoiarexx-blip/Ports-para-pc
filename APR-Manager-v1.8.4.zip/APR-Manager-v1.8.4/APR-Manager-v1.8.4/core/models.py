from __future__ import annotations

from dataclasses import dataclass, field, asdict
from datetime import datetime
from pathlib import Path
from typing import Optional


@dataclass(frozen=True)
class ParsedNumber:
    num_raw: str
    year_raw: str
    num_int: int
    year4: int

    @property
    def display(self) -> str:
        """Formato padronizado usado no banco: preserva o número e reduz o ano para 2 dígitos."""
        return f"{self.num_raw}/{self.year4 % 100:02d}"

    @property
    def raw_display(self) -> str:
        return f"{self.num_raw}/{self.year_raw}"

    @property
    def canonical(self) -> str:
        return f"{self.year4}:{self.num_int}"


@dataclass
class ManualCorrection:
    field: str
    original: str
    corrected: str
    action: str = "corrected"
    method: str = "manual_visual_pdf"
    reason: str = ""
    applied_at: str = ""
    reviewer: str = "Usuário local"

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class CompanyProfile:
    name: str
    company_id: str
    user_id: str
    transparency_type_detail_id: str
    cnpj: str = ""
    unit_name: str = ""
    catalog_db_name: str = ""
    catalog_sub_title: str = ""
    db_host: str = ""
    db_port: str = "3306"
    upload_host: str = ""
    upload_port: str = "22"
    upload_protocol: str = "SFTP"
    remote_template: str = ""
    file_template: str = "/dist/uploads/files/{company_id}/aplicacoes-e-investimentos/apr/{year4}/{filename}"

    def to_dict(self) -> dict:
        return asdict(self)

    def to_manifest_dict(self) -> dict:
        """Dados não sensíveis/relevantes para auditoria do pacote exportado.

        Hosts/portas de infraestrutura não são gravados no manifest.
        """
        return {
            "name": self.name,
            "company_id": self.company_id,
            "user_id": self.user_id,
            "transparency_type_detail_id": self.transparency_type_detail_id,
            "cnpj": self.cnpj,
            "unit_name": self.unit_name,
            "catalog_db_name": self.catalog_db_name,
            "catalog_sub_title": self.catalog_sub_title,
            "file_template": self.file_template,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "CompanyProfile":
        return cls(
            name=str(data.get("name", "")).strip(),
            company_id=str(data.get("company_id", "")).strip(),
            user_id=str(data.get("user_id", "")).strip(),
            transparency_type_detail_id=str(data.get("transparency_type_detail_id", "")).strip(),
            cnpj=str(data.get("cnpj", "")).strip(),
            unit_name=str(data.get("unit_name", "")).strip(),
            catalog_db_name=str(data.get("catalog_db_name", "")).strip(),
            catalog_sub_title=str(data.get("catalog_sub_title", "")).strip(),
            db_host=str(data.get("db_host", "")).strip(),
            db_port=str(data.get("db_port", "3306")).strip() or "3306",
            upload_host=str(data.get("upload_host", "")).strip(),
            upload_port=str(data.get("upload_port", "22")).strip() or "22",
            upload_protocol=str(data.get("upload_protocol", "SFTP")).strip().upper() or "SFTP",
            remote_template=str(data.get("remote_template", "")).strip(),
            file_template=str(data.get("file_template") or cls.file_template),
        )


@dataclass
class APRRecord:
    pdf: Path
    filename_number: Optional[ParsedNumber] = None
    pdf_number: Optional[ParsedNumber] = None
    apr_date: Optional[datetime] = None
    cnpj: str = ""
    manual_number: Optional[ParsedNumber] = None
    manual_apr_date: Optional[datetime] = None
    manual_cnpj: str = ""
    manual_corrections: list[ManualCorrection] = field(default_factory=list)
    unit_name: str = ""
    amount: str = ""
    operation_type: str = ""
    name: str = ""
    slug: str = ""
    date_sql: str = ""
    year4: Optional[int] = None
    file_db: str = ""
    source_name: str = ""
    sha256: str = ""
    size_bytes: int = 0
    mtime_ns: int = 0
    page_count: int = 0
    extracted_text: str = ""
    is_probably_scanned: bool = False
    text_source: str = "PDF"
    ocr_used: bool = False
    ocr_provider: str = ""
    ocr_confidence: float = 0.0
    ocr_error: str = ""
    ocr_truncated: bool = False
    signature_score: int = 0
    history_status: str = ""
    history_message: str = ""
    history_blocking: bool = False
    history_override_allowed: bool = False
    export_status: str = ""
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    infos: list[str] = field(default_factory=list)

    @property
    def effective_number(self) -> Optional[ParsedNumber]:
        return self.manual_number or self.filename_number or self.pdf_number

    @property
    def effective_apr_date(self) -> Optional[datetime]:
        return self.manual_apr_date or self.apr_date

    @property
    def effective_cnpj(self) -> str:
        return self.manual_cnpj or self.cnpj

    @property
    def manually_reviewed(self) -> bool:
        return bool(self.manual_corrections)

    @property
    def manual_review_summary(self) -> str:
        if not self.manual_corrections:
            return ""
        fields = []
        labels = {"number": "Nº/ANO", "date": "Data", "cnpj": "CNPJ"}
        for item in self.manual_corrections:
            label = labels.get(item.field, item.field)
            if label not in fields:
                fields.append(label)
        return ", ".join(fields)

    @property
    def status(self) -> str:
        if self.errors or self.history_blocking:
            return "ERRO"
        if self.warnings:
            return "AVISO"
        return "OK"

    @property
    def canonical_number(self) -> str:
        n = self.effective_number
        return n.canonical if n else ""

    @property
    def messages(self) -> str:
        extra = [self.history_message] if self.history_blocking and self.history_message else []
        return " | ".join([*self.errors, *extra, *self.warnings, *self.infos])
