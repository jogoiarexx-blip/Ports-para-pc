from __future__ import annotations

import re
from datetime import datetime

from .models import APRRecord, CompanyProfile, ManualCorrection, ParsedNumber
from .parser import make_number
from .utils import cnpj_is_valid, normalize_cnpj, only_digits
from .validator import build_file_path, validate_db_path

_NUMBER_RE = re.compile(r"^\s*(\d{1,6})\s*[/._-]\s*(\d{2}|\d{4})\s*$")

_NUMBER_ERROR_PREFIXES = (
    "não foi possível localizar Nº/ANO",
    "PDF contém Nº/ANO conflitantes",
    "Nº/ANO divergente",
    "nome do arquivo contém mais de um Nº/ANO",
    "Nº/ANO foi obtido somente por OCR",
    "slug ficou vazio",
)
_DATE_ERROR_PREFIXES = (
    "não foi possível localizar uma DATA válida",
    "PDF contém datas de APR conflitantes",
)
_CNPJ_ERROR_PREFIXES = (
    "CNPJ divergente",
)
_RECOMPUTED_ERROR_PREFIXES = (
    "ano divergente",
    "erro ao montar campo file",
    "campo file ",
)
_CNPJ_WARNING_PREFIXES = (
    "CNPJ da unidade gestora não foi localizado",
    "CNPJ encontrado no PDF não passou",
)
_REVIEW_WARNING_PREFIX = "revisão manual aplicada:"


def parse_manual_number(value: str) -> ParsedNumber:
    m = _NUMBER_RE.fullmatch(value or "")
    if not m:
        raise ValueError("Nº/ANO deve estar no formato 52/26 ou 52/2026")
    number = make_number(m.group(1), m.group(2))
    if not (1900 <= number.year4 <= 2199):
        raise ValueError("ano do Nº/ANO está fora do intervalo aceito")
    return number


def parse_manual_date(value: str) -> datetime:
    raw = (value or "").strip()
    for fmt in ("%d/%m/%Y", "%Y-%m-%d"):
        try:
            return datetime.strptime(raw, fmt)
        except ValueError:
            pass
    raise ValueError("data deve estar no formato DD/MM/AAAA ou AAAA-MM-DD")


def parse_manual_cnpj(value: str) -> str:
    raw = (value or "").strip()
    if not raw:
        raise ValueError("CNPJ não pode ficar vazio na correção manual")
    normalized = normalize_cnpj(raw)
    if len(only_digits(normalized)) != 14:
        raise ValueError("CNPJ deve conter 14 dígitos")
    if not cnpj_is_valid(normalized):
        raise ValueError("CNPJ informado não passou na validação matemática")
    return normalized


def _remove_prefixed(values: list[str], prefixes: tuple[str, ...]) -> None:
    values[:] = [v for v in values if not any(v.startswith(prefix) for prefix in prefixes)]


def _display_source_number(row: APRRecord) -> str:
    if row.filename_number and row.pdf_number and row.filename_number.canonical != row.pdf_number.canonical:
        return f"arquivo={row.filename_number.display}; pdf={row.pdf_number.display}"
    value = row.filename_number or row.pdf_number
    return value.display if value else ""


def source_snapshot(row: APRRecord) -> dict[str, str]:
    return {
        "number": _display_source_number(row),
        "date": row.apr_date.strftime("%d/%m/%Y") if row.apr_date else "",
        "cnpj": row.cnpj,
    }


def effective_snapshot(row: APRRecord) -> dict[str, str]:
    number = row.effective_number
    date = row.effective_apr_date
    return {
        "number": number.display if number else "",
        "date": date.strftime("%d/%m/%Y") if date else "",
        "cnpj": row.effective_cnpj,
    }


def _add_correction(
    row: APRRecord,
    field: str,
    original: str,
    corrected: str,
    reason: str,
    reviewer: str,
    applied_at: str,
) -> None:
    row.manual_corrections.append(
        ManualCorrection(
            field=field,
            original=original,
            corrected=corrected,
            action="confirmed" if original == corrected else "corrected",
            reason=reason,
            applied_at=applied_at,
            reviewer=reviewer or "Usuário local",
        )
    )


def recompute_effective_fields(row: APRRecord, profile: CompanyProfile) -> None:
    """Recalcula os campos usados no SQL sem modificar o PDF nem apagar a trilha de auditoria."""
    _remove_prefixed(row.errors, _RECOMPUTED_ERROR_PREFIXES)

    number = row.effective_number
    date = row.effective_apr_date

    if number:
        row.name = number.display
        row.slug = re.sub(r"\D", "", row.name)
        row.source_name = "manual" if row.manual_number else ("arquivo" if row.filename_number else "pdf")
        if not row.slug:
            row.errors.append("slug ficou vazio")
    else:
        row.name = ""
        row.slug = ""
        row.source_name = ""

    if date:
        row.date_sql = date.strftime("%Y-%m-%d 00:00:00")
    else:
        row.date_sql = ""

    if number and date and number.year4 != date.year:
        row.errors.append(
            f"ano divergente: Nº/ANO indica {number.year4}, mas DATA indica {date.year}"
        )

    if date:
        row.year4 = date.year
    elif number:
        row.year4 = number.year4
    else:
        row.year4 = None

    row.file_db = ""
    if row.year4 is not None:
        try:
            row.file_db = build_file_path(profile.file_template, profile, row.year4, row.pdf.name)
            row.errors.extend(validate_db_path(row.file_db, row.pdf.name))
        except Exception as exc:
            row.errors.append(f"erro ao montar campo file: {exc}")

    # Revalida CNPJ efetivo em relação ao perfil.
    _remove_prefixed(row.errors, _CNPJ_ERROR_PREFIXES)
    if profile.cnpj and row.effective_cnpj and only_digits(profile.cnpj) != only_digits(row.effective_cnpj):
        row.errors.append(
            f"CNPJ divergente: perfil='{normalize_cnpj(profile.cnpj)}' x revisão='{normalize_cnpj(row.effective_cnpj)}'"
        )

    # Uma revisão manual permanece visível como AVISO/auditoria, sem bloquear por si só.
    _remove_prefixed(row.warnings, (_REVIEW_WARNING_PREFIX,))
    if row.manually_reviewed:
        row.warnings.append(f"{_REVIEW_WARNING_PREFIX} {row.manual_review_summary}; confira o relatório de auditoria")


def apply_manual_review(
    row: APRRecord,
    profile: CompanyProfile,
    *,
    number_text: str | None = None,
    date_text: str | None = None,
    cnpj_text: str | None = None,
    reason: str,
    reviewer: str = "Usuário local",
    applied_at: str | None = None,
) -> APRRecord:
    """Aplica correções explícitas aos campos críticos e registra antes/depois.

    Campos com valor None não são alterados. O PDF original e seu SHA-256 nunca são modificados.
    """
    reason = (reason or "").strip()
    if len(reason) < 3:
        raise ValueError("informe um motivo/observação para registrar a revisão manual")
    applied_at = applied_at or datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    before = effective_snapshot(row)

    if number_text is not None:
        number = parse_manual_number(number_text)
        row.manual_number = number
        _remove_prefixed(row.errors, _NUMBER_ERROR_PREFIXES)
        # Divergência arquivo x PDF é deliberadamente superada por uma conferência manual explícita.
        _add_correction(row, "number", before["number"], number.display, reason, reviewer, applied_at)

    if date_text is not None:
        date = parse_manual_date(date_text)
        row.manual_apr_date = date
        _remove_prefixed(row.errors, _DATE_ERROR_PREFIXES)
        _add_correction(row, "date", before["date"], date.strftime("%d/%m/%Y"), reason, reviewer, applied_at)

    if cnpj_text is not None:
        cnpj = parse_manual_cnpj(cnpj_text)
        row.manual_cnpj = cnpj
        _remove_prefixed(row.errors, _CNPJ_ERROR_PREFIXES)
        _remove_prefixed(row.warnings, _CNPJ_WARNING_PREFIXES)
        _add_correction(row, "cnpj", before["cnpj"], cnpj, reason, reviewer, applied_at)

    # Em OCR de baixa confiança, os campos que realmente alimentam o INSERT
    # (Nº/ANO e data) precisam ser explicitamente conferidos. O CNPJ é opcional
    # e continua servindo apenas como validação adicional quando estiver cadastrado.
    if row.manual_number and row.manual_apr_date:
        low_ocr = [e for e in row.errors if e.startswith("OCR com confiança baixa")]
        if low_ocr:
            _remove_prefixed(row.errors, ("OCR com confiança baixa",))
            row.warnings.append("OCR de baixa confiança superado por conferência manual de Nº/ANO e data")

    recompute_effective_fields(row, profile)
    return row


def clear_manual_review(row: APRRecord, profile: CompanyProfile) -> APRRecord:
    """Remove overrides atuais. A trilha anterior é removida da sessão, não do PDF/histórico exportado."""
    row.manual_number = None
    row.manual_apr_date = None
    row.manual_cnpj = ""
    row.manual_corrections.clear()
    _remove_prefixed(row.warnings, (_REVIEW_WARNING_PREFIX,))
    # A restauração de mensagens originais completas exige nova validação do documento.
    # O chamador deve revalidar o PDF para reconstruir exatamente os erros de origem.
    recompute_effective_fields(row, profile)
    return row
