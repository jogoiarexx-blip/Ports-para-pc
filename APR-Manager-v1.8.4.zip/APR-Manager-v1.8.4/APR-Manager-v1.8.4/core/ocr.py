from __future__ import annotations

import importlib.util
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable


@dataclass
class OCRPageResult:
    page_number: int
    text: str
    confidence: float


@dataclass
class OCRResult:
    text: str
    confidence: float
    provider: str
    pages: list[OCRPageResult] = field(default_factory=list)
    truncated: bool = False


class OCRUnavailable(RuntimeError):
    """OCR opcional não está disponível nesta instalação."""


class OCRCancelled(RuntimeError):
    """OCR cancelado pelo usuário."""


_ENGINE = None


def ocr_available() -> tuple[bool, str]:
    """Verificação leve: não importa ONNX/RapidOCR na thread da interface."""
    missing = []
    if importlib.util.find_spec("rapidocr") is None:
        missing.append("rapidocr")
    if importlib.util.find_spec("pymupdf") is None and importlib.util.find_spec("fitz") is None and importlib.util.find_spec("pypdfium2") is None:
        missing.append("PyMuPDF/pypdfium2")
    if missing:
        return False, "faltando: " + ", ".join(missing)
    renderer = "MuPDF/Fitz" if (importlib.util.find_spec("pymupdf") or importlib.util.find_spec("fitz")) else "PDFium"
    return True, f"RapidOCR 3.x + {renderer}"


def _get_engine():
    global _ENGINE
    if _ENGINE is None:
        try:
            from rapidocr import RapidOCR
        except Exception as exc:  # pragma: no cover - depende do ambiente
            raise OCRUnavailable(
                "RapidOCR não está instalado. Instale as dependências de OCR do APR Manager."
            ) from exc
        # A engine é pesada; é criada uma única vez e reutilizada em todo o lote.
        _ENGINE = RapidOCR()
    return _ENGINE


def _as_list(value) -> list:
    """Converte listas/tuplas/ndarrays sem avaliar ndarray como booleano."""
    if value is None:
        return []
    try:
        return list(value)
    except Exception:
        return []


def _parse_rapidocr_result(result) -> tuple[str, float]:
    """Aceita saídas do RapidOCR 3.x e formatos antigos usados nos testes."""
    if result is None:
        return "", 0.0

    txts = getattr(result, "txts", None)
    scores = getattr(result, "scores", None)
    if txts is not None:
        texts = [str(x).strip() for x in _as_list(txts)]
        score_values = _as_list(scores)
        lines: list[str] = []
        weighted = 0.0
        weight_total = 0
        for idx, text in enumerate(texts):
            if not text:
                continue
            try:
                score = float(score_values[idx]) if idx < len(score_values) else 0.0
            except Exception:
                score = 0.0
            lines.append(text)
            weight = max(1, len(text))
            weighted += max(0.0, min(1.0, score)) * weight
            weight_total += weight
        return "\n".join(lines), (weighted / weight_total if weight_total else 0.0)

    if isinstance(result, tuple) and len(result) == 2 and not isinstance(result[0], (str, bytes)):
        first = result[0]
        if first is not result:
            parsed = _parse_rapidocr_result(first)
            if parsed[0] or parsed[1]:
                return parsed

    if not isinstance(result, (list, tuple)):
        return "", 0.0

    lines: list[str] = []
    weighted = 0.0
    weight_total = 0
    for item in result:
        try:
            text = str(item[1]).strip()
            score = float(item[2])
        except Exception:
            continue
        if not text:
            continue
        lines.append(text)
        weight = max(1, len(text))
        weighted += max(0.0, min(1.0, score)) * weight
        weight_total += weight
    return "\n".join(lines), (weighted / weight_total if weight_total else 0.0)


def _load_mupdf():
    try:
        import pymupdf as fitz
        return fitz
    except Exception:
        try:
            import fitz  # type: ignore
            return fitz
        except Exception:
            return None


def _render_mupdf_page(doc, index: int, scale: float):
    """Renderiza direto em ndarray, sem PIL e sem arquivo temporário."""
    import numpy as np

    page = doc.load_page(index)
    try:
        matrix = doc._fitz.Matrix(scale, scale) if hasattr(doc, "_fitz") else None
    except Exception:
        matrix = None
    if matrix is None:
        # O módulo fitz expõe Matrix; o objeto Document não.
        fitz = _load_mupdf()
        matrix = fitz.Matrix(scale, scale)
    pix = page.get_pixmap(matrix=matrix, alpha=False)
    arr = np.frombuffer(pix.samples, dtype=np.uint8)
    arr = arr.reshape(pix.height, pix.width, pix.n)
    if pix.n > 3:
        arr = arr[:, :, :3]
    # Cópia pequena e contínua evita manter o buffer do Pixmap vivo no OCR.
    return arr.copy()


def _render_pdfium_page(pdf, index: int, scale: float):
    page = pdf[index]
    try:
        bitmap = page.render(scale=scale)
        try:
            return bitmap.to_numpy()
        except Exception:
            return bitmap.to_pil()
    finally:
        try:
            page.close()
        except Exception:
            pass


def _critical_fields_present(text: str, filename: str) -> bool:
    """Critério para evitar segunda passada cara de OCR quando a primeira já basta."""
    up = re.sub(r"\s+", " ", text.upper())
    has_date = re.search(r"\b\d{1,2}\s*[/.\-]\s*\d{1,2}\s*[/.\-]\s*\d{4}\b", up) is not None
    has_cnpj = re.search(r"\b\d{2}[. ]?\d{3}[. ]?\d{3}[/ ]?\d{4}[- ]?\d{2}\b", up) is not None
    has_apr = re.search(r"\bAPR\b", up) is not None or "AUTORIZA" in up
    has_number_label = re.search(r"\bN\s*[º°O0.]?\s*(?:/|\-)?\s*ANO\b", up) is not None
    filename_has_number = re.search(r"(?<!\d)\d{1,6}\s*[.\-_/]\s*(?:\d{2}|\d{4})(?!\d)", filename) is not None
    return has_date and (has_cnpj or has_apr) and (has_number_label or filename_has_number)


def _result_score(text: str, confidence: float) -> tuple[int, float, int]:
    critical = int(_critical_fields_present(text, ""))
    return critical, confidence, sum(ch.isalnum() for ch in text)


def _ocr_image(engine, image) -> tuple[str, float]:
    raw = engine(image)
    return _parse_rapidocr_result(raw)


def extract_text_with_ocr(
    pdf_path: Path,
    *,
    scale: float = 1.65,
    max_pages: int | None = None,
    cancel_check: Callable[[], bool] | None = None,
) -> OCRResult:
    """OCR adaptativo local, priorizando velocidade sem abrir mão de uma segunda passada.

    Estratégia 1.8.3:
    - Renderiza com MuPDF/Fitz quando disponível (mais rápido para este fluxo).
    - Primeira passada em ~119 dpi (scale 1.65).
    - Só repete a página em resolução maior quando os campos críticos ficaram
      incompletos ou a confiança ficou baixa.
    - Em documentos multipágina, pode encerrar após uma página que já contenha os
      campos críticos da APR. O PDF continua sendo validado pelo parser/validator.
    """
    engine = _get_engine()
    pages: list[OCRPageResult] = []
    truncated = False
    provider_renderer = ""

    fitz = _load_mupdf()
    mupdf_doc = None
    pdfium_doc = None

    try:
        if fitz is not None:
            mupdf_doc = fitz.open(str(pdf_path))
            total = len(mupdf_doc)
            provider_renderer = "MuPDF/Fitz"
            render = lambda idx, sc: _render_mupdf_page(mupdf_doc, idx, sc)
        else:
            try:
                import pypdfium2 as pdfium
            except Exception as exc:  # pragma: no cover
                raise OCRUnavailable(
                    "Nem PyMuPDF/Fitz nem pypdfium2 estão disponíveis para renderizar o PDF."
                ) from exc
            pdfium_doc = pdfium.PdfDocument(str(pdf_path))
            total = len(pdfium_doc)
            provider_renderer = "PDFium"
            render = lambda idx, sc: _render_pdfium_page(pdfium_doc, idx, sc)

        count = total if max_pages is None else min(total, max_pages)
        truncated = max_pages is not None and total > count

        for index in range(count):
            if cancel_check and cancel_check():
                raise OCRCancelled("OCR cancelado")

            # Passada rápida.
            image = render(index, scale)
            text, confidence = _ocr_image(engine, image)
            del image

            if cancel_check and cancel_check():
                raise OCRCancelled("OCR cancelado")

            # Segunda passada apenas se realmente necessária. Escala 2.15 ainda é
            # bem menor que a antiga 2.4, mas recupera caracteres pequenos.
            if confidence < 0.82 or not _critical_fields_present(text, pdf_path.name):
                image_hi = render(index, 2.15)
                text_hi, confidence_hi = _ocr_image(engine, image_hi)
                del image_hi
                if _result_score(text_hi, confidence_hi) > _result_score(text, confidence):
                    text, confidence = text_hi, confidence_hi

            pages.append(OCRPageResult(index + 1, text, confidence))

            # APR normalmente concentra número/data/CNPJ no cabeçalho da primeira
            # página. Em multipágina, não há motivo para OCR de anexos se já obtivemos
            # os campos necessários com boa confiança.
            combined_now = "\n\n".join(p.text for p in pages if p.text.strip())
            if total > 1 and confidence >= 0.84 and _critical_fields_present(combined_now, pdf_path.name):
                break

    except (OCRUnavailable, OCRCancelled):
        raise
    except Exception as exc:
        raise RuntimeError(f"falha no OCR local: {exc}") from exc
    finally:
        if mupdf_doc is not None:
            try:
                mupdf_doc.close()
            except Exception:
                pass
        if pdfium_doc is not None:
            try:
                pdfium_doc.close()
            except Exception:
                pass

    useful_pages = [p for p in pages if p.text.strip()]
    combined = "\n\n".join(p.text for p in useful_pages)
    weights = [max(1, len(p.text)) for p in useful_pages]
    confidence = (
        sum(p.confidence * w for p, w in zip(useful_pages, weights)) / sum(weights)
        if weights else 0.0
    )

    provider = f"RapidOCR 3.x + {provider_renderer} (adaptativo)"
    return OCRResult(
        text=combined,
        confidence=confidence,
        provider=provider,
        pages=pages,
        truncated=truncated,
    )
