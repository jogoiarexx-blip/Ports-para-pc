from __future__ import annotations

import importlib.util
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from pypdf import PdfReader

from .ocr import OCRCancelled, OCRUnavailable, extract_text_with_ocr


@dataclass
class PDFContent:
    text: str
    page_count: int
    probably_scanned: bool
    text_source: str = "PDF"
    ocr_used: bool = False
    ocr_provider: str = ""
    ocr_confidence: float = 0.0
    ocr_error: str = ""
    ocr_truncated: bool = False


class ExtractionCancelled(RuntimeError):
    pass


def _alnum_count(text: str) -> int:
    return sum(ch.isalnum() for ch in text)


def _marker_score(text: str) -> int:
    """Pontua sinais de que a camada de texto contém os campos úteis da APR.

    A pontuação não é usada para decidir se o documento *é* uma APR; isso continua
    sendo responsabilidade do validator. Aqui ela serve somente para escolher o
    melhor extrator e evitar OCR desnecessário.
    """
    up = re.sub(r"\s+", " ", text.upper())
    checks = [
        re.search(r"\bAPR\b", up) is not None,
        "UNIDADE GESTORA" in up,
        re.search(r"\bCNPJ\b", up) is not None,
        re.search(r"\bDATA(?:\s+DA\s+(?:OPERA[ÇC][ÃA]O|MOVIMENTA[ÇC][ÃA]O|APR))?\s*[:\-]?\s*\d{1,2}[/.\-]\d{1,2}[/.\-]\d{2,4}", up) is not None,
        re.search(r"\bN\s*[º°O0.]?\s*(?:/|\-)?\s*ANO\b", up) is not None,
        "TIPO DE OPERAÇÃO" in up or "TIPO DE OPERACAO" in up,
        "AUTORIZAÇÃO DE APLICAÇÃO" in up or "AUTORIZACAO DE APLICACAO" in up,
    ]
    return sum(1 for x in checks if x)


def _looks_garbled(text: str) -> bool:
    if not text.strip():
        return True
    chars = max(1, len(text))
    replacement = text.count("\ufffd")
    control = sum((ord(ch) < 32 and ch not in "\n\r\t") for ch in text)
    if replacement / chars > 0.01 or control / chars > 0.005:
        return True

    tokens = re.findall(r"\S+", text)
    if len(tokens) >= 20:
        one_char = sum(len(t) == 1 for t in tokens)
        if one_char / len(tokens) > 0.55:
            return True
    return False


def _needs_ocr(text: str) -> bool:
    """OCR somente quando a camada textual é realmente insuficiente.

    A versão anterior também acionava OCR quando o layout não batia com alguns
    marcadores. Isso fazia PDFs perfeitamente pesquisáveis irem para OCR e deixava
    lotes grandes muito mais lentos. Agora texto suficiente é preservado mesmo que
    o layout da APR seja diferente.
    """
    alnum = _alnum_count(text)
    if alnum < 80:
        return True
    if _looks_garbled(text):
        return True
    if alnum >= 220:
        return False
    if _marker_score(text) >= 1:
        return False
    # Documento curto e sem nenhum marcador conhecido: um OCR pode recuperar uma
    # camada de texto defeituosa de scanner. Documentos maiores ficam com o texto
    # original para o validator decidir se são APRs ou não.
    return alnum < 160


def _text_quality(text: str) -> tuple[int, int, int]:
    """Chave de comparação entre extratores: estrutura > volume > menos ruído."""
    return (_marker_score(text), _alnum_count(text), -text.count("\ufffd"))


def _load_mupdf():
    """Importa PyMuPDF pelo nome moderno e mantém compatibilidade com `fitz`."""
    try:
        import pymupdf as fitz  # PyMuPDF >= 1.24
        return fitz
    except Exception:
        try:
            import fitz  # type: ignore
            return fitz
        except Exception:
            return None


def mupdf_available() -> bool:
    return importlib.util.find_spec("pymupdf") is not None or importlib.util.find_spec("fitz") is not None


def _extract_mupdf_text(pdf_path: Path, cancel_check: Callable[[], bool] | None = None) -> tuple[str, int]:
    fitz = _load_mupdf()
    if fitz is None:
        return "", 0

    doc = None
    parts: list[str] = []
    try:
        doc = fitz.open(str(pdf_path))
        if getattr(doc, "needs_pass", False):
            try:
                if not doc.authenticate(""):
                    return "", len(doc)
            except Exception:
                return "", len(doc)
        for page_index in range(len(doc)):
            if cancel_check and cancel_check():
                raise ExtractionCancelled("extração cancelada")
            page = doc.load_page(page_index)
            try:
                # sort=True tende a reconstruir melhor a ordem visual dos formulários.
                parts.append(page.get_text("text", sort=True) or "")
            except TypeError:
                parts.append(page.get_text("text") or "")
            finally:
                try:
                    page = None
                except Exception:
                    pass
        return "\n".join(parts), len(doc)
    finally:
        if doc is not None:
            try:
                doc.close()
            except Exception:
                pass


def _extract_pypdf_text(pdf_path: Path, cancel_check: Callable[[], bool] | None = None) -> tuple[str, int, int, str]:
    page_count = 0
    parts: list[str] = []
    failed_pages = 0
    last_error = ""
    try:
        reader = PdfReader(str(pdf_path), strict=False)
        if reader.is_encrypted:
            try:
                result = reader.decrypt("")
                if result == 0:
                    raise ValueError("PDF protegido por senha")
            except Exception as exc:
                raise ValueError("PDF protegido por senha; não foi possível ler o conteúdo") from exc
        page_count = len(reader.pages)
        for page_no, page in enumerate(reader.pages, start=1):
            if cancel_check and cancel_check():
                raise ExtractionCancelled("extração cancelada")
            try:
                parts.append(page.extract_text() or "")
            except Exception as exc:
                failed_pages += 1
                parts.append("")
                last_error = f"pypdf falhou na página {page_no}: {exc}"
    except ExtractionCancelled:
        raise
    except Exception as exc:
        last_error = str(exc)
    return "\n".join(parts), page_count, failed_pages, last_error


def _extract_pdfium_text(pdf_path: Path, cancel_check: Callable[[], bool] | None = None) -> tuple[str, int]:
    try:
        import pypdfium2 as pdfium
    except Exception:
        return "", 0
    pdf = None
    parts: list[str] = []
    try:
        pdf = pdfium.PdfDocument(str(pdf_path))
        for idx in range(len(pdf)):
            if cancel_check and cancel_check():
                raise ExtractionCancelled("extração cancelada")
            page = pdf[idx]
            textpage = None
            try:
                textpage = page.get_textpage()
                parts.append(textpage.get_text_range() or "")
            except Exception:
                parts.append("")
            finally:
                try:
                    if textpage is not None:
                        textpage.close()
                except Exception:
                    pass
                try:
                    page.close()
                except Exception:
                    pass
        return "\n".join(parts), len(pdf)
    finally:
        if pdf is not None:
            try:
                pdf.close()
            except Exception:
                pass


def extract_pdf_content(
    pdf_path: Path,
    *,
    enable_ocr: bool = True,
    cancel_check: Callable[[], bool] | None = None,
) -> PDFContent:
    if cancel_check and cancel_check():
        raise ExtractionCancelled("extração cancelada")

    # 1) MuPDF/Fitz é muito rápido e costuma reconstruir melhor formulários/tabelas.
    candidates: list[tuple[str, str, int]] = []
    mupdf_error = ""
    try:
        mupdf_text, mupdf_pages = _extract_mupdf_text(pdf_path, cancel_check)
        if mupdf_text.strip():
            candidates.append(("MuPDF/Fitz", mupdf_text, mupdf_pages))
    except ExtractionCancelled:
        raise
    except Exception as exc:
        mupdf_error = str(exc)

    # 2) pypdf é mantido como extrator independente/fallback.
    pypdf_text, pypdf_pages, pypdf_failed_pages, pypdf_error = _extract_pypdf_text(pdf_path, cancel_check)
    if pypdf_text.strip():
        candidates.append(("pypdf", pypdf_text, pypdf_pages))

    # 3) PDFium só é consultado quando os extratores anteriores ficaram fracos.
    current_best = max(candidates, key=lambda item: _text_quality(item[1]), default=("", "", 0))
    if not current_best[1].strip() or _needs_ocr(current_best[1]) or pypdf_failed_pages:
        try:
            pdfium_text, pdfium_pages = _extract_pdfium_text(pdf_path, cancel_check)
            if pdfium_text.strip():
                candidates.append(("PDFium", pdfium_text, pdfium_pages))
        except ExtractionCancelled:
            raise

    if candidates:
        source, text, page_count = max(candidates, key=lambda item: _text_quality(item[1]))
    else:
        source, text, page_count = "PDF", "", pypdf_pages

    scanned = _needs_ocr(text)
    content = PDFContent(text=text, page_count=page_count, probably_scanned=scanned, text_source=source)

    if scanned and enable_ocr:
        try:
            ocr = extract_text_with_ocr(pdf_path, cancel_check=cancel_check)
            content.ocr_used = True
            content.ocr_provider = ocr.provider
            content.ocr_confidence = ocr.confidence
            content.ocr_truncated = ocr.truncated
            # OCR não precisa reproduzir perfeitamente todo o corpo da APR: se trouxe
            # material útil em quantidade suficiente, o parser/validator faz a decisão.
            if _alnum_count(ocr.text) >= 55:
                # Preserve uma camada textual útil junto do OCR. Isso ajuda quando o
                # OCR reconhece melhor cabeçalho, mas o PDF tinha campos adicionais.
                if text.strip() and _text_quality(text) > (0, 0, 0):
                    content.text = ocr.text + "\n\n--- TEXTO DA CAMADA PDF ---\n" + text
                else:
                    content.text = ocr.text
                content.probably_scanned = False
                content.text_source = "OCR"
            else:
                content.ocr_error = "OCR executado, mas não encontrou texto suficiente"
        except OCRCancelled as exc:
            raise ExtractionCancelled(str(exc)) from exc
        except OCRUnavailable as exc:
            content.ocr_error = str(exc)
        except Exception as exc:
            content.ocr_error = str(exc)

    if not content.text.strip() and not content.ocr_error:
        errors = [x for x in (mupdf_error, pypdf_error) if x]
        if errors:
            content.ocr_error = " | ".join(errors)
    return content
