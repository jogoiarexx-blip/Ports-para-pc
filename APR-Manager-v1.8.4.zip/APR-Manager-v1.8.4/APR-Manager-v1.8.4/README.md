# APR Manager 1.8.4

## O que mudou na v1.8.4

- Avisos agora representam somente situações que realmente exigem atenção.
- OCR com confiança de **95% ou mais** não gera `AVISO`; a origem continua visível em `Fonte` e `Confiança OCR`.
- Quando o nome é `APR 33.pdf` e o Nº/ANO é encontrado com alta confiança dentro do documento, isso é comportamento normal e não gera aviso.
- Informações de rastreabilidade foram separadas em `Informações` no relatório/manifest, sem alterar o status para AVISO.
- OCR entre 85% e 94% continua gerando aviso para conferência; abaixo de 65% continua bloqueando.


Aplicativo Windows para validar lotes de APR, conferir a empresa/RPPS e gerar com segurança os arquivos usados na publicação na tabela `transparencies`.



## O que mudou na v1.8.3

A v1.8.3 corrige o fluxo mostrado em lotes como `APR 33.pdf`, `APR 34.pdf` etc., em que o **ano não existe no nome do arquivo** e o Nº/ANO precisa vir do documento.

- adicionado **PyMuPDF/Fitz** (`PyMuPDF 1.26.7`) como extrator preferencial de texto;
- cadeia de leitura passa a ser **MuPDF/Fitz → pypdf → PDFium → OCR**, usando OCR somente quando a camada textual realmente é insuficiente;
- removido o falso bloqueio que marcava como ERRO um Nº/ANO obtido por OCR de alta confiança apenas porque o nome era `APR 33.pdf` sem `/26`;
- OCR alto e coerente agora pode fornecer o Nº/ANO quando o arquivo não contém ano, conforme a regra original do projeto;
- validação do cabeçalho ficou tolerante a OCR: quando Nº/ANO, data e CNPJ/valor/operação são coerentes, pequenas falhas de reconhecimento do título viram **AVISO**, não ERRO;
- OCR adaptativo: primeira passada em resolução menor e segunda passada de alta resolução somente quando necessário;
- renderização do OCR usa MuPDF/Fitz quando disponível e PDFium como fallback;
- documentos multipágina podem encerrar o OCR cedo quando os campos críticos já foram reconhecidos com boa confiança;
- RapidOCR agora aceita corretamente `numpy.ndarray` em `txts/scores`, evitando exceção por avaliação booleana ambígua;
- CNPJ ficou mais tolerante a OCR que perde pontos/barras, mantendo a validação matemática posterior;
- padrões de `Nº/ANO` aceitam pequenas variações comuns de OCR (`N°`, `N0`, `NO`, espaços e separadores);
- a coluna **Fonte** passa a mostrar `MuPDF/Fitz`, `pypdf`, `PDFium` ou `OCR xx%`;
- tratamento de falhas da interface após a validação foi reforçado: uma exceção de apresentação não derruba silenciosamente o resultado e é registrada no log;
- dependências/build foram atualizados para incluir MuPDF/Fitz;
- suíte ampliada para **47 testes automatizados**.

### Sobre velocidade do OCR

O OCR não deve mais ser executado em todo PDF apenas porque o layout textual difere do padrão esperado. Se MuPDF/Fitz, pypdf ou PDFium recuperarem texto utilizável, o OCR é pulado. Em PDFs realmente escaneados, o OCR começa numa resolução menor e só repete a página em resolução maior quando os campos críticos não ficaram confiáveis.

## O que mudou na v1.8.2

A v1.8.2 é focada em **telas menores e notebooks abaixo de 1080p**.

- a tela principal agora possui **rolagem vertical e horizontal**; nenhum controle fica inacessível quando a altura disponível é pequena;
- tamanho inicial reduzido para `1080x680`, com mínimo de `760x500`;
- conteúdo principal passa a usar um painel rolável e responsivo;
- cards ficam em uma linha em larguras normais e mudam automaticamente para **3x2** quando a janela fica estreita;
- subtítulo, dicas dos cards e ajuda secundária são ocultados automaticamente no modo compacto para economizar altura;
- painel da empresa, IDs e configuração de `published_in` foram reorganizados em grade, evitando linhas horizontais muito largas;
- barras de **Arquivos** e **Processamento** passaram a distribuir botões em mais de uma linha, funcionando melhor com escala de tela elevada;
- área de arrastar PDFs ficou mais baixa;
- tabela, visualizador e painel de detalhes receberam alturas mínimas menores e continuam redimensionáveis pelos splitters;
- visualizador de PDF aceita uma área mínima menor;
- janelas de Perfis e Histórico também abrem em dimensões menores;
- corrigido o estado do campo de data manual de `published_in` depois que uma validação termina.

O objetivo é manter todas as funções da v1.8.1 sem exigir maximizar a janela ou usar monitor 1080p.

## O que mudou na v1.8.1

- **CNPJ deixou de ser obrigatório** para validar ou gerar o SQL.
- `company_id`, `user_id` e `transparency_type_detail_id` continuam sendo os identificadores obrigatórios do perfil.
- Quando o CNPJ estiver cadastrado no perfil, ele continua sendo comparado com o CNPJ encontrado na APR e uma divergência continua bloqueando o documento.
- Quando o perfil não tiver CNPJ, a ausência não bloqueia o lote; o campo funciona apenas como validação adicional.
- A revisão de OCR com baixa confiança passa a exigir confirmação manual de **Nº/ANO e Data**, sem obrigar CNPJ.
- A interface identifica o CNPJ como **opcional** no editor de perfis e na conferência da exportação.
- A CLI também deixa de exigir `--cnpj`.

## O que mudou na v1.8.0

A v1.8.0 é uma atualização focada em **design, fluidez e desempenho em lotes maiores**, sem alterar as regras de validação e segurança consolidadas nas versões anteriores.

### Interface

- barras de ação separadas por etapa (**Arquivos** e **Processamento**), reduzindo a poluição visual;
- botões principais com hierarquia visual e ícones do próprio Windows/Qt;
- cards de resumo com cores por categoria;
- tabela mais compacta e legível, com larguras iniciais otimizadas e status em destaque;
- contador de linhas exibidas durante filtros/pesquisa;
- painel de inspeção dividido em abas **Resumo** e **Texto extraído**;
- tema revisado, com melhor contraste, espaçamento, tabs, barras de rolagem e área do PDF;
- atalhos de teclado: `Ctrl+O`, `Ctrl+Shift+O`, `F5`, `Ctrl+Enter`, `Ctrl+E`, `Ctrl+F` e `Delete`.

### Desempenho

- remoção do `ResizeToContents` global da tabela, que ficava caro em lotes grandes;
- renderização da tabela com atualizações/sinais temporariamente suspensos;
- pesquisa com **debounce de 160 ms** e índice textual pré-calculado por linha;
- texto completo do PDF agora é carregado **sob demanda** apenas ao abrir a aba `Texto extraído`;
- visualizador de PDF ganhou **debounce de renderização** e **cache LRU de páginas renderizadas**;
- redimensionar a janela não dispara mais dezenas de renderizações consecutivas;
- cache da validação em memória passou a ter limite de 120 documentos para evitar crescimento sem controle;
- a barra de status informa quantas APRs foram reaproveitadas do cache durante a validação;
- leitura SHA-256 usa blocos maiores para reduzir chamadas de I/O em PDFs grandes.

As mudanças acima melhoram principalmente o uso com centenas de APRs e a navegação rápida entre documentos já validados.

## O que mudou na v1.7.0

A v1.7.0 adicionou **revisão manual assistida e auditável** para três campos da APR:

- Nº/ANO;
- Data da APR;
- CNPJ da unidade gestora.

Depois da validação, selecione uma APR e clique em **Revisar/corrigir selecionada**. A tela mostra lado a lado o valor detectado automaticamente e o valor efetivo que irá para o SQL.

A revisão manual:

- exige confirmação de que o valor foi conferido visualmente no PDF;
- exige motivo/observação;
- registra o usuário/revisor local;
- registra data/hora;
- distingue **confirmado** (valor mantido) de **corrigido** (valor alterado);
- não modifica o PDF original;
- não altera o SHA-256 do PDF;
- recalcula `name`, `slug`, `reference_date`, ano do caminho e `file` quando necessário;
- refaz as verificações de duplicidade e histórico depois da correção;
- invalida um pacote exportado anteriormente na mesma sessão, exigindo uma nova exportação.

Se um OCR estiver com confiança baixa, o bloqueio pode ser superado pela revisão explícita de **Nº/ANO e Data**. O CNPJ é opcional e serve como conferência adicional quando estiver cadastrado no perfil. Outros erros estruturais do documento continuam bloqueando o SQL.

## Auditoria da revisão manual

Cada exportação agora inclui também:

```text
AUDITORIA_REVISAO.json
```

O arquivo contém, para cada APR revisada:

- nome do PDF;
- SHA-256 do PDF original;
- valores detectados automaticamente;
- valores efetivos usados na exportação;
- campo revisado;
- ação (`confirmed` ou `corrected`);
- método (`manual_visual_pdf`);
- valor anterior;
- valor final;
- motivo;
- revisor;
- data/hora.

A mesma trilha também fica dentro do `manifest_apr.json` e resumida no CSV/HTML.

## Fluxo recomendado

1. Selecione a empresa.
2. Confira o `company_id` automático.
3. Informe ou ajuste `user_id` e `transparency_type_detail_id`.
4. Adicione os PDFs e clique em **Validar tudo**.
5. Confira CNPJ, Nº/ANO, data, unidade, OCR, histórico e mensagens.
6. Se necessário, selecione uma linha e clique em **Revisar/corrigir selecionada**.
7. Confira o PDF no visualizador e informe somente os campos que deseja confirmar/corrigir.
8. Escolha a regra de `published_in`.
9. Clique em **Gerar SQL + relatórios**.
10. Confira `RESUMO_EXPORTACAO.txt` e `AUDITORIA_REVISAO.json`.
11. Use **Verificar pacote** para conferir os hashes SHA-256.
12. Execute o SQL no banco.
13. Somente depois do sucesso, clique em **Confirmar SQL executado**.

## Arquivos gerados

Cada exportação cria uma pasta exclusiva, por exemplo:

```text
2026-09-30_120000_PITANPREV/
```

Ela pode conter:

- `inserts_transparencies.sql`
- `relatorio_apr.csv`
- `relatorio_apr.html`
- `manifest_apr.json`
- `AUDITORIA_REVISAO.json`
- `RESUMO_EXPORTACAO.txt`
- `CHECKSUMS.sha256`

O arquivo de auditoria é criado mesmo quando nenhuma APR foi revisada; nesse caso ele registra `reviewed_documents: 0`.

## Segurança do SQL

O SQL usa `START TRANSACTION` / `COMMIT` e `INSERT ... SELECT ... WHERE NOT EXISTS` considerando:

```text
company_id
+ transparency_type_detail_id
+ slug
+ deleted_at IS NULL
```

O cabeçalho do SQL registra quantas APRs tiveram revisão manual. A trilha detalhada permanece no manifest e no arquivo de auditoria.

## `reference_date` e `published_in`

- `reference_date`: usa a **data efetiva da APR**. Se houve correção manual auditada, usa a data corrigida.
- `published_in`: continua configurável como:
  - mesma data da APR;
  - data da exportação;
  - data manual.

## Proteções mantidas das versões anteriores

- perfis salvos atomicamente e recuperação de JSON corrompido;
- CNPJ opcional; quando cadastrado, divergências com a APR continuam bloqueando o documento;
- histórico `GERADO` e `CONFIRMADO`;
- exportação em subpasta única por lote;
- SQL idempotente;
- SQL apenas das válidas;
- rechecagem de tamanho, `mtime` e SHA-256 do PDF antes da exportação;
- OCR local adaptativo com RapidOCR 3.x;
- extração preferencial com **PyMuPDF/Fitz**, seguida de `pypdf` e fallback `pypdfium2`;
- cache de validação;
- logs rotativos em `%LOCALAPPDATA%\APRManager\logs`;
- `CHECKSUMS.sha256` e botão **Verificar pacote**.

## Executar no Windows

Dê duplo clique em:

```text
executar.bat
```

O instalador de dependências prefere Python 3.12 e interrompe corretamente se o `pip` falhar.

## Criar o EXE

```powershell
powershell -ExecutionPolicy Bypass -File .\build_windows.ps1
```

O executável é criado em:

```text
dist\APR Manager\APR Manager.exe
```

Se o Inno Setup estiver disponível, o instalador também é criado.

## Linha de comando

O modo CLI continua disponível para validação e geração automatizada. A revisão manual assistida continua sendo uma função da interface gráfica.

```bat
python gerar_inserts_apr.py .\apr --profile-id 5
```

Usando a data da exportação em `published_in`:

```bat
python gerar_inserts_apr.py .\apr --profile-id 5 --published-in export
```

## Limites atuais

- A confirmação da execução do SQL ainda é manual; o aplicativo não consulta o banco.
- Não há upload FTP/SFTP automático nesta etapa.
- Não há assinatura digital de código incluída; isso depende de certificado do publicador.
- A revisão manual altera apenas os valores usados pelo APR Manager; o PDF original nunca é editado.
