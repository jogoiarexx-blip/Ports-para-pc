@echo off
setlocal
cd /d "%~dp0"

set "PYLAUNCHER=py"
set "PYARGS=-3.12"
%PYLAUNCHER% %PYARGS% -V >nul 2>&1
if errorlevel 1 (
  set "PYARGS="
  %PYLAUNCHER% -V >nul 2>&1
  if errorlevel 1 (
    echo Python nao foi encontrado. Instale Python 3.12 ou mais novo e tente novamente.
    pause
    exit /b 1
  )
)

if not exist ".venv\Scripts\python.exe" goto :criar
.venv\Scripts\python.exe -c "import PySide6,pypdf,pypdfium2,rapidocr,onnxruntime,importlib.util; assert importlib.util.find_spec('pymupdf')" >nul 2>&1
if errorlevel 1 goto :reparar
goto :rodar

:criar
echo Criando ambiente virtual...
%PYLAUNCHER% %PYARGS% -m venv .venv
if errorlevel 1 goto :erro
goto :instalar

:reparar
echo Ambiente incompleto detectado. Reparando dependencias...

:instalar
.venv\Scripts\python.exe -m pip install --upgrade pip
if errorlevel 1 goto :erro_instalacao
.venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 goto :erro_instalacao
.venv\Scripts\python.exe -c "import PySide6,pypdf,pypdfium2,rapidocr,onnxruntime,importlib.util; assert importlib.util.find_spec('pymupdf')"
if errorlevel 1 goto :erro_instalacao

:rodar
.venv\Scripts\python.exe app.py
exit /b %errorlevel%

:erro_instalacao
echo.
echo A instalacao falhou. O ambiente virtual incompleto sera removido para permitir nova tentativa.
rmdir /s /q .venv 2>nul
goto :erro

:erro
echo.
echo Nao foi possivel preparar o APR Manager.
pause
exit /b 1
