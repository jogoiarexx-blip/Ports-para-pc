@echo off
cd /d "%~dp0"
if exist "CrashNative.exe" goto :abrir
echo CrashNative.exe v0.20.0 ainda nao foi compilado neste PC.
echo.
echo Vou abrir o compilador automatico. Ele procura o Visual Studio Build Tools 2022.
echo Se a compilacao passar, o jogo sera aberto em seguida.
echo.
call "%~dp0COMPILAR-WINDOWS.cmd"
if not exist "CrashNative.exe" exit /b 1
:abrir
start "" "%~dp0CrashNative.exe"
