# v0.21.0 — GAX2 Advanced Audio + Original Frontend

## Áudio GAX2

- O replayer nativo passou a interpretar mais do comportamento real do GAX2 da ROM, em vez de apenas patterns + PCM.
- Adicionados envelopes com sustain/loop/interpolação.
- Adicionados vibrato e delay de vibrato.
- Adicionados pitch slide, note slide e tone portamento.
- Adicionados volume slide/set por pattern e por instrument sequence.
- Adicionada instrument sequence interna com comandos de loop/jump/speed.
- Adicionados loops de sample, ping-pong e sweep dinâmico.
- Adicionado note delay `E-Dx`.
- SFX passaram a usar um estado de vozes separado, respeitando prioridade básica e o esquema principal de alternância de vozes.
- O banco continua sendo lido diretamente da ROM: 52 instrumentos de música, 29 waves PCM úteis e 88 instrumentos do banco SFX.

### Limite atual

O áudio ficou bem mais próximo do jogo original, mas ainda não é bit-exact. O port ainda usa um resampler/mapeamento de frequência nativo aproximado em vez da tabela de período + mixer/DSP ARM do GAX2 original. Echo/DSP e alguns detalhes finos de voice stealing ainda precisam ser reproduzidos com exatidão.

## Frontend / Warp Room

- O menu passa a usar o céu/clouds original extraído da ROM.
- O Warp Room passa a usar o fundo metálico original e a plataforma original do level select.
- O title screen também usa um badge original como detalhe visual.
- Os assets originais têm fallback para o renderer anterior caso algum arquivo esteja ausente ou inválido.
- Portais, bloqueio/desbloqueio, conclusão, boss e navegação continuam usando o runtime nativo atual.

## Ferramentas e testes

- `CrashGaxTool` agora reporta envelopes, instrumentos com vibrato, rows com sweep/ping-pong e quantidade de sequence FX.
- `CrashFrontendTool SAIDA.bmp map` gera o Warp Room.
- `CrashFrontendTool SAIDA.bmp title` gera o menu/tela de título.
- `TestAudio` valida o replayer avançado e confirma reprodução SFX mesmo sem música de fundo.
- `TestFrontend` valida a presença/tamanho dos assets originais do frontend.
- 8/8 suítes PASS.
- Strict `-Werror` PASS.
- ASan + UBSan PASS em Audio, Frontend e Category.
