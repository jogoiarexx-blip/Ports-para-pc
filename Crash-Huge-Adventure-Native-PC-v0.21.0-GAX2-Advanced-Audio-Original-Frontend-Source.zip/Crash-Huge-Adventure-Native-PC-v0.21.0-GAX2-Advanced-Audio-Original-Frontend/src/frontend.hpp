#pragma once
#include "run_state.hpp"
#include <algorithm>
#include <array>
#include <cstdint>
#include <fstream>
#include <string>
#include <utility>
#include <vector>

namespace crash {

inline void uiPixel(std::vector<uint32_t>& p,int x,int y,uint32_t c){if(x>=0&&y>=0&&x<240&&y<160)p[size_t(y*240+x)]=c;}
inline void uiRect(std::vector<uint32_t>& p,int x,int y,int w,int h,uint32_t c){for(int yy=y;yy<y+h;yy++)for(int xx=x;xx<x+w;xx++)uiPixel(p,xx,yy,c);}
inline void uiLine(std::vector<uint32_t>& p,int x0,int y0,int x1,int y1,uint32_t c){int dx=std::abs(x1-x0),sx=x0<x1?1:-1,dy=-std::abs(y1-y0),sy=y0<y1?1:-1,err=dx+dy;for(;;){uiPixel(p,x0,y0,c);if(x0==x1&&y0==y1)break;int e2=2*err;if(e2>=dy){err+=dy;x0+=sx;}if(e2<=dx){err+=dx;y0+=sy;}}}
inline void uiCircle(std::vector<uint32_t>& p,int cx,int cy,int r,uint32_t c){int x=r,y=0,err=0;while(x>=y){const int q[8][2]={{x,y},{y,x},{-y,x},{-x,y},{-x,-y},{-y,-x},{y,-x},{x,-y}};for(auto& a:q)uiPixel(p,cx+a[0],cy+a[1],c);if(err<=0){++y;err+=2*y+1;}if(err>0){--x;err-=2*x+1;}}}
inline void uiDisc(std::vector<uint32_t>& p,int cx,int cy,int r,uint32_t c){for(int y=-r;y<=r;y++)for(int x=-r;x<=r;x++)if(x*x+y*y<=r*r)uiPixel(p,cx+x,cy+y,c);}
inline void uiDigit(std::vector<uint32_t>& p,int x,int y,unsigned d,uint32_t c){static constexpr const char* g[10]={"111101101101111","010110010010111","111001111100111","111001111001111","101101111001001","111100111001111","111100111101111","111001001001001","111101111101111","111101111001111"};for(int yy=0;yy<5;yy++)for(int xx=0;xx<3;xx++)if(g[d%10][yy*3+xx]=='1')uiPixel(p,x+xx,y+yy,c);}
inline void uiNumber(std::vector<uint32_t>& p,int x,int y,unsigned n,uint32_t c){if(n>=100){uiDigit(p,x,y,(n/100)%10,c);uiDigit(p,x+4,y,(n/10)%10,c);uiDigit(p,x+8,y,n%10,c);}else if(n>=10){uiDigit(p,x,y,(n/10)%10,c);uiDigit(p,x+4,y,n%10,c);}else uiDigit(p,x,y,n,c);}

inline const char* glyph5(char ch){
    switch(ch){
    case 'A':return "01110100011000111111100011000110001";case 'B':return "11110100011000111110100011000111110";
    case 'C':return "01111100001000010000100001000001111";case 'D':return "11110100011000110001100011000111110";
    case 'E':return "11111100001000011110100001000011111";case 'F':return "11111100001000011110100001000010000";
    case 'G':return "01111100001000010111100011000101111";case 'H':return "10001100011000111111100011000110001";
    case 'I':return "11111001000010000100001000010011111";case 'J':return "00111000100001000010100101001001100";
    case 'K':return "10001100101010011000101001001010001";case 'L':return "10000100001000010000100001000011111";
    case 'M':return "10001110111010110101100011000110001";case 'N':return "10001110011010110011100011000110001";
    case 'O':return "01110100011000110001100011000101110";case 'P':return "11110100011000111110100001000010000";
    case 'Q':return "01110100011000110001101011001001101";case 'R':return "11110100011000111110101001001010001";
    case 'S':return "01111100001000001110000010000111110";case 'T':return "11111001000010000100001000010000100";
    case 'U':return "10001100011000110001100011000101110";case 'V':return "10001100011000110001100010101000100";
    case 'W':return "10001100011000110101101011101110001";case 'X':return "10001100010101000100010101000110001";
    case 'Y':return "10001100010101000100001000010000100";case 'Z':return "11111000010001000100010001000011111";
    case '0':return "01110100011001110101110011000101110";case '1':return "00100011000010000100001000010001110";
    case '2':return "01110100010000100010001000100011111";case '3':return "11110000010000101110000010000111110";
    case '4':return "00010001100101010010111110001000010";case '5':return "11111100001000011110000010000111110";
    case '6':return "01110100001000011110100011000101110";case '7':return "11111000010001000100010000100001000";
    case '8':return "01110100011000101110100011000101110";case '9':return "01110100011000101111000010000101110";
    case '-':return "00000000000000011111000000000000000";case ':':return "00000001000000000000001000000000000";
    case '.':return "00000000000000000000000000010000100";case '/':return "00001000100001000100010001000000000";
    default:return "00000000000000000000000000000000000";
    }
}
inline void uiChar(std::vector<uint32_t>& p,int x,int y,char ch,uint32_t c,int s=1){if(ch==' ')return;const char* g=glyph5(ch);for(int yy=0;yy<7;yy++)for(int xx=0;xx<5;xx++)if(g[yy*5+xx]=='1')for(int sy=0;sy<s;sy++)for(int sx=0;sx<s;sx++)uiPixel(p,x+xx*s+sx,y+yy*s+sy,c);}
inline int uiTextWidth(const std::string& s,int scale=1){return s.empty()?0:int(s.size())*6*scale-scale;}
inline void uiText(std::vector<uint32_t>& p,int x,int y,std::string s,uint32_t c,int scale=1){for(char& ch:s)if(ch>='a'&&ch<='z')ch=char(ch-'a'+'A');for(char ch:s){uiChar(p,x,y,ch,c,scale);x+=6*scale;}}
inline void uiCentered(std::vector<uint32_t>& p,int y,const std::string& s,uint32_t c,int scale=1){uiText(p,(240-uiTextWidth(s,scale))/2,y,s,c,scale);}

inline std::vector<uint8_t> uiReadFile(const char* path){std::ifstream f(path,std::ios::binary);if(!f)return {};f.seekg(0,std::ios::end);auto n=f.tellg();if(n<=0)return {};f.seekg(0);std::vector<uint8_t> b;b.resize(static_cast<size_t>(n));f.read(reinterpret_cast<char*>(b.data()),static_cast<std::streamsize>(n));return f?b:std::vector<uint8_t>{};}
inline uint32_t uiRgb555(uint16_t v){unsigned r=(v&31u)*255u/31u,g=((v>>5)&31u)*255u/31u,b=((v>>10)&31u)*255u/31u;return 0xff000000u|(r<<16)|(g<<8)|b;}
inline std::vector<uint32_t> uiDecode8bpp(const char* palPath,const char* tilePath,const char* mapPath,int tw,int th){auto pal=uiReadFile(palPath),tiles=uiReadFile(tilePath),map=uiReadFile(mapPath);if(pal.size()<512||tiles.size()<64||map.size()<size_t(tw*th*2))return {};std::array<uint32_t,256> colors{};for(unsigned i=0;i<256;i++)colors[i]=uiRgb555(uint16_t(pal[i*2]|(uint16_t(pal[i*2+1])<<8)));std::vector<uint32_t> out(size_t(tw*8*th*8),0xff000000u);int w=tw*8;for(int y=0;y<th;y++)for(int x=0;x<tw;x++){size_t mo=size_t((y*tw+x)*2);uint16_t e=uint16_t(map[mo]|(uint16_t(map[mo+1])<<8));unsigned ti=e&0x3ffu;bool hf=(e&0x400u)!=0,vf=(e&0x800u)!=0;if(size_t(ti)*64+64>tiles.size())continue;for(int py=0;py<8;py++)for(int px=0;px<8;px++){int sx=hf?7-px:px,sy=vf?7-py:py;out[size_t((y*8+py)*w+x*8+px)]=colors[tiles[size_t(ti)*64+size_t(sy*8+sx)]];}}return out;}
inline std::vector<uint32_t> uiDecode4bpp(const char* palPath,const char* tilePath,const char* mapPath,int tw,int th){auto pal=uiReadFile(palPath),tiles=uiReadFile(tilePath),map=uiReadFile(mapPath);if(pal.size()<32||tiles.size()<32||map.size()<size_t(tw*th*2))return {};std::array<uint32_t,16> colors{};for(unsigned i=0;i<16;i++)colors[i]=uiRgb555(uint16_t(pal[i*2]|(uint16_t(pal[i*2+1])<<8)));std::vector<uint32_t> out(size_t(tw*8*th*8),0xff000000u);int w=tw*8;for(int y=0;y<th;y++)for(int x=0;x<tw;x++){size_t mo=size_t((y*tw+x)*2);uint16_t e=uint16_t(map[mo]|(uint16_t(map[mo+1])<<8));unsigned ti=e&0x3ffu;bool hf=(e&0x400u)!=0,vf=(e&0x800u)!=0;if(size_t(ti)*32+32>tiles.size())continue;for(int py=0;py<8;py++)for(int px=0;px<8;px++){int sx=hf?7-px:px,sy=vf?7-py:py;uint8_t q=tiles[size_t(ti)*32+size_t(sy*4+sx/2)];unsigned ci=(sx&1)?(q>>4):(q&15);out[size_t((y*8+py)*w+x*8+px)]=colors[ci];}}return out;}
inline const std::vector<uint32_t>& uiOriginalMenuSky(){static const auto p=uiDecode4bpp("assets/lz_619B54.bin","assets/lz_61A384.bin","assets/lz_62DD00.bin",32,20);return p;}
inline const std::vector<uint32_t>& uiOriginalPauseBg(){static const auto p=uiDecode8bpp("assets/lz_619B7C.bin","assets/lz_61C670.bin","assets/lz_62E1D0.bin",30,20);return p;}
inline const std::vector<uint32_t>& uiOriginalLevelPlatform(){static const auto p=uiDecode8bpp("assets/lz_619DC0.bin","assets/lz_6235E4.bin","assets/lz_62E718.bin",32,32);return p;}
inline const std::vector<uint32_t>& uiOriginalTitleBadge(){static const auto p=uiDecode8bpp("assets/lz_61A29C.bin","assets/lz_62C428.bin","assets/lz_62FA18.bin",16,16);return p;}
inline bool originalFrontendAssetsAvailable(){return uiOriginalMenuSky().size()==256u*160u&&uiOriginalPauseBg().size()==240u*160u&&uiOriginalLevelPlatform().size()==256u*256u&&uiOriginalTitleBadge().size()==128u*128u;}
inline void uiBlitKeyedScaled(std::vector<uint32_t>& dst,const std::vector<uint32_t>& src,int sw,int sh,int sx0,int sy0,int cw,int ch,int dx,int dy,int dw,int dh,uint32_t key){if(dst.size()!=240u*160u||src.size()<size_t(sw*sh)||cw<=0||ch<=0||dw<=0||dh<=0)return;for(int y=0;y<dh;y++){int sy=sy0+std::clamp(y*ch/dh,0,ch-1);for(int x=0;x<dw;x++){int sx=sx0+std::clamp(x*cw/dw,0,cw-1);uint32_t c=src[size_t(sy*sw+sx)];if(c!=key)uiPixel(dst,dx+x,dy+y,c);}}}
inline void uiDim(std::vector<uint32_t>& p,unsigned num,unsigned den){for(auto& c:p){unsigned r=(c>>16)&255u,g=(c>>8)&255u,b=c&255u;r=r*num/den;g=g*num/den;b=b*num/den;c=0xff000000u|(r<<16)|(g<<8)|b;}}

inline const std::array<const char*,25>& levelNames(){static const std::array<const char*,25> n={{
    "JUNGLE JAM","SHIPWRECKED","TEMPLE OF BOOM","FROSTBITE CAVERN","JUST IN SLIME","DINGODILE",
    "SNOW CRASH","ROCKET RACKET","JUST HANGIN","SHARK ATTACK","RUINED","N GIN",
    "SNOW JOE","ACE OF SPACE","SUNKEN CITY","DOWN THE HOLE","BLIMP BONANZA","TINY",
    "STAR TO FINISH","AIR SUPPLY","NO-FLY ZONE","DRIP DRIP DRIP","FINAL COUNTDOWN","NEO CORTEX","SECRET LEVEL"
}};return n;}
inline unsigned warpRoomOf(unsigned level){return level>=24?4u:level/6u;}
inline unsigned warpSlotOf(unsigned level){return level>=24?0u:level%6u;}
inline unsigned warpLevel(unsigned room,unsigned slot){return room>=4?24u:std::min(23u,room*6u+std::min(slot,5u));}

inline std::vector<uint32_t> renderTitleScreen(bool savePresent,int choice){
    std::vector<uint32_t> p(240*160,0xff071936u);const auto& sky=uiOriginalMenuSky();
    if(sky.size()==256u*160u){for(int y=0;y<160;y++)for(int x=0;x<240;x++)p[size_t(y*240+x)]=sky[size_t(y*256+x+8)];}
    else{for(int y=0;y<160;y++){unsigned r=5u+unsigned(y)/10,g=18u+unsigned(y)/6,b=48u+unsigned(y)/3;for(int x=0;x<240;x++)p[size_t(y*240+x)]=0xff000000u|(std::min(r,40u)<<16)|(std::min(g,75u)<<8)|std::min(b,115u);}}
    const auto& badge=uiOriginalTitleBadge();if(badge.size()==128u*128u){uint32_t key=badge[0];uiBlitKeyedScaled(p,badge,128,128,0,0,128,128,198,72,38,38,key);}
    uiRect(p,18,14,204,48,0xff142a47u);uiRect(p,21,17,198,42,0xff254a70u);
    uiCentered(p,21,"CRASH",0xffff8a20u,2);uiCentered(p,39,"BANDICOOT",0xffffd04au,1);uiCentered(p,51,"THE HUGE ADVENTURE",0xffffffffu,1);
    std::vector<std::string> opts=savePresent?std::vector<std::string>{"CONTINUAR","NOVO JOGO","SAIR"}:std::vector<std::string>{"NOVO JOGO","SAIR"};
    uiRect(p,46,82,148,58,0xff17324du);uiRect(p,49,85,142,52,0xffdce9f4u);
    int y0=91;for(size_t i=0;i<opts.size();i++){bool sel=int(i)==choice;if(sel){uiRect(p,52,y0+int(i)*18-4,136,15,0xff57351cu);uiRect(p,55,y0+int(i)*18-2,130,11,0xffb86928u);}uiCentered(p,y0+int(i)*18,opts[i],sel?0xffffffffu:0xff17324du,1);}
    uiRect(p,54,145,132,12,0xff17324du);uiCentered(p,148,"ENTER CONFIRMA",0xffffffffu,1);return p;
}
inline std::vector<uint32_t> renderLevelMap(const RunState& state,unsigned selected){
    selected=std::min(selected,24u);const unsigned room=warpRoomOf(selected),slot=warpSlotOf(selected);
    std::vector<uint32_t> p(240*160,0xff06121du);const auto& pause=uiOriginalPauseBg();
    if(pause.size()==240u*160u){p=pause;uiDim(p,3,5);}else{for(int y=0;y<160;y++){unsigned b=24u+unsigned(y)*28u/160u,g=15u+unsigned(y)*18u/160u,r=4u+unsigned(y)*7u/160u;for(int x=0;x<240;x++)p[size_t(y*240+x)]=0xff000000u|(r<<16)|(g<<8)|b;}}
    const auto& platform=uiOriginalLevelPlatform();if(platform.size()==256u*256u){uint32_t key=platform[0];uiBlitKeyedScaled(p,platform,256,256,7,66,242,166,14,31,212,116,key);}else{
        uiRect(p,15,25,210,16,0xff382e2bu);uiRect(p,18,28,204,10,0xff6b5747u);uiLine(p,20,41,57,119,0xff705d4du);uiLine(p,220,41,183,119,0xff705d4du);
        for(int y=41;y<121;y+=8){int half=34+(y-41)*84/80;uiLine(p,120-half,y,120+half,y,0xff25343bu);}for(int x=35;x<=205;x+=17)uiLine(p,120,44,x,119,0xff1b2b34u);
    }
    uiCentered(p,8,room<4?(std::string("WARP ROOM ")+char('1'+room)):"SECRET WARP",0xffffd75au,1);
    if(room<4){
        static constexpr int px[6]={38,78,120,162,202,120};
        static constexpr int py[6]={91,80,75,80,91,104};
        for(unsigned s=0;s<6;s++){unsigned level=warpLevel(room,s);bool unlocked=state.levelUnlocked(int(level)),done=state.completedLevels.count(int(level))!=0,sel=s==slot;int x=px[s],y=py[s];bool boss=s==5;
            int outer=boss?16:13,inner=boss?12:9;uint32_t ring=sel?0xffffffffu:(unlocked?0xffe7ad43u:0xff4b535bu),fill=done?0xff4fa965u:(unlocked?(boss?0xffa43939u:0xff654291u):0xff252a31u);
            if(boss){uiRect(p,x-18,y-7,36,14,0xff3b2726u);uiRect(p,x-15,y-5,30,10,0xff674139u);}
            uiDisc(p,x,y,outer,0xff211923u);uiCircle(p,x,y,outer,ring);uiCircle(p,x,y,inner,fill);uiDisc(p,x,y,inner-2,fill);
            uiNumber(p,x-(level+1>=10?4:2),y-2,level+1,unlocked?0xffffffffu:0xff72787fu);if(done){uiDisc(p,x+outer-2,y-outer+2,3,0xff71e38cu);uiPixel(p,x+outer-2,y-outer+1,0xffffffffu);}
            if(boss)uiCentered(p,y+18,"BOSS",unlocked?0xffffbf55u:0xff73777du,1);
        }
        uiCentered(p,43,"5 FASES + BOSS",0xff9db4c5u,1);
    }else{
        bool unlocked=state.levelUnlocked(24),done=state.completedLevels.count(24)!=0;uiDisc(p,120,91,28,0xff21182du);uiCircle(p,120,91,28,unlocked?0xfff0c35eu:0xff62666cu);uiCircle(p,120,91,22,unlocked?0xff9f4dc2u:0xff33363du);uiNumber(p,116,88,25,unlocked?0xffffffffu:0xff777d83u);if(done)uiDisc(p,140,70,5,0xff71e38cu);uiCentered(p,43,"SECRET PORTAL",0xffbba4d1u,1);
    }
    uiRect(p,8,124,224,28,0xff0e151du);uiRect(p,10,126,220,24,0xff202b38u);
    std::string n=levelNames()[selected];if(uiTextWidth(n)>218)n=n.substr(0,35);uiCentered(p,129,n,state.levelUnlocked(int(selected))?0xffffffffu:0xff8a9098u,1);
    std::string status=state.levelUnlocked(int(selected))?(state.completedLevels.count(int(selected))?"CONCLUIDA":"LIBERADA"):"BLOQUEADA";uiCentered(p,141,status,state.levelUnlocked(int(selected))?0xffffd75au:0xff8a9098u,1);
    return p;
}
inline std::vector<uint32_t> scaleUi(const std::vector<uint32_t>& logical,int scale){if(scale<=1)return logical;int w=240*scale;std::vector<uint32_t> out(size_t(w*160*scale));for(int y=0;y<160;y++)for(int x=0;x<240;x++){uint32_t c=logical[size_t(y*240+x)];for(int yy=0;yy<scale;yy++)for(int xx=0;xx<scale;xx++)out[size_t((y*scale+yy)*w+x*scale+xx)]=c;}return out;}

}
