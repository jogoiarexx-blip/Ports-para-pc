#pragma once
#include "player.hpp"
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <vector>

namespace crash {

struct MoverState {
    bool enabled=false;
    unsigned kind=0;
    int inputDistX=0,inputDistY=0;
    int rangeX=0,rangeY=0;
    int travelledX=0,travelledY=0;
    bool dirX=false,dirY=false;
    int32_t xQ8=0,yQ8=0;
    int32_t vxQ8=0,vyQ8=0;
    int32_t targetVxQ8=0,targetVyQ8=0;
    int lastX=0,lastY=0;
    bool active=false,falling=false;
    unsigned specialTimer=0,holdUntil=0;
};

struct RuntimeEntity {
    Entity source;
    bool active=true;
    unsigned stateTicks=0,countdown=0;
    bool triggered=false,dying=false,facingLeft=false,attacking=false,attackDamageDone=false;
    unsigned hits=0,triggerCap=0,deathTicks=0,attackTicks=0;
    double x=0,y=0,prevX=0,prevY=0,patrolOrigin=0,patrolRange=0,patrolSpeed=.8;
    MoverState mover{};
    RuntimeEntity()=default;
    explicit RuntimeEntity(const Entity& e):source(e),x(e.x),y(e.y),prevX(e.x),prevY(e.y){mover.xQ8=int32_t(e.x)<<8;mover.yQ8=int32_t(e.y)<<8;mover.lastX=int(e.x);mover.lastY=int(e.y);}
};

struct EntityEffect { double x=0,y=0; unsigned animation=0,ticks=0; };
struct EntityClip { std::vector<Frame> frames; unsigned duration=1,flags=0; };

class EntityWorld {
 public:
    static constexpr unsigned WumpaType=6,GemType=7,TimeTrialType=16,CrateFirst=21,CrateLast=39,EnemyType=40,PlantType=42;
    static constexpr unsigned MovingPlatformType=79,ExitMarkerType=85,LevelPlatformType=86,TimedPlatformType=87,FallingPlatformType=88;
    static constexpr unsigned CheckpointCrateType=22,AkuCrateType=23,LifeCrateType=30,NitroCrateType=31,QuestionCrateType=32,BounceCrateType=33,TntCrateType=35,CounterCrateType=36;

    std::vector<RuntimeEntity> items;
    std::vector<Frame> wumpaFrames;
    std::array<EntityClip,36> crateClips{};
    std::array<Player::SolidBox,36> crateBounds{};
    std::array<EntityClip,13> levelObjectClips{};
    std::array<Player::SolidBox,13> levelObjectBounds{};
    std::array<EntityClip,2> enemyClips{};
    std::array<Player::SolidBox,2> enemyBounds{};
    std::array<EntityClip,2> plantClips{};
    EntityClip gemClip{},timeTrialClip{};
    Player::SolidBox gemBounds{},timeTrialBounds{};
    std::array<Player::SolidBox,2> plantBodyBounds{};
    std::array<Player::SolidBox,2> plantHitBounds{};
    std::vector<EntityEffect> effects;
    std::vector<Player::SolidBox> solids;

    unsigned wumpaCollected=0,wumpaTotal=0,wumpaPlaced=0;
    unsigned crateBroken=0,crateTotal=0,checkpointHits=0,akuMasks=0,extraLives=0,hazardHits=0;
    unsigned levelObjectTotal=0,moverTotal=0,carriedTicks=0,ticks=0;
    unsigned enemyTotal=0,enemyKills=0,plantTotal=0,plantAttacks=0,gemTotal=0,gemsCollected=0,timeTrialTotal=0,exitMarkers=0;
    int worldWidth=0;
    bool levelExitTriggered=false,exitMarkerArmed=false,autoExitCandidate=false,timeTrialAvailable=false,timeTrialStarted=false;

    EntityWorld(const GameData& data,const Scene& scene){
        for(const auto& layer:scene.layers)if(layer.slot==4)worldWidth=int(layer.wt*8);
        for(auto e:data.entities(scene)){
            RuntimeEntity r(e);
            if(e.type==QuestionCrateType||e.type==CounterCrateType)r.triggerCap=parameterByte(data,scene,e.param,6);
            if(e.type==EnemyType){
                r.patrolOrigin=e.x;r.patrolRange=std::max(8.0,double(std::abs(parameterSWord(data,scene,e.param,4))));
                const unsigned flags=parameterByte(data,scene,e.param,0);r.facingLeft=(((flags>>1)^1)&1)!=0;
            } else if(e.type==PlantType) {
                const unsigned flags=parameterByte(data,scene,e.param,0);r.facingLeft=(((flags>>1)^1)&1)!=0;
            }
            if(e.type==MovingPlatformType){
                const unsigned recordType=parameterWord(data,scene,e.param,4);
                if(recordType==1||recordType==5||recordType==6||recordType==7)configureMover(r,recordType,parameterSWord(data,scene,e.param,8),parameterSWord(data,scene,e.param,12),parameterSHalf(data,scene,e.param,16)!=0,parameterSHalf(data,scene,e.param,18)!=0);
            } else if(e.type==TimedPlatformType) {
                configureMover(r,6,0,0,false,false);
            } else if(e.type==FallingPlatformType) {
                configureMover(r,7,0,0,false,false);
            }
            items.push_back(r);
            if(e.type==WumpaType){++wumpaPlaced;++wumpaTotal;}
            if(e.type==GemType)++gemTotal;
            if(e.type==TimeTrialType){++timeTrialTotal;items.back().active=false;}
            if(isCrate(e.type)){++crateTotal;wumpaTotal+=r.triggerCap;}
            if(isLevelObject(e.type))++levelObjectTotal;
            if(e.type==EnemyType)++enemyTotal;
            if(e.type==PlantType)++plantTotal;
            if(e.type==ExitMarkerType){++exitMarkers;if(worldWidth>0&&int(e.x)>=worldWidth-300)autoExitCandidate=true;}
            if(r.mover.enabled&&(r.mover.rangeX||r.mover.rangeY||r.mover.kind>=5))++moverTotal;
        }
        loadWumpaFrames(data);
        loadCrateClips(data);
        loadLevelObjectClips(data);
        loadEnemyClips(data);
        loadPlantClips(data);
        loadGemClip(data);
        loadTimeTrialClip(data);
        if(wumpaPlaced&&wumpaFrames.size()!=14)throw std::runtime_error("Wumpa frame set incomplete");
        if(data.banks.at(31).animations.size()!=36)throw std::runtime_error("Crate bank revision");
        rebuildSolids();
    }

    static bool isCrate(unsigned type){return type>=CrateFirst&&type<=CrateLast;}
    static bool isLevelObject(unsigned type){return type==78||type==79||type==80||type==LevelPlatformType||type==TimedPlatformType||type==FallingPlatformType;}
    static bool solidLevelObject(unsigned type){return type==MovingPlatformType||type==LevelPlatformType||type==TimedPlatformType||type==FallingPlatformType;}
    static unsigned levelObjectAnimation(unsigned type){
        switch(type){case 78:return 0;case 79:return 1;case 80:return 2;case LevelPlatformType:return 5;case TimedPlatformType:return 6;case FallingPlatformType:return 8;default:throw std::runtime_error("Not a supported level object");}
    }
    static unsigned crateAnimation(unsigned type){
        // USA ACQE: level entity 21..39 -> level dispatch -> physics box constructor -> bank 31 animation tag.
        static constexpr unsigned map[19]={31,26,23,3,24,21,4,32,2,28,5,0,25,6,17,7,14,15,16};
        if(!isCrate(type))throw std::runtime_error("Not a crate entity type");
        return map[type-CrateFirst];
    }
    static bool metalCrate(unsigned type){return type==28||type==29;}
    static bool metalArrowCrate(unsigned type){return type==29;}
    static bool nitroCrate(unsigned type){return type==NitroCrateType;}
    static bool tntCrate(unsigned type){return type==TntCrateType;}
    static bool repeatedTriggerCrate(unsigned type){return type==QuestionCrateType||type==CounterCrateType;}

    void bind(Player& p){rebuildSolids();p.setDynamicSolids(&solids);}
    void setTimeTrialAvailable(bool enabled){timeTrialAvailable=enabled;for(auto& e:items)if(e.source.type==TimeTrialType)e.active=enabled&&!timeTrialStarted;}
    void armExitMarker(bool enabled=true){exitMarkerArmed=enabled;if(!enabled)levelExitTriggered=false;}
    bool canAutoExit()const{return autoExitCandidate;}
    void reset(){
        for(auto& e:items){
            e.active=true;e.stateTicks=e.countdown=e.hits=e.deathTicks=e.attackTicks=0;e.triggered=e.dying=e.attacking=e.attackDamageDone=false;e.x=e.source.x;e.y=e.source.y;e.prevX=e.x;e.prevY=e.y;
            if(e.source.type==EnemyType)e.patrolOrigin=e.source.x;
            if(e.mover.enabled){e.mover.xQ8=int32_t(e.source.x)<<8;e.mover.yQ8=int32_t(e.source.y)<<8;e.mover.vxQ8=e.mover.vyQ8=0;e.mover.travelledX=e.mover.inputDistX;e.mover.travelledY=e.mover.inputDistY;e.mover.lastX=int(e.source.x);e.mover.lastY=int(e.source.y);e.mover.active=e.mover.falling=false;e.mover.specialTimer=0;e.mover.holdUntil=e.mover.kind==6?120:0;setMoverTargets(e.mover);}
        }
        effects.clear();wumpaCollected=crateBroken=checkpointHits=akuMasks=extraLives=hazardHits=carriedTicks=ticks=0;enemyKills=plantAttacks=gemsCollected=0;levelExitTriggered=false;timeTrialStarted=false;for(auto& e:items)if(e.source.type==TimeTrialType)e.active=timeTrialAvailable;rebuildSolids();
    }

    void step(Player& p){
        ++ticks;
        for(auto& fx:effects)++fx.ticks;
        effects.erase(std::remove_if(effects.begin(),effects.end(),[&](const EntityEffect& fx){return fx.ticks>=effectLength(fx.animation);}),effects.end());

        stepMovers(p);
        rebuildSolids();

        auto body=p.bodyBox(),attack=p.attackBox();
        for(auto& e:items){
            if(!e.active)continue;
            ++e.stateTicks;
            if(e.source.type==WumpaType){if(overlap(body,entityBox(e))){e.active=false;++wumpaCollected;}continue;}
            if(e.source.type==GemType){if(overlap(body,entityBox(e))){e.active=false;++gemsCollected;}continue;}
            if(e.source.type==TimeTrialType){if(timeTrialAvailable&&overlap(body,entityBox(e))){e.active=false;timeTrialStarted=true;timeTrialAvailable=false;}continue;}
            if(e.source.type==ExitMarkerType){
                const double cx=(body[0]+body[2])*.5,cy=(body[1]+body[3])*.5;
                if(exitMarkerArmed&&std::abs(cx-e.x)<=50.0&&std::abs(cy-e.y)<=50.0)levelExitTriggered=true;
                continue;
            }
            if(e.source.type==EnemyType){stepEnemy(e,p,body,attack);body=p.bodyBox();attack=p.attackBox();continue;}
            if(e.source.type==PlantType){stepPlant(e,p,body);body=p.bodyBox();attack=p.attackBox();continue;}
            if(!isCrate(e.source.type))continue;
            if(e.triggered&&e.countdown){--e.countdown;if(!e.countdown){explode(e,p);body=p.bodyBox();attack=p.attackBox();}continue;}
            const auto box=entityBox(e);
            const bool spinHit=p.spinning()&&overlap(attack,box);
            const bool contact=touch(body,box,.75);
            const bool onTop=p.lastDownImpact>1.0&&horizontal(body,box)&&std::abs(body[3]-box[1])<1.25;
            const bool fromBelow=p.lastUpImpact<-.8&&horizontal(body,box)&&std::abs(body[1]-box[3])<1.25;
            if(nitroCrate(e.source.type)){
                if(spinHit||contact){e.active=false;++crateBroken;effects.push_back({e.x,e.y,35,0});hurt(p);body=p.bodyBox();attack=p.attackBox();}
                continue;
            }
            if(metalCrate(e.source.type)){if(onTop&&metalArrowCrate(e.source.type))p.bounce(-7.2);continue;}
            if(tntCrate(e.source.type)){
                if(spinHit){e.triggered=true;e.countdown=8;}
                else if(onTop||fromBelow){e.triggered=true;e.countdown=180;if(onTop)p.bounce();}
                continue;
            }
            if(spinHit){breakCrate(e,p);body=p.bodyBox();attack=p.attackBox();continue;}
            if(onTop&&e.source.type==BounceCrateType){p.bounce(-7.0);continue;}
            if((onTop||fromBelow)&&repeatedTriggerCrate(e.source.type)&&e.triggerCap){
                ++e.hits;++wumpaCollected;e.stateTicks=0;
                if(e.hits>=e.triggerCap)breakCrate(e,p,false);else if(onTop)p.bounce(-5.7);
                body=p.bodyBox();attack=p.attackBox();continue;
            }
            if(onTop||fromBelow){breakCrate(e,p);if(onTop)p.bounce();body=p.bodyBox();attack=p.attackBox();}
        }
        rebuildSolids();
    }

    void renderLogical(std::vector<uint32_t>& canvas,int w,int h,int cameraX,int cameraY,bool hud=true)const{
        if(!wumpaFrames.empty()){
            const auto& f=wumpaFrames[(ticks/4)%wumpaFrames.size()];
            for(const auto& e:items)if(e.active&&e.source.type==WumpaType)GameData::blit(canvas,w,h,f,int(std::lround(e.x))-cameraX,int(std::lround(e.y))-cameraY);
        }
        if(!gemClip.frames.empty()){const Frame* f=clipFrame(gemClip,ticks);if(f)for(const auto& e:items)if(e.active&&e.source.type==GemType)GameData::blit(canvas,w,h,*f,int(std::lround(e.x))-cameraX,int(std::lround(e.y))-cameraY);}
        if(!timeTrialClip.frames.empty()){const Frame* f=clipFrame(timeTrialClip,ticks);if(f)for(const auto& e:items)if(e.active&&e.source.type==TimeTrialType)GameData::blit(canvas,w,h,*f,int(std::lround(e.x))-cameraX,int(std::lround(e.y))-cameraY);}
        for(const auto& e:items)if(e.active&&isLevelObject(e.source.type)){
            unsigned anim=levelObjectAnimation(e.source.type);const Frame* f=clipFrame(levelObjectClips[anim],levelObjectTick(e,anim));
            if(f)GameData::blit(canvas,w,h,*f,int(std::lround(e.x))-cameraX,int(std::lround(e.y))-cameraY);
        }
        for(const auto& e:items)if(e.active&&e.source.type==EnemyType){
            const unsigned anim=e.dying?1u:0u;const Frame* f=clipFrame(enemyClips[anim],e.dying?e.deathTicks:e.stateTicks);
            if(f)GameData::blit(canvas,w,h,*f,int(std::lround(e.x))-cameraX,int(std::lround(e.y))-cameraY,e.facingLeft);
        }
        for(const auto& e:items)if(e.active&&e.source.type==PlantType){
            const unsigned anim=e.attacking?1u:0u;const Frame* f=clipFrame(plantClips[anim],e.attacking?e.attackTicks:e.stateTicks);
            if(f)GameData::blit(canvas,w,h,*f,int(std::lround(e.x))-cameraX,int(std::lround(e.y))-cameraY,e.facingLeft);
        }
        for(const auto& e:items)if(e.active&&isCrate(e.source.type)){
            unsigned anim=crateAnimation(e.source.type),local=e.stateTicks;
            if(tntCrate(e.source.type)&&e.triggered){anim=e.countdown>120?18:e.countdown>60?19:20;local=e.stateTicks;}
            const Frame* f=clipFrame(anim,local);if(f)GameData::blit(canvas,w,h,*f,int(std::lround(e.x))-cameraX,int(std::lround(e.y))-cameraY);
        }
        for(const auto& fx:effects){const Frame* f=clipFrame(fx.animation,fx.ticks);if(f)GameData::blit(canvas,w,h,*f,int(std::lround(fx.x))-cameraX,int(std::lround(fx.y))-cameraY);}
        if(hud){
            if(!wumpaFrames.empty()){GameData::blit(canvas,w,h,wumpaFrames[(ticks/4)%wumpaFrames.size()],14,15);drawX(canvas,w,h,27,8);drawNumber(canvas,w,h,34,7,wumpaCollected);}
            if(const Frame* box=clipFrame(31,0)){GameData::blit(canvas,w,h,*box,78,15);drawX(canvas,w,h,91,8);drawNumber(canvas,w,h,98,7,crateBroken);}
            if(akuMasks){drawLetterA(canvas,w,h,139,7);drawX(canvas,w,h,146,8);drawNumber(canvas,w,h,153,7,akuMasks);}
            if(gemTotal&&!gemClip.frames.empty()){GameData::blit(canvas,w,h,*clipFrame(gemClip,ticks),198,15);drawX(canvas,w,h,210,8);drawNumber(canvas,w,h,217,7,gemsCollected);}
        }
    }

    Player::SolidBox entityBox(const RuntimeEntity& e)const{
        if(isCrate(e.source.type)){auto q=crateBounds[crateAnimation(e.source.type)];return {e.x+q[0],e.y+q[1],e.x+q[2],e.y+q[3]};}
        if(e.source.type==GemType)return {e.x+gemBounds[0],e.y+gemBounds[1],e.x+gemBounds[2],e.y+gemBounds[3]};
        if(e.source.type==TimeTrialType)return {e.x+timeTrialBounds[0],e.y+timeTrialBounds[1],e.x+timeTrialBounds[2],e.y+timeTrialBounds[3]};
        if(isLevelObject(e.source.type)){auto q=levelObjectBounds[levelObjectAnimation(e.source.type)];return {e.x+q[0],e.y+q[1],e.x+q[2],e.y+q[3]};}
        if(e.source.type==EnemyType){auto q=enemyBounds[e.dying?1:0];return translatedBox(e, q);}
        if(e.source.type==PlantType){auto q=plantBodyBounds[e.attacking?1:0];return translatedBox(e,q);}
        return {e.x-12,e.y-12,e.x+12,e.y+12};
    }

    Player::SolidBox plantTriggerBox(const RuntimeEntity& e)const{Player::SolidBox q{0,-20,45,0};return translatedBox(e,q);}
    Player::SolidBox plantHitBox(const RuntimeEntity& e)const{return translatedBox(e,plantHitBounds[e.attacking?1:0]);}

    struct Snapshot {
        std::vector<RuntimeEntity> items;
        unsigned wumpaCollected=0,crateBroken=0,checkpointHits=0,hazardHits=0;
        unsigned carriedTicks=0,ticks=0,enemyKills=0,plantAttacks=0,gemsCollected=0;
        bool exitMarkerArmed=false;
    };
    Snapshot snapshot()const{
        Snapshot s;s.items=items;s.wumpaCollected=wumpaCollected;s.crateBroken=crateBroken;s.checkpointHits=checkpointHits;s.hazardHits=hazardHits;s.carriedTicks=carriedTicks;s.ticks=ticks;s.enemyKills=enemyKills;s.plantAttacks=plantAttacks;s.gemsCollected=gemsCollected;s.exitMarkerArmed=exitMarkerArmed;return s;
    }
    void restore(const Snapshot& s){
        if(s.items.size()!=items.size())throw std::runtime_error("Entity snapshot revision");
        items=s.items;wumpaCollected=s.wumpaCollected;crateBroken=s.crateBroken;checkpointHits=s.checkpointHits;hazardHits=s.hazardHits;carriedTicks=s.carriedTicks;ticks=s.ticks;enemyKills=s.enemyKills;plantAttacks=s.plantAttacks;gemsCollected=s.gemsCollected;exitMarkerArmed=s.exitMarkerArmed;levelExitTriggered=false;effects.clear();rebuildSolids();
    }

 private:
    static uint32_t parameterAddress(const GameData& data,const Scene& scene,unsigned index){uint32_t list=data.rom.w(scene.descriptor+28),offsets=data.rom.w(list+8),params=data.rom.w(list+12);return params+data.rom.h(offsets+2*index);}
    static unsigned parameterByte(const GameData& data,const Scene& scene,unsigned index,unsigned off){return data.rom.b(parameterAddress(data,scene,index)+off);}
    static uint32_t parameterWord(const GameData& data,const Scene& scene,unsigned index,unsigned off){return data.rom.w(parameterAddress(data,scene,index)+off);}
    static int32_t parameterSWord(const GameData& data,const Scene& scene,unsigned index,unsigned off){return int32_t(parameterWord(data,scene,index,off));}
    static int16_t parameterSHalf(const GameData& data,const Scene& scene,unsigned index,unsigned off){return data.rom.sh(parameterAddress(data,scene,index)+off);}
    static bool overlap(const std::array<double,4>& a,const std::array<double,4>& b){return a[0]<b[2]&&a[2]>b[0]&&a[1]<b[3]&&a[3]>b[1];}
    static bool touch(const std::array<double,4>& a,const std::array<double,4>& b,double eps){return a[0]<=b[2]+eps&&a[2]>=b[0]-eps&&a[1]<=b[3]+eps&&a[3]>=b[1]-eps;}
    static bool horizontal(const std::array<double,4>& a,const std::array<double,4>& b){return a[2]>b[0]+.5&&a[0]<b[2]-.5;}
    static Player::SolidBox translatedBox(const RuntimeEntity& e,const Player::SolidBox& q){if(e.facingLeft)return {e.x-q[2],e.y+q[1],e.x-q[0],e.y+q[3]};return {e.x+q[0],e.y+q[1],e.x+q[2],e.y+q[3]};}

    static void configureMover(RuntimeEntity& e,unsigned kind,int distX,int distY,bool dirX,bool dirY){
        auto& m=e.mover;m.enabled=true;m.kind=kind;m.inputDistX=std::max(0,distX);m.inputDistY=std::max(0,distY);if(kind==6||kind==7)m.inputDistX=m.inputDistY=0;m.rangeX=m.inputDistX*2;m.rangeY=m.inputDistY*2;m.travelledX=m.inputDistX;m.travelledY=m.inputDistY;m.dirX=dirX;m.dirY=dirY;m.xQ8=int32_t(e.source.x)<<8;m.yQ8=int32_t(e.source.y)<<8;m.lastX=int(e.source.x);m.lastY=int(e.source.y);m.holdUntil=kind==6?120:0;setMoverTargets(m);
    }
    static void setMoverTargets(MoverState& m){m.targetVxQ8=m.rangeX?(m.dirX?256:-256):0;m.targetVyQ8=m.rangeY?(m.dirY?256:-256):0;}
    static int32_t approach(int32_t value,int32_t target,int32_t step){if(value<target)return std::min(target,value+step);if(value>target)return std::max(target,value-step);return value;}
    static void integrateAxis(int32_t& posQ8,int32_t& velocityQ8,int32_t targetQ8){velocityQ8=approach(velocityQ8,targetQ8,8);posQ8+=velocityQ8;}
    static void moverDistanceAxis(int currentInt,int& lastInt,int& travelled,int range,bool& dir,int32_t velocityQ8,int32_t& targetQ8){
        if(!range){lastInt=currentInt;return;}
        if(travelled!=-1)travelled+=std::abs(currentInt-lastInt);else if(std::abs(velocityQ8)>=256)travelled=0;
        if(travelled>range){dir=!dir;targetQ8=dir?256:-256;travelled=-1;}
        lastInt=currentInt;
    }
    unsigned levelObjectTick(const RuntimeEntity& e,unsigned /*anim*/)const{
        if(!e.mover.enabled)return e.stateTicks;
        const auto& m=e.mover;
        if(m.kind==6){if(ticks<m.holdUntil)return 0;return ticks-m.holdUntil;}
        if(m.kind==7&&!m.active)return 0;
        return e.stateTicks;
    }
    unsigned levelObjectClipLength(unsigned anim)const{if(anim>=levelObjectClips.size()||levelObjectClips[anim].frames.empty())return 1;return std::max(1u,levelObjectClips[anim].duration)*unsigned(levelObjectClips[anim].frames.size());}
    void stepMovers(Player& p){
        for(auto& e:items){
            if(!e.active||!e.mover.enabled)continue;
            auto oldBox=entityBox(e),body=p.bodyBox();
            const bool standing=p.grounded&&horizontal(body,oldBox)&&std::abs(body[3]-oldBox[1])<1.5;
            auto& m=e.mover;
            if(m.kind==1||m.kind==5||m.kind==6)m.active=standing;
            if(m.kind==6){
                const unsigned anim=levelObjectAnimation(e.source.type);
                if(ticks>=m.holdUntil&&ticks-m.holdUntil>=levelObjectClipLength(anim)){m.holdUntil=ticks+120;e.stateTicks=0;}
                continue;
            }
            if(m.kind==7){
                if(m.active&&e.stateTicks>=levelObjectClipLength(levelObjectAnimation(e.source.type))){e.active=false;m.active=false;}
                continue;
            }
            e.prevX=e.x;e.prevY=e.y;
            if(m.kind==5&&!m.falling){
                if(standing&&m.specialTimer==0)m.specialTimer=1;
                else if(m.specialTimer>0)++m.specialTimer;
                if(m.specialTimer>=60){m.falling=true;m.targetVyQ8=1024;}
            }
            if(m.kind==5&&m.falling){
                m.vyQ8=approach(m.vyQ8,1024,40);m.yQ8+=m.vyQ8;e.y=double(m.yQ8)/256.0;
                if(e.y>p.terrain.height()+160){e.active=false;continue;}
            }else{
                if(m.rangeX)integrateAxis(m.xQ8,m.vxQ8,m.targetVxQ8);
                if(m.rangeY)integrateAxis(m.yQ8,m.vyQ8,m.targetVyQ8);
                e.x=double(m.xQ8)/256.0;e.y=double(m.yQ8)/256.0;
                moverDistanceAxis(int(m.xQ8>>8),m.lastX,m.travelledX,m.rangeX,m.dirX,m.vxQ8,m.targetVxQ8);
                moverDistanceAxis(int(m.yQ8>>8),m.lastY,m.travelledY,m.rangeY,m.dirY,m.vyQ8,m.targetVyQ8);
            }
            if(m.kind==5&&m.active&&!m.falling&&m.specialTimer&&m.specialTimer%30<=4)e.y+=(m.specialTimer&1)?3.0:-3.0;
            if(standing){p.x+=e.x-e.prevX;p.y+=e.y-e.prevY;p.grounded=true;++carriedTicks;}
        }
    }
    bool activateLinkedMover(unsigned id){for(auto& e:items)if(e.source.id==id&&e.mover.enabled){e.mover.active=true;e.stateTicks=0;return true;}return false;}
    void rebuildSolids(){
        solids.clear();solids.reserve(crateTotal+levelObjectTotal);
        for(const auto& e:items)if(e.active&&(isCrate(e.source.type)||solidLevelObject(e.source.type)))solids.push_back(entityBox(e));
    }
    void stepEnemy(RuntimeEntity& e,Player& p,const Player::SolidBox& body,const Player::SolidBox& attack){
        if(e.dying){if(++e.deathTicks>=enemyClipLength(1))e.active=false;return;}
        if(p.spinning()&&overlap(attack,entityBox(e))){e.dying=true;e.deathTicks=0;e.stateTicks=0;++enemyKills;return;}
        const double dir=e.facingLeft?-1.0:1.0;double nx=e.x+dir*e.patrolSpeed;
        if(nx<e.patrolOrigin-e.patrolRange||nx>e.patrolOrigin+e.patrolRange){e.facingLeft=!e.facingLeft;nx=e.x;}
        auto q=enemyBounds[0];double floor=p.terrain.floor(nx+q[0],nx+q[2],e.y+q[3]-6,e.y+q[3]+12);
        if(std::isfinite(floor)){e.prevX=e.x;e.x=nx;e.y=floor-q[3];}else e.facingLeft=!e.facingLeft;
        if(overlap(body,entityBox(e)))hurt(p);
    }
    unsigned enemyClipLength(unsigned anim)const{if(anim>=enemyClips.size()||enemyClips[anim].frames.empty())return 1;return std::max(1u,enemyClips[anim].duration)*unsigned(enemyClips[anim].frames.size());}
    unsigned plantClipLength(unsigned anim)const{if(anim>=plantClips.size()||plantClips[anim].frames.empty())return 1;return std::max(1u,plantClips[anim].duration)*unsigned(plantClips[anim].frames.size());}
    void stepPlant(RuntimeEntity& e,Player& p,const Player::SolidBox& body){
        // Original state 3 / sub_800C5D4: mode 0 tests the fixed 45x20 trigger box; mode 2 plays bank-10 anim 1 until animDone, then returns to mode 0.
        if(!e.attacking){if(overlap(body,plantTriggerBox(e))){e.attacking=true;e.attackTicks=0;e.attackDamageDone=false;e.stateTicks=0;++plantAttacks;}return;}
        ++e.attackTicks;
        if(!e.attackDamageDone&&overlap(body,plantHitBox(e))){e.attackDamageDone=true;hurt(p);}
        if(e.attackTicks>=plantClipLength(1)){e.attacking=false;e.attackTicks=0;e.attackDamageDone=false;e.stateTicks=0;}
    }
    void breakCrate(RuntimeEntity& e,Player& p,bool reward=true){
        if(!e.active)return;
        e.active=false;++crateBroken;effects.push_back({e.x,e.y,29,0});
        if(e.source.type==CheckpointCrateType){++checkpointHits;p.setCheckpoint(e.x,e.y);}
        else if(e.source.type==AkuCrateType)akuMasks=std::min(2u,akuMasks+1);
        else if(e.source.type==LifeCrateType)++extraLives;
        else if(reward&&repeatedTriggerCrate(e.source.type)&&e.triggerCap>e.hits){wumpaCollected+=e.triggerCap-e.hits;e.hits=e.triggerCap;}
    }
    void hurt(Player& p){++hazardHits;if(akuMasks)--akuMasks;else p.respawn();}
    void explode(RuntimeEntity& e,Player& p){
        if(!e.active)return;
        e.active=false;++crateBroken;effects.push_back({e.x,e.y,33,0});
        auto b=p.bodyBox();double cx=(b[0]+b[2])/2,cy=(b[1]+b[3])/2;if(std::hypot(cx-e.x,cy-e.y)<48.0)hurt(p);
        for(auto& other:items){if(!other.active||&other==&e||!isCrate(other.source.type))continue;if(std::hypot(other.x-e.x,other.y-e.y)>42.0)continue;
            if(nitroCrate(other.source.type)){other.active=false;++crateBroken;effects.push_back({other.x,other.y,35,0});}
            else if(tntCrate(other.source.type)){other.triggered=true;other.countdown=8;}
            else if(!metalCrate(other.source.type))breakCrate(other,p);
        }
    }
    unsigned effectLength(unsigned anim)const{if(anim>=crateClips.size()||crateClips[anim].frames.empty())return 1;return std::max(1u,crateClips[anim].duration)*unsigned(crateClips[anim].frames.size());}
    const Frame* clipFrame(unsigned anim,unsigned tick)const{if(anim>=crateClips.size())return nullptr;return clipFrame(crateClips[anim],tick);}
    static const Frame* clipFrame(const EntityClip& c,unsigned tick){if(c.frames.empty())return nullptr;size_t n=tick/std::max(1u,c.duration);n=(c.flags&2)?n%c.frames.size():std::min(n,c.frames.size()-1);return &c.frames[n];}

    static Frame decodeFramed(const GameData& data,const Bytes& asset,size_t p,unsigned paletteRecord){
        if(p+4>asset.size())throw std::runtime_error("Framed sprite header");
        unsigned wt=asset[p],ht=asset[p+1];if((wt!=1&&wt!=2&&wt!=4&&wt!=8)||(ht!=1&&ht!=2&&ht!=4&&ht!=8)||asset[p+2]!=0x10||asset[p+3]!=0)throw std::runtime_error("Framed sprite format");
        size_t bytes=size_t(wt)*ht*32;if(p+4+bytes>asset.size())throw std::runtime_error("Framed sprite data");Frame out;out.width=int(wt*8);out.height=int(ht*8);out.x=-out.width/2;out.y=-out.height/2;out.pixels.assign(size_t(out.width*out.height),0);
        std::array<uint32_t,16> colors{};uint32_t palette=data.rom.w(GameData::Table+8)+32*paletteRecord;for(unsigned i=0;i<16;i++)colors[i]=rgb555(data.rom.h(palette+2*i));
        const size_t base=p+4;for(unsigned ty=0;ty<ht;ty++)for(unsigned tx=0;tx<wt;tx++)for(unsigned y=0;y<8;y++)for(unsigned x=0;x<8;x++){size_t a=base+(ty*wt+tx)*32+y*4+x/2;unsigned v=(asset[a]>>((x&1)*4))&15;if(v)out.pixels[size_t((ty*8+y)*out.width+tx*8+x)]=colors[v];}
        return out;
    }
    void loadWumpaFrames(const GameData& data){
        Bytes asset=data.rom.tagged(0x080B1C60);if(asset.size()!=213064)throw std::runtime_error("Wumpa sheet revision");std::vector<size_t> offsets;size_t p=0;
        while(p<asset.size()){if(p+4>asset.size())throw std::runtime_error("Framed sheet tail");unsigned wt=asset[p],ht=asset[p+1];if((wt!=1&&wt!=2&&wt!=4&&wt!=8)||(ht!=1&&ht!=2&&ht!=4&&ht!=8)||asset[p+2]!=0x10||asset[p+3]!=0)throw std::runtime_error("Framed sheet revision");offsets.push_back(p);p+=4+size_t(wt)*ht*32;}
        if(p!=asset.size()||offsets.size()!=274)throw std::runtime_error("Framed sheet count");
        for(unsigned i=200;i<214;i++)wumpaFrames.push_back(decodeFramed(data,asset,offsets[i],33));
    }
    void loadCrateClips(const GameData& data){
        const auto& bank=data.banks.at(31);if(bank.animations.size()!=36)throw std::runtime_error("Crate animation count");
        for(unsigned ai=0;ai<bank.animations.size();++ai){const auto& a=bank.animations[ai];auto& clip=crateClips[ai];clip.duration=std::max(1u,a.duration);clip.flags=a.flags;for(unsigned fi:a.sequence)clip.frames.push_back(data.frame(31,fi,a.paletteRecord));double l=data.rom.sh(a.address+4),t=data.rom.sh(a.address+6);crateBounds[ai]={l,t,l+data.rom.b(a.address+8),t+data.rom.b(a.address+9)};}
    }
    void loadLevelObjectClips(const GameData& data){
        const auto& bank=data.banks.at(39);if(bank.animations.size()!=levelObjectClips.size())throw std::runtime_error("Level-object bank revision");
        for(unsigned ai=0;ai<bank.animations.size();++ai){const auto& a=bank.animations[ai];auto& clip=levelObjectClips[ai];clip.duration=std::max(1u,a.duration);clip.flags=a.flags;for(unsigned fi:a.sequence)clip.frames.push_back(data.frame(39,fi,a.paletteRecord));double l=data.rom.sh(a.address+4),t=data.rom.sh(a.address+6);levelObjectBounds[ai]={l,t,l+data.rom.b(a.address+8),t+data.rom.b(a.address+9)};}
    }
    void loadEnemyClips(const GameData& data){
        const auto& bank=data.banks.at(13);if(bank.animations.size()!=enemyClips.size())throw std::runtime_error("Enemy bank 13 revision");
        for(unsigned ai=0;ai<bank.animations.size();++ai){const auto& a=bank.animations[ai];auto& clip=enemyClips[ai];clip.duration=std::max(1u,a.duration);clip.flags=a.flags;for(unsigned fi:a.sequence)clip.frames.push_back(data.frame(13,fi,a.paletteRecord));double l=data.rom.sh(a.address+4),t=data.rom.sh(a.address+6);enemyBounds[ai]={l,t,l+data.rom.b(a.address+8),t+data.rom.b(a.address+9)};}
    }
    void loadPlantClips(const GameData& data){
        const auto& bank=data.banks.at(10);if(bank.animations.size()!=plantClips.size())throw std::runtime_error("Plant bank 10 revision");
        for(unsigned ai=0;ai<bank.animations.size();++ai){const auto& a=bank.animations[ai];auto& clip=plantClips[ai];clip.duration=std::max(1u,a.duration);clip.flags=a.flags;for(unsigned fi:a.sequence)clip.frames.push_back(data.frame(10,fi,a.paletteRecord));double l=data.rom.sh(a.address+4),t=data.rom.sh(a.address+6);plantBodyBounds[ai]={l,t,l+data.rom.b(a.address+8),t+data.rom.b(a.address+9)};l=data.rom.sh(a.address+12);t=data.rom.sh(a.address+14);plantHitBounds[ai]={l,t,l+data.rom.b(a.address+16),t+data.rom.b(a.address+17)};}
    }
    void loadGemClip(const GameData& data){
        const auto& bank=data.banks.at(37);if(bank.animations.size()!=1)throw std::runtime_error("Gem bank 37 revision");const auto& a=bank.animations[0];gemClip.duration=std::max(1u,a.duration);gemClip.flags=a.flags;for(unsigned fi:a.sequence)gemClip.frames.push_back(data.frame(37,fi,a.paletteRecord));double l=data.rom.sh(a.address+4),t=data.rom.sh(a.address+6);gemBounds={l,t,l+data.rom.b(a.address+8),t+data.rom.b(a.address+9)};
    }
    void loadTimeTrialClip(const GameData& data){
        const auto& bank=data.banks.at(36);if(bank.animations.size()!=1)throw std::runtime_error("Time-trial bank 36 revision");const auto& a=bank.animations[0];timeTrialClip.duration=std::max(1u,a.duration);timeTrialClip.flags=a.flags;for(unsigned fi:a.sequence)timeTrialClip.frames.push_back(data.frame(36,fi,a.paletteRecord));double l=data.rom.sh(a.address+4),t=data.rom.sh(a.address+6);timeTrialBounds={l,t,l+data.rom.b(a.address+8),t+data.rom.b(a.address+9)};
    }

    static void pixel(std::vector<uint32_t>& c,int w,int h,int x,int y,uint32_t color){if(x>=0&&y>=0&&x<w&&y<h)c[size_t(y*w+x)]=color;}
    static void drawX(std::vector<uint32_t>& c,int w,int h,int x,int y){for(int i=0;i<5;i++){pixel(c,w,h,x+i,y+i,0xfff8f8f0);pixel(c,w,h,x+4-i,y+i,0xfff8f8f0);}}
    static void drawLetterA(std::vector<uint32_t>& c,int w,int h,int x,int y){for(int yy=0;yy<5;yy++)for(int xx=0;xx<4;xx++)if((yy==0&&xx>0&&xx<3)||(xx==0&&yy>0)||(xx==3&&yy>0)||(yy==2))pixel(c,w,h,x+xx,y+yy,0xfff8e76c);}
    static void drawDigit(std::vector<uint32_t>& c,int w,int h,int x,int y,unsigned d){
        static constexpr const char* pat[10]={"111101101101111","010110010010111","111001111100111","111001111001111","101101111001001","111100111001111","111100111101111","111001001001001","111101111101111","111101111001111"};const char* p=pat[d%10];
        for(int yy=0;yy<5;yy++)for(int xx=0;xx<3;xx++)if(p[yy*3+xx]=='1'){pixel(c,w,h,x+xx+1,y+yy+1,0xff101018);pixel(c,w,h,x+xx,y+yy,0xfff8e76c);}
    }
    static void drawNumber(std::vector<uint32_t>& c,int w,int h,int x,int y,unsigned value){std::array<unsigned,3> ds{(value/100)%10,(value/10)%10,value%10};unsigned first=value>=100?0:value>=10?1:2;for(unsigned i=first;i<3;i++)drawDigit(c,w,h,x+int((i-first)*5),y,ds[i]);}
};

}
