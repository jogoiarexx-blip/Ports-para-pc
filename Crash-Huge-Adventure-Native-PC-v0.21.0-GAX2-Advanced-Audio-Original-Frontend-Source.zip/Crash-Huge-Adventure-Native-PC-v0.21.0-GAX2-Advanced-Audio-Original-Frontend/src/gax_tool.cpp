#include "gax_rom.hpp"
#include <iomanip>
#include <iostream>
int main(int argc,char** argv){try{using namespace crash;
    const char* path=argc>1?argv[1]:"input/crash.gba";auto rom=read(path);size_t table=0;auto songs=parseGaxSongs(rom,&table);auto tracks=scanGaxTracks(rom);auto waves=parseWaveTable(rom,songs[0].waveTablePtr,30);auto inst=parseInstrumentBank(rom,songs[0].instrumentTablePtr,52);auto sfx=parseGaxSfxTable(rom,table);uint32_t sfxData=findGaxSfxSongData(rom,songs[0]);
    unsigned env=0,vib=0,sweep=0,ping=0,seqfx=0;for(const auto& i:inst){if(i.envelope.valid)++env;if(i.vibratoDepth)++vib;for(const auto& r:i.rows){if(r.sweepEnabled)++sweep;if(r.pingPong)++ping;}for(const auto& e:i.seq)for(auto fx:e.fx)if(fx)++seqfx;}
    std::cout<<"Engine: "<<gaxVersion(rom)<<"\nSong table ROM offset: 0x"<<std::hex<<std::uppercase<<table<<std::dec<<"\n";
    std::cout<<"Songs: "<<songs.size()<<" | metadata tags: "<<tracks.size()<<" | music PCM waves: "<<(waves.size()?waves.size()-1:0)<<" | SFX routes: "<<sfx.size()<<"\n";
    std::cout<<"Music instruments: "<<inst.size()<<" | envelopes: "<<env<<" | vibrato instruments: "<<vib<<" | sweep rows: "<<sweep<<" | ping-pong rows: "<<ping<<" | sequence FX: "<<seqfx<<"\n";
    if(sfxData)std::cout<<"SFX SongData: 0x"<<std::hex<<std::uppercase<<sfxData<<"  instruments: 0x"<<gaxU32(rom,sfxData+0x10)<<"  waves: 0x"<<gaxU32(rom,sfxData+0x14)<<std::dec<<"\n";
    for(const auto& s:songs)std::cout<<std::setw(2)<<s.id<<"  0x"<<std::hex<<std::uppercase<<s.songPtr<<std::dec<<"  "<<std::left<<std::setw(18)<<s.title<<std::right<<" ch="<<s.channels<<" rows="<<s.patternRows<<" orders="<<s.orderCount<<" rate="<<s.mixRate<<" Hz\n";
    return songs.size()==19?0:1;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
