#pragma once
#include "audio.hpp"
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <limits>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

namespace crash {

inline bool gaxPtr(const Bytes& rom,uint32_t p,size_t n=1){return p>=0x08000000u&&size_t(p-0x08000000u)<=rom.size()&&n<=rom.size()-size_t(p-0x08000000u);}
inline size_t gaxOff(const Bytes& rom,uint32_t p,size_t n=1){if(!gaxPtr(rom,p,n))throw std::runtime_error("GAX ROM pointer bounds");return size_t(p-0x08000000u);}
inline uint16_t gaxU16(const Bytes& r,uint32_t p){auto o=gaxOff(r,p,2);return uint16_t(r[o]|(uint16_t(r[o+1])<<8));}
inline int16_t gaxS16(const Bytes& r,uint32_t p){return int16_t(gaxU16(r,p));}
inline uint32_t gaxU32(const Bytes& r,uint32_t p){return u32(r,gaxOff(r,p,4));}
inline int32_t gaxS32(const Bytes& r,uint32_t p){return int32_t(gaxU32(r,p));}

struct GaxOrderEntry { uint16_t patternOffset=0; int8_t transpose=0; };
struct GaxRomSong {
    unsigned id=0,channels=0,patternRows=0,orderCount=0,loopOrder=0,volume=0,mixRate=0,numSfx=0;
    uint32_t songPtr=0,infoTypePtr=0,songDataPtr=0,patternsPtr=0,instrumentTablePtr=0,waveTablePtr=0;
    std::string title;
    std::vector<std::vector<GaxOrderEntry>> orders;
};
struct GaxWaveInfo { uint32_t ptr=0,length=0; };
struct GaxSfxEntry { unsigned slotId=0; int32_t priority=0; unsigned baseVolume=0; };
struct GaxEnvelopePointInfo { unsigned pos=0; int slope=0; unsigned value=0; };
struct GaxEnvelopeInfo {
    unsigned count=0,sustain=0xff,loopStart=0xff,loopEnd=0xff;
    std::vector<GaxEnvelopePointInfo> points;
    bool valid=false;
};
struct GaxInstrumentRowInfo {
    bool sweepEnabled=false,pingPong=false;
    int start=0,sweepMin=0,sweepMax=0,sweepLen=0,sweepStep=0,tune=0;
    unsigned sweepRate=0;
};
struct GaxSeqEntryInfo {
    unsigned note=0,wave=0;
    bool fixedPitch=false;
    std::array<uint16_t,2> fx{};
};
struct GaxInstrumentInfo {
    uint32_t ptr=0;
    std::array<uint8_t,4> waveIdx{};
    unsigned vibratoDelay=0,vibratoDepth=0,vibratoSpeed=0,cutDelay=0;
    std::array<GaxInstrumentRowInfo,4> rows{};
    GaxEnvelopeInfo envelope;
    std::vector<GaxSeqEntryInfo> seq;
    // Compatibility summary fields retained for tools/tests from v0.20.
    unsigned row=0,seqNote=0; int tune=0,start=0,loopStart=0,loopEnd=0; bool fixedPitch=false,valid=false;
};

inline const std::array<const char*,19>& gaxSongNames(){
    static const std::array<const char*,19> n{{"jungle","underwater","arctic","sewers","future","rocket crash","bonus round","dingodile","n gin","tiny","neo cortex","main menu europe","main menu japan","cutscenes","cutscenes spooky","intro","warp room","credits","drums"}};return n;
}
inline const std::array<unsigned,19>& gaxSongChannels(){
    static const std::array<unsigned,19> n{{4,5,4,5,5,4,6,5,5,5,5,7,1,6,7,6,7,7,3}};return n;
}

inline bool gaxSongLooksValid(const Bytes& rom,uint32_t songPtr,unsigned expectedChannels){
    if(!gaxPtr(rom,songPtr,16+(expectedChannels*4)))return false;
    const unsigned items=gaxU32(rom,songPtr);if(items!=expectedChannels+3)return false;
    const uint32_t info=gaxU32(rom,songPtr+8);if(!gaxPtr(rom,info,28))return false;
    const uint32_t songData=gaxU32(rom,info+24);if(!gaxPtr(rom,songData,28))return false;
    const unsigned rows=gaxU16(rom,songData+2),orders=gaxU16(rom,songData+4),rate=gaxU16(rom,songData+0x18);
    if(rows<1||rows>64||orders<1||orders>128||rate<5000||rate>50000)return false;
    if(!gaxPtr(rom,gaxU32(rom,songData+0x0c))||!gaxPtr(rom,gaxU32(rom,songData+0x10))||!gaxPtr(rom,gaxU32(rom,songData+0x14),8))return false;
    for(unsigned c=0;c<expectedChannels;c++){uint32_t type=gaxU32(rom,songPtr+16+c*4);if(!gaxPtr(rom,type,28))return false;uint32_t orderPtr=gaxU32(rom,type+24);if(!gaxPtr(rom,orderPtr,orders*4))return false;}
    return true;
}

inline size_t findGaxSongTableOffset(const Bytes& rom){
    const auto& ch=gaxSongChannels();
    for(size_t p=0x100000;p+19*4<=std::min<size_t>(rom.size(),0x240000);p+=4){
        uint32_t first=u32(rom,p);if(!gaxPtr(rom,first,32))continue;
        if(!gaxSongLooksValid(rom,first,ch[0]))continue;
        bool ok=true;for(unsigned i=1;i<19&&ok;i++){uint32_t s=u32(rom,p+i*4);ok=gaxSongLooksValid(rom,s,ch[i]);}
        if(ok)return p;
    }
    throw std::runtime_error("GAX 19-song table not found");
}

inline GaxRomSong parseGaxSong(const Bytes& rom,size_t tableOffset,unsigned id){
    if(id>=19)throw std::runtime_error("GAX song id");
    GaxRomSong s;s.id=id;s.title=gaxSongNames()[id];s.songPtr=u32(rom,tableOffset+id*4);s.channels=gaxSongChannels()[id];
    if(!gaxSongLooksValid(rom,s.songPtr,s.channels))throw std::runtime_error("Invalid GAX song layout");
    uint32_t info=gaxU32(rom,s.songPtr+8);s.infoTypePtr=info;s.songDataPtr=gaxU32(rom,info+24);
    s.patternRows=gaxU16(rom,s.songDataPtr+2);s.orderCount=gaxU16(rom,s.songDataPtr+4);s.loopOrder=gaxU16(rom,s.songDataPtr+6);s.volume=gaxU16(rom,s.songDataPtr+8);
    s.patternsPtr=gaxU32(rom,s.songDataPtr+0x0c);s.instrumentTablePtr=gaxU32(rom,s.songDataPtr+0x10);s.waveTablePtr=gaxU32(rom,s.songDataPtr+0x14);s.mixRate=gaxU16(rom,s.songDataPtr+0x18);s.numSfx=rom[gaxOff(rom,s.songDataPtr+0x1a)];
    s.orders.resize(s.channels);
    for(unsigned c=0;c<s.channels;c++){uint32_t type=gaxU32(rom,s.songPtr+16+c*4),op=gaxU32(rom,type+24);auto& v=s.orders[c];v.reserve(s.orderCount);for(unsigned j=0;j<s.orderCount;j++){uint32_t a=op+j*4;GaxOrderEntry e;e.patternOffset=gaxU16(rom,a);e.transpose=int8_t(rom[gaxOff(rom,a+2)]);v.push_back(e);}}
    return s;
}

inline std::vector<GaxRomSong> parseGaxSongs(const Bytes& rom,size_t* tableOffsetOut=nullptr){
    const size_t t=findGaxSongTableOffset(rom);if(tableOffsetOut)*tableOffsetOut=t;std::vector<GaxRomSong> out;out.reserve(19);for(unsigned i=0;i<19;i++)out.push_back(parseGaxSong(rom,t,i));return out;
}
inline int gaxSongId(MusicCue cue){std::string n=musicName(cue);const auto& names=gaxSongNames();for(unsigned i=0;i<names.size();i++)if(n==names[i])return int(i);return -1;}

inline std::vector<GaxWaveInfo> parseWaveTable(const Bytes& rom,uint32_t table,unsigned maxEntries){
    std::vector<GaxWaveInfo> w;w.reserve(maxEntries);for(unsigned i=0;i<maxEntries;i++){uint32_t p=gaxU32(rom,table+i*8),n=gaxU32(rom,table+i*8+4);if(p&&(!gaxPtr(rom,p,n)||n>2*1024*1024))break;w.push_back({p,n});}return w;
}

inline GaxEnvelopeInfo parseEnvelope(const Bytes& rom,uint32_t p){
    GaxEnvelopeInfo e;if(!p||!gaxPtr(rom,p,4))return e;auto o=gaxOff(rom,p,4);e.count=rom[o];e.sustain=rom[o+1];e.loopStart=rom[o+2];e.loopEnd=rom[o+3];if(!e.count||e.count>32||!gaxPtr(rom,p+4,e.count*8))return GaxEnvelopeInfo{};e.points.reserve(e.count);for(unsigned i=0;i<e.count;i++){uint32_t q=p+4+i*8;e.points.push_back({gaxU16(rom,q),gaxS16(rom,q+2),rom[gaxOff(rom,q+4)]});}for(size_t i=1;i<e.points.size();i++)if(e.points[i].pos<e.points[i-1].pos)return GaxEnvelopeInfo{};e.valid=true;return e;
}

inline GaxInstrumentInfo parseInstrument(const Bytes& rom,uint32_t table,unsigned id,unsigned maxCount){
    GaxInstrumentInfo x;if(id>=maxCount||!gaxPtr(rom,table+id*4,4))return x;uint32_t ip=gaxU32(rom,table+id*4);if(!gaxPtr(rom,ip,0x8c))return x;x.ptr=ip;for(unsigned i=0;i<4;i++)x.waveIdx[i]=rom[gaxOff(rom,ip+1+i)];
    x.vibratoDelay=rom[gaxOff(rom,ip+8)];x.vibratoDepth=rom[gaxOff(rom,ip+9)];x.vibratoSpeed=rom[gaxOff(rom,ip+10)];
    for(unsigned i=0;i<4;i++){uint32_t rp=ip+0x0c+i*28;auto& r=x.rows[i];r.sweepEnabled=rom[gaxOff(rom,rp)]!=0;r.pingPong=rom[gaxOff(rom,rp+1)]!=0;r.start=gaxS32(rom,rp+4);r.sweepMin=gaxS32(rom,rp+8);r.sweepMax=gaxS32(rom,rp+12);r.sweepLen=gaxS32(rom,rp+16);r.sweepStep=gaxS32(rom,rp+20);r.sweepRate=gaxU16(rom,rp+24);r.tune=gaxS16(rom,rp+26);}
    x.envelope=parseEnvelope(rom,gaxU32(rom,ip+0x7c));x.cutDelay=rom[gaxOff(rom,ip+0x84)];unsigned seqLen=rom[gaxOff(rom,ip+0x85)];uint32_t seqPtr=gaxU32(rom,ip+0x88);if(seqLen<=64&&(!seqLen||gaxPtr(rom,seqPtr,seqLen*8))){x.seq.reserve(seqLen);for(unsigned i=0;i<seqLen;i++){uint32_t q=seqPtr+i*8;GaxSeqEntryInfo e;e.note=rom[gaxOff(rom,q)];e.fixedPitch=rom[gaxOff(rom,q+1)]!=0;e.wave=rom[gaxOff(rom,q+2)];e.fx[0]=gaxU16(rom,q+4);e.fx[1]=gaxU16(rom,q+6);x.seq.push_back(e);}}
    unsigned row=0;if(!x.seq.empty()&&x.seq[0].wave>=1&&x.seq[0].wave<=4)row=x.seq[0].wave-1;if(!x.waveIdx[row])for(unsigned i=0;i<4;i++)if(x.waveIdx[i]){row=i;break;}x.row=row;x.seqNote=x.seq.empty()?0:x.seq[0].note;x.fixedPitch=!x.seq.empty()&&x.seq[0].fixedPitch;x.tune=x.rows[row].tune;x.start=std::max(0,x.rows[row].start);x.loopStart=std::max(0,x.rows[row].sweepMin);x.loopEnd=std::max(0,x.rows[row].sweepMax);x.valid=std::any_of(x.waveIdx.begin(),x.waveIdx.end(),[](uint8_t v){return v!=0;})&&!x.seq.empty();return x;
}

inline std::vector<GaxInstrumentInfo> parseInstrumentBank(const Bytes& rom,uint32_t table,unsigned count){std::vector<GaxInstrumentInfo> out;out.reserve(count);for(unsigned i=0;i<count;i++)out.push_back(parseInstrument(rom,table,i,count));return out;}

inline uint32_t findGaxSfxSongData(const Bytes& rom,const GaxRomSong& anySong){
    const uint32_t musicInst=anySong.instrumentTablePtr;const size_t hi=gaxOff(rom,musicInst);
    const size_t begin=hi>0x20000?hi-0x20000:0,end=std::min(hi,rom.size()-36);
    for(size_t p=begin;p<=end;p+=4){uint32_t a=u32(rom,p);if(!gaxPtr(rom,a,28))continue;bool same=true;for(unsigned i=1;i<9;i++)if(u32(rom,p+i*4)!=a){same=false;break;}if(!same)continue;
        uint32_t sd=gaxU32(rom,a+24);if(!gaxPtr(rom,sd,28))continue;uint32_t it=gaxU32(rom,sd+0x10),wt=gaxU32(rom,sd+0x14);if(!gaxPtr(rom,it,88*4)||!gaxPtr(rom,wt,88*8))continue;if(gaxU16(rom,sd+8)!=256)continue;return sd;
    }
    return 0;
}
inline std::vector<GaxSfxEntry> parseGaxSfxTable(const Bytes& rom,size_t songTableOffset){
    const size_t p=songTableOffset+19*4;if(p+99*12>rom.size())return {};std::vector<GaxSfxEntry> out;out.reserve(99);for(unsigned i=0;i<99;i++){size_t q=p+i*12;uint32_t slot=u32(rom,q),prio=u32(rom,q+4),vol=u32(rom,q+8);if(slot>=88||vol>0x400)return {};out.push_back({slot,int32_t(prio),vol});}return out;
}
inline int originalSfxId(SfxCue c){
    switch(c){case SfxCue::Navigate:return 0x46;case SfxCue::Confirm:return 0x49;case SfxCue::Cancel:return 0x49;case SfxCue::Jump:return 0x0d;case SfxCue::Spin:return 0x0a;case SfxCue::Wumpa:return 0x08;case SfxCue::Crate:return 0x03;case SfxCue::Life:return 0x07;case SfxCue::Clock:return 0x01;case SfxCue::Shot:return 0x17;case SfxCue::Explosion:return 0x42;case SfxCue::EnemyDown:return 0x14;case SfxCue::BossHit:return 0x43;case SfxCue::LevelClear:return 0x1c;default:return -1;}
}

class GaxLitePlayer {
    static constexpr double GbaHz=59.7275;
    static constexpr double OutRate=44100.0;
    const Bytes* rom_=nullptr;
    std::vector<GaxRomSong> songs_;size_t songTableOffset_=0;
    std::vector<GaxWaveInfo> musicWaves_,sfxWaves_;
    std::vector<GaxInstrumentInfo> musicInstruments_,sfxInstruments_;
    std::vector<GaxSfxEntry> sfxTable_;uint32_t sfxInstTable_=0;
    struct Chan {
        size_t patternOff=0;unsigned rowSkip=0;bool empty=true;
        unsigned instrument=0,row=0,seqPos=0,seqLoopCount=0,cutDelay=0,cutTimer=0;
        unsigned envPos=0,vibratoDelay=0,vibratoPhase=0,retriggerDelay=0,delayedNote=0,delayedInstrument=0;
        int patternPitch=0,instrumentNote=0,pitchStep=0,noteStep=0,vibrato=0,slideTarget=0,slideRate=0;
        int vol15=255,vol17=255,volStep15=0,volStep17=0,envOut=255;
        int transpose=0,sweepPos=0,sweepDir=1;unsigned sweepTimer=0;
        double samplePos=0;int sampleDir=1;uint32_t wavePtr=0,waveLen=0;
        bool fixedPitch=false,released=false,playing=false,sweepOn=false;
        double externalVolume=1.0;
    };
    struct FxVoice {Chan c;bool active=false;int priority=std::numeric_limits<int>::min();unsigned cueId=0;};
    std::vector<Chan> ch_;std::array<FxVoice,3> fx_{};unsigned fxToggle_=0;
    int songId_=-1;unsigned order_=0,row_=0,speedWord_=6,tickCounter_=0;bool started_=false,patternBreak_=false;double tickAccum_=0;

    static int clamp255(int v){return std::clamp(v,0,255);}
    static const std::array<int,64>& vibratoTable(){static const std::array<int,64> t{{0,12,24,37,48,60,70,80,90,98,106,112,117,122,125,126,127,126,125,122,117,112,106,98,90,80,70,60,48,37,24,12,0,-12,-24,-37,-48,-60,-70,-80,-90,-98,-106,-112,-117,-122,-125,-126,-127,-126,-125,-122,-117,-112,-106,-98,-90,-80,-70,-60,-48,-37,-24,-12}};return t;}
    static unsigned speedLow(unsigned w){return w&0xffu;}
    void swapSpeedIfNeeded(){if((speedWord_>>8)&0xffu)speedWord_=((speedWord_&0xffu)<<8)|((speedWord_>>8)&0xffu);}

    const GaxInstrumentInfo* instrument(const std::vector<GaxInstrumentInfo>& bank,unsigned id)const{return id<bank.size()&&bank[id].valid?&bank[id]:nullptr;}
    void stopVoice(Chan& c){c.playing=false;c.wavePtr=0;c.waveLen=0;c.samplePos=0;}
    void releaseNote(Chan& c,const std::vector<GaxInstrumentInfo>& bank){const auto* ins=instrument(bank,c.instrument);c.released=true;if(!ins||!ins->envelope.valid||ins->envelope.sustain==0xff)stopVoice(c);}
    void setPatternNote(Chan& c,unsigned note,const std::vector<GaxInstrumentInfo>& bank){if(note==0)return;if(note==1){releaseNote(c,bank);return;}c.patternPitch=(int(note)-2)<<5;c.released=false;}
    void bindInstrument(Chan& c,unsigned id,const std::vector<GaxInstrumentInfo>& bank){if(!id)return;const auto* ins=instrument(bank,id);if(!ins)return;c.instrument=id;c.envPos=0;c.released=false;c.vibratoDelay=ins->vibratoDelay;c.vibratoPhase=0;c.vibrato=0;c.seqPos=0;c.seqLoopCount=0;c.cutDelay=ins->cutDelay;c.cutTimer=0;c.vol15=255;c.vol17=255;c.volStep15=c.volStep17=0;c.pitchStep=c.noteStep=0;c.slideRate=0;c.slideTarget=0;c.envOut=255;c.fixedPitch=false;c.sweepOn=false;c.row=0;}
    void startRow(Chan& c,const GaxInstrumentInfo& ins,unsigned row,const std::vector<GaxWaveInfo>& waves){if(row>3)return;c.row=row;unsigned wi=ins.waveIdx[row];if(wi>=waves.size()||!waves[wi].ptr||!waves[wi].length){stopVoice(c);return;}const auto& rw=ins.rows[row];const auto& w=waves[wi];c.wavePtr=w.ptr;c.waveLen=w.length;c.samplePos=std::clamp<double>(rw.start,0.0,double(w.length-1));c.sampleDir=1;c.vol17=255;c.sweepOn=rw.sweepEnabled&&rw.sweepMin<rw.sweepMax&&rw.sweepLen>0&&rw.sweepRate>0&&rw.sweepStep>0;c.sweepPos=rw.start;c.sweepTimer=rw.sweepRate;c.sweepDir=(rw.start+rw.sweepLen>rw.sweepMax)?-1:1;c.playing=true;}
    void stepInstrumentSeq(Chan& c,const std::vector<GaxInstrumentInfo>& bank,const std::vector<GaxWaveInfo>& waves){const auto* ins=instrument(bank,c.instrument);if(!ins||c.seqPos>=ins->seq.size()){c.cutDelay=0;return;}const auto& e=ins->seq[c.seqPos++];if(e.note){c.instrumentNote=(int(e.note)-2)<<5;c.fixedPitch=e.fixedPitch;if(e.wave>=1&&e.wave<=4)startRow(c,*ins,e.wave-1,waves);}c.volStep17=0;c.noteStep=0;for(uint16_t raw:e.fx){unsigned cmd=raw>>8,param=raw&0xff;switch(cmd){case 1:c.noteStep=int(param);break;case 2:c.noteStep=-int(param);break;case 5:if(c.seqLoopCount==0||--c.seqLoopCount!=0)c.seqPos=std::min<unsigned>(param,unsigned(ins->seq.size()));break;case 6:if(c.seqLoopCount==0)c.seqLoopCount=param?param+1:0;break;case 10:c.volStep17=int(param);break;case 11:c.volStep17=-int(param);break;case 12:c.vol17=int(param);break;case 15:c.cutDelay=param;break;default:break;}}}
    int tickEnvelope(Chan& c,const std::vector<GaxInstrumentInfo>& bank){const auto* ins=instrument(bank,c.instrument);if(!ins||!ins->envelope.valid)return 255;const auto& e=ins->envelope;unsigned pos=c.envPos++;if(e.sustain!=0xff&&e.sustain<e.points.size()&&!c.released&&pos==e.points[e.sustain].pos)c.envPos=pos;const size_t last=e.points.size()-1;if(pos>=e.points[last].pos){if(e.points[last].value==0&&(e.loopEnd==0xff||e.loopEnd<last))stopVoice(c);c.envPos=pos;}if(!c.released&&e.loopStart!=0xff&&e.loopEnd!=0xff&&e.loopStart<e.points.size()&&e.loopEnd<e.points.size()&&pos==e.points[e.loopEnd].pos)c.envPos=e.points[e.loopStart].pos;size_t i=0;while(i+1<e.points.size()&&e.points[i].pos<pos)++i;if(pos==e.points[i].pos)return int(e.points[i].value);if(i==0)return int(e.points[0].value);const auto& prev=e.points[i-1];int v=int(prev.value)+int((int(pos)-int(prev.pos))*e.points[i].slope/256);return clamp255(v);}
    void tickVibrato(Chan& c,const std::vector<GaxInstrumentInfo>& bank){const auto* ins=instrument(bank,c.instrument);if(!ins||!ins->vibratoDepth){c.vibrato=0;return;}if(c.vibratoDelay)c.vibratoDelay--;else c.vibratoPhase=(c.vibratoPhase+ins->vibratoSpeed)&63u;c.vibrato=(vibratoTable()[c.vibratoPhase]*int(ins->vibratoDepth))>>8;}
    void tickSweep(Chan& c,const std::vector<GaxInstrumentInfo>& bank){if(!c.sweepOn)return;const auto* ins=instrument(bank,c.instrument);if(!ins)return;const auto& r=ins->rows[c.row];if(c.sweepTimer>1){--c.sweepTimer;return;}int old=c.sweepPos;c.sweepTimer=std::max(1u,r.sweepRate);if(c.sweepDir>0){c.sweepPos=old+r.sweepStep;if(c.sweepPos+r.sweepLen>r.sweepMax){c.sweepPos-=r.sweepStep*2;c.sweepDir=-1;}}else{c.sweepPos=old-r.sweepStep;if(c.sweepPos<r.sweepMin){c.sweepPos+=r.sweepStep*2;c.sweepDir=1;}}c.samplePos+=double(c.sweepPos-old);}
    void tickVoice(Chan& c,const std::vector<GaxInstrumentInfo>& bank,const std::vector<GaxWaveInfo>& waves){if(!c.instrument)return;if(c.cutTimer==0){if(c.cutDelay){stepInstrumentSeq(c,bank,waves);c.cutTimer=c.cutDelay?c.cutDelay-1:0;}}else --c.cutTimer;c.envOut=tickEnvelope(c,bank);tickVibrato(c,bank);tickSweep(c,bank);c.vol15=clamp255(c.vol15+c.volStep15);c.vol17=clamp255(c.vol17+c.volStep17);c.patternPitch+=c.pitchStep;c.instrumentNote+=c.noteStep;if(c.slideRate){int before=c.slideTarget-c.patternPitch;c.patternPitch+=c.slideRate;int after=c.slideTarget-c.patternPitch;if((before<0)!=(after<0)||after==0){c.patternPitch=c.slideTarget;c.slideRate=0;c.slideTarget=0;}}}
    double stepFor(const Chan& c,const std::vector<GaxInstrumentInfo>& bank)const{const auto* ins=instrument(bank,c.instrument);if(!ins||c.row>3)return 0.0;int q5=c.instrumentNote+c.vibrato+ins->rows[c.row].tune;if(!c.fixedPitch)q5+=c.patternPitch+c.transpose*32;double semis=double(q5)/32.0-48.0;double hz=8363.0*std::pow(2.0,semis/12.0);return std::clamp(hz/OutRate,0.002,32.0);}
    double voiceSample(Chan& c,const std::vector<GaxInstrumentInfo>& bank){if(!c.playing||!c.wavePtr||!c.waveLen)return 0.0;const auto* ins=instrument(bank,c.instrument);if(!ins||c.row>3){stopVoice(c);return 0.0;}const auto& r=ins->rows[c.row];double lo=0.0,hi=double(c.waveLen);bool loop=false,ping=false,dynamic=false;if(c.sweepOn){lo=std::clamp<double>(c.sweepPos,0.0,double(c.waveLen));hi=std::clamp<double>(c.sweepPos+r.sweepLen,lo+1.0,double(c.waveLen));loop=hi>lo;dynamic=true;}else if(!r.sweepEnabled&&r.sweepMin<r.sweepMax){lo=std::clamp<double>(r.sweepMin,0.0,double(c.waveLen));hi=std::clamp<double>(r.sweepMax,lo+1.0,double(c.waveLen));loop=hi>lo;ping=r.pingPong;}
        if(c.samplePos<0||c.samplePos>=double(c.waveLen)){if(!loop){stopVoice(c);return 0.0;}c.samplePos=std::clamp(c.samplePos,lo,hi-1.0);}if(loop){if(c.sampleDir>0&&c.samplePos>=hi){if(ping&&!dynamic){c.samplePos=std::max(lo,hi-(c.samplePos-hi)-1.0);c.sampleDir=-1;}else c.samplePos=lo+std::fmod(std::max(0.0,c.samplePos-lo),std::max(1.0,hi-lo));}else if(c.sampleDir<0&&c.samplePos<lo){c.samplePos=lo+(lo-c.samplePos);c.sampleDir=1;}}else if(c.samplePos>=double(c.waveLen)||c.samplePos<0){stopVoice(c);return 0.0;}
        unsigned pos=unsigned(std::clamp(c.samplePos,0.0,double(c.waveLen-1)));int8_t v=int8_t((*rom_)[gaxOff(*rom_,c.wavePtr+pos)]);double env=(c.envOut==255)?1.0:double(c.envOut)/256.0;double amp=env*(double(c.vol15)/255.0)*(double(c.vol17)/255.0)*c.externalVolume;double out=double(v)/128.0*amp;double st=stepFor(c,bank);c.samplePos+=st*double(c.sampleDir);return out;}

    void setPattern(const GaxRomSong& s,unsigned ci){Chan& c=ch_[ci];const auto& e=s.orders[ci][order_];uint32_t ptr=s.patternsPtr+e.patternOffset;if(!gaxPtr(*rom_,ptr,1)){c.empty=true;return;}c.patternOff=gaxOff(*rom_,ptr);c.empty=(*rom_)[c.patternOff++]!=0;c.rowSkip=0;c.transpose=e.transpose;}
    void applyPatternEvent(Chan& c,const GaxRomSong& s,unsigned note,unsigned inst,unsigned cmd,unsigned param){c.volStep15=0;c.pitchStep=0;if(cmd==14&&(param>>4)==13){c.retriggerDelay=param&15;c.delayedNote=note;c.delayedInstrument=inst;return;}if(cmd!=3)setPatternNote(c,note,musicInstruments_);if(inst)bindInstrument(c,inst,musicInstruments_);switch(cmd){case 1:c.pitchStep=int(param);break;case 2:c.pitchStep=-int(param);break;case 3:if(param&&note>1){c.slideTarget=(int(note)-2)<<5;c.slideRate=(c.slideTarget-c.patternPitch)/int(param);if(!c.slideRate&&c.slideTarget!=c.patternPitch)c.slideRate=c.slideTarget>c.patternPitch?1:-1;}break;case 7:speedWord_=(param>>4)|((param&15)<<8);if(speedLow(speedWord_))tickCounter_=speedLow(speedWord_)-1;break;case 10:c.volStep15=int(param);break;case 11:c.volStep15=-int(param);break;case 12:c.vol15=int(param);break;case 13:patternBreak_=true;break;case 15:speedWord_=param;if(speedLow(speedWord_))tickCounter_=speedLow(speedWord_)-1;break;default:break;} (void)s;}
    void decodeRow(const GaxRomSong& s,unsigned ci){Chan& c=ch_[ci];c.volStep15=0;c.pitchStep=0;c.retriggerDelay=0;if(c.empty)return;if(c.rowSkip){--c.rowSkip;return;}if(c.patternOff>=rom_->size())return;size_t p=c.patternOff;uint8_t b=(*rom_)[p];if(b==0xff){if(p+1>=rom_->size())return;c.rowSkip=(*rom_)[p+1]?(*rom_)[p+1]-1:0;c.patternOff=p+2;return;}unsigned note=0,inst=0,cmd=0,param=0;if(b&0x80){unsigned packed=b&0x7f;if(!packed){c.patternOff=p+1;return;}if(packed<=121){if(p+1>=rom_->size())return;note=packed;inst=(*rom_)[p+1];c.patternOff=p+2;}else{if(p+2>=rom_->size())return;cmd=(*rom_)[p+1];param=(*rom_)[p+2];c.patternOff=p+3;}}else{if(p+3>=rom_->size())return;note=b;inst=(*rom_)[p+1];cmd=(*rom_)[p+2];param=(*rom_)[p+3];c.patternOff=p+4;}applyPatternEvent(c,s,note,inst,cmd,param);}
    void retrigger(Chan& c,const GaxRomSong& s){if(!c.retriggerDelay)return;if(--c.retriggerDelay==0){unsigned n=c.delayedNote,i=c.delayedInstrument;c.delayedNote=c.delayedInstrument=0;applyPatternEvent(c,s,n,i,0,0);}}
    void tickMusic(){if(songId_<0)return;const GaxRomSong& s=songs_[unsigned(songId_)];bool newRow=false,newOrder=false;if(!started_){started_=true;order_=0;row_=0;speedWord_=6;tickCounter_=5;patternBreak_=false;newRow=newOrder=true;}else if(tickCounter_){--tickCounter_;}else{if(patternBreak_)row_=s.patternRows;else ++row_;patternBreak_=false;swapSpeedIfNeeded();if(row_>=s.patternRows){row_=0;++order_;if(order_>=s.orderCount)order_=std::min(s.loopOrder,s.orderCount-1);newOrder=true;}newRow=true;unsigned sp=speedLow(speedWord_);tickCounter_=sp?sp-1:0;}if(newOrder)for(unsigned c=0;c<s.channels;c++)setPattern(s,c);for(unsigned c=0;c<s.channels;c++){retrigger(ch_[c],s);if(newRow)decodeRow(s,c);tickVoice(ch_[c],musicInstruments_,musicWaves_);}}
    void tickFx(){for(auto& f:fx_)if(f.active){tickVoice(f.c,sfxInstruments_,sfxWaves_);if(!f.c.playing&&f.c.cutDelay==0){f.active=false;f.priority=std::numeric_limits<int>::min();}}}
    void tick(){tickMusic();tickFx();}
    bool startFxVoice(unsigned voice,unsigned cueId,const GaxSfxEntry& e){if(voice>=fx_.size()||e.slotId>=sfxInstruments_.size())return false;auto& f=fx_[voice];if(f.active&&e.priority<f.priority)return false;f=FxVoice{};f.active=true;f.priority=e.priority;f.cueId=cueId;f.c.externalVolume=std::clamp(double(e.baseVolume)/256.0*.72,.04,.85);bindInstrument(f.c,e.slotId,sfxInstruments_);setPatternNote(f.c,8,sfxInstruments_);return f.c.instrument!=0;}
public:
    bool load(const Bytes& rom){try{rom_=&rom;songs_=parseGaxSongs(rom,&songTableOffset_);musicWaves_=parseWaveTable(rom,songs_[0].waveTablePtr,30);musicInstruments_=parseInstrumentBank(rom,songs_[0].instrumentTablePtr,52);sfxTable_=parseGaxSfxTable(rom,songTableOffset_);uint32_t sd=findGaxSfxSongData(rom,songs_[0]);if(sd){sfxInstTable_=gaxU32(rom,sd+0x10);sfxWaves_=parseWaveTable(rom,gaxU32(rom,sd+0x14),88);sfxInstruments_=parseInstrumentBank(rom,sfxInstTable_,88);}return songs_.size()==19&&musicWaves_.size()>=30&&musicInstruments_.size()==52;}catch(...){rom_=nullptr;songs_.clear();musicInstruments_.clear();return false;}}
    bool ready()const{return rom_&&songs_.size()==19&&musicWaves_.size()>=30&&musicInstruments_.size()==52;}
    size_t songTableOffset()const{return songTableOffset_;}const std::vector<GaxRomSong>& songs()const{return songs_;}const std::vector<GaxWaveInfo>& musicWaves()const{return musicWaves_;}const std::vector<GaxSfxEntry>& sfxTable()const{return sfxTable_;}const std::vector<GaxInstrumentInfo>& musicInstruments()const{return musicInstruments_;}const std::vector<GaxInstrumentInfo>& sfxInstruments()const{return sfxInstruments_;}
    void select(MusicCue cue){int id=gaxSongId(cue);if(id==songId_)return;songId_=id;ch_.clear();started_=false;tickAccum_=0;if(id>=0){ch_.resize(songs_[unsigned(id)].channels);for(auto& c:ch_)c.externalVolume=std::clamp(double(songs_[unsigned(id)].volume)/256.0,0.0,1.5);}}
    void playSfx(SfxCue cue){if(!ready()||sfxInstruments_.empty())return;int id=originalSfxId(cue);if(id<0||size_t(id)>=sfxTable_.size())return;const auto& e=sfxTable_[size_t(id)];unsigned v=fxToggle_;if(!startFxVoice(v,unsigned(id),e)){v^=1u;if(!startFxVoice(v,unsigned(id),e))return;}fxToggle_=v^1u;}
    double next(){if(!ready())return 0;tickAccum_+=GbaHz/OutRate;while(tickAccum_>=1.0){tickAccum_-=1.0;tick();}double m=0;unsigned activeMusic=0;for(auto& c:ch_)if(c.playing){m+=voiceSample(c,musicInstruments_);++activeMusic;}if(activeMusic)m/=std::sqrt(double(activeMusic));for(auto& f:fx_)if(f.active){double s=voiceSample(f.c,sfxInstruments_);m+=s;if(!f.c.playing&&f.c.cutDelay==0){f.active=false;f.priority=std::numeric_limits<int>::min();}}return std::clamp(m,-1.0,1.0);}
    unsigned activeSfxVoices()const{unsigned n=0;for(const auto& f:fx_)if(f.active)++n;return n;}
};

}
