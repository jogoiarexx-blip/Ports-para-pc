#include "frontend.hpp"
#include <iostream>
#include <string>
int main(int argc,char** argv){if(argc<2){std::cerr<<"usage: CrashFrontendTool OUT.bmp [map|title]\n";return 2;}std::string mode=argc>2?argv[2]:"map";if(mode=="title"){auto p=crash::renderTitleScreen(true,0);crash::bmp(argv[1],p,240,160);std::cout<<"Frontend title: original ROM sky assets + native menu overlay.\n";return 0;}crash::RunState s;for(int i=0;i<7;i++)s.finishLevel(i);s.lastLevel=7;s.bestTimeFrames[0]=5432;s.bestTimeFrames[3]=4977;auto p=crash::renderLevelMap(s,7);crash::bmp(argv[1],p,240,160);std::cout<<"Frontend warp-room map: original ROM metallic background + level-select platform + portal progression.\n";return 0;}
