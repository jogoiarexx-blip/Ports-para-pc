#pragma once
#include "entities.hpp"
#include <map>
#include <set>
#include <utility>
#include <fstream>
#include <iomanip>
#include <string>

namespace crash {

class RunState {
public:
    struct RoomState {
        EntityWorld::Snapshot world;
        bool checkpointActive=false;
        double checkpointX=0,checkpointY=0;
    };

    std::map<std::pair<int,int>,RoomState> rooms;
    std::set<int> completedLevels;
    std::map<int,unsigned> bestTimeFrames;
    unsigned akuMasks=0,extraLives=0,respawns=0;
    unsigned lastLevel=0;
    bool timeTrialActive=false;
    int timeTrialLevel=-1;
    unsigned timeTrialFrames=0;

    void clear(){rooms.clear();completedLevels.clear();bestTimeFrames.clear();akuMasks=extraLives=respawns=lastLevel=0;timeTrialActive=false;timeTrialLevel=-1;timeTrialFrames=0;}
    void syncGlobal(const EntityWorld& world,const Player& player){akuMasks=world.akuMasks;extraLives=world.extraLives;respawns=player.respawns;}
    void capture(int level,int slot,const EntityWorld& world,const Player& player){syncGlobal(world,player);RoomState r;r.world=world.snapshot();r.checkpointActive=player.checkpointActive;r.checkpointX=player.checkpointX;r.checkpointY=player.checkpointY;rooms[{level,slot}]=std::move(r);}
    bool restore(int level,int slot,EntityWorld& world,Player& player)const{auto it=rooms.find({level,slot});if(it!=rooms.end()){world.restore(it->second.world);player.checkpointActive=it->second.checkpointActive;player.checkpointX=it->second.checkpointX;player.checkpointY=it->second.checkpointY;if(player.checkpointActive)player.placeAt(player.checkpointX,player.checkpointY);}world.akuMasks=akuMasks;world.extraLives=extraLives;player.respawns=respawns;world.bind(player);return it!=rooms.end();}

    bool clockAvailable(int level)const{return completedLevels.count(level)!=0 && !(timeTrialActive&&timeTrialLevel==level);}
    void startTimeTrial(int level){timeTrialActive=true;timeTrialLevel=level;timeTrialFrames=0;}
    void restartTimeTrial(int level){if(timeTrialActive&&timeTrialLevel==level)timeTrialFrames=0;}
    void tickTimeTrial(){if(timeTrialActive)++timeTrialFrames;}
    void finishLevel(int level){completedLevels.insert(level);if(timeTrialActive&&timeTrialLevel==level){auto it=bestTimeFrames.find(level);if(it==bestTimeFrames.end()||timeTrialFrames<it->second)bestTimeFrames[level]=timeTrialFrames;timeTrialActive=false;timeTrialLevel=-1;timeTrialFrames=0;}}
    unsigned bestTime(int level)const{auto it=bestTimeFrames.find(level);return it==bestTimeFrames.end()?0:it->second;}


    bool levelUnlocked(int level)const{
        if(level<=0)return true;
        return completedLevels.count(level-1)!=0;
    }
    unsigned highestUnlocked()const{
        unsigned n=0;while(n<24&&levelUnlocked(int(n+1)))++n;return n;
    }

    bool saveFile(const std::string& path)const{
        std::ofstream f(path,std::ios::binary);if(!f)return false;
        f<<std::setprecision(17);
        f<<"CRASH_NATIVE_SAVE 1\n";
        f<<"GLOBAL "<<akuMasks<<' '<<extraLives<<' '<<respawns<<' '<<lastLevel<<"\n";
        f<<"TT "<<(timeTrialActive?1:0)<<' '<<timeTrialLevel<<' '<<timeTrialFrames<<"\n";
        f<<"COMPLETED "<<completedLevels.size();for(int v:completedLevels)f<<' '<<v;f<<"\n";
        f<<"BEST "<<bestTimeFrames.size();for(const auto& q:bestTimeFrames)f<<' '<<q.first<<' '<<q.second;f<<"\n";
        f<<"ROOMS "<<rooms.size()<<"\n";
        for(const auto& it:rooms){const auto& key=it.first;const auto& r=it.second;const auto& s=r.world;
            f<<"ROOM "<<key.first<<' '<<key.second<<' '<<(r.checkpointActive?1:0)<<' '<<r.checkpointX<<' '<<r.checkpointY<<' '<<s.wumpaCollected<<' '<<s.crateBroken<<' '<<s.checkpointHits<<' '<<s.hazardHits<<' '<<s.carriedTicks<<' '<<s.ticks<<' '<<s.enemyKills<<' '<<s.plantAttacks<<' '<<s.gemsCollected<<' '<<(s.exitMarkerArmed?1:0)<<' '<<s.items.size()<<"\n";
            for(const auto& e:s.items){const auto& m=e.mover;
                f<<"E "<<e.source.id<<' '<<e.source.type<<' '<<e.source.x<<' '<<e.source.y<<' '<<e.source.param<<' '<<e.source.column
                 <<' '<<(e.active?1:0)<<' '<<e.stateTicks<<' '<<e.countdown<<' '<<(e.triggered?1:0)<<' '<<(e.dying?1:0)<<' '<<(e.facingLeft?1:0)<<' '<<(e.attacking?1:0)<<' '<<(e.attackDamageDone?1:0)
                 <<' '<<e.hits<<' '<<e.triggerCap<<' '<<e.deathTicks<<' '<<e.attackTicks<<' '<<e.x<<' '<<e.y<<' '<<e.prevX<<' '<<e.prevY<<' '<<e.patrolOrigin<<' '<<e.patrolRange<<' '<<e.patrolSpeed
                 <<' '<<(m.enabled?1:0)<<' '<<m.kind<<' '<<m.inputDistX<<' '<<m.inputDistY<<' '<<m.rangeX<<' '<<m.rangeY<<' '<<m.travelledX<<' '<<m.travelledY<<' '<<(m.dirX?1:0)<<' '<<(m.dirY?1:0)
                 <<' '<<m.xQ8<<' '<<m.yQ8<<' '<<m.vxQ8<<' '<<m.vyQ8<<' '<<m.targetVxQ8<<' '<<m.targetVyQ8<<' '<<m.lastX<<' '<<m.lastY<<' '<<(m.active?1:0)<<' '<<(m.falling?1:0)<<' '<<m.specialTimer<<' '<<m.holdUntil<<"\n";
            }
        }
        f<<"END\n";return bool(f);
    }

    bool loadFile(const std::string& path){
        std::ifstream f(path,std::ios::binary);if(!f)return false;RunState tmp;std::string tag;unsigned version=0;if(!(f>>tag>>version)||tag!="CRASH_NATIVE_SAVE"||version!=1)return false;
        unsigned b=0;if(!(f>>tag)||tag!="GLOBAL"||!(f>>tmp.akuMasks>>tmp.extraLives>>tmp.respawns>>tmp.lastLevel))return false;
        if(!(f>>tag)||tag!="TT"||!(f>>b>>tmp.timeTrialLevel>>tmp.timeTrialFrames))return false;
        tmp.timeTrialActive=b!=0;
        size_t n=0;if(!(f>>tag>>n)||tag!="COMPLETED")return false;for(size_t i=0;i<n;i++){int v;if(!(f>>v))return false;tmp.completedLevels.insert(v);}
        if(!(f>>tag>>n)||tag!="BEST")return false;
        for(size_t i=0;i<n;i++){int k;unsigned v;if(!(f>>k>>v))return false;tmp.bestTimeFrames[k]=v;}
        if(!(f>>tag>>n)||tag!="ROOMS")return false;
        for(size_t ri=0;ri<n;ri++){int level,slot;unsigned cp,exitFlag;RoomState r;size_t count=0;if(!(f>>tag)||tag!="ROOM")return false;if(!(f>>level>>slot>>cp>>r.checkpointX>>r.checkpointY>>r.world.wumpaCollected>>r.world.crateBroken>>r.world.checkpointHits>>r.world.hazardHits>>r.world.carriedTicks>>r.world.ticks>>r.world.enemyKills>>r.world.plantAttacks>>r.world.gemsCollected>>exitFlag>>count))return false;r.checkpointActive=cp!=0;r.world.exitMarkerArmed=exitFlag!=0;r.world.items.reserve(count);
            for(size_t ei=0;ei<count;ei++){RuntimeEntity e;MoverState& m=e.mover;unsigned active,triggered,dying,facing,attacking,damage,menabled,mdirx,mdiry,mactive,mfalling;if(!(f>>tag)||tag!="E")return false;if(!(f>>e.source.id>>e.source.type>>e.source.x>>e.source.y>>e.source.param>>e.source.column>>active>>e.stateTicks>>e.countdown>>triggered>>dying>>facing>>attacking>>damage>>e.hits>>e.triggerCap>>e.deathTicks>>e.attackTicks>>e.x>>e.y>>e.prevX>>e.prevY>>e.patrolOrigin>>e.patrolRange>>e.patrolSpeed>>menabled>>m.kind>>m.inputDistX>>m.inputDistY>>m.rangeX>>m.rangeY>>m.travelledX>>m.travelledY>>mdirx>>mdiry>>m.xQ8>>m.yQ8>>m.vxQ8>>m.vyQ8>>m.targetVxQ8>>m.targetVyQ8>>m.lastX>>m.lastY>>mactive>>mfalling>>m.specialTimer>>m.holdUntil))return false;e.active=active!=0;e.triggered=triggered!=0;e.dying=dying!=0;e.facingLeft=facing!=0;e.attacking=attacking!=0;e.attackDamageDone=damage!=0;m.enabled=menabled!=0;m.dirX=mdirx!=0;m.dirY=mdiry!=0;m.active=mactive!=0;m.falling=mfalling!=0;r.world.items.push_back(e);}
            tmp.rooms[{level,slot}]=std::move(r);
        }
        if(!(f>>tag)||tag!="END")return false;
        *this=std::move(tmp);return true;
    }

    unsigned totalWumpa()const{unsigned n=0;for(const auto& r:rooms)n+=r.second.world.wumpaCollected;return n;}
    unsigned totalCrates()const{unsigned n=0;for(const auto& r:rooms)n+=r.second.world.crateBroken;return n;}
    unsigned totalEnemies()const{unsigned n=0;for(const auto& r:rooms)n+=r.second.world.enemyKills;return n;}
    unsigned totalGems()const{unsigned n=0;for(const auto& r:rooms)n+=r.second.world.gemsCollected;return n;}
};

}
