# Crash Bandicoot: The Huge Adventure — port nativo PC, v0.21.0

A v0.21.0 continua o runtime C++ nativo para PC. A ROM USA ACQE é usada como fonte de dados e assets; o runtime não executa o código ARM do GBA e não funciona como emulador.

## O que mudou nesta versão

O alvo principal foi aproximar o replayer nativo do comportamento real do **GAX Sound Engine 2.01D** e substituir partes do frontend recriado por gráficos originais já extraídos da ROM.

### Áudio GAX2 avançado

A v0.20 já reproduzia patterns, order lists, instrumentos e PCM da ROM. A v0.21 acrescenta ao replayer:

- envelopes com sustain, loop e interpolação;
- vibrato + vibrato delay;
- pitch slide e note slide;
- tone portamento;
- volume slide/set;
- note delay `E-Dx`;
- instrument sequence interna com FX e loops;
- sample loop e ping-pong;
- sweep dinâmico de posição;
- estado separado das vozes SFX com prioridade básica.

Na ROM testada o parser valida **19 músicas, 52 instrumentos musicais, 29 waves PCM úteis, 99 rotas de SFX e 88 instrumentos no banco SFX**. Foram encontrados também 52 envelopes válidos, 7 instrumentos com vibrato, 6 rows com sweep, 9 rows ping-pong e 36 comandos de sequence FX.

O sintetizador antigo continua disponível como fallback de segurança quando os dados GAX não validam.

### Importante sobre fidelidade do áudio

Este é um avanço grande, mas ainda **não é o mixer Shin'en bit-exact**. A lógica musical principal agora segue muito mais da estrutura real do GAX2, porém o port ainda usa seu próprio resampler/mapeamento de frequência. A próxima camada forte é portar a tabela de período, resampling/mixagem, echo/DSP e detalhes restantes do voice stealing original.

## SFX

O port lê a tabela real de 99 SFX e o banco separado de instrumentos/waves. Os cues já mapeados usam as amostras originais e o runtime agora mantém vozes SFX independentes da música, inclusive quando nenhuma faixa está tocando.

## Menu e Warp Room com assets originais

A v0.21 passa a usar diretamente no frontend:

- céu/clouds original do menu;
- fundo metálico original do Warp Room/pause;
- plataforma original do level select;
- badge original da tela de título como detalhe visual.

Os portais, nomes das fases, boss, bloqueio/desbloqueio e progresso continuam sendo desenhados pelo runtime nativo por cima desses assets. Se os arquivos originais estiverem ausentes, o frontend usa o renderer anterior como fallback.

No mapa atual existem quatro Warp Rooms principais, cada uma organizada em 5 fases + boss, e o portal secreto para a fase 25.

## IA / callbacks

A família jetpack continua usando `JetAiProfile`, com caminhos separados para cannon plane, tracker/bomber, depth runner, balloon orbit, parachute, rocket, airship e ring. As actor-categories 0/1/2 continuam com callbacks explícitos para pickups, caixas, checkpoint, vida, freeze e hazards.

## Controles

| Contexto | Teclas |
|---|---|
| Menu | Cima/Baixo + Enter; Esc sai |
| Warp Room | Esquerda/Direita = portal; Cima/Baixo = Warp Room; Enter = jogar; Esc = menu |
| Sala normal | A/D ou setas; Espaço/Z = salto; X/K = giro |
| Polar | A/D ou setas; Espaço/Z = salto |
| Jetpack | A/D/W/S; Espaço/Z = tiro; Q/E = roll |
| Geral | P pausa; R reinicia; F10 salva; F11 tela cheia; C debug |
| Desenvolvimento | F5 recarrega PNG; F6 escala; F7/F8 troca fase; H alterna PNG/ROM |

## Ferramentas

- `CrashGaxTool [ROM]`: valida catálogo GAX2, banks, waves, envelopes, vibrato, sweep/ping-pong e sequence FX.
- `CrashFrontendTool SAIDA.bmp map`: preview do Warp Room.
- `CrashFrontendTool SAIDA.bmp title`: preview do menu/título.
- `CrashCategoryTool`, `CrashAirshipTool`, `CrashHovercraftTool`: validação das actor-categories.
- `CrashGameplayTool`, `CrashMoverTool`, `CrashEnemyTool`, `CrashPlantTool`, `CrashRouteTool`, `CrashHDTool`: ferramentas já existentes.

## Compilar no Windows

Execute `COMPILAR-WINDOWS.cmd`. O script procura Visual Studio 2022 / Build Tools, compila `CrashNative.exe`, linka `winmm.lib`, compila as ferramentas e executa as oito suítes de teste.

Este ambiente de entrega não possui MSVC/MinGW Windows. Por isso o EXE final deve ser gerado no seu PC com o script. O core independente de Win32 foi compilado e testado aqui com GCC, incluindo `-Werror` e sanitizadores.

## ROM esperada

USA ACQE — SHA-256:
`6be639d1db218ca2bf2b1ff0ee0867334404cead5fb6684af4870d4644a15635`

## Próximos alvos fortes

- aproximar o mixer do GAX2 original usando a tabela de períodos e resampling mais fiel;
- reproduzir echo/DSP e voice stealing com maior precisão;
- confirmar/remover os últimos fallbacks de SFX;
- integrar mais sprites/elementos originais do title/menu/portais;
- continuar convertendo callbacks genéricos para comportamento específico por kind;
- refinar ataques/efeitos de airship e hovercraft.

## Validação v0.21.0

- 8/8 suítes PASS;
- strict/Werror PASS;
- ASan + UBSan em Audio/Frontend/Category PASS;
- áudio avançado com envelopes, vibrato, portamento/slides, sequence FX e sweep/ping-pong;
- frontend usando assets originais de céu, fundo metálico e plataforma;
- previews em `reports/v021-warp-room-preview.png` e `reports/v021-title-preview.png`;
- relatório GAX em `reports/v021-gax-audio.txt`.
