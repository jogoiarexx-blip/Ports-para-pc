#include "../src/category0.hpp"
#include <cassert>
#include <cmath>
#include <iostream>
#include <algorithm>
#include <set>

int main(){try{using namespace crash;
    GameData data(read("input/crash.gba"));
    Category0Data c0(data,0),c1(data,1),c2(data,2),c3(data,3),c4(data,4),c5(data,5);
    assert(c0.bgCols==19&&c0.bgRows==13&&c0.backgroundFrames==60&&c0.eventCount==164&&c0.routeEndThreshold==2336&&c0.spriteAsset.size()==213064);
    assert(c1.type==0&&c1.background==c0.background&&c1.animTable==c0.animTable&&c1.spriteSheet==c0.spriteSheet&&c1.eventCount==175&&c1.routeEndThreshold==2556&&c1.positionOffsetFlag==3);
    assert(c2.type==0&&c2.background==c0.background&&c2.animTable==c0.animTable&&c2.spriteSheet==c0.spriteSheet&&c2.eventCount==171&&c2.routeEndThreshold==2676&&c2.positionOffsetFlag==5);
    assert(c3.type==1&&c3.bgCols==38&&c3.bgRows==10&&c3.backgroundFrames==21&&c3.eventCount==121&&c3.routeEndThreshold==5236&&c3.pictureCols==38&&c3.pictureRows==16&&c3.pictureTiles==357&&c3.spriteAsset.size()==207124);
    assert(c4.type==1&&c4.background==c3.background&&c4.animTable==c3.animTable&&c4.spriteSheet==c3.spriteSheet&&c4.eventCount==230&&c4.routeEndThreshold==6856&&c4.pictureCols==38&&c4.pictureRows==16&&c4.pictureTiles==237&&c4.spriteAsset.size()==207124);
    assert(c5.type==1&&c5.background==c3.background&&c5.animTable==c3.animTable&&c5.spriteSheet==c3.spriteSheet&&c5.eventCount==295&&c5.routeEndThreshold==8116&&c5.pictureCols==38&&c5.pictureRows==16&&c5.pictureTiles==374&&c5.spriteAsset.size()==207124);
    auto jpbox=c3.actorBox(0);assert(jpbox.x==-10&&jpbox.y==-20&&jpbox.z==-1&&jpbox.w==20&&jpbox.h==42&&jpbox.d==3&&std::abs(c3.actorBaseDepth(0)-28.0)<1e-9);
    auto jetA0=c3.animation(0,0),jetA1=c3.animation(0,1),jetA2=c3.animation(0,2);assert(jetA0.duration==64&&jetA0.loopThreshold==18&&jetA1.duration==85&&jetA2.duration==85);
    auto a=c0.animation(0,0);assert(a.duration==128&&a.frameIndex==0&&a.loopThreshold==20&&a.loopBase==0);
    auto pbox=c0.actorBox(0),crateBox=c0.actorBox(1),fenceBox=c0.actorBox(23),logBox=c0.actorBox(13);assert(pbox.x==-10&&pbox.y==-20&&pbox.w==20&&pbox.h==44&&pbox.d==3);assert(crateBox.w==20&&crateBox.h==20&&crateBox.d==3);assert(fenceBox.x==-24&&fenceBox.y==-25&&fenceBox.w==48&&fenceBox.h==40);assert(logBox.x==-30&&logBox.w==120&&logBox.h==20&&std::abs(c0.actorSpawnX(13)+30.0)<1e-9&&std::abs(c0.actorSpawnY(13)+4.0)<1e-9);
    auto f=c0.rleFrame(c0.actorFrameAddress(0,0));assert(f.width==64&&f.height==64&&std::count_if(f.pixels.begin(),f.pixels.end(),[](uint32_t p){return (p>>24)!=0;})>300);
    auto bg=c0.backgroundLogical(0);assert(bg.size()==240u*160u);auto mm=std::minmax_element(bg.begin(),bg.end());assert(*mm.first!=*mm.second);
    auto e1=c0.event(1);assert(e1.threshold==18&&e1.variantA==28&&e1.variantC==28&&e1.offsetX==30&&e1.offsetY==54);assert(c0.eventDepth(0)==18&&c0.eventDepth(c0.eventCount-1)==2336);
    // The original first-pass selector is non-zero, so type-0 categories use variantC; time trial uses variantB plus the original fold rules.
    assert(c0.selectedKind(c0.event(0))==3&&c0.selectedKind(c0.event(0),true)==1);assert(Category0Data::timeTrialFold(11)==0&&Category0Data::timeTrialFold(35)==1);
    std::set<unsigned> kinds0,kinds1,kinds2;for(unsigned i=0;i<c0.eventCount;i++){unsigned k=c0.selectedKind(c0.event(i));if(c0.spawnableKind(k))kinds0.insert(k);}for(unsigned i=0;i<c1.eventCount;i++){unsigned k=c1.selectedKind(c1.event(i));if(c1.spawnableKind(k))kinds1.insert(k);}for(unsigned i=0;i<c2.eventCount;i++){unsigned k=c2.selectedKind(c2.event(i));if(c2.spawnableKind(k))kinds2.insert(k);}
    assert(kinds0==std::set<unsigned>({1,3,4,8,9,10,11,22,23,24,25,28,29,30,35}));
    assert(kinds1.count(1)&&kinds1.count(11)&&kinds1.count(12)&&kinds1.count(23)&&kinds1.count(24)&&kinds1.count(31)&&!kinds1.count(36)&&!kinds1.count(37));
    assert(kinds2==std::set<unsigned>({1,3,4,8,9,11,12,13,22,23,24,25,28,30,31}));
    std::set<unsigned> kinds3,kinds4,kinds5;for(unsigned i=0;i<c3.eventCount;i++){unsigned k=c3.selectedKind(c3.event(i));if(c3.spawnableKind(k))kinds3.insert(k);}for(unsigned i=0;i<c4.eventCount;i++){unsigned k=c4.selectedKind(c4.event(i));if(c4.spawnableKind(k))kinds4.insert(k);}for(unsigned i=0;i<c5.eventCount;i++){unsigned k=c5.selectedKind(c5.event(i));if(c5.spawnableKind(k))kinds5.insert(k);}
    assert(kinds3==std::set<unsigned>({1,4,5,8,9,16,17,19,20,21,22,23,27,29,31}));
    assert(kinds4==std::set<unsigned>({1,4,5,8,9,16,17,18,19,20,21,22,23,27,28,29,31}));
    assert(kinds5==std::set<unsigned>({1,4,5,6,8,9,17,18,19,20,21,22,23,27,28,29,31}));
    auto jetCrate=c3.actorBox(20),jetRing=c3.actorBox(31);assert(jetCrate.w==22&&jetCrate.h==22&&jetCrate.d==4&&jetRing.w==50&&jetRing.h==38&&std::abs(c3.actorSpawnX(31)+28.0)<1e-9);
    for(unsigned kind:kinds0){auto ref=c0.actorFrameReference(kind,c0.animation(kind,0).frameIndex);assert(ref<c0.spriteAsset.size());auto q=c0.actorAnimationFrame(kind,0,0);assert(q.width>=16&&q.height>=16&&q.width<=128&&q.height<=128);}
    Category0Stage s(data,0);const double d=double(0x2cd)/256.0;s.step(false,true,false);assert(std::abs(s.x-d)<1e-9);for(int i=0;i<100;i++)s.step(false,true,false);assert(std::abs(s.x-50.0)<1e-9);
    s.step(false,false,true);assert(!s.grounded&&s.jumpY<0);for(int i=0;i<80;i++)s.step(false,false,false);assert(s.grounded&&std::abs(s.jumpY)<1e-9);
    // Exact ROM AABB collision: place the rider on the first Wumpa's true depth/position.
    Category0Stage exact(data,0);unsigned wi=0;while(wi<exact.rom.eventCount&&exact.kind(wi)!=11)++wi;assert(wi<exact.rom.eventCount);exact.scroll=exact.rom.eventDepth(wi);auto wp=exact.project(wi);exact.x=std::clamp(double(wp.sx-120),-50.0,50.0);exact.handleCollisions();assert(exact.wumpa==1&&exact.consumed[wi]);
    // Category 2 adds kind 13; its 120x20 ROM box is a real hazard and uses the per-kind spawn offset.
    Category0Stage hz(data,2);unsigned hi=0;while(hi<hz.rom.eventCount&&hz.kind(hi)!=13)++hi;assert(hi<hz.rom.eventCount);hz.scroll=hz.rom.eventDepth(hi);auto hp=hz.project(hi);hz.x=std::clamp(double(hp.sx-120),-50.0,50.0);unsigned beforeLives=hz.lives;hz.handleCollisions();assert(hz.hazards==1&&hz.lives+1==beforeLives&&hz.consumed[hi]);
    // Electric fence kind 23 follows the original idle -> used animation -> destroy state instead of vanishing instantly.
    Category0Stage fence(data,0);unsigned fi=0;while(fi<fence.rom.eventCount&&fence.kind(fi)!=23)++fi;assert(fi<fence.rom.eventCount);fence.scroll=fence.rom.eventDepth(fi);auto fp=fence.project(fi);fence.x=std::clamp(double(fp.sx-120),-50.0,50.0);fence.handleCollisions();assert(fence.eventAnim[fi]==1&&!fence.consumed[fi]);for(unsigned t=0;t<=fence.rom.animationTicks(23,1);t++)fence.updatePolarStates();assert(fence.consumed[fi]);
    assert(Category0Stage::polarCallback(11)==Category0Stage::PolarCallback::Wumpa);assert(Category0Stage::polarCallback(3)==Category0Stage::PolarCallback::Checkpoint);assert(Category0Stage::polarCallback(23)==Category0Stage::PolarCallback::HazardAnimate);assert(Category0Stage::polarCallback(13)==Category0Stage::PolarCallback::HazardConsume);
    assert(Category0Stage::jetHitPoints(1)==4&&Category0Stage::jetHitPoints(17)==45&&Category0Stage::jetHitPoints(31)==100000);assert(Category0Stage::jetContactDamage(27)==20);assert(Category0Stage::jetAiProfile(1)==Category0Stage::JetAiProfile::CannonPlane);assert(Category0Stage::jetAiProfile(7)==Category0Stage::JetAiProfile::Tracker);assert(Category0Stage::jetAiProfile(20)==Category0Stage::JetAiProfile::BalloonOrbit);
    Category0Stage s1(data,1);assert(s1.rom.categoryIndex==1&&s1.rom.eventCount==175);s1.setTimeTrialVariant(true);s1.collisions=false;for(unsigned i=0;i<s1.rom.eventCount;i++){unsigned k=s1.kind(i);assert(k<64);}
    unsigned guard=0;while(!s1.complete&&guard<6000){s1.step(false,false,false);++guard;}assert(s1.complete&&std::abs(s1.scroll-2556.0)<1e-9&&guard<6000);
    Category0Stage s2(data,2);s2.collisions=false;unsigned guard2=0;while(!s2.complete&&guard2<7000){s2.step(false,false,false);++guard2;}assert(s2.complete&&std::abs(s2.scroll-2676.0)<1e-9&&guard2<7000);
    Category0Stage jet(data,3);jet.collisions=false;assert(jet.jetpack()&&jet.hp==100);jet.step(false,true,false);assert(std::abs(jet.jetVx-.25)<1e-9&&std::abs(jet.x-.25)<1e-9);jet.step(false,false,false,true,false);assert(jet.jetVy<0);unsigned shots=jet.shotsFired;jet.step(false,false,true);assert(jet.shotsFired==shots+1&&!jet.shots.empty());for(int t=0;t<20;t++)jet.step(false,false,false);jet.step(false,false,false,false,false,true,false);assert(jet.rollTicks>0&&jet.rollDir==-1);
    unsigned moving=0;while(moving<jet.rom.eventCount&&jet.kind(moving)!=8)++moving;assert(moving<jet.rom.eventCount);jet.scroll=std::max(0.0,double(jet.rom.eventDepth(moving))-160.0);jet.updateJetpackSpawns();auto m0=jet.eventWorld(moving);for(int t=0;t<24;t++)jet.step(false,false,false);auto m1=jet.eventWorld(moving);assert(std::abs(m1[0]-m0[0])>1.0||std::abs(m1[1]-m0[1])>1.0);
    // Close-range bomber state follows the player by 1/32 per native update once depth <= 0x35ff (~54 px).
    Category0Stage closeBomber(data,4);unsigned bi=0;while(bi<closeBomber.rom.eventCount&&closeBomber.kind(bi)!=8)++bi;assert(bi<closeBomber.rom.eventCount);closeBomber.scroll=double(closeBomber.rom.eventDepth(bi))-50.0;closeBomber.x=100;closeBomber.y=40;closeBomber.updateJetpackSpawns();auto b0=closeBomber.eventWorld(bi);closeBomber.updateJetpackActors();auto b1=closeBomber.eventWorld(bi);assert(std::abs(100.0-b1[0])<std::abs(100.0-b0[0])&&std::abs(40.0-b1[1])<std::abs(40.0-b0[1]));
    // Balloon crates now use the original 17x30 sine orbit in world space.
    unsigned ci=0;while(ci<closeBomber.rom.eventCount&&closeBomber.kind(ci)!=20)++ci;assert(ci<closeBomber.rom.eventCount);closeBomber.scroll=double(closeBomber.rom.eventDepth(ci))-120.0;closeBomber.updateJetpackSpawns();auto c0p=closeBomber.eventWorld(ci);for(int t=0;t<20;t++){++closeBomber.ticks;closeBomber.updateJetpackActors();}auto c1p=closeBomber.eventWorld(ci);assert(std::abs(c1p[0]-c0p[0])>1.0||std::abs(c1p[1]-c0p[1])>1.0);
    // Plane kind 1 has 4 HP and fires native-style cannonballs with 20/60 frame cooldowns when the player is in front.
    Category0Stage plane(data,4);unsigned pi=0;while(pi<plane.rom.eventCount&&plane.kind(pi)!=1)++pi;assert(pi<plane.rom.eventCount&&plane.eventHp[pi]==4);plane.scroll=double(plane.rom.eventDepth(pi))-60.0;plane.updateJetpackSpawns();auto pp=plane.eventWorld(pi);plane.x=pp[0];plane.y=pp[1];plane.updateJetpackActors();assert(plane.enemyShotsFired==1&&plane.eventCooldown[pi]==20);for(int t=0;t<20;t++){++plane.ticks;plane.updateJetpackActors();}assert(plane.enemyShotsFired>=2);
    // Ring kind 31 is a pass-through guide, not a fake checkpoint: first overlap latches one pass and pulls the player toward its center.
    Category0Stage ring(data,4);unsigned ri=0;while(ri<ring.rom.eventCount&&ring.kind(ri)!=31)++ri;assert(ri<ring.rom.eventCount);ring.scroll=double(ring.rom.eventDepth(ri))-28.0;ring.updateJetpackSpawns();auto rp=ring.eventWorld(ri);ring.x=rp[0]-2;ring.y=rp[1];unsigned cp0=ring.checkpointHits;ring.handleJetpackCollisions();assert(ring.ringPasses==1&&ring.checkpointHits==cp0&&!ring.consumed[ri]);
    jet.collisions=false;unsigned guard3=0;while(!jet.complete&&guard3<9000){jet.step(false,false,false);++guard3;}assert(jet.complete&&std::abs(jet.scroll-5236.0)<1e-9&&guard3<9000);

    // Category 5 / level 18 uses the same jetpack family but a distinct 295-event route and full airship state machine.
    Category0Stage boss(data,5);unsigned ai=0;while(ai<boss.rom.eventCount&&boss.kind(ai)!=17)++ai;assert(ai<boss.rom.eventCount&&boss.eventHp[ai]==45);
    boss.scroll=double(boss.rom.eventDepth(ai))-160.0;boss.updateJetpackSpawns();assert(boss.eventSpawnTick[ai]>=0&&boss.eventState[ai]==1);
    boss.scroll=boss.eventZ[ai]-120.0;boss.updateJetpackActors();assert(boss.eventState[ai]==2);
    boss.eventCooldown[ai]=0;unsigned ap0=boss.airshipProjectilesFired;boss.updateJetpackActors();assert(boss.airshipProjectilesFired==ap0+1&&!boss.enemyShots.empty());
    boss.scroll=boss.eventZ[ai]-40.0;boss.updateJetpackActors();assert(boss.eventState[ai]==3);
    boss.eventHp[ai]=1;auto aw=boss.eventWorld(ai);auto ab=boss.jetBox(17);Category0Stage::JetShot hit;hit.x=aw[0]+ab.x+1;hit.y=aw[1]+ab.y+1;hit.z=aw[2]+ab.z+1;hit.vx=hit.vy=hit.vz=0;boss.shots.push_back(hit);boss.stepShots();assert(boss.eventState[ai]==4&&boss.eventHp[ai]==0&&!boss.consumed[ai]);
    for(int t=0;t<171;t++){boss.updateAirship(ai,17);}assert(boss.eventState[ai]==5);boss.eventY[ai]=188.0;boss.updateAirship(ai,17);assert(boss.consumed[ai]&&boss.airshipsDefeated==1);
    boss.collisions=false;Category0Stage cat5run(data,5);cat5run.collisions=false;unsigned guard5=0;while(!cat5run.complete&&guard5<14000){cat5run.step(false,false,false);++guard5;}assert(cat5run.complete&&std::abs(cat5run.scroll-8116.0)<1e-9&&guard5<14000);

    // Category 6 / level 22 is the type-2 hovercraft boss route. It has no normal route-end sentinel:
    // kind 10 creates the singleton and the run ends only after all four attached parts are destroyed and it falls away.
    Category0Stage hover(data,6);assert(hover.rom.type==2&&hover.rom.eventCount==1&&hover.rom.routeEndThreshold==0&&hover.kind(0)==10&&hover.rom.eventDepth(0)==712);
    auto hf=hover.rom.hovercraftFrame();assert(hf.width==128&&hf.height==80);
    hover.scroll=544.0;hover.updateJetpackSpawns();assert(hover.hovercraftSpawned&&hover.hovercraftState==1&&hover.hovercraftPartsLeft==4);
    assert(hover.hoverParts[0].hp==15&&hover.hoverParts[1].hp==25&&hover.hoverParts[2].hp==24&&hover.hoverParts[3].hp==24);
    hover.scroll=hover.hovercraftZ-120.0;hover.updateHovercraft();assert(hover.hovercraftState==2);
    hover.scroll=hover.hovercraftZ-70.0;hover.updateHovercraft();assert(hover.hoverParts[0].active);
    for(unsigned p=0;p<4;p++){hover.hoverParts[p].hp=1;hover.hoverParts[p].active=true;auto pos=hover.hoverPartWorld(p);auto box=hover.rom.actorBox(hover.hoverParts[p].kind);Category0Stage::JetShot s;s.x=pos[0]+box.x+1;s.y=pos[1]+box.y+1;s.z=pos[2]+box.z+1;s.vx=s.vy=s.vz=0;hover.shots.push_back(s);hover.stepHovercraftShots();hover.shots.clear();}
    assert(hover.hovercraftPartsLeft==0&&hover.hovercraftPartsDestroyed==4&&hover.hovercraftState==5&&!hover.complete);
    hover.hovercraftY=75.5;hover.updateHovercraft();assert(hover.hovercraftGone&&hover.complete);

    auto route11=data.roomRoute(10);assert(route11.size()==3&&route11[1].kind==3&&route11[1].category==2);
    auto route7=data.roomRoute(6);assert(route7.size()==1&&route7[0].kind==3&&route7[0].category==3);
    auto route15=data.roomRoute(14);assert(route15.size()==1&&route15[0].kind==3&&route15[0].category==4);auto route18=data.roomRoute(17);assert(route18.size()==1&&route18[0].kind==3&&route18[0].category==5);auto route22=data.roomRoute(21);assert(route22.size()==1&&route22[0].kind==3&&route22[0].category==6);
    auto img=s1.renderLogical(true);auto img2=s2.renderLogical(true);auto img3=jet.renderLogical(true);Category0Stage jet4(data,4);auto img4=jet4.renderLogical(true);Category0Stage jet5(data,5);auto img5=jet5.renderLogical(true);Category0Stage hoverRender(data,6);hoverRender.scroll=544;hoverRender.updateJetpackSpawns();auto img6=hoverRender.renderLogical(true);assert(img.size()==240u*160u&&img2.size()==240u*160u&&img3.size()==240u*160u&&img4.size()==240u*160u&&img5.size()==240u*160u&&img6.size()==240u*160u);
    std::cout<<"Category checks passed: categories 0/1/2 polar + 3/4/5 jetpack + 6 hovercraft, exact ROM selection/AABBs, airship and hovercraft state machines, shooting and rolls.\n";return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
