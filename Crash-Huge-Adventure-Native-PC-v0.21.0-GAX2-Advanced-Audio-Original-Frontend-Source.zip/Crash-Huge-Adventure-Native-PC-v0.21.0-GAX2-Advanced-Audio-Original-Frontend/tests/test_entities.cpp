#include "../src/entities.hpp"
#include <cassert>
#include <iostream>
#include <algorithm>
#include <cmath>
int main(){try{using namespace crash;
 GameData data(read("input/crash.gba"));auto scene=data.scene();auto list=data.entities(scene);
 assert(list.size()==79);assert(std::count_if(list.begin(),list.end(),[](const Entity& e){return e.type==EntityWorld::WumpaType;})==26);
 assert(std::count_if(list.begin(),list.end(),[](const Entity& e){return e.type==EntityWorld::GemType;})==1);
 assert(std::count_if(list.begin(),list.end(),[](const Entity& e){return EntityWorld::isCrate(e.type);})==40);
 assert(std::count_if(list.begin(),list.end(),[](const Entity& e){return e.type==EntityWorld::LevelPlatformType;})==1);
 assert(EntityWorld::crateAnimation(21)==31); // wooden X crate
 assert(EntityWorld::crateAnimation(22)==26); // C/checkpoint crate
 assert(EntityWorld::crateAnimation(23)==23); // Aku crate
 assert(EntityWorld::crateAnimation(30)==28); // Crash/life crate
 assert(EntityWorld::crateAnimation(31)==5);  // Nitro
 assert(EntityWorld::crateAnimation(32)==0);  // ? crate
 assert(EntityWorld::crateAnimation(33)==25); // bounce/slatted crate
 assert(EntityWorld::crateAnimation(35)==17); // TNT
 auto spawn=std::find_if(list.begin(),list.end(),[](const Entity& e){return e.type==0;});assert(spawn!=list.end()&&spawn->x==31&&spawn->y==363);
 Terrain terrain(data,scene);Player p(data,scene,terrain);EntityWorld world(data,scene);world.bind(p);
 assert(world.items.size()==79&&world.wumpaPlaced==26&&world.wumpaTotal==71&&world.gemTotal==1&&world.timeTrialTotal==1&&world.gemsCollected==0&&world.crateTotal==40&&world.levelObjectTotal==1&&world.wumpaCollected==0&&world.crateBroken==0&&world.wumpaFrames.size()==14);
 assert(!world.levelObjectClips[5].frames.empty());auto lb=world.levelObjectBounds[5];assert(std::abs((lb[2]-lb[0])-37.0)<.01);assert(std::abs((lb[3]-lb[1])-15.0)<.01);
 for(const auto& f:world.wumpaFrames){assert(f.width==32&&f.height==32);assert(std::any_of(f.pixels.begin(),f.pixels.end(),[](uint32_t v){return v!=0;}));}
 for(unsigned a:{0u,2u,5u,17u,23u,25u,26u,28u,31u,32u})assert(!world.crateClips[a].frames.empty());
 auto q5=std::find_if(world.items.begin(),world.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::QuestionCrateType&&e.triggerCap==5;});
 auto q10=std::find_if(world.items.begin(),world.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::QuestionCrateType&&e.triggerCap==10;});
 auto counter=std::find_if(world.items.begin(),world.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::CounterCrateType;});
 assert(q5!=world.items.end()&&q10!=world.items.end()&&counter!=world.items.end()&&counter->triggerCap==5);
 // Exact collision boxes are read from the ROM animation records, not guessed from the sprite image.
 auto normal=std::find_if(world.items.begin(),world.items.end(),[](const RuntimeEntity& e){return e.source.type==21;});assert(normal!=world.items.end());
 auto nb=world.entityBox(*normal);assert(std::abs((nb[2]-nb[0])-19.0)<.01&&std::abs((nb[3]-nb[1])-19.0)<.01);
 assert(p.dynamicSolids==&world.solids&&!world.solids.empty());
 // Wumpa collection.
 auto fruit=std::find_if(world.items.begin(),world.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::WumpaType;});assert(fruit!=world.items.end());
 p.x=fruit->source.x;p.y=fruit->source.y;world.step(p);assert(world.wumpaCollected>=1&&!fruit->active);auto before=world.wumpaCollected;world.step(p);assert(world.wumpaCollected==before);
 // Purple gem: level entity type 7 is dispatcher sub_801EA5C -> sprite bank 37 animation 0; collection persists through runtime state.
 auto gem=std::find_if(world.items.begin(),world.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::GemType;});assert(gem!=world.items.end()&&!world.gemClip.frames.empty());auto gb=world.entityBox(*gem);assert(gb[2]>gb[0]&&gb[3]>gb[1]);p.x=gem->x;p.y=gem->y;world.step(p);assert(!gem->active&&world.gemsCollected==1);
    // Type 16 is the time-trial clock: dispatcher sub_8021F70 -> master record 36 -> bank 36. It is gated until the level has been completed.
    auto clock=std::find_if(world.items.begin(),world.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::TimeTrialType;});assert(clock!=world.items.end()&&!clock->active&&!world.timeTrialClip.frames.empty());world.setTimeTrialAvailable(true);assert(clock->active);auto tb=world.entityBox(*clock);assert(tb[2]>tb[0]&&tb[3]>tb[1]);p.x=clock->x;p.y=clock->y;world.step(p);assert(!clock->active&&world.timeTrialStarted&&!world.timeTrialAvailable);world.timeTrialStarted=false;
 // A normal crate is destroyed by the native spin and creates a ROM-sprite break effect.
 world.reset();p.reset();normal=std::find_if(world.items.begin(),world.items.end(),[](const RuntimeEntity& e){return e.source.type==21;});p.x=normal->source.x;p.y=normal->source.y;p.spinTicks=10;world.step(p);assert(!normal->active&&world.crateBroken>=1&&!world.effects.empty());
 // Metal crate survives the spin and participates in dynamic solid collision.
 world.reset();p.reset();auto metal=std::find_if(world.items.begin(),world.items.end(),[](const RuntimeEntity& e){return e.source.type==28;});assert(metal!=world.items.end());p.x=metal->source.x;p.y=metal->source.y;p.spinTicks=10;world.step(p);assert(metal->active&&world.crateBroken==0);
 auto mb=world.entityBox(*metal);double floor= p.floorSurface(mb[0]+2,mb[2]-2,mb[1]-2,mb[1]+2);assert(std::abs(floor-mb[1])<.01);
 // Land on a metal box: the player stops exactly on its ROM collision top instead of passing through.
 p.spinTicks=0;p.x=metal->source.x;p.y=mb[1]-p.by-p.bh-8;p.vy=4;p.grounded=false;bool landed=false;for(int i=0;i<6;i++){p.step({});world.step(p);if(p.grounded){landed=true;break;}}assert(landed&&std::abs(p.feet()-mb[1])<.05);
 // Metal arrow crate is a solid bounce surface.
 world.reset();p.reset();auto arrow=std::find_if(world.items.begin(),world.items.end(),[](const RuntimeEntity& e){return e.source.type==29;});assert(arrow!=world.items.end());auto ab=world.entityBox(*arrow);p.x=arrow->source.x;p.y=ab[1]-p.by-p.bh-5;p.vy=4;p.grounded=false;bool bounced=false;for(int i=0;i<6;i++){p.step({});world.step(p);if(p.vy<0){bounced=true;break;}}assert(bounced);
 // ROM +6 cap: repeated trigger crate awards one Wumpa per valid landing and survives until the cap.
 world.reset();p.reset();q5=std::find_if(world.items.begin(),world.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::QuestionCrateType&&e.triggerCap==5;});auto qb=world.entityBox(*q5);unsigned wc=world.wumpaCollected;
 for(unsigned hit=0;hit<4;hit++){p.x=q5->source.x;p.y=qb[1]-p.by-p.bh;p.grounded=true;p.vy=0;p.lastDownImpact=3;world.step(p);assert(q5->active&&q5->hits==hit+1&&world.wumpaCollected==wc+hit+1);}
 p.x=q5->source.x;p.y=qb[1]-p.by-p.bh;p.grounded=true;p.vy=0;p.lastDownImpact=3;world.step(p);assert(!q5->active&&q5->hits==5&&world.wumpaCollected==wc+5);
 // C crate stores a native respawn checkpoint when broken.
 world.reset();p.reset();auto checkpoint=std::find_if(world.items.begin(),world.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::CheckpointCrateType;});assert(checkpoint!=world.items.end());p.x=checkpoint->source.x;p.y=checkpoint->source.y;p.spinTicks=10;world.step(p);assert(!checkpoint->active&&world.checkpointHits==1&&p.checkpointActive&&p.checkpointX==checkpoint->source.x);
 auto savedX=p.checkpointX;p.x=10;p.y=terrain.height()+100;p.respawn();assert(p.respawns==1&&p.checkpointActive&&p.x==savedX);
 // Aku crate grants protection; first Nitro consumes it, second one respawns Crash.
 world.reset();p.reset();unsigned respawnBase=p.respawns;auto aku=std::find_if(world.items.begin(),world.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::AkuCrateType;});assert(aku!=world.items.end());p.x=aku->source.x;p.y=aku->source.y;p.spinTicks=10;world.step(p);assert(world.akuMasks==1);
 p.spinTicks=0;unsigned nx=unsigned(p.x),ny=unsigned(p.y);world.items.emplace_back(Entity{900,EntityWorld::NitroCrateType,nx,ny,0,0});auto& nitro1=world.items.back();world.step(p);assert(!nitro1.active&&world.akuMasks==0&&p.respawns==respawnBase&&world.hazardHits==1);
 nx=unsigned(p.x);ny=unsigned(p.y);world.items.emplace_back(Entity{901,EntityWorld::NitroCrateType,nx,ny,0,0});world.step(p);assert(!world.items.back().active&&p.respawns==respawnBase+1&&world.hazardHits==2);
 // TNT: spin arms a short fuse; its own ROM animation phases are available and it eventually explodes.
 p.x=500;p.y=200;p.spinTicks=10;world.items.emplace_back(Entity{902,EntityWorld::TntCrateType,500,200,0,0});size_t ti=world.items.size()-1;world.step(p);assert(world.items[ti].triggered&&world.items[ti].countdown==8);p.spinTicks=0;p.x=700;p.y=100;for(int i=0;i<8;i++)world.step(p);assert(!world.items[ti].active);
 // Type 86: first non-crate level object, rendered from bank 39 animation 5 and present in the solid set.
 auto platform=std::find_if(world.items.begin(),world.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::LevelPlatformType;});assert(platform!=world.items.end());auto pb=world.entityBox(*platform);assert(std::abs((pb[2]-pb[0])-37.0)<.01&&std::abs((pb[3]-pb[1])-15.0)<.01);
 // Level 2 contains the first verified ROM mover family: entity type 79 / bank 39 animation 1.
 auto scene2=data.scene(2);Terrain terrain2(data,scene2);Player p2(data,scene2,terrain2);EntityWorld world2(data,scene2);world2.bind(p2);
 assert(world2.moverTotal==8);assert(!world2.levelObjectClips[1].frames.empty());
 auto mover=std::find_if(world2.items.begin(),world2.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::MovingPlatformType&&e.mover.inputDistX==40;});assert(mover!=world2.items.end()&&mover->mover.enabled&&mover->mover.rangeX==80);
 double mx0=mover->x;for(int i=0;i<40;i++)world2.step(p2);assert(std::abs(mover->x-mx0)>1.0);
 // Standing on the old top carries Crash by exactly the platform delta, like sub_801B624.
 world2.reset();p2.reset();mover=std::find_if(world2.items.begin(),world2.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::MovingPlatformType&&e.mover.inputDistX==40;});auto oldBox=world2.entityBox(*mover);p2.x=mover->x;p2.y=oldBox[1]-p2.by-p2.bh;p2.grounded=true;double px0=p2.x,oldX=mover->x;world2.step(p2);assert(world2.carriedTicks==1);assert(std::abs((p2.x-px0)-(mover->x-oldX))<1e-9);
 // After enough ticks it reverses, proving the center->edge->full-range oscillation is active.
 int firstDir=mover->mover.targetVxQ8;bool reversed=false;for(int i=0;i<260;i++){world2.step(p2);if(mover->mover.targetVxQ8==-firstDir){reversed=true;break;}}assert(reversed);
 // First native enemy: entity type 40, bank 13. Five are placed in room 0; patrol range comes from the room parameter record.
 assert(world.enemyTotal==5&&world.plantTotal==3&&world.exitMarkers==1&&world.canAutoExit()&&!world.enemyClips[0].frames.empty()&&!world.enemyClips[1].frames.empty());
 world.reset();p.reset();auto enemy=std::find_if(world.items.begin(),world.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::EnemyType&&e.triggerCap==0&&e.patrolRange==40;});assert(enemy!=world.items.end());double ex0=enemy->x;p.x=31;p.y=363;for(int i=0;i<12;i++)world.step(p);assert(std::abs(enemy->x-ex0)>1.0&&enemy->active&&!enemy->dying);
 // Spin changes the enemy to its non-looping bank-13 death clip, then removes it.
 p.x=enemy->x;p.y=enemy->y;p.spinTicks=10;world.step(p);assert(enemy->dying&&world.enemyKills==1);p.spinTicks=0;p.x=31;p.y=363;for(int i=0;i<40;i++)world.step(p);assert(!enemy->active);
 // Contact without spin is hazardous and uses the existing native respawn/checkpoint path.
 world.reset();p.reset();enemy=std::find_if(world.items.begin(),world.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::EnemyType;});unsigned enemyRespawns=p.respawns;p.x=enemy->x;p.y=enemy->y;world.step(p);assert(world.hazardHits==1&&p.respawns==enemyRespawns+1);
 // Type 42 plant: the decompiled state-3 controller uses a fixed 45x20 mirrored trigger, bank-10 anim 0 idle and non-looping anim 1 attack.
 world.reset();p.reset();auto plant=std::find_if(world.items.begin(),world.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::PlantType;});assert(plant!=world.items.end()&&plant->facingLeft);
 assert(world.plantClips[0].duration==3&&world.plantClips[0].frames.size()==9&&(world.plantClips[0].flags&2));assert(world.plantClips[1].duration==3&&world.plantClips[1].frames.size()==11&&!(world.plantClips[1].flags&2));
 auto plantBody=world.entityBox(*plant),plantTrigger=world.plantTriggerBox(*plant);assert(std::abs((plantBody[2]-plantBody[0])-38.0)<.01&&std::abs((plantBody[3]-plantBody[1])-42.0)<.01);assert(std::abs((plantTrigger[2]-plantTrigger[0])-45.0)<.01&&std::abs((plantTrigger[3]-plantTrigger[1])-20.0)<.01&&plantTrigger[2]<=plant->x+.01);
 unsigned plantRespawns=p.respawns;p.x=plant->x-20;p.y=plant->y;world.step(p);assert(plant->attacking&&plant->attackTicks==0&&world.plantAttacks==1&&p.respawns==plantRespawns);auto plantHit=world.plantHitBox(*plant);assert(std::abs((plantHit[2]-plantHit[0])-94.0)<.01&&std::abs((plantHit[3]-plantHit[1])-55.0)<.01);world.step(p);assert(plant->attackDamageDone&&p.respawns==plantRespawns+1);for(int i=0;i<40;i++)world.step(p);assert(!plant->attacking&&plant->active);
 // Room route parser: preserves the original 3-entry level with its actor-category stage in the middle instead of flattening it.
 auto route3=data.roomRoute(3);assert(route3.size()==3&&route3[0].tileRoom()&&!route3[1].tileRoom()&&route3[1].kind==3&&route3[1].category==0&&route3[2].tileRoom());auto room3b=data.scene(3,2);assert(room3b.record==route3[2].record);
 auto route6=data.roomRoute(6);assert(route6.size()==1&&!route6[0].tileRoom()&&route6[0].kind==3);
 // The exit auto-arm heuristic is ROM-position based: room 0's marker is 45px from the right edge; level 2's marker is not an exit.
 auto scene1=data.scene(1);EntityWorld world1(data,scene1);assert(!world1.canAutoExit());

 // Type 85 is the room-end marker. Reaching its 100x100 sensor requests the normal transition.
 world.reset();p.reset();auto exit=std::find_if(world.items.begin(),world.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::ExitMarkerType;});assert(exit!=world.items.end());p.x=exit->x;p.y=exit->y;world.step(p);assert(!world.levelExitTriggered);world.armExitMarker();world.step(p);assert(world.levelExitTriggered);
 // Mover kind 5: once Crash lands, its 60-tick timer continues even after he leaves; then gravity target becomes 4 px/tick with 40/256 acceleration. No main USA room places one directly, so this exercises the generic native implementation.
 world2.reset();p2.reset();RuntimeEntity synthetic(Entity{990,EntityWorld::MovingPlatformType,500,200,0,0});synthetic.mover.enabled=true;synthetic.mover.kind=5;synthetic.mover.xQ8=500<<8;synthetic.mover.yQ8=200<<8;world2.items.push_back(synthetic);auto& drop=world2.items.back();auto db=world2.entityBox(drop);p2.x=drop.x;p2.y=db[1]-p2.by-p2.bh;p2.grounded=true;world2.step(p2);assert(drop.mover.specialTimer==1);p2.x=20;p2.y=20;p2.grounded=false;for(int i=0;i<59;i++)world2.step(p2);assert(drop.mover.falling&&drop.mover.vyQ8>0&&drop.mover.vyQ8<=1024);
 // Entity type 87 is original mover kind 6: it holds its frame for 120 ticks, plays the 33-frame clip, then rearms another 120-tick hold.
 auto scene11=data.scene(11);Terrain terrain11(data,scene11);Player p11(data,scene11,terrain11);EntityWorld world11(data,scene11);world11.bind(p11);assert(std::count_if(world11.items.begin(),world11.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::TimedPlatformType;})==10);auto timed=std::find_if(world11.items.begin(),world11.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::TimedPlatformType;});assert(timed!=world11.items.end()&&timed->mover.kind==6&&timed->mover.holdUntil==120);for(int i=0;i<286;i++)world11.step(p11);assert(timed->mover.holdUntil>285);
 // Entity type 88 is original mover kind 7: dormant until activated, then its non-looping clip removes the platform.
 auto scene22=data.scene(22);Terrain terrain22(data,scene22);Player p22(data,scene22,terrain22);EntityWorld world22(data,scene22);world22.bind(p22);assert(std::count_if(world22.items.begin(),world22.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::FallingPlatformType;})==5);auto falling=std::find_if(world22.items.begin(),world22.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::FallingPlatformType;});assert(falling!=world22.items.end()&&falling->mover.kind==7&&!falling->mover.active);falling->mover.active=true;falling->stateTicks=0;for(int i=0;i<60&&falling->active;i++)world22.step(p22);assert(!falling->active);
 // Reset + HUD/render path.
 world.reset();p.reset();assert(world.wumpaCollected==0&&world.gemsCollected==0&&world.crateBroken==0&&world.enemyKills==0&&!world.levelExitTriggered&&std::count_if(world.items.begin(),world.items.begin()+79,[](const RuntimeEntity& e){return e.active;})==78);
 std::vector<uint32_t> canvas(240*160,0xff101018);int camX=0,camY=250;world.renderLogical(canvas,240,160,camX,camY,true);assert(std::any_of(canvas.begin(),canvas.end(),[](uint32_t v){return v!=0xff101018;}));
 std::cout<<"Entity checks passed: room 0 crates/Wumpas/gem7/time-trial16/type40/type42 + route table + ROM-position exits + native movers kind 1/6/7.\n";return 0;
 }catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
