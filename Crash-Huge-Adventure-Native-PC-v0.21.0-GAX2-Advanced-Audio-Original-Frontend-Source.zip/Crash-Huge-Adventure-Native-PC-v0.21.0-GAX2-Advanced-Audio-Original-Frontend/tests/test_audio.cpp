#include "../src/gax_rom.hpp"
#include <cassert>
#include <cmath>
#include <iostream>
int main(){try{using namespace crash;
    auto rom=read("input/crash.gba");auto version=gaxVersion(rom);auto tracks=scanGaxTracks(rom);
    assert(version.find("GAX Sound Engine 2.01D")!=std::string::npos);assert(tracks.size()==19);
    size_t table=0;auto songs=parseGaxSongs(rom,&table);assert(songs.size()==19);assert(table==0x16a560);
    assert(songs[0].title=="jungle"&&songs[0].channels==4&&songs[0].patternRows==16&&songs[0].orderCount==28&&songs[0].mixRate==18158);
    assert(songs[11].title=="main menu europe"&&songs[11].channels==7&&songs[16].title=="warp room"&&songs[16].channels==7);
    auto waves=parseWaveTable(rom,songs[0].waveTablePtr,30);assert(waves.size()==30&&waves[1].length>1000&&waves[29].length>1000);
    auto sfx=parseGaxSfxTable(rom,table);assert(sfx.size()==99);assert(sfx[0x46].slotId==0x3f&&sfx[0x49].slotId==0x11&&sfx[8].slotId==0x1f);assert(originalSfxId(SfxCue::Jump)==0x0d&&originalSfxId(SfxCue::Spin)==0x0a&&originalSfxId(SfxCue::Cancel)==0x49);
    uint32_t sfxData=findGaxSfxSongData(rom,songs[0]);assert(sfxData!=0);assert(gaxPtr(rom,gaxU32(rom,sfxData+0x10),88*4));
    auto instruments=parseInstrumentBank(rom,songs[0].instrumentTablePtr,52);unsigned envCount=0,vibCount=0,sweepRows=0,pingRows=0,seqFx=0;for(const auto& ins:instruments){if(ins.envelope.valid)++envCount;if(ins.vibratoDepth)++vibCount;for(const auto& r:ins.rows){if(r.sweepEnabled)++sweepRows;if(r.pingPong)++pingRows;}for(const auto& e:ins.seq)for(auto fx:e.fx)if(fx)++seqFx;}assert(envCount==52&&vibCount>=7&&sweepRows>=6&&pingRows>=9&&seqFx>=30);
    GaxLitePlayer player;assert(player.load(rom)&&player.ready());assert(player.musicInstruments().size()==52&&player.sfxInstruments().size()==88);player.select(MusicCue::WarpRoom);double energy=0;for(int i=0;i<44100;i++)energy+=std::abs(player.next());assert(energy>1.0);
    player.select(MusicCue::Silence);player.playSfx(SfxCue::Confirm);double fxEnergy=0;for(int i=0;i<12000;i++)fxEnergy+=std::abs(player.next());assert(fxEnergy>1.0);assert(player.activeSfxVoices()<=2);
    assert(levelMusic(5)==MusicCue::Dingodile&&levelMusic(11)==MusicCue::NGin&&levelMusic(17)==MusicCue::Tiny&&levelMusic(23)==MusicCue::Cortex);
    AudioCounters a,b;b.wumpa=1;b.crates=1;b.hazards=1;b.gems=1;b.shots=1;b.complete=true;auto d=audioDelta(a,b);assert(d.size()==6);
    std::cout<<"Audio checks passed: GAX2 song table 0x"<<std::hex<<table<<std::dec<<", 19 songs, 52-instrument music bank, 29 PCM waves, 99 SFX routes, advanced envelope/vibrato/sequence/sweep state and ROM PCM output.\n";return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
