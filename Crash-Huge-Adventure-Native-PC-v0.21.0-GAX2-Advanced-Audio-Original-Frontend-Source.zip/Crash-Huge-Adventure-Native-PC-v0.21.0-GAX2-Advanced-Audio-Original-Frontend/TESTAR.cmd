@echo off
cd /d "%~dp0"
TestCore.exe
if errorlevel 1 goto erro
TestPlayer.exe
if errorlevel 1 goto erro
TestEntities.exe
if errorlevel 1 goto erro
TestCategory.exe
if errorlevel 1 goto erro
TestRunState.exe
if errorlevel 1 goto erro
TestFrontend.exe
if errorlevel 1 goto erro
TestAudio.exe
if errorlevel 1 goto erro
TestHD.exe
if errorlevel 1 goto erro
echo Testes concluidos.
pause
exit /b 0
:erro
echo Falha nos testes.
pause
exit /b 1
