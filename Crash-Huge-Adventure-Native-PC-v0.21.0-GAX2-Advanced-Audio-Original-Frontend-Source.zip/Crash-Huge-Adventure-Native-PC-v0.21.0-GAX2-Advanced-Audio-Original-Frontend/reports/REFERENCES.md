# Referências e origem dos dados

- ROM USA ACQE enviada pelo usuário; todos os recursos deste pacote foram lidos dela.
- [CrashBandicootXS-decomp](https://github.com/Almamu/CrashBandicootXS-decomp), de Almamu e colaboradores, commit `1f417177c20de6836370ecaa0a9f266923e56bbe`. Consultados os layouts documentados de bancos de sprites, peças, sequências, paletas e mapas de salas, além dos leitores de cache de paletas. O projeto trabalha com a ROM europeia e ainda está em andamento.
- [Formato de salas](https://github.com/Almamu/CrashBandicootXS-decomp/blob/1f417177c20de6836370ecaa0a9f266923e56bbe/docs/levels.md).
- [Layout dos bancos](https://github.com/Almamu/CrashBandicootXS-decomp/blob/1f417177c20de6836370ecaa0a9f266923e56bbe/include/sprite_bank.h).
- [Leitor de cache de paletas](https://github.com/Almamu/CrashBandicootXS-decomp/blob/1f417177c20de6836370ecaa0a9f266923e56bbe/src/graphics/graphics.c).
- [GBATEK](https://mgba-emu.github.io/gbatek/): formatos de tiles e cores de GBA.

O código C++/Python da prévia foi escrito para este port com verificações de limites. Não foi copiado o código-fonte nem o conteúdo gráfico da decompilação de referência. Os endereços europeus serviram de pista; a descoberta e a validação foram realizadas sobre os bytes da ROM americana fornecida.

## Referências adicionais usadas até a v0.19.0

- `src/data/actor_category_175558.c`: descritores e vtable das 7 actor-categories.
- `src/graphics/actor_part101.c` / `actor_part103.c`: inicialização da category, ordem de spawn e leitura do threshold do próximo registro.
- `src/graphics/actor_part_2ac28.c`: factory `sub_802AC28` e seleção dos kinds de atores.
- `include/actor_anim.h` e `src/graphics/actor_anim.c`: `table_A`, `table_B`, frames, duração/loop e lookup no sprite sheet descompactado.
- `src/graphics/sprite_frame_queue.c`: frames brutos dos atores comuns e cache/VRAM do sheet LZ.
- `src/iwram/sprite_arm.c` / `tools/rle_sprites.py`: formato zero-run RLE `0x30` usado pelo Crash montado.
- `src/graphics/actor_part50.c`: `InitActorPart`/`sub_802A7B8`, profundidade e avanço das animações.
- `src/graphics/graphics_loading_1ea5c.c`: tipo 7 -> bank 37 e condição de progresso da gema.
- `src/graphics/actor_part102.c` / `actor_part94.c`: seleção `variantA/B/C`, thresholds e modos das sub-effects.
- `src/system/game_loop2.c`: flags de conclusão, relógio, `TickLevelClock` e estado de time trial.
- `src/graphics/graphics_loading_21d80.c`: entidade tipo 16, master asset record 36 (`+0x1B0`).
- `src/data/dispatch_table_16c6a4.c`: dispatch unificado de 92 tipos de entidade.
- `src/graphics/actor_part19*.c`: callbacks confirmados de Wumpa/caixas/freeze e objetos usados pelas actor-categories.



## Áudio — v0.19.0

- Shin’en GAX Sound Engine specification / research note (loveemu): estrutura geral de música, tags `"Title" © Author`, samples e diferenças do layout GAX v2.
- `shinen-gax-python` (beanieaxolotl): usado como referência cruzada para scanners e constantes de versões GAX posteriores; não foi copiado como backend do port.
- A implementação audível da v0.19.0 é própria e sintetizada; o catálogo de 19 faixas é obtido diretamente da ROM enviada pelo usuário.

## Áudio — v0.20.0

Referência cruzada adicional: branch pública atual de `Almamu/CrashBandicootXS-decomp`, consultada em 2026-10-05, especialmente `docs/audio.md`, `sound/gax_manifest.json`, `lib/gax/src/gax_internal.h`, `gax_sound_handler_info.c`, `gax_sound_handler_channel_play.c`, `gax_channel_note_scheduler.c`, `gax_note_trigger.c`, `src/data/song_table_16aa20.c` e `include/audio.h`.

Esses arquivos foram usados para confirmar a semântica das estruturas GAX2 e dos comandos. O código do replayer deste port foi escrito separadamente para ler a ROM ACQE do usuário; endereços USA foram descobertos/validados nos bytes da ROM, não copiados dos endereços EUR da referência.
