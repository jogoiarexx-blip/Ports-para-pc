# Estado do port v0.20.0

## Runtime nativo

O runtime permanece C++ nativo, sem execução do ARM do GBA. Parser da ROM, assets, física, entidades, rotas, save, time trial, actor-categories 0–6, airship, hovercraft e overrides HD continuam ativos.

## Áudio GAX2

- `gax_rom.hpp` descobre e valida a tabela lógica de 19 `GAX2_Song`.
- `GaxSongData`, handlers dos canais, order lists e packed patterns são lidos da ROM ACQE.
- Banco de música: 52 instrumentos / 29 waves PCM não vazias.
- Banco SFX: 88 instrumentos; tabela de gameplay com 99 rotas.
- `GaxLitePlayer` sequencia a ROM a ~59,7275 ticks/s e mistura PCM no backend Win32 44,1 kHz.
- O sintetizador antigo permanece somente como fallback.

### Ainda parcial

O mixer ainda aproxima envelopes, instrument sequences, vibrato, portamento e sweep. O objetivo do próximo áudio é substituir essas aproximações pelas regras completas do GAX 2.01D.

## Frontend

Warp Room em quatro andares, cada um com cinco fases + boss, mais portal secreto. A seleção preserva a numeração original do port (0–24) e o desbloqueio/save existente.

## Actor callbacks / IA

- Polar categories 0/1/2: callbacks explícitos já existentes preservados.
- Jetpack: `JetAiProfile` agora é o dispatcher real de update; tracker, depth runner, balloon, parachute, rocket, cannon plane, airship e ring são separados.

## Validação

8/8 suítes PASS; strict/Werror PASS; ASan/UBSan Audio/Frontend/Category PASS; SHA-256 da ROM preservado.
