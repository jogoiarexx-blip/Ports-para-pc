$ErrorActionPreference = "Stop"

$Root = Split-Path -Parent $MyInvocation.MyCommand.Path

function Find-CMake {
    $cmd = Get-Command cmake.exe -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }

    $candidates = @(
        (Join-Path $Root "tools\cmake\bin\cmake.exe"),
        "$env:ProgramFiles\CMake\bin\cmake.exe",
        "${env:ProgramFiles(x86)}\CMake\bin\cmake.exe",
        "$env:ProgramFiles\Microsoft Visual Studio\2022\BuildTools\Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin\cmake.exe",
        "$env:ProgramFiles\Microsoft Visual Studio\2022\Community\Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin\cmake.exe",
        "$env:ProgramFiles\Microsoft Visual Studio\2022\Professional\Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin\cmake.exe",
        "$env:ProgramFiles\Microsoft Visual Studio\2022\Enterprise\Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin\cmake.exe",
        "$env:ProgramFiles\Microsoft Visual Studio\2019\BuildTools\Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin\cmake.exe",
        "${env:ProgramFiles(x86)}\Microsoft Visual Studio\2019\BuildTools\Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin\cmake.exe"
    )
    foreach ($p in $candidates) {
        if ($p -and (Test-Path $p)) { return $p }
    }
    return $null
}

function Find-VSWhere {
    $cmd = Get-Command vswhere.exe -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    $p = "${env:ProgramFiles(x86)}\Microsoft Visual Studio\Installer\vswhere.exe"
    if (Test-Path $p) { return $p }
    return $null
}

function Find-MSVCInstallation {
    $vswhere = Find-VSWhere
    if (-not $vswhere) { return $null }
    $install = & $vswhere -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath
    if ($LASTEXITCODE -ne 0) { return $null }
    if ($install) { return ($install | Select-Object -First 1) }
    return $null
}

function Find-AnyVSInstallation {
    $vswhere = Find-VSWhere
    if (-not $vswhere) { return $null }
    $install = & $vswhere -latest -products * -property installationPath
    if ($LASTEXITCODE -ne 0) { return $null }
    if ($install) { return ($install | Select-Object -First 1) }
    return $null
}

function Require-Winget {
    $w = Get-Command winget.exe -ErrorAction SilentlyContinue
    if (-not $w) {
        Write-Host "winget nao foi encontrado." -ForegroundColor Red
        Write-Host "Instale/atualize o 'App Installer' da Microsoft Store e execute este arquivo novamente." -ForegroundColor Yellow
        exit 20
    }
    return $w.Source
}

function Refresh-ProcessPath {
    try {
        $machine = [Environment]::GetEnvironmentVariable("Path", "Machine")
        $user = [Environment]::GetEnvironmentVariable("Path", "User")
        $env:Path = "$machine;$user"
    } catch {}
}

Write-Host "OpenBOR Native Builder - preparacao do compilador Win64" -ForegroundColor Cyan
Write-Host "Este passo instala ferramentas APENAS para gerar OpenBOR-Native-Builder.exe." -ForegroundColor Yellow
Write-Host "O EXE gerado em dist-portable sera portatil e nao precisara dessas ferramentas em outro PC." -ForegroundColor Yellow
Write-Host ""

# 1) CMake: NAO chamar winget se ele ja existe. Isso evita o codigo de
#    'nenhuma atualizacao disponivel' ser tratado como falha.
$CMake = Find-CMake
if ($CMake) {
    Write-Host "CMake ja encontrado: $CMake" -ForegroundColor Green
} else {
    $Winget = Require-Winget
    Write-Host "CMake nao encontrado. Instalando Kitware.CMake..." -ForegroundColor Cyan
    & $Winget install --id Kitware.CMake -e --source winget --accept-package-agreements --accept-source-agreements --silent
    $wingetCode = $LASTEXITCODE

    Refresh-ProcessPath
    $CMake = Find-CMake
    if (-not $CMake) {
        Write-Host "" -ForegroundColor Red
        Write-Host "Nao foi possivel localizar o CMake depois do winget (codigo $wingetCode)." -ForegroundColor Red
        Write-Host "Se o winget disser que o CMake ja esta instalado, ele pode estar em:" -ForegroundColor Yellow
        Write-Host "  C:\Program Files\CMake\bin\cmake.exe" -ForegroundColor Yellow
        Write-Host "Repare/reinstale o CMake e marque a opcao para adicionar ao PATH, ou coloque um CMake portatil em tools\cmake\bin." -ForegroundColor Yellow
        exit 21
    }
    Write-Host "CMake instalado/encontrado: $CMake" -ForegroundColor Green
}

# 2) MSVC / Desktop development with C++.
$MSVC = Find-MSVCInstallation
if ($MSVC) {
    Write-Host "Visual Studio C++ Build Tools ja encontrado: $MSVC" -ForegroundColor Green
} else {
    Write-Host "Compilador MSVC C++ nao encontrado." -ForegroundColor Yellow

    $vswhere = Find-VSWhere
    $anyVS = Find-AnyVSInstallation
    $setup = "${env:ProgramFiles(x86)}\Microsoft Visual Studio\Installer\setup.exe"

    if ($anyVS -and (Test-Path $setup)) {
        # Ha Visual Studio/Build Tools instalado, mas sem o workload C++.
        # Modificamos a instalacao existente em vez de pedir ao winget um 'upgrade'.
        Write-Host "Visual Studio encontrado em: $anyVS" -ForegroundColor Cyan
        Write-Host "Adicionando o workload 'Desktop development with C++'..." -ForegroundColor Cyan
        $args = @(
            "modify",
            "--installPath", ('"' + $anyVS + '"'),
            "--add", "Microsoft.VisualStudio.Workload.VCTools",
            "--includeRecommended",
            "--quiet",
            "--norestart"
        )
        $p = Start-Process -FilePath $setup -ArgumentList $args -Verb RunAs -Wait -PassThru
        if ($p.ExitCode -ne 0 -and $p.ExitCode -ne 3010) {
            Write-Host "O Visual Studio Installer retornou codigo $($p.ExitCode)." -ForegroundColor Red
        }
    } else {
        $Winget = Require-Winget
        Write-Host "Instalando Visual Studio 2022 Build Tools + workload C++..." -ForegroundColor Cyan
        Write-Host "O Windows pode solicitar permissao de administrador." -ForegroundColor Yellow
        & $Winget install --id Microsoft.VisualStudio.2022.BuildTools -e --source winget --accept-package-agreements --accept-source-agreements --override "--wait --passive --norestart --add Microsoft.VisualStudio.Workload.VCTools --includeRecommended"
        $wingetVSCode = $LASTEXITCODE
        if ($wingetVSCode -ne 0) {
            Write-Host "winget retornou codigo $wingetVSCode. Vou verificar a instalacao antes de considerar isso uma falha." -ForegroundColor Yellow
        }
    }

    # Recarrega a deteccao depois do instalador. vswhere pode ter sido instalado agora.
    Start-Sleep -Seconds 2
    $MSVC = Find-MSVCInstallation
    if (-not $MSVC) {
        Write-Host "" -ForegroundColor Red
        Write-Host "ERRO: o workload C++ ainda nao foi localizado." -ForegroundColor Red
        Write-Host "Abra 'Visual Studio Installer' -> Build Tools 2022 -> Modificar e marque:" -ForegroundColor Yellow
        Write-Host "  Desktop development with C++" -ForegroundColor Cyan
        Write-Host "Depois confirme que 'MSVC v143' e um Windows 10/11 SDK estao selecionados." -ForegroundColor Yellow
        Write-Host "Reinicie este script depois da instalacao." -ForegroundColor Yellow
        exit 22
    }

    Write-Host "Visual Studio C++ Build Tools encontrado: $MSVC" -ForegroundColor Green
}

Write-Host ""
Write-Host "Tudo certo." -ForegroundColor Green
Write-Host "CMake: $CMake" -ForegroundColor Green
Write-Host "MSVC:  $MSVC" -ForegroundColor Green
Write-Host "Agora execute BUILD-PORTABLE-WINDOWS.cmd." -ForegroundColor Green
exit 0
