$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
Write-Host "BUILD-WINDOWS.ps1 usa o mesmo fluxo validado do build portatil Win64." -ForegroundColor Cyan
& (Join-Path $Root "BUILD-PORTABLE-WINDOWS.ps1")
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
Write-Host "Pronto: $Root\dist-portable\OpenBOR-Native-Builder.exe" -ForegroundColor Green
