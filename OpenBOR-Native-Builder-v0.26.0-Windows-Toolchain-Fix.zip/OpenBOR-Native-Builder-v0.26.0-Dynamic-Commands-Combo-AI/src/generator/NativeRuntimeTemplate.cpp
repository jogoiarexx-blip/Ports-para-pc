#include "NativeRuntimeTemplate.hpp"
#include <fstream>
#include <filesystem>

void NativeRuntimeTemplate::generate(const std::filesystem::path& outDir) {
    auto runtime = outDir / "runtime";
    auto src = runtime / "src";
    auto include = runtime / "include";
    std::filesystem::create_directories(src);
    std::filesystem::create_directories(include);

    std::ofstream cfg(outDir / "config" / "graphics.ini");
    cfg << "[video]\nrenderer=d3d11\ngpu_acceleration=true\nfullscreen=false\nwidth=1280\nheight=720\nvsync=true\nfps_limit=60\nrender_scale=1.0\ntexture_filter=nearest\n\n"
           "[graphics]\npreset=original\nupscale=original\npixel_perfect=true\nkeep_aspect_4_3=true\nfill_16_9=false\ninteger_scale=0\ncrt=false\nscanlines=false\ncrt_curvature=false\nbloom=false\ncontrast=1.0\nsaturation=1.0\nreduce_banding=false\nsharpen=0.0\n\n"
           "[gameplay]\nlogical_width=320\nlogical_height=240\ngravity=0.35\njump_default=4.0\nrun_multiplier=1.65\ndash_speed=6.0\ndash_ticks=12\nprojectile_lifetime=360\n\n[combat]\nenemy_ai=true\ncamera_lock_on_combat=true\nknockback=12\nenemy_attack_range=28\ncombo_window=24\nmax_combo=3\ngrab_range=30\nthrow_damage=24\nfall_ticks=28\nrecovery_ticks=18\n\n[audio]\nmaster_volume=1.0\nmusic_volume=0.80\neffects_volume=0.90\nopenbor_bor_adpcm=true\nauto_preview_music=true\npreferred_music_format=auto\n\n[input]\nmax_players=4\nactive_players=1\ngamepad=true\nplayer1_gamepad=0\nplayer2_gamepad=1\nplayer3_gamepad=2\nplayer4_gamepad=3\nkey_left=37\nkey_right=39\nkey_up=38\nkey_down=40\nkey_attack=74\nkey_jump=32\nkey_pickup=69\nkey_dash=76\nkey_grab=71\nkey_throw=72\nkey_run=16\npad_attack=4096\npad_jump=8192\npad_pickup=16384\npad_grab=32768\npad_dash=256\npad_throw=512\n\n[debug]\nshow_bbox=true\nshow_attack_box=true\n\n"
           "[compatibility]\nopenbor_palette_index0_transparency=true\npreserve_source_alpha=true\n\n[effects]\nparticles=high\nshadows=true\n";

    std::ofstream h(include / "RuntimeConfig.hpp");
    h << R"CPP(#pragma once
#include <filesystem>
#include <string>
struct RuntimeConfig {
  bool gpuAcceleration = true;
  bool fullscreen = false;
  bool vsync = true;
  bool showBBox = true;
  bool showAttackBox = true;
  bool openborPaletteIndex0Transparency = true;
  bool preserveSourceAlpha = true;
  bool openborBorAdpcm = true;
  bool autoPreviewMusic = true;
  bool enemyAI = true;
  bool cameraLockOnCombat = true;
  bool gamepad = true;
  bool pixelPerfect = true;
  bool keepAspect43 = true;
  bool fill169 = false;
  bool crt = false;
  bool scanlines = false;
  bool crtCurvature = false;
  bool bloom = false;
  bool reduceBanding = false;
  int maxPlayers = 4;
  int activePlayers = 1;
  int player1Gamepad = 0;
  int player2Gamepad = 1;
  int player3Gamepad = 2;
  int player4Gamepad = 3;
  int keyLeft = 37, keyRight = 39, keyUp = 38, keyDown = 40;
  int keyAttack = 74, keyJump = 32, keyPickup = 69, keyDash = 76, keyGrab = 71, keyThrow = 72, keyRun = 16;
  int padAttack = 4096, padJump = 8192, padPickup = 16384, padGrab = 32768, padDash = 256, padThrow = 512;
  int width = 1280;
  int height = 720;
  int fpsLimit = 60;
  int logicalWidth = 320;
  int logicalHeight = 240;
  int integerScale = 0;
  int dashTicks = 12;
  int projectileLifetime = 360;
  int knockback = 12;
  int enemyAttackRange = 28;
  int comboWindow = 24;
  int maxCombo = 3;
  int grabRange = 30;
  int throwDamage = 24;
  int fallTicks = 28;
  int recoveryTicks = 18;
  float renderScale = 1.0f;
  float gravity = 0.35f;
  float jumpDefault = 4.0f;
  float runMultiplier = 1.65f;
  float dashSpeed = 6.0f;
  float masterVolume = 1.0f;
  float musicVolume = 0.80f;
  float effectsVolume = 0.90f;
  float contrast = 1.0f;
  float saturation = 1.0f;
  float sharpen = 0.0f;
  std::string renderer = "d3d11";
  std::string textureFilter = "nearest";
  std::string graphicsPreset = "original";
  std::string upscaleMode = "original";
  std::string preferredMusicFormat = "auto";
};
RuntimeConfig loadRuntimeConfig(const std::filesystem::path& iniPath);
bool saveRuntimeConfig(const std::filesystem::path& iniPath, const RuntimeConfig& config);
void applyGraphicsPreset(RuntimeConfig& config, const std::string& preset);
)CPP";

    std::ofstream configCpp(src / "RuntimeConfig.cpp");
    configCpp << R"CPP(#include "RuntimeConfig.hpp"
#include <random>
#include <algorithm>
#include <cctype>
#include <fstream>
#include <string>
namespace {
std::string trim(std::string s){
  auto ws=[](unsigned char c){ return std::isspace(c)!=0; };
  while(!s.empty() && ws((unsigned char)s.front())) s.erase(s.begin());
  while(!s.empty() && ws((unsigned char)s.back())) s.pop_back();
  return s;
}
std::string lower(std::string s){ for(auto& c:s)c=(char)std::tolower((unsigned char)c); return s; }
bool parseBool(const std::string& v,bool fallback){ auto x=lower(trim(v)); if(x=="true"||x=="1"||x=="yes"||x=="on")return true; if(x=="false"||x=="0"||x=="no"||x=="off")return false; return fallback; }
float parseFloat(const std::string& v,float fallback){ try{return std::stof(v);}catch(...){return fallback;} }
int parseInt(const std::string& v,int fallback){ try{return std::stoi(v);}catch(...){return fallback;} }
}
void applyGraphicsPreset(RuntimeConfig& c,const std::string& requested){
  auto p=lower(requested); c.graphicsPreset=p;
  if(p=="original"){
    c.upscaleMode="original";c.textureFilter="nearest";c.pixelPerfect=true;c.keepAspect43=true;c.fill169=false;c.crt=false;c.scanlines=false;c.crtCurvature=false;c.bloom=false;c.contrast=1.0f;c.saturation=1.0f;c.reduceBanding=false;c.sharpen=0.0f;
  }else if(p=="improved"||p=="melhorado"){
    c.graphicsPreset="improved";c.upscaleMode="sharp-bilinear";c.textureFilter="linear";c.pixelPerfect=false;c.keepAspect43=true;c.fill169=false;c.crt=false;c.scanlines=false;c.crtCurvature=false;c.bloom=false;c.contrast=1.05f;c.saturation=1.05f;c.reduceBanding=true;c.sharpen=0.28f;
  }else if(p=="crt"){
    c.upscaleMode="sharp-bilinear";c.textureFilter="linear";c.pixelPerfect=false;c.keepAspect43=true;c.fill169=false;c.crt=true;c.scanlines=true;c.crtCurvature=true;c.bloom=true;c.contrast=1.06f;c.saturation=1.04f;c.reduceBanding=true;c.sharpen=0.16f;
  }else if(p=="sharp"||p=="nitido"||p=="nítido"){
    c.graphicsPreset="sharp";c.upscaleMode="cas";c.textureFilter="linear";c.pixelPerfect=false;c.keepAspect43=true;c.fill169=false;c.crt=false;c.scanlines=false;c.crtCurvature=false;c.bloom=false;c.contrast=1.03f;c.saturation=1.02f;c.reduceBanding=true;c.sharpen=0.68f;
  }
}
RuntimeConfig loadRuntimeConfig(const std::filesystem::path& iniPath){
  RuntimeConfig c; std::ifstream f(iniPath); if(!f) return c;
  std::string section,line;
  while(std::getline(f,line)){
    line=trim(line); if(line.empty()||line[0]=='#'||line[0]==';') continue;
    if(line.front()=='['&&line.back()==']'){ section=lower(trim(line.substr(1,line.size()-2))); continue; }
    auto eq=line.find('='); if(eq==std::string::npos) continue;
    auto key=lower(trim(line.substr(0,eq))), val=trim(line.substr(eq+1));
    if(section=="video"){
      if(key=="renderer") c.renderer=lower(val); else if(key=="gpu_acceleration") c.gpuAcceleration=parseBool(val,c.gpuAcceleration);
      else if(key=="fullscreen") c.fullscreen=parseBool(val,c.fullscreen); else if(key=="width") c.width=parseInt(val,c.width);
      else if(key=="height") c.height=parseInt(val,c.height); else if(key=="vsync") c.vsync=parseBool(val,c.vsync);
      else if(key=="fps_limit") c.fpsLimit=std::max(0,parseInt(val,c.fpsLimit)); else if(key=="render_scale") c.renderScale=parseFloat(val,c.renderScale);
      else if(key=="texture_filter") c.textureFilter=lower(val);
    } else if(section=="graphics"){
      if(key=="preset") c.graphicsPreset=lower(val); else if(key=="upscale") c.upscaleMode=lower(val);
      else if(key=="pixel_perfect") c.pixelPerfect=parseBool(val,c.pixelPerfect); else if(key=="keep_aspect_4_3") c.keepAspect43=parseBool(val,c.keepAspect43);
      else if(key=="fill_16_9") c.fill169=parseBool(val,c.fill169); else if(key=="integer_scale") c.integerScale=std::clamp(parseInt(val,c.integerScale),0,4);
      else if(key=="crt") c.crt=parseBool(val,c.crt); else if(key=="scanlines") c.scanlines=parseBool(val,c.scanlines);
      else if(key=="crt_curvature") c.crtCurvature=parseBool(val,c.crtCurvature); else if(key=="bloom") c.bloom=parseBool(val,c.bloom);
      else if(key=="contrast") c.contrast=std::clamp(parseFloat(val,c.contrast),0.5f,2.0f); else if(key=="saturation") c.saturation=std::clamp(parseFloat(val,c.saturation),0.0f,2.0f);
      else if(key=="reduce_banding") c.reduceBanding=parseBool(val,c.reduceBanding); else if(key=="sharpen") c.sharpen=std::clamp(parseFloat(val,c.sharpen),0.0f,1.0f);
    } else if(section=="gameplay"){
      if(key=="logical_width") c.logicalWidth=parseInt(val,c.logicalWidth);
      else if(key=="logical_height") c.logicalHeight=parseInt(val,c.logicalHeight);
      else if(key=="gravity") c.gravity=std::max(0.01f,parseFloat(val,c.gravity));
      else if(key=="jump_default") c.jumpDefault=std::max(0.5f,parseFloat(val,c.jumpDefault));
      else if(key=="run_multiplier") c.runMultiplier=std::max(1.0f,parseFloat(val,c.runMultiplier));
      else if(key=="dash_speed") c.dashSpeed=std::max(1.0f,parseFloat(val,c.dashSpeed));
      else if(key=="dash_ticks") c.dashTicks=std::max(1,parseInt(val,c.dashTicks));
      else if(key=="projectile_lifetime") c.projectileLifetime=std::max(30,parseInt(val,c.projectileLifetime));
    } else if(section=="combat"){
      if(key=="enemy_ai") c.enemyAI=parseBool(val,c.enemyAI);
      else if(key=="camera_lock_on_combat") c.cameraLockOnCombat=parseBool(val,c.cameraLockOnCombat);
      else if(key=="knockback") c.knockback=parseInt(val,c.knockback);
      else if(key=="enemy_attack_range") c.enemyAttackRange=parseInt(val,c.enemyAttackRange);
      else if(key=="combo_window") c.comboWindow=parseInt(val,c.comboWindow);
      else if(key=="max_combo") c.maxCombo=std::max(1,parseInt(val,c.maxCombo));
      else if(key=="grab_range") c.grabRange=std::max(8,parseInt(val,c.grabRange));
      else if(key=="throw_damage") c.throwDamage=std::max(1,parseInt(val,c.throwDamage));
      else if(key=="fall_ticks") c.fallTicks=std::max(1,parseInt(val,c.fallTicks));
      else if(key=="recovery_ticks") c.recoveryTicks=std::max(1,parseInt(val,c.recoveryTicks));
    } else if(section=="input"){
      if(key=="max_players") c.maxPlayers=std::clamp(parseInt(val,c.maxPlayers),1,4);
      else if(key=="active_players") c.activePlayers=std::clamp(parseInt(val,c.activePlayers),1,4);
      else if(key=="gamepad") c.gamepad=parseBool(val,c.gamepad);
      else if(key=="player1_gamepad") c.player1Gamepad=std::clamp(parseInt(val,c.player1Gamepad),0,3);
      else if(key=="player2_gamepad") c.player2Gamepad=std::clamp(parseInt(val,c.player2Gamepad),0,3);
      else if(key=="player3_gamepad") c.player3Gamepad=std::clamp(parseInt(val,c.player3Gamepad),0,3);
      else if(key=="player4_gamepad") c.player4Gamepad=std::clamp(parseInt(val,c.player4Gamepad),0,3);
      else if(key=="key_left") c.keyLeft=std::clamp(parseInt(val,c.keyLeft),1,255);
      else if(key=="key_right") c.keyRight=std::clamp(parseInt(val,c.keyRight),1,255);
      else if(key=="key_up") c.keyUp=std::clamp(parseInt(val,c.keyUp),1,255);
      else if(key=="key_down") c.keyDown=std::clamp(parseInt(val,c.keyDown),1,255);
      else if(key=="key_attack") c.keyAttack=std::clamp(parseInt(val,c.keyAttack),1,255);
      else if(key=="key_jump") c.keyJump=std::clamp(parseInt(val,c.keyJump),1,255);
      else if(key=="key_pickup") c.keyPickup=std::clamp(parseInt(val,c.keyPickup),1,255);
      else if(key=="key_dash") c.keyDash=std::clamp(parseInt(val,c.keyDash),1,255);
      else if(key=="key_grab") c.keyGrab=std::clamp(parseInt(val,c.keyGrab),1,255);
      else if(key=="key_throw") c.keyThrow=std::clamp(parseInt(val,c.keyThrow),1,255);
      else if(key=="key_run") c.keyRun=std::clamp(parseInt(val,c.keyRun),1,255);
      else if(key=="pad_attack") c.padAttack=parseInt(val,c.padAttack);
      else if(key=="pad_jump") c.padJump=parseInt(val,c.padJump);
      else if(key=="pad_pickup") c.padPickup=parseInt(val,c.padPickup);
      else if(key=="pad_grab") c.padGrab=parseInt(val,c.padGrab);
      else if(key=="pad_dash") c.padDash=parseInt(val,c.padDash);
      else if(key=="pad_throw") c.padThrow=parseInt(val,c.padThrow);
    } else if(section=="audio"){
      if(key=="master_volume") c.masterVolume=std::clamp(parseFloat(val,c.masterVolume),0.0f,1.0f);
      else if(key=="music_volume") c.musicVolume=std::clamp(parseFloat(val,c.musicVolume),0.0f,1.0f);
      else if(key=="effects_volume") c.effectsVolume=std::clamp(parseFloat(val,c.effectsVolume),0.0f,1.0f);
      else if(key=="openbor_bor_adpcm") c.openborBorAdpcm=parseBool(val,c.openborBorAdpcm);
      else if(key=="auto_preview_music") c.autoPreviewMusic=parseBool(val,c.autoPreviewMusic);
      else if(key=="preferred_music_format") c.preferredMusicFormat=lower(val);
    } else if(section=="debug"){
      if(key=="show_bbox") c.showBBox=parseBool(val,c.showBBox); else if(key=="show_attack_box") c.showAttackBox=parseBool(val,c.showAttackBox);
    } else if(section=="compatibility"){
      if(key=="openbor_palette_index0_transparency") c.openborPaletteIndex0Transparency=parseBool(val,c.openborPaletteIndex0Transparency);
      else if(key=="preserve_source_alpha") c.preserveSourceAlpha=parseBool(val,c.preserveSourceAlpha);
    }
  }
  c.logicalWidth=std::max(160,c.logicalWidth);c.logicalHeight=std::max(120,c.logicalHeight);
  return c;
}
bool saveRuntimeConfig(const std::filesystem::path& iniPath,const RuntimeConfig& c){
  std::ofstream f(iniPath,std::ios::trunc); if(!f) return false;
  f<<"[video]\nrenderer="<<c.renderer<<"\ngpu_acceleration="<<(c.gpuAcceleration?"true":"false")
   <<"\nfullscreen="<<(c.fullscreen?"true":"false")<<"\nwidth="<<c.width<<"\nheight="<<c.height
   <<"\nvsync="<<(c.vsync?"true":"false")<<"\nfps_limit="<<c.fpsLimit<<"\nrender_scale="<<c.renderScale<<"\ntexture_filter="<<c.textureFilter<<"\n\n";
  f<<"[graphics]\npreset="<<c.graphicsPreset<<"\nupscale="<<c.upscaleMode<<"\npixel_perfect="<<(c.pixelPerfect?"true":"false")
   <<"\nkeep_aspect_4_3="<<(c.keepAspect43?"true":"false")<<"\nfill_16_9="<<(c.fill169?"true":"false")<<"\ninteger_scale="<<c.integerScale
   <<"\ncrt="<<(c.crt?"true":"false")<<"\nscanlines="<<(c.scanlines?"true":"false")<<"\ncrt_curvature="<<(c.crtCurvature?"true":"false")
   <<"\nbloom="<<(c.bloom?"true":"false")<<"\ncontrast="<<c.contrast<<"\nsaturation="<<c.saturation<<"\nreduce_banding="<<(c.reduceBanding?"true":"false")<<"\nsharpen="<<c.sharpen<<"\n\n";
  f<<"[gameplay]\nlogical_width="<<c.logicalWidth<<"\nlogical_height="<<c.logicalHeight
   <<"\ngravity="<<c.gravity<<"\njump_default="<<c.jumpDefault<<"\nrun_multiplier="<<c.runMultiplier
   <<"\ndash_speed="<<c.dashSpeed<<"\ndash_ticks="<<c.dashTicks<<"\nprojectile_lifetime="<<c.projectileLifetime<<"\n\n";
  f<<"[combat]\nenemy_ai="<<(c.enemyAI?"true":"false")<<"\ncamera_lock_on_combat="<<(c.cameraLockOnCombat?"true":"false")
   <<"\nknockback="<<c.knockback<<"\nenemy_attack_range="<<c.enemyAttackRange<<"\ncombo_window="<<c.comboWindow
   <<"\nmax_combo="<<c.maxCombo<<"\ngrab_range="<<c.grabRange<<"\nthrow_damage="<<c.throwDamage
   <<"\nfall_ticks="<<c.fallTicks<<"\nrecovery_ticks="<<c.recoveryTicks<<"\n\n";
  f<<"[input]\nmax_players="<<c.maxPlayers<<"\nactive_players="<<c.activePlayers<<"\ngamepad="<<(c.gamepad?"true":"false")
   <<"\nplayer1_gamepad="<<c.player1Gamepad<<"\nplayer2_gamepad="<<c.player2Gamepad<<"\nplayer3_gamepad="<<c.player3Gamepad<<"\nplayer4_gamepad="<<c.player4Gamepad
   <<"\nkey_left="<<c.keyLeft<<"\nkey_right="<<c.keyRight<<"\nkey_up="<<c.keyUp<<"\nkey_down="<<c.keyDown
   <<"\nkey_attack="<<c.keyAttack<<"\nkey_jump="<<c.keyJump<<"\nkey_pickup="<<c.keyPickup<<"\nkey_dash="<<c.keyDash
   <<"\nkey_grab="<<c.keyGrab<<"\nkey_throw="<<c.keyThrow<<"\nkey_run="<<c.keyRun
   <<"\npad_attack="<<c.padAttack<<"\npad_jump="<<c.padJump<<"\npad_pickup="<<c.padPickup<<"\npad_grab="<<c.padGrab<<"\npad_dash="<<c.padDash<<"\npad_throw="<<c.padThrow<<"\n\n";
  f<<"[audio]\nmaster_volume="<<c.masterVolume<<"\nmusic_volume="<<c.musicVolume<<"\neffects_volume="<<c.effectsVolume
   <<"\nopenbor_bor_adpcm="<<(c.openborBorAdpcm?"true":"false")<<"\nauto_preview_music="<<(c.autoPreviewMusic?"true":"false")
   <<"\npreferred_music_format="<<c.preferredMusicFormat<<"\n\n";
  f<<"[debug]\nshow_bbox="<<(c.showBBox?"true":"false")<<"\nshow_attack_box="<<(c.showAttackBox?"true":"false")<<"\n\n";
  f<<"[compatibility]\nopenbor_palette_index0_transparency="<<(c.openborPaletteIndex0Transparency?"true":"false")
   <<"\npreserve_source_alpha="<<(c.preserveSourceAlpha?"true":"false")<<"\n\n";
  f<<"[effects]\nparticles=high\nshadows=true\n";
  return (bool)f;
}
)CPP";

    std::ofstream renderer(include / "Renderer.hpp");
    renderer << R"CPP(#pragma once
#include "RuntimeConfig.hpp"
#include <random>
#include "../generated/GeneratedCharacters.hpp"
#include <filesystem>
#include <string>
#include <vector>
struct SpriteImage { int width=0; int height=0; std::vector<unsigned char> bgra; };
class Renderer {
public:
  Renderer() = default;
  ~Renderer();
  bool initialize(const RuntimeConfig&);
  void setConfig(const RuntimeConfig&);
  bool isRunning() const;
  bool pumpEvents();
  void beginFrame();
  void drawImage(const SpriteImage&, int x, int y);
  void drawSolidRect(int x, int y, int w, int h, unsigned char r, unsigned char g, unsigned char b);
  void drawDot(int x, int y, unsigned int rgb);
  void drawLine(int x1, int y1, int x2, int y2, unsigned int rgb);
  void drawText(const std::string& text, int x, int y, int size=12, bool selected=false);
  void drawFrame(const SpriteImage&, const generated::Frame&, int originX, int originY, const RuntimeConfig&, bool flipX=false);
  void endFrame();
  bool loadSprite(const std::filesystem::path&, SpriteImage&);
  const std::string& backend() const;
private:
  RuntimeConfig config_;
  std::string backend_ = "headless";
  bool running_ = true;
#ifdef _WIN32
  bool createLogicalCanvas();
  bool initializeD3D11();
  void shutdownWindowsResources();
  void presentWithGdiFallback();
  void* hwnd_ = nullptr;
  void* frameDC_ = nullptr;
  void* frameBitmap_ = nullptr;
  void* frameOldBitmap_ = nullptr;
  void* frameBits_ = nullptr;
  int frameStride_ = 0;
  void* d3dDevice_ = nullptr;
  void* d3dContext_ = nullptr;
  void* swapChain_ = nullptr;
  void* sourceTexture_ = nullptr;
  void* sourceSRV_ = nullptr;
  void* samplerPoint_ = nullptr;
  void* samplerLinear_ = nullptr;
  void* vertexShader_ = nullptr;
  void* pixelShader_ = nullptr;
  void* constantBuffer_ = nullptr;
  void* d2dFactory_ = nullptr;
  void* d2dTarget_ = nullptr;
  void* dwriteFactory_ = nullptr;
#endif
};
)CPP";

    std::ofstream rendererCpp(src / "Renderer.cpp");
    rendererCpp << R"CPP(#include "Renderer.hpp"
#include <iostream>
#include <algorithm>
#include <cstring>
#include <cmath>
#include <cstdint>
#ifdef _WIN32
#define NOMINMAX
#include <windows.h>
#include <wincodec.h>
#include <d3d11.h>
#include <dxgi.h>
#include <d3dcompiler.h>
#include <d2d1.h>
#include <dwrite.h>
#pragma comment(lib, "windowscodecs.lib")
#pragma comment(lib, "ole32.lib")
#pragma comment(lib, "msimg32.lib")
#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "dxgi.lib")
#pragma comment(lib, "d3dcompiler.lib")
#pragma comment(lib, "d2d1.lib")
#pragma comment(lib, "dwrite.lib")

template<class T> static void safeRelease(T*& p){ if(p){ p->Release(); p=nullptr; } }
static LRESULT CALLBACK PortWndProc(HWND h, UINT m, WPARAM w, LPARAM l){
  if(m==WM_DESTROY){ PostQuitMessage(0); return 0; }
  return DefWindowProcW(h,m,w,l);
}
static std::wstring widenUtf8(const std::string& s){
  if(s.empty()) return {};
  int n=MultiByteToWideChar(CP_UTF8,0,s.c_str(),(int)s.size(),nullptr,0); if(n<=0) return std::wstring(s.begin(),s.end());
  std::wstring w((size_t)n,L' '); MultiByteToWideChar(CP_UTF8,0,s.c_str(),(int)s.size(),w.data(),n); return w;
}
struct ShaderParams {
  float texelX=1.0f/320.0f, texelY=1.0f/240.0f, sharpen=0.0f, contrast=1.0f;
  float saturation=1.0f, bloom=0.0f, scanline=0.0f, curvature=0.0f;
  float banding=0.0f, mode=0.0f, time=0.0f, unused=0.0f;
  float uvScaleX=1.0f, uvScaleY=1.0f, uvOffsetX=0.0f, uvOffsetY=0.0f;
};
static const char* kVs = R"HLSL(
struct VSOut { float4 pos:SV_POSITION; float2 uv:TEXCOORD0; };
VSOut main(uint id:SV_VertexID){
  VSOut o; float2 p = id==0?float2(-1,-1):(id==1?float2(-1,3):float2(3,-1));
  o.pos=float4(p,0,1); o.uv=float2((p.x+1)*0.5,1-(p.y+1)*0.5); return o;
}
)HLSL";
static const char* kPs = R"HLSL(
Texture2D Scene:register(t0); SamplerState Samp:register(s0);
cbuffer Params:register(b0){
  float2 texel; float sharpen; float contrast;
  float saturation; float bloom; float scanline; float curvature;
  float banding; float mode; float time; float unused;
  float2 uvScale; float2 uvOffset;
};
float hash12(float2 p){ float3 p3=frac(float3(p.xyx)*.1031); p3+=dot(p3,p3.yzx+33.33); return frac((p3.x+p3.y)*p3.z); }
float3 sampleScene(float2 uv){ return Scene.Sample(Samp,uv).rgb; }
float4 main(float4 pos:SV_POSITION,float2 baseUV:TEXCOORD0):SV_TARGET{
  float2 uv=baseUV;
  if(curvature>0.001){ float2 q=uv*2-1; q*=1+curvature*0.18*dot(q,q); uv=q*0.5+0.5; if(any(uv<0)||any(uv>1)) return float4(0,0,0,1); }
  uv=uv*uvScale+uvOffset;
  float3 c=sampleScene(uv);
  float3 l=sampleScene(uv-float2(texel.x,0)), r=sampleScene(uv+float2(texel.x,0));
  float3 u=sampleScene(uv-float2(0,texel.y)), d=sampleScene(uv+float2(0,texel.y));
  float3 avg=(l+r+u+d)*0.25;
  if(mode>0.5&&mode<1.5) c=saturate(c*1.18-avg*0.18);
  else if(mode>=1.5&&mode<2.5) c=saturate(c+(c-avg)*max(sharpen,0.22));
  else if(mode>=2.5){ float ex=dot(abs(l-r),float3(.333,.333,.333)); float ey=dot(abs(u-d),float3(.333,.333,.333)); float3 edge=ex<ey?(l+r)*.5:(u+d)*.5; c=lerp(c,edge,0.20); c=saturate(c+(c-avg)*sharpen*0.45); }
  if(bloom>0.001){ float3 glow=(sampleScene(uv+texel*2)+sampleScene(uv-texel*2)+sampleScene(uv+float2(texel.x*2,-texel.y*2))+sampleScene(uv+float2(-texel.x*2,texel.y*2)))*0.25; float lum=max(glow.r,max(glow.g,glow.b)); c+=glow*max(0,lum-.45)*bloom; }
  float lum=dot(c,float3(.299,.587,.114)); c=lerp(float3(lum,lum,lum),c,saturation); c=(c-.5)*contrast+.5;
  if(scanline>0.001){ float line=0.5+0.5*cos(3.14159265*(uv.y/max(texel.y,0.00001))); c*=1-scanline*(0.10+0.18*line); }
  if(banding>0.001){ float n=hash12(pos.xy+time)-.5; c+=n*(1.0/255.0)*banding; }
  if(unused>0.001){ float2 vp=baseUV*2-1; float vign=saturate(1.0-0.12*dot(vp,vp)); float mask=0.975+0.025*sin(pos.x*3.14159265); c*=vign*mask; }
  return float4(saturate(c),1);
}
)HLSL";
#endif

Renderer::~Renderer(){
#ifdef _WIN32
  shutdownWindowsResources();
#endif
}
void Renderer::setConfig(const RuntimeConfig& c){ config_=c; }

#ifdef _WIN32
bool Renderer::createLogicalCanvas(){
  if(frameDC_){ HDC dc=(HDC)frameDC_; if(frameOldBitmap_) SelectObject(dc,(HGDIOBJ)frameOldBitmap_); if(frameBitmap_) DeleteObject((HBITMAP)frameBitmap_); DeleteDC(dc); frameDC_=frameBitmap_=frameOldBitmap_=frameBits_=nullptr; }
  BITMAPINFO bi{}; bi.bmiHeader.biSize=sizeof(BITMAPINFOHEADER); bi.bmiHeader.biWidth=config_.logicalWidth; bi.bmiHeader.biHeight=-config_.logicalHeight; bi.bmiHeader.biPlanes=1; bi.bmiHeader.biBitCount=32; bi.bmiHeader.biCompression=BI_RGB;
  HDC dc=CreateCompatibleDC(nullptr); void* bits=nullptr; HBITMAP bmp=CreateDIBSection(dc,&bi,DIB_RGB_COLORS,&bits,nullptr,0); if(!dc||!bmp||!bits){ if(bmp)DeleteObject(bmp); if(dc)DeleteDC(dc); return false; }
  HGDIOBJ old=SelectObject(dc,bmp); frameDC_=dc; frameBitmap_=bmp; frameOldBitmap_=old; frameBits_=bits; frameStride_=config_.logicalWidth*4;
  ID2D1Factory* factory=nullptr; if(SUCCEEDED(D2D1CreateFactory(D2D1_FACTORY_TYPE_SINGLE_THREADED,&factory))){
    d2dFactory_=factory; D2D1_RENDER_TARGET_PROPERTIES props=D2D1::RenderTargetProperties(D2D1_RENDER_TARGET_TYPE_SOFTWARE,D2D1::PixelFormat(DXGI_FORMAT_B8G8R8A8_UNORM,D2D1_ALPHA_MODE_PREMULTIPLIED)); ID2D1DCRenderTarget* rt=nullptr; if(SUCCEEDED(factory->CreateDCRenderTarget(&props,&rt))) d2dTarget_=rt;
  }
  IDWriteFactory* dw=nullptr; if(SUCCEEDED(DWriteCreateFactory(DWRITE_FACTORY_TYPE_SHARED,__uuidof(IDWriteFactory),(IUnknown**)&dw))) dwriteFactory_=dw;
  return true;
}
bool Renderer::initializeD3D11(){
  if(!hwnd_||!config_.gpuAcceleration||config_.renderer!="d3d11") return false;
  HWND h=(HWND)hwnd_; RECT rc{}; GetClientRect(h,&rc); UINT ww=(UINT)std::max<LONG>(1,rc.right-rc.left), wh=(UINT)std::max<LONG>(1,rc.bottom-rc.top);
  DXGI_SWAP_CHAIN_DESC sd{}; sd.BufferDesc.Width=ww; sd.BufferDesc.Height=wh; sd.BufferDesc.Format=DXGI_FORMAT_R8G8B8A8_UNORM; sd.SampleDesc.Count=1; sd.BufferUsage=DXGI_USAGE_RENDER_TARGET_OUTPUT; sd.BufferCount=2; sd.OutputWindow=h; sd.Windowed=TRUE; sd.SwapEffect=DXGI_SWAP_EFFECT_DISCARD;
  D3D_FEATURE_LEVEL levels[]={D3D_FEATURE_LEVEL_11_0,D3D_FEATURE_LEVEL_10_1,D3D_FEATURE_LEVEL_10_0}; D3D_FEATURE_LEVEL got{}; ID3D11Device* dev=nullptr;ID3D11DeviceContext* ctx=nullptr;IDXGISwapChain* sc=nullptr;
  HRESULT hr=D3D11CreateDeviceAndSwapChain(nullptr,D3D_DRIVER_TYPE_HARDWARE,nullptr,D3D11_CREATE_DEVICE_BGRA_SUPPORT,levels,3,D3D11_SDK_VERSION,&sd,&sc,&dev,&got,&ctx);
  if(FAILED(hr)) hr=D3D11CreateDeviceAndSwapChain(nullptr,D3D_DRIVER_TYPE_WARP,nullptr,D3D11_CREATE_DEVICE_BGRA_SUPPORT,levels,3,D3D11_SDK_VERSION,&sd,&sc,&dev,&got,&ctx);
  if(FAILED(hr)){safeRelease(sc);safeRelease(ctx);safeRelease(dev);return false;}
  d3dDevice_=dev;d3dContext_=ctx;swapChain_=sc;
  D3D11_TEXTURE2D_DESC td{}; td.Width=(UINT)config_.logicalWidth;td.Height=(UINT)config_.logicalHeight;td.MipLevels=1;td.ArraySize=1;td.Format=DXGI_FORMAT_B8G8R8A8_UNORM;td.SampleDesc.Count=1;td.Usage=D3D11_USAGE_DEFAULT;td.BindFlags=D3D11_BIND_SHADER_RESOURCE;
  ID3D11Texture2D* src=nullptr; if(FAILED(dev->CreateTexture2D(&td,nullptr,&src))) return false; sourceTexture_=src; ID3D11ShaderResourceView* srv=nullptr;if(FAILED(dev->CreateShaderResourceView(src,nullptr,&srv)))return false;sourceSRV_=srv;
  D3D11_SAMPLER_DESC sp{};sp.Filter=D3D11_FILTER_MIN_MAG_MIP_POINT;sp.AddressU=sp.AddressV=sp.AddressW=D3D11_TEXTURE_ADDRESS_CLAMP;sp.MaxLOD=D3D11_FLOAT32_MAX;ID3D11SamplerState* point=nullptr;dev->CreateSamplerState(&sp,&point);samplerPoint_=point;sp.Filter=D3D11_FILTER_MIN_MAG_MIP_LINEAR;ID3D11SamplerState* linear=nullptr;dev->CreateSamplerState(&sp,&linear);samplerLinear_=linear;
  ID3DBlob* vb=nullptr,*pb=nullptr,*err=nullptr; if(FAILED(D3DCompile(kVs,std::strlen(kVs),nullptr,nullptr,nullptr,"main","vs_4_0",D3DCOMPILE_OPTIMIZATION_LEVEL3,0,&vb,&err))){if(err){std::cerr<<(const char*)err->GetBufferPointer()<<"\n";err->Release();}return false;} if(err){err->Release();err=nullptr;}
  if(FAILED(D3DCompile(kPs,std::strlen(kPs),nullptr,nullptr,nullptr,"main","ps_4_0",D3DCOMPILE_OPTIMIZATION_LEVEL3,0,&pb,&err))){if(err){std::cerr<<(const char*)err->GetBufferPointer()<<"\n";err->Release();}vb->Release();return false;} if(err)err->Release();
  ID3D11VertexShader* vs=nullptr;ID3D11PixelShader* ps=nullptr;dev->CreateVertexShader(vb->GetBufferPointer(),vb->GetBufferSize(),nullptr,&vs);dev->CreatePixelShader(pb->GetBufferPointer(),pb->GetBufferSize(),nullptr,&ps);vb->Release();pb->Release();vertexShader_=vs;pixelShader_=ps;
  D3D11_BUFFER_DESC bd{};bd.ByteWidth=sizeof(ShaderParams);bd.Usage=D3D11_USAGE_DYNAMIC;bd.BindFlags=D3D11_BIND_CONSTANT_BUFFER;bd.CPUAccessFlags=D3D11_CPU_ACCESS_WRITE;ID3D11Buffer* cb=nullptr;dev->CreateBuffer(&bd,nullptr,&cb);constantBuffer_=cb;
  backend_="d3d11-postprocess"; return true;
}
void Renderer::shutdownWindowsResources(){
  auto* ctx=(ID3D11DeviceContext*)d3dContext_; if(ctx)ctx->ClearState();
  if(constantBuffer_){((ID3D11Buffer*)constantBuffer_)->Release();constantBuffer_=nullptr;}if(pixelShader_){((ID3D11PixelShader*)pixelShader_)->Release();pixelShader_=nullptr;}if(vertexShader_){((ID3D11VertexShader*)vertexShader_)->Release();vertexShader_=nullptr;}if(samplerLinear_){((ID3D11SamplerState*)samplerLinear_)->Release();samplerLinear_=nullptr;}if(samplerPoint_){((ID3D11SamplerState*)samplerPoint_)->Release();samplerPoint_=nullptr;}if(sourceSRV_){((ID3D11ShaderResourceView*)sourceSRV_)->Release();sourceSRV_=nullptr;}if(sourceTexture_){((ID3D11Texture2D*)sourceTexture_)->Release();sourceTexture_=nullptr;}if(swapChain_){((IDXGISwapChain*)swapChain_)->Release();swapChain_=nullptr;}if(d3dContext_){((ID3D11DeviceContext*)d3dContext_)->Release();d3dContext_=nullptr;}if(d3dDevice_){((ID3D11Device*)d3dDevice_)->Release();d3dDevice_=nullptr;}
  if(d2dTarget_){((ID2D1DCRenderTarget*)d2dTarget_)->Release();d2dTarget_=nullptr;}if(d2dFactory_){((ID2D1Factory*)d2dFactory_)->Release();d2dFactory_=nullptr;}if(dwriteFactory_){((IDWriteFactory*)dwriteFactory_)->Release();dwriteFactory_=nullptr;}
  if(frameDC_){HDC dc=(HDC)frameDC_;if(frameOldBitmap_)SelectObject(dc,(HGDIOBJ)frameOldBitmap_);if(frameBitmap_)DeleteObject((HBITMAP)frameBitmap_);DeleteDC(dc);}frameDC_=frameBitmap_=frameOldBitmap_=frameBits_=nullptr;
  if(hwnd_){DestroyWindow((HWND)hwnd_);hwnd_=nullptr;} CoUninitialize();
}
#endif

bool Renderer::initialize(const RuntimeConfig& c){
  config_=c;
#ifdef _WIN32
  CoInitializeEx(nullptr, COINIT_MULTITHREADED); HINSTANCE inst=GetModuleHandleW(nullptr); WNDCLASSW wc{};wc.lpfnWndProc=PortWndProc;wc.hInstance=inst;wc.lpszClassName=L"OpenBORNativePort";wc.hCursor=LoadCursor(nullptr,IDC_ARROW);RegisterClassW(&wc);
  DWORD style=c.fullscreen?WS_POPUP:WS_OVERLAPPEDWINDOW;int x=c.fullscreen?0:CW_USEDEFAULT,y=c.fullscreen?0:CW_USEDEFAULT;HWND h=CreateWindowExW(0,wc.lpszClassName,L"OpenBOR Native Port",style|WS_VISIBLE,x,y,c.width,c.height,nullptr,nullptr,inst,nullptr);if(!h)return false;hwnd_=h;
  if(!createLogicalCanvas())return false; if(!initializeD3D11())backend_="win32-gdi-fallback";
#else
  backend_="headless-preview";
#endif
  return true;
}
bool Renderer::isRunning() const { return running_; }
bool Renderer::pumpEvents(){
#ifdef _WIN32
  MSG msg{};while(PeekMessageW(&msg,nullptr,0,0,PM_REMOVE)){if(msg.message==WM_QUIT){running_=false;return false;}TranslateMessage(&msg);DispatchMessageW(&msg);}
#endif
  return running_;
}
void Renderer::beginFrame(){
#ifdef _WIN32
  if(!frameBits_)return;auto* p=(unsigned char*)frameBits_;for(int y=0;y<config_.logicalHeight;++y)for(int x=0;x<config_.logicalWidth;++x){size_t i=((size_t)y*config_.logicalWidth+x)*4u;p[i]=30;p[i+1]=24;p[i+2]=24;p[i+3]=255;}
#endif
}
void Renderer::drawImage(const SpriteImage& img,int x,int y){
#ifdef _WIN32
  if(!frameDC_||img.width<=0||img.height<=0||img.bgra.empty())return;HDC dc=(HDC)frameDC_;BITMAPINFO bi{};bi.bmiHeader.biSize=sizeof(BITMAPINFOHEADER);bi.bmiHeader.biWidth=img.width;bi.bmiHeader.biHeight=-img.height;bi.bmiHeader.biPlanes=1;bi.bmiHeader.biBitCount=32;bi.bmiHeader.biCompression=BI_RGB;HDC mem=CreateCompatibleDC(dc);void* bits=nullptr;HBITMAP bmp=CreateDIBSection(dc,&bi,DIB_RGB_COLORS,&bits,nullptr,0);if(mem&&bmp&&bits){std::memcpy(bits,img.bgra.data(),img.bgra.size());HGDIOBJ old=SelectObject(mem,bmp);BLENDFUNCTION blend{AC_SRC_OVER,0,255,AC_SRC_ALPHA};AlphaBlend(dc,x,y,img.width,img.height,mem,0,0,img.width,img.height,blend);SelectObject(mem,old);}if(bmp)DeleteObject(bmp);if(mem)DeleteDC(mem);
#else
  (void)img;(void)x;(void)y;
#endif
}
void Renderer::drawSolidRect(int x,int y,int w,int h,unsigned char r,unsigned char g,unsigned char b){
#ifdef _WIN32
  if(!frameDC_||w<=0||h<=0)return;RECT rc{x,y,x+w,y+h};auto* rt=(ID2D1DCRenderTarget*)d2dTarget_;if(rt){RECT full{0,0,config_.logicalWidth,config_.logicalHeight};rt->BindDC((HDC)frameDC_,&full);rt->BeginDraw();ID2D1SolidColorBrush* brush=nullptr;rt->CreateSolidColorBrush(D2D1::ColorF(r/255.0f,g/255.0f,b/255.0f,1),&brush);if(brush){rt->FillRectangle(D2D1::RectF((FLOAT)x,(FLOAT)y,(FLOAT)(x+w),(FLOAT)(y+h)),brush);brush->Release();}rt->EndDraw();}else{HBRUSH brush=CreateSolidBrush(RGB(r,g,b));FillRect((HDC)frameDC_,&rc,brush);DeleteObject(brush);}
#else
  (void)x;(void)y;(void)w;(void)h;(void)r;(void)g;(void)b;
#endif
}
void Renderer::drawDot(int x,int y,unsigned int rgb){
  drawSolidRect(x,y,1,1,(unsigned char)((rgb>>16)&255),(unsigned char)((rgb>>8)&255),(unsigned char)(rgb&255));
}
void Renderer::drawLine(int x1,int y1,int x2,int y2,unsigned int rgb){
  int dx=std::abs(x2-x1),sx=x1<x2?1:-1,dy=-std::abs(y2-y1),sy=y1<y2?1:-1,err=dx+dy;
  for(;;){drawDot(x1,y1,rgb);if(x1==x2&&y1==y2)break;int e2=2*err;if(e2>=dy){err+=dy;x1+=sx;}if(e2<=dx){err+=dx;y1+=sy;}}
}
void Renderer::drawText(const std::string& text,int x,int y,int size,bool selected){
#ifdef _WIN32
  if(!frameDC_||text.empty())return;auto* rt=(ID2D1DCRenderTarget*)d2dTarget_;auto* dw=(IDWriteFactory*)dwriteFactory_;if(rt&&dw){RECT rc{0,0,config_.logicalWidth,config_.logicalHeight};rt->BindDC((HDC)frameDC_,&rc);IDWriteTextFormat* fmt=nullptr;dw->CreateTextFormat(L"Segoe UI",nullptr,selected?DWRITE_FONT_WEIGHT_BOLD:DWRITE_FONT_WEIGHT_NORMAL,DWRITE_FONT_STYLE_NORMAL,DWRITE_FONT_STRETCH_NORMAL,(FLOAT)std::max(6,size),L"pt-BR",&fmt);ID2D1SolidColorBrush* brush=nullptr;rt->CreateSolidColorBrush(selected?D2D1::ColorF(1.0f,.84f,.31f,1):D2D1::ColorF(.93f,.93f,.95f,1),&brush);auto w=widenUtf8(text);rt->BeginDraw();if(fmt&&brush)rt->DrawText(w.c_str(),(UINT32)w.size(),fmt,D2D1::RectF((FLOAT)x,(FLOAT)y,(FLOAT)config_.logicalWidth,(FLOAT)(y+size+8)),brush,D2D1_DRAW_TEXT_OPTIONS_CLIP);rt->EndDraw();if(brush)brush->Release();if(fmt)fmt->Release();}else{HDC dc=(HDC)frameDC_;SetBkMode(dc,TRANSPARENT);SetTextColor(dc,selected?RGB(255,215,80):RGB(238,238,242));HFONT font=CreateFontA(-std::max(8,size),0,0,0,selected?FW_BOLD:FW_NORMAL,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,ANTIALIASED_QUALITY,DEFAULT_PITCH|FF_DONTCARE,"Segoe UI");HGDIOBJ old=SelectObject(dc,font);TextOutA(dc,x,y,text.c_str(),(int)text.size());SelectObject(dc,old);DeleteObject(font);}
#else
  (void)text;(void)x;(void)y;(void)size;(void)selected;
#endif
}
static unsigned char clampByte(int v){return(unsigned char)std::clamp(v,0,255);}static unsigned char blendChannel(unsigned char src,unsigned char dst,int mode){const int s=(int)src,d=(int)dst;switch(mode){case 3:return clampByte(d<128?(2*s*d)/255:255-(2*(255-s)*(255-d))/255);case 4:return clampByte(s<128?(2*s*d)/255:255-(2*(255-s)*(255-d))/255);case 5:return clampByte(s>=255?255:std::min(255,(d*255)/std::max(1,255-s)));case 6:return(unsigned char)((s+d)/2);default:return src;}}
#ifdef _WIN32
static void drawOpenBORBlend(HDC dc,const SpriteImage& src,int x,int y,int mode){if(src.width<=0||src.height<=0||src.bgra.empty())return;RECT clip{0,0,32000,32000};int sx0=0,sy0=0,w=src.width,h=src.height;if(x<0){sx0=-x;w-=sx0;x=0;}if(y<0){sy0=-y;h-=sy0;y=0;}if(w<=0||h<=0)return;BITMAPINFO bi{};bi.bmiHeader.biSize=sizeof(BITMAPINFOHEADER);bi.bmiHeader.biWidth=w;bi.bmiHeader.biHeight=-h;bi.bmiHeader.biPlanes=1;bi.bmiHeader.biBitCount=32;bi.bmiHeader.biCompression=BI_RGB;HDC mem=CreateCompatibleDC(dc);void* bits=nullptr;HBITMAP bmp=CreateDIBSection(dc,&bi,DIB_RGB_COLORS,&bits,nullptr,0);if(!mem||!bmp||!bits){if(bmp)DeleteObject(bmp);if(mem)DeleteDC(mem);return;}HGDIOBJ old=SelectObject(mem,bmp);BitBlt(mem,0,0,w,h,dc,x,y,SRCCOPY);auto* dst=(unsigned char*)bits;for(int py=0;py<h;++py)for(int px=0;px<w;++px){size_t si=((size_t)(py+sy0)*src.width+(px+sx0))*4u,di=((size_t)py*w+px)*4u;unsigned a=src.bgra[si+3];if(!a)continue;unsigned char sb=(unsigned char)std::min(255u,(unsigned)src.bgra[si]*255u/a),sg=(unsigned char)std::min(255u,(unsigned)src.bgra[si+1]*255u/a),sr=(unsigned char)std::min(255u,(unsigned)src.bgra[si+2]*255u/a);unsigned char db=dst[di],dg=dst[di+1],dr=dst[di+2];unsigned weight=a;if(mode==1){unsigned lum=((unsigned)sr+(unsigned)sg+(unsigned)sb)/3u;weight=weight*lum/255u;}else if(mode==2){unsigned lum=((unsigned)sr+(unsigned)sg+(unsigned)sb)/3u;weight=weight*(255u-lum)/255u;}unsigned char rb=mode<=2?sb:blendChannel(sb,db,mode),rg=mode<=2?sg:blendChannel(sg,dg,mode),rr=mode<=2?sr:blendChannel(sr,dr,mode);dst[di]=(unsigned char)(((unsigned)rb*weight+(unsigned)db*(255u-weight))/255u);dst[di+1]=(unsigned char)(((unsigned)rg*weight+(unsigned)dg*(255u-weight))/255u);dst[di+2]=(unsigned char)(((unsigned)rr*weight+(unsigned)dr*(255u-weight))/255u);dst[di+3]=255;}BitBlt(dc,x,y,w,h,mem,0,0,SRCCOPY);SelectObject(mem,old);DeleteObject(bmp);DeleteDC(mem);}
#endif
static SpriteImage transformOpenBORSprite(const SpriteImage& src,const generated::DrawMethod& d,bool entityFlip){if(src.width<=0||src.height<=0||src.bgra.empty())return src;float sx=d.enabled?d.scaleX:1.0f,sy=d.enabled?d.scaleY:1.0f;bool fx=entityFlip^(d.enabled&&d.flipX)^(sx<0.0f);bool fy=(d.enabled&&d.flipY)^(sy<0.0f);sx=std::max(0.01f,std::abs(sx));sy=std::max(0.01f,std::abs(sy));int sw=std::max(1,(int)std::lround(src.width*sx)),sh=std::max(1,(int)std::lround(src.height*sy));SpriteImage scaled;scaled.width=sw;scaled.height=sh;scaled.bgra.assign((size_t)sw*sh*4,0);const float shear=d.enabled?d.shiftX:0.0f;for(int y=0;y<sh;++y){float srcY=(float)y/sy;int iy=std::clamp((int)srcY,0,src.height-1);if(fy)iy=src.height-1-iy;float rowShift=shear*((float)y-(float)sh*0.5f);for(int x=0;x<sw;++x){float ux=(float)x-rowShift;if(ux<0||ux>=sw)continue;int ix=std::clamp((int)(ux/sx),0,src.width-1);if(fx)ix=src.width-1-ix;size_t si=((size_t)iy*src.width+ix)*4u,di=((size_t)y*sw+x)*4u;unsigned char b=src.bgra[si],g=src.bgra[si+1],r=src.bgra[si+2],a=src.bgra[si+3];if(d.enabled&&d.fillColor>255&&a){unsigned int col=(unsigned int)d.fillColor;r=(unsigned char)((col>>16)&255);g=(unsigned char)((col>>8)&255);b=(unsigned char)(col&255);b=(unsigned char)((unsigned)b*a/255u);g=(unsigned char)((unsigned)g*a/255u);r=(unsigned char)((unsigned)r*a/255u);}scaled.bgra[di]=b;scaled.bgra[di+1]=g;scaled.bgra[di+2]=r;scaled.bgra[di+3]=a;}}int angle=d.enabled?d.rotate:0;if(d.enabled&&d.flipRotate&&entityFlip&&angle)angle=(360-angle)%360;if(angle==0)return scaled;const double rad=(double)angle*3.14159265358979323846/180.0,cs=std::cos(rad),sn=std::sin(rad);int rw=std::max(1,(int)std::ceil(std::abs(sw*cs)+std::abs(sh*sn))),rh=std::max(1,(int)std::ceil(std::abs(sw*sn)+std::abs(sh*cs)));SpriteImage rot;rot.width=rw;rot.height=rh;rot.bgra.assign((size_t)rw*rh*4,0);double cx=(sw-1)*0.5,cy=(sh-1)*0.5,dcx=(rw-1)*0.5,dcy=(rh-1)*0.5;for(int y=0;y<rh;++y)for(int x=0;x<rw;++x){double dx=x-dcx,dy=y-dcy;double ox=cs*dx+sn*dy+cx,oy=-sn*dx+cs*dy+cy;int ix=(int)std::lround(ox),iy=(int)std::lround(oy);if(ix<0||iy<0||ix>=sw||iy>=sh)continue;size_t si=((size_t)iy*sw+ix)*4u,di=((size_t)y*rw+x)*4u;std::memcpy(&rot.bgra[di],&scaled.bgra[si],4);}return rot;}
void Renderer::drawFrame(const SpriteImage& img,const generated::Frame& f,int originX,int originY,const RuntimeConfig& c,bool flipX){
#ifdef _WIN32
  if(!frameDC_)return;HDC dc=(HDC)frameDC_;auto rendered=transformOpenBORSprite(img,f.draw,flipX);float sx=f.draw.enabled?std::abs(f.draw.scaleX):1.0f,sy=f.draw.enabled?std::abs(f.draw.scaleY):1.0f;int scaledOffX=(int)std::lround(f.offsetX*sx),scaledOffY=(int)std::lround(f.offsetY*sy);int x=originX-scaledOffX,y=originY-scaledOffY;if(rendered.width>0&&rendered.height>0&&!rendered.bgra.empty()){if(f.draw.enabled&&f.draw.alphaMode>=1&&f.draw.alphaMode<=6)drawOpenBORBlend(dc,rendered,x,y,f.draw.alphaMode);else drawImage(rendered,x,y);}int baseX=flipX?originX-(img.width-f.offsetX):originX-f.offsetX,baseY=originY-f.offsetY;if(c.showBBox&&f.hasBBox){int bx=flipX?img.width-f.bbox.x-f.bbox.w:f.bbox.x;HPEN p=CreatePen(PS_SOLID,1,RGB(0,255,80));HGDIOBJ old=SelectObject(dc,p);SelectObject(dc,GetStockObject(NULL_BRUSH));Rectangle(dc,baseX+bx,baseY+f.bbox.y,baseX+bx+f.bbox.w,baseY+f.bbox.y+f.bbox.h);SelectObject(dc,old);DeleteObject(p);}if(c.showAttackBox&&f.hasAttack){int ax=flipX?img.width-f.attack.x-f.attack.w:f.attack.x;HPEN p=CreatePen(PS_SOLID,1,RGB(255,60,60));HGDIOBJ old=SelectObject(dc,p);SelectObject(dc,GetStockObject(NULL_BRUSH));Rectangle(dc,baseX+ax,baseY+f.attack.y,baseX+ax+f.attack.w,baseY+f.attack.y+f.attack.h);SelectObject(dc,old);DeleteObject(p);}
#else
  (void)img;(void)f;(void)originX;(void)originY;(void)c;(void)flipX;
#endif
}
#ifdef _WIN32
void Renderer::presentWithGdiFallback(){if(!hwnd_||!frameBits_)return;HWND h=(HWND)hwnd_;HDC dc=GetDC(h);RECT rc{};GetClientRect(h,&rc);int cw=std::max(1L,rc.right-rc.left),ch=std::max(1L,rc.bottom-rc.top);int dw=cw,dh=ch,dx=0,dy=0,sx=0,sy=0,sw=config_.logicalWidth,sh=config_.logicalHeight;float srcAspect=(float)config_.logicalWidth/(float)config_.logicalHeight,targetAspect=(float)cw/(float)ch;if(config_.fill169){if(targetAspect>srcAspect){sh=std::max(1,(int)std::lround(config_.logicalWidth/targetAspect));sy=(config_.logicalHeight-sh)/2;}else{sw=std::max(1,(int)std::lround(config_.logicalHeight*targetAspect));sx=(config_.logicalWidth-sw)/2;}}else if(config_.keepAspect43||config_.pixelPerfect||config_.integerScale>0){int scale=config_.integerScale>0?config_.integerScale:std::max(1,std::min(cw/config_.logicalWidth,ch/config_.logicalHeight));if(config_.pixelPerfect||config_.integerScale>0){dw=config_.logicalWidth*scale;dh=config_.logicalHeight*scale;}else if((float)cw/ch>srcAspect){dh=ch;dw=(int)(dh*srcAspect);}else{dw=cw;dh=(int)(dw/srcAspect);}dx=(cw-dw)/2;dy=(ch-dh)/2;}HBRUSH black=CreateSolidBrush(RGB(0,0,0));FillRect(dc,&rc,black);DeleteObject(black);SetStretchBltMode(dc,config_.textureFilter=="nearest"?COLORONCOLOR:HALFTONE);BITMAPINFO bi{};bi.bmiHeader.biSize=sizeof(BITMAPINFOHEADER);bi.bmiHeader.biWidth=config_.logicalWidth;bi.bmiHeader.biHeight=-config_.logicalHeight;bi.bmiHeader.biPlanes=1;bi.bmiHeader.biBitCount=32;bi.bmiHeader.biCompression=BI_RGB;StretchDIBits(dc,dx,dy,dw,dh,sx,sy,sw,sh,frameBits_,&bi,DIB_RGB_COLORS,SRCCOPY);ReleaseDC(h,dc);}
#endif
void Renderer::endFrame(){
#ifdef _WIN32
  auto* dev=(ID3D11Device*)d3dDevice_;auto* ctx=(ID3D11DeviceContext*)d3dContext_;auto* sc=(IDXGISwapChain*)swapChain_;if(!dev||!ctx||!sc||!frameBits_){presentWithGdiFallback();return;}auto* src=(ID3D11Texture2D*)sourceTexture_;ctx->UpdateSubresource(src,0,nullptr,frameBits_,(UINT)frameStride_,0);ID3D11Texture2D* back=nullptr;if(FAILED(sc->GetBuffer(0,__uuidof(ID3D11Texture2D),(void**)&back))){presentWithGdiFallback();return;}ID3D11RenderTargetView* rtv=nullptr;dev->CreateRenderTargetView(back,nullptr,&rtv);back->Release();if(!rtv){presentWithGdiFallback();return;}float clear[4]={0,0,0,1};ctx->ClearRenderTargetView(rtv,clear);RECT rc{};GetClientRect((HWND)hwnd_,&rc);int cw=std::max(1L,rc.right-rc.left),ch=std::max(1L,rc.bottom-rc.top);float vw=(float)cw,vh=(float)ch,vx=0,vy=0;ShaderParams sp;sp.texelX=1.0f/config_.logicalWidth;sp.texelY=1.0f/config_.logicalHeight;sp.sharpen=config_.sharpen;sp.contrast=config_.contrast;sp.saturation=config_.saturation;sp.bloom=config_.bloom?0.28f:0.0f;sp.scanline=(config_.scanlines||config_.crt)?0.55f:0.0f;sp.curvature=config_.crtCurvature?1.0f:0.0f;sp.banding=config_.reduceBanding?1.0f:0.0f;sp.mode=config_.upscaleMode=="sharp-bilinear"?1.0f:(config_.upscaleMode=="cas"?2.0f:(config_.upscaleMode=="xbr"||config_.upscaleMode=="xbrz-like"?3.0f:0.0f));sp.time=(float)(GetTickCount64()%100000)/1000.0f;sp.unused=config_.crt?1.0f:0.0f;float srcAspect=(float)config_.logicalWidth/(float)config_.logicalHeight,targetAspect=(float)cw/(float)ch;if(config_.fill169){if(targetAspect>srcAspect){sp.uvScaleY=srcAspect/targetAspect;sp.uvOffsetY=(1.0f-sp.uvScaleY)*0.5f;}else{sp.uvScaleX=targetAspect/srcAspect;sp.uvOffsetX=(1.0f-sp.uvScaleX)*0.5f;}}else if(config_.keepAspect43||config_.pixelPerfect||config_.integerScale>0){if(config_.integerScale>0||config_.pixelPerfect){int scale=config_.integerScale>0?config_.integerScale:std::max(1,std::min(cw/config_.logicalWidth,ch/config_.logicalHeight));vw=(float)(config_.logicalWidth*scale);vh=(float)(config_.logicalHeight*scale);}else if(targetAspect>srcAspect){vh=(float)ch;vw=vh*srcAspect;}else{vw=(float)cw;vh=vw/srcAspect;}vx=(cw-vw)*0.5f;vy=(ch-vh)*0.5f;}D3D11_VIEWPORT vp{vx,vy,vw,vh,0,1};ctx->RSSetViewports(1,&vp);ctx->OMSetRenderTargets(1,&rtv,nullptr);ctx->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);ctx->VSSetShader((ID3D11VertexShader*)vertexShader_,nullptr,0);ctx->PSSetShader((ID3D11PixelShader*)pixelShader_,nullptr,0);ID3D11ShaderResourceView* srv=(ID3D11ShaderResourceView*)sourceSRV_;ctx->PSSetShaderResources(0,1,&srv);ID3D11SamplerState* samp=config_.textureFilter=="nearest"?(ID3D11SamplerState*)samplerPoint_:(ID3D11SamplerState*)samplerLinear_;ctx->PSSetSamplers(0,1,&samp);D3D11_MAPPED_SUBRESOURCE map{};if(SUCCEEDED(ctx->Map((ID3D11Buffer*)constantBuffer_,0,D3D11_MAP_WRITE_DISCARD,0,&map))){std::memcpy(map.pData,&sp,sizeof(sp));ctx->Unmap((ID3D11Buffer*)constantBuffer_,0);}ID3D11Buffer* cb=(ID3D11Buffer*)constantBuffer_;ctx->PSSetConstantBuffers(0,1,&cb);ctx->Draw(3,0);ID3D11ShaderResourceView* nullSrv=nullptr;ctx->PSSetShaderResources(0,1,&nullSrv);rtv->Release();sc->Present(config_.vsync?1:0,0);
#endif
}
bool Renderer::loadSprite(const std::filesystem::path& path,SpriteImage& out){
#ifdef _WIN32
  IWICImagingFactory* factory=nullptr;IWICBitmapDecoder* dec=nullptr;IWICBitmapFrameDecode* frame=nullptr;IWICFormatConverter* conv=nullptr;if(FAILED(CoCreateInstance(CLSID_WICImagingFactory,nullptr,CLSCTX_INPROC_SERVER,IID_PPV_ARGS(&factory))))return false;std::wstring w=path.wstring();HRESULT hr=factory->CreateDecoderFromFilename(w.c_str(),nullptr,GENERIC_READ,WICDecodeMetadataCacheOnLoad,&dec);if(SUCCEEDED(hr))hr=dec->GetFrame(0,&frame);if(SUCCEEDED(hr))hr=factory->CreateFormatConverter(&conv);if(SUCCEEDED(hr))hr=conv->Initialize(frame,GUID_WICPixelFormat32bppBGRA,WICBitmapDitherTypeNone,nullptr,0.0,WICBitmapPaletteTypeCustom);UINT wi=0,he=0;if(SUCCEEDED(hr))hr=conv->GetSize(&wi,&he);if(SUCCEEDED(hr)){out.width=(int)wi;out.height=(int)he;out.bgra.resize((size_t)wi*he*4);hr=conv->CopyPixels(nullptr,wi*4,(UINT)out.bgra.size(),out.bgra.data());}if(SUCCEEDED(hr)&&frame&&!out.bgra.empty()){IWICPalette* palette=nullptr;bool paletted=false;if(SUCCEEDED(factory->CreatePalette(&palette))&&SUCCEEDED(frame->CopyPalette(palette))){UINT count=0;palette->GetColorCount(&count);if(count>0){WICColor color0=0;UINT actual=0;if(SUCCEEDED(palette->GetColors(1,&color0,&actual))&&actual==1){paletted=true;const unsigned char p0b=(unsigned char)(color0&0xFF),p0g=(unsigned char)((color0>>8)&0xFF),p0r=(unsigned char)((color0>>16)&0xFF);for(size_t i=0;i+3<out.bgra.size();i+=4){auto&b=out.bgra[i];auto&g=out.bgra[i+1];auto&r=out.bgra[i+2];auto&a=out.bgra[i+3];if(config_.openborPaletteIndex0Transparency&&r==p0r&&g==p0g&&b==p0b)a=0;b=(unsigned char)((unsigned)b*a/255u);g=(unsigned char)((unsigned)g*a/255u);r=(unsigned char)((unsigned)r*a/255u);}}}}if(!paletted){for(size_t i=0;i+3<out.bgra.size();i+=4){auto&b=out.bgra[i];auto&g=out.bgra[i+1];auto&r=out.bgra[i+2];auto&a=out.bgra[i+3];b=(unsigned char)((unsigned)b*a/255u);g=(unsigned char)((unsigned)g*a/255u);r=(unsigned char)((unsigned)r*a/255u);}}if(palette)palette->Release();}if(conv)conv->Release();if(frame)frame->Release();if(dec)dec->Release();if(factory)factory->Release();return SUCCEEDED(hr);
#else
  (void)path;out.width=64;out.height=64;out.bgra.assign(64*64*4,255);return std::filesystem::exists(path);
#endif
}
const std::string& Renderer::backend() const { return backend_; }
)CPP";

    std::ofstream audioDecoderH(include / "AudioDecoder.hpp");
    audioDecoderH << R"CPP(#pragma once
#include <cstdint>
#include <filesystem>
#include <string>
#include <vector>
struct DecodedAudio {
  int sampleRate = 22050;
  int channels = 1;
  std::vector<std::int16_t> pcm;
  std::uint32_t loopStartFrames = 0;
  std::uint32_t loopLengthFrames = 0;
  bool hasLoop = false;
  std::string format;
};
class AudioDecoder {
public:
  static bool decodeFile(const std::filesystem::path&, DecodedAudio&, std::string& error);
  // Legacy OpenBOR .bor music: 160-byte metadata header followed by Intel/IMA ADPCM.
  // Never pass .bor bytes directly to a PCM backend.
  static bool decodeOpenBorBor(const std::filesystem::path&, DecodedAudio&, std::string& error);
  static bool decodeWav(const std::filesystem::path&, DecodedAudio&, std::string& error);
#ifdef _WIN32
  static bool decodeMediaFoundation(const std::filesystem::path&, DecodedAudio&, std::string& error);
#endif
};
)CPP";

    std::ofstream audioDecoderCpp(src / "AudioDecoder.cpp");
    audioDecoderCpp << R"CPP(#include "AudioDecoder.hpp"
#include <algorithm>
#include <array>
#include <cctype>
#include <cmath>
#include <cstring>
#include <fstream>
#include <iterator>
#ifdef _WIN32
#define NOMINMAX
#include <windows.h>
#include <mfapi.h>
#include <mfidl.h>
#include <mfreadwrite.h>
#endif

namespace {
constexpr std::array<int,16> kIndexTable={-1,-1,-1,-1,2,4,6,8,-1,-1,-1,-1,2,4,6,8};
constexpr std::array<int,89> kStepTable={
7,8,9,10,11,12,13,14,16,17,19,21,23,25,28,31,34,37,41,45,50,55,60,66,73,80,88,97,107,118,
130,143,157,173,190,209,230,253,279,307,337,371,408,449,494,544,598,658,724,796,876,963,1060,1166,
1282,1411,1552,1707,1878,2066,2272,2499,2749,3024,3327,3660,4026,4428,4871,5358,5894,6484,7132,7845,
8630,9493,10442,11487,12635,13899,15289,16818,18500,20350,22385,24623,27086,29794,32767};
struct State { int predicted=0; int index=0; };
std::int16_t decodeNibble(unsigned nibble, State& st){
  int step=kStepTable[(std::size_t)st.index], diff=step>>3;
  if(nibble&4) diff+=step; if(nibble&2) diff+=step>>1; if(nibble&1) diff+=step>>2;
  if(nibble&8) st.predicted-=diff; else st.predicted+=diff;
  st.predicted=std::clamp(st.predicted,-32768,32767);
  st.index=std::clamp(st.index+kIndexTable[nibble&0x0f],0,88);
  return (std::int16_t)st.predicted;
}
std::uint16_t u16(const unsigned char* p){ return (std::uint16_t)(p[0] | (p[1]<<8)); }
std::uint32_t u32(const unsigned char* p){ return (std::uint32_t)p[0] | ((std::uint32_t)p[1]<<8) | ((std::uint32_t)p[2]<<16) | ((std::uint32_t)p[3]<<24); }
std::string lowerExt(std::filesystem::path p){ auto s=p.extension().string(); for(auto& c:s)c=(char)std::tolower((unsigned char)c); return s; }
}

bool AudioDecoder::decodeFile(const std::filesystem::path& path, DecodedAudio& out, std::string& error){
  auto ext=lowerExt(path);
  if(ext==".bor") return decodeOpenBorBor(path,out,error);
  if(ext==".wav" || ext==".wave") return decodeWav(path,out,error);
#ifdef _WIN32
  if(ext==".mp3" || ext==".flac" || ext==".ogg" || ext==".oga" || ext==".m4a" || ext==".aac") return decodeMediaFoundation(path,out,error);
#else
  if(ext==".mp3" || ext==".flac" || ext==".ogg" || ext==".oga" || ext==".m4a" || ext==".aac") { error="compressed audio requires the Windows Media Foundation backend in this generated runtime"; return false; }
#endif
  error="unsupported audio extension: "+ext; return false;
}

#ifdef _WIN32
bool AudioDecoder::decodeMediaFoundation(const std::filesystem::path& path, DecodedAudio& out, std::string& error){
  HRESULT hr=MFStartup(MF_VERSION,MFSTARTUP_LITE);if(FAILED(hr)){error="MFStartup failed for compressed audio";return false;}
  IMFSourceReader* reader=nullptr;IMFMediaType* requested=nullptr;IMFMediaType* actual=nullptr;bool ok=false;
  auto cleanup=[&](){if(actual)actual->Release();if(requested)requested->Release();if(reader)reader->Release();MFShutdown();};
  hr=MFCreateSourceReaderFromURL(path.wstring().c_str(),nullptr,&reader);if(FAILED(hr)){error="Media Foundation could not open compressed audio (codec may be unavailable)";cleanup();return false;}
  hr=MFCreateMediaType(&requested);if(SUCCEEDED(hr))hr=requested->SetGUID(MF_MT_MAJOR_TYPE,MFMediaType_Audio);if(SUCCEEDED(hr))hr=requested->SetGUID(MF_MT_SUBTYPE,MFAudioFormat_PCM);if(SUCCEEDED(hr))hr=requested->SetUINT32(MF_MT_AUDIO_BITS_PER_SAMPLE,16);if(SUCCEEDED(hr))hr=reader->SetCurrentMediaType(MF_SOURCE_READER_FIRST_AUDIO_STREAM,nullptr,requested);
  if(FAILED(hr)){error="Media Foundation could not negotiate PCM output";cleanup();return false;}
  hr=reader->GetCurrentMediaType(MF_SOURCE_READER_FIRST_AUDIO_STREAM,&actual);if(FAILED(hr)){error="Media Foundation did not expose decoded audio format";cleanup();return false;}
  UINT32 channels=MFGetAttributeUINT32(actual,MF_MT_AUDIO_NUM_CHANNELS,1),rate=MFGetAttributeUINT32(actual,MF_MT_AUDIO_SAMPLES_PER_SECOND,22050),bits=MFGetAttributeUINT32(actual,MF_MT_AUDIO_BITS_PER_SAMPLE,16);
  if(channels<1||channels>2||rate==0||bits!=16){error="Media Foundation PCM output is not supported (expected mono/stereo 16-bit)";cleanup();return false;}
  out=DecodedAudio{};out.channels=(int)channels;out.sampleRate=(int)rate;out.format="media-foundation-pcm16";std::vector<unsigned char> bytes;
  for(;;){DWORD stream=0,flags=0;LONGLONG ts=0;IMFSample* sample=nullptr;hr=reader->ReadSample(MF_SOURCE_READER_FIRST_AUDIO_STREAM,0,&stream,&flags,&ts,&sample);if(FAILED(hr)){if(sample)sample->Release();error="Media Foundation ReadSample failed";break;}if(flags&MF_SOURCE_READERF_ENDOFSTREAM){if(sample)sample->Release();ok=true;break;}if(flags&MF_SOURCE_READERF_CURRENTMEDIATYPECHANGED){if(actual){actual->Release();actual=nullptr;}reader->GetCurrentMediaType(MF_SOURCE_READER_FIRST_AUDIO_STREAM,&actual);if(actual){channels=MFGetAttributeUINT32(actual,MF_MT_AUDIO_NUM_CHANNELS,channels);rate=MFGetAttributeUINT32(actual,MF_MT_AUDIO_SAMPLES_PER_SECOND,rate);bits=MFGetAttributeUINT32(actual,MF_MT_AUDIO_BITS_PER_SAMPLE,bits);out.channels=(int)channels;out.sampleRate=(int)rate;if(bits!=16||channels<1||channels>2){if(sample)sample->Release();error="Media Foundation changed to unsupported PCM format";break;}}}
    if(sample){IMFMediaBuffer* buffer=nullptr;hr=sample->ConvertToContiguousBuffer(&buffer);if(SUCCEEDED(hr)&&buffer){BYTE* data=nullptr;DWORD maxLen=0,len=0;hr=buffer->Lock(&data,&maxLen,&len);if(SUCCEEDED(hr)&&data&&len){auto old=bytes.size();bytes.resize(old+len);std::memcpy(bytes.data()+old,data,len);buffer->Unlock();}buffer->Release();}sample->Release();if(FAILED(hr)){error="Media Foundation sample buffer conversion failed";break;}}
  }
  if(ok){if(bytes.size()<2){error="decoded compressed audio contained no PCM samples";ok=false;}else{out.pcm.resize(bytes.size()/2);std::memcpy(out.pcm.data(),bytes.data(),out.pcm.size()*2);}}
  cleanup();return ok;
}
#endif

bool AudioDecoder::decodeOpenBorBor(const std::filesystem::path& path, DecodedAudio& out, std::string& error){
  std::ifstream f(path,std::ios::binary); if(!f){ error="cannot open .bor music"; return false; }
  std::vector<unsigned char> bytes((std::istreambuf_iterator<char>(f)),{});
  constexpr std::size_t kHeader=160;
  if(bytes.size()<=kHeader){ error="invalid OpenBOR .bor: file is smaller than 160-byte header"; return false; }

  // Classic WAV2BOR input was normally 16-bit PCM, mono, 22050 Hz. Some later tools/ports
  // used variants, but there is no safe universal channel flag we can infer from arbitrary
  // legacy files. Until a verified header variant says otherwise, mono/22050 is deliberately
  // chosen over guessing stereo and corrupting playback.
  out=DecodedAudio{}; out.sampleRate=22050; out.channels=1; out.format="openbor-bor-ima-adpcm-mono";
  out.pcm.reserve((bytes.size()-kHeader)*2); State st{};
  for(std::size_t i=kHeader;i<bytes.size();++i){ const unsigned b=bytes[i]; out.pcm.push_back(decodeNibble((b>>4)&0x0f,st)); out.pcm.push_back(decodeNibble(b&0x0f,st)); }
  if(out.pcm.empty()){ error="OpenBOR .bor contains no ADPCM payload"; return false; }
  return true;
}

bool AudioDecoder::decodeWav(const std::filesystem::path& path, DecodedAudio& out, std::string& error){
  std::ifstream f(path,std::ios::binary); if(!f){ error="cannot open WAV"; return false; }
  std::vector<unsigned char> b((std::istreambuf_iterator<char>(f)),{});
  if(b.size()<44 || std::memcmp(b.data(),"RIFF",4)!=0 || std::memcmp(b.data()+8,"WAVE",4)!=0){ error="invalid RIFF/WAVE file"; return false; }
  std::uint16_t tag=0,channels=0,bits=0; std::uint32_t rate=0; const unsigned char* data=nullptr; std::size_t dataSize=0;
  std::uint32_t loopStart=0, loopEnd=0; bool haveLoop=false;
  for(std::size_t pos=12;pos+8<=b.size();){
    const char* id=(const char*)&b[pos]; std::uint32_t size=u32(&b[pos+4]); std::size_t body=pos+8; if(body+size>b.size()) break;
    if(std::memcmp(id,"fmt ",4)==0 && size>=16){ tag=u16(&b[body]); channels=u16(&b[body+2]); rate=u32(&b[body+4]); bits=u16(&b[body+14]); }
    else if(std::memcmp(id,"data",4)==0){ data=&b[body]; dataSize=size; }
    else if(std::memcmp(id,"smpl",4)==0 && size>=60){
      auto loops=u32(&b[body+28]); if(loops>0 && size>=60){ loopStart=u32(&b[body+44]); loopEnd=u32(&b[body+48]); haveLoop=loopEnd>=loopStart; }
    }
    pos=body+size+(size&1u);
  }
  if(!data||!dataSize||!channels||!rate){ error="WAV missing fmt/data chunk"; return false; }
  if(tag!=1 && tag!=3){ error="WAV codec is not PCM/IEEE-float"; return false; }
  if(tag==1 && bits!=8 && bits!=16 && bits!=24 && bits!=32){ error="WAV PCM bit depth must be 8/16/24/32"; return false; }
  if(tag==3 && bits!=32){ error="WAV IEEE-float must be 32-bit"; return false; }
  if(channels>2){ error="WAV channel count >2 is not supported by preview runtime"; return false; }
  out=DecodedAudio{}; out.sampleRate=(int)rate; out.channels=(int)channels; out.format=tag==3?"wav-float32":("wav-pcm"+std::to_string(bits));
  if(tag==3){
    out.pcm.reserve(dataSize/4);for(std::size_t i=0;i+3<dataSize;i+=4){float f32=0;std::memcpy(&f32,data+i,4);f32=std::clamp(f32,-1.0f,1.0f);out.pcm.push_back((std::int16_t)std::lround(f32*32767.0f));}
  } else if(bits==32){
    out.pcm.reserve(dataSize/4);for(std::size_t i=0;i+3<dataSize;i+=4){std::int32_t v=(std::int32_t)u32(data+i);out.pcm.push_back((std::int16_t)(v>>16));}
  } else if(bits==24){
    out.pcm.reserve(dataSize/3);for(std::size_t i=0;i+2<dataSize;i+=3){std::int32_t v=(std::int32_t)(data[i]|(data[i+1]<<8)|(data[i+2]<<16));if(v&0x800000)v|=~0xFFFFFF;out.pcm.push_back((std::int16_t)(v>>8));}
  } else if(bits==16){
    auto samples=dataSize/2; out.pcm.reserve(samples);
    for(std::size_t i=0;i+1<dataSize;i+=2) out.pcm.push_back((std::int16_t)u16(data+i));
  } else {
    out.pcm.reserve(dataSize); for(std::size_t i=0;i<dataSize;++i) out.pcm.push_back((std::int16_t)(((int)data[i]-128)<<8));
  }
  if(haveLoop){ out.hasLoop=true; out.loopStartFrames=loopStart; out.loopLengthFrames=loopEnd-loopStart+1; }
  if(out.pcm.empty()){ error="WAV contains no PCM samples"; return false; }
  return true;
}
)CPP";

    std::ofstream audioH(include / "AudioSystem.hpp");
    audioH << R"CPP(#pragma once
#include "RuntimeConfig.hpp"
#include <random>
#include "AudioDecoder.hpp"
#include <filesystem>
#include <memory>
#include <string>
#include <vector>
class AudioSystem {
public:
  ~AudioSystem();
  bool initialize(const RuntimeConfig&);
  bool playMusic(const std::filesystem::path&, bool loop=true);
  bool playEffect(const std::filesystem::path&, float gain=1.0f, bool loop=false, float speed=1.0f);
  void stopMusic();
  void pauseMusic(bool paused);
  void setMasterVolume(float);
  void setMusicVolume(float);
  void setEffectsVolume(float);
  float masterVolume() const { return config_.masterVolume; }
  float musicVolume() const { return config_.musicVolume; }
  float effectsVolume() const { return config_.effectsVolume; }
  const std::string& lastError() const { return error_; }
private:
  void applyVolumes();
  void cleanupEffects();
  RuntimeConfig config_{};
  std::string error_;
#ifdef _WIN32
  struct ActiveEffect { void* voice=nullptr; std::shared_ptr<DecodedAudio> audio; float gain=1.0f; };
  void* xaudio_ = nullptr;
  void* mastering_ = nullptr;
  void* musicVoice_ = nullptr;
  std::vector<ActiveEffect> effectVoices_;
#endif
  bool musicPaused_ = false;
  DecodedAudio musicBuffer_{};
};
)CPP";

    std::ofstream audioCpp(src / "AudioSystem.cpp");
    audioCpp << R"CPP(#include "AudioSystem.hpp"
#include <algorithm>
#include <cctype>
#include <iostream>
#ifdef _WIN32
#define NOMINMAX
#include <windows.h>
#include <xaudio2.h>
#endif

AudioSystem::~AudioSystem(){
#ifdef _WIN32
  for(auto& e:effectVoices_) if(e.voice) ((IXAudio2SourceVoice*)e.voice)->DestroyVoice();
  effectVoices_.clear();
  if(musicVoice_){ ((IXAudio2SourceVoice*)musicVoice_)->DestroyVoice(); musicVoice_=nullptr; }
  if(mastering_){ ((IXAudio2MasteringVoice*)mastering_)->DestroyVoice(); mastering_=nullptr; }
  if(xaudio_){ ((IXAudio2*)xaudio_)->Release(); xaudio_=nullptr; }
#endif
}
bool AudioSystem::initialize(const RuntimeConfig& c){
  config_=c;
#ifdef _WIN32
  IXAudio2* xa=nullptr; HRESULT hr=XAudio2Create(&xa,0,XAUDIO2_DEFAULT_PROCESSOR);
  if(FAILED(hr)){ error_="XAudio2Create failed"; return false; }
  IXAudio2MasteringVoice* mv=nullptr; hr=xa->CreateMasteringVoice(&mv);
  if(FAILED(hr)){ xa->Release(); error_="CreateMasteringVoice failed"; return false; }
  xaudio_=xa; mastering_=mv;
#endif
  return true;
}
static void fillFormat(const DecodedAudio& a,
#ifdef _WIN32
WAVEFORMATEX& fmt
#else
int& fmt
#endif
){
#ifdef _WIN32
  fmt={}; fmt.wFormatTag=WAVE_FORMAT_PCM; fmt.nChannels=(WORD)a.channels; fmt.nSamplesPerSec=a.sampleRate; fmt.wBitsPerSample=16;
  fmt.nBlockAlign=(WORD)(fmt.nChannels*2); fmt.nAvgBytesPerSec=fmt.nSamplesPerSec*fmt.nBlockAlign;
#else
  (void)a; (void)fmt;
#endif
}
bool AudioSystem::playMusic(const std::filesystem::path& path, bool loop){
  error_.clear(); auto ext=path.extension().string(); for(auto& c:ext)c=(char)std::tolower((unsigned char)c);
  if(ext==".bor" && !config_.openborBorAdpcm){ error_="OpenBOR .bor ADPCM decoder disabled"; return false; }
  if(!AudioDecoder::decodeFile(path,musicBuffer_,error_)) return false;
#ifdef _WIN32
  auto* xa=(IXAudio2*)xaudio_; if(!xa){ error_="audio system not initialized"; return false; }
  if(musicVoice_){ ((IXAudio2SourceVoice*)musicVoice_)->DestroyVoice(); musicVoice_=nullptr; }
  WAVEFORMATEX fmt{}; fillFormat(musicBuffer_,fmt); IXAudio2SourceVoice* voice=nullptr;
  HRESULT hr=xa->CreateSourceVoice(&voice,&fmt); if(FAILED(hr)){ error_="CreateSourceVoice(music) failed"; return false; }
  XAUDIO2_BUFFER buf{}; buf.AudioBytes=(UINT32)(musicBuffer_.pcm.size()*sizeof(std::int16_t)); buf.pAudioData=(const BYTE*)musicBuffer_.pcm.data(); buf.Flags=XAUDIO2_END_OF_STREAM;
  if(loop){
    if(musicBuffer_.hasLoop && musicBuffer_.loopLengthFrames>0){ buf.LoopBegin=musicBuffer_.loopStartFrames; buf.LoopLength=musicBuffer_.loopLengthFrames; }
    buf.LoopCount=XAUDIO2_LOOP_INFINITE;
  }
  hr=voice->SubmitSourceBuffer(&buf); if(FAILED(hr)){ voice->DestroyVoice(); error_="SubmitSourceBuffer(music) failed"; return false; }
  musicVoice_=voice; musicPaused_=false; applyVolumes(); hr=voice->Start(0); if(FAILED(hr)){ voice->DestroyVoice(); musicVoice_=nullptr; error_="XAudio2 music start failed"; return false; }
#else
  (void)loop; std::cout<<"Decoded music: "<<musicBuffer_.format<<" "<<musicBuffer_.channels<<"ch "<<musicBuffer_.sampleRate<<"Hz frames="<<(musicBuffer_.pcm.size()/std::max(1,musicBuffer_.channels))<<"\n";
#endif
  return true;
}
void AudioSystem::cleanupEffects(){
#ifdef _WIN32
  for(auto it=effectVoices_.begin();it!=effectVoices_.end();){auto* v=(IXAudio2SourceVoice*)it->voice;XAUDIO2_VOICE_STATE state{};if(v)v->GetState(&state);if(!v||state.BuffersQueued==0){if(v)v->DestroyVoice();it=effectVoices_.erase(it);}else ++it;}
#endif
}
bool AudioSystem::playEffect(const std::filesystem::path& path,float gain,bool loop,float speed){
  error_.clear(); auto decoded=std::make_shared<DecodedAudio>(); if(!AudioDecoder::decodeFile(path,*decoded,error_)) return false;
#ifdef _WIN32
  auto* xa=(IXAudio2*)xaudio_; if(!xa){ error_="audio system not initialized"; return false; } cleanupEffects();
  WAVEFORMATEX fmt{}; fillFormat(*decoded,fmt); IXAudio2SourceVoice* voice=nullptr;
  HRESULT hr=xa->CreateSourceVoice(&voice,&fmt,0,2.0f); if(FAILED(hr)){ error_="CreateSourceVoice(effect) failed"; return false; }
  XAUDIO2_BUFFER buf{}; buf.AudioBytes=(UINT32)(decoded->pcm.size()*sizeof(std::int16_t)); buf.pAudioData=(const BYTE*)decoded->pcm.data(); buf.Flags=XAUDIO2_END_OF_STREAM; if(loop)buf.LoopCount=XAUDIO2_LOOP_INFINITE;
  hr=voice->SubmitSourceBuffer(&buf); if(FAILED(hr)){ voice->DestroyVoice(); error_="SubmitSourceBuffer(effect) failed"; return false; }
  voice->SetVolume(std::clamp(config_.masterVolume*config_.effectsVolume*gain,0.0f,2.0f)); voice->SetFrequencyRatio(std::clamp(speed,0.5f,2.0f));
  hr=voice->Start(0); if(FAILED(hr)){ voice->DestroyVoice(); error_="XAudio2 effect start failed"; return false; } effectVoices_.push_back({voice,decoded,gain});
#else
  (void)gain;(void)loop;(void)speed;std::cout<<"Decoded effect: "<<decoded->format<<" "<<decoded->channels<<"ch "<<decoded->sampleRate<<"Hz\n";
#endif
  return true;
}
void AudioSystem::stopMusic(){
#ifdef _WIN32
  if(musicVoice_) ((IXAudio2SourceVoice*)musicVoice_)->Stop(0);
#endif
  musicPaused_=false;
}
void AudioSystem::pauseMusic(bool paused){
#ifdef _WIN32
  if(musicVoice_){ if(paused)((IXAudio2SourceVoice*)musicVoice_)->Stop(0); else ((IXAudio2SourceVoice*)musicVoice_)->Start(0); }
#endif
  musicPaused_=paused;
}
void AudioSystem::applyVolumes(){
#ifdef _WIN32
  if(musicVoice_) ((IXAudio2SourceVoice*)musicVoice_)->SetVolume(std::clamp(config_.masterVolume*config_.musicVolume,0.0f,1.0f));
  cleanupEffects(); for(auto& e:effectVoices_) if(e.voice) ((IXAudio2SourceVoice*)e.voice)->SetVolume(std::clamp(config_.masterVolume*config_.effectsVolume*e.gain,0.0f,2.0f));
#endif
}
void AudioSystem::setMasterVolume(float v){ config_.masterVolume=std::clamp(v,0.0f,1.0f); applyVolumes(); }
void AudioSystem::setMusicVolume(float v){ config_.musicVolume=std::clamp(v,0.0f,1.0f); applyVolumes(); }
void AudioSystem::setEffectsVolume(float v){ config_.effectsVolume=std::clamp(v,0.0f,1.0f); applyVolumes(); }
)CPP";

    std::ofstream player(include / "AnimationPlayer.hpp");
    player << R"CPP(#pragma once
#include "../generated/GeneratedCharacters.hpp"
#include <cstddef>
class AnimationPlayer {
public:
  void setAnimation(const generated::Animation* animation);
  void update(int ticks=1);
  void setFrame(std::size_t frameIndex);
  const generated::Frame* frame() const;
  const generated::Animation* animation() const { return animation_; }
  std::size_t frameIndex() const { return frameIndex_; }
  bool finished() const { return finished_; }
private:
  const generated::Animation* animation_ = nullptr;
  std::size_t frameIndex_ = 0;
  int tick_ = 0;
  bool finished_ = false;
};
)CPP";
    std::ofstream playerCpp(src / "AnimationPlayer.cpp");
    playerCpp << R"CPP(#include "AnimationPlayer.hpp"
#include <algorithm>
void AnimationPlayer::setAnimation(const generated::Animation* a){ animation_=a; frameIndex_=0; tick_=0; finished_=false; }
void AnimationPlayer::setFrame(std::size_t frameIndex){ if(!animation_||animation_->frameCount==0)return;frameIndex_=std::min(frameIndex,animation_->frameCount-1);tick_=0;finished_=false; }
void AnimationPlayer::update(int ticks){
  if(!animation_ || animation_->frameCount==0 || finished_) return;
  const auto frameDelay=[&](){ return animation_->frames[frameIndex_].delay; };
  if(frameDelay()<0) return; // OpenBOR infinite delay: hold current frame.
  tick_ += std::max(0,ticks);
  int delay=std::max(1,frameDelay());
  while(tick_>=delay && !finished_){
    tick_-=delay;
    const std::size_t last=animation_->frameCount-1;
    const std::size_t loopStart=(std::size_t)std::clamp(animation_->loopStart,0,(int)last);
    const std::size_t loopEnd=animation_->loopEnd<0?last:(std::size_t)std::clamp(animation_->loopEnd,0,(int)last);
    if(animation_->loop && frameIndex_>=loopEnd){ frameIndex_=std::min(loopStart,loopEnd); }
    else if(frameIndex_<last){ ++frameIndex_; }
    else if(animation_->loop){ frameIndex_=std::min(loopStart,last); }
    else { finished_=true; tick_=0; break; }
    if(animation_->frames[frameIndex_].delay<0){ tick_=0; break; }
    delay=std::max(1,animation_->frames[frameIndex_].delay);
  }
}
const generated::Frame* AnimationPlayer::frame() const { if(!animation_||animation_->frameCount==0) return nullptr; return &animation_->frames[frameIndex_]; }
)CPP";

    std::ofstream scriptVmH(include / "ScriptVM.hpp");
    scriptVmH << R"CPP(#pragma once
#include <cstdint>
#include <filesystem>
#include <memory>
#include <string>
#include <unordered_map>
#include <variant>
#include <vector>
struct ScriptArray;
using ScriptArrayPtr = std::shared_ptr<ScriptArray>;
using ScriptValue = std::variant<std::monostate,double,std::string,bool,std::uintptr_t,ScriptArrayPtr>;
struct ScriptArray {
  std::vector<ScriptValue> indexed;
  std::unordered_map<std::string,ScriptValue> named;
  std::vector<std::string> namedOrder;
  std::size_t cursor=0;
};
struct ScriptContext {
  std::unordered_map<std::string,ScriptValue> local;
  void* entity=nullptr;
  void* other=nullptr;
  bool player=false;
  int playerIndex=0;
};
struct ScriptRunResult { bool ok=true; std::string error; std::vector<std::string> unsupported; };
class ScriptHost {
public:
  virtual ~ScriptHost()=default;
  virtual ScriptValue callScriptFunction(const std::string&,const std::vector<ScriptValue>&,ScriptContext&,std::vector<std::string>& unsupported)=0;
};
class ScriptVM {
public:
  void setRoot(std::filesystem::path p){root_=std::move(p);}
  void setHost(ScriptHost* h){host_=h;}
  ScriptRunResult runFile(const std::string& path,ScriptContext& context,const std::string& function="main");
  const std::unordered_map<std::string,ScriptValue>& globals() const { return globals_; }
private:
  std::filesystem::path root_;
  ScriptHost* host_=nullptr;
  std::unordered_map<std::string,std::string> sourceCache_;
  std::unordered_map<std::string,ScriptValue> globals_;
};
)CPP";

    std::ofstream scriptVmCpp(src / "ScriptVM.cpp");
    scriptVmCpp << R"CPP(#include "ScriptVM.hpp"
#include <algorithm>
#include <cctype>
#include <cmath>
#include <fstream>
#include <random>
#include <sstream>
#include <stdexcept>
#include <unordered_set>

namespace {
enum class TK{End,Id,Num,Str,Sym};
struct Tok{TK k=TK::End;std::string s;};
static std::string lower(std::string s){for(auto&c:s)c=(char)std::tolower((unsigned char)c);return s;}
static bool truth(const ScriptValue&v){if(auto p=std::get_if<bool>(&v))return *p;if(auto p=std::get_if<double>(&v))return *p!=0;if(auto p=std::get_if<std::string>(&v))return !p->empty();if(auto p=std::get_if<std::uintptr_t>(&v))return *p!=0;if(auto p=std::get_if<ScriptArrayPtr>(&v))return p&&*p;return false;}
static double num(const ScriptValue&v){if(auto p=std::get_if<double>(&v))return *p;if(auto p=std::get_if<bool>(&v))return *p?1:0;if(auto p=std::get_if<std::uintptr_t>(&v))return (double)*p;if(auto p=std::get_if<std::string>(&v)){try{return std::stod(*p);}catch(...){}}return 0;}
static std::string str(const ScriptValue&v){if(auto p=std::get_if<std::string>(&v))return *p;if(auto p=std::get_if<double>(&v)){std::ostringstream o;o<<*p;return o.str();}if(auto p=std::get_if<bool>(&v))return *p?"1":"0";if(auto p=std::get_if<std::uintptr_t>(&v))return std::to_string(*p);if(auto p=std::get_if<ScriptArrayPtr>(&v))return (p&&*p)?"[array]":"";return {};}
static bool eq(const ScriptValue&a,const ScriptValue&b){if(a.index()==2||b.index()==2)return str(a)==str(b);if(a.index()==5||b.index()==5){auto ap=std::get_if<ScriptArrayPtr>(&a),bp=std::get_if<ScriptArrayPtr>(&b);return ap&&bp&&*ap==*bp;}return std::fabs(num(a)-num(b))<0.000001;}
static bool isTypeName(const std::string&s){auto q=lower(s);return q=="void"||q=="int"||q=="float"||q=="char"||q=="string"||q=="mixed"||q=="decimal"||q=="pointer";}
static std::vector<Tok> lex(const std::string&in){
  std::vector<Tok>o;size_t i=0;
  while(i<in.size()){
    unsigned char c=in[i];
    if(std::isspace(c)){++i;continue;}
    if(c=='#'){while(i<in.size()&&in[i]!='\n')++i;continue;}
    if(c=='/'&&i+1<in.size()&&in[i+1]=='/'){i+=2;while(i<in.size()&&in[i]!='\n')++i;continue;}
    if(c=='/'&&i+1<in.size()&&in[i+1]=='*'){i+=2;while(i+1<in.size()&&!(in[i]=='*'&&in[i+1]=='/'))++i;i=std::min(in.size(),i+2);continue;}
    if(std::isalpha(c)||c=='_'){size_t b=i++;while(i<in.size()&&(std::isalnum((unsigned char)in[i])||in[i]=='_'))++i;o.push_back({TK::Id,in.substr(b,i-b)});continue;}
    if(std::isdigit(c)||(c=='.'&&i+1<in.size()&&std::isdigit((unsigned char)in[i+1]))){
      size_t b=i++;
      if(c=='0'&&i<in.size()&&(in[i]=='x'||in[i]=='X')){++i;while(i<in.size()&&std::isxdigit((unsigned char)in[i]))++i;}
      else while(i<in.size()&&(std::isdigit((unsigned char)in[i])||in[i]=='.'||in[i]=='e'||in[i]=='E'||in[i]=='+'||in[i]=='-')){if((in[i]=='+'||in[i]=='-')&&i>b&&in[i-1]!='e'&&in[i-1]!='E')break;++i;}
      o.push_back({TK::Num,in.substr(b,i-b)});continue;
    }
    if(c=='"'||c=='\''){
      char quote=(char)c;++i;std::string v;
      while(i<in.size()&&in[i]!=quote){if(in[i]=='\\'&&i+1<in.size()){char n=in[++i];v+=n=='n'?'\n':n=='t'?'\t':n;}else v+=in[i];++i;}if(i<in.size())++i;o.push_back({TK::Str,v});continue;
    }
    std::string three=i+2<in.size()?in.substr(i,3):"";
    std::string two=i+1<in.size()?in.substr(i,2):"";
    if(three=="<<="||three==">>="){o.push_back({TK::Sym,three});i+=3;}
    else if(two=="=="||two=="!="||two=="<="||two==">="||two=="&&"||two=="||"||two=="+="||two=="-="||two=="*="||two=="/="||two=="%="||two=="&="||two=="|="||two=="^="||two=="++"||two=="--"||two=="<<"||two==">>"){o.push_back({TK::Sym,two});i+=2;}
    else{o.push_back({TK::Sym,std::string(1,(char)c)});++i;}
  }
  o.push_back({TK::End,{}});return o;
}
static bool safeScriptPath(const std::filesystem::path& root,const std::filesystem::path& current,const std::string& raw,std::filesystem::path& out){
  std::string q=raw;for(auto&c:q)if(c=='\\')c='/';while(q.rfind("data/",0)==0)q.erase(0,5);auto rel=std::filesystem::path(q).lexically_normal();if(rel.empty()||rel.is_absolute()||rel.has_root_name()||rel.has_root_directory())return false;for(const auto&part:rel)if(part=="..")return false;
  auto candidate=(root/rel).lexically_normal();if(!std::filesystem::exists(candidate)){auto local=(current.parent_path()/rel).lexically_normal();std::error_code ec;auto rr=std::filesystem::weakly_canonical(root,ec);auto cc=std::filesystem::weakly_canonical(local,ec);if(!ec){auto r=cc.lexically_relative(rr);bool ok=!r.empty();for(const auto&part:r)if(part=="..")ok=false;if(ok)candidate=cc;}}out=candidate;return true;
}
struct FunctionMacro { std::vector<std::string> params; std::string body; };
static std::string trimMacro(std::string x){while(!x.empty()&&std::isspace((unsigned char)x.front()))x.erase(x.begin());while(!x.empty()&&std::isspace((unsigned char)x.back()))x.pop_back();return x;}
static std::string replaceObjectMacros(const std::string& line,const std::unordered_map<std::string,std::string>& macros){
  std::string out;out.reserve(line.size());bool quoted=false;char quote=0;for(std::size_t i=0;i<line.size();){char c=line[i];if(quoted){out+=c;if(c=='\\'&&i+1<line.size()){out+=line[++i];++i;continue;}if(c==quote)quoted=false;++i;continue;}if(c=='"'||c=='\''){quoted=true;quote=c;out+=c;++i;continue;}if(std::isalpha((unsigned char)c)||c=='_'){std::size_t b=i++;while(i<line.size()&&(std::isalnum((unsigned char)line[i])||line[i]=='_'))++i;auto name=line.substr(b,i-b);auto it=macros.find(name);out+=it==macros.end()?name:it->second;continue;}out+=c;++i;}return out;
}
static std::string substituteMacroParams(const std::string& body,const FunctionMacro& fn,const std::vector<std::string>& args){
  std::unordered_map<std::string,std::string> repl;for(std::size_t i=0;i<fn.params.size()&&i<args.size();++i)repl[fn.params[i]]=args[i];return replaceObjectMacros(body,repl);
}
static std::string expandFunctionMacros(const std::string& line,const std::unordered_map<std::string,FunctionMacro>& funcs){
  std::string out;out.reserve(line.size());bool quoted=false;char quote=0;
  for(std::size_t i=0;i<line.size();){char c=line[i];if(quoted){out+=c;if(c=='\\'&&i+1<line.size()){out+=line[++i];++i;continue;}if(c==quote)quoted=false;++i;continue;}if(c=='"'||c=='\''){quoted=true;quote=c;out+=c;++i;continue;}
    if(std::isalpha((unsigned char)c)||c=='_'){std::size_t b=i++;while(i<line.size()&&(std::isalnum((unsigned char)line[i])||line[i]=='_'))++i;auto name=line.substr(b,i-b);auto fit=funcs.find(name);if(fit==funcs.end()){out+=name;continue;}std::size_t q=i;while(q<line.size()&&std::isspace((unsigned char)line[q]))++q;if(q>=line.size()||line[q]!='('){out+=name;continue;}
      std::vector<std::string> args;std::string cur;int depth=1;bool aq=false;char aqc=0;std::size_t j=q+1;for(;j<line.size()&&depth>0;++j){char ch=line[j];if(aq){cur+=ch;if(ch=='\\'&&j+1<line.size()){cur+=line[++j];continue;}if(ch==aqc)aq=false;continue;}if(ch=='"'||ch=='\''){aq=true;aqc=ch;cur+=ch;continue;}if(ch=='('){++depth;cur+=ch;continue;}if(ch==')'){--depth;if(depth==0){args.push_back(trimMacro(cur));break;}cur+=ch;continue;}if(ch==','&&depth==1){args.push_back(trimMacro(cur));cur.clear();continue;}cur+=ch;}
      if(depth!=0){out+=name;i=b+name.size();continue;}if(args.size()==1&&args[0].empty()&&fit->second.params.empty())args.clear();if(args.size()!=fit->second.params.size()){out+=line.substr(b,j-b);i=j;continue;}out+=substituteMacroParams(fit->second.body,fit->second,args);i=j;continue;}
    out+=c;++i;
  }return out;
}
static std::string expandMacros(std::string line,const std::unordered_map<std::string,std::string>& macros,const std::unordered_map<std::string,FunctionMacro>& funcs){
  for(int pass=0;pass<16;++pass){auto before=line;line=expandFunctionMacros(line,funcs);line=replaceObjectMacros(line,macros);if(line==before)break;}return line;
}
static std::string preprocessScript(const std::filesystem::path& root,const std::filesystem::path& file,const std::string& source,std::unordered_map<std::string,std::string>& macros,std::unordered_map<std::string,FunctionMacro>& funcMacros,std::unordered_set<std::string>& imported,std::vector<std::string>& unsupported,int depth){
  if(depth>24){unsupported.push_back("preprocessor-depth");return source;}std::istringstream in(source);std::ostringstream out;std::string line;std::vector<bool> active{true};
  while(std::getline(in,line)){auto t=trimMacro(line);if(!t.empty()&&t[0]=='#'){std::istringstream ds(t.substr(1));std::string cmd;ds>>cmd;cmd=lower(cmd);
      if(cmd=="define"){if(active.back()){std::string rest;std::getline(ds,rest);rest=trimMacro(rest);std::size_t n=0;while(n<rest.size()&&(std::isalnum((unsigned char)rest[n])||rest[n]=='_'))++n;auto name=rest.substr(0,n);std::size_t q=n;while(q<rest.size()&&std::isspace((unsigned char)rest[q]))++q;if(!name.empty()&&q<rest.size()&&rest[q]=='('){int depthp=1;std::size_t e=q+1;for(;e<rest.size()&&depthp>0;++e){if(rest[e]=='(')++depthp;else if(rest[e]==')')--depthp;}if(depthp==0){auto inside=rest.substr(q+1,(e-1)-(q+1));FunctionMacro fm;std::istringstream ps(inside);std::string param;while(std::getline(ps,param,',')){param=trimMacro(param);if(!param.empty())fm.params.push_back(param);}fm.body=trimMacro(rest.substr(e));funcMacros[name]=std::move(fm);}else unsupported.push_back("preprocessor-function-macro-malformed:"+name);}else if(!name.empty()){auto value=trimMacro(rest.substr(n));macros[name]=value.empty()?"1":value;}}continue;}
      if(cmd=="ifdef"||cmd=="ifndef"){std::string name;ds>>name;bool yes=macros.count(name)!=0||funcMacros.count(name)!=0;if(cmd=="ifndef")yes=!yes;active.push_back(active.back()&&yes);continue;}
      if(cmd=="else"){if(active.size()>1){bool parent=active[active.size()-2];active.back()=parent&&!active.back();}continue;}
      if(cmd=="endif"){if(active.size()>1)active.pop_back();continue;}
      if(cmd=="include"||cmd=="import"){if(!active.back())continue;std::string raw;std::getline(ds,raw);raw=trimMacro(raw);if(raw.size()>=2&&((raw.front()=='"'&&raw.back()=='"')||(raw.front()=='<'&&raw.back()=='>')))raw=raw.substr(1,raw.size()-2);std::filesystem::path inc;if(!safeScriptPath(root,file,raw,inc)){unsupported.push_back("unsafe-"+cmd+":"+raw);continue;}auto key=inc.generic_string();if(cmd=="import"&&!imported.insert(key).second)continue;std::ifstream f(inc);if(!f){unsupported.push_back(cmd+"-missing:"+raw);continue;}std::ostringstream ss;ss<<f.rdbuf();out<<preprocessScript(root,inc,ss.str(),macros,funcMacros,imported,unsupported,depth+1)<<"\n";continue;}
      if(active.back())unsupported.push_back("preprocessor:"+cmd);continue;}
    if(active.back())out<<expandMacros(line,macros,funcMacros)<<"\n";
  }return out.str();
}
struct ReturnSignal{ScriptValue v;};
struct BreakSignal{};struct ContinueSignal{};
struct FunctionInfo{bool found=false;size_t body=0;std::vector<std::string> params;};
class Exec{
 public:
  Exec(std::vector<Tok>t,ScriptVM*vm,ScriptHost*h,ScriptContext&c,std::unordered_map<std::string,ScriptValue>&g,std::vector<std::string>&u):t_(std::move(t)),vm_(vm),host_(h),ctx_(c),globals_(g),unsupported_(u){}
  bool runFunction(const std::string&name){ScriptValue ignored;return callUserFunction(name,{},ignored);}
 private:
  std::vector<Tok>t_;size_t pos_=0;ScriptVM*vm_;ScriptHost*host_;ScriptContext&ctx_;std::unordered_map<std::string,ScriptValue>&globals_;std::vector<std::string>&unsupported_;int callDepth_=0;
  bool is(const std::string&s)const{return t_[pos_].s==s;}Tok take(){return t_[pos_++];}bool eat(const std::string&s){if(is(s)){++pos_;return true;}return false;}void need(const std::string&s){if(!eat(s))throw std::runtime_error("expected "+s+" near '"+t_[pos_].s+"'");}
  FunctionInfo findFunction(const std::string&wanted){
    for(size_t i=0;i+3<t_.size();++i){if(t_[i].k!=TK::Id)continue;size_t n=i;if(isTypeName(t_[i].s))n=i+1;if(n>=t_.size()||t_[n].k!=TK::Id||lower(t_[n].s)!=lower(wanted)||n+1>=t_.size()||t_[n+1].s!="(")continue;
      FunctionInfo f;f.found=true;size_t j=n+2;std::vector<Tok> segment;int d=1;
      for(;j<t_.size()&&d;){if(t_[j].s=="("){++d;segment.push_back(t_[j++]);continue;}if(t_[j].s==")"){--d;if(d==0){if(!segment.empty()){for(auto it=segment.rbegin();it!=segment.rend();++it)if(it->k==TK::Id&&!isTypeName(it->s)){f.params.push_back(it->s);break;}}++j;break;}segment.push_back(t_[j++]);continue;}if(d==1&&t_[j].s==","){if(!segment.empty()){for(auto it=segment.rbegin();it!=segment.rend();++it)if(it->k==TK::Id&&!isTypeName(it->s)){f.params.push_back(it->s);break;}}segment.clear();++j;continue;}segment.push_back(t_[j++]);}
      while(j<t_.size()&&t_[j].s!="{")++j;if(j<t_.size()){f.body=j;return f;}
    }return {};
  }
  bool callUserFunction(const std::string&name,const std::vector<ScriptValue>&args,ScriptValue&out){
    auto f=findFunction(name);if(!f.found)return false;if(++callDepth_>64){--callDepth_;throw std::runtime_error("script recursion limit exceeded");}
    size_t savePos=pos_;std::vector<std::pair<std::string,std::pair<bool,ScriptValue>>> saved;
    for(size_t i=0;i<f.params.size();++i){auto it=ctx_.local.find(f.params[i]);saved.push_back({f.params[i],{it!=ctx_.local.end(),it==ctx_.local.end()?ScriptValue{}:it->second}});ctx_.local[f.params[i]]=i<args.size()?args[i]:ScriptValue{};}
    pos_=f.body;try{block(true);out=ScriptValue{};}catch(const ReturnSignal&r){out=r.v;}catch(...){pos_=savePos;for(auto&s:saved){if(s.second.first)ctx_.local[s.first]=s.second.second;else ctx_.local.erase(s.first);}--callDepth_;throw;}
    pos_=savePos;for(auto&s:saved){if(s.second.first)ctx_.local[s.first]=s.second.second;else ctx_.local.erase(s.first);}--callDepth_;return true;
  }
  void block(bool exec){need("{");while(!is("}")&&t_[pos_].k!=TK::End)statement(exec);need("}");}
  void simpleClause(bool exec,const std::string&terminator){
    if(eat(terminator))return;bool decl=false;if(t_[pos_].k==TK::Id&&isTypeName(t_[pos_].s)){decl=true;take();}
    if((decl||t_[pos_].k==TK::Id)&&t_[pos_].k==TK::Id){std::string n=t_[pos_].s;std::string next=pos_+1<t_.size()?t_[pos_+1].s:"";
      if(next=="++"||next=="--"){take();take();if(exec)ctx_.local[n]=num(get(n))+(next=="++"?1.0:-1.0);need(terminator);return;}
      if(next=="="||next=="+="||next=="-="||next=="*="||next=="/="||next=="%="||next=="&="||next=="|="||next=="^="||next=="<<="||next==">>="){take();std::string op=take().s;auto v=expr(exec);if(exec){auto cur=get(n);if(op=="+=")v=num(cur)+num(v);else if(op=="-=")v=num(cur)-num(v);else if(op=="*=")v=num(cur)*num(v);else if(op=="/=")v=num(v)==0?0.0:num(cur)/num(v);else if(op=="%=")v=(double)((long long)num(cur)%std::max(1LL,(long long)num(v)));else if(op=="&=")v=(double)((long long)num(cur)&(long long)num(v));else if(op=="|=")v=(double)((long long)num(cur)|(long long)num(v));else if(op=="^=")v=(double)((long long)num(cur)^(long long)num(v));else if(op=="<<=")v=(double)((long long)num(cur)<<(int)num(v));else if(op==">>=")v=(double)((long long)num(cur)>>(int)num(v));ctx_.local[n]=v;}need(terminator);return;}
      if(decl){take();if(exec)ctx_.local[n]=0.0;need(terminator);return;}
    }
    (void)expr(exec);need(terminator);
  }
  void switchStatement(bool exec){
    take();need("(");auto key=expr(exec);need(")");need("{");const size_t bodyStart=pos_;size_t end=bodyStart;int depth=1;size_t target=(size_t)-1,def=(size_t)-1;
    for(size_t i=bodyStart;i<t_.size()&&depth>0;){if(t_[i].s=="{"){++depth;++i;continue;}if(t_[i].s=="}"){--depth;if(depth==0){end=i;break;}++i;continue;}if(depth==1&&t_[i].k==TK::Id&&lower(t_[i].s)=="case"){size_t save=pos_;pos_=i+1;ScriptValue cv{};try{cv=expr(exec);need(":");}catch(...){pos_=save;throw;}size_t after=pos_;pos_=save;if(exec&&target==(size_t)-1&&eq(key,cv))target=after;i=after;continue;}if(depth==1&&t_[i].k==TK::Id&&lower(t_[i].s)=="default"){size_t j=i+1;while(j<t_.size()&&t_[j].s!=":"&&t_[j].s!="}")++j;if(j<t_.size()&&t_[j].s==":")def=j+1;i=j+1;continue;}++i;}
    if(!exec){pos_=std::min(end+1,t_.size()-1);return;}if(target==(size_t)-1)target=def;if(target==(size_t)-1){pos_=std::min(end+1,t_.size()-1);return;}pos_=target;try{while(pos_<end){if(t_[pos_].k==TK::Id&&lower(t_[pos_].s)=="case"){take();(void)expr(false);need(":");continue;}if(t_[pos_].k==TK::Id&&lower(t_[pos_].s)=="default"){take();need(":");continue;}statement(true);}}catch(const BreakSignal&){}pos_=std::min(end+1,t_.size()-1);
  }
  void statement(bool exec){
    if(is("{")){block(exec);return;}
    if(t_[pos_].k==TK::Id&&lower(t_[pos_].s)=="switch"){switchStatement(exec);return;}
    if(t_[pos_].k==TK::Id&&lower(t_[pos_].s)=="do"){take();size_t bodyStart=pos_;statement(false);size_t afterBody=pos_;if(!(t_[pos_].k==TK::Id&&lower(t_[pos_].s)=="while"))throw std::runtime_error("expected while after do");take();need("(");size_t condStart=pos_;(void)expr(false);need(")");eat(";");size_t end=pos_;if(!exec){pos_=end;return;}for(int guard=0;guard<100000;++guard){pos_=bodyStart;bool br=false;try{statement(true);}catch(const ContinueSignal&){}catch(const BreakSignal&){br=true;}if(br)break;pos_=afterBody;take();need("(");pos_=condStart;auto c=expr(true);need(")");eat(";");if(!truth(c))break;}pos_=end;return;}
    if(t_[pos_].k==TK::Id&&lower(t_[pos_].s)=="if"){take();need("(");auto c=expr(exec);need(")");bool on=exec&&truth(c);statement(on);if(t_[pos_].k==TK::Id&&lower(t_[pos_].s)=="else"){take();statement(exec&&!truth(c));}return;}
    if(t_[pos_].k==TK::Id&&lower(t_[pos_].s)=="while"){
      take();need("(");size_t condStart=pos_;auto c=expr(exec);need(")");size_t bodyStart=pos_;pos_=bodyStart;statement(false);size_t bodyEnd=pos_;if(!exec||!truth(c)){pos_=bodyEnd;return;}
      for(int guard=0;guard<100000;++guard){pos_=bodyStart;bool br=false;try{statement(true);}catch(const ContinueSignal&){}catch(const BreakSignal&){br=true;}if(br)break;pos_=condStart;c=expr(true);need(")");if(!truth(c))break;}pos_=bodyEnd;return;
    }
    if(t_[pos_].k==TK::Id&&lower(t_[pos_].s)=="for"){
      take();need("(");simpleClause(exec,";");size_t condStart=pos_;bool hasCond=!is(";");auto initialCond=hasCond?expr(exec):ScriptValue(true);need(";");size_t incrStart=pos_;simpleClause(false,")");size_t bodyStart=pos_;pos_=bodyStart;statement(false);size_t bodyEnd=pos_;if(!exec||!truth(initialCond)){pos_=bodyEnd;return;}
      for(int guard=0;guard<100000;++guard){pos_=condStart;ScriptValue c=hasCond?expr(true):ScriptValue(true);need(";");if(!truth(c))break;pos_=bodyStart;bool br=false;try{statement(true);}catch(const ContinueSignal&){}catch(const BreakSignal&){br=true;}if(br)break;pos_=incrStart;simpleClause(true,")");}pos_=bodyEnd;return;
    }
    if(t_[pos_].k==TK::Id&&lower(t_[pos_].s)=="break"){take();eat(";");if(exec)throw BreakSignal{};return;}
    if(t_[pos_].k==TK::Id&&lower(t_[pos_].s)=="continue"){take();eat(";");if(exec)throw ContinueSignal{};return;}
    if(t_[pos_].k==TK::Id&&lower(t_[pos_].s)=="return"){take();ScriptValue v{};if(!is(";"))v=expr(exec);eat(";");if(exec)throw ReturnSignal{v};return;}
    bool decl=false;if(t_[pos_].k==TK::Id&&isTypeName(t_[pos_].s)){decl=true;take();}
    if((decl||t_[pos_].k==TK::Id)&&t_[pos_].k==TK::Id&&pos_+1<t_.size()&&(t_[pos_+1].s=="="||t_[pos_+1].s=="+="||t_[pos_+1].s=="-="||t_[pos_+1].s=="*="||t_[pos_+1].s=="/="||t_[pos_+1].s=="%="||t_[pos_+1].s=="&="||t_[pos_+1].s=="|="||t_[pos_+1].s=="^="||t_[pos_+1].s=="<<="||t_[pos_+1].s==">>=")){std::string n=take().s;std::string op=take().s;auto v=expr(exec);eat(";");if(exec){auto cur=get(n);if(op=="+=")v=num(cur)+num(v);else if(op=="-=")v=num(cur)-num(v);else if(op=="*=")v=num(cur)*num(v);else if(op=="/=")v=num(v)==0?0.0:num(cur)/num(v);else if(op=="%=")v=(double)((long long)num(cur)%std::max(1LL,(long long)num(v)));else if(op=="&=")v=(double)((long long)num(cur)&(long long)num(v));else if(op=="|=")v=(double)((long long)num(cur)|(long long)num(v));else if(op=="^=")v=(double)((long long)num(cur)^(long long)num(v));else if(op=="<<=")v=(double)((long long)num(cur)<<(int)num(v));else if(op==">>=")v=(double)((long long)num(cur)>>(int)num(v));ctx_.local[n]=v;}return;}
    if((decl||t_[pos_].k==TK::Id)&&t_[pos_].k==TK::Id&&pos_+1<t_.size()&&(t_[pos_+1].s=="++"||t_[pos_+1].s=="--")){std::string n=take().s;std::string op=take().s;eat(";");if(exec)ctx_.local[n]=num(get(n))+(op=="++"?1.0:-1.0);return;}
    if(decl&&t_[pos_].k==TK::Id){std::string n=take().s;ScriptValue v=0.0;if(eat("="))v=expr(exec);eat(";");if(exec)ctx_.local[n]=v;return;}
    (void)expr(exec);eat(";");
  }
  ScriptValue get(const std::string&n){auto it=ctx_.local.find(n);if(it!=ctx_.local.end())return it->second;auto g=globals_.find(n);if(g!=globals_.end())return g->second;if(lower(n)=="null")return std::uintptr_t(0);return 0.0;}
  ScriptValue expr(bool exec,int minp=0){auto l=unary(exec);for(;;){std::string op=t_[pos_].s;int p=prec(op);if(p<minp)break;take();auto r=expr(exec,p+1);if(!exec){l=0.0;continue;}if(op=="+"){if(l.index()==2||r.index()==2)l=str(l)+str(r);else l=num(l)+num(r);}else if(op=="-")l=num(l)-num(r);else if(op=="*")l=num(l)*num(r);else if(op=="/")l=num(r)==0?0.0:num(l)/num(r);else if(op=="%")l=(double)((long long)num(l)%std::max(1LL,(long long)num(r)));else if(op=="<<")l=(double)((long long)num(l)<<(int)num(r));else if(op==">>")l=(double)((long long)num(l)>>(int)num(r));else if(op=="&")l=(double)((long long)num(l)&(long long)num(r));else if(op=="^")l=(double)((long long)num(l)^(long long)num(r));else if(op=="|")l=(double)((long long)num(l)|(long long)num(r));else if(op=="==")l=eq(l,r);else if(op=="!=")l=!eq(l,r);else if(op=="<")l=num(l)<num(r);else if(op==">")l=num(l)>num(r);else if(op=="<=")l=num(l)<=num(r);else if(op==">=")l=num(l)>=num(r);else if(op=="&&")l=truth(l)&&truth(r);else if(op=="||")l=truth(l)||truth(r);}if(minp==0&&eat("?")){bool choose=exec&&truth(l);auto yes=expr(choose);need(":");auto no=expr(exec&&!choose);if(exec)l=choose?yes:no;else l=0.0;}return l;}
  int prec(const std::string&o){if(o=="||")return 1;if(o=="&&")return 2;if(o=="|")return 3;if(o=="^")return 4;if(o=="&")return 5;if(o=="=="||o=="!=")return 6;if(o=="<"||o==">"||o=="<="||o==">=")return 7;if(o=="<<"||o==">>")return 8;if(o=="+"||o=="-")return 9;if(o=="*"||o=="/"||o=="%")return 10;return -1;}
  ScriptValue unary(bool exec){if(eat("!"))return exec?ScriptValue(!truth(unary(exec))):ScriptValue(0.0);if(eat("~"))return exec?ScriptValue((double)~(long long)num(unary(exec))):ScriptValue(0.0);if(eat("-"))return exec?ScriptValue(-num(unary(exec))):ScriptValue(0.0);if(eat("+"))return unary(exec);return primary(exec);}
  ScriptValue primary(bool exec){
    if(eat("(")){auto v=expr(exec);need(")");return v;}
    if(t_[pos_].k==TK::Num){auto raw=take().s;double v=0;try{v=(raw.size()>2&&raw[0]=='0'&&(raw[1]=='x'||raw[1]=='X'))?(double)std::stoll(raw,nullptr,16):std::stod(raw);}catch(...){v=0;}return exec?ScriptValue(v):ScriptValue(0.0);}
    if(t_[pos_].k==TK::Str){auto v=take().s;return exec?ScriptValue(v):ScriptValue(std::string{});}
    if(t_[pos_].k==TK::Id){
      std::string n=take().s;
      if(eat("(")){
        std::vector<ScriptValue>a;if(!is(")")){do{a.push_back(expr(exec));}while(eat(","));}need(")");if(!exec)return 0.0;auto ln=lower(n);
        if(ln=="getglobalvar"&&a.size()){auto it=globals_.find(str(a[0]));return it==globals_.end()?ScriptValue{}:it->second;}
        if(ln=="setglobalvar"&&a.size()>1){globals_[str(a[0])]=a[1];return a[1];}
        if(ln=="clearglobalvar"){globals_.clear();return 1.0;}
        if(ln=="getlocalvar"&&a.size()){auto it=ctx_.local.find(str(a[0]));return it==ctx_.local.end()?ScriptValue{}:it->second;}
        if(ln=="setlocalvar"&&a.size()>1){ctx_.local[str(a[0])]=a[1];return a[1];}
        if(ln=="clearlocalvar"){ctx_.local.clear();return 1.0;}
        if(ln=="maxglobalvarindex")return globals_.empty()?-1.0:(double)globals_.size()-1.0;
        if(ln=="getindexedvar"&&a.size()){auto k="#"+std::to_string((long long)num(a[0]));auto it=globals_.find(k);return it==globals_.end()?ScriptValue{}:it->second;}
        if(ln=="setindexedvar"&&a.size()>1){auto k="#"+std::to_string((long long)num(a[0]));globals_[k]=a[1];return a[1];}
        if(ln=="clearindexedvar"){for(auto it=globals_.begin();it!=globals_.end();){if(!it->first.empty()&&it->first[0]=='#')it=globals_.erase(it);else ++it;}return 1.0;}
        if(ln=="isempty")return a.empty()||std::holds_alternative<std::monostate>(a[0]);
        if(ln=="rand"){static std::mt19937 r{0x0B0B0B};return (double)(r()&0x7fffffff);}
        if(ln=="null")return std::uintptr_t(0);
        if(ln=="array"){auto ar=std::make_shared<ScriptArray>();if(!a.empty()&&num(a[0])>0)ar->indexed.resize((std::size_t)num(a[0]));return ar;}
        if(ln=="size"&&a.size()){if(auto p=std::get_if<ScriptArrayPtr>(&a[0]);p&&*p)return (double)((*p)->indexed.size()+(*p)->named.size());return 0.0;}
        if((ln=="get"||ln=="set"||ln=="add"||ln=="delete")&&a.size()>=2){auto p=std::get_if<ScriptArrayPtr>(&a[0]);if(!p||!*p)return {};auto ar=*p;bool numeric=a[1].index()!=2;
          if(ln=="get"){if(numeric){long long i=(long long)num(a[1]);return i>=0&&(std::size_t)i<ar->indexed.size()?ar->indexed[(std::size_t)i]:ScriptValue{};}auto it=ar->named.find(str(a[1]));return it==ar->named.end()?ScriptValue{}:it->second;}
          if(ln=="set"&&a.size()>=3){if(numeric){long long i=(long long)num(a[1]);if(i<0)return 0.0;if((std::size_t)i>=ar->indexed.size())ar->indexed.resize((std::size_t)i+1);ar->indexed[(std::size_t)i]=a[2];}else{auto k=str(a[1]);if(!ar->named.count(k))ar->namedOrder.push_back(k);ar->named[k]=a[2];}return a[2];}
          if(ln=="add"&&a.size()>=3){long long i=(long long)num(a[1]);if(i<0||i>(long long)ar->indexed.size())return 0.0;ar->indexed.insert(ar->indexed.begin()+i,a[2]);return 1.0;}
          if(ln=="delete"){if(numeric){long long i=(long long)num(a[1]);if(i<0||(std::size_t)i>=ar->indexed.size())return 0.0;ar->indexed.erase(ar->indexed.begin()+i);return 1.0;}auto k=str(a[1]);auto erased=ar->named.erase(k);ar->namedOrder.erase(std::remove(ar->namedOrder.begin(),ar->namedOrder.end(),k),ar->namedOrder.end());if(ar->cursor>=ar->namedOrder.size()&&ar->cursor)ar->cursor=ar->namedOrder.size()-1;return erased?1.0:0.0;}
        }
        if((ln=="next"||ln=="previous"||ln=="reset"||ln=="value"||ln=="key"||ln=="free")&&a.size()){auto p=std::get_if<ScriptArrayPtr>(&a[0]);if((!p||!*p)&&ln=="free"){}else if(!p||!*p)return {};else {auto ar=*p;if(ln=="next"){if(ar->cursor+1<ar->namedOrder.size())++ar->cursor;return 1.0;}if(ln=="previous"){if(ar->cursor>0)--ar->cursor;return 1.0;}if(ln=="reset"){ar->cursor=0;return 1.0;}if(ln=="key"){return ar->cursor<ar->namedOrder.size()?ScriptValue(ar->namedOrder[ar->cursor]):ScriptValue{};}if(ln=="value"){if(ar->cursor<ar->namedOrder.size()){auto it=ar->named.find(ar->namedOrder[ar->cursor]);if(it!=ar->named.end())return it->second;}return ScriptValue{};}if(ln=="free"){p->reset();return 1.0;}}}
        ScriptValue userRet{};if(callUserFunction(n,a,userRet))return userRet;
        if(host_)return host_->callScriptFunction(n,a,ctx_,unsupported_);if(std::find(unsupported_.begin(),unsupported_.end(),n)==unsupported_.end())unsupported_.push_back(n);return {};
      }
      auto q=lower(n);if(q=="true")return true;if(q=="false")return false;return exec?get(n):ScriptValue(0.0);
    }
    throw std::runtime_error("unexpected token "+t_[pos_].s);
  }
};
}
ScriptRunResult ScriptVM::runFile(const std::string& raw,ScriptContext& context,const std::string& function){
  ScriptRunResult r;if(raw.empty())return r;
  try{
    std::string key=raw;for(auto&c:key)if(c=='\\')c='/';while(key.rfind("data/",0)==0)key.erase(0,5);auto rel=std::filesystem::path(key).lexically_normal();for(const auto&part:rel)if(part=="..")return {false,"unsafe script path",{}};if(rel.is_absolute()||rel.has_root_name()||rel.has_root_directory())return {false,"unsafe script path",{}};auto path=root_/rel;std::string source;
    auto it=sourceCache_.find(path.generic_string());if(it==sourceCache_.end()){std::ifstream in(path);if(!in){r.ok=false;r.error="script not found: "+path.generic_string();return r;}std::ostringstream ss;ss<<in.rdbuf();source=ss.str();sourceCache_[path.generic_string()]=source;}else source=it->second;
    std::unordered_map<std::string,std::string> macros;std::unordered_map<std::string,FunctionMacro> funcMacros;std::unordered_set<std::string> imported;imported.insert(path.generic_string());source=preprocessScript(root_,path,source,macros,funcMacros,imported,r.unsupported,0);auto tokens=lex(source);Exec e(std::move(tokens),this,host_,context,globals_,r.unsupported);bool ran=e.runFunction(function);if(!ran&&function!="main")ran=e.runFunction("main");if(!ran){r.ok=false;r.error="requested function/main() not found";}
  }catch(const std::exception&e){r.ok=false;r.error=e.what();}
  return r;
}
)CPP";

    std::ofstream engine(include / "Engine.hpp");
    engine << R"CPP(#pragma once
#include "Renderer.hpp"
#include "AnimationPlayer.hpp"
#include "AudioSystem.hpp"
#include "ScriptVM.hpp"
#include "../generated/GeneratedStages.hpp"
#include <filesystem>
#include <deque>
#include <string>
#include <unordered_map>
#include <vector>
struct RuntimeEntity {
  const generated::Spawn* spawn = nullptr;
  const generated::Character* model = nullptr;
  AnimationPlayer animation;
  float worldX = 0;
  float z = 200;
  int health = 100;
  int maxHealth = 100;
  int hitStun = 0;
  int attackTicks = 0;
  int attackCooldown = 0;
  int attackHits = 0;
  bool attackHasHit = false;
  bool projectileFired = false;
  int facing = -1;
  int fallTicks = 0;
  int recoveryTicks = 0;
  int juggleRemaining = 4;
  float altitude = 0.0f;
  float verticalVelocity = 0.0f;
  bool grabbed = false;
  bool alive = true;
  bool visible = true;
  int deathTicks = 0;
  int paletteMap = 0;
  int reactionType = 0;
  int guardPoints = 0;
  int blockState = 0;
  bool blocking = false;
  float scriptVelocityX = 0.0f;
  float scriptVelocityZ = 0.0f;
  const generated::Character* equippedWeapon = nullptr;
  int weaponUses = 0;
  const generated::Character* weaponItemModel = nullptr;
  int weaponDropsRemaining = -1;
  std::uintptr_t parentHandle = 0;
  bool summonedChild = false;
  std::unordered_map<std::string,ScriptValue> scriptVars;
  unsigned lastPlayerAttackId = 0;
  std::size_t lastFrame = (std::size_t)-1;
  SpriteImage sprite;
  ScriptContext scriptCtx;
};
struct RuntimeCoopPlayer {
  const generated::Character* model = nullptr;
  AnimationPlayer animation;
  float worldX = 80.0f, z = 200.0f, altitude = 0.0f, verticalVelocity = 0.0f;
  int health = 100, maxHealth = 100, hitStun = 0, attackTicks = 0, attackCooldown = 0, facing = 1;
  int paletteMap = 0;
  int reactionType = 0;
  int guardPoints = 0;
  int blockState = 0;
  bool blocking = false;
  float scriptVelocityX = 0.0f, scriptVelocityZ = 0.0f;
  bool alive = true, jumping = false, attackHasHit = false, projectileFired = false;
  int attackHits = 0;
  int comboStep = 0, comboBranch = -1, comboWindow = 0;
  const generated::Character* equippedWeapon = nullptr;
  int weaponUses = 0;
  const generated::Character* weaponItemModel = nullptr;
  int weaponDropsRemaining = -1;
  unsigned attackId = 0;
  int gamepadId = 0;
  std::size_t lastFrame = (std::size_t)-1;
  SpriteImage sprite;
  ScriptContext scriptCtx;
};
struct RuntimeStageLayer {
  SpriteImage image;
  std::string kind;
  float xRatio=0.5f, zRatio=0.5f;
  int xOffset=0, zOffset=0, xSpacing=0, zSpacing=0, xRepeat=0, zRepeat=0, zOrder=0;
};
struct ScriptSpawnEntry {
  std::string model;
  std::string alias;
  std::string item;
  std::string map;
  float x=0.0f,z=200.0f,a=0.0f;
  int health=-1;
  bool boss=false;
};
struct PendingChildSpawn {
  const generated::Character* model = nullptr;
  float worldX=0,z=200,altitude=0;
  int facing=1;
  std::uintptr_t parent=0;
  bool summon=false;
};
struct PendingWeaponDrop {
  const generated::Character* itemModel = nullptr;
  float worldX=0,z=200,altitude=0;
  int facing=1;
  int remainingDrops=-1;
};
struct InputHistoryEntry { unsigned held=0,newKeys=0,released=0; };
struct RuntimeProjectile {
  const generated::Character* model = nullptr;
  AnimationPlayer animation;
  float worldX=0,z=200,altitude=0;
  float vx=0,vy=0,vz=0;
  int facing=1;
  int life=0;
  bool bomb=false;
  bool exploded=false;
  bool fromPlayer=true;
  bool alive=true;
  bool subjectToGravity=false;
  int bouncesLeft=0;
  float bounceFactor=0.5f;
  int hitMask=0;
  unsigned hitId=0;
  std::size_t lastFrame=(std::size_t)-1;
  SpriteImage sprite;
};
struct ScriptDrawCommand {
  enum class Kind { Text, Box, Line, Dot, Sprite } kind = Kind::Dot;
  int x=0,y=0,x2=0,y2=0,w=0,h=0,z=0,font=0;
  unsigned int color=0xFFFFFFu;
  std::string text;
  std::uintptr_t sprite=0;
};
class Engine : public ScriptHost {
public: bool initialize(const std::filesystem::path& portRoot); int run();
  ScriptValue callScriptFunction(const std::string&,const std::vector<ScriptValue>&,ScriptContext&,std::vector<std::string>&) override;
private:
  enum class FrontendState { MainMenu, CharacterSelect, Loading, Options, GraphicsOptions, Controls, Playing, Paused, GameOver, Quit };
  struct RectF { float x=0,y=0,w=0,h=0; };
  void previewMusic();
  void pollAudioHotkeys();
  void beginGame();
  bool loadStage(std::size_t index, bool keepHealth=false);
  void advanceStage();
  void saveProgress();
  bool loadProgress();
  void applyStageGeometry(float oldX,float oldZ);
  void updateFrontend();
  void drawFrontend();
  void runModelScript(const char* path, ScriptContext& ctx, const char* event);
  void saveSettings();
  bool frontendKeyPressed(int vk);
  bool gamepadButtonPressed(unsigned short button);
  bool gamepadButtonPressedFor(int pad, unsigned short button);
  int captureAnyKey();
  unsigned short captureAnyGamepadButton(int pad);
  void updatePlayer();
  void updateCoopPlayers();
  void updateEntities();
  void updateProjectiles();
  void resolveCombat();
  void updateCombatLock();
  void updateCamera();
  void triggerSpawns();
  void updateStageEvents();
  float scrollMin() const;
  float scrollMax() const;
  void drawStage();
  void drawHud();
  void startPlayerAttack();
  void startPlayerJump();
  void startPlayerDash();
  void startEnemyAttack(RuntimeEntity&, float targetDistance=0.0f, std::uintptr_t targetHandle=0);
  void maybeSpawnProjectile(const generated::Character*, const generated::Animation*, std::size_t frameIndex, float x, float z, float altitude, int facing, bool fromPlayer, bool& firedFlag, const generated::Character* equippedOverride=nullptr, int* weaponUses=nullptr);
  void spawnProjectile(const generated::Character*, float x, float z, float altitude, int facing, float vx, float vy, float vz, bool bomb, bool fromPlayer);
  void tryPickupWeapon();
  void tryPickupWeapon(RuntimeCoopPlayer&);
  void setPlayerWeaponIndex(int index);
  void setCoopWeaponIndex(RuntimeCoopPlayer&, int index);
  void setEntityWeaponIndex(RuntimeEntity&, int index);
  void queueChildSpawn(const generated::Character* owner,const generated::Animation*,std::size_t frameIndex,float x,float z,float altitude,int facing,std::uintptr_t parent);
  void unsummonChildren(std::uintptr_t parent,bool allChildren=false);
  void flushChildSpawns();
  void updateChildFollowing(RuntimeEntity&);
  void queueWeaponDrop(const generated::Character* item,float x,float z,float altitude,int facing,int remaining);
  void flushWeaponDrops();
  void dropPlayerWeapon(bool stageLoss=false);
  void dropCoopWeapon(RuntimeCoopPlayer&,bool stageLoss=false);
  void dropEntityWeapon(RuntimeEntity&,bool stageLoss=false);
  void recordInputHistory(int slot);
  const generated::Animation* commandTarget(const generated::Character*,int slot,int facing) const;
  const generated::Animation* cancelTarget(const generated::Character*,const generated::Animation*,std::size_t frame,int hits,int slot,int facing) const;
  bool tryEntityPickupWeapon(RuntimeEntity&);
  void tryGrabNearest();
  void throwGrabbed();
  void playFrameSound(const generated::Frame*);
  void damageEnemy(RuntimeEntity&, int damage, float knockDirection, bool knockdown=false, int dropVy=-3, int attackType=0, std::uintptr_t attacker=0);
  void damagePlayer(int damage, float knockDirection, bool knockdown=false, int dropVy=-3, int attackType=0, std::uintptr_t attacker=0);
  void damageCoopPlayer(RuntimeCoopPlayer&, int damage, float knockDirection, bool knockdown=false, int dropVy=-3, int attackType=0, std::uintptr_t attacker=0);
  bool tryBlockEntity(RuntimeEntity&, const generated::Frame&, std::uintptr_t attacker);
  bool tryBlockPlayer(int slot, const generated::Frame&, std::uintptr_t attacker);
  void renderScriptDrawQueue();
  RectF bboxFor(const generated::Frame*, float worldX, float worldY, int facing=1) const;
  RectF attackFor(const generated::Frame*, float worldX, float worldY, int facing=1) const;
  static bool overlaps(const RectF&, const RectF&);
  const generated::Character* findCharacter(const char* name) const;
  const generated::Animation* findAnimation(const generated::Character*, const char* preferred) const;
  const generated::Animation* findActionAnimation(const generated::Character* base,const generated::Character* weapon,const char* preferred) const;
  void setEntityAnimation(RuntimeEntity&, const generated::Animation*);
  void loadCurrentPlayerSprite();
  void loadEntitySprite(RuntimeEntity&);
  RuntimeConfig config_; Renderer renderer_; AnimationPlayer player_; AudioSystem audio_; ScriptVM scriptVm_; ScriptContext playerScriptCtx_; ScriptContext stageScriptCtx_; std::filesystem::path root_;
  const generated::Stage* stage_ = nullptr;
  const generated::Character* playerModel_ = nullptr;
  float playerWorldX_ = 80.0f, playerZ_ = 200.0f, cameraX_ = 0.0f, cameraMaxX_ = 0.0f, stageLength_ = 320.0f;
  int playerHealth_ = 100, playerMaxHealth_ = 100, playerHitStun_ = 0, playerAttackTicks_ = 0, playerAttackCooldown_ = 0;
  int playerFacing_ = 1, playerComboStep_ = 0, playerComboBranch_ = -1, playerComboWindow_ = 0, playerFallTicks_ = 0, playerRecoveryTicks_ = 0, playerDashTicks_ = 0, playerReactionType_ = 0;
  int playerGuardPoints_ = 0, playerBlockState_ = 0; bool playerBlocking_ = false;
  bool playerAlive_ = true, playerQueuedAttack_ = false, playerProjectileFired_ = false, playerJumping_ = false, playerAnimJumpTriggered_ = false, playerAttackHasHit_ = false;
  int playerAttackHits_ = 0;
  int grabbedEntity_ = -1, grabHoldTicks_ = 0;
  float playerAltitude_ = 0.0f, playerVerticalVelocity_ = 0.0f, playerJumpVelocityX_ = 0.0f, playerJumpVelocityZ_ = 0.0f;
  unsigned playerAttackId_ = 0;
  bool combatLocked_ = false;
  float combatLockX_ = 0.0f;
  std::size_t nextSpawn_ = 0;
  std::vector<unsigned char> spawnState_;
  std::vector<unsigned char> eventState_;
  int scrollDir_ = 1;
  bool cameraFixed_ = false;
  bool allowBacktrack_ = false;
  bool scrollBlocked_ = false;
  int groupMin_ = 0, groupMax_ = 0;
  bool groupRefillActive_ = false;
  float backtrackFloor_ = 0.0f;
  std::size_t lastFrame_=(std::size_t)-1; SpriteImage sprite_; SpriteImage background_; SpriteImage titleBackground_;
  float backgroundRatioX_=0.5f; int backgroundOffsetX_=0, backgroundOffsetY_=0;
  std::vector<SpriteImage> panels_;
  std::vector<RuntimeStageLayer> backgroundLayers_;
  std::vector<RuntimeStageLayer> foregroundLayers_;
  std::deque<RuntimeEntity> entities_;
  std::vector<RuntimeProjectile> projectiles_;
  std::vector<PendingChildSpawn> pendingChildSpawns_;
  std::vector<PendingWeaponDrop> pendingWeaponDrops_;
  std::vector<RuntimeCoopPlayer> coopPlayers_;
  const generated::Character* equippedWeapon_ = nullptr;
  int weaponUses_ = 0;
  const generated::Character* weaponItemModel_ = nullptr;
  int weaponDropsRemaining_ = -1;
  std::vector<std::filesystem::path> scriptSamples_;
  std::unordered_map<std::uintptr_t,SpriteImage> scriptSprites_;
  std::uintptr_t nextScriptSpriteHandle_ = 0x10000000u;
  std::vector<ScriptDrawCommand> scriptDrawQueue_;
  ScriptSpawnEntry scriptSpawnEntry_;
  std::unordered_map<std::string,ScriptValue> playerScriptVars_[4];
  unsigned playerKeys_[4]{0,0,0,0};
  unsigned playerNewKeys_[4]{0,0,0,0};
  unsigned playerReleasedKeys_[4]{0,0,0,0};
  unsigned playerPlayKeys_[4]{0,0,0,0};
  unsigned playerDisabledKeys_[4]{0,0,0,0};
  std::deque<InputHistoryEntry> playerInputHistory_[4];
  float playerScriptVelocityX_=0.0f, playerScriptVelocityZ_=0.0f;
  unsigned long long tickCounter_ = 0;
  FrontendState frontendState_ = FrontendState::MainMenu;
  int menuIndex_ = 0;
  int optionIndex_ = 0;
  int graphicsOptionIndex_ = 0;
  int pauseIndex_ = 0;
  bool optionsFromPause_ = false;
  std::size_t stageIndex_ = 0;
  std::size_t pendingBranchTarget_ = (std::size_t)-1;
  bool pendingBranchImmediate_ = false;
  int selectIndex_ = 0;
  int selectedPlayerIndex_ = -1;
  int selectIndexes_[4]{0,0,0,0};
  bool joinedPlayers_[4]{true,false,false,false};
  int controlsIndex_ = 0;
  bool waitingForKey_ = false;
  bool waitingForPad_ = false;
  int controlCaptureDelay_ = 0;
  bool stageComplete_ = false;
};
)CPP";
    std::ofstream engineCpp(src / "Engine.cpp");
    engineCpp << R"CPP(#include "Engine.hpp"
#include "RuntimeConfig.hpp"
#include <random>
#include "../generated/GeneratedCharacters.hpp"
#include "../generated/GeneratedStages.hpp"
#include <algorithm>
#include <cctype>
#include <cmath>
#include <cstring>
#include <iostream>
#include <fstream>
#include <sstream>
#include <unordered_map>
#include <thread>
#include <chrono>
#ifdef _WIN32
#define NOMINMAX
#include <windows.h>
#include <Xinput.h>
#pragma comment(lib, "xinput.lib")
#endif

static std::filesystem::path normalizeDataPath(std::string s){
  for(auto& c:s) if(c=='\\') c='/';
  while(s.rfind("./",0)==0) s.erase(0,2);
  std::string low=s; for(auto& c:low)c=(char)std::tolower((unsigned char)c);
  if(low.rfind("data/",0)==0) s.erase(0,5);
  auto p=std::filesystem::path(s).lexically_normal();
  if(p.empty() || p.is_absolute() || p.has_root_name() || p.has_root_directory()) return {};
  for(const auto& part:p) if(part=="..") return {};
  return p;
}
static std::string lowerString(std::string s){ for(auto& c:s)c=(char)std::tolower((unsigned char)c); return s; }
static std::string lowerExt(const std::filesystem::path& p){ return lowerString(p.extension().string()); }
// OpenBOR entity type bit values used by candamage/hostile/projectilehit.
static int openborTypeBit(const generated::Character* m){
  if(!m)return 0;auto t=lowerString(m->type?m->type:"");
  if(t=="none")return 1<<0;if(t=="player")return 1<<2;if(t=="enemy")return 1<<3;if(t=="item")return 1<<4;if(t=="obstacle")return 1<<5;if(t=="projectile")return 1<<6;if(t=="steamer")return 1<<7;if(t=="shot")return 1<<8;if(t=="trap")return 1<<9;if(t=="textbox")return 1<<10;if(t=="endlevel")return 1<<11;if(t=="npc")return 1<<12;if(t=="panel")return 1<<13;return 0;
}
static bool modelCanDamage(const generated::Character* attacker,const generated::Character* target,bool legacyDefault){
  if(!attacker||!target)return legacyDefault;int bit=openborTypeBit(target);
  if(attacker->canDamageMask!=0)return bit!=0&&(attacker->canDamageMask&bit)!=0;
  if(attacker->hostileMask!=0)return bit!=0&&(attacker->hostileMask&bit)!=0;
  return legacyDefault;
}
static int highestAttackIndex(const generated::Character* m){
  if(!m)return 1;int hi=1;for(std::size_t i=0;i<m->animationCount;++i){std::string n=lowerString(m->animations[i].name?m->animations[i].name:"");if(n=="attack")hi=std::max(hi,1);else if(n.rfind("attack",0)==0&&n.size()>6){try{hi=std::max(hi,std::stoi(n.substr(6)));}catch(...){}}}return hi;
}
static int comboWindowFor(const generated::Character* m,int fallback){
  if(!m||m->comboDelay<=0)return fallback;return std::max(6,(int)std::lround((double)m->comboDelay*0.30));
}
static std::vector<std::vector<int>> comboBranches(const generated::Character* m){
  std::vector<std::vector<int>> out;if(!m||!m->attackChain||m->attackChainCount==0)return out;out.push_back({});for(std::size_t i=0;i<m->attackChainCount;++i){int v=m->attackChain[i];if(v<=0){if(!out.back().empty())out.push_back({});continue;}out.back().push_back(v);}if(!out.empty()&&out.back().empty())out.pop_back();return out;
}
static int chainAttackNumber(const generated::Character* m,int step){
  if(!m)return std::max(1,step+1);if(!m->attackChain||m->attackChainCount==0)return ((std::max(0,step))%std::max(1,highestAttackIndex(m)))+1;
  auto branches=comboBranches(m);if(branches.empty())return 1;const auto&chain=branches.front();if(chain.empty())return 1;return chain[(std::size_t)(std::max(0,step)%((int)chain.size()))];
}
static bool attackRangePass(const generated::Character* m,int attack,float dx,float dz,float da){
  if(!m)return false;const generated::Animation* a=nullptr;std::string name="attack"+std::to_string(std::max(1,attack));for(std::size_t i=0;i<m->animationCount;++i)if(lowerString(m->animations[i].name?m->animations[i].name:"")==name){a=&m->animations[i];break;}if(!a)return false;float ax=std::fabs(dx),az=std::fabs(dz);float xmin=a->hasRangeX?a->rangeXMin:0.0f,xmax=a->hasRangeX?a->rangeXMax:75.0f;float zmin=a->hasRangeZ?std::min(std::fabs(a->rangeZMin),std::fabs(a->rangeZMax)):0.0f,zmax=a->hasRangeZ?std::max(std::fabs(a->rangeZMin),std::fabs(a->rangeZMax)):std::max(1.0f,(float)m->grabDistance/3.0f);float amin=a->hasRangeA?a->rangeAMin:-1000.0f,amax=a->hasRangeA?a->rangeAMax:1000.0f;return ax>=std::min(xmin,xmax)&&ax<=std::max(xmin,xmax)&&az>=zmin&&az<=zmax&&da>=amin&&da<=amax;
}
static int dynamicChainAttackNumber(const generated::Character* m,int step,int& branch,float dx,float dz,float da){
  if(!m||m->comboStyle!=1)return chainAttackNumber(m,step);auto b=comboBranches(m);if(b.empty())return chainAttackNumber(m,step);if(step<=0){branch=-1;return b[0].empty()?1:b[0][0];}
  if(branch<0){for(std::size_t bi=0;bi<b.size();++bi){std::size_t idx=(bi==0?(std::size_t)step:(std::size_t)step-1);if(idx<b[bi].size()&&attackRangePass(m,b[bi][idx],dx,dz,da)){branch=(int)bi;break;}}if(branch<0)branch=0;}
  std::size_t idx=(branch==0?(std::size_t)step:(std::size_t)step-1);if(branch<0||(std::size_t)branch>=b.size()||idx>=b[(std::size_t)branch].size()){branch=-1;return b[0].empty()?1:b[0][0];}return b[(std::size_t)branch][idx];
}
static bool followConditionPass(int cond,bool blocked,bool hostile,bool lethal,bool targetNoGrab){
  switch(cond){case 1:return true;case 2:return hostile;case 3:return hostile&&!lethal&&!blocked;case 4:return hostile&&!lethal&&!blocked&&!targetNoGrab;case 5:return hostile&&!lethal&&!blocked;default:return false;}
}
static bool animationHasProjectile(const generated::Animation* a){return a&&(a->throwFrame>=0||a->tossFrame>=0);}
static std::filesystem::path resolveSpriteAsset(const std::filesystem::path& dataRoot,const char* raw){
  if(!raw||!*raw)return {};
  auto rel=normalizeDataPath(raw);
  auto exact=dataRoot/rel;
  if(std::filesystem::exists(exact))return exact;
  if(rel.has_extension())return exact;
  // OpenBOR legacy extension fallback order.
  static const char* exts[]={".gif",".bmp",".pcx",".png"};
  for(auto* ext:exts){auto p=exact;p+=ext;if(std::filesystem::exists(p))return p;}
  return exact;
}
static std::filesystem::path resolveAudioAsset(const std::filesystem::path& dataRoot,const std::string& raw){
  if(raw.empty())return {};auto rel=normalizeDataPath(raw);if(rel.empty())return {};auto exact=dataRoot/rel;if(std::filesystem::exists(exact))return exact;if(rel.has_extension())return exact;
  // OpenBOR-compatible extension probing: exact path first, then streamed/native formats.
  static const char* exts[]={".ogg",".oga",".wav",".bor",".mp3",".flac"};for(auto* ext:exts){auto p=exact;p+=ext;if(std::filesystem::exists(p))return p;}return exact;
}
static int paletteIndexFromText(const char* raw){if(!raw||!*raw)return 0;try{return std::max(0,std::stoi(raw));}catch(...){return 0;}}
static unsigned char unpremul(unsigned char c,unsigned char a){if(a==0)return 0;return (unsigned char)std::min(255u,((unsigned)c*255u+(unsigned)a/2u)/(unsigned)a);}
static bool loadPaletteColors(Renderer& renderer,const std::filesystem::path& path,std::vector<unsigned>& colors){
  colors.clear();
  if(lowerExt(path)==".act"){
    std::ifstream f(path,std::ios::binary);if(!f)return false;std::vector<unsigned char> bytes((std::istreambuf_iterator<char>(f)),{});std::size_t count=std::min<std::size_t>(256,bytes.size()/3);if(count==0)return false;colors.reserve(count);for(std::size_t i=0;i<count;++i){unsigned r=bytes[i*3],g=bytes[i*3+1],b=bytes[i*3+2];colors.push_back(b|(g<<8)|(r<<16));}return true;
  }
  SpriteImage img;if(!renderer.loadSprite(path,img))return false;colors.reserve(img.bgra.size()/4);for(std::size_t o=0;o+3<img.bgra.size();o+=4){auto a=img.bgra[o+3];if(a==0){colors.push_back(0);continue;}unsigned b=unpremul(img.bgra[o],a),g=unpremul(img.bgra[o+1],a),r=unpremul(img.bgra[o+2],a);colors.push_back(b|(g<<8)|(r<<16));}return !colors.empty();
}
static void applyCharacterPalette(Renderer& renderer,const std::filesystem::path& dataRoot,const generated::Character* model,int mapIndex,SpriteImage& sprite){
  if(!model||mapIndex<=0||sprite.bgra.empty())return;
  const char* source=nullptr;const char* target=nullptr;
  if(model->paletteRemapCount>0 && model->paletteRemaps && (std::size_t)mapIndex<=model->paletteRemapCount){source=model->paletteRemaps[mapIndex-1].source;target=model->paletteRemaps[mapIndex-1].target;}
  else if(model->palettePath&&*model->palettePath&&model->alternatePalettes&&(std::size_t)mapIndex<=model->alternatePaletteCount){source=model->palettePath;target=model->alternatePalettes[mapIndex-1];}
  if(!source||!target||!*source||!*target)return;
  auto sourcePath=resolveSpriteAsset(dataRoot,source),targetPath=resolveSpriteAsset(dataRoot,target);std::vector<unsigned> srcColors,tgtColors;if(!loadPaletteColors(renderer,sourcePath,srcColors)||!loadPaletteColors(renderer,targetPath,tgtColors))return;
  const std::size_t count=std::min(srcColors.size(),tgtColors.size());if(count==0)return;std::unordered_map<unsigned,unsigned> lut;lut.reserve(count);for(std::size_t i=0;i<count;++i)lut[srcColors[i]]=tgtColors[i];
  for(std::size_t o=0;o+3<sprite.bgra.size();o+=4){auto a=sprite.bgra[o+3];if(a==0)continue;unsigned b=unpremul(sprite.bgra[o],a),g=unpremul(sprite.bgra[o+1],a),r=unpremul(sprite.bgra[o+2],a);auto it=lut.find(b|(g<<8)|(r<<16));if(it==lut.end())continue;unsigned v=it->second;unsigned nb=v&255u,ng=(v>>8)&255u,nr=(v>>16)&255u;sprite.bgra[o]=(unsigned char)(nb*a/255u);sprite.bgra[o+1]=(unsigned char)(ng*a/255u);sprite.bgra[o+2]=(unsigned char)(nr*a/255u);}
}

const generated::Character* Engine::findCharacter(const char* name) const{
  if(!name) return nullptr; auto wanted=lowerString(name);
  for(std::size_t i=0;i<generated::kCharacterCount;++i){
    const auto& c=generated::kCharacters[i];
    if((c.modelName && lowerString(c.modelName)==wanted) || (c.name && lowerString(c.name)==wanted)) return &c;
  }
  return nullptr;
}
const generated::Animation* Engine::findAnimation(const generated::Character* c,const char* preferred) const{
  if(!c || c->animationCount==0) return nullptr; auto wanted=lowerString(preferred?preferred:"");
  for(std::size_t i=0;i<c->animationCount;++i){ auto n=lowerString(c->animations[i].name); if(n==wanted || (!wanted.empty() && n.find(wanted)!=std::string::npos)) return &c->animations[i]; }
  return &c->animations[0];
}
static const generated::Animation* exactAnimation(const generated::Character* c,const std::string& wanted){if(!c)return nullptr;auto low=lowerString(wanted);for(std::size_t i=0;i<c->animationCount;++i)if(lowerString(c->animations[i].name)==low)return &c->animations[i];return nullptr;}
const generated::Animation* Engine::findActionAnimation(const generated::Character* base,const generated::Character* weapon,const char* preferred) const{
  if(weapon){if(auto* a=exactAnimation(weapon,preferred?preferred:""))return a;if((weapon->modelCopyFlags&1)!=0)return nullptr;}
  return findAnimation(base,preferred);
}
static const generated::Animation* followAnimationFor(const generated::Character* model,const generated::Animation* source){
  if(!model||!source||source->followAnim<=0)return nullptr;return exactAnimation(model,"follow"+std::to_string(source->followAnim));
}
struct CounterResult{const generated::Animation* animation=nullptr;bool takesDamage=true;bool rage=false;};
static CounterResult counterFor(const generated::Character* model,const generated::Animation* current,std::size_t frame,bool hostile,bool unblockable,bool fromFront,int currentHealth,int damage){
  CounterResult out;if(!model||!current||current->counterStart<0||current->counterEnd<current->counterStart||(int)frame<current->counterStart||(int)frame>current->counterEnd)return out;
  bool ok=false;switch(current->counterCond){case 1:ok=true;break;case 2:ok=hostile;break;case 3:ok=hostile&&!unblockable&&fromFront;break;case 4:ok=true;out.rage=true;break;default:break;}if(!ok)return out;
  out.animation=followAnimationFor(model,current);out.takesDamage=current->counterTakesDamage;if(out.rage&&currentHealth-damage<=0)out.takesDamage=false;return out;
}
static const generated::Animation* reactionAnimation(const generated::Character* c,const char* base,int attackType){if(!c)return nullptr;if(attackType>1){if(auto a=exactAnimation(c,std::string(base)+std::to_string(attackType)))return a;}if(auto a=exactAnimation(c,base))return a;return nullptr;}
void Engine::setEntityAnimation(RuntimeEntity& e,const generated::Animation* a){ if(a && e.animation.animation()!=a){ e.animation.setAnimation(a); e.lastFrame=(std::size_t)-1; } }

static std::string scriptString(const ScriptValue& v){if(auto p=std::get_if<std::string>(&v))return *p;if(auto p=std::get_if<double>(&v))return std::to_string(*p);if(auto p=std::get_if<bool>(&v))return *p?"1":"0";return {};}
static double scriptNumber(const ScriptValue& v){if(auto p=std::get_if<double>(&v))return *p;if(auto p=std::get_if<bool>(&v))return *p?1.0:0.0;if(auto p=std::get_if<std::uintptr_t>(&v))return (double)*p;if(auto p=std::get_if<std::string>(&v)){try{return std::stod(*p);}catch(...){}}return 0.0;}
static std::uintptr_t scriptPointer(const ScriptValue& v){if(auto p=std::get_if<std::uintptr_t>(&v))return *p;return (std::uintptr_t)scriptNumber(v);}
void Engine::runModelScript(const char* path, ScriptContext& ctx, const char* event){
  if(!path||!*path)return;auto result=scriptVm_.runFile(path,ctx,"main");if(!result.ok)std::cerr<<"Script VM "<<(event?event:"hook")<<" error ["<<path<<"]: "<<result.error<<"\n";
  if(!result.unsupported.empty()){std::filesystem::create_directories(root_/"logs");std::ofstream log(root_/"logs"/"script-vm.log",std::ios::app);for(const auto&f:result.unsupported){log<<(event?event:"hook")<<"\t"<<path<<"\tunsupported="<<f<<"\n";}}
}
enum ScriptKeyBits : unsigned {
  SK_LEFT=1u<<0, SK_RIGHT=1u<<1, SK_UP=1u<<2, SK_DOWN=1u<<3,
  SK_ATTACK=1u<<4, SK_JUMP=1u<<5, SK_SPECIAL=1u<<6, SK_START=1u<<7,
  SK_ESC=1u<<8, SK_ATTACK2=1u<<9, SK_ATTACK3=1u<<10, SK_ATTACK4=1u<<11
};
static unsigned scriptKeyBit(const std::string& raw){
  auto k=lowerString(raw);if(k=="moveleft"||k=="left")return SK_LEFT;if(k=="moveright"||k=="right")return SK_RIGHT;if(k=="moveup"||k=="up")return SK_UP;if(k=="movedown"||k=="down")return SK_DOWN;
  if(k=="attack"||k=="attack1")return SK_ATTACK;if(k=="attack2")return SK_ATTACK2;if(k=="attack3")return SK_ATTACK3;if(k=="attack4")return SK_ATTACK4;if(k=="jump")return SK_JUMP;if(k=="special")return SK_SPECIAL;if(k=="start")return SK_START;if(k=="esc"||k=="escape")return SK_ESC;
  if(k=="anybutton")return SK_ATTACK|SK_ATTACK2|SK_ATTACK3|SK_ATTACK4|SK_JUMP|SK_SPECIAL;return 0;
}
struct ParsedCommandStep{unsigned press=0,hold=0,holdTrigger=0,release=0;int holdMin=0,holdMax=0,chordTime=0;};
struct ParsedCommand{std::vector<ParsedCommandStep> steps;int sequenceGrace=50;int specificity=0;};
static unsigned commandBit(std::string tok,int facing){tok=lowerString(tok);if(tok=="a")return SK_ATTACK;if(tok=="a2")return SK_ATTACK2;if(tok=="a3")return SK_ATTACK3;if(tok=="a4")return SK_ATTACK4;if(tok=="j")return SK_JUMP;if(tok=="s"||tok=="k")return SK_SPECIAL;if(tok=="u")return SK_UP;if(tok=="d")return SK_DOWN;if(tok=="l")return SK_LEFT;if(tok=="r")return SK_RIGHT;if(tok=="f")return facing>=0?SK_RIGHT:SK_LEFT;if(tok=="b")return facing>=0?SK_LEFT:SK_RIGHT;return scriptKeyBit(tok);}
static int bracketNumber(const std::string&s,std::size_t from,int fallback=0){auto a=s.find('[',from),b=a==std::string::npos?std::string::npos:s.find(']',a+1);if(a==std::string::npos||b==std::string::npos)return fallback;try{return std::max(0,std::stoi(s.substr(a+1,b-a-1)));}catch(...){return fallback;}}
static ParsedCommand parseOpenBorCommand(std::string raw,int facing){
  ParsedCommand out;for(std::size_t p=0;(p=raw.find(":[",p))!=std::string::npos;){auto e=raw.find(']',p+2);if(e==std::string::npos)break;try{out.sequenceGrace=std::max(1,std::stoi(raw.substr(p+2,e-p-2)));}catch(...){}raw.replace(p,e-p+1," ");}
  for(std::size_t p=0;(p=raw.find("->",p))!=std::string::npos;){raw.replace(p,2," | ");p+=3;}for(char&c:raw)if(c==',')c=' ';
  std::istringstream ss(raw);std::string tok;ParsedCommandStep cur{};bool join=false;auto flush=[&](){if(cur.press||cur.hold||cur.holdTrigger||cur.release){out.steps.push_back(cur);cur={};}};
  while(ss>>tok){if(tok=="|"){flush();join=false;continue;}if(tok=="+"){join=true;continue;}if(tok.rfind("+[",0)==0){cur.chordTime=bracketNumber(tok,1,0);join=true;continue;}if((cur.press||cur.hold||cur.holdTrigger||cur.release)&&!join)flush();
    bool release=!tok.empty()&&tok[0]=='~';if(release)tok.erase(tok.begin());bool trigger=tok.find('*')!=std::string::npos;if(trigger)tok.erase(tok.find('*'),1);auto bp=tok.find('[');std::string key=bp==std::string::npos?tok:tok.substr(0,bp);unsigned bit=commandBit(key,facing);if(!bit){join=false;continue;}int minHold=bp==std::string::npos?0:bracketNumber(tok,bp,0);int maxHold=0;if(bp!=std::string::npos){auto close=tok.find(']',bp+1);if(close!=std::string::npos)maxHold=bracketNumber(tok,close+1,0);}if(release)cur.release|=bit;else if(trigger)cur.holdTrigger|=bit;else if(bp!=std::string::npos)cur.hold|=bit;else cur.press|=bit;if(bp!=std::string::npos){cur.holdMin=std::max(cur.holdMin,minHold);if(maxHold>0)cur.holdMax=cur.holdMax==0?maxHold:std::min(cur.holdMax,maxHold);}out.specificity+=1+(bp!=std::string::npos)+(release||trigger);join=false;
  }flush();return out;
}
static int heldDuration(const std::deque<InputHistoryEntry>&h,std::ptrdiff_t pos,unsigned bit){if(pos<0)return 0;std::ptrdiff_t p=pos;if((h[(std::size_t)p].held&bit)==0){if((h[(std::size_t)p].released&bit)==0)return 0;--p;}int n=0;for(;p>=0&&((h[(std::size_t)p].held&bit)!=0);--p)++n;return n;}
static bool commandStepMatches(const std::deque<InputHistoryEntry>&h,std::ptrdiff_t pos,const ParsedCommandStep&st){if(pos<0)return false;const auto&e=h[(std::size_t)pos];
  if(st.release&&((e.released&st.release)!=st.release))return false;if(st.holdTrigger){if((e.held&st.holdTrigger)!=st.holdTrigger)return false;for(unsigned b=1;b;b<<=1)if(st.holdTrigger&b){int d=heldDuration(h,pos,b);if(d!=std::max(1,st.holdMin))return false;}}
  if(st.press){if(st.chordTime<=0){if((e.newKeys&st.press)!=st.press)return false;}else{if((e.held&st.press)!=st.press)return false;for(unsigned b=1;b;b<<=1)if(st.press&b){bool edge=false;for(std::ptrdiff_t j=pos;j>=0&&pos-j<=st.chordTime;--j)if(h[(std::size_t)j].newKeys&b){edge=true;break;}if(!edge)return false;}}}
  unsigned holdMask=st.hold;if(st.release)holdMask|=st.release;for(unsigned b=1;b;b<<=1)if(holdMask&b){int d=heldDuration(h,pos,b);if(d<st.holdMin)return false;if(st.holdMax>0&&d>st.holdMax)return false;}return st.press||st.release||st.holdTrigger;
}
static bool matchOpenBorCommand(const std::deque<InputHistoryEntry>&h,const std::string&raw,int facing,int* score=nullptr){if(h.empty())return false;auto parsed=parseOpenBorCommand(raw,facing);if(parsed.steps.empty())return false;std::ptrdiff_t pos=(std::ptrdiff_t)h.size()-1,newest=-1,previous=-1;for(std::ptrdiff_t si=(std::ptrdiff_t)parsed.steps.size()-1;si>=0;--si){bool found=false;for(;pos>=0;--pos){if(previous>=0&&previous-pos>parsed.sequenceGrace)break;if(commandStepMatches(h,pos,parsed.steps[(std::size_t)si])){if(newest<0)newest=pos;previous=pos;found=true;--pos;break;}}if(!found)return false;}if(newest!=(std::ptrdiff_t)h.size()-1)return false;if(score)*score=(int)parsed.steps.size()*100+parsed.specificity;return true;}
const generated::Animation* Engine::cancelTarget(const generated::Character* model,const generated::Animation* anim,std::size_t frame,int hits,int slot,int facing) const{
  if(!model||!anim||!anim->cancels||anim->cancelCount==0||slot<0||slot>=4)return nullptr;const auto&hist=playerInputHistory_[slot];for(std::size_t i=0;i<anim->cancelCount;++i){const auto&c=anim->cancels[i];if((int)frame<c.startFrame||(int)frame>c.endFrame||hits<c.hits)continue;if(!matchOpenBorCommand(hist,c.command?c.command:"",facing))continue;std::string target=c.targetAnimation?c.targetAnimation:"";if(target.empty())continue;if(std::all_of(target.begin(),target.end(),[](unsigned char ch){return std::isdigit(ch)!=0;}))target="freespecial"+target;if(auto*a=exactAnimation(model,target))return a;if(auto*a=findAnimation(model,target.c_str()))return a;}return nullptr;
}
void Engine::recordInputHistory(int slot){if(slot<0||slot>=4)return;InputHistoryEntry e{playerPlayKeys_[slot],playerNewKeys_[slot],playerReleasedKeys_[slot]};auto&h=playerInputHistory_[slot];h.push_back(e);while(h.size()>128)h.pop_front();}
const generated::Animation* Engine::commandTarget(const generated::Character* model,int slot,int facing) const{
  if(!model||!model->commands||model->commandCount==0||slot<0||slot>=4)return nullptr;const auto&hist=playerInputHistory_[slot];const generated::Animation*best=nullptr;int bestScore=-1;for(std::size_t ci=0;ci<model->commandCount;++ci){const auto&cmd=model->commands[ci];int score=0;if(!matchOpenBorCommand(hist,cmd.sequence?cmd.sequence:"",facing,&score))continue;std::string target=cmd.targetAnimation?cmd.targetAnimation:"";if(target.empty())continue;if(std::all_of(target.begin(),target.end(),[](unsigned char ch){return std::isdigit(ch)!=0;}))target="freespecial"+target;const generated::Animation*a=exactAnimation(model,target);if(!a)a=findAnimation(model,target.c_str());if(a&&score>=bestScore){best=a;bestScore=score;}}return best;
}
static ScriptValue openborConstantValue(const std::string& raw){
  auto k=lowerString(raw);
  if(k.rfind("ani_",0)==0)return k.substr(4);
  if(k.rfind("type_",0)==0)return k.substr(5);
  if(k=="flag_moveleft")return (double)SK_LEFT;if(k=="flag_moveright")return (double)SK_RIGHT;if(k=="flag_moveup")return (double)SK_UP;if(k=="flag_movedown")return (double)SK_DOWN;
  if(k=="flag_attack"||k=="flag_attack1")return (double)SK_ATTACK;if(k=="flag_attack2")return (double)SK_ATTACK2;if(k=="flag_attack3")return (double)SK_ATTACK3;if(k=="flag_attack4")return (double)SK_ATTACK4;
  if(k=="flag_jump")return (double)SK_JUMP;if(k=="flag_special")return (double)SK_SPECIAL;if(k=="flag_start")return (double)SK_START;if(k=="flag_esc")return (double)SK_ESC;
  if(k=="direction_left")return 0.0;if(k=="direction_right")return 1.0;
  if(k=="type_none")return (double)(1<<0);if(k=="type_player")return (double)(1<<2);if(k=="type_enemy")return (double)(1<<3);if(k=="type_item")return (double)(1<<4);if(k=="type_obstacle")return (double)(1<<5);if(k=="type_projectile")return (double)(1<<6);if(k=="type_shot")return (double)(1<<8);if(k=="type_trap")return (double)(1<<9);if(k=="type_npc")return (double)(1<<12);
  if(k=="aiattack1_normal")return 0.0;if(k=="aiattack1_long")return 1.0;if(k=="aiattack1_melee")return 2.0;if(k=="aiattack1_noattack")return 4.0;if(k=="aiattack1_always")return 8.0;if(k=="aiattack2_dodge")return 65536.0;if(k=="aiattack2_dodgemove")return 131072.0;
  if(k=="aimove1_none")return 0.0;if(k=="aimove1_normal")return 1.0;if(k=="aimove1_chase")return 2.0;if(k=="aimove1_chasez")return 4.0;if(k=="aimove1_chasex")return 8.0;if(k=="aimove1_avoid")return 16.0;if(k=="aimove1_avoidz")return 32.0;if(k=="aimove1_avoidx")return 64.0;if(k=="aimove1_wander")return 128.0;if(k=="aimove1_biker")return 256.0;if(k=="aimove1_arrow")return 512.0;if(k=="aimove1_star")return 1024.0;if(k=="aimove1_bomb")return 2048.0;if(k=="aimove1_nomove")return 4096.0;if(k=="aimove2_ignoreholes")return 65536.0;if(k=="aimove2_notargetidle")return 131072.0;
  if(k=="block_state_active")return 1.0;if(k=="block_state_native")return 2.0;if(k=="block_state_ignore_chance")return 4.0;if(k=="block_state_ignore_guard_points")return 8.0;if(k=="block_state_ignore_direction")return 16.0;if(k=="block_state_ignore_attack_eligibility")return 32.0;if(k=="block_state_ignore_blockpain")return 64.0;
  static const std::unordered_map<std::string,std::string> props={
    {"entity_property_hp","health"},{"entity_property_health","health"},{"entity_property_hp_max","maxhealth"},{"entity_property_max_health","maxhealth"},
    {"entity_property_position_x","x"},{"entity_property_position_z","z"},{"entity_property_position_y","altitude"},{"entity_property_altitude","altitude"},
    {"entity_property_direction","direction"},{"entity_property_animation","animation"},{"entity_property_animation_frame","animpos"},
    {"entity_property_velocity_x","xdir"},{"entity_property_velocity_z","zdir"},{"entity_property_velocity_y","tossv"},
    {"entity_property_color_map","colourmap"},{"entity_property_colourmap","colourmap"},{"entity_property_modeldata","modelptr"},{"entity_property_model","modelptr"},
    {"entity_property_block_state","blockstate"},{"entity_property_guard_points","guardpoints"},{"entity_property_exists","exists"},{"entity_property_dead","dead"},
    {"model_property_name","name"},{"model_property_type","type"},{"model_property_subtype","subtype"},{"model_property_hp","health"},{"model_property_health","health"},
    {"model_property_speed","speed"},{"model_property_run_speed","runspeed"},{"model_property_grab_distance","grabdistance"},{"model_property_juggle_points","jugglepoints"},
    {"model_property_block_odds","blockodds"},{"model_property_block_pain","blockpain"},{"model_property_block_threshold","blockthreshold"},{"model_property_guard_points","guardpoints"},{"model_property_guard_rate","guardrate"},
    {"model_property_aggression","aggression"},{"model_property_ai_attack","aiattack"},{"model_property_ai_move","aimove"},{"model_property_candamage","candamage"},{"model_property_hostile","hostile"},{"model_property_projectilehit","projectilehit"},
    {"model_property_nograb","nograb"},{"model_property_grab_force","grabforce"},{"model_property_grab_resistance","grabresistance"},{"model_property_throw_damage","throwdamage"},{"model_property_bounce","bounce"},{"model_property_subject_to_gravity","subject_to_gravity"},
    {"level_property_name","name"},{"level_property_width","width"},{"level_property_height","height"},{"level_property_z_min","zmin"},{"level_property_z_max","zmax"},
    {"level_property_camera_x","camerax"},{"level_property_scroll_speed","scrollspeed"},{"level_property_direction","direction"},{"level_property_branch","branch"}
  };
  auto it=props.find(k);if(it!=props.end())return it->second;
  if(k=="plane_x")return 0.0;if(k=="plane_z")return 1.0;
  if(k=="blend_none")return 0.0;if(k=="blend_alpha")return 1.0;if(k=="blend_add")return 2.0;if(k=="blend_multiply")return 3.0;
  return 0.0;
}
ScriptValue Engine::callScriptFunction(const std::string& raw,const std::vector<ScriptValue>& a,ScriptContext& ctx,std::vector<std::string>& unsupported){
  auto name=lowerString(raw);
  auto normalizeHandle=[&](std::uintptr_t p)->std::uintptr_t{if(p==0&&ctx.entity)return (std::uintptr_t)ctx.entity;if(p==0&&ctx.player)return (std::uintptr_t)(ctx.playerIndex+1);return p;};
  auto entityFromHandle=[&](std::uintptr_t p)->RuntimeEntity*{p=normalizeHandle(p);if(p<=4)return nullptr;for(auto& e:entities_)if((std::uintptr_t)&e==p)return &e;return nullptr;};
  auto playerSlot=[&](std::uintptr_t p)->int{p=normalizeHandle(p);return p>=1&&p<=4?(int)p-1:-1;};
  auto modelForPlayer=[&](int slot)->const generated::Character*{if(slot==0)return playerModel_;std::size_t i=(std::size_t)(slot-1);return i<coopPlayers_.size()?coopPlayers_[i].model:nullptr;};
  auto playerAliveFor=[&](int slot)->bool{if(slot==0)return playerAlive_;std::size_t i=(std::size_t)(slot-1);return i<coopPlayers_.size()&&coopPlayers_[i].alive;};
  auto playerX=[&](int slot)->float{if(slot==0)return playerWorldX_;std::size_t i=(std::size_t)(slot-1);return i<coopPlayers_.size()?coopPlayers_[i].worldX:0.0f;};
  auto playerZ=[&](int slot)->float{if(slot==0)return playerZ_;std::size_t i=(std::size_t)(slot-1);return i<coopPlayers_.size()?coopPlayers_[i].z:0.0f;};
  auto playerAlt=[&](int slot)->float{if(slot==0)return -playerAltitude_;std::size_t i=(std::size_t)(slot-1);return i<coopPlayers_.size()?-coopPlayers_[i].altitude:0.0f;};
  auto playerFace=[&](int slot)->int{if(slot==0)return playerFacing_;std::size_t i=(std::size_t)(slot-1);return i<coopPlayers_.size()?coopPlayers_[i].facing:1;};
  auto getAnimName=[&](std::uintptr_t p)->std::string{int slot=playerSlot(p);if(slot==0)return player_.animation()&&player_.animation()->name?player_.animation()->name:"";if(slot>0){std::size_t i=(std::size_t)(slot-1);return i<coopPlayers_.size()&&coopPlayers_[i].animation.animation()&&coopPlayers_[i].animation.animation()->name?coopPlayers_[i].animation.animation()->name:"";}auto*e=entityFromHandle(p);return e&&e->animation.animation()&&e->animation.animation()->name?e->animation.animation()->name:"";};
  auto setAnim=[&](std::uintptr_t p,const std::string& an)->bool{int slot=playerSlot(p);if(slot==0){auto q=findAnimation(playerModel_,an.c_str());if(!q)return false;player_.setAnimation(q);lastFrame_=(std::size_t)-1;return true;}if(slot>0){std::size_t i=(std::size_t)(slot-1);if(i>=coopPlayers_.size())return false;auto q=findAnimation(coopPlayers_[i].model,an.c_str());if(!q)return false;coopPlayers_[i].animation.setAnimation(q);coopPlayers_[i].lastFrame=(std::size_t)-1;return true;}auto*e=entityFromHandle(p);if(!e)return false;auto q=findAnimation(e->model,an.c_str());if(!q)return false;setEntityAnimation(*e,q);return true;};
  auto entityVarMap=[&](std::uintptr_t p)->std::unordered_map<std::string,ScriptValue>*{int slot=playerSlot(p);if(slot>=0&&slot<4)return &playerScriptVars_[slot];auto*e=entityFromHandle(p);return e?&e->scriptVars:nullptr;};
  auto modelFromValue=[&](const ScriptValue& v)->const generated::Character*{
    if(auto sp=std::get_if<std::string>(&v))return findCharacter(sp->c_str());
    auto p=scriptPointer(v);for(std::size_t i=0;i<generated::kCharacterCount;++i)if((std::uintptr_t)&generated::kCharacters[i]==p)return &generated::kCharacters[i];
    int slot=playerSlot(p);if(slot>=0)return modelForPlayer(slot);if(auto*e=entityFromHandle(p))return e->model;return nullptr;
  };

  if(name=="openborconstant") return a.empty()?ScriptValue(0.0):openborConstantValue(scriptString(a[0]));
  if(name=="openborvariant") {
    auto k=a.empty()?std::string{}:lowerString(scriptString(a[0]));
    if(k=="xpos"||k=="levelpos")return (double)cameraX_;if(k=="elapsed_time"||k=="elapsedtime")return (double)tickCounter_;
    if(k=="count_players")return (double)(1+coopPlayers_.size());if(k=="maxplayers"||k=="max_players")return (double)config_.maxPlayers;
    if(k=="count_entities"||k=="ent_count"){int n=0;for(const auto&e:entities_)if(e.visible)++n;return(double)n;}if(k=="count_enemies"){int n=0;for(const auto&e:entities_)if(e.alive&&e.model&&lowerString(e.model->type)=="enemy")++n;return(double)n;}
    if(k=="current_player")return (double)ctx.playerIndex;if(k=="current_level"||k=="currentlevel")return (double)stageIndex_;if(k=="current_branch"||k=="currentbranch")return stage_&&stage_->branchName?std::string(stage_->branchName):std::string{};
    if(k=="hresolution")return (double)config_.logicalWidth;if(k=="vresolution")return (double)config_.logicalHeight;if(k=="levelwidth")return(double)stageLength_;if(k=="levelheight")return stage_?(double)(stage_->zMax-stage_->zMin):0.0;
    if(k=="in_level"||k=="inlevel")return stage_!=nullptr&&frontendState_==FrontendState::Playing;if(k=="game_speed"||k=="gamespeed")return 60.0;
    return 0.0;
  }
  if(name=="changeopenborvariant"||name=="setopenborvariant") {if(a.size()>1){auto k=lowerString(scriptString(a[0]));if(k=="xpos"||k=="levelpos")cameraX_=std::clamp((float)scriptNumber(a[1]),0.0f,std::max(0.0f,stageLength_-(float)config_.logicalWidth));}return a.size()>1?a[1]:ScriptValue{};}
  if(name=="jumptobranch"){if(a.empty())return false;auto wanted=lowerString(scriptString(a[0]));std::size_t targetIndex=(std::size_t)-1;for(std::size_t i=0;i<generated::kStageCount;++i){auto label=generated::kStages[i].branchName?lowerString(generated::kStages[i].branchName):std::string{};if(!label.empty()&&label==wanted){targetIndex=i;break;}}if(targetIndex==(std::size_t)-1){if(std::find(unsupported.begin(),unsupported.end(),"jumptobranch-missing:"+wanted)==unsupported.end())unsupported.push_back("jumptobranch-missing:"+wanted);return false;}pendingBranchTarget_=targetIndex;pendingBranchImmediate_=a.size()>1&&scriptNumber(a[1])!=0;if(pendingBranchImmediate_){stageComplete_=true;}return true;}

  if(name=="getentity"||name=="get_entity"){if(a.empty())return std::uintptr_t(0);long long idx=(long long)scriptNumber(a[0]);if(idx<0||(std::size_t)idx>=entities_.size())return std::uintptr_t(0);auto it=entities_.begin();std::advance(it,idx);return std::uintptr_t((std::uintptr_t)&*it);}
  if(name=="findtarget"||name=="find_target"){
    std::uintptr_t self=a.empty()?normalizeHandle(0):normalizeHandle(scriptPointer(a[0]));int slot=playerSlot(self);float sx=0,sz=0;if(slot>=0){sx=playerX(slot);sz=playerZ(slot);RuntimeEntity*best=nullptr;float bd=1e30f;for(auto&e:entities_){if(!e.alive||!e.model||lowerString(e.model->type)!="enemy")continue;float d=std::fabs(e.worldX-sx)+std::fabs(e.z-sz);if(d<bd){bd=d;best=&e;}}return best?ScriptValue(std::uintptr_t((std::uintptr_t)best)):ScriptValue(std::uintptr_t(0));}
    auto* selfEnt=entityFromHandle(self);if(!selfEnt)return std::uintptr_t(0);sx=selfEnt->worldX;sz=selfEnt->z;int bestSlot=-1;float bd=1e30f;for(int ps=0;ps<4;++ps){if(!playerAliveFor(ps))continue;float d=std::fabs(playerX(ps)-sx)+std::fabs(playerZ(ps)-sz);if(d<bd){bd=d;bestSlot=ps;}}return bestSlot>=0?ScriptValue(std::uintptr_t((std::uintptr_t)(bestSlot+1))):ScriptValue(std::uintptr_t(0));
  }
  if(name=="checkrange"||name=="check_range"){
    if(a.size()<2)return false;auto p1=normalizeHandle(scriptPointer(a[0])),p2=normalizeHandle(scriptPointer(a[1]));auto pos=[&](std::uintptr_t p,float&x,float&z)->bool{int sl=playerSlot(p);if(sl>=0){if(!playerAliveFor(sl))return false;x=playerX(sl);z=playerZ(sl);return true;}auto*e=entityFromHandle(p);if(!e||!e->alive)return false;x=e->worldX;z=e->z;return true;};float x1,z1,x2,z2;if(!pos(p1,x1,z1)||!pos(p2,x2,z2))return false;float range=(float)config_.enemyAttackRange;if(auto*e=entityFromHandle(p1);e&&e->model)range=(float)std::max(e->model->grabDistance,config_.enemyAttackRange);return std::fabs(x1-x2)<=range&&std::fabs(z1-z2)<=24.0f;
  }

  if(name=="getentityproperty"||name=="get_entity_property") {
    if(a.size()<2)return {};auto p=normalizeHandle(scriptPointer(a[0]));auto k=lowerString(scriptString(a[1]));int slot=playerSlot(p);
    if(slot>=0){auto*m=modelForPlayer(slot);if(!m)return {};if(k=="x")return(double)playerX(slot);if(k=="z")return(double)playerZ(slot);if(k=="a"||k=="altitude")return(double)playerAlt(slot);if(k=="health")return slot==0?(double)playerHealth_:(double)coopPlayers_[(std::size_t)(slot-1)].health;if(k=="maxhealth")return slot==0?(double)playerMaxHealth_:(double)coopPlayers_[(std::size_t)(slot-1)].maxHealth;if(k=="direction")return(double)(playerFace(slot)<0?0:1);if(k=="name"||k=="model")return std::string(m->name);if(k=="modelptr")return std::uintptr_t((std::uintptr_t)m);if(k=="blockstate")return slot==0?(double)playerBlockState_:(double)coopPlayers_[(std::size_t)(slot-1)].blockState;if(k=="guardpoints")return slot==0?(double)playerGuardPoints_:(double)coopPlayers_[(std::size_t)(slot-1)].guardPoints;if(k=="type")return std::string(m->type);if(k=="subtype")return std::string(m->subtype);if(k=="playerindex")return(double)slot;if(k=="speed")return(double)m->speed;if(k=="animpos"||k=="animationposition")return slot==0?(double)player_.frameIndex():(double)coopPlayers_[(std::size_t)(slot-1)].animation.frameIndex();if(k=="animating")return slot==0?(player_.finished()?0.0:1.0):(coopPlayers_[(std::size_t)(slot-1)].animation.finished()?0.0:1.0);if(k=="xdir")return slot==0?(double)playerScriptVelocityX_:(double)coopPlayers_[(std::size_t)(slot-1)].scriptVelocityX;if(k=="zdir")return slot==0?(double)playerScriptVelocityZ_:(double)coopPlayers_[(std::size_t)(slot-1)].scriptVelocityZ;if(k=="tossv"||k=="velocityy")return slot==0?(double)playerVerticalVelocity_:(double)coopPlayers_[(std::size_t)(slot-1)].verticalVelocity;if(k=="attacking")return slot==0?playerAttackTicks_>0:coopPlayers_[(std::size_t)(slot-1)].attackTicks>0;if(k=="animationid"||k=="animation")return getAnimName(p);if(k=="exists")return playerAliveFor(slot);if(k=="dead")return !playerAliveFor(slot);if(k=="colourmap"||k=="colormap"||k=="map")return slot==0?0.0:(double)coopPlayers_[(std::size_t)(slot-1)].paletteMap;if(k=="aiflag"&&a.size()>2){auto f=lowerString(scriptString(a[2]));if(f=="drop"||f=="falling")return slot==0?(playerFallTicks_>0||playerAltitude_<0):(coopPlayers_[(std::size_t)(slot-1)].altitude<0);return false;}return {};}
    auto*e=entityFromHandle(p);if(!e)return {};if(k=="x")return(double)e->worldX;if(k=="z")return(double)e->z;if(k=="a"||k=="altitude")return(double)(-e->altitude);if(k=="health")return(double)e->health;if(k=="maxhealth")return(double)e->maxHealth;if(k=="direction")return(double)(e->facing<0?0:1);if(k=="name"||k=="model")return e->model?std::string(e->model->name):std::string{};if(k=="modelptr")return e->model?ScriptValue(std::uintptr_t((std::uintptr_t)e->model)):ScriptValue(std::uintptr_t(0));if(k=="blockstate")return(double)e->blockState;if(k=="guardpoints")return(double)e->guardPoints;if(k=="type")return e->model?std::string(e->model->type):std::string{};if(k=="subtype")return e->model?std::string(e->model->subtype):std::string{};if(k=="speed")return e->model?(double)e->model->speed:0.0;if(k=="animpos"||k=="animationposition")return(double)e->animation.frameIndex();if(k=="animating")return e->animation.finished()?0.0:1.0;if(k=="xdir")return(double)e->scriptVelocityX;if(k=="zdir")return(double)e->scriptVelocityZ;if(k=="tossv"||k=="velocityy")return(double)e->verticalVelocity;if(k=="attacking")return e->attackTicks>0;if(k=="animationid"||k=="animation")return getAnimName(p);if(k=="exists")return e->visible;if(k=="dead")return !e->alive;if(k=="colourmap"||k=="colormap"||k=="map")return(double)e->paletteMap;if(k=="aiflag"&&a.size()>2){auto f=lowerString(scriptString(a[2]));if(f=="drop")return e->fallTicks>0||e->altitude<0;if(f=="falling")return e->altitude<0&&e->verticalVelocity>0;if(f=="attacking")return e->attackTicks>0;return false;}return {};
  }
  if(name=="changeentityproperty"||name=="change_entity_property"||name=="setentityproperty") {
    if(a.size()<3)return {};auto p=normalizeHandle(scriptPointer(a[0]));auto k=lowerString(scriptString(a[1]));int slot=playerSlot(p);double v=scriptNumber(a[2]);
    if(k=="animation"||k=="animationid")return setAnim(p,scriptString(a[2]));
    if(slot>=0){if(k=="x"){if(slot==0)playerWorldX_=(float)v;else coopPlayers_[(std::size_t)(slot-1)].worldX=(float)v;}else if(k=="z"){if(slot==0)playerZ_=(float)v;else coopPlayers_[(std::size_t)(slot-1)].z=(float)v;}else if(k=="a"||k=="altitude"){if(slot==0)playerAltitude_=-(float)v;else coopPlayers_[(std::size_t)(slot-1)].altitude=-(float)v;}else if(k=="health"){if(slot==0)playerHealth_=std::clamp((int)v,0,playerMaxHealth_);else{auto&cp=coopPlayers_[(std::size_t)(slot-1)];cp.health=std::clamp((int)v,0,cp.maxHealth);}}else if(k=="maxhealth"){if(slot==0){playerMaxHealth_=std::max(1,(int)v);playerHealth_=std::min(playerHealth_,playerMaxHealth_);}else{auto&cp=coopPlayers_[(std::size_t)(slot-1)];cp.maxHealth=std::max(1,(int)v);cp.health=std::min(cp.health,cp.maxHealth);}}else if(k=="direction"){int f=v==0?-1:1;if(slot==0)playerFacing_=f;else coopPlayers_[(std::size_t)(slot-1)].facing=f;}else if(k=="colourmap"||k=="colormap"||k=="map"){if(slot>0)coopPlayers_[(std::size_t)(slot-1)].paletteMap=(int)v;}else if(k=="blockstate"){if(slot==0)playerBlockState_=(int)v;else coopPlayers_[(std::size_t)(slot-1)].blockState=(int)v;}else if(k=="guardpoints"){if(slot==0)playerGuardPoints_=(int)v;else coopPlayers_[(std::size_t)(slot-1)].guardPoints=(int)v;}else if(k=="velocity"){float vx=(float)v,vz=a.size()>3?(float)scriptNumber(a[3]):0.0f,va=a.size()>4?(float)scriptNumber(a[4]):0.0f;if(slot==0){playerScriptVelocityX_=vx;playerScriptVelocityZ_=vz;if(a.size()>4)playerVerticalVelocity_=va;}else{std::size_t ci=(std::size_t)(slot-1);if(ci>=coopPlayers_.size())return false;auto&cp=coopPlayers_[ci];cp.scriptVelocityX=vx;cp.scriptVelocityZ=vz;if(a.size()>4)cp.verticalVelocity=va;}}return a[2];}
    auto*e=entityFromHandle(p);if(!e)return {};if(k=="x")e->worldX=(float)v;else if(k=="z")e->z=(float)v;else if(k=="a"||k=="altitude")e->altitude=-(float)v;else if(k=="health")e->health=std::clamp((int)v,0,e->maxHealth);else if(k=="maxhealth"){e->maxHealth=std::max(1,(int)v);e->health=std::min(e->health,e->maxHealth);}else if(k=="direction")e->facing=v==0?-1:1;else if(k=="colourmap"||k=="colormap"||k=="map")e->paletteMap=(int)v;else if(k=="blockstate")e->blockState=(int)v;else if(k=="guardpoints")e->guardPoints=(int)v;else if(k=="velocity"){e->scriptVelocityX=(float)v;e->scriptVelocityZ=a.size()>3?(float)scriptNumber(a[3]):0.0f;if(a.size()>4)e->verticalVelocity=(float)scriptNumber(a[4]);}return a[2];
  }
  if(name=="getmodelproperty"||name=="get_model_property"){
    if(a.size()<2)return {};auto*m=modelFromValue(a[0]);if(!m)return {};auto k=lowerString(scriptString(a[1]));
    if(k=="name")return std::string(m->name);if(k=="type")return std::string(m->type);if(k=="subtype")return std::string(m->subtype);if(k=="health"||k=="hp")return(double)m->health;if(k=="speed")return(double)m->speed;if(k=="runspeed")return(double)m->runSpeed;if(k=="grabdistance")return(double)m->grabDistance;if(k=="jugglepoints")return(double)m->jugglePoints;if(k=="blockodds")return(double)m->blockOdds;if(k=="blockpain")return(double)m->blockPain;if(k=="blockthreshold")return(double)m->blockThreshold;if(k=="guardpoints")return(double)m->guardPoints;if(k=="guardrate")return(double)m->guardRate;if(k=="aggression")return(double)m->aggression;if(k=="aiattack")return(double)m->aiAttack;if(k=="aimove")return(double)m->aiMove;if(k=="candamage")return(double)m->canDamageMask;if(k=="hostile")return(double)m->hostileMask;if(k=="projectilehit")return(double)m->projectileHitMask;if(k=="nograb")return m->noGrab;if(k=="grabforce")return(double)m->grabForce;if(k=="grabresistance")return(double)m->grabResistance;if(k=="throwdamage")return(double)m->throwDamage;if(k=="throwdist")return(double)m->throwDistance;if(k=="throwheight")return(double)m->throwHeight;if(k=="bounce")return(double)m->bounce;if(k=="bouncefactor")return(double)m->bounceFactor;if(k=="subject_to_gravity")return m->subjectToGravity;return {};
  }
  if(name=="getlevelproperty"||name=="get_level_property"){
    if(a.empty()||!stage_)return {};auto k=lowerString(scriptString(a.size()>1?a[1]:a[0]));if(k=="name"||k=="source")return std::string(stage_->sourceFile?stage_->sourceFile:"");if(k=="width")return(double)stageLength_;if(k=="height")return(double)(stage_->zMax-stage_->zMin);if(k=="zmin")return(double)stage_->zMin;if(k=="zmax")return(double)stage_->zMax;if(k=="camerax")return(double)cameraX_;if(k=="scrollspeed")return(double)stage_->scrollSpeed;if(k=="direction")return std::string(stage_->direction?stage_->direction:"");if(k=="branch")return std::string(stage_->branchName?stage_->branchName:"");return {};
  }
  if(name=="changelevelproperty"||name=="set_level_property"||name=="setlevelproperty"){
    if(a.size()<2||!stage_)return false;auto k=lowerString(scriptString(a.size()>2?a[1]:a[0]));const auto&v=a.size()>2?a[2]:a[1];if(k=="camerax"){cameraX_=std::clamp((float)scriptNumber(v),0.0f,std::max(0.0f,stageLength_-(float)config_.logicalWidth));return v;}return false;
  }

  if(name=="getentityvar"||name=="get_entity_var"){if(a.size()<2)return {};auto*m=entityVarMap(normalizeHandle(scriptPointer(a[0])));if(!m)return {};auto it=m->find(scriptString(a[1]));return it==m->end()?ScriptValue{}:it->second;}
  if(name=="setentityvar"||name=="set_entity_var"){if(a.size()<3)return {};auto*m=entityVarMap(normalizeHandle(scriptPointer(a[0])));if(!m)return {};(*m)[scriptString(a[1])]=a[2];return a[2];}
  if(name=="clearentityvar"||name=="clear_entity_var"){if(a.empty())return false;auto*m=entityVarMap(normalizeHandle(scriptPointer(a[0])));if(!m)return false;if(a.size()>1)m->erase(scriptString(a[1]));else m->clear();return true;}

  if(name=="setanimation"||name=="changeanimation") {std::uintptr_t p=a.empty()?normalizeHandle(0):normalizeHandle(scriptPointer(a[0]));std::string an=a.size()>1?scriptString(a[1]):"idle";return setAnim(p,an);}
  if(name=="performattack"||name=="perform_attack") {
    std::uintptr_t p=a.empty()?normalizeHandle(0):normalizeHandle(scriptPointer(a[0]));std::string an=a.size()>1?scriptString(a[1]):"attack1";if(!setAnim(p,an))return false;int slot=playerSlot(p);
    if(slot==0){auto aa=player_.animation();playerAttackTicks_=std::max(8,aa?(int)aa->frameCount*6:8);playerAttackCooldown_=std::max(2,playerAttackTicks_/3);playerProjectileFired_=false;++playerAttackId_;if(playerModel_&&playerModel_->onDoAttackScript&&*playerModel_->onDoAttackScript){playerScriptCtx_.local["attack"]=an;runModelScript(playerModel_->onDoAttackScript,playerScriptCtx_,"script-player-performattack");}}
    else if(slot>0){auto&cp=coopPlayers_[(std::size_t)(slot-1)];auto aa=cp.animation.animation();cp.attackTicks=std::max(8,aa?(int)aa->frameCount*6:8);cp.attackCooldown=std::max(2,cp.attackTicks/3);cp.attackHasHit=false;++cp.attackId;if(cp.model&&cp.model->onDoAttackScript&&*cp.model->onDoAttackScript){cp.scriptCtx.local["attack"]=an;runModelScript(cp.model->onDoAttackScript,cp.scriptCtx,"script-coop-performattack");}}
    else if(auto*e=entityFromHandle(p)){auto aa=e->animation.animation();e->attackTicks=std::max(8,aa?(int)aa->frameCount*6:8);e->attackCooldown=std::max(2,e->attackTicks/3);e->attackHasHit=false;e->projectileFired=false;if(e->model&&e->model->onDoAttackScript&&*e->model->onDoAttackScript){e->scriptCtx.local["attack"]=an;runModelScript(e->model->onDoAttackScript,e->scriptCtx,"script-entity-performattack");}}
    return true;
  }
  if(name=="setidle") {std::uintptr_t p=a.empty()?normalizeHandle(0):normalizeHandle(scriptPointer(a[0]));std::string an=a.size()>1?scriptString(a[1]):"idle";return setAnim(p,an);}
  if(name=="updateframe") {if(a.size()<2)return false;auto p=normalizeHandle(scriptPointer(a[0]));std::size_t f=(std::size_t)std::max(0.0,scriptNumber(a[1]));int slot=playerSlot(p);if(slot==0){player_.setFrame(f);lastFrame_=(std::size_t)-1;return true;}if(slot>0){auto&cp=coopPlayers_[(std::size_t)(slot-1)];cp.animation.setFrame(f);cp.lastFrame=(std::size_t)-1;return true;}if(auto*e=entityFromHandle(p)){e->animation.setFrame(f);e->lastFrame=(std::size_t)-1;return true;}return false;}

  if(name=="damageentity"||name=="damage_entity") {if(a.empty())return {};auto p=normalizeHandle(scriptPointer(a[0]));int dmg=a.size()>2?(int)scriptNumber(a[2]):(a.size()>1?(int)scriptNumber(a[1]):1);int slot=playerSlot(p);if(slot==0)damagePlayer(dmg,-1,false,-3,0,normalizeHandle(0));else if(slot>0){std::size_t ci=(std::size_t)(slot-1);if(ci>=coopPlayers_.size())return false;damageCoopPlayer(coopPlayers_[ci],dmg,-1,false,-3,0,normalizeHandle(0));}else if(auto*e=entityFromHandle(p))damageEnemy(*e,dmg,-1,false,-3,0,normalizeHandle(0));return true;}
  if(name=="killentity"||name=="kill_entity") {if(a.empty())return {};auto p=normalizeHandle(scriptPointer(a[0]));int slot=playerSlot(p);if(slot==0){playerHealth_=0;playerAlive_=false;}else if(slot>0){std::size_t ci=(std::size_t)(slot-1);if(ci>=coopPlayers_.size())return false;auto&cp=coopPlayers_[ci];cp.health=0;cp.alive=false;}else if(auto*e=entityFromHandle(p)){e->health=0;e->alive=false;}return true;}

  if(name=="getplayerproperty"||name=="get_player_property") {if(a.size()<2)return {};int slot=std::clamp((int)scriptNumber(a[0]),0,3);auto k=lowerString(scriptString(a[1]));if(k=="entity")return playerAliveFor(slot)?ScriptValue(std::uintptr_t((std::uintptr_t)(slot+1))):ScriptValue(std::uintptr_t(0));if(k=="health")return slot==0?(double)playerHealth_:((std::size_t)(slot-1)<coopPlayers_.size()?(double)coopPlayers_[(std::size_t)(slot-1)].health:0.0);if(k=="maxhealth")return slot==0?(double)playerMaxHealth_:((std::size_t)(slot-1)<coopPlayers_.size()?(double)coopPlayers_[(std::size_t)(slot-1)].maxHealth:0.0);if(k=="name"){auto*m=modelForPlayer(slot);return m?ScriptValue(std::string(m->name)):ScriptValue(std::string{});}if(k=="keys")return(double)playerKeys_[slot];if(k=="newkeys")return(double)playerNewKeys_[slot];if(k=="releasekeys"||k=="releasedkeys")return(double)playerReleasedKeys_[slot];if(k=="playkeys")return(double)playerPlayKeys_[slot];if(k=="disablekeys")return(double)playerDisabledKeys_[slot];return 0.0;}
  if(name=="changeplayerproperty"||name=="change_player_property") {if(a.size()<3)return false;int slot=std::clamp((int)scriptNumber(a[0]),0,3);auto k=lowerString(scriptString(a[1]));if(k=="health"){if(slot==0)playerHealth_=std::clamp((int)scriptNumber(a[2]),0,playerMaxHealth_);else if((std::size_t)(slot-1)<coopPlayers_.size()){auto&cp=coopPlayers_[(std::size_t)(slot-1)];cp.health=std::clamp((int)scriptNumber(a[2]),0,cp.maxHealth);}}else if(k=="playkeys")playerPlayKeys_[slot]=(unsigned)scriptNumber(a[2]);else if(k=="disablekeys")playerDisabledKeys_[slot]=(unsigned)scriptNumber(a[2]);return true;}
  if(name=="playerkeys"||name=="key") {if(a.size()<3)return false;int slot=std::clamp((int)scriptNumber(a[0]),0,3);int state=(int)scriptNumber(a[1]);unsigned mask=state==1?playerNewKeys_[slot]:(state==2?playerReleasedKeys_[slot]:playerKeys_[slot]);for(std::size_t i=2;i<a.size();++i){unsigned bit=scriptKeyBit(scriptString(a[i]));if(bit==0)return false;if(lowerString(scriptString(a[i]))=="anybutton"){if((mask&bit)==0)return false;}else if((mask&bit)!=bit)return false;}return true;}

  if(name=="clearspawnentry"||name=="clear_spawn_entry"){scriptSpawnEntry_=ScriptSpawnEntry{};return true;}
  if(name=="setspawnentry"||name=="set_spawn_entry"){
    if(a.size()<2)return false;auto k=lowerString(scriptString(a[0]));if(k=="name"||k=="model")scriptSpawnEntry_.model=scriptString(a[1]);else if(k=="alias")scriptSpawnEntry_.alias=scriptString(a[1]);else if(k=="item")scriptSpawnEntry_.item=scriptString(a[1]);else if(k=="map"||k=="colourmap"||k=="colormap")scriptSpawnEntry_.map=scriptString(a[1]);else if(k=="health")scriptSpawnEntry_.health=(int)scriptNumber(a[1]);else if(k=="boss")scriptSpawnEntry_.boss=scriptNumber(a[1])!=0;else if(k=="x")scriptSpawnEntry_.x=(float)scriptNumber(a[1]);else if(k=="z")scriptSpawnEntry_.z=(float)scriptNumber(a[1]);else if(k=="a"||k=="altitude")scriptSpawnEntry_.a=(float)scriptNumber(a[1]);else if(k=="coords"){scriptSpawnEntry_.x=(float)scriptNumber(a[1]);if(a.size()>2)scriptSpawnEntry_.z=(float)scriptNumber(a[2]);if(a.size()>3)scriptSpawnEntry_.a=(float)scriptNumber(a[3]);}return true;
  }
  if(name=="spawn"||name=="spawnentity"||name=="spawn_entity"){
    if(scriptSpawnEntry_.model.empty())return std::uintptr_t(0);auto*m=findCharacter(scriptSpawnEntry_.model.c_str());if(!m)return std::uintptr_t(0);RuntimeEntity e;e.model=m;e.weaponDropsRemaining=std::max(0,m->weaponDropCounter);e.worldX=scriptSpawnEntry_.x==0.0f?cameraX_+(float)config_.logicalWidth*0.5f:scriptSpawnEntry_.x;e.z=scriptSpawnEntry_.z;e.altitude=-std::max(0.0f,scriptSpawnEntry_.a);e.paletteMap=paletteIndexFromText(scriptSpawnEntry_.map.c_str());e.maxHealth=e.health=std::max(1,scriptSpawnEntry_.health>0?scriptSpawnEntry_.health:m->health);e.guardPoints=std::max(0,m->guardPoints);e.juggleRemaining=std::max(1,m->jugglePoints);auto idle=findAnimation(m,"idle");if(!idle)idle=findAnimation(m,"walk");e.animation.setAnimation(idle);entities_.push_back(std::move(e));auto&spawned=entities_.back();spawned.scriptCtx.entity=&spawned;spawned.scriptCtx.local["self"]=std::uintptr_t((std::uintptr_t)&spawned);runModelScript(m->onSpawnScript,spawned.scriptCtx,"script-spawn-onspawn");return std::uintptr_t((std::uintptr_t)&spawned);
  }

  if(name=="rgbcolor"||name=="rgbcolour"){if(a.size()<3)return 0.0;unsigned r=(unsigned)std::clamp((int)scriptNumber(a[0]),0,255),g=(unsigned)std::clamp((int)scriptNumber(a[1]),0,255),b=(unsigned)std::clamp((int)scriptNumber(a[2]),0,255);return(double)((r<<16)|(g<<8)|b);}
  if(name=="loadsprite"){if(a.empty())return std::uintptr_t(0);SpriteImage img;auto path=resolveSpriteAsset(root_/"assets"/"openbor-data",scriptString(a[0]).c_str());if(!renderer_.loadSprite(path,img)||img.width<=0)return std::uintptr_t(0);auto h=nextScriptSpriteHandle_++;scriptSprites_[h]=std::move(img);return std::uintptr_t(h);}
  if(name=="freesprite"||name=="free"){if(a.empty())return false;auto h=scriptPointer(a[0]);return scriptSprites_.erase(h)>0;}
  if(name=="getgfxproperty"||name=="get_gfx_property"){if(a.size()<2)return {};auto h=scriptPointer(a[0]);auto it=scriptSprites_.find(h);if(it==scriptSprites_.end())return {};auto k=lowerString(scriptString(a[1]));if(k=="width")return(double)it->second.width;if(k=="height")return(double)it->second.height;return {};}
  if(name=="drawdot"&&a.size()>=4){ScriptDrawCommand c;c.kind=ScriptDrawCommand::Kind::Dot;c.x=(int)scriptNumber(a[0]);c.y=(int)scriptNumber(a[1]);c.z=(int)scriptNumber(a[2]);c.color=(unsigned int)scriptNumber(a[3]);scriptDrawQueue_.push_back(std::move(c));return true;}
  if(name=="drawline"&&a.size()>=6){ScriptDrawCommand c;c.kind=ScriptDrawCommand::Kind::Line;c.x=(int)scriptNumber(a[0]);c.y=(int)scriptNumber(a[1]);c.x2=(int)scriptNumber(a[2]);c.y2=(int)scriptNumber(a[3]);c.z=(int)scriptNumber(a[4]);c.color=(unsigned int)scriptNumber(a[5]);scriptDrawQueue_.push_back(std::move(c));return true;}
  if(name=="drawbox"&&a.size()>=6){ScriptDrawCommand c;c.kind=ScriptDrawCommand::Kind::Box;c.x=(int)scriptNumber(a[0]);c.y=(int)scriptNumber(a[1]);c.w=(int)scriptNumber(a[2]);c.h=(int)scriptNumber(a[3]);c.z=(int)scriptNumber(a[4]);c.color=(unsigned int)scriptNumber(a[5]);scriptDrawQueue_.push_back(std::move(c));return true;}
  if(name=="drawstring"&&a.size()>=4){ScriptDrawCommand c;c.kind=ScriptDrawCommand::Kind::Text;c.x=(int)scriptNumber(a[0]);c.y=(int)scriptNumber(a[1]);c.font=(int)scriptNumber(a[2]);c.text=scriptString(a[3]);c.z=a.size()>4?(int)scriptNumber(a[4]):0;scriptDrawQueue_.push_back(std::move(c));return true;}
  if(name=="drawsprite"&&a.size()>=3){ScriptDrawCommand c;c.kind=ScriptDrawCommand::Kind::Sprite;c.sprite=scriptPointer(a[0]);c.x=(int)scriptNumber(a[1]);c.y=(int)scriptNumber(a[2]);c.z=a.size()>3?(int)scriptNumber(a[3]):0;scriptDrawQueue_.push_back(std::move(c));return true;}

  if(name=="playmusic"){if(a.empty())return false;auto path=resolveAudioAsset(root_/"assets"/"openbor-data",scriptString(a[0]));bool loop=a.size()>1?scriptNumber(a[1])!=0:true;return std::filesystem::exists(path)&&audio_.playMusic(path,loop);}
  if(name=="pausemusic"){audio_.pauseMusic(!a.empty()&&scriptNumber(a[0])!=0);return true;}
  if(name=="loadsample"){if(a.empty())return -1.0;auto path=resolveAudioAsset(root_/"assets"/"openbor-data",scriptString(a[0]));if(!std::filesystem::exists(path))return -1.0;for(std::size_t i=0;i<scriptSamples_.size();++i)if(scriptSamples_[i]==path)return (double)i;scriptSamples_.push_back(path);return (double)(scriptSamples_.size()-1);}
  if(name=="unloadsample"){if(a.empty())return false;auto id=(long long)scriptNumber(a[0]);if(id<0||(std::size_t)id>=scriptSamples_.size())return false;scriptSamples_[(std::size_t)id].clear();return true;}
  if(name=="playsample"){if(a.empty())return -1.0;auto id=(long long)scriptNumber(a[0]);if(id<0||(std::size_t)id>=scriptSamples_.size()||scriptSamples_[(std::size_t)id].empty())return -1.0;float lv=a.size()>2?(float)scriptNumber(a[2]):100.0f,rv=a.size()>3?(float)scriptNumber(a[3]):lv;float gain=std::clamp((lv+rv)/200.0f,0.0f,8.0f);float speed=a.size()>4?(float)scriptNumber(a[4])/100.0f:1.0f;bool loop=a.size()>5&&scriptNumber(a[5])!=0;return audio_.playEffect(scriptSamples_[(std::size_t)id],gain,loop,speed)?1.0:-1.0;}
  if(name=="log"||name=="printf"||name=="debug") {if(!a.empty())std::cout<<"[OpenBOR script] "<<scriptString(a[0])<<"\n";return true;}
  if(std::find(unsupported.begin(),unsupported.end(),raw)==unsupported.end())unsupported.push_back(raw);return {};
}
bool Engine::loadStage(std::size_t index,bool keepHealth){
  if(generated::kStageCount==0||index>=generated::kStageCount)return false;
  stageIndex_=index;stage_=&generated::kStages[index];entities_.clear();projectiles_.clear();panels_.clear();backgroundLayers_.clear();foregroundLayers_.clear();background_=SpriteImage{};backgroundRatioX_=0.5f;backgroundOffsetX_=backgroundOffsetY_=0;nextSpawn_=0;cameraX_=0;cameraMaxX_=0;combatLocked_=false;stageComplete_=false;scrollBlocked_=false;groupMin_=groupMax_=0;groupRefillActive_=false;backtrackFloor_=0.0f;cameraFixed_=stage_&&stage_->cameraType!=0;scrollDir_=1;allowBacktrack_=false;if(stage_&&stage_->direction){std::string d=lowerString(stage_->direction);if(d=="left"||d=="in"||d=="bothleft")scrollDir_=-1;if(d=="both")allowBacktrack_=true;}spawnState_.assign(stage_->spawnCount,0);eventState_.assign(stage_->eventCount,0);
  auto data=root_/"assets"/"openbor-data";if(stage_->background&&*stage_->background)renderer_.loadSprite(data/normalizeDataPath(stage_->background),background_);
  for(std::size_t i=0;i<stage_->panelCount;++i){SpriteImage img;renderer_.loadSprite(data/normalizeDataPath(stage_->panels[i]),img);panels_.push_back(std::move(img));}
  for(std::size_t i=0;i<stage_->layerCount;++i){const auto&gl=stage_->layers[i];std::string kind=lowerString(gl.kind?gl.kind:"");if(kind=="background"){backgroundRatioX_=gl.xRatio;backgroundOffsetX_=gl.xOffset;backgroundOffsetY_=gl.zOffset;continue;}if(kind!="bglayer"&&kind!="fglayer"&&kind!="frontpanel")continue;RuntimeStageLayer rl;rl.kind=kind;rl.xRatio=gl.xRatio;rl.zRatio=gl.zRatio;rl.xOffset=gl.xOffset;rl.zOffset=gl.zOffset;rl.xSpacing=gl.xSpacing;rl.zSpacing=gl.zSpacing;rl.xRepeat=gl.xRepeat;rl.zRepeat=gl.zRepeat;rl.zOrder=gl.zOrder;if(!renderer_.loadSprite(data/normalizeDataPath(gl.path?gl.path:""),rl.image)||rl.image.width<=0)continue;if(kind=="bglayer"||(kind=="fglayer"&&rl.zOrder<0))backgroundLayers_.push_back(std::move(rl));else foregroundLayers_.push_back(std::move(rl));}
  auto layerSort=[](const RuntimeStageLayer&a,const RuntimeStageLayer&b){return a.zOrder<b.zOrder;};std::stable_sort(backgroundLayers_.begin(),backgroundLayers_.end(),layerSort);std::stable_sort(foregroundLayers_.begin(),foregroundLayers_.end(),layerSort);
  float panelWidth=0;for(const auto&p:panels_)panelWidth+=(float)p.width;stageLength_=std::max(320.0f,panelWidth);stageLength_=std::max(stageLength_,(float)background_.width);for(const auto&l:backgroundLayers_)stageLength_=std::max(stageLength_,(float)l.image.width+std::max(0,l.xOffset));float farthest=stageLength_;for(std::size_t i=0;i<stage_->spawnCount;++i)farthest=std::max(farthest,(float)stage_->spawns[i].at+(float)std::max(0,stage_->spawns[i].x)+64.0f);stageLength_=std::max(stageLength_,farthest);
  playerWorldX_=(float)stage_->playerStartX;playerZ_=(float)stage_->playerStartZ;playerAltitude_=-(float)std::max(0,stage_->playerStartA);
  if(!keepHealth&&playerModel_){playerHealth_=playerMaxHealth_=std::max(1,playerModel_->health);playerGuardPoints_=std::max(0,playerModel_->guardPoints);}else playerHealth_=std::clamp(playerHealth_,1,std::max(1,playerMaxHealth_));
  stageScriptCtx_.local.clear();stageScriptCtx_.entity=nullptr;stageScriptCtx_.other=nullptr;stageScriptCtx_.player=false;stageScriptCtx_.playerIndex=0;if(stage_->levelScript&&*stage_->levelScript)runModelScript(stage_->levelScript,stageScriptCtx_,"levelscript");
  audio_.stopMusic();if(stage_->music&&*stage_->music){auto music=resolveAudioAsset(data,stage_->music);if(!audio_.playMusic(music,stage_->musicLoop))std::cerr<<"Stage music diagnostic: "<<audio_.lastError()<<"\n";}else if(config_.autoPreviewMusic)previewMusic();
  std::cout<<"Stage "<<(index+1)<<"/"<<generated::kStageCount<<": "<<stage_->sourceFile<<" geometry="<<stage_->geometryCount<<" length="<<stageLength_<<"\n";return true;
}
void Engine::saveProgress(){
  std::filesystem::create_directories(root_/"saves");std::ofstream f(root_/"saves"/"slot1.sav",std::ios::trunc);if(!f)return;
  f<<"stage="<<stageIndex_<<"\nactive_players="<<(1+(int)coopPlayers_.size())<<"\nplayer1="<<(playerModel_?playerModel_->name:"")<<"\nhealth1="<<playerHealth_<<"\n";
  for(std::size_t i=0;i<coopPlayers_.size()&&i<3;++i)f<<"player"<<(i+2)<<"="<<(coopPlayers_[i].model?coopPlayers_[i].model->name:"")<<"\nhealth"<<(i+2)<<"="<<coopPlayers_[i].health<<"\n";
}
bool Engine::loadProgress(){
  std::ifstream f(root_/"saves"/"slot1.sav");if(!f)return false;std::string line;std::size_t st=0;int active=1;std::string names[4];int hp[4]{0,0,0,0};
  while(std::getline(f,line)){auto p=line.find('=');if(p==std::string::npos)continue;auto k=line.substr(0,p),v=line.substr(p+1);try{if(k=="stage")st=(std::size_t)std::stoul(v);else if(k=="active_players")active=std::clamp(std::stoi(v),1,4);else for(int i=0;i<4;++i){if(k=="player"+std::to_string(i+1))names[i]=v;else if(k=="health"+std::to_string(i+1))hp[i]=std::stoi(v);}}catch(...){}}
  std::vector<const generated::Character*> selectable;for(std::size_t i=0;i<generated::kCharacterCount;++i)if(lowerString(generated::kCharacters[i].type)=="player")selectable.push_back(&generated::kCharacters[i]);if(selectable.empty()&&generated::kCharacterCount)selectable.push_back(&generated::kCharacters[0]);if(selectable.empty()||generated::kStageCount==0)return false;
  for(int slot=0;slot<4;++slot){joinedPlayers_[slot]=slot<active;selectIndexes_[slot]=0;if(!names[slot].empty())for(std::size_t j=0;j<selectable.size();++j)if(lowerString(selectable[j]->name)==lowerString(names[slot])){selectIndexes_[slot]=(int)j;break;}}
  config_.activePlayers=active;playerModel_=selectable[(std::size_t)selectIndexes_[0]];stageIndex_=std::min(st,generated::kStageCount-1);beginGame();if(hp[0]>0)playerHealth_=std::clamp(hp[0],1,playerMaxHealth_);for(std::size_t i=0;i<coopPlayers_.size()&&i<3;++i)if(hp[i+1]>0)coopPlayers_[i].health=std::clamp(hp[i+1],1,coopPlayers_[i].maxHealth);return true;
}
void Engine::advanceStage(){
  dropPlayerWeapon(true);for(auto&cp:coopPlayers_)dropCoopWeapon(cp,true);for(auto&e:entities_)dropEntityWeapon(e,true);flushWeaponDrops();
  saveProgress();std::size_t target=stageIndex_+1;if(pendingBranchTarget_!=(std::size_t)-1){target=pendingBranchTarget_;pendingBranchTarget_=(std::size_t)-1;pendingBranchImmediate_=false;}else if(stage_&&stage_->nextStage&&*stage_->nextStage){auto want=normalizeDataPath(stage_->nextStage).generic_string();for(std::size_t i=0;i<generated::kStageCount;++i){auto src=normalizeDataPath(generated::kStages[i].sourceFile).generic_string();if(src==want||src.ends_with(want)){target=i;break;}}}
  if(target<generated::kStageCount){int hp1=playerHealth_;std::vector<int> coopHp;for(const auto&cp:coopPlayers_)coopHp.push_back(cp.health);frontendState_=FrontendState::Loading;renderer_.beginFrame();SpriteImage loading;auto lp=resolveSpriteAsset(root_/"assets"/"openbor-data","bgs/loading");if(renderer_.loadSprite(lp,loading)&&loading.width>0)renderer_.drawImage(loading,0,0);else renderer_.drawText("LOADING...",92,105,18,true);renderer_.endFrame();std::this_thread::sleep_for(std::chrono::milliseconds(250));loadStage(target,true);playerHealth_=std::clamp(hp1,1,std::max(1,playerMaxHealth_));for(std::size_t i=0;i<coopPlayers_.size();++i){coopPlayers_[i].worldX=(float)stage_->playerStartX+18.0f*(float)(i+1);coopPlayers_[i].z=(float)stage_->playerStartZ+7.0f*(float)(i+1);coopPlayers_[i].altitude=0;coopPlayers_[i].alive=true;if(i<coopHp.size())coopPlayers_[i].health=std::clamp(coopHp[i],1,coopPlayers_[i].maxHealth);coopPlayers_[i].animation.setAnimation(findAnimation(coopPlayers_[i].model,"idle"));coopPlayers_[i].lastFrame=(std::size_t)-1;}nextSpawn_=0;frontendState_=FrontendState::Playing;}
  else{std::error_code ec;std::filesystem::remove(root_/"saves"/"slot1.sav",ec);frontendState_=FrontendState::MainMenu;audio_.stopMusic();}
}
void Engine::applyStageGeometry(float oldX,float oldZ){
  if(!stage_)return;for(std::size_t i=0;i<stage_->geometryCount;++i){const auto&g=stage_->geometry[i];std::string k=lowerString(g.kind?g.kind:"");bool inside=playerWorldX_>=g.x&&playerWorldX_<=g.x+g.w&&playerZ_>=g.z&&playerZ_<=g.z+g.h;if(k=="wall"&&inside){float dx=playerWorldX_-oldX,dz=playerZ_-oldZ;playerWorldX_=oldX;playerZ_=oldZ;if(playerModel_){playerScriptCtx_.local["plane"]=(double)(std::fabs(dx)>=std::fabs(dz)?0:1);playerScriptCtx_.local["index"]=(double)i;playerScriptCtx_.local["height"]=(double)g.w;playerScriptCtx_.local["depth"]=(double)g.h;playerScriptCtx_.local["type"]=std::string("wall");runModelScript(playerModel_->onBlockWScript,playerScriptCtx_,"player-onblockw");runModelScript(playerModel_->onBlockOScript,playerScriptCtx_,"player-onblocko");}}else if(k=="hole"&&inside&&playerAltitude_>=-0.1f){playerHealth_=std::max(1,playerHealth_-10);playerWorldX_=(float)stage_->playerStartX;playerZ_=(float)stage_->playerStartZ;std::cout<<"Hole reset, hp="<<playerHealth_<<"\n";}else if(k=="platform"&&inside&&playerAltitude_>0)playerAltitude_=0;}
  for(std::size_t pi=0;pi<coopPlayers_.size();++pi){auto&cp=coopPlayers_[pi];for(std::size_t i=0;i<stage_->geometryCount;++i){const auto&g=stage_->geometry[i];std::string k=lowerString(g.kind?g.kind:"");bool inside=cp.worldX>=g.x&&cp.worldX<=g.x+g.w&&cp.z>=g.z&&cp.z<=g.z+g.h;if(k=="hole"&&inside&&cp.altitude>=-0.1f){cp.health=std::max(1,cp.health-10);cp.worldX=(float)stage_->playerStartX+18.0f*(float)(pi+1);cp.z=(float)stage_->playerStartZ+7.0f*(float)(pi+1);}}}
}
bool Engine::initialize(const std::filesystem::path& portRoot){
  root_=portRoot; config_=loadRuntimeConfig(root_/"config"/"graphics.ini"); {std::ifstream vf(root_/"config"/"openbor-video.ini");std::string line;while(std::getline(vf,line)){auto eq=line.find('=');if(eq==std::string::npos)continue;auto k=line.substr(0,eq),v=line.substr(eq+1);try{if(k=="logical_width")config_.logicalWidth=std::max(160,std::stoi(v));else if(k=="logical_height")config_.logicalHeight=std::max(120,std::stoi(v));}catch(...){}}} scriptVm_.setRoot(root_/"assets"/"openbor-data"); scriptVm_.setHost(this); playerScriptCtx_.player=true; playerScriptCtx_.playerIndex=0; playerScriptCtx_.local["self"]=std::uintptr_t(1);
  if(!renderer_.initialize(config_)) return false;
  if(!audio_.initialize(config_)) std::cerr<<"Audio warning: "<<audio_.lastError()<<"\n";
  std::cout << "Renderer: " << renderer_.backend() << "\nCharacters: " << generated::kCharacterCount << " Stages: " << generated::kStageCount << "\n";
  std::cout << "Graphics: preset="<<config_.graphicsPreset<<" upscale="<<config_.upscaleMode<<" filter="<<config_.textureFilter<<" vsync="<<(config_.vsync?"on":"off")<<" fps="<<(config_.fpsLimit==0?std::string("unlimited"):std::to_string(config_.fpsLimit))<<"\n";
  std::cout << "Audio volumes master="<<audio_.masterVolume()<<" music="<<audio_.musicVolume()<<" effects="<<audio_.effectsVolume()<<"\n";

  if(generated::kStageCount>0) stage_=&generated::kStages[0];

  renderer_.loadSprite(resolveSpriteAsset(root_/"assets"/"openbor-data","bgs/title"),titleBackground_);
  for(std::size_t i=0;i<generated::kCharacterCount;++i){ if(lowerString(generated::kCharacters[i].type)=="player"){ playerModel_=&generated::kCharacters[i]; break; } }
  if(!playerModel_ && generated::kCharacterCount) playerModel_=&generated::kCharacters[0];
  if(playerModel_){
    playerMaxHealth_=playerHealth_=std::max(1,playerModel_->health);
    player_.setAnimation(findAnimation(playerModel_,"idle")); if(!player_.frame()) player_.setAnimation(findAnimation(playerModel_,"walk"));
    std::cout<<"Combat ready: player="<<playerModel_->name<<" hp="<<playerHealth_<<" enemyAI="<<(config_.enemyAI?"on":"off")<<" cameraLock="<<(config_.cameraLockOnCombat?"on":"off")<<"\n";
  }
#ifdef _WIN32
  frontendState_=FrontendState::MainMenu;
  audio_.stopMusic();
#else
  frontendState_=FrontendState::Playing;for(int i=0;i<4;++i)joinedPlayers_[i]=(i<config_.activePlayers);beginGame();
#endif
  return true;
}
bool Engine::frontendKeyPressed(int vk){
#ifdef _WIN32
  static SHORT prev[256]{}; if(vk<0||vk>255) return false; SHORT now=GetAsyncKeyState(vk); bool down=(now&0x8000)!=0, was=(prev[vk]&0x8000)!=0; prev[vk]=now; return down&&!was;
#else
  (void)vk; return false;
#endif
}
bool Engine::gamepadButtonPressedFor(int pad,unsigned short button){
#ifdef _WIN32
  if(!config_.gamepad)return false;static WORD prev[4]{},cur[4]{};static ULONGLONG stamp[4]{};DWORD id=(DWORD)std::clamp(pad,0,3);ULONGLONG nowTick=GetTickCount64();if(nowTick!=stamp[id]){prev[id]=cur[id];XINPUT_STATE state{};cur[id]=(XInputGetState(id,&state)==ERROR_SUCCESS)?state.Gamepad.wButtons:0;stamp[id]=nowTick;}return (cur[id]&button)&&!(prev[id]&button);
#else
  (void)pad;(void)button;return false;
#endif
}
bool Engine::gamepadButtonPressed(unsigned short button){ return gamepadButtonPressedFor(config_.player1Gamepad,button); }
int Engine::captureAnyKey(){
#ifdef _WIN32
  static unsigned char prev[256]{};for(int vk=8;vk<255;++vk){bool down=(GetAsyncKeyState(vk)&0x8000)!=0;bool fire=down&&!prev[vk];prev[vk]=(unsigned char)(down?1:0);if(fire)return vk;}return 0;
#else
  return 0;
#endif
}
unsigned short Engine::captureAnyGamepadButton(int pad){
#ifdef _WIN32
  static WORD prev[4]{};XINPUT_STATE xs{};DWORD id=(DWORD)std::clamp(pad,0,3);WORD cur=(XInputGetState(id,&xs)==ERROR_SUCCESS)?xs.Gamepad.wButtons:0;WORD pressed=(WORD)(cur&~prev[id]);prev[id]=cur;static const WORD buttons[]={XINPUT_GAMEPAD_A,XINPUT_GAMEPAD_B,XINPUT_GAMEPAD_X,XINPUT_GAMEPAD_Y,XINPUT_GAMEPAD_LEFT_SHOULDER,XINPUT_GAMEPAD_RIGHT_SHOULDER,XINPUT_GAMEPAD_BACK,XINPUT_GAMEPAD_START,XINPUT_GAMEPAD_LEFT_THUMB,XINPUT_GAMEPAD_RIGHT_THUMB};for(WORD b:buttons)if(pressed&b)return b;return 0;
#else
  (void)pad;return 0;
#endif
}
void Engine::saveSettings(){
  config_.masterVolume=audio_.masterVolume(); config_.musicVolume=audio_.musicVolume(); config_.effectsVolume=audio_.effectsVolume();
  renderer_.setConfig(config_);
  if(!saveRuntimeConfig(root_/"config"/"graphics.ini",config_)) std::cerr<<"Could not save graphics.ini\n";
}
void Engine::beginGame(){
  if(!playerModel_) return;
  if(!loadStage(stageIndex_,false)) return;
  entities_.clear(); projectiles_.clear(); equippedWeapon_=nullptr; grabbedEntity_=-1; grabHoldTicks_=0;
  nextSpawn_=0; cameraX_=0.0f; combatLocked_=false; combatLockX_=0.0f; tickCounter_=0;
  playerWorldX_=stage_?(float)stage_->playerStartX:80.0f; playerZ_=stage_?(float)stage_->playerStartZ:200.0f;
  playerAltitude_=stage_?-(float)std::max(0,stage_->playerStartA):0.0f; playerVerticalVelocity_=0; playerJumpVelocityX_=playerJumpVelocityZ_=0;
  playerAlive_=true; playerMaxHealth_=playerHealth_=std::max(1,playerModel_->health); playerGuardPoints_=std::max(0,playerModel_->guardPoints); playerBlockState_=0; playerBlocking_=false; playerHitStun_=playerAttackTicks_=playerAttackCooldown_=0;
  playerComboStep_=playerComboWindow_=playerFallTicks_=playerRecoveryTicks_=playerDashTicks_=0; playerComboBranch_=-1; playerQueuedAttack_=playerProjectileFired_=playerJumping_=playerAnimJumpTriggered_=false;
  playerAttackId_=0; lastFrame_=(std::size_t)-1; player_.setAnimation(findAnimation(playerModel_,"idle")); if(!player_.frame()) player_.setAnimation(findAnimation(playerModel_,"walk"));
  coopPlayers_.clear();
  std::vector<const generated::Character*> selectable;for(std::size_t i=0;i<generated::kCharacterCount;++i)if(lowerString(generated::kCharacters[i].type)=="player")selectable.push_back(&generated::kCharacters[i]);if(selectable.empty()&&generated::kCharacterCount)selectable.push_back(&generated::kCharacters[0]);
  int pads[4]={config_.player1Gamepad,config_.player2Gamepad,config_.player3Gamepad,config_.player4Gamepad};
  for(int slot=1;slot<std::min(4,config_.maxPlayers);++slot){if(!joinedPlayers_[slot]||selectable.empty())continue;RuntimeCoopPlayer cp;cp.model=selectable[(std::size_t)(selectIndexes_[slot]%(int)selectable.size())];cp.maxHealth=cp.health=std::max(1,cp.model->health);cp.guardPoints=std::max(0,cp.model->guardPoints);cp.worldX=playerWorldX_+18.0f*(float)slot;cp.z=playerZ_+7.0f*(float)slot;cp.gamepadId=pads[slot];cp.paletteMap=slot;cp.animation.setAnimation(findAnimation(cp.model,"idle"));if(!cp.animation.frame())cp.animation.setAnimation(findAnimation(cp.model,"walk"));cp.scriptCtx.player=true;cp.scriptCtx.playerIndex=slot;cp.scriptCtx.local["self"]=std::uintptr_t(slot+1);cp.scriptCtx.local["player"]=(double)slot;coopPlayers_.push_back(std::move(cp));}
  audio_.stopMusic();
  if(stage_ && stage_->music && *stage_->music){ auto music=root_/"assets"/"openbor-data"/normalizeDataPath(stage_->music); if(!audio_.playMusic(music,stage_->musicLoop)) std::cerr<<"Stage music diagnostic: "<<audio_.lastError()<<"\n"; }
  else if(config_.autoPreviewMusic) previewMusic();
  frontendState_=FrontendState::Playing;
  playerScriptCtx_.player=true;playerScriptCtx_.playerIndex=0;playerScriptCtx_.local["self"]=std::uintptr_t(1);playerScriptCtx_.local["player"]=0.0;runModelScript(playerModel_->onSpawnScript,playerScriptCtx_,"player-onspawn");
  for(auto&cp:coopPlayers_)runModelScript(cp.model?cp.model->onSpawnScript:"",cp.scriptCtx,"coop-onspawn");
  std::cout<<"New game started local_players="<<(1+coopPlayers_.size())<<"\n";
}
void Engine::updateFrontend(){
#ifdef _WIN32
  auto up=frontendKeyPressed(VK_UP)||frontendKeyPressed('W');
  auto down=frontendKeyPressed(VK_DOWN)||frontendKeyPressed('S');
  auto left=frontendKeyPressed(VK_LEFT)||frontendKeyPressed('A');
  auto right=frontendKeyPressed(VK_RIGHT)||frontendKeyPressed('D');
  auto accept=frontendKeyPressed(VK_RETURN)||frontendKeyPressed('J')||frontendKeyPressed('X')||gamepadButtonPressed((unsigned short)config_.padAttack);
  auto back=frontendKeyPressed(VK_ESCAPE)||frontendKeyPressed(VK_BACK)||gamepadButtonPressed((unsigned short)config_.padJump);
  up=up||gamepadButtonPressed(XINPUT_GAMEPAD_DPAD_UP);down=down||gamepadButtonPressed(XINPUT_GAMEPAD_DPAD_DOWN);left=left||gamepadButtonPressed(XINPUT_GAMEPAD_DPAD_LEFT);right=right||gamepadButtonPressed(XINPUT_GAMEPAD_DPAD_RIGHT);
  if(frontendState_==FrontendState::MainMenu){
    constexpr int count=5;if(up)menuIndex_=(menuIndex_+count-1)%count;if(down)menuIndex_=(menuIndex_+1)%count;
    if(accept){if(menuIndex_==0){selectIndex_=0;for(int i=0;i<4;++i){selectIndexes_[i]=0;joinedPlayers_[i]=(i==0);}frontendState_=FrontendState::CharacterSelect;}else if(menuIndex_==1){if(loadProgress())frontendState_=FrontendState::Playing;}else if(menuIndex_==2){optionsFromPause_=false;optionIndex_=0;frontendState_=FrontendState::Options;}else if(menuIndex_==3)frontendState_=FrontendState::Controls;else frontendState_=FrontendState::Quit;}
  }else if(frontendState_==FrontendState::CharacterSelect){
    std::vector<const generated::Character*> players;for(std::size_t i=0;i<generated::kCharacterCount;++i)if(lowerString(generated::kCharacters[i].type)=="player")players.push_back(&generated::kCharacters[i]);if(players.empty()&&generated::kCharacterCount)players.push_back(&generated::kCharacters[0]);
    if(!players.empty()){
      if(left)selectIndexes_[0]=(selectIndexes_[0]+(int)players.size()-1)%(int)players.size();if(right)selectIndexes_[0]=(selectIndexes_[0]+1)%(int)players.size();
      int pads[4]={config_.player1Gamepad,config_.player2Gamepad,config_.player3Gamepad,config_.player4Gamepad};
      for(int slot=0;slot<std::min(4,config_.maxPlayers);++slot){int pad=pads[slot];if(gamepadButtonPressedFor(pad,XINPUT_GAMEPAD_A)||gamepadButtonPressedFor(pad,XINPUT_GAMEPAD_START))joinedPlayers_[slot]=true;if(slot>0&&gamepadButtonPressedFor(pad,XINPUT_GAMEPAD_B))joinedPlayers_[slot]=false;if(joinedPlayers_[slot]){if(gamepadButtonPressedFor(pad,XINPUT_GAMEPAD_DPAD_LEFT))selectIndexes_[slot]=(selectIndexes_[slot]+(int)players.size()-1)%(int)players.size();if(gamepadButtonPressedFor(pad,XINPUT_GAMEPAD_DPAD_RIGHT))selectIndexes_[slot]=(selectIndexes_[slot]+1)%(int)players.size();}}
      if(back)frontendState_=FrontendState::MainMenu;else if(frontendKeyPressed(VK_RETURN)||gamepadButtonPressedFor(config_.player1Gamepad,XINPUT_GAMEPAD_START)){playerModel_=players[(std::size_t)selectIndexes_[0]];selectedPlayerIndex_=selectIndexes_[0];config_.activePlayers=0;for(int i=0;i<std::min(4,config_.maxPlayers);++i)if(joinedPlayers_[i])++config_.activePlayers;config_.activePlayers=std::max(1,config_.activePlayers);stageIndex_=0;saveSettings();beginGame();}
    }
  }else if(frontendState_==FrontendState::Paused){
    constexpr int count=5;if(up)pauseIndex_=(pauseIndex_+count-1)%count;if(down)pauseIndex_=(pauseIndex_+1)%count;if(back){frontendState_=FrontendState::Playing;return;}if(accept){if(pauseIndex_==0)frontendState_=FrontendState::Playing;else if(pauseIndex_==1){optionsFromPause_=true;optionIndex_=0;frontendState_=FrontendState::Options;}else if(pauseIndex_==2)beginGame();else if(pauseIndex_==3){audio_.stopMusic();frontendState_=FrontendState::MainMenu;menuIndex_=0;}else frontendState_=FrontendState::Quit;}
  }else if(frontendState_==FrontendState::GameOver){if(accept){if(loadProgress())frontendState_=FrontendState::Playing;else frontendState_=FrontendState::MainMenu;}if(back)frontendState_=FrontendState::MainMenu;
  }else if(frontendState_==FrontendState::Controls){
    constexpr int count=22;
    if(waitingForKey_){if(controlCaptureDelay_>0)--controlCaptureDelay_;else{int k=captureAnyKey();if(k){int* binds[]={&config_.keyLeft,&config_.keyRight,&config_.keyUp,&config_.keyDown,&config_.keyAttack,&config_.keyJump,&config_.keyPickup,&config_.keyDash,&config_.keyGrab,&config_.keyThrow,&config_.keyRun};if(controlsIndex_>=0&&controlsIndex_<11)*binds[controlsIndex_]=k;waitingForKey_=false;saveSettings();}}}
    else if(waitingForPad_){if(controlCaptureDelay_>0)--controlCaptureDelay_;else{auto b=captureAnyGamepadButton(config_.player1Gamepad);if(b){int* binds[]={&config_.padAttack,&config_.padJump,&config_.padPickup,&config_.padDash,&config_.padGrab,&config_.padThrow};if(controlsIndex_>=11&&controlsIndex_<17)*binds[controlsIndex_-11]=(int)b;waitingForPad_=false;saveSettings();}}}
    else{if(up)controlsIndex_=(controlsIndex_+count-1)%count;if(down)controlsIndex_=(controlsIndex_+1)%count;int dir=right?1:(left?-1:0);if(controlsIndex_>=17&&controlsIndex_<=20&&dir!=0){int* pads[]={&config_.player1Gamepad,&config_.player2Gamepad,&config_.player3Gamepad,&config_.player4Gamepad};int idx=controlsIndex_-17;*pads[idx]=(*pads[idx]+(dir<0?3:1))%4;saveSettings();}else if(accept&&controlsIndex_<11){waitingForKey_=true;controlCaptureDelay_=8;}else if(accept&&controlsIndex_>=11&&controlsIndex_<17){waitingForPad_=true;controlCaptureDelay_=8;}else if((accept&&controlsIndex_==21)||back){waitingForKey_=waitingForPad_=false;frontendState_=FrontendState::MainMenu;saveSettings();}}
  }else if(frontendState_==FrontendState::Options){
    constexpr int count=11;if(up)optionIndex_=(optionIndex_+count-1)%count;if(down)optionIndex_=(optionIndex_+1)%count;int dir=right?1:(left?-1:0);
    if((accept||dir!=0)&&optionIndex_==0)config_.fullscreen=!config_.fullscreen;
    else if((accept||dir!=0)&&optionIndex_==1){static const int rw[]={640,960,1280,1920,2560};static const int rh[]={480,720,720,1080,1440};int cur=2;for(int i=0;i<5;++i)if(config_.width==rw[i]&&config_.height==rh[i])cur=i;cur=(cur+(dir<0?4:1))%5;config_.width=rw[cur];config_.height=rh[cur];}
    else if((accept||dir!=0)&&optionIndex_==2){static const int fps[]={60,120,144,0};int cur=0;for(int i=0;i<4;++i)if(config_.fpsLimit==fps[i])cur=i;cur=(cur+(dir<0?3:1))%4;config_.fpsLimit=fps[cur];}
    else if((accept||dir!=0)&&optionIndex_==3)config_.vsync=!config_.vsync;
    else if(accept&&optionIndex_==4){graphicsOptionIndex_=0;frontendState_=FrontendState::GraphicsOptions;}
    else if(dir!=0&&optionIndex_==5)audio_.setMasterVolume(audio_.masterVolume()+0.05f*(float)dir);
    else if(dir!=0&&optionIndex_==6)audio_.setMusicVolume(audio_.musicVolume()+0.05f*(float)dir);
    else if(dir!=0&&optionIndex_==7)audio_.setEffectsVolume(audio_.effectsVolume()+0.05f*(float)dir);
    else if((accept||dir!=0)&&optionIndex_==8)config_.showBBox=!config_.showBBox;
    else if((accept||dir!=0)&&optionIndex_==9)config_.showAttackBox=!config_.showAttackBox;
    else if((accept||back)&&optionIndex_==10){saveSettings();frontendState_=optionsFromPause_?FrontendState::Paused:FrontendState::MainMenu;}
    if(back&&optionIndex_!=10){saveSettings();frontendState_=optionsFromPause_?FrontendState::Paused:FrontendState::MainMenu;}if(accept||dir!=0)saveSettings();
  }else if(frontendState_==FrontendState::GraphicsOptions){
    constexpr int count=15;if(up)graphicsOptionIndex_=(graphicsOptionIndex_+count-1)%count;if(down)graphicsOptionIndex_=(graphicsOptionIndex_+1)%count;int dir=right?1:(left?-1:0);
    if((accept||dir!=0)&&graphicsOptionIndex_==0){static const char* p[]={"original","improved","crt","sharp"};int cur=0;for(int i=0;i<4;++i)if(config_.graphicsPreset==p[i])cur=i;cur=(cur+(dir<0?3:1))%4;applyGraphicsPreset(config_,p[cur]);}
    else if((accept||dir!=0)&&graphicsOptionIndex_==1){static const char* u[]={"original","sharp-bilinear","cas","xbrz-like"};int cur=0;for(int i=0;i<4;++i)if(config_.upscaleMode==u[i])cur=i;cur=(cur+(dir<0?3:1))%4;config_.upscaleMode=u[cur];config_.graphicsPreset="custom";}
    else if((accept||dir!=0)&&graphicsOptionIndex_==2){config_.pixelPerfect=!config_.pixelPerfect;config_.graphicsPreset="custom";}
    else if((accept||dir!=0)&&graphicsOptionIndex_==3){config_.keepAspect43=!config_.keepAspect43;if(config_.keepAspect43)config_.fill169=false;config_.graphicsPreset="custom";}
    else if((accept||dir!=0)&&graphicsOptionIndex_==4){config_.fill169=!config_.fill169;if(config_.fill169){config_.keepAspect43=false;config_.pixelPerfect=false;}config_.graphicsPreset="custom";}
    else if((accept||dir!=0)&&graphicsOptionIndex_==5){static const int sc[]={0,2,3,4};int cur=0;for(int i=0;i<4;++i)if(config_.integerScale==sc[i])cur=i;cur=(cur+(dir<0?3:1))%4;config_.integerScale=sc[cur];config_.graphicsPreset="custom";}
    else if((accept||dir!=0)&&graphicsOptionIndex_==6){config_.textureFilter=config_.textureFilter=="nearest"?"linear":"nearest";config_.graphicsPreset="custom";}
    else if((accept||dir!=0)&&graphicsOptionIndex_==7){config_.crt=!config_.crt;config_.graphicsPreset="custom";}
    else if((accept||dir!=0)&&graphicsOptionIndex_==8){config_.scanlines=!config_.scanlines;config_.graphicsPreset="custom";}
    else if((accept||dir!=0)&&graphicsOptionIndex_==9){config_.crtCurvature=!config_.crtCurvature;config_.graphicsPreset="custom";}
    else if((accept||dir!=0)&&graphicsOptionIndex_==10){config_.bloom=!config_.bloom;config_.graphicsPreset="custom";}
    else if(dir!=0&&graphicsOptionIndex_==11){config_.contrast=std::clamp(config_.contrast+0.05f*dir,0.5f,2.0f);config_.graphicsPreset="custom";}
    else if(dir!=0&&graphicsOptionIndex_==12){config_.saturation=std::clamp(config_.saturation+0.05f*dir,0.0f,2.0f);config_.graphicsPreset="custom";}
    else if((accept||dir!=0)&&graphicsOptionIndex_==13){config_.reduceBanding=!config_.reduceBanding;config_.graphicsPreset="custom";}
    else if(dir!=0&&graphicsOptionIndex_==14){config_.sharpen=std::clamp(config_.sharpen+0.05f*dir,0.0f,1.0f);config_.graphicsPreset="custom";}
    if(back){saveSettings();frontendState_=FrontendState::Options;}else if(accept||dir!=0)saveSettings();
  }
#else
  frontendState_=FrontendState::Playing;
#endif
}
void Engine::drawFrontend(){
  const bool overGameplay=(frontendState_==FrontendState::Paused)||(frontendState_==FrontendState::Options&&optionsFromPause_)||(frontendState_==FrontendState::GraphicsOptions&&optionsFromPause_);
  if(overGameplay){drawStage();renderer_.drawSolidRect(8,22,304,210,18,18,24);}else{renderer_.beginFrame();if(titleBackground_.width>0)renderer_.drawImage(titleBackground_,0,0);}
  renderer_.drawText("OPENBOR NATIVE PORT",10,6,15,true);renderer_.drawText("OpenBOR Native Builder",11,25,8,false);
  if(frontendState_==FrontendState::MainMenu){const char* items[]={"NEW GAME","CONTINUE","OPTIONS","CONTROLS","QUIT"};for(int i=0;i<5;++i)renderer_.drawText(items[i],28,62+i*29,13,i==menuIndex_);renderer_.drawText("ENTER/J select  UP/DOWN navigate",18,216,8,false);
  }else if(frontendState_==FrontendState::CharacterSelect){renderer_.drawText("SELECT CHARACTERS",20,46,14,true);std::vector<const generated::Character*>players;for(std::size_t i=0;i<generated::kCharacterCount;++i)if(lowerString(generated::kCharacters[i].type)=="player")players.push_back(&generated::kCharacters[i]);if(players.empty()&&generated::kCharacterCount)players.push_back(&generated::kCharacters[0]);if(!players.empty()){for(int slot=0;slot<std::min(4,config_.maxPlayers);++slot){std::string line="P"+std::to_string(slot+1)+"  ";if(joinedPlayers_[slot])line+="< "+std::string(players[(std::size_t)std::clamp(selectIndexes_[slot],0,(int)players.size()-1)]->name)+" >";else line+="PRESS A/START TO JOIN";renderer_.drawText(line,22,76+slot*28,10,slot==0);}}renderer_.drawText("P1 arrows choose | pads D-PAD choose",14,194,7,false);renderer_.drawText("ENTER / P1 START begin   B leaves",14,210,7,false);
  }else if(frontendState_==FrontendState::Paused){renderer_.drawText("PAUSED",24,49,15,true);const char* items[]={"CONTINUE","OPTIONS","RESTART STAGE","MAIN MENU","QUIT"};for(int i=0;i<5;++i)renderer_.drawText(items[i],30,78+i*25,11,i==pauseIndex_);
  }else if(frontendState_==FrontendState::GameOver){renderer_.drawText("GAME OVER",78,92,24,true);renderer_.drawText("ENTER CONTINUE   ESC MAIN MENU",35,138,9,false);
  }else if(frontendState_==FrontendState::Controls){renderer_.drawText("CONTROLS / REMAP",18,43,13,true);std::vector<std::string>rows={"LEFT KEY: "+std::to_string(config_.keyLeft),"RIGHT KEY: "+std::to_string(config_.keyRight),"UP KEY: "+std::to_string(config_.keyUp),"DOWN KEY: "+std::to_string(config_.keyDown),"ATTACK KEY: "+std::to_string(config_.keyAttack),"JUMP KEY: "+std::to_string(config_.keyJump),"PICKUP KEY: "+std::to_string(config_.keyPickup),"DASH KEY: "+std::to_string(config_.keyDash),"GRAB KEY: "+std::to_string(config_.keyGrab),"THROW KEY: "+std::to_string(config_.keyThrow),"RUN KEY: "+std::to_string(config_.keyRun),"PAD ATTACK: "+std::to_string(config_.padAttack),"PAD JUMP: "+std::to_string(config_.padJump),"PAD PICKUP: "+std::to_string(config_.padPickup),"PAD DASH: "+std::to_string(config_.padDash),"PAD GRAB: "+std::to_string(config_.padGrab),"PAD THROW: "+std::to_string(config_.padThrow),"P1 GAMEPAD: "+std::to_string(config_.player1Gamepad+1),"P2 GAMEPAD: "+std::to_string(config_.player2Gamepad+1),"P3 GAMEPAD: "+std::to_string(config_.player3Gamepad+1),"P4 GAMEPAD: "+std::to_string(config_.player4Gamepad+1),"BACK"};int first=std::clamp(controlsIndex_-5,0,std::max(0,(int)rows.size()-10));for(int r=0;r<10&&first+r<(int)rows.size();++r){int idx=first+r;renderer_.drawText(rows[(std::size_t)idx],18,62+r*15,8,idx==controlsIndex_);}std::string help=waitingForKey_?"PRESS A NEW KEY...":(waitingForPad_?"PRESS A GAMEPAD BUTTON...":"ENTER remap | LEFT/RIGHT pad slot");renderer_.drawText(help,14,218,7,waitingForKey_||waitingForPad_);
  }else if(frontendState_==FrontendState::Options){renderer_.drawText("OPTIONS",18,44,14,true);std::vector<std::string>rows={std::string("FULLSCREEN: ")+(config_.fullscreen?"ON":"OFF"),"RESOLUTION: "+std::to_string(config_.width)+"x"+std::to_string(config_.height),"FPS: "+(config_.fpsLimit==0?std::string("UNLIMITED"):std::to_string(config_.fpsLimit)),std::string("V-SYNC: ")+(config_.vsync?"ON":"OFF"),"GRAPHICS...","MASTER: "+std::to_string((int)(audio_.masterVolume()*100))+"%","MUSIC: "+std::to_string((int)(audio_.musicVolume()*100))+"%","SFX: "+std::to_string((int)(audio_.effectsVolume()*100))+"%",std::string("SHOW BBOX: ")+(config_.showBBox?"ON":"OFF"),std::string("ATTACK BOX: ")+(config_.showAttackBox?"ON":"OFF"),"BACK"};for(int i=0;i<(int)rows.size();++i)renderer_.drawText(rows[(std::size_t)i],22,59+i*14,8,i==optionIndex_);renderer_.drawText("LEFT/RIGHT change",20,222,7,false);
  }else if(frontendState_==FrontendState::GraphicsOptions){renderer_.drawText("OPTIONS > GRAPHICS",12,42,13,true);auto on=[](bool v){return v?"ON":"OFF";};std::string scale=config_.integerScale==0?"AUTO":std::to_string(config_.integerScale)+"x";std::vector<std::string>rows={"PRESET: "+config_.graphicsPreset,"UPSCALE: "+config_.upscaleMode,std::string("PIXEL PERFECT: ")+on(config_.pixelPerfect),std::string("KEEP 4:3: ")+on(config_.keepAspect43),std::string("FILL 16:9: ")+on(config_.fill169),"INTEGER SCALE: "+scale,"TEXTURE: "+config_.textureFilter,std::string("CRT: ")+on(config_.crt),std::string("SCANLINES: ")+on(config_.scanlines),std::string("CURVATURE: ")+on(config_.crtCurvature),std::string("BLOOM: ")+on(config_.bloom),"CONTRAST: "+std::to_string((int)(config_.contrast*100))+"%","SATURATION: "+std::to_string((int)(config_.saturation*100))+"%",std::string("REDUCE BANDING: ")+on(config_.reduceBanding),"SHARPEN: "+std::to_string((int)(config_.sharpen*100))+"%"};int first=std::clamp(graphicsOptionIndex_-4,0,std::max(0,(int)rows.size()-9));for(int row=0;row<9&&first+row<(int)rows.size();++row){int idx=first+row;renderer_.drawText(rows[(std::size_t)idx],14,65+row*16,8,idx==graphicsOptionIndex_);}renderer_.drawText("ESC back  LEFT/RIGHT change",14,220,7,false);
  }
  renderer_.endFrame();
}
void Engine::previewMusic(){
  auto data=root_/"assets"/"openbor-data"; if(!std::filesystem::exists(data)) return; std::filesystem::path best; int bestScore=-1;
  for(const auto& e:std::filesystem::recursive_directory_iterator(data)){
    if(!e.is_regular_file()) continue; auto ext=lowerExt(e.path()); if(ext!=".bor"&&ext!=".wav"&&ext!=".ogg"&&ext!=".oga"&&ext!=".mp3"&&ext!=".flac") continue;
    auto generic=e.path().generic_string(); std::string low=lowerString(generic); int score=(ext==".bor"?30:ext==".wav"?20:10)+(low.find("music")!=std::string::npos?20:0);
    if(config_.preferredMusicFormat!="auto" && ext=="."+config_.preferredMusicFormat) score+=40; if(score>bestScore){bestScore=score;best=e.path();}
  }
  if(!best.empty()){ if(audio_.playMusic(best,true)) std::cout<<"Preview music: "<<best.generic_string()<<"\n"; else std::cerr<<"Music diagnostic: "<<best.generic_string()<<" -> "<<audio_.lastError()<<"\n"; }
}
void Engine::pollAudioHotkeys(){
#ifdef _WIN32
  static SHORT p2=0,p3=0,p4=0,p5=0,p6=0,p7=0; auto press=[](int vk,SHORT& prev){SHORT now=GetAsyncKeyState(vk);bool down=(now&0x8000)!=0,was=(prev&0x8000)!=0;prev=now;return down&&!was;}; bool changed=false;
  if(press(VK_F2,p2)){audio_.setMusicVolume(audio_.musicVolume()-0.05f);changed=true;} if(press(VK_F3,p3)){audio_.setMusicVolume(audio_.musicVolume()+0.05f);changed=true;}
  if(press(VK_F4,p4)){audio_.setEffectsVolume(audio_.effectsVolume()-0.05f);changed=true;} if(press(VK_F5,p5)){audio_.setEffectsVolume(audio_.effectsVolume()+0.05f);changed=true;}
  if(press(VK_F6,p6)){audio_.setMasterVolume(audio_.masterVolume()-0.05f);changed=true;} if(press(VK_F7,p7)){audio_.setMasterVolume(audio_.masterVolume()+0.05f);changed=true;}
  if(changed) std::cout<<"Audio settings: master="<<audio_.masterVolume()<<" music="<<audio_.musicVolume()<<" effects="<<audio_.effectsVolume()<<"\n";
#endif
}
void Engine::startPlayerAttack(){
  if(!playerAlive_ || !playerModel_ || playerHitStun_>0 || playerFallTicks_>0 || playerRecoveryTicks_>0 || grabbedEntity_>=0) return;
  if(playerAttackTicks_>0){ if(playerComboWindow_>0 && !playerJumping_) playerQueuedAttack_=true; return; }
  if(playerAttackCooldown_>0 && playerComboWindow_<=0 && !playerJumping_) return;
  const generated::Animation* attack=nullptr; int attackNumber=1;
  if(playerJumping_ || playerAltitude_<-0.1f){
    attack=findActionAnimation(playerModel_,equippedWeapon_,"jumpattack");
    if(!attack) attack=findActionAnimation(playerModel_,equippedWeapon_,"jumpforward");
  } else {
    if(playerComboWindow_<=0){playerComboStep_=0;playerComboBranch_=-1;}
    else if(playerAttackHasHit_ || playerModel_->comboStyle==2) ++playerComboStep_;
    else {playerComboStep_=0;playerComboBranch_=-1;}
    float cdx=99999.0f,cdz=99999.0f,cda=0.0f,best=1.0e30f;for(const auto&e:entities_)if(e.alive&&e.visible&&e.model&&modelCanDamage(playerModel_,e.model,true)){float dx=e.worldX-playerWorldX_,dz=e.z-playerZ_,d=std::fabs(dx)+std::fabs(dz);if(d<best){best=d;cdx=dx;cdz=dz;cda=e.altitude-playerAltitude_;}}
    attackNumber=dynamicChainAttackNumber(playerModel_,playerComboStep_,playerComboBranch_,cdx,cdz,cda);
    std::string wanted="attack"+std::to_string(attackNumber);
    attack=findActionAnimation(playerModel_,equippedWeapon_,wanted.c_str());
    if(!attack) attack=findActionAnimation(playerModel_,equippedWeapon_,"attack");
  }
  if(!attack) return;
  player_.setAnimation(attack); lastFrame_=(std::size_t)-1; playerAttackTicks_=std::max(8,(int)attack->frameCount*6); playerAttackCooldown_=std::max(2,playerAttackTicks_/3);
  playerComboWindow_=playerJumping_?0:comboWindowFor(playerModel_,config_.comboWindow); playerQueuedAttack_=false; playerProjectileFired_=false; playerAnimJumpTriggered_=false; ++playerAttackId_;
  playerAttackHasHit_=false;playerAttackHits_=0;
  if(playerModel_->onDoAttackScript&&*playerModel_->onDoAttackScript){playerScriptCtx_.local["attack"]=(double)attackNumber;playerScriptCtx_.local["target"]=std::uintptr_t(0);runModelScript(playerModel_->onDoAttackScript,playerScriptCtx_,"player-ondoattack");}
  std::cout<<(playerJumping_?"Player air attack ":"Player combo attack ")<<attackNumber<<" chain="<<playerComboStep_<<" #"<<playerAttackId_<<" facing="<<(playerFacing_>0?"right":"left")<<"\n";
}
void Engine::startPlayerJump(){
  if(!playerAlive_ || !playerModel_ || playerJumping_ || playerFallTicks_>0 || playerRecoveryTicks_>0 || playerHitStun_>0 || grabbedEntity_>=0) return;
  float h=(float)std::max(1,playerModel_->jumpHeight); if(h<=0.0f) h=config_.jumpDefault;
  playerJumping_=true; playerAltitude_=-0.1f; playerVerticalVelocity_=-std::fabs(h);
  float js=std::max(1.0f,playerModel_->speed); playerJumpVelocityX_=(float)playerFacing_*js; playerJumpVelocityZ_=0.0f;
  auto a=findActionAnimation(playerModel_,equippedWeapon_,"jump"); if(!a) a=findActionAnimation(playerModel_,equippedWeapon_,"jumpforward"); if(a){player_.setAnimation(a);lastFrame_=(std::size_t)-1;}
  std::cout<<"Player jump height="<<h<<" vx="<<playerJumpVelocityX_<<"\n";
}
void Engine::startPlayerDash(){
  if(!playerAlive_||!playerModel_||playerJumping_||playerFallTicks_>0||playerRecoveryTicks_>0||playerHitStun_>0||grabbedEntity_>=0)return;
  playerDashTicks_=config_.dashTicks; auto a=findActionAnimation(playerModel_,equippedWeapon_,"run"); if(a){player_.setAnimation(a);lastFrame_=(std::size_t)-1;}
  std::cout<<"Player dash facing="<<(playerFacing_>0?"right":"left")<<" ticks="<<playerDashTicks_<<"\n";
}
void Engine::setPlayerWeaponIndex(int index){
  if(index<=0){equippedWeapon_=nullptr;weaponUses_=0;return;}if(!playerModel_||!playerModel_->weapons||(std::size_t)index>playerModel_->weaponCount)return;const char* name=playerModel_->weapons[index-1];if(!name||!*name||lowerString(name)=="none")return;auto* w=findCharacter(name);if(!w)return;equippedWeapon_=w;weaponUses_=w->shootNum>0?w->shootNum:0;playerScriptCtx_.local["weapon"]=(double)index;runModelScript(w->onModelCopyScript,playerScriptCtx_,"player-onmodelcopy");std::cout<<"Player weapon index="<<index<<" model="<<w->name<<" uses="<<weaponUses_<<"\n";
}
void Engine::setCoopWeaponIndex(RuntimeCoopPlayer& cp,int index){
  if(index<=0){cp.equippedWeapon=nullptr;cp.weaponUses=0;return;}if(!cp.model||!cp.model->weapons||(std::size_t)index>cp.model->weaponCount)return;const char* name=cp.model->weapons[index-1];if(!name||!*name||lowerString(name)=="none")return;auto*w=findCharacter(name);if(!w)return;cp.equippedWeapon=w;cp.weaponUses=w->shootNum>0?w->shootNum:0;cp.scriptCtx.local["weapon"]=(double)index;runModelScript(w->onModelCopyScript,cp.scriptCtx,"coop-onmodelcopy");
}
void Engine::setEntityWeaponIndex(RuntimeEntity& e,int index){
  if(index<=0){e.equippedWeapon=nullptr;e.weaponUses=0;return;}if(!e.model||!e.model->weapons||(std::size_t)index>e.model->weaponCount)return;const char*name=e.model->weapons[index-1];if(!name||!*name||lowerString(name)=="none")return;auto*w=findCharacter(name);if(!w)return;e.equippedWeapon=w;e.weaponUses=w->shootNum>0?w->shootNum:0;e.scriptCtx.local["weapon"]=(double)index;runModelScript(w->onModelCopyScript,e.scriptCtx,"entity-onmodelcopy");
}
void Engine::tryPickupWeapon(){
  for(auto& e:entities_){
    if(!e.alive||!e.model) continue; auto t=lowerString(e.model->type),st=lowerString(e.model->subtype);bool weapon=(t=="item")&&(st.find("weapon")!=std::string::npos||st.find("project")!=std::string::npos||e.model->weaponNumber>0||e.model->reloadAmount>0||(e.model->projectModel&&*e.model->projectModel));if(!weapon)continue;
    if(std::fabs(e.worldX-playerWorldX_)>24.0f||std::fabs(e.z-playerZ_)>18.0f)continue;
    if(e.model->reloadAmount>0&&equippedWeapon_&&equippedWeapon_->shootNum>0){weaponUses_+=e.model->reloadAmount;e.alive=false;e.visible=false;std::cout<<"Ammo reload +"<<e.model->reloadAmount<<" uses="<<weaponUses_<<"\n";return;}
    if(e.model->weaponNumber>0){auto before=equippedWeapon_;setPlayerWeaponIndex(e.model->weaponNumber);if(equippedWeapon_!=before||equippedWeapon_){weaponItemModel_=e.model;weaponDropsRemaining_=e.weaponDropsRemaining>=0?e.weaponDropsRemaining:std::max(0,e.model->weaponDropCounter);e.alive=false;e.visible=false;return;}}
    if(st.find("project")!=std::string::npos||(e.model->projectModel&&*e.model->projectModel)){equippedWeapon_=e.model;weaponUses_=e.model->shootNum>0?e.model->shootNum:0;e.alive=false;e.visible=false;return;}
  }
}
void Engine::tryPickupWeapon(RuntimeCoopPlayer& cp){
  for(auto& e:entities_){if(!e.alive||!e.model)continue;auto t=lowerString(e.model->type),st=lowerString(e.model->subtype);bool weapon=(t=="item")&&(st.find("weapon")!=std::string::npos||st.find("project")!=std::string::npos||e.model->weaponNumber>0||e.model->reloadAmount>0||(e.model->projectModel&&*e.model->projectModel));if(!weapon)continue;if(std::fabs(e.worldX-cp.worldX)>24.0f||std::fabs(e.z-cp.z)>18.0f)continue;if(e.model->reloadAmount>0&&cp.equippedWeapon&&cp.equippedWeapon->shootNum>0){cp.weaponUses+=e.model->reloadAmount;e.alive=false;e.visible=false;return;}if(e.model->weaponNumber>0){auto before=cp.equippedWeapon;setCoopWeaponIndex(cp,e.model->weaponNumber);if(cp.equippedWeapon!=before||cp.equippedWeapon){cp.weaponItemModel=e.model;cp.weaponDropsRemaining=e.weaponDropsRemaining>=0?e.weaponDropsRemaining:std::max(0,e.model->weaponDropCounter);e.alive=false;e.visible=false;return;}}if(st.find("project")!=std::string::npos||(e.model->projectModel&&*e.model->projectModel)){cp.equippedWeapon=e.model;cp.weaponUses=e.model->shootNum>0?e.model->shootNum:0;e.alive=false;e.visible=false;return;}}
}
void Engine::spawnProjectile(const generated::Character* model,float x,float z,float altitude,int facing,float vx,float vy,float vz,bool bomb,bool fromPlayer){
  if(!model) return; RuntimeProjectile p; p.model=model;p.worldX=x;p.z=z;p.altitude=altitude;p.facing=facing;p.vx=vx*(float)facing;p.vy=-vy;p.vz=vz;p.bomb=bomb;p.fromPlayer=fromPlayer;p.life=config_.projectileLifetime;
  p.subjectToGravity=bomb||model->subjectToGravity;p.bouncesLeft=std::max(0,model->bounce);p.bounceFactor=model->bounceFactor>0.0f?model->bounceFactor:0.5f;p.hitMask=model->projectileHitMask;
  p.animation.setAnimation(findAnimation(model,"idle")); if(!p.animation.frame()) p.animation.setAnimation(findAnimation(model,"attack1")); projectiles_.push_back(std::move(p));
  std::cout<<"Projectile spawned: "<<model->name<<" kind="<<(bomb?"bomb":"knife")<<" vx="<<vx*(float)facing<<" vy="<<-vy<<"\n";
}
void Engine::queueChildSpawn(const generated::Character* owner,const generated::Animation* a,std::size_t frameIndex,float x,float z,float altitude,int facing,std::uintptr_t parent){
  if(!owner||!a||a->spawnFrame<0||(int)frameIndex!=a->spawnFrame)return;if(a->summonFrame){for(const auto&e:entities_)if(e.alive&&e.summonedChild&&e.parentHandle==parent)return;for(const auto&q:pendingChildSpawns_)if(q.summon&&q.parent==parent)return;}std::string name=(a->custEntity&&*a->custEntity)?a->custEntity:(owner->subEntityModel?owner->subEntityModel:"");if(name.empty())return;auto* model=findCharacter(name.c_str());if(!model){std::cerr<<"Child model missing: "<<name<<"\n";return;}PendingChildSpawn q;q.model=model;q.facing=facing;q.parent=parent;q.summon=a->summonFrame;q.worldX=a->spawnScreenRelative?cameraX_+a->spawnOffsetX:x+a->spawnOffsetX*(float)facing;q.z=z+a->spawnOffsetZ;q.altitude=altitude-a->spawnOffsetA;pendingChildSpawns_.push_back(q);
}
void Engine::flushChildSpawns(){
  if(pendingChildSpawns_.empty())return;auto pending=std::move(pendingChildSpawns_);pendingChildSpawns_.clear();for(const auto&q:pending){if(!q.model)continue;RuntimeEntity e;e.model=q.model;e.weaponDropsRemaining=std::max(0,q.model->weaponDropCounter);e.worldX=q.worldX;e.z=q.z;e.altitude=q.altitude;e.facing=q.facing;e.parentHandle=q.parent;e.summonedChild=q.summon;e.maxHealth=e.health=std::max(1,q.model->health);e.juggleRemaining=std::max(1,q.model->jugglePoints);e.guardPoints=q.model->guardPoints;auto a=findAnimation(q.model,"spawn");if(!a)a=findAnimation(q.model,"idle");if(!a)a=findAnimation(q.model,"walk");e.animation.setAnimation(a);entities_.push_back(std::move(e));auto& spawned=entities_.back();spawned.scriptCtx.entity=&spawned;spawned.scriptCtx.local["self"]=std::uintptr_t((std::uintptr_t)&spawned);spawned.scriptCtx.local["parent"]=q.parent;spawned.scriptCtx.local["spawn_type"]=q.summon?3.0:2.0;runModelScript(spawned.model->onSpawnScript,spawned.scriptCtx,"child-onspawn");std::cout<<"Child spawn model="<<spawned.model->name<<" parent="<<q.parent<<" summon="<<(q.summon?"yes":"no")<<"\n";}
}
void Engine::unsummonChildren(std::uintptr_t parent,bool allChildren){
  for(auto& e:entities_){if(!e.alive||e.parentHandle!=parent)continue;if(!allChildren&&!e.summonedChild)continue;e.alive=false;e.deathTicks=0;e.scriptCtx.local["trigger"]=1.0;runModelScript(e.model?e.model->onKillScript:"",e.scriptCtx,"child-unsummon");e.visible=false;}
}
void Engine::updateChildFollowing(RuntimeEntity& e){
  if(!e.alive||!e.model||e.parentHandle==0)return;std::string st=lowerString(e.model->subtype?e.model->subtype:"");if(st.find("follow")==std::string::npos&&e.model->childFollowRange<=0.0f)return;float px=0,pz=0,pa=0;int pf=1;bool found=false;if(e.parentHandle==1){if(playerAlive_){px=playerWorldX_;pz=playerZ_;pa=playerAltitude_;pf=playerFacing_;found=true;}}else if(e.parentHandle>=2&&e.parentHandle<=4){std::size_t i=(std::size_t)e.parentHandle-2;if(i<coopPlayers_.size()&&coopPlayers_[i].alive){auto&cp=coopPlayers_[i];px=cp.worldX;pz=cp.z;pa=cp.altitude;pf=cp.facing;found=true;}}else{for(auto&p:entities_)if((std::uintptr_t)&p==e.parentHandle&&p.alive){px=p.worldX;pz=p.z;pa=p.altitude;pf=p.facing;found=true;break;}}if(!found)return;
  float tx=px+e.model->childFollowOffsetX*(float)pf,tz=pz+e.model->childFollowOffsetZ,ta=pa-e.model->childFollowOffsetY;float dx=tx-e.worldX,dz=tz-e.z,da=ta-e.altitude;
  auto outside=[](float v,float mn,float mx){return v<mn||v>mx;};bool recall=outside(dx,e.model->childRecallRangeXMin,e.model->childRecallRangeXMax)||outside(dz,e.model->childRecallRangeZMin,e.model->childRecallRangeZMax)||outside(da,e.model->childRecallRangeYMin,e.model->childRecallRangeYMax);bool follow=outside(dx,e.model->childFollowRangeXMin,e.model->childFollowRangeXMax)||outside(dz,e.model->childFollowRangeZMin,e.model->childFollowRangeZMax)||outside(da,e.model->childFollowRangeYMin,e.model->childFollowRangeYMax);
  if(recall){e.worldX=px+(e.model->childRecallOffsetX+e.model->childFollowOffsetX)*(float)pf;e.z=pz+e.model->childRecallOffsetZ+e.model->childFollowOffsetZ;e.altitude=pa-e.model->childRecallOffsetY-e.model->childFollowOffsetY;e.facing=pf;auto*a=findAnimation(e.model,(e.model->childRecallAnimation&&*e.model->childRecallAnimation)?e.model->childRecallAnimation:"respawn");if(!a)a=findAnimation(e.model,"spawn");if(a)setEntityAnimation(e,a);return;}
  switch(e.model->childDirectionAdjust){case 1:e.facing=pf;break;case 2:e.facing=-pf;break;case 3:e.facing=-1;break;case 4:e.facing=1;break;case 5:e.facing=dx<0?1:-1;break;case 6:e.facing=dx<0?-1:1;break;default:if(std::fabs(dx)>1)e.facing=dx<0?-1:1;break;}
  if(follow){float dist=std::sqrt(dx*dx+dz*dz+da*da),speed=std::max(0.5f,e.model->runSpeed>0?e.model->runSpeed:e.model->speed);if(dist>0.001f){e.worldX+=dx/dist*speed;e.z+=dz/dist*speed;e.altitude+=da/dist*std::min(speed,1.5f);}auto*w=findAnimation(e.model,e.model->runSpeed>0?"run":"walk");if(w&&e.animation.animation()!=w)setEntityAnimation(e,w);}else if(e.attackTicks<=0&&e.hitStun<=0&&e.fallTicks<=0){auto*i=findAnimation(e.model,"idle");if(i&&e.animation.animation()!=i)setEntityAnimation(e,i);}
}
void Engine::queueWeaponDrop(const generated::Character* item,float x,float z,float altitude,int facing,int remaining){if(!item||remaining<=0)return;PendingWeaponDrop q;q.itemModel=item;q.worldX=x;q.z=z;q.altitude=altitude;q.facing=facing;q.remainingDrops=remaining;pendingWeaponDrops_.push_back(q);}
void Engine::flushWeaponDrops(){
  if(pendingWeaponDrops_.empty())return;auto q=std::move(pendingWeaponDrops_);pendingWeaponDrops_.clear();for(const auto&d:q){if(!d.itemModel||d.remainingDrops<=0)continue;RuntimeEntity e;e.model=d.itemModel;e.worldX=d.worldX+12.0f*(float)d.facing;e.z=d.z;e.altitude=d.altitude;e.facing=d.facing;e.weaponDropsRemaining=d.remainingDrops;e.maxHealth=e.health=std::max(1,d.itemModel->health);auto*a=findAnimation(d.itemModel,"respawn");if(!a)a=findAnimation(d.itemModel,"spawn");if(!a)a=findAnimation(d.itemModel,"idle");e.animation.setAnimation(a);entities_.push_back(std::move(e));auto&drop=entities_.back();drop.scriptCtx.entity=&drop;drop.scriptCtx.local["self"]=std::uintptr_t((std::uintptr_t)&drop);runModelScript(drop.model->onSpawnScript,drop.scriptCtx,"weapon-drop");}
}
void Engine::dropPlayerWeapon(bool stageLoss){if(!equippedWeapon_)return;const auto*spec=equippedWeapon_->weaponLossDefined?equippedWeapon_:playerModel_;int remaining=weaponDropsRemaining_;if(remaining<0&&weaponItemModel_)remaining=std::max(0,weaponItemModel_->weaponDropCounter);if(!stageLoss&&weaponItemModel_&&remaining>1)queueWeaponDrop(weaponItemModel_,playerWorldX_,playerZ_,playerAltitude_,playerFacing_,remaining-1);int loss=spec?std::max(0,spec->weaponLossIndex):0;setPlayerWeaponIndex(loss);weaponItemModel_=nullptr;weaponDropsRemaining_=-1;}
void Engine::dropCoopWeapon(RuntimeCoopPlayer&cp,bool stageLoss){if(!cp.equippedWeapon)return;const auto*spec=cp.equippedWeapon->weaponLossDefined?cp.equippedWeapon:cp.model;int remaining=cp.weaponDropsRemaining;if(remaining<0&&cp.weaponItemModel)remaining=std::max(0,cp.weaponItemModel->weaponDropCounter);if(!stageLoss&&cp.weaponItemModel&&remaining>1)queueWeaponDrop(cp.weaponItemModel,cp.worldX,cp.z,cp.altitude,cp.facing,remaining-1);int loss=spec?std::max(0,spec->weaponLossIndex):0;setCoopWeaponIndex(cp,loss);cp.weaponItemModel=nullptr;cp.weaponDropsRemaining=-1;}
void Engine::dropEntityWeapon(RuntimeEntity&e,bool stageLoss){if(!e.equippedWeapon)return;const auto*spec=e.equippedWeapon->weaponLossDefined?e.equippedWeapon:e.model;int remaining=e.weaponDropsRemaining;if(remaining<0&&e.weaponItemModel)remaining=std::max(0,e.weaponItemModel->weaponDropCounter);if(!stageLoss&&e.weaponItemModel&&remaining>1)queueWeaponDrop(e.weaponItemModel,e.worldX,e.z,e.altitude,e.facing,remaining-1);int loss=spec?std::max(0,spec->weaponLossIndex):0;setEntityWeaponIndex(e,loss);e.weaponItemModel=nullptr;e.weaponDropsRemaining=-1;}
void Engine::maybeSpawnProjectile(const generated::Character* owner,const generated::Animation* a,std::size_t frameIndex,float x,float z,float altitude,int facing,bool fromPlayer,bool& firedFlag,const generated::Character* equippedOverride,int* weaponUses){
  if(!owner||!a||firedFlag)return; bool bomb=false;int trigger=a->throwFrame;std::string modelName=a->custKnife?a->custKnife:"";
  if(trigger<0 && a->tossFrame>=0){trigger=a->tossFrame;bomb=true;modelName=a->custBomb?a->custBomb:"";}
  if(trigger<0)return; if((int)frameIndex<trigger)return;
  const generated::Character* equipped=equippedOverride?equippedOverride:(fromPlayer?equippedWeapon_:nullptr);
  if(modelName.empty() && equipped){ if(bomb&&equipped->bombModel&&*equipped->bombModel)modelName=equipped->bombModel; else if(equipped->projectModel&&*equipped->projectModel)modelName=equipped->projectModel; else if(equipped->knifeModel&&*equipped->knifeModel)modelName=equipped->knifeModel; }
  if(modelName.empty()){ if(bomb && owner->bombModel)modelName=owner->bombModel; else if(owner->projectModel&&*owner->projectModel)modelName=owner->projectModel; else if(owner->knifeModel)modelName=owner->knifeModel; }
  auto model=findCharacter(modelName.c_str()); if(!model){ if(!modelName.empty())std::cerr<<"Projectile model missing: "<<modelName<<"\n"; firedFlag=true;return; }
  float vy=a->projectileVelocityY; if(bomb && std::fabs(vy)<0.001f)vy=(float)std::max(1,model->jumpHeight);
  spawnProjectile(model,x,z,altitude-(float)a->projectileOffsetY,facing,a->projectileVelocityX,vy,a->projectileVelocityZ,bomb,fromPlayer); firedFlag=true;if(equipped&&equipped->shootNum>0&&weaponUses&&*weaponUses>0){--*weaponUses;}
}
void Engine::updatePlayer(){
  if(!playerModel_ || !playerAlive_) return; float dx=0,dz=0; bool attackPressed=false,grabPressed=false,throwPressed=false,jumpPressed=false,dashPressed=false,pickupPressed=false,running=false;
  bool leftHeld=false,rightHeld=false,upHeld=false,downHeld=false,attackHeld=false,grabHeld=false,throwHeld=false,jumpHeld=false,dashHeld=false,pickupHeld=false,startHeld=false,escHeld=false;
#ifdef _WIN32
  static bool attackWasDown=false,grabWasDown=false,throwWasDown=false,jumpWasDown=false,dashWasDown=false,pickupWasDown=false;
  bool attackDown=(GetAsyncKeyState(config_.keyAttack)&0x8000)!=0;
  bool grabDown=(GetAsyncKeyState(config_.keyGrab)&0x8000)!=0, throwDown=(GetAsyncKeyState(config_.keyThrow)&0x8000)!=0;
  bool jumpDown=(GetAsyncKeyState(config_.keyJump)&0x8000)!=0, dashDown=(GetAsyncKeyState(config_.keyDash)&0x8000)!=0, pickupDown=(GetAsyncKeyState(config_.keyPickup)&0x8000)!=0;
  leftHeld=(GetAsyncKeyState(config_.keyLeft)&0x8000)!=0;rightHeld=(GetAsyncKeyState(config_.keyRight)&0x8000)!=0;upHeld=(GetAsyncKeyState(config_.keyUp)&0x8000)!=0;downHeld=(GetAsyncKeyState(config_.keyDown)&0x8000)!=0;
  attackHeld=attackDown;grabHeld=grabDown;throwHeld=throwDown;jumpHeld=jumpDown;dashHeld=dashDown;pickupHeld=pickupDown;startHeld=(GetAsyncKeyState(VK_RETURN)&0x8000)!=0;escHeld=(GetAsyncKeyState(VK_ESCAPE)&0x8000)!=0;
  attackPressed=attackDown&&!attackWasDown; grabPressed=grabDown&&!grabWasDown; throwPressed=throwDown&&!throwWasDown; jumpPressed=jumpDown&&!jumpWasDown;dashPressed=dashDown&&!dashWasDown;pickupPressed=pickupDown&&!pickupWasDown;
  attackWasDown=attackDown; grabWasDown=grabDown; throwWasDown=throwDown;jumpWasDown=jumpDown;dashWasDown=dashDown;pickupWasDown=pickupDown;
  running=(GetAsyncKeyState(config_.keyRun)&0x8000)!=0;
  if(config_.gamepad){XINPUT_STATE xs{};if(XInputGetState((DWORD)std::clamp(config_.player1Gamepad,0,3),&xs)==ERROR_SUCCESS){auto&g=xs.Gamepad;const int dead=7849;float gx=std::abs((int)g.sThumbLX)>dead?(float)g.sThumbLX/32767.0f:0.0f;float gy=std::abs((int)g.sThumbLY)>dead?-(float)g.sThumbLY/32767.0f:0.0f;if(std::fabs(gx)>std::fabs(dx))dx=gx;if(std::fabs(gy)>std::fabs(dz))dz=gy;leftHeld=leftHeld||gx<-0.25f||(g.wButtons&XINPUT_GAMEPAD_DPAD_LEFT);rightHeld=rightHeld||gx>0.25f||(g.wButtons&XINPUT_GAMEPAD_DPAD_RIGHT);upHeld=upHeld||gy<-0.25f||(g.wButtons&XINPUT_GAMEPAD_DPAD_UP);downHeld=downHeld||gy>0.25f||(g.wButtons&XINPUT_GAMEPAD_DPAD_DOWN);attackHeld=attackHeld||(g.wButtons&(unsigned short)config_.padAttack);jumpHeld=jumpHeld||(g.wButtons&(unsigned short)config_.padJump);pickupHeld=pickupHeld||(g.wButtons&(unsigned short)config_.padPickup);grabHeld=grabHeld||(g.wButtons&(unsigned short)config_.padGrab);dashHeld=dashHeld||(g.wButtons&(unsigned short)config_.padDash);throwHeld=throwHeld||(g.wButtons&(unsigned short)config_.padThrow);startHeld=startHeld||(g.wButtons&XINPUT_GAMEPAD_START);attackPressed=attackPressed||gamepadButtonPressed((unsigned short)config_.padAttack);jumpPressed=jumpPressed||gamepadButtonPressed((unsigned short)config_.padJump);pickupPressed=pickupPressed||gamepadButtonPressed((unsigned short)config_.padPickup);grabPressed=grabPressed||gamepadButtonPressed((unsigned short)config_.padGrab);dashPressed=dashPressed||gamepadButtonPressed((unsigned short)config_.padDash);throwPressed=throwPressed||gamepadButtonPressed((unsigned short)config_.padThrow);running=running||(g.bRightTrigger>80);}}
  if(playerHitStun_<=0 && playerFallTicks_<=0 && playerRecoveryTicks_<=0 && grabbedEntity_<0){
    if(GetAsyncKeyState(config_.keyLeft)&0x8000) dx-=1; if(GetAsyncKeyState(config_.keyRight)&0x8000) dx+=1;
    if(GetAsyncKeyState(config_.keyUp)&0x8000) dz-=1; if(GetAsyncKeyState(config_.keyDown)&0x8000) dz+=1;
  }
#else
  float nearest=99999.0f; for(const auto& e:entities_) if(e.alive && !e.grabbed && e.model && lowerString(e.model->type)=="enemy") nearest=std::min(nearest,std::fabs(e.worldX-playerWorldX_));
  if(tickCounter_==2){pickupPressed=true;pickupHeld=true;}
  if(playerHitStun_<=0 && playerFallTicks_<=0 && playerRecoveryTicks_<=0 && !playerJumping_ && grabbedEntity_<0){ dx = scrollDir_<0 ? -1.0f : 1.0f;leftHeld=dx<0;rightHeld=dx>0; }
  attackHeld=attackPressed;jumpHeld=jumpPressed;grabHeld=grabPressed;throwHeld=throwPressed;dashHeld=dashPressed;
#endif
  unsigned rawKeys=(leftHeld?SK_LEFT:0u)|(rightHeld?SK_RIGHT:0u)|(upHeld?SK_UP:0u)|(downHeld?SK_DOWN:0u)|(attackHeld?SK_ATTACK:0u)|(jumpHeld?SK_JUMP:0u)|(dashHeld?SK_SPECIAL:0u)|(startHeld?SK_START:0u)|(escHeld?SK_ESC:0u)|(grabHeld?SK_ATTACK2:0u)|(throwHeld?SK_ATTACK3:0u)|(pickupHeld?SK_ATTACK4:0u);
  rawKeys&=~playerDisabledKeys_[0];playerNewKeys_[0]=rawKeys&~playerKeys_[0];playerReleasedKeys_[0]=playerKeys_[0]&~rawKeys;playerKeys_[0]=rawKeys;playerPlayKeys_[0]=rawKeys;
  playerScriptCtx_.player=true;playerScriptCtx_.playerIndex=0;playerScriptCtx_.local["self"]=std::uintptr_t(1);playerScriptCtx_.local["player"]=0.0;
  if(playerNewKeys_[0]||playerReleasedKeys_[0]){
    if(playerModel_->keyScript&&*playerModel_->keyScript)runModelScript(playerModel_->keyScript,playerScriptCtx_,"player-key");
    const auto keySpecific=std::string("scripts/key")+std::to_string(playerScriptCtx_.playerIndex+1)+".c";
    if(std::filesystem::exists(root_/"assets"/"openbor-data"/keySpecific))runModelScript(keySpecific.c_str(),playerScriptCtx_,"global-key-player");
    if(std::filesystem::exists(root_/"assets"/"openbor-data"/"scripts"/"keyall.c"))runModelScript("scripts/keyall.c",playerScriptCtx_,"global-key-all");
  }
  runModelScript(playerModel_->thinkScript,playerScriptCtx_,"player-think");runModelScript(playerModel_->updateScript,playerScriptCtx_,"player-update");
  unsigned play=playerPlayKeys_[0];if(!(play&SK_ATTACK))attackPressed=false;if(!(play&SK_ATTACK2))grabPressed=false;if(!(play&SK_ATTACK3))throwPressed=false;if(!(play&SK_ATTACK4))pickupPressed=false;if(!(play&SK_JUMP))jumpPressed=false;if(!(play&SK_SPECIAL))dashPressed=false;if(dx<0&&!(play&SK_LEFT))dx=0;if(dx>0&&!(play&SK_RIGHT))dx=0;if(dz<0&&!(play&SK_UP))dz=0;if(dz>0&&!(play&SK_DOWN))dz=0;
  if(dx<0) playerFacing_=-1; else if(dx>0) playerFacing_=1;
  recordInputHistory(0);
  const generated::Character* commandModel=equippedWeapon_?equippedWeapon_:playerModel_;
  bool commandActivated=false;
  if(playerAttackTicks_<=0&&playerHitStun_<=0&&playerFallTicks_<=0&&playerRecoveryTicks_<=0&&grabbedEntity_<0){if(auto* special=commandTarget(commandModel,0,playerFacing_)){player_.setAnimation(special);lastFrame_=(std::size_t)-1;playerAttackTicks_=std::max(8,(int)special->frameCount*6);playerAttackCooldown_=std::max(2,playerAttackTicks_/3);playerComboWindow_=0;playerQueuedAttack_=false;playerProjectileFired_=false;playerAttackHasHit_=false;playerAttackHits_=0;++playerAttackId_;commandActivated=true;attackPressed=jumpPressed=dashPressed=grabPressed=throwPressed=pickupPressed=false;if(commandModel&&commandModel->onDoAttackScript&&*commandModel->onDoAttackScript){playerScriptCtx_.local["attack"]=std::string(special->name?special->name:"freespecial");playerScriptCtx_.local["target"]=std::uintptr_t(0);runModelScript(commandModel->onDoAttackScript,playerScriptCtx_,"player-com");}}}
  if(playerAttackTicks_>0&&!commandActivated){if(auto* ca=cancelTarget(commandModel,player_.animation(),player_.frameIndex(),playerAttackHits_,0,playerFacing_)){player_.setAnimation(ca);lastFrame_=(std::size_t)-1;playerAttackTicks_=std::max(8,(int)ca->frameCount*6);playerAttackCooldown_=std::max(2,playerAttackTicks_/3);playerAttackHasHit_=false;playerAttackHits_=0;playerProjectileFired_=false;++playerAttackId_;attackPressed=false;jumpPressed=false;}}
  if(!commandActivated){if(pickupPressed) tryPickupWeapon(); if(jumpPressed) startPlayerJump(); if(dashPressed) startPlayerDash(); if(grabPressed) tryGrabNearest(); if(throwPressed) throwGrabbed(); if(attackPressed) startPlayerAttack();}
  if(playerAttackCooldown_>0) --playerAttackCooldown_; if(playerComboWindow_>0) --playerComboWindow_; else if(playerAttackTicks_<=0) playerComboStep_=0;
  if(playerFallTicks_>0 && !playerJumping_){
    --playerFallTicks_; playerAltitude_+=playerVerticalVelocity_; playerVerticalVelocity_+=config_.gravity;
    if(playerAltitude_>=0.0f){playerAltitude_=0;playerVerticalVelocity_=0;if(playerFallTicks_<=0){playerRecoveryTicks_=config_.recoveryTicks;auto r=reactionAnimation(playerModel_,"rise",playerReactionType_);if(!r)r=findAnimation(playerModel_,"rise");if(r)player_.setAnimation(r);}}
    player_.update(1);return;
  }
  if(playerJumping_){
    float airAdjust=(playerModel_->jumpMoveX>=2?0.10f:0.0f);playerJumpVelocityX_+=dx*airAdjust*(float)playerFacing_;playerJumpVelocityZ_+=dz*(playerModel_->jumpMoveZ?0.08f:0.04f);
    playerWorldX_+=playerJumpVelocityX_;playerZ_+=playerJumpVelocityZ_;playerAltitude_+=playerVerticalVelocity_;playerVerticalVelocity_+=config_.gravity;
    if(playerAttackTicks_>0){maybeSpawnProjectile(playerModel_,player_.animation(),player_.frameIndex(),playerWorldX_,playerZ_,playerAltitude_,playerFacing_,true,playerProjectileFired_,equippedWeapon_,&weaponUses_);if(equippedWeapon_&&equippedWeapon_->shootNum>0&&weaponUses_<=0){if(equippedWeapon_->typeShot&&weaponItemModel_)dropPlayerWeapon();else setPlayerWeaponIndex(0);}--playerAttackTicks_;player_.update(1);}
    else player_.update(1);
    if(playerAltitude_>=0.0f){playerAltitude_=0;playerVerticalVelocity_=0;playerJumpVelocityX_=playerJumpVelocityZ_=0;playerJumping_=false;playerAttackTicks_=0;playerProjectileFired_=false;auto land=findAnimation(playerModel_,"land");player_.setAnimation(land?land:findActionAnimation(playerModel_,equippedWeapon_,"idle"));lastFrame_=(std::size_t)-1;std::cout<<"Player landed\n";}
    playerWorldX_=std::clamp(playerWorldX_,0.0f,std::max(0.0f,stageLength_-1.0f));if(stage_)playerZ_=std::clamp(playerZ_,(float)stage_->zMin,(float)stage_->zMax);return;
  }
  if(playerRecoveryTicks_>0){--playerRecoveryTicks_;player_.update(1);if(playerRecoveryTicks_==0){player_.setAnimation(findActionAnimation(playerModel_,equippedWeapon_,"idle"));lastFrame_=(std::size_t)-1;}return;}
  if(playerHitStun_>0){--playerHitStun_;player_.update(1);if(playerHitStun_==0){player_.setAnimation(findActionAnimation(playerModel_,equippedWeapon_,"idle"));lastFrame_=(std::size_t)-1;}return;}
  if(playerAttackTicks_>0){
    auto active=player_.animation();
    maybeSpawnProjectile(playerModel_,active,player_.frameIndex(),playerWorldX_,playerZ_,playerAltitude_,playerFacing_,true,playerProjectileFired_,equippedWeapon_,&weaponUses_);if(equippedWeapon_&&equippedWeapon_->shootNum>0&&weaponUses_<=0){if(equippedWeapon_->typeShot&&weaponItemModel_)dropPlayerWeapon();else setPlayerWeaponIndex(0);}
    if(active && active->jumpFrame>=0 && !playerAnimJumpTriggered_ && (int)player_.frameIndex()>=active->jumpFrame){
      playerAnimJumpTriggered_=true;playerJumping_=true;playerAltitude_=-0.1f;float jy=std::fabs(active->jumpVelocityY)>0.001f?active->jumpVelocityY:(float)std::max(1,playerModel_->jumpHeight);playerVerticalVelocity_=-std::fabs(jy);playerJumpVelocityX_=active->jumpVelocityX*(float)playerFacing_;playerJumpVelocityZ_=active->jumpVelocityZ;std::cout<<"jumpframe triggered y="<<jy<<" x="<<playerJumpVelocityX_<<" z="<<playerJumpVelocityZ_<<"\n";
    }
    --playerAttackTicks_;player_.update(1);if(playerAttackTicks_==0&&!playerJumping_){if(playerQueuedAttack_){playerAttackCooldown_=0;startPlayerAttack();}else{player_.setAnimation(findActionAnimation(playerModel_,equippedWeapon_,"idle"));lastFrame_=(std::size_t)-1;}}return;}
  if(grabbedEntity_>=0){if((std::size_t)grabbedEntity_<entities_.size()){auto& e=entities_[(std::size_t)grabbedEntity_];e.worldX=playerWorldX_+(float)(playerFacing_*14);e.z=playerZ_;}player_.update(1);return;}
  float walk=std::max(1.0f,playerModel_->speed),run=playerModel_->runSpeed>0?playerModel_->runSpeed:walk*config_.runMultiplier;float speed=running?run:walk;
  if(playerDashTicks_>0){--playerDashTicks_;dx=(float)playerFacing_;speed=std::max(config_.dashSpeed,run);}
  float oldX=playerWorldX_,oldZ=playerZ_;playerWorldX_+=dx*speed+playerScriptVelocityX_;playerZ_+=dz*speed+playerScriptVelocityZ_;float unclampedX=playerWorldX_,unclampedZ=playerZ_;playerWorldX_=std::clamp(playerWorldX_,0.0f,std::max(0.0f,stageLength_-1.0f));if(playerWorldX_!=unclampedX&&playerModel_->onBlockSScript&&*playerModel_->onBlockSScript){playerScriptCtx_.local["plane"]=0.0;runModelScript(playerModel_->onBlockSScript,playerScriptCtx_,"player-onblocks");}if(stage_){playerZ_=std::clamp(playerZ_,(float)stage_->zMin,(float)stage_->zMax);if(playerZ_!=unclampedZ&&playerModel_->onBlockZScript&&*playerModel_->onBlockZScript){playerScriptCtx_.local["plane"]=1.0;runModelScript(playerModel_->onBlockZScript,playerScriptCtx_,"player-onblockz");}}applyStageGeometry(oldX,oldZ);
  if(std::fabs(playerWorldX_-oldX)>0.001f&&playerModel_->onMoveXScript&&*playerModel_->onMoveXScript){playerScriptCtx_.local["movex"]=double(playerWorldX_-oldX);runModelScript(playerModel_->onMoveXScript,playerScriptCtx_,"player-onmovex");}
  if(std::fabs(playerZ_-oldZ)>0.001f&&playerModel_->onMoveZScript&&*playerModel_->onMoveZScript){playerScriptCtx_.local["movez"]=double(playerZ_-oldZ);runModelScript(playerModel_->onMoveZScript,playerScriptCtx_,"player-onmovez");}
  const char* anim=(dx!=0||dz!=0)?((running||playerDashTicks_>0)?"run":"walk"):"idle";const generated::Animation* wanted=findActionAnimation(playerModel_,equippedWeapon_,anim);if(wanted&&wanted!=player_.animation()){player_.setAnimation(wanted);lastFrame_=(std::size_t)-1;}player_.update(1);
}
void Engine::updateCoopPlayers(){
  for(std::size_t ci=0;ci<coopPlayers_.size();++ci){auto& cp=coopPlayers_[ci];int slot=(int)ci+1;
    if(!cp.model)continue;if(!cp.alive){cp.animation.update(1);continue;}
    float dx=0.0f,dz=0.0f;bool attackPressed=false,jumpPressed=false,pickupPressed=false,running=false;unsigned rawKeys=0;
#ifdef _WIN32
    XINPUT_STATE xs{};if(config_.gamepad&&XInputGetState((DWORD)std::clamp(cp.gamepadId,0,3),&xs)==ERROR_SUCCESS){auto&g=xs.Gamepad;const int dead=7849;float gx=std::abs((int)g.sThumbLX)>dead?(float)g.sThumbLX/32767.0f:0.0f;float gy=std::abs((int)g.sThumbLY)>dead?-(float)g.sThumbLY/32767.0f:0.0f;dx=gx;dz=gy;if(g.wButtons&XINPUT_GAMEPAD_DPAD_LEFT)dx=-1;if(g.wButtons&XINPUT_GAMEPAD_DPAD_RIGHT)dx=1;if(g.wButtons&XINPUT_GAMEPAD_DPAD_UP)dz=-1;if(g.wButtons&XINPUT_GAMEPAD_DPAD_DOWN)dz=1;if(dx<-.25f)rawKeys|=SK_LEFT;if(dx>.25f)rawKeys|=SK_RIGHT;if(dz<-.25f)rawKeys|=SK_UP;if(dz>.25f)rawKeys|=SK_DOWN;if(g.wButtons&(unsigned short)config_.padAttack)rawKeys|=SK_ATTACK;if(g.wButtons&(unsigned short)config_.padJump)rawKeys|=SK_JUMP;if(g.wButtons&(unsigned short)config_.padGrab)rawKeys|=SK_ATTACK2;if(g.wButtons&(unsigned short)config_.padThrow)rawKeys|=SK_ATTACK3;if(g.wButtons&(unsigned short)config_.padPickup)rawKeys|=SK_ATTACK4;if(g.wButtons&(unsigned short)config_.padDash)rawKeys|=SK_SPECIAL;if(g.wButtons&XINPUT_GAMEPAD_START)rawKeys|=SK_START;attackPressed=gamepadButtonPressedFor(cp.gamepadId,(unsigned short)config_.padAttack);jumpPressed=gamepadButtonPressedFor(cp.gamepadId,(unsigned short)config_.padJump);pickupPressed=gamepadButtonPressedFor(cp.gamepadId,(unsigned short)config_.padPickup);running=g.bRightTrigger>80;}
#else
    if(tickCounter_%120<60){dx=0.35f;rawKeys|=SK_RIGHT;} if(tickCounter_%90==10){attackPressed=true;rawKeys|=SK_ATTACK;}
#endif
    rawKeys&=~playerDisabledKeys_[slot];playerNewKeys_[slot]=rawKeys&~playerKeys_[slot];playerReleasedKeys_[slot]=playerKeys_[slot]&~rawKeys;playerKeys_[slot]=rawKeys;playerPlayKeys_[slot]=rawKeys;
    cp.scriptCtx.player=true;cp.scriptCtx.playerIndex=slot;cp.scriptCtx.local["self"]=std::uintptr_t(slot+1);cp.scriptCtx.local["player"]=(double)slot;
    if(playerNewKeys_[slot]||playerReleasedKeys_[slot]){if(cp.model->keyScript&&*cp.model->keyScript)runModelScript(cp.model->keyScript,cp.scriptCtx,"coop-key");auto keySpecific=std::string("scripts/key")+std::to_string(slot+1)+".c";if(std::filesystem::exists(root_/"assets"/"openbor-data"/keySpecific))runModelScript(keySpecific.c_str(),cp.scriptCtx,"global-key-player");if(std::filesystem::exists(root_/"assets"/"openbor-data"/"scripts"/"keyall.c"))runModelScript("scripts/keyall.c",cp.scriptCtx,"global-key-all");}
    runModelScript(cp.model->thinkScript,cp.scriptCtx,"coop-think");runModelScript(cp.model->updateScript,cp.scriptCtx,"coop-update");
    if(!(playerPlayKeys_[slot]&SK_ATTACK))attackPressed=false;if(!(playerPlayKeys_[slot]&SK_JUMP))jumpPressed=false;if(!(playerPlayKeys_[slot]&SK_ATTACK4))pickupPressed=false;if(dx<0&&!(playerPlayKeys_[slot]&SK_LEFT))dx=0;if(dx>0&&!(playerPlayKeys_[slot]&SK_RIGHT))dx=0;if(dz<0&&!(playerPlayKeys_[slot]&SK_UP))dz=0;if(dz>0&&!(playerPlayKeys_[slot]&SK_DOWN))dz=0;if(dx<0)cp.facing=-1;else if(dx>0)cp.facing=1;recordInputHistory(slot);if(pickupPressed)tryPickupWeapon(cp);
    if(cp.hitStun>0){--cp.hitStun;cp.animation.update(1);continue;}
    if(cp.attackCooldown>0)--cp.attackCooldown;
    const generated::Character* commandModel=cp.equippedWeapon?cp.equippedWeapon:cp.model;bool commandActivated=false;if(cp.attackTicks<=0&&!cp.jumping){if(auto*special=commandTarget(commandModel,slot,cp.facing)){cp.animation.setAnimation(special);cp.lastFrame=(std::size_t)-1;cp.attackTicks=std::max(8,(int)special->frameCount*6);cp.attackCooldown=std::max(2,cp.attackTicks/3);cp.comboWindow=0;cp.projectileFired=false;cp.attackHasHit=false;cp.attackHits=0;++cp.attackId;commandActivated=true;attackPressed=jumpPressed=false;if(commandModel&&commandModel->onDoAttackScript&&*commandModel->onDoAttackScript){cp.scriptCtx.local["attack"]=std::string(special->name?special->name:"freespecial");cp.scriptCtx.local["target"]=std::uintptr_t(0);runModelScript(commandModel->onDoAttackScript,cp.scriptCtx,"coop-com");}}}
    if(jumpPressed&&!cp.jumping&&!commandActivated){cp.jumping=true;cp.altitude=-0.1f;cp.verticalVelocity=-(float)std::max(1,cp.model->jumpHeight);auto a=findActionAnimation(cp.model,cp.equippedWeapon,"jump");if(a)cp.animation.setAnimation(a);cp.lastFrame=(std::size_t)-1;}
    if(cp.comboWindow>0)--cp.comboWindow;else if(cp.attackTicks<=0){cp.comboStep=0;cp.comboBranch=-1;}
    if(cp.attackTicks>0&&!commandActivated){if(auto* ca=cancelTarget(commandModel,cp.animation.animation(),cp.animation.frameIndex(),cp.attackHits,slot,cp.facing)){cp.animation.setAnimation(ca);cp.lastFrame=(std::size_t)-1;cp.attackTicks=std::max(8,(int)ca->frameCount*6);cp.attackCooldown=std::max(2,cp.attackTicks/3);cp.attackHasHit=false;cp.attackHits=0;cp.projectileFired=false;++cp.attackId;attackPressed=false;jumpPressed=false;}}
    if(!commandActivated&&attackPressed&&cp.attackTicks<=0&&cp.attackCooldown<=0){const generated::Animation* a=nullptr;int attackNumber=1;if(cp.jumping)a=findActionAnimation(cp.model,cp.equippedWeapon,"jumpattack");else{if(cp.comboWindow<=0){cp.comboStep=0;cp.comboBranch=-1;}else if(cp.attackHasHit||cp.model->comboStyle==2)++cp.comboStep;else{cp.comboStep=0;cp.comboBranch=-1;}float cdx=99999.0f,cdz=99999.0f,cda=0.0f,best=1.0e30f;for(const auto&e:entities_)if(e.alive&&e.visible&&e.model&&modelCanDamage(cp.model,e.model,true)){float tx=e.worldX-cp.worldX,tz=e.z-cp.z,d=std::fabs(tx)+std::fabs(tz);if(d<best){best=d;cdx=tx;cdz=tz;cda=e.altitude-cp.altitude;}}attackNumber=dynamicChainAttackNumber(cp.model,cp.comboStep,cp.comboBranch,cdx,cdz,cda);std::string wanted="attack"+std::to_string(attackNumber);a=findActionAnimation(cp.model,cp.equippedWeapon,wanted.c_str());}if(!a)a=findActionAnimation(cp.model,cp.equippedWeapon,"attack1");if(!a)a=findActionAnimation(cp.model,cp.equippedWeapon,"attack");if(a){cp.animation.setAnimation(a);cp.attackTicks=std::max(8,(int)a->frameCount*6);cp.attackCooldown=std::max(2,cp.attackTicks/3);cp.comboWindow=comboWindowFor(cp.model,config_.comboWindow);cp.attackHasHit=false;cp.attackHits=0;cp.projectileFired=false;cp.attackId+=1;if(cp.attackId==0)cp.attackId=1;cp.lastFrame=(std::size_t)-1;if(cp.model->onDoAttackScript&&*cp.model->onDoAttackScript){cp.scriptCtx.local["attack"]=(double)attackNumber;cp.scriptCtx.local["target"]=std::uintptr_t(0);runModelScript(cp.model->onDoAttackScript,cp.scriptCtx,"coop-ondoattack");}}}
    float oldX=cp.worldX,oldZ=cp.z;
    cp.worldX+=cp.scriptVelocityX;cp.z+=cp.scriptVelocityZ;
    if(cp.jumping){cp.worldX+=dx*0.7f;cp.z+=dz*0.7f;cp.altitude+=cp.verticalVelocity;cp.verticalVelocity+=config_.gravity;cp.animation.update(1);if(cp.altitude>=0){cp.altitude=0;cp.verticalVelocity=0;cp.jumping=false;if(cp.attackTicks<=0)cp.animation.setAnimation(findActionAnimation(cp.model,cp.equippedWeapon,"idle"));}}
    else if(cp.attackTicks>0){maybeSpawnProjectile(cp.model,cp.animation.animation(),cp.animation.frameIndex(),cp.worldX,cp.z,cp.altitude,cp.facing,true,cp.projectileFired,cp.equippedWeapon,&cp.weaponUses);if(cp.equippedWeapon&&cp.equippedWeapon->shootNum>0&&cp.weaponUses<=0){if(cp.equippedWeapon->typeShot&&cp.weaponItemModel)dropCoopWeapon(cp);else setCoopWeaponIndex(cp,0);}--cp.attackTicks;cp.animation.update(1);if(cp.attackTicks==0){cp.projectileFired=false;cp.animation.setAnimation(findActionAnimation(cp.model,cp.equippedWeapon,"idle"));}}
    else{float walk=std::max(1.0f,cp.model->speed),run=cp.model->runSpeed>0?cp.model->runSpeed:walk*config_.runMultiplier;float speed=running?run:walk;cp.worldX+=dx*speed;cp.z+=dz*speed;cp.worldX=std::clamp(cp.worldX,cameraX_+4.0f,std::min(stageLength_-1.0f,cameraX_+(float)config_.logicalWidth-4.0f));if(stage_){cp.z=std::clamp(cp.z,(float)stage_->zMin,(float)stage_->zMax);for(std::size_t gi=0;gi<stage_->geometryCount;++gi){const auto&g=stage_->geometry[gi];std::string k=lowerString(g.kind?g.kind:"");bool inside=cp.worldX>=g.x&&cp.worldX<=g.x+g.w&&cp.z>=g.z&&cp.z<=g.z+g.h;if(k=="wall"&&inside){cp.worldX=oldX;cp.z=oldZ;}else if(k=="hole"&&inside&&cp.altitude>=-0.1f){cp.health=std::max(1,cp.health-10);cp.worldX=(float)stage_->playerStartX;cp.z=(float)stage_->playerStartZ;}}}const generated::Animation* wanted=findActionAnimation(cp.model,cp.equippedWeapon,(dx!=0||dz!=0)?(running?"run":"walk"):"idle");if(wanted&&wanted!=cp.animation.animation()){cp.animation.setAnimation(wanted);cp.lastFrame=(std::size_t)-1;}cp.animation.update(1);}
    if(std::fabs(cp.worldX-oldX)>0.001f&&cp.model->onMoveXScript&&*cp.model->onMoveXScript){cp.scriptCtx.local["movex"]=(double)(cp.worldX-oldX);runModelScript(cp.model->onMoveXScript,cp.scriptCtx,"coop-onmovex");}
    if(std::fabs(cp.z-oldZ)>0.001f&&cp.model->onMoveZScript&&*cp.model->onMoveZScript){cp.scriptCtx.local["movez"]=(double)(cp.z-oldZ);runModelScript(cp.model->onMoveZScript,cp.scriptCtx,"coop-onmovez");}
  }
}
void Engine::startEnemyAttack(RuntimeEntity& e,float targetDistance,std::uintptr_t targetHandle){
  if(!e.alive || !e.model || e.attackCooldown>0 || e.attackTicks>0 || e.fallTicks>0 || e.recoveryTicks>0 || e.grabbed) return;
  constexpr int AI_NOATTACK=0x00000004,AI_ALWAYS=0x00000008,AI_LONG=0x00000001,AI_MELEE=0x00000002;
  if((e.model->aiAttack&AI_NOATTACK)!=0)return;
  std::vector<const generated::Animation*> all,projectile,melee;const generated::Character* attackModel=e.equippedWeapon?e.equippedWeapon:e.model;auto collectAttacks=[&](const generated::Character* src){if(!src)return;for(std::size_t i=0;i<src->animationCount;++i){auto* a=&src->animations[i];std::string n=lowerString(a->name?a->name:"");if(n=="attack"||n.rfind("attack",0)==0||n.rfind("shoot",0)==0||n.rfind("throw",0)==0){all.push_back(a);if(animationHasProjectile(a))projectile.push_back(a);else melee.push_back(a);}}};collectAttacks(attackModel);if(all.empty()&&attackModel!=e.model)collectAttacks(e.model);
  if(all.empty())return;const generated::Animation* a=nullptr;bool wantsLong=(e.model->aiAttack&AI_LONG)!=0||targetDistance>(float)config_.enemyAttackRange*1.15f;bool wantsMelee=(e.model->aiAttack&AI_MELEE)!=0;
  auto pick=[&](const std::vector<const generated::Animation*>& list)->const generated::Animation*{if(list.empty())return nullptr;std::size_t idx=(std::size_t)((tickCounter_+(unsigned long long)std::max(0,e.model->aggression))%list.size());return list[idx];};
  if(wantsLong)a=pick(projectile);if(!a&&wantsMelee)a=pick(melee);if(!a)a=pick(all);if(!a)return;
  setEntityAnimation(e,a);e.attackTicks=std::max(8,(int)a->frameCount*6);int aggr=std::clamp(e.model->aggression,0,100);int rest=std::max(2,18-aggr/6);if((e.model->aiAttack&AI_ALWAYS)!=0)rest=2;e.attackCooldown=e.attackTicks+rest;e.attackHasHit=false;e.projectileFired=false;
  if(e.model->onDoAttackScript&&*e.model->onDoAttackScript){e.scriptCtx.local["attack"]=std::string(a->name?a->name:"attack");e.scriptCtx.local["target"]=targetHandle;runModelScript(e.model->onDoAttackScript,e.scriptCtx,"entity-ondoattack");}
}
bool Engine::tryEntityPickupWeapon(RuntimeEntity& e){
  if(!e.alive||!e.model||e.equippedWeapon||!e.model->weapons||e.model->weaponCount==0)return false;RuntimeEntity*best=nullptr;float bestD=1.0e30f;for(auto&it:entities_){if(&it==&e||!it.alive||!it.visible||!it.model)continue;auto typ=lowerString(it.model->type?it.model->type:"");auto sub=lowerString(it.model->subtype?it.model->subtype:"");if(typ!="item"&&sub.find("weapon")==std::string::npos&&sub.find("projectile")==std::string::npos)continue;int wi=it.model->weaponNumber;if(wi<=0||(std::size_t)wi>e.model->weaponCount)continue;std::string expected=e.model->weapons[wi-1]?e.model->weapons[wi-1]:"";if(expected.empty()||lowerString(expected)=="none")continue;float d=std::fabs(it.worldX-e.worldX)+std::fabs(it.z-e.z);if(d<bestD){bestD=d;best=&it;}}if(!best||bestD>180.0f)return false;float dx=best->worldX-e.worldX,dz=best->z-e.z;if(std::fabs(dx)<=20.0f&&std::fabs(dz)<=14.0f){int wi=best->model->weaponNumber;setEntityWeaponIndex(e,wi);e.weaponItemModel=best->model;e.weaponDropsRemaining=best->weaponDropsRemaining>=0?best->weaponDropsRemaining:std::max(0,best->model->weaponDropCounter);best->alive=false;best->visible=false;std::cout<<"AI picked weapon model="<<(best->model->name?best->model->name:"")<<" index="<<wi<<"\n";return true;}float step=std::max(0.5f,e.model->speed);if(std::fabs(dx)>2.0f){e.worldX+=dx>0?step:-step;e.facing=dx<0?-1:1;}if(std::fabs(dz)>2.0f)e.z+=dz>0?std::min(step,1.2f):-std::min(step,1.2f);setEntityAnimation(e,findAnimation(e.model,"walk"));return true;
}
void Engine::updateEntities(){
  for(auto& e:entities_){
    if(!e.visible || !e.model) continue;
    e.scriptCtx.entity=&e; e.scriptCtx.local["self"]=std::uintptr_t((std::uintptr_t)&e); runModelScript(e.model->thinkScript,e.scriptCtx,"entity-think"); runModelScript(e.model->updateScript,e.scriptCtx,"entity-update");
    if(!e.alive){ if(e.deathTicks>0){ --e.deathTicks; e.animation.update(1); } else {e.scriptCtx.local["trigger"]=0.0;runModelScript(e.model?e.model->onKillScript:"",e.scriptCtx,"entity-onkill");e.visible=false;} continue; }
    if(e.grabbed){ e.animation.update(1); continue; }
    updateChildFollowing(e);
    float oldX=e.worldX,oldZ=e.z;
    if(std::fabs(e.scriptVelocityX)>0.0001f)e.worldX+=e.scriptVelocityX;
    if(std::fabs(e.scriptVelocityZ)>0.0001f)e.z+=e.scriptVelocityZ;
    if(e.attackCooldown>0) --e.attackCooldown;
    if(e.fallTicks>0 || e.altitude<0.0f){
      if(e.fallTicks>0) --e.fallTicks; e.altitude+=e.verticalVelocity; e.verticalVelocity+=0.35f;
      if(e.altitude>=0.0f){ e.altitude=0.0f; e.verticalVelocity=0.0f; if(e.fallTicks<=0){e.recoveryTicks=config_.recoveryTicks; auto r=reactionAnimation(e.model,"rise",e.reactionType); if(!r)r=findAnimation(e.model,"rise"); if(r) setEntityAnimation(e,r);} }
      e.animation.update(1);
    } else if(e.recoveryTicks>0){ --e.recoveryTicks; e.animation.update(1); if(e.recoveryTicks==0){e.juggleRemaining=std::max(1,e.model->jugglePoints);setEntityAnimation(e,findAnimation(e.model,"idle"));} }
    else if(e.hitStun>0){ --e.hitStun; e.animation.update(1); if(e.hitStun==0) setEntityAnimation(e,findAnimation(e.model,"idle")); }
    else if(e.attackTicks>0){ maybeSpawnProjectile(e.model,e.animation.animation(),e.animation.frameIndex(),e.worldX,e.z,e.altitude,e.facing,false,e.projectileFired,e.equippedWeapon,&e.weaponUses); if(e.equippedWeapon&&e.equippedWeapon->shootNum>0&&e.weaponUses<=0){if(e.equippedWeapon->typeShot&&e.weaponItemModel)dropEntityWeapon(e);else setEntityWeaponIndex(e,0);} --e.attackTicks; e.animation.update(1); if(e.attackTicks==0) setEntityAnimation(e,findActionAnimation(e.model,e.equippedWeapon,"idle")); }
    else {
      auto entityType=lowerString(e.model->type);
      if(entityType=="obstacle" || entityType=="item" || entityType=="projectile" || entityType=="none" || !config_.enemyAI){ e.animation.update(1); }
      else {
        if(tryEntityPickupWeapon(e)){e.animation.update(1);continue;}
        bool anyTarget=false;float targetX=e.worldX,targetZ=e.z,bestDist=1.0e30f;std::uintptr_t targetHandle=0;
        if(playerAlive_&&modelCanDamage(e.model,playerModel_,true)){float d=std::fabs(playerWorldX_-e.worldX)+std::fabs(playerZ_-e.z);targetX=playerWorldX_;targetZ=playerZ_;bestDist=d;targetHandle=std::uintptr_t(1);anyTarget=true;}
        for(std::size_t ci=0;ci<coopPlayers_.size();++ci){const auto& cp=coopPlayers_[ci];if(!cp.alive||!modelCanDamage(e.model,cp.model,true))continue;float d=std::fabs(cp.worldX-e.worldX)+std::fabs(cp.z-e.z);if(!anyTarget||d<bestDist){targetX=cp.worldX;targetZ=cp.z;bestDist=d;targetHandle=std::uintptr_t(ci+2);anyTarget=true;}}
        if(!anyTarget){e.animation.update(1);}else{
          float dx=targetX-e.worldX,dz=targetZ-e.z,adx=std::fabs(dx),adz=std::fabs(dz);if(dx<0)e.facing=-1;else if(dx>0)e.facing=1;
          constexpr int AI_DODGE=0x00010000,AI_DODGEMOVE=0x00020000,AI_LONG=0x00000001;constexpr int MV_CHASE=1<<1,MV_CHASEZ=1<<2,MV_CHASEX=1<<3,MV_AVOID=1<<4,MV_AVOIDZ=1<<5,MV_AVOIDX=1<<6,MV_WANDER=1<<7,MV_BIKER=1<<8,MV_ARROW=1<<9,MV_STAR=1<<10,MV_BOMB=1<<11,MV_NOMOVE=1<<12;std::string subtype=lowerString(e.model->subtype?e.model->subtype:"");int effectiveMove=e.model->aiMove;if(subtype.find("chase")!=std::string::npos)effectiveMove|=MV_CHASE;if(subtype.find("biker")!=std::string::npos)effectiveMove|=MV_BIKER;if(subtype.find("arrow")!=std::string::npos)effectiveMove|=MV_ARROW;
          bool threat=playerAlive_&&playerAttackTicks_>0&&std::fabs(playerWorldX_-e.worldX)<(float)config_.enemyAttackRange*1.8f;
          if(threat&&(e.model->aiAttack&(AI_DODGE|AI_DODGEMOVE))){auto dodge=findAnimation(e.model,"dodge");if(dodge)setEntityAnimation(e,dodge);float side=(playerZ_<=e.z?1.0f:-1.0f);if((e.model->aiAttack&AI_DODGEMOVE)!=0)e.z+=side*std::max(1.0f,e.model->speed);else e.worldX-=e.facing*std::max(0.5f,e.model->speed*0.5f);e.animation.update(1);}
          else {int move=e.model->aiMove&0xFFFF;float attackRange=(float)config_.enemyAttackRange;if((e.model->aiAttack&AI_LONG)!=0)attackRange*=2.25f;
            if(adx<=attackRange&&adz<=20.0f){startEnemyAttack(e,adx,targetHandle);e.animation.update(1);}
            else if((move&MV_NOMOVE)!=0){e.animation.update(1);}
            else {float step=std::max(0.5f,e.model->speed*(0.55f+(float)std::clamp(e.model->aggression,0,100)/220.0f));float sx=dx>0?step:-step,sz=dz>0?std::min(step,1.5f):-std::min(step,1.5f);
              if((move&MV_WANDER)!=0){int phase=(int)((tickCounter_/90u+(unsigned long long)((std::uintptr_t)&e>>4))%4u);sx=(phase==0?step:phase==1?-step:0.0f);sz=(phase==2?std::min(step,1.2f):phase==3?-std::min(step,1.2f):0.0f);}
              else if((move&MV_AVOID)!=0){sx=-sx;sz=-sz;}else{if((move&MV_AVOIDX)!=0)sx=-sx;if((move&MV_AVOIDZ)!=0)sz=-sz;}
              if((move&MV_CHASEZ)!=0)sx=0.0f;if((move&MV_CHASEX)!=0)sz=0.0f;if((move&(MV_BIKER|MV_ARROW|MV_STAR|MV_BOMB))!=0){sx=(float)e.facing*std::max(step,1.0f);if((move&MV_STAR)!=0)sz=((tickCounter_/30)%2?1.0f:-1.0f)*std::min(step,1.0f);}
              if(adx>3.0f||((move&(MV_WANDER|MV_BIKER|MV_ARROW|MV_STAR|MV_BOMB))!=0))e.worldX+=sx;if(adz>3.0f||((move&(MV_WANDER|MV_STAR))!=0))e.z+=sz;setEntityAnimation(e,findActionAnimation(e.model,e.equippedWeapon,"walk"));e.animation.update(1);}
          }
        }
      }
    }
    if(stage_){float attemptedZ=e.z;e.z=std::clamp(e.z,(float)stage_->zMin,(float)stage_->zMax);if(e.z!=attemptedZ&&e.model->onBlockZScript&&*e.model->onBlockZScript){e.scriptCtx.local["plane"]=1.0;runModelScript(e.model->onBlockZScript,e.scriptCtx,"entity-onblockz");}for(std::size_t gi=0;gi<stage_->geometryCount;++gi){const auto&g=stage_->geometry[gi];std::string gk=lowerString(g.kind?g.kind:"");bool inside=e.worldX>=g.x&&e.worldX<=g.x+g.w&&e.z>=g.z&&e.z<=g.z+g.h;if(gk=="wall"&&inside){float mdx=e.worldX-oldX,mdz=e.z-oldZ;e.worldX=oldX;e.z=oldZ;e.scriptCtx.local["plane"]=(double)(std::fabs(mdx)>=std::fabs(mdz)?0:1);e.scriptCtx.local["index"]=(double)gi;e.scriptCtx.local["height"]=(double)g.w;e.scriptCtx.local["depth"]=(double)g.h;e.scriptCtx.local["type"]=std::string("wall");runModelScript(e.model->onBlockWScript,e.scriptCtx,"entity-onblockw");runModelScript(e.model->onBlockOScript,e.scriptCtx,"entity-onblocko");}
      else if(gk=="hole"&&inside&&(e.model->aiMove&0x00010000)==0&&e.altitude>=-0.1f){e.worldX=oldX;e.z=oldZ;e.facing=-e.facing;e.scriptCtx.local["type"]=std::string("hole");runModelScript(e.model->onBlockOScript,e.scriptCtx,"entity-hole-avoid");}}}
    if(std::fabs(e.worldX-oldX)>0.001f&&e.model->onMoveXScript&&*e.model->onMoveXScript){e.scriptCtx.local["movex"]=(double)(e.worldX-oldX);runModelScript(e.model->onMoveXScript,e.scriptCtx,"entity-onmovex");}
    if(std::fabs(e.z-oldZ)>0.001f&&e.model->onMoveZScript&&*e.model->onMoveZScript){e.scriptCtx.local["movez"]=(double)(e.z-oldZ);runModelScript(e.model->onMoveZScript,e.scriptCtx,"entity-onmovez");}
  }
}
void Engine::updateProjectiles(){
  for(auto& p:projectiles_){
    if(!p.alive||!p.model)continue;if(--p.life<=0){p.alive=false;continue;}
    p.worldX+=p.vx;p.z+=p.vz;p.altitude+=p.vy;if(p.subjectToGravity&&!p.exploded)p.vy+=config_.gravity;
    if(p.subjectToGravity&&p.altitude>=0.0f&&!p.exploded){
      if(p.bouncesLeft>0&&std::fabs(p.vy)>0.05f){p.altitude=-0.1f;p.vy=-std::fabs(p.vy)*std::clamp(p.bounceFactor,0.05f,1.5f);--p.bouncesLeft;std::cout<<"Projectile bounce: "<<p.model->name<<" left="<<p.bouncesLeft<<"\n";}
      else if(p.bomb){p.altitude=0;p.vx=p.vz=p.vy=0;p.exploded=true;p.life=24;auto boom=findAnimation(p.model,"attack1");if(boom)p.animation.setAnimation(boom);std::cout<<"Bomb landed: "<<p.model->name<<"\n";}
      else {p.alive=false;continue;}
    }
    p.animation.update(1);float half=(float)std::max(160,config_.logicalWidth)/2.0f;if(p.worldX<cameraX_-half||p.worldX>cameraX_+(float)config_.logicalWidth+half)p.alive=false;
  }
  projectiles_.erase(std::remove_if(projectiles_.begin(),projectiles_.end(),[](const RuntimeProjectile& p){return !p.alive;}),projectiles_.end());
}
Engine::RectF Engine::bboxFor(const generated::Frame* f,float worldX,float worldY,int facing) const{
  if(!f) return {worldX-10,worldY-28,20,28}; if(!f->hasBBox) return {worldX-10,worldY-28,20,28}; float x=facing>=0?worldX-f->offsetX+f->bbox.x:worldX+f->offsetX-f->bbox.x-f->bbox.w; return {x,worldY-f->offsetY+f->bbox.y,(float)f->bbox.w,(float)f->bbox.h};
}
Engine::RectF Engine::attackFor(const generated::Frame* f,float worldX,float worldY,int facing) const{
  if(!f || !f->hasAttack) return {}; float x=facing>=0?worldX-f->offsetX+f->attack.x:worldX+f->offsetX-f->attack.x-f->attack.w; return {x,worldY-f->offsetY+f->attack.y,(float)f->attack.w,(float)f->attack.h};
}
bool Engine::overlaps(const RectF& a,const RectF& b){ return a.w>0&&a.h>0&&b.w>0&&b.h>0&&a.x<b.x+b.w&&a.x+a.w>b.x&&a.y<b.y+b.h&&a.y+a.h>b.y; }
void Engine::tryGrabNearest(){
  if(grabbedEntity_>=0 || !playerAlive_ || playerAttackTicks_>0) return; float best=(float)std::max(config_.grabRange,playerModel_?playerModel_->grabDistance:30); int found=-1;
  for(std::size_t i=0;i<entities_.size();++i){auto& e=entities_[i];if(!e.alive||e.grabbed||e.fallTicks>0||!e.model||lowerString(e.model->type)!="enemy"||e.model->noGrab)continue;int force=playerModel_?playerModel_->grabForce:0;if(e.model->grabResistance>0&&force<=e.model->grabResistance)continue;float dx=std::fabs(e.worldX-playerWorldX_),dz=std::fabs(e.z-playerZ_);if(dx<=best&&dz<=16.0f){best=dx;found=(int)i;}}
  if(found<0)return; grabbedEntity_=found;grabHoldTicks_=0;auto& e=entities_[(std::size_t)found];e.grabbed=true;e.attackTicks=0;e.hitStun=0;playerFacing_=e.worldX>=playerWorldX_?1:-1;
  if(auto g=findAnimation(playerModel_,"grab"))player_.setAnimation(g);if(auto g=findAnimation(e.model,"grabbed"))setEntityAnimation(e,g);std::cout<<"Grabbed enemy "<<(e.spawn?e.spawn->model:e.model->name)<<"\n";
}
void Engine::throwGrabbed(){
  if(grabbedEntity_<0||(std::size_t)grabbedEntity_>=entities_.size())return;auto& e=entities_[(std::size_t)grabbedEntity_];e.grabbed=false;e.worldX=playerWorldX_+(float)(playerFacing_*18);grabbedEntity_=-1;grabHoldTicks_=0;++playerAttackId_;
  if(auto t=findAnimation(playerModel_,"throw")){player_.setAnimation(t);lastFrame_=(std::size_t)-1;}int td=playerModel_&&playerModel_->throwDamage>0?playerModel_->throwDamage:config_.throwDamage;float dist=playerModel_&&playerModel_->throwDistance>0.0f?playerModel_->throwDistance:18.0f;int drop=playerModel_&&playerModel_->throwHeight>0.0f?-(int)std::round(playerModel_->throwHeight):-5;e.worldX=playerWorldX_+(float)playerFacing_*dist;damageEnemy(e,td,(float)playerFacing_,true,drop,0,std::uintptr_t(1));std::cout<<"Throw executed damage="<<td<<" distance="<<dist<<"\n";
}
void Engine::playFrameSound(const generated::Frame* f){
  if(!f||!f->sound||!*f->sound)return;std::string snd=f->sound;bool file=snd.find('/')!=std::string::npos||snd.find('\\')!=std::string::npos||snd.find('.')!=std::string::npos;if(!file)return;auto path=resolveAudioAsset(root_/"assets"/"openbor-data",snd);if(std::filesystem::exists(path)&&!audio_.playEffect(path))std::cerr<<"Frame sound diagnostic: "<<audio_.lastError()<<"\n";
}
bool Engine::tryBlockEntity(RuntimeEntity& e,const generated::Frame& atk,std::uintptr_t attacker){
  if(!e.alive||!e.model||!atk.hasAttack)return false;auto*m=e.model;auto block=findAnimation(m,"block");if(!block)return false;
  constexpr int BS_ACTIVE=1,BS_NATIVE=2,BS_IGNORE_CHANCE=4,BS_IGNORE_GUARD=8,BS_IGNORE_DIR=16,BS_IGNORE_ELIG=32,BS_IGNORE_BLOCKPAIN=64;
  bool forced=(e.blockState&BS_ACTIVE)!=0;bool native=forced||(e.blockState&BS_NATIVE)!=0||m->blockOdds>=0;if(!native)return false;
  if(!(e.blockState&BS_IGNORE_ELIG)&&atk.attack.penetration>std::max(0,m->blockThreshold))return false;
  float ax=e.worldX;int ps=(attacker>=1&&attacker<=4)?(int)attacker-1:-1;if(ps==0)ax=playerWorldX_;else if(ps>0&&(std::size_t)(ps-1)<coopPlayers_.size())ax=coopPlayers_[(std::size_t)(ps-1)].worldX;else for(auto&other:entities_)if((std::uintptr_t)&other==attacker){ax=other.worldX;break;}
  bool facingAttack=(ax<e.worldX&&e.facing<0)||(ax>e.worldX&&e.facing>0);if(!m->blockBack&&!(e.blockState&BS_IGNORE_DIR)&&!facingAttack)return false;
  if(!forced&&!(e.blockState&BS_IGNORE_CHANCE)){static std::mt19937 brng{0xB10C2026u};int odds=std::max(0,m->blockOdds);if(((int)brng()&odds)!=0)return false;}
  if(m->guardPoints>0&&!(e.blockState&BS_IGNORE_GUARD)&&e.guardPoints<=0){if(auto gb=findAnimation(m,"guardbreak"))setEntityAnimation(e,gb);return false;}
  int cost=std::max(0,atk.attack.guardCost);if(m->guardPoints>0&&!(e.blockState&BS_IGNORE_GUARD))e.guardPoints=std::max(0,e.guardPoints-cost);
  const generated::Animation* react=block;if(!(e.blockState&BS_IGNORE_BLOCKPAIN)&&m->blockPain>0&&atk.attack.damage>=m->blockPain){react=reactionAnimation(m,"blockpain",atk.attack.type);if(!react)react=block;}setEntityAnimation(e,react);e.blocking=true;e.hitStun=std::max(2,atk.attack.pauseTime);
  e.scriptCtx.local["attacker"]=attacker;e.scriptCtx.local["damage"]=(double)atk.attack.damage;e.scriptCtx.local["attacktype"]=(double)atk.attack.type;e.scriptCtx.local["drop"]=atk.knockdown;e.scriptCtx.local["noblock"]=(double)atk.attack.penetration;e.scriptCtx.local["guardcost"]=(double)cost;e.scriptCtx.local["jugglecost"]=(double)atk.attack.juggleCost;e.scriptCtx.local["pauseadd"]=(double)atk.attack.pauseTime;e.scriptCtx.local["tag"]=(double)atk.attack.tag;runModelScript(m->didBlockScript,e.scriptCtx,"entity-didblock");return true;
}
bool Engine::tryBlockPlayer(int slot,const generated::Frame& atk,std::uintptr_t attacker){
  auto*m=slot==0?playerModel_:((std::size_t)(slot-1)<coopPlayers_.size()?coopPlayers_[(std::size_t)(slot-1)].model:nullptr);if(!m||!atk.hasAttack||!findAnimation(m,"block"))return false;constexpr int BS_ACTIVE=1,BS_IGNORE_GUARD=8,BS_IGNORE_DIR=16,BS_IGNORE_ELIG=32,BS_IGNORE_BLOCKPAIN=64;int&state=slot==0?playerBlockState_:coopPlayers_[(std::size_t)(slot-1)].blockState;int&guard=slot==0?playerGuardPoints_:coopPlayers_[(std::size_t)(slot-1)].guardPoints;std::string currentAnim;if(slot==0&&player_.animation()&&player_.animation()->name)currentAnim=player_.animation()->name;else if(slot>0){auto&cp=coopPlayers_[(std::size_t)(slot-1)];if(cp.animation.animation()&&cp.animation.animation()->name)currentAnim=cp.animation.animation()->name;}bool animBlock=lowerString(currentAnim).rfind("block",0)==0;if(!(state&BS_ACTIVE)&&!animBlock)return false;if(!(state&BS_IGNORE_ELIG)&&atk.attack.penetration>std::max(0,m->blockThreshold))return false;
  float px=slot==0?playerWorldX_:coopPlayers_[(std::size_t)(slot-1)].worldX;int face=slot==0?playerFacing_:coopPlayers_[(std::size_t)(slot-1)].facing;float ax=px;for(auto&other:entities_)if((std::uintptr_t)&other==attacker){ax=other.worldX;break;}bool facingAttack=(ax<px&&face<0)||(ax>px&&face>0);if(!m->blockBack&&!(state&BS_IGNORE_DIR)&&!facingAttack)return false;if(m->guardPoints>0&&!(state&BS_IGNORE_GUARD)&&guard<=0)return false;int cost=std::max(0,atk.attack.guardCost);if(m->guardPoints>0&&!(state&BS_IGNORE_GUARD))guard=std::max(0,guard-cost);
  auto react=findAnimation(m,"block");if(!(state&BS_IGNORE_BLOCKPAIN)&&m->blockPain>0&&atk.attack.damage>=m->blockPain){if(auto bp=reactionAnimation(m,"blockpain",atk.attack.type))react=bp;}if(slot==0){player_.setAnimation(react);lastFrame_=(std::size_t)-1;playerBlocking_=true;playerHitStun_=std::max(2,atk.attack.pauseTime);playerScriptCtx_.local["attacker"]=attacker;playerScriptCtx_.local["damage"]=(double)atk.attack.damage;playerScriptCtx_.local["attacktype"]=(double)atk.attack.type;playerScriptCtx_.local["drop"]=atk.knockdown;playerScriptCtx_.local["noblock"]=(double)atk.attack.penetration;playerScriptCtx_.local["guardcost"]=(double)cost;playerScriptCtx_.local["jugglecost"]=(double)atk.attack.juggleCost;playerScriptCtx_.local["pauseadd"]=(double)atk.attack.pauseTime;playerScriptCtx_.local["tag"]=(double)atk.attack.tag;runModelScript(m->didBlockScript,playerScriptCtx_,"player-didblock");}else{auto&cp=coopPlayers_[(std::size_t)(slot-1)];cp.animation.setAnimation(react);cp.lastFrame=(std::size_t)-1;cp.blocking=true;cp.hitStun=std::max(2,atk.attack.pauseTime);cp.scriptCtx.local["attacker"]=attacker;cp.scriptCtx.local["damage"]=(double)atk.attack.damage;cp.scriptCtx.local["attacktype"]=(double)atk.attack.type;cp.scriptCtx.local["guardcost"]=(double)cost;runModelScript(m->didBlockScript,cp.scriptCtx,"coop-didblock");}return true;
}
void Engine::damageEnemy(RuntimeEntity& e,int damage,float knockDirection,bool knockdown,int dropVy,int attackType,std::uintptr_t attacker){
  if(!e.alive)return; const generated::Character* activeWeapon=e.equippedWeapon;const generated::Character* lossSpec=activeWeapon?(activeWeapon->weaponLossDefined?activeWeapon:e.model):nullptr;if(activeWeapon&&lossSpec&&(lossSpec->weaponLossFlag==0||(knockdown&&(lossSpec->weaponLossFlag==1||activeWeapon->animalWeapon))))dropEntityWeapon(e); e.scriptCtx.entity=&e; e.scriptCtx.local["self"]=std::uintptr_t((std::uintptr_t)&e); e.scriptCtx.local["attacker"]=attacker; e.scriptCtx.local["damage"]=double(damage);e.scriptCtx.local["attacktype"]=(double)attackType;e.scriptCtx.local["drop"]=knockdown;e.scriptCtx.local["noblock"]=0.0;e.scriptCtx.local["guardcost"]=0.0;e.scriptCtx.local["jugglecost"]=0.0;e.scriptCtx.local["pauseadd"]=0.0; runModelScript(e.model?e.model->takeDamageScript:"",e.scriptCtx,"entity-takedamage");e.health=std::max(0,e.health-std::max(1,damage));e.worldX=std::max(0.0f,e.worldX+knockDirection*(float)config_.knockback);std::cout<<"Hit enemy "<<(e.spawn?e.spawn->model:e.model->name)<<" damage="<<damage<<" hp="<<e.health<<"/"<<e.maxHealth<<(knockdown?" knockdown":"")<<"\n";
  if(e.health<=0){if(activeWeapon&&lossSpec&&lossSpec->weaponLossFlag==2)dropEntityWeapon(e);if(e.model&&e.model->summonKill>0)unsummonChildren((std::uintptr_t)&e,e.model->summonKill>=2);runModelScript(e.model?e.model->onDeathScript:"",e.scriptCtx,"entity-ondeath");e.alive=false;e.grabbed=false;e.deathTicks=30;auto d=findAnimation(e.model,"death");if(!d)d=findAnimation(e.model,"fall");setEntityAnimation(e,d);auto kind=lowerString(e.model?e.model->type:"");std::cout<<(kind=="obstacle"?"Object destroyed: ":"Enemy defeated: ")<<(e.spawn?e.spawn->model:e.model->name)<<"\n";}
  else if(knockdown){runModelScript(e.model?e.model->onFallScript:"",e.scriptCtx,"entity-onfall");e.reactionType=attackType;e.fallTicks=config_.fallTicks;e.altitude=-1.0f;e.verticalVelocity=(float)dropVy;e.juggleRemaining=std::max(1,e.model?e.model->jugglePoints:4);auto f=reactionAnimation(e.model,"fall",attackType);if(!f)f=findAnimation(e.model,"fall");if(f)setEntityAnimation(e,f);}
  else{runModelScript(e.model?e.model->onPainScript:"",e.scriptCtx,"entity-onpain");e.reactionType=attackType;e.hitStun=8;auto pain=reactionAnimation(e.model,"pain",attackType);if(!pain)pain=findAnimation(e.model,"pain");setEntityAnimation(e,pain);}
}
void Engine::damagePlayer(int damage,float knockDirection,bool knockdown,int dropVy,int attackType,std::uintptr_t attacker){
  if(playerModel_){playerScriptCtx_.local["attacker"]=attacker;playerScriptCtx_.local["damage"]=double(damage);playerScriptCtx_.local["attacktype"]=(double)attackType;playerScriptCtx_.local["drop"]=knockdown;playerScriptCtx_.local["noblock"]=0.0;playerScriptCtx_.local["guardcost"]=0.0;playerScriptCtx_.local["jugglecost"]=0.0;playerScriptCtx_.local["pauseadd"]=0.0;runModelScript(playerModel_->takeDamageScript,playerScriptCtx_,"player-takedamage");}
  if(!playerAlive_||playerHitStun_>0||playerFallTicks_>0)return;const generated::Character*activeWeapon=equippedWeapon_;const generated::Character*lossSpec=activeWeapon?(activeWeapon->weaponLossDefined?activeWeapon:playerModel_):nullptr;if(activeWeapon&&lossSpec&&(lossSpec->weaponLossFlag==0||(knockdown&&(lossSpec->weaponLossFlag==1||activeWeapon->animalWeapon))))dropPlayerWeapon();playerHealth_=std::max(0,playerHealth_-std::max(1,damage));playerWorldX_=std::clamp(playerWorldX_+knockDirection*(float)config_.knockback,0.0f,std::max(0.0f,stageLength_-1.0f));std::cout<<"Player hit damage="<<damage<<" hp="<<playerHealth_<<"/"<<playerMaxHealth_<<(knockdown?" knockdown":"")<<"\n";
  if(playerHealth_<=0){if(activeWeapon&&lossSpec&&lossSpec->weaponLossFlag==2)dropPlayerWeapon();if(playerModel_&&playerModel_->summonKill>0)unsummonChildren(std::uintptr_t(1),playerModel_->summonKill>=2);if(playerModel_)runModelScript(playerModel_->onDeathScript,playerScriptCtx_,"player-ondeath");playerAlive_=false;auto d=findAnimation(playerModel_,"death");if(!d)d=findAnimation(playerModel_,"fall");player_.setAnimation(d);lastFrame_=(std::size_t)-1;std::cout<<"GAME OVER\n";}
  else if(knockdown){if(playerModel_)runModelScript(playerModel_->onFallScript,playerScriptCtx_,"player-onfall");playerReactionType_=attackType;playerFallTicks_=config_.fallTicks;playerAltitude_=-1.0f;playerVerticalVelocity_=(float)dropVy;auto f=reactionAnimation(playerModel_,"fall",attackType);if(!f)f=findAnimation(playerModel_,"fall");if(f)player_.setAnimation(f);lastFrame_=(std::size_t)-1;}
  else{if(playerModel_)runModelScript(playerModel_->onPainScript,playerScriptCtx_,"player-onpain");playerReactionType_=attackType;playerHitStun_=10;auto pain=reactionAnimation(playerModel_,"pain",attackType);if(!pain)pain=findAnimation(playerModel_,"pain");player_.setAnimation(pain);lastFrame_=(std::size_t)-1;}
}
void Engine::damageCoopPlayer(RuntimeCoopPlayer& cp,int damage,float knockDirection,bool knockdown,int dropVy,int attackType,std::uintptr_t attacker){
  if(cp.model){cp.scriptCtx.local["attacker"]=attacker;cp.scriptCtx.local["damage"]=(double)damage;cp.scriptCtx.local["attacktype"]=(double)attackType;cp.scriptCtx.local["drop"]=knockdown;cp.scriptCtx.local["noblock"]=0.0;cp.scriptCtx.local["guardcost"]=0.0;cp.scriptCtx.local["jugglecost"]=0.0;cp.scriptCtx.local["pauseadd"]=0.0;runModelScript(cp.model->takeDamageScript,cp.scriptCtx,"coop-takedamage");}
  if(!cp.alive||cp.hitStun>0)return;const generated::Character*activeWeapon=cp.equippedWeapon;const generated::Character*lossSpec=activeWeapon?(activeWeapon->weaponLossDefined?activeWeapon:cp.model):nullptr;if(activeWeapon&&lossSpec&&(lossSpec->weaponLossFlag==0||(knockdown&&(lossSpec->weaponLossFlag==1||activeWeapon->animalWeapon))))dropCoopWeapon(cp);cp.health=std::max(0,cp.health-std::max(1,damage));cp.worldX=std::max(0.0f,cp.worldX+knockDirection*(float)config_.knockback);cp.reactionType=attackType;std::cout<<"Coop player hit damage="<<damage<<" hp="<<cp.health<<"/"<<cp.maxHealth<<"\n";if(cp.health<=0){if(activeWeapon&&lossSpec&&lossSpec->weaponLossFlag==2)dropCoopWeapon(cp);if(cp.model&&cp.model->summonKill>0)unsummonChildren(std::uintptr_t((&cp-&coopPlayers_[0])+2),cp.model->summonKill>=2);if(cp.model)runModelScript(cp.model->onDeathScript,cp.scriptCtx,"coop-ondeath");cp.alive=false;auto d=findAnimation(cp.model,"death");if(!d)d=findAnimation(cp.model,"fall");cp.animation.setAnimation(d);cp.lastFrame=(std::size_t)-1;}else{if(cp.model)runModelScript(knockdown?cp.model->onFallScript:cp.model->onPainScript,cp.scriptCtx,knockdown?"coop-onfall":"coop-onpain");cp.hitStun=10;auto p=reactionAnimation(cp.model,knockdown?"fall":"pain",attackType);if(!p)p=findAnimation(cp.model,knockdown?"fall":"pain");if(p)cp.animation.setAnimation(p);if(knockdown){cp.jumping=true;cp.altitude=-1.0f;cp.verticalVelocity=(float)dropVy;}cp.lastFrame=(std::size_t)-1;}
}
void Engine::resolveCombat(){
  auto pf=player_.frame();RectF playerBox=bboxFor(pf,playerWorldX_,playerZ_+playerAltitude_,playerFacing_);
  auto activatePlayerFollow=[&](const generated::Animation* source){auto*f=followAnimationFor(playerModel_,source);if(!f)return false;player_.setAnimation(f);lastFrame_=(std::size_t)-1;playerAttackTicks_=std::max(8,(int)f->frameCount*6);playerAttackCooldown_=std::max(2,playerAttackTicks_/3);playerComboWindow_=0;playerQueuedAttack_=false;playerProjectileFired_=false;playerAttackHasHit_=false;playerAttackHits_=0;++playerAttackId_;return true;};
  auto activateCoopFollow=[&](RuntimeCoopPlayer&cp,const generated::Animation* source){auto*f=followAnimationFor(cp.model,source);if(!f)return false;cp.animation.setAnimation(f);cp.lastFrame=(std::size_t)-1;cp.attackTicks=std::max(8,(int)f->frameCount*6);cp.attackCooldown=std::max(2,cp.attackTicks/3);cp.comboWindow=0;cp.projectileFired=false;cp.attackHasHit=false;cp.attackHits=0;++cp.attackId;return true;};
  auto activateEntityFollow=[&](RuntimeEntity&e,const generated::Animation* source){auto*f=followAnimationFor(e.model,source);if(!f)return false;setEntityAnimation(e,f);e.hitStun=e.fallTicks=e.recoveryTicks=0;e.attackTicks=std::max(8,(int)f->frameCount*6);e.attackCooldown=std::max(2,e.attackTicks/3);e.projectileFired=false;e.attackHasHit=false;e.attackHits=0;return true;};
  auto activateEntityCounter=[&](RuntimeEntity&e,const CounterResult&cr){if(!cr.animation||!e.alive)return;setEntityAnimation(e,cr.animation);e.hitStun=e.fallTicks=e.recoveryTicks=0;e.attackTicks=std::max(8,(int)cr.animation->frameCount*6);e.attackCooldown=std::max(2,e.attackTicks/3);e.projectileFired=false;e.attackHasHit=false;e.attackHits=0;};
  auto activatePlayerCounter=[&](const CounterResult&cr){if(!cr.animation||!playerAlive_)return;player_.setAnimation(cr.animation);lastFrame_=(std::size_t)-1;playerHitStun_=playerFallTicks_=playerRecoveryTicks_=0;playerAttackTicks_=std::max(8,(int)cr.animation->frameCount*6);playerAttackCooldown_=std::max(2,playerAttackTicks_/3);playerProjectileFired_=false;playerAttackHasHit_=false;playerAttackHits_=0;playerQueuedAttack_=false;++playerAttackId_;};
  auto activateCoopCounter=[&](RuntimeCoopPlayer&cp,const CounterResult&cr){if(!cr.animation||!cp.alive)return;cp.animation.setAnimation(cr.animation);cp.lastFrame=(std::size_t)-1;cp.hitStun=0;cp.attackTicks=std::max(8,(int)cr.animation->frameCount*6);cp.attackCooldown=std::max(2,cp.attackTicks/3);cp.projectileFired=false;cp.attackHasHit=false;cp.attackHits=0;++cp.attackId;};
  for(auto& e:entities_){if(!e.alive||!e.model||!e.model->onEntityCollisionScript||!*e.model->onEntityCollisionScript)continue;if(overlaps(playerBox,bboxFor(e.animation.frame(),e.worldX,e.z+e.altitude,e.facing))){e.scriptCtx.local["other"]=std::uintptr_t(1);e.scriptCtx.other=reinterpret_cast<void*>(std::uintptr_t(1));runModelScript(e.model->onEntityCollisionScript,e.scriptCtx,"entity-collision-player");if(playerModel_&&playerModel_->onEntityCollisionScript&&*playerModel_->onEntityCollisionScript){playerScriptCtx_.local["other"]=std::uintptr_t((std::uintptr_t)&e);playerScriptCtx_.other=&e;runModelScript(playerModel_->onEntityCollisionScript,playerScriptCtx_,"player-collision-entity");}}}
  if(playerAlive_&&playerAttackTicks_>0&&pf&&pf->hasAttack){const generated::Animation* sourceAnim=player_.animation();RectF atk=attackFor(pf,playerWorldX_,playerZ_+playerAltitude_,playerFacing_);int damage=std::max(1,pf->attack.damage);for(auto& e:entities_){if(!e.alive||e.grabbed||!e.model||e.lastPlayerAttackId==playerAttackId_)continue;auto t=lowerString(e.model->type);if(t=="item"||t=="projectile"||t=="none")continue;if(!modelCanDamage(playerModel_,e.model,t=="enemy"||t=="obstacle"))continue;if((e.fallTicks>0||e.altitude<0.0f)&&e.juggleRemaining<=0)continue;auto ef=e.animation.frame();if(!overlaps(atk,bboxFor(ef,e.worldX,e.z+e.altitude,e.facing)))continue;e.lastPlayerAttackId=playerAttackId_;if(e.fallTicks>0||e.altitude<0.0f)--e.juggleRemaining;bool hostile=t=="enemy";bool fromFront=(playerWorldX_<e.worldX&&e.facing<0)||(playerWorldX_>e.worldX&&e.facing>0);CounterResult cr=counterFor(e.model,e.animation.animation(),e.animation.frameIndex(),hostile,pf->attack.penetration>0,fromFront,e.health,damage);bool blocked=false;bool kd=pf->knockdown||pf->attack.type>=2;if(cr.animation){if(cr.takesDamage){int dealt=damage;if(cr.rage&&damage>=e.health)dealt=std::max(0,e.health-1);if(dealt>0)damageEnemy(e,dealt,(float)playerFacing_,false,pf->dropVy,pf->attack.type,std::uintptr_t(1));}activateEntityCounter(e,cr);}else{blocked=tryBlockEntity(e,*pf,std::uintptr_t(1));if(!blocked)damageEnemy(e,damage,(float)playerFacing_,kd,pf->dropVy,pf->attack.type,std::uintptr_t(1));}bool lethal=!e.alive;playerAttackHasHit_=true;++playerAttackHits_;if(playerModel_){playerScriptCtx_.local["damagetaker"]=std::uintptr_t((std::uintptr_t)&e);playerScriptCtx_.local["damage"]=(double)damage;playerScriptCtx_.local["drop"]=kd;playerScriptCtx_.local["attacktype"]=(double)pf->attack.type;playerScriptCtx_.local["blocked"]=blocked;runModelScript(playerModel_->didHitScript,playerScriptCtx_,"player-didhit");}if(sourceAnim&&followConditionPass(sourceAnim->followCond,blocked,hostile,lethal,e.model->noGrab)&&activatePlayerFollow(sourceAnim))break;}}
  for(std::size_t pi=0;pi<coopPlayers_.size();++pi){auto& cp=coopPlayers_[pi];auto f=cp.animation.frame();if(!cp.alive||cp.attackTicks<=0||!f||!f->hasAttack)continue;const generated::Animation* sourceAnim=cp.animation.animation();unsigned id=(unsigned)((pi+2)*1000000u)+(cp.attackId%1000000u);RectF atk=attackFor(f,cp.worldX,cp.z+cp.altitude,cp.facing);for(auto& e:entities_){if(!e.alive||e.grabbed||!e.model||e.lastPlayerAttackId==id)continue;auto t=lowerString(e.model->type);if(t=="item"||t=="projectile"||t=="none")continue;if(!modelCanDamage(cp.model,e.model,t=="enemy"||t=="obstacle"))continue;if(!overlaps(atk,bboxFor(e.animation.frame(),e.worldX,e.z+e.altitude,e.facing)))continue;e.lastPlayerAttackId=id;std::cout<<"P"<<(pi+2)<<" hit "<<(e.model?e.model->name:"enemy")<<"\n";int damage=std::max(1,f->attack.damage);bool hostile=t=="enemy";bool fromFront=(cp.worldX<e.worldX&&e.facing<0)||(cp.worldX>e.worldX&&e.facing>0);CounterResult cr=counterFor(e.model,e.animation.animation(),e.animation.frameIndex(),hostile,f->attack.penetration>0,fromFront,e.health,damage);bool blocked=false;bool kd=f->knockdown||f->attack.type>=2;if(cr.animation){if(cr.takesDamage){int dealt=damage;if(cr.rage&&damage>=e.health)dealt=std::max(0,e.health-1);if(dealt>0)damageEnemy(e,dealt,(float)cp.facing,false,f->dropVy,f->attack.type,std::uintptr_t(pi+2));}activateEntityCounter(e,cr);}else{blocked=tryBlockEntity(e,*f,std::uintptr_t(pi+2));if(!blocked)damageEnemy(e,damage,(float)cp.facing,kd,f->dropVy,f->attack.type,std::uintptr_t(pi+2));}cp.scriptCtx.local["damagetaker"]=std::uintptr_t((std::uintptr_t)&e);cp.scriptCtx.local["blocked"]=blocked;runModelScript(cp.model?cp.model->didHitScript:"",cp.scriptCtx,"coop-didhit");cp.attackHasHit=true;++cp.attackHits;bool lethal=!e.alive;if(sourceAnim&&followConditionPass(sourceAnim->followCond,blocked,hostile,lethal,e.model->noGrab)&&activateCoopFollow(cp,sourceAnim))break;}}
  for(auto& e:entities_){if(!e.alive||e.grabbed||!e.model||e.attackTicks<=0||e.attackHasHit||lowerString(e.model->type)!="enemy")continue;auto ef=e.animation.frame();if(!ef||!ef->hasAttack)continue;const generated::Animation* sourceAnim=e.animation.animation();RectF atk=attackFor(ef,e.worldX,e.z+e.altitude,e.facing);int dmg=std::max(1,ef->attack.damage);bool kd=ef->knockdown||ef->attack.type>=2;if(playerAlive_&&modelCanDamage(e.model,playerModel_,true)&&overlaps(atk,playerBox)){e.attackHasHit=true;++e.attackHits;bool fromFront=(e.worldX<playerWorldX_&&playerFacing_<0)||(e.worldX>playerWorldX_&&playerFacing_>0);CounterResult cr=counterFor(playerModel_,player_.animation(),player_.frameIndex(),true,ef->attack.penetration>0,fromFront,playerHealth_,dmg);bool blocked=false;if(cr.animation){if(cr.takesDamage){int dealt=dmg;if(cr.rage&&dmg>=playerHealth_)dealt=std::max(0,playerHealth_-1);if(dealt>0)damagePlayer(dealt,(float)e.facing,false,ef->dropVy,ef->attack.type,std::uintptr_t((std::uintptr_t)&e));}activatePlayerCounter(cr);}else{blocked=tryBlockPlayer(0,*ef,std::uintptr_t((std::uintptr_t)&e));if(!blocked)damagePlayer(dmg,(float)e.facing,kd,ef->dropVy,ef->attack.type,std::uintptr_t((std::uintptr_t)&e));}e.scriptCtx.local["damagetaker"]=std::uintptr_t(1);e.scriptCtx.local["damage"]=(double)dmg;e.scriptCtx.local["drop"]=kd;e.scriptCtx.local["attacktype"]=(double)ef->attack.type;e.scriptCtx.local["blocked"]=blocked;runModelScript(e.model->didHitScript,e.scriptCtx,"entity-didhit");bool lethal=!playerAlive_;if(sourceAnim&&followConditionPass(sourceAnim->followCond,blocked,true,lethal,playerModel_?playerModel_->noGrab:false))activateEntityFollow(e,sourceAnim);continue;}for(std::size_t ci=0;ci<coopPlayers_.size();++ci){auto&cp=coopPlayers_[ci];if(!cp.alive||!modelCanDamage(e.model,cp.model,true)||!overlaps(atk,bboxFor(cp.animation.frame(),cp.worldX,cp.z+cp.altitude,cp.facing)))continue;e.attackHasHit=true;++e.attackHits;bool fromFront=(e.worldX<cp.worldX&&cp.facing<0)||(e.worldX>cp.worldX&&cp.facing>0);CounterResult cr=counterFor(cp.model,cp.animation.animation(),cp.animation.frameIndex(),true,ef->attack.penetration>0,fromFront,cp.health,dmg);bool blocked=false;if(cr.animation){if(cr.takesDamage){int dealt=dmg;if(cr.rage&&dmg>=cp.health)dealt=std::max(0,cp.health-1);if(dealt>0)damageCoopPlayer(cp,dealt,(float)e.facing,false,ef->dropVy,ef->attack.type,std::uintptr_t((std::uintptr_t)&e));}activateCoopCounter(cp,cr);}else{blocked=tryBlockPlayer((int)ci+1,*ef,std::uintptr_t((std::uintptr_t)&e));if(!blocked)damageCoopPlayer(cp,dmg,(float)e.facing,kd,ef->dropVy,ef->attack.type,std::uintptr_t((std::uintptr_t)&e));}e.scriptCtx.local["damagetaker"]=std::uintptr_t(ci+2);e.scriptCtx.local["damage"]=(double)dmg;e.scriptCtx.local["drop"]=kd;e.scriptCtx.local["attacktype"]=(double)ef->attack.type;e.scriptCtx.local["blocked"]=blocked;runModelScript(e.model->didHitScript,e.scriptCtx,"entity-didhit");bool lethal=!cp.alive;if(sourceAnim&&followConditionPass(sourceAnim->followCond,blocked,true,lethal,cp.model?cp.model->noGrab:false))activateEntityFollow(e,sourceAnim);break;}}
  for(auto& p:projectiles_){if(!p.alive||!p.model)continue;auto f=p.animation.frame();if(!f)continue;RectF atk=f->hasAttack?attackFor(f,p.worldX,p.z+p.altitude,p.facing):bboxFor(f,p.worldX,p.z+p.altitude,p.facing);int damage=f->hasAttack?std::max(1,f->attack.damage):1;
    auto targetAllowed=[&](const generated::Character* target,bool legacy){int bit=openborTypeBit(target);if(p.hitMask!=0)return bit!=0&&(p.hitMask&bit)!=0;return modelCanDamage(p.model,target,legacy);};
    for(auto& e:entities_){if(!p.alive)break;if(!e.alive||!e.model||e.model==p.model&&lowerString(e.model->type)=="projectile")continue;auto t=lowerString(e.model->type);bool legacy=p.fromPlayer&&(t=="enemy"||t=="obstacle");if(!targetAllowed(e.model,legacy))continue;if(overlaps(atk,bboxFor(e.animation.frame(),e.worldX,e.z+e.altitude,e.facing))){damageEnemy(e,damage,(float)p.facing,f->knockdown||f->attack.type>=2,f->dropVy,f->attack.type,p.fromPlayer?std::uintptr_t(1):std::uintptr_t(0));p.alive=false;std::cout<<"Projectile hit "<<e.model->name<<"\n";break;}}
    if(!p.alive)continue;if(playerAlive_&&targetAllowed(playerModel_,!p.fromPlayer)&&overlaps(atk,playerBox)){damagePlayer(damage,(float)p.facing,f->knockdown||f->attack.type>=2,f->dropVy,f->attack.type,0);p.alive=false;std::cout<<"Projectile hit player\n";continue;}
    for(auto& cp:coopPlayers_)if(p.alive&&cp.alive&&targetAllowed(cp.model,!p.fromPlayer)&&overlaps(atk,bboxFor(cp.animation.frame(),cp.worldX,cp.z+cp.altitude,cp.facing))){damageCoopPlayer(cp,damage,(float)p.facing,f->knockdown||f->attack.type>=2,f->dropVy,f->attack.type,0);p.alive=false;std::cout<<"Projectile hit coop player\n";break;}
  }
}
void Engine::updateCombatLock(){
  if(!config_.cameraLockOnCombat) return; bool active=false; for(const auto& e:entities_) if(e.alive&&e.model&&lowerString(e.model->type)=="enemy"){active=true;break;}
  if(active && !combatLocked_ && cameraX_>1.0f){ combatLocked_=true; combatLockX_=cameraX_; std::cout<<"Camera locked for combat at "<<combatLockX_<<"\n"; }
  else if(!active && combatLocked_){ combatLocked_=false; std::cout<<"Camera released after wave\n"; }
}
float Engine::scrollMin() const{
  if(!stage_) return 0.0f;
  if(scrollDir_<0) return 0.0f;
  return cameraMaxX_;
}
float Engine::scrollMax() const{
  float view=(float)std::max(160,config_.logicalWidth);
  float hard=std::max(0.0f,stageLength_-view);
  if(scrollBlocked_) return std::min(hard, cameraX_);
  return hard;
}
void Engine::updateCamera(){
  float previousCamera=cameraX_;
  float view=(float)std::max(160,config_.logicalWidth);
  if(cameraFixed_){ cameraX_=std::clamp(cameraX_,0.0f,std::max(0.0f,stageLength_-view)); cameraMaxX_=std::max(cameraMaxX_,cameraX_); return; }
  float focus=0.0f;int aliveCount=0;if(playerAlive_){focus+=playerWorldX_;++aliveCount;}for(const auto& cp:coopPlayers_)if(cp.alive){focus+=cp.worldX;++aliveCount;}if(aliveCount==0)return;focus/=(float)aliveCount;
  float target=cameraX_;float left=cameraX_+view*0.35f,right=cameraX_+view*0.65f;if(focus>right)target=focus-view*0.65f;else if(focus<left)target=focus-view*0.35f;
  if(scrollDir_<0){ target=std::clamp(target,0.0f,std::max(0.0f,stageLength_-view)); if(combatLocked_ && combatLockX_>1.0f) target=std::max(target,combatLockX_); cameraX_=target; }
  else if(allowBacktrack_){ float hi=std::max(0.0f,stageLength_-view);target=std::clamp(target,std::clamp(backtrackFloor_,0.0f,hi),hi);if(scrollBlocked_)target=std::min(target,cameraX_);if(combatLocked_&&combatLockX_>1.0f)target=std::min(target,combatLockX_);cameraX_=target; }
  else { target=std::clamp(target,0.0f,scrollMax()); if(combatLocked_ && combatLockX_>1.0f) target=std::min(target,std::max(combatLockX_,cameraMaxX_)); if(target<cameraMaxX_-1.0f) target=cameraMaxX_; cameraX_=target; }
  if(stage_&&stage_->scrollSpeed>0){float maxStep=(float)std::max(1,stage_->scrollSpeed);cameraX_=previousCamera+std::clamp(cameraX_-previousCamera,-maxStep,maxStep);}
  cameraMaxX_=std::max(cameraMaxX_,cameraX_);
}
void Engine::updateStageEvents(){
  if(!stage_) return;
  for(std::size_t i=0;i<stage_->eventCount && i<eventState_.size();++i){
    if(eventState_[i]!=0) continue;
    const auto& ev=stage_->events[i];std::string kind=lowerString(ev.kind?ev.kind:"");
    float edge=scrollDir_<0?cameraX_:cameraX_+(float)std::max(160,config_.logicalWidth);
    bool reached=!ev.hasAt||(scrollDir_<0?cameraX_<=(float)ev.at:edge>=(float)ev.at);if(!reached)continue;
    if(kind=="wait"){
      bool enemies=false;for(const auto&e:entities_)if(e.alive&&e.model&&lowerString(e.model->type)=="enemy"){enemies=true;break;}
      if(enemies){scrollBlocked_=true;continue;}scrollBlocked_=false;eventState_[i]=2;std::cout<<"Wait cleared at "<<ev.at<<"\n";
    }else if(kind=="blockade"){
      // OpenBOR blockade prevents returning behind a floor; it is not a combat wait.
      float floor=(float)(ev.value!=0?ev.value:ev.at);backtrackFloor_=std::max(backtrackFloor_,floor);eventState_[i]=2;std::cout<<"Blockade floor="<<backtrackFloor_<<" trigger="<<ev.at<<"\n";
    }else if(kind=="group"){
      groupMin_=std::max(0,ev.value);groupMax_=std::max(groupMin_,ev.group);groupRefillActive_=false;eventState_[i]=2;std::cout<<"Group rule min="<<groupMin_<<" max="<<groupMax_<<" at="<<ev.at<<"\n";
    }else{
      eventState_[i]=2;
    }
  }
}
void Engine::triggerSpawns(){
  if(!stage_) return;
  int activeEnemies=0;for(const auto& e:entities_)if(e.alive&&e.model&&lowerString(e.model->type)=="enemy")++activeEnemies;
  if(groupMax_>0 && !groupRefillActive_ && activeEnemies<groupMin_)groupRefillActive_=true;
  for(std::size_t i=0;i<stage_->spawnCount && i<spawnState_.size();++i){
    if(spawnState_[i]!=0) continue;
    const auto& s=stage_->spawns[i];
    if(s.id<0){ spawnState_[i]=2; continue; }
    // OpenBOR `at` is reached when the scroll position (camera origin + view) passes it.
    // Using only cameraX_ misses spawns that sit inside the visible screen, and spawning
    // them at cameraX_==0 would rewind the stage when the player is knocked back.
    float scrollEdge = scrollDir_<0 ? cameraX_ : cameraX_+(float)std::max(160,config_.logicalWidth);
    bool reached = !s.hasAt || s.at<=0 || (scrollDir_<0 ? cameraX_<=(float)s.at : scrollEdge>=(float)s.at);
    if(!reached) continue;
    if(scrollBlocked_ && s.hasAt && s.at>(int)cameraX_+(int)std::max(160,config_.logicalWidth)) continue;
    const generated::Character* spawnModel=findCharacter(s.model);bool groupedEnemy=spawnModel&&lowerString(spawnModel->type)=="enemy"&&s.spawnType!=1&&s.spawnType!=2;
    if(groupedEnemy&&groupMax_>0){if(!groupRefillActive_)continue;if(activeEnemies>=groupMax_){groupRefillActive_=false;continue;}}
    spawnState_[i]=1;
    RuntimeEntity e; e.spawn=&s; e.model=spawnModel; e.weaponDropsRemaining=spawnModel?std::max(0,spawnModel->weaponDropCounter):-1; e.worldX=(float)(s.hasAt?s.at+s.x:s.x); e.z=(float)s.z; e.altitude=-(float)std::max(0,s.a); e.paletteMap=paletteIndexFromText(s.map);
    if(e.model){ e.maxHealth=e.health=std::max(1,s.health>0?s.health:e.model->health); e.juggleRemaining=std::max(1,e.model->jugglePoints); e.facing=s.flip?-1:1; auto startAnim=findAnimation(e.model,"idle"); if(!startAnim) startAnim=findAnimation(e.model,"walk"); e.animation.setAnimation(startAnim); }
    std::string kind = e.model?lowerString(e.model->type):"";
    if(s.spawnType==1) kind="item";
    entities_.push_back(std::move(e));
    auto& spawned=entities_.back(); spawned.scriptCtx.entity=&spawned; spawned.scriptCtx.local["self"]=std::uintptr_t((std::uintptr_t)&spawned); runModelScript(spawned.model?spawned.model->onSpawnScript:"",spawned.scriptCtx,"entity-onspawn");
    if(s.spawnScript&&*s.spawnScript){spawned.scriptCtx.local["spawnx"]=(double)spawned.worldX;spawned.scriptCtx.local["spawnz"]=(double)spawned.z;spawned.scriptCtx.local["spawny"]=(double)(-spawned.altitude);spawned.scriptCtx.local["spawnat"]=(double)s.at;runModelScript(s.spawnScript,spawned.scriptCtx,"spawnscript");}
    spawnState_[i]=2; ++nextSpawn_;if(groupedEnemy&&groupMax_>0){++activeEnemies;if(activeEnemies>=groupMax_)groupRefillActive_=false;}
    std::cout<<"Spawn trigger id="<<s.id<<" model="<<s.model<<" at="<<s.at<<" worldX="<<spawned.worldX<<" boss="<<(s.boss?"yes":"no")<<" state=COMPLETED\n";
  }
}
void Engine::loadCurrentPlayerSprite(){
  auto f=player_.frame(); if(!f) return; if(lastFrame_==player_.frameIndex()) return; lastFrame_=player_.frameIndex();
  if(playerModel_){playerScriptCtx_.local["frame"]=(double)player_.frameIndex();runModelScript(playerModel_->animationScript,playerScriptCtx_,"player-animation-frame");}
  auto a=player_.animation();if(a&&a->flipFrame>=0&&(int)player_.frameIndex()==a->flipFrame)playerFacing_=-playerFacing_;if(a&&a->weaponFrame>=0&&(int)player_.frameIndex()==a->weaponFrame)setPlayerWeaponIndex(a->weaponIndex);const generated::Character* frameOwner=(equippedWeapon_&&a&&exactAnimation(equippedWeapon_,a->name?a->name:"")==a)?equippedWeapon_:playerModel_;queueChildSpawn(frameOwner,a,player_.frameIndex(),playerWorldX_,playerZ_,playerAltitude_,playerFacing_,std::uintptr_t(1));if(a&&a->unsummonFrame>=0&&(int)player_.frameIndex()==a->unsummonFrame)unsummonChildren(std::uintptr_t(1),false);
  playerWorldX_+=f->moveX*(float)playerFacing_; playerZ_+=f->moveZ; playerAltitude_-=f->moveA; playFrameSound(f); sprite_=SpriteImage{}; if(lowerString(f->sprite)!="none" && f->sprite[0]){renderer_.loadSprite(resolveSpriteAsset(root_/"assets"/"openbor-data",f->sprite),sprite_);applyCharacterPalette(renderer_,root_/"assets"/"openbor-data",playerModel_,f->draw.remap,sprite_);}
}
void Engine::loadEntitySprite(RuntimeEntity& e){
  auto f=e.animation.frame(); if(!f || e.lastFrame==e.animation.frameIndex()) return; e.lastFrame=e.animation.frameIndex();e.scriptCtx.local["frame"]=(double)e.animation.frameIndex();runModelScript(e.model?e.model->animationScript:"",e.scriptCtx,"entity-animation-frame");
  auto a=e.animation.animation();if(a&&a->flipFrame>=0&&(int)e.animation.frameIndex()==a->flipFrame)e.facing=-e.facing;if(a&&a->weaponFrame>=0&&(int)e.animation.frameIndex()==a->weaponFrame)setEntityWeaponIndex(e,a->weaponIndex);const generated::Character* frameOwner=(e.equippedWeapon&&a&&exactAnimation(e.equippedWeapon,a->name?a->name:"")==a)?e.equippedWeapon:e.model;queueChildSpawn(frameOwner,a,e.animation.frameIndex(),e.worldX,e.z,e.altitude,e.facing,std::uintptr_t((std::uintptr_t)&e));if(a&&a->unsummonFrame>=0&&(int)e.animation.frameIndex()==a->unsummonFrame)unsummonChildren(std::uintptr_t((std::uintptr_t)&e),false);
  e.worldX+=f->moveX*(float)e.facing; e.z+=f->moveZ; e.altitude-=f->moveA; playFrameSound(f); e.sprite=SpriteImage{}; if(lowerString(f->sprite)!="none" && f->sprite[0]){renderer_.loadSprite(resolveSpriteAsset(root_/"assets"/"openbor-data",f->sprite),e.sprite);applyCharacterPalette(renderer_,root_/"assets"/"openbor-data",e.model,f->draw.remap>0?f->draw.remap:e.paletteMap,e.sprite);}
}
void Engine::drawHud(){
  struct Bar{int hp,max;std::string label;};std::vector<Bar> bars;bars.push_back({playerHealth_,playerMaxHealth_,"P1"});for(std::size_t i=0;i<coopPlayers_.size();++i)bars.push_back({coopPlayers_[i].health,coopPlayers_[i].maxHealth,"P"+std::to_string(i+2)});int bw=70,bh=7;for(std::size_t i=0;i<bars.size()&&i<4;++i){int x=8+(int)i*78,y=10;renderer_.drawText(bars[i].label,x,y-8,7,i==0);renderer_.drawSolidRect(x,y,bw,bh,40,40,40);int fill=(int)((float)bw*(float)std::max(0,bars[i].hp)/(float)std::max(1,bars[i].max));renderer_.drawSolidRect(x,y,fill,bh,40,210,70);}int ey=28;for(const auto& e:entities_){if(!e.visible||!e.model)continue;int ew=90,ef=(int)((float)ew*(float)e.health/(float)std::max(1,e.maxHealth));renderer_.drawSolidRect(12,ey,ew,6,45,45,45);renderer_.drawSolidRect(12,ey,ef,6,220,70,70);ey+=9;if(ey>80)break;}
}
void Engine::renderScriptDrawQueue(){
  std::stable_sort(scriptDrawQueue_.begin(),scriptDrawQueue_.end(),[](const ScriptDrawCommand&a,const ScriptDrawCommand&b){return a.z<b.z;});
  for(const auto&c:scriptDrawQueue_){unsigned r=(c.color>>16)&255u,g=(c.color>>8)&255u,b=c.color&255u;switch(c.kind){
    case ScriptDrawCommand::Kind::Dot: renderer_.drawDot(c.x,c.y,c.color);break;
    case ScriptDrawCommand::Kind::Line: renderer_.drawLine(c.x,c.y,c.x2,c.y2,c.color);break;
    case ScriptDrawCommand::Kind::Box: renderer_.drawSolidRect(c.x,c.y,c.w,c.h,(unsigned char)r,(unsigned char)g,(unsigned char)b);break;
    case ScriptDrawCommand::Kind::Text: renderer_.drawText(c.text,c.x,c.y,std::max(6,8+c.font),false);break;
    case ScriptDrawCommand::Kind::Sprite:{auto it=scriptSprites_.find(c.sprite);if(it!=scriptSprites_.end())renderer_.drawImage(it->second,c.x,c.y);break;}
  }}
}
void Engine::drawStage(){
  renderer_.beginFrame();
  auto drawLayer=[&](const RuntimeStageLayer&l){if(l.image.width<=0||l.image.height<=0)return;int step=std::max(1,l.image.width+l.xSpacing);int base=l.xOffset-(int)(cameraX_*l.xRatio);int y=l.zOffset;int first=base;while(first>0)first-=step;int hardLimit=l.xRepeat>0?std::min(256,l.xRepeat):256;int drawn=0;for(int x=first;x<config_.logicalWidth&&drawn<hardLimit;x+=step,++drawn)renderer_.drawImage(l.image,x,y);};
  if(background_.width>0) renderer_.drawImage(background_,backgroundOffsetX_-(int)(cameraX_*backgroundRatioX_),backgroundOffsetY_);
  for(const auto&l:backgroundLayers_)drawLayer(l);
  int panelX=-(int)cameraX_; for(const auto& p:panels_){ renderer_.drawImage(p,panelX,0); panelX+=p.width; }
  if(auto f=player_.frame()){ runModelScript(playerModel_?playerModel_->onDrawScript:"",playerScriptCtx_,"player-ondraw"); loadCurrentPlayerSprite(); renderer_.drawFrame(sprite_,*f,(int)(playerWorldX_-cameraX_),(int)(playerZ_+playerAltitude_),config_,playerFacing_<0); }
  for(auto& cp:coopPlayers_){if(!cp.model)continue;auto f=cp.animation.frame();if(!f)continue;if(cp.lastFrame!=cp.animation.frameIndex()){cp.lastFrame=cp.animation.frameIndex();auto ca=cp.animation.animation();if(ca&&ca->flipFrame>=0&&(int)cp.animation.frameIndex()==ca->flipFrame)cp.facing=-cp.facing;if(ca&&ca->weaponFrame>=0&&(int)cp.animation.frameIndex()==ca->weaponFrame)setCoopWeaponIndex(cp,ca->weaponIndex);const generated::Character* frameOwner=(cp.equippedWeapon&&ca&&exactAnimation(cp.equippedWeapon,ca->name?ca->name:"")==ca)?cp.equippedWeapon:cp.model;queueChildSpawn(frameOwner,ca,cp.animation.frameIndex(),cp.worldX,cp.z,cp.altitude,cp.facing,std::uintptr_t((&cp-&coopPlayers_[0])+2));if(ca&&ca->unsummonFrame>=0&&(int)cp.animation.frameIndex()==ca->unsummonFrame)unsummonChildren(std::uintptr_t((&cp-&coopPlayers_[0])+2),false);cp.worldX+=f->moveX*(float)cp.facing;cp.z+=f->moveZ;cp.altitude-=f->moveA;playFrameSound(f);cp.sprite=SpriteImage{};if(lowerString(f->sprite)!="none"&&f->sprite[0]){renderer_.loadSprite(resolveSpriteAsset(root_/"assets"/"openbor-data",f->sprite),cp.sprite);applyCharacterPalette(renderer_,root_/"assets"/"openbor-data",cp.model,f->draw.remap>0?f->draw.remap:cp.paletteMap,cp.sprite);}}renderer_.drawFrame(cp.sprite,*f,(int)(cp.worldX-cameraX_),(int)(cp.z+cp.altitude),config_,cp.facing<0);}
  for(auto& e:entities_){ if(!e.visible) continue; if(e.model){e.scriptCtx.entity=&e;e.scriptCtx.local["self"]=std::uintptr_t((std::uintptr_t)&e);runModelScript(e.model->onDrawScript,e.scriptCtx,"entity-ondraw");} auto f=e.animation.frame(); if(!f) continue; loadEntitySprite(e); renderer_.drawFrame(e.sprite,*f,(int)(e.worldX-cameraX_),(int)(e.z+e.altitude),config_,e.facing<0); }
  for(auto& p:projectiles_){ if(!p.alive||!p.model)continue; auto f=p.animation.frame(); if(!f)continue; if(p.lastFrame!=p.animation.frameIndex()){p.lastFrame=p.animation.frameIndex();auto pa=p.animation.animation();if(pa&&pa->flipFrame>=0&&(int)p.animation.frameIndex()==pa->flipFrame)p.facing=-p.facing;queueChildSpawn(p.model,pa,p.animation.frameIndex(),p.worldX,p.z,p.altitude,p.facing,std::uintptr_t(0));playFrameSound(f);p.sprite=SpriteImage{};if(lowerString(f->sprite)!="none" && f->sprite[0]){renderer_.loadSprite(resolveSpriteAsset(root_/"assets"/"openbor-data",f->sprite),p.sprite);applyCharacterPalette(renderer_,root_/"assets"/"openbor-data",p.model,f->draw.remap,p.sprite);}} renderer_.drawFrame(p.sprite,*f,(int)(p.worldX-cameraX_),(int)(p.z+p.altitude),config_,p.facing<0); }
  flushChildSpawns();
  renderScriptDrawQueue();
  for(const auto&l:foregroundLayers_)drawLayer(l);
  drawHud(); renderer_.endFrame();
}
int Engine::run(){
  int headlessFrames=0;
  while(renderer_.isRunning() && renderer_.pumpEvents()){
    if(frontendState_==FrontendState::Quit) break;
#ifdef _WIN32
    if(frontendState_==FrontendState::Playing && (frontendKeyPressed(VK_ESCAPE)||gamepadButtonPressed(XINPUT_GAMEPAD_START))){ frontendState_=FrontendState::Paused; pauseIndex_=0; }
#endif
    if(frontendState_!=FrontendState::Playing){
      updateFrontend(); drawFrontend();
    } else {
      scriptDrawQueue_.clear(); ++tickCounter_; pollAudioHotkeys(); if(std::filesystem::exists(root_/"assets"/"openbor-data"/"scripts"/"update.c"))runModelScript("scripts/update.c",stageScriptCtx_,"global-update"); updatePlayer(); updateCoopPlayers(); updateEntities(); updateProjectiles(); resolveCombat(); flushWeaponDrops(); updateCombatLock(); updateStageEvents(); updateCamera(); triggerSpawns(); updateCombatLock(); if(std::filesystem::exists(root_/"assets"/"openbor-data"/"scripts"/"updated.c"))runModelScript("scripts/updated.c",stageScriptCtx_,"global-updated");
      if(tickCounter_%60==0){if(playerModel_&&playerModel_->guardPoints>0)playerGuardPoints_=std::min(playerModel_->guardPoints,playerGuardPoints_+std::max(1,playerModel_->guardRate));for(auto&cp:coopPlayers_)if(cp.model&&cp.model->guardPoints>0)cp.guardPoints=std::min(cp.model->guardPoints,cp.guardPoints+std::max(1,cp.model->guardRate));for(auto&e:entities_)if(e.model&&e.model->guardPoints>0)e.guardPoints=std::min(e.model->guardPoints,e.guardPoints+std::max(1,e.model->guardRate));}
      if(pendingBranchImmediate_ && pendingBranchTarget_!=(std::size_t)-1){auto target=pendingBranchTarget_;pendingBranchTarget_=(std::size_t)-1;pendingBranchImmediate_=false;int hp1=playerHealth_;std::vector<int> coopHp;for(const auto&cp:coopPlayers_)coopHp.push_back(cp.health);loadStage(target,true);playerHealth_=std::clamp(hp1,1,std::max(1,playerMaxHealth_));for(std::size_t i=0;i<coopPlayers_.size()&&i<coopHp.size();++i)coopPlayers_[i].health=std::clamp(coopHp[i],1,coopPlayers_[i].maxHealth);}
      drawStage();
      bool anyPlayerAlive=playerAlive_;for(const auto&cp:coopPlayers_)anyPlayerAlive=anyPlayerAlive||cp.alive;if(!anyPlayerAlive){frontendState_=FrontendState::GameOver;saveProgress();}
      else if(stage_){bool pendingSpawn=false;for(std::size_t si=0;si<spawnState_.size();++si)if(spawnState_[si]==0&&stage_->spawns[si].id>=0){pendingSpawn=true;break;}bool enemies=false;for(const auto&e:entities_)if(e.alive&&e.model&&lowerString(e.model->type)=="enemy"){enemies=true;break;}float lead=playerAlive_?playerWorldX_:0.0f;for(const auto&cp:coopPlayers_)if(cp.alive)lead=std::max(lead,cp.worldX);if(!pendingSpawn&&!enemies&&lead>=std::max(0.0f,stageLength_-(float)config_.logicalWidth*0.8f))advanceStage();}
    }
    if(config_.fpsLimit>0){const int frameMs=std::max(1,1000/config_.fpsLimit);std::this_thread::sleep_for(std::chrono::milliseconds(frameMs));}
#ifndef _WIN32
    if(tickCounter_%120==0) std::cout<<"headless camera="<<cameraX_<<" player="<<playerWorldX_<<" max="<<cameraMaxX_<<"\n";
    if(++headlessFrames>900) break;
#endif
  }
  saveSettings();
  return 0;
}
)CPP";

    std::ofstream main(src / "main.cpp");
    main << R"CPP(#include "Engine.hpp"
#include <filesystem>
#ifdef _WIN32
#define NOMINMAX
#include <windows.h>
#endif
static std::filesystem::path executableDir(const char* argv0){
#ifdef _WIN32
  std::wstring buf(32768,L'\0'); DWORD n=GetModuleFileNameW(nullptr,buf.data(),(DWORD)buf.size());
  if(n>0 && n<buf.size()){buf.resize(n);return std::filesystem::path(buf).parent_path();}
#else
  std::error_code linkEc; auto self=std::filesystem::read_symlink("/proc/self/exe",linkEc); if(!linkEc && self.has_parent_path()) return self.parent_path();
#endif
  std::error_code ec; auto p=std::filesystem::absolute(argv0?argv0:"openbor-port",ec); if(!ec && p.has_parent_path()) return p.parent_path();
  return std::filesystem::current_path();
}
int main(int argc,char** argv){ std::filesystem::path root=executableDir(argc>0?argv[0]:nullptr); for(int i=1;i<argc;++i){ if(argv[i] && argv[i][0]!='-'){ root=std::filesystem::path(argv[i]); break; } } Engine e; return e.initialize(root)?e.run():1; }
)CPP";

    std::ofstream cm(runtime / "CMakeLists.txt");
    cm << R"CMAKE(cmake_minimum_required(VERSION 3.20)
project(GeneratedOpenBORPort LANGUAGES CXX)
set(CMAKE_CXX_STANDARD 20)
if(MSVC)
  set(CMAKE_MSVC_RUNTIME_LIBRARY "MultiThreaded$<$<CONFIG:Debug>:Debug>")
endif()
add_executable(openbor-port src/main.cpp src/Engine.cpp src/Renderer.cpp src/AnimationPlayer.cpp src/RuntimeConfig.cpp src/AudioDecoder.cpp src/AudioSystem.cpp src/ScriptVM.cpp generated/GeneratedCharacters.cpp generated/GeneratedStages.cpp)
target_include_directories(openbor-port PRIVATE include)
if(MINGW)
  target_link_options(openbor-port PRIVATE -static -static-libgcc -static-libstdc++)
endif()
if(WIN32)
  target_link_libraries(openbor-port PRIVATE windowscodecs ole32 user32 gdi32 msimg32 xaudio2 xinput d3d11 dxgi d3dcompiler d2d1 dwrite mfplat mfreadwrite mfuuid)
endif()
)CMAKE";

    std::ofstream portable(outDir / "BUILD-PORTABLE-WINDOWS.ps1");
    portable << R"PS1($ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Runtime = Join-Path $Root "runtime"
$Build = Join-Path $Runtime "build-portable-win64"
$Dist = Join-Path $Root "portable-win64"
if (Test-Path $Build) { Remove-Item $Build -Recurse -Force }
if (Test-Path $Dist) { Remove-Item $Dist -Recurse -Force }
New-Item -ItemType Directory -Force -Path $Dist | Out-Null
cmake -S $Runtime -B $Build -A x64 -DCMAKE_MSVC_RUNTIME_LIBRARY=MultiThreaded
cmake --build $Build --config Release
Copy-Item (Join-Path $Build "Release\openbor-port.exe") (Join-Path $Dist "OpenBOR-Port.exe")
Copy-Item (Join-Path $Root "assets") $Dist -Recurse
Copy-Item (Join-Path $Root "config") $Dist -Recurse
if (Test-Path (Join-Path $Root "saves")) { Copy-Item (Join-Path $Root "saves") $Dist -Recurse }
Write-Host "Portatil Win64 pronto em: $Dist"
)PS1";

    std::ofstream portableMingw(outDir / "BUILD-PORTABLE-MINGW.ps1");
    portableMingw << R"PS1($ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Runtime = Join-Path $Root "runtime"
$Build = Join-Path $Runtime "build-portable-mingw"
$Dist = Join-Path $Root "portable-win64"
$Cxx = (Get-Command x86_64-w64-mingw32-g++ -ErrorAction Stop).Source
$Cc = (Get-Command x86_64-w64-mingw32-gcc -ErrorAction Stop).Source
if (Test-Path $Build) { Remove-Item $Build -Recurse -Force }
if (Test-Path $Dist) { Remove-Item $Dist -Recurse -Force }
New-Item -ItemType Directory -Force -Path $Dist | Out-Null
cmake -S $Runtime -B $Build -G Ninja -DCMAKE_BUILD_TYPE=Release -DCMAKE_C_COMPILER=$Cc -DCMAKE_CXX_COMPILER=$Cxx
cmake --build $Build
Copy-Item (Join-Path $Build "openbor-port.exe") (Join-Path $Dist "OpenBOR-Port.exe")
Copy-Item (Join-Path $Root "assets") $Dist -Recurse
Copy-Item (Join-Path $Root "config") $Dist -Recurse
if (Test-Path (Join-Path $Root "saves")) { Copy-Item (Join-Path $Root "saves") $Dist -Recurse }
Write-Host "Portatil MinGW Win64 pronto em: $Dist"
)PS1";

    std::ofstream portableCmd(outDir / "BUILD-PORTABLE-WINDOWS.cmd");
    portableCmd << R"CMD(@echo off
setlocal
where cmake >nul 2>nul || (echo ERRO: CMake nao encontrado.& pause & exit /b 1)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0BUILD-PORTABLE-WINDOWS.ps1"
if errorlevel 1 pause
)CMD";
}
