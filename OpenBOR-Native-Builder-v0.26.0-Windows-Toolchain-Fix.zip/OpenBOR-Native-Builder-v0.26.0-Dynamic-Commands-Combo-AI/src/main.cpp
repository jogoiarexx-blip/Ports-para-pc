#include "ProjectScanner.hpp"
#include "TextDatabase.hpp"
#include "PortGenerator.hpp"
#include "CompatibilityAnalyzer.hpp"
#include "RepairPackage.hpp"
#include "ParityAudit.hpp"
#include "LevelParser.hpp"
#include "SafePath.hpp"
#include "InputResolver.hpp"
#include <filesystem>
#include <fstream>
#include <iostream>
#include <iterator>
#include <sstream>
#include <string>
#include <cstdlib>
#include <vector>

#ifdef _WIN32
#define NOMINMAX
#include <windows.h>
#include <shlobj.h>
#include <shellapi.h>
#include <commdlg.h>
#endif

static const char* kVersion = "0.26.0";

static void usage() {
    std::cout << "OpenBOR Native Builder " << kVersion << "\n"
              << "Generic OpenBOR -> native C++ converter. No game-specific hardcode.\n"
              << "Usage:\n"
              << "  openbor-native-builder analyze <game-folder|game.zip|game.pak>\n"
              << "  openbor-native-builder convert <game-folder|game.zip|game.pak> [output-folder]\n"
              << "  openbor-native-builder build <game-folder|game.zip|game.pak> <output-folder>\n"
              << "  openbor-native-builder scan <game-folder|game.zip|game.pak>\n"
              << "  openbor-native-builder audit <game-folder|game.zip|game.pak>\n"
              << "  openbor-native-builder repair <game-folder|game.zip|game.pak> <output-folder>\n"
              << "  openbor-native-builder package <port-folder>\n"
              << "  openbor-native-builder test <port-folder>\n"
              << "\nbuild converts and compiles the generated runtime. package assembles a portable ZIP. analyze writes analysis.json and compatibility-report.txt.\n"
              << "Windows: run with no arguments and choose a folder, ZIP or PAK.\n";
}

static void printScan(const ScanReport& report) {
    std::cout << "OpenBOR project: " << report.root << "\n"
              << "data/: " << (report.hasDataDir ? "OK" : "MISSING") << "\n"
              << "models.txt: " << (report.hasModels ? "OK" : "MISSING") << "\n"
              << "levels.txt: " << (report.hasLevels ? "OK" : "MISSING") << "\n"
              << "menu.txt: " << (report.hasMenu ? "FOUND" : "none") << "  video.txt: " << (report.hasVideo ? "FOUND" : "none")
              << "  lifebar.txt: " << (report.hasLifebar ? "FOUND" : "none") << "  script.txt: " << (report.hasScriptConfig ? "FOUND" : "none") << "\n"
              << "files=" << report.files << " images=" << report.images
              << " audio=" << report.audio << " text=" << report.text << "\n";
    for (const auto& w : report.warnings) std::cout << "[WARN] " << w << "\n";
}

static void printCompatibility(const CompatibilityReport& c) {
    std::cout << "Compatibility: text_files=" << c.scannedTextFiles
              << " models=" << c.models
              << " stages=" << c.stages
              << " animations=" << c.animations
              << " scripts=" << c.scripts
              << " resolution=" << c.logicalWidth << "x" << c.logicalHeight
              << " supported=" << c.supportedCommands
              << " partial=" << c.partialCommands
              << " unsupported=" << c.unsupportedCommands
              << " unknown=" << c.unknownCommands << "\n";
    std::size_t shown = 0;
    for (const auto& issue : c.issues) {
        if (shown++ > 40) { std::cout << "... " << (c.issues.size()-40) << " more issues in the report files\n"; break; }
        std::cout << '[' << CommandRegistry::statusName(issue.status) << "] "
                  << issue.file.generic_string() << ':' << issue.line
                  << " " << issue.command << " - " << issue.message << "\n";
    }
}

static int writeAnalysis(const ScanReport& report, const CompatibilityReport& compatibility, const std::filesystem::path& outDir) {
    CompatibilityAnalyzer::writeReport(report, compatibility, outDir);
    std::cout << "Wrote " << (outDir / "analysis.json") << "\n";
    std::cout << "Wrote " << (outDir / "compatibility-report.txt") << "\n";
    return 0;
}

[[maybe_unused]] static bool pathInside(const std::filesystem::path& root, const std::filesystem::path& candidate) {
    std::error_code ec;
    auto base = std::filesystem::weakly_canonical(root, ec);
    if (ec) return false;
    auto full = std::filesystem::weakly_canonical(candidate, ec);
    if (ec) {
        full = std::filesystem::absolute(candidate).lexically_normal();
        base = std::filesystem::absolute(root).lexically_normal();
    }
    auto rel = full.lexically_relative(base);
    for (const auto& part : rel) if (part == "..") return false;
    return true;
}


static std::string shellQuote(const std::filesystem::path& p) {
#ifdef _WIN32
    std::string v=p.string(); std::string out="\""; for(char c:v){ if(c=='\"') out+="\\\""; else out+=c; } return out+="\"";
#else
    std::string v=p.string(), out="'"; for(char c:v){ if(c=='\'') out+="'\\''"; else out+=c; } return out+="'";
#endif
}

static int runCommand(const std::string& command) {
    std::cout << "> " << command << "\n";
    return std::system(command.c_str());
}

static std::filesystem::path findCMakeProgram() {
#ifdef _WIN32
    wchar_t found[32768]{};
    DWORD n=SearchPathW(nullptr,L"cmake.exe",nullptr,static_cast<DWORD>(std::size(found)),found,nullptr);
    if(n>0 && n<std::size(found)) return std::filesystem::path(found);

    wchar_t module[32768]{};
    DWORD mn=GetModuleFileNameW(nullptr,module,static_cast<DWORD>(std::size(module)));
    std::filesystem::path exeDir=(mn>0 && mn<std::size(module)) ? std::filesystem::path(module).parent_path() : std::filesystem::current_path();
    std::vector<std::filesystem::path> candidates={
        exeDir/"tools"/"cmake"/"bin"/"cmake.exe",
        exeDir/"cmake"/"bin"/"cmake.exe"
    };
    if(const wchar_t* pf=_wgetenv(L"ProgramFiles")) {
        auto base=std::filesystem::path(pf);
        candidates.push_back(base/"CMake"/"bin"/"cmake.exe");
        for(const wchar_t* edition : {L"Community",L"Professional",L"Enterprise"})
            candidates.push_back(base/"Microsoft Visual Studio"/"2022"/edition/L"Common7"/L"IDE"/L"CommonExtensions"/L"Microsoft"/L"CMake"/L"CMake"/L"bin"/L"cmake.exe");
    }
    if(const wchar_t* pfx86=_wgetenv(L"ProgramFiles(x86)")) {
        auto base=std::filesystem::path(pfx86);
        candidates.push_back(base/"CMake"/"bin"/"cmake.exe");
        candidates.push_back(base/"Microsoft Visual Studio"/"2022"/"BuildTools"/"Common7"/"IDE"/"CommonExtensions"/"Microsoft"/"CMake"/"CMake"/"bin"/"cmake.exe");
    }
    for(const auto& c : candidates) if(std::filesystem::exists(c)) return c;
    return {};
#else
    return std::filesystem::path("cmake");
#endif
}

static std::filesystem::path findBuiltRuntime(const std::filesystem::path& buildDir) {
#ifdef _WIN32
    const std::string wanted="openbor-port.exe";
#else
    const std::string wanted="openbor-port";
#endif
    std::error_code ec;
    if(!std::filesystem::exists(buildDir,ec)) return {};
    for(const auto& e: std::filesystem::recursive_directory_iterator(buildDir, std::filesystem::directory_options::skip_permission_denied, ec)) {
        if(ec){ ec.clear(); continue; }
        if(e.is_regular_file(ec) && e.path().filename().string()==wanted) return e.path();
    }
    return {};
}

static int buildGeneratedRuntime(const std::filesystem::path& portDir) {
    const auto runtime=portDir/"runtime";
    const auto cmakeFile=runtime/"CMakeLists.txt";
    if(!std::filesystem::exists(cmakeFile)) { std::cerr << "Erro: runtime/CMakeLists.txt nao encontrado em " << portDir << "\n"; return 20; }
    const auto buildDir=runtime/"build";
    std::filesystem::create_directories(buildDir);
    const auto cmake=findCMakeProgram();
    if(cmake.empty()) {
        std::cerr << "Erro: CMake nao foi encontrado. Instale o CMake/Visual Studio Build Tools ou coloque um CMake portatil em tools/cmake/bin ao lado do Builder.\n";
        return 20;
    }
    std::string configure=shellQuote(cmake)+" -S "+shellQuote(runtime)+" -B "+shellQuote(buildDir)+" -DCMAKE_BUILD_TYPE=Release";
#ifdef _WIN32
    int rc=runCommand(configure+" -A x64");
    if(rc!=0) rc=runCommand(configure);
#else
    int rc=runCommand(configure);
#endif
    if(rc!=0) return 21;
    rc=runCommand(shellQuote(cmake)+" --build "+shellQuote(buildDir)+" --config Release");
    if(rc!=0) return 22;
    auto built=findBuiltRuntime(buildDir);
    if(built.empty()) { std::cerr << "Erro: compilacao terminou sem localizar openbor-port.\n"; return 23; }
#ifdef _WIN32
    auto finalExe=portDir/"OpenBOR-Port.exe";
#else
    auto finalExe=portDir/"openbor-port";
#endif
    std::error_code ec;
    std::filesystem::copy_file(built, finalExe, std::filesystem::copy_options::overwrite_existing, ec);
    if(ec){ std::cerr << "Erro copiando runtime final: " << ec.message() << "\n"; return 24; }
    std::cout << "NATIVE BUILD SUCCESS: " << std::filesystem::absolute(finalExe) << "\n";
    return 0;
}

static int packagePort(const std::filesystem::path& portDir) {
    if(!std::filesystem::is_directory(portDir/"assets"/"openbor-data") || !std::filesystem::exists(portDir/"runtime"/"CMakeLists.txt")) {
        std::cerr << "Erro: a pasta nao parece ser um port gerado valido.\n"; return 30;
    }
    int rc=buildGeneratedRuntime(portDir); if(rc!=0) return rc;
#ifdef _WIN32
    const std::string suffix="-Portable-Win64"; const auto exeName=std::filesystem::path("OpenBOR-Port.exe");
#else
    const std::string suffix="-Portable-Host"; const auto exeName=std::filesystem::path("openbor-port");
#endif
    auto parent=portDir.parent_path();
    auto portable=parent/(portDir.filename().string()+suffix);
    auto archive=parent/(portDir.filename().string()+suffix+".zip");
    std::error_code ec; std::filesystem::remove_all(portable,ec); std::filesystem::create_directories(portable,ec);
    for(const char* name: {"assets","config","reports"}) {
        auto src=portDir/name; if(std::filesystem::exists(src)) std::filesystem::copy(src, portable/name, std::filesystem::copy_options::recursive|std::filesystem::copy_options::overwrite_existing, ec);
        if(ec){ std::cerr<<"Erro empacotando "<<name<<": "<<ec.message()<<"\n"; return 31; }
    }
    if(std::filesystem::exists(portDir/"README-PORT.txt")) std::filesystem::copy_file(portDir/"README-PORT.txt", portable/"README-PORT.txt", std::filesystem::copy_options::overwrite_existing, ec);
    std::filesystem::copy_file(portDir/exeName, portable/exeName, std::filesystem::copy_options::overwrite_existing, ec);
    if(ec){ std::cerr<<"Erro copiando executavel portatil: "<<ec.message()<<"\n"; return 32; }
    auto old=std::filesystem::current_path(); std::filesystem::current_path(parent);
    std::filesystem::remove(archive,ec);
    const auto cmake=findCMakeProgram();
    if(cmake.empty()) { std::cerr<<"Erro: CMake nao encontrado para criar o ZIP portatil.\n"; std::filesystem::current_path(old); return 33; }
    rc=runCommand(shellQuote(cmake)+" -E tar cf "+shellQuote(archive)+" --format=zip "+shellQuote(portable.filename()));
    std::filesystem::current_path(old);
    if(rc!=0) return 33;
    std::cout << "PACKAGE SUCCESS: " << std::filesystem::absolute(archive) << "\n";
    return 0;
}

static int validateGeneratedPort(const std::filesystem::path& portDir, const CompatibilityReport& compatibility) {
    int failures=0;
    auto need=[&](const std::filesystem::path& rel){ if(!std::filesystem::exists(portDir/rel)){ std::cerr<<"[FAIL] missing "<<rel.generic_string()<<"\n"; ++failures; } else std::cout<<"[PASS] "<<rel.generic_string()<<"\n"; };
    need("assets/openbor-data"); need("runtime/CMakeLists.txt"); need("runtime/generated/GeneratedCharacters.cpp"); need("runtime/generated/GeneratedStages.cpp"); need("runtime/src/Engine.cpp"); need("config/openbor-video.ini");
    std::ifstream vf(portDir/"config"/"openbor-video.ini"); std::string body((std::istreambuf_iterator<char>(vf)),{});
    if(body.find("logical_width="+std::to_string(compatibility.logicalWidth))==std::string::npos || body.find("logical_height="+std::to_string(compatibility.logicalHeight))==std::string::npos){ std::cerr<<"[FAIL] video config does not match detected resolution\n"; ++failures; } else std::cout<<"[PASS] video config matches detected resolution\n";
    return failures?40:0;
}

#ifdef _WIN32
static std::filesystem::path chooseFolder(HWND owner, const wchar_t* title) {
    BROWSEINFOW bi{};
    bi.hwndOwner = owner;
    bi.lpszTitle = title;
    bi.ulFlags = BIF_RETURNONLYFSDIRS | BIF_NEWDIALOGSTYLE | BIF_USENEWUI;
    PIDLIST_ABSOLUTE pidl = SHBrowseForFolderW(&bi);
    if (!pidl) return {};
    wchar_t path[MAX_PATH]{};
    std::filesystem::path result;
    if (SHGetPathFromIDListW(pidl, path)) result = std::filesystem::path(path);
    CoTaskMemFree(pidl);
    return result;
}

static std::filesystem::path chooseGameArchive(HWND owner) {
    wchar_t file[32768]{};
    OPENFILENAMEW ofn{};
    ofn.lStructSize = sizeof(ofn);
    ofn.hwndOwner = owner;
    ofn.lpstrFile = file;
    ofn.nMaxFile = static_cast<DWORD>(std::size(file));
    ofn.lpstrFilter = L"OpenBOR ZIP/PAK\0*.zip;*.pak\0ZIP\0*.zip\0OpenBOR PAK\0*.pak\0Todos\0*.*\0";
    ofn.nFilterIndex = 1;
    ofn.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_EXPLORER;
    ofn.lpstrTitle = L"Selecione o ZIP ou PAK do jogo OpenBOR";
    if (!GetOpenFileNameW(&ofn)) return {};
    return std::filesystem::path(file);
}

static std::wstring widen(const std::string& s) {
    if (s.empty()) return {};
    int count = MultiByteToWideChar(CP_UTF8, 0, s.c_str(), (int)s.size(), nullptr, 0);
    if (count <= 0) return std::wstring(s.begin(), s.end());
    std::wstring out((std::size_t)count, L'\0');
    MultiByteToWideChar(CP_UTF8, 0, s.c_str(), (int)s.size(), out.data(), count);
    return out;
}

static int runPortableGui() {
    if (HWND console = GetConsoleWindow()) ShowWindow(console, SW_HIDE);
    CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);

    int sourceChoice = MessageBoxW(nullptr,
                L"OpenBOR Native Builder v0.26.0\n\nAgora voce pode usar:\n- uma pasta do jogo;\n- um arquivo .ZIP;\n- um arquivo .PAK do OpenBOR.\n\nSIM = escolher ZIP/PAK\nNAO = escolher pasta\nCANCELAR = sair",
                L"OpenBOR Native Builder", MB_YESNOCANCEL | MB_ICONINFORMATION);
    if(sourceChoice==IDCANCEL){ CoUninitialize(); return 0; }
    auto selected = sourceChoice==IDYES ? chooseGameArchive(nullptr) : chooseFolder(nullptr, L"Selecione a pasta/pacote do jogo OpenBOR");
    if (selected.empty()) { CoUninitialize(); return 0; }

    try {
        auto input = InputResolver::resolve(selected);
        const auto game = input.gameRoot;
        auto report = ProjectScanner::scan(game);
        if (!report.hasDataDir) {
            MessageBoxW(nullptr, L"A pasta escolhida nao parece ser um projeto OpenBOR: a pasta data/ nao foi encontrada.",
                        L"OpenBOR Native Builder", MB_OK | MB_ICONERROR);
            CoUninitialize();
            return 3;
        }
        auto compatibility = CompatibilityAnalyzer::analyze(report);
        auto outputParent = std::filesystem::is_regular_file(selected) ? selected.parent_path() : selected.parent_path();
        auto outputBase = std::filesystem::is_regular_file(selected) ? selected.stem().wstring() : selected.filename().wstring();
        auto reportDir = outputParent / (outputBase + L"-analysis");
        CompatibilityAnalyzer::writeReport(report, compatibility, reportDir);
        std::wstringstream summary;
        summary << L"Entrada: " << selected.wstring() << L"\nProjeto detectado: " << game.wstring() << L"\nFonte: " << widen(input.sourceKind) << L"\n\n"
                << L"Models: " << compatibility.models << L"\n"
                << L"Stages: " << compatibility.stages << L"\n"
                << L"Animations: " << compatibility.animations << L"\n"
                << L"Resolution: " << compatibility.logicalWidth << L"x" << compatibility.logicalHeight << L"\n"
                << L"Supported: " << compatibility.supportedCommands << L"\n"
                << L"Partial: " << compatibility.partialCommands << L"\n"
                << L"Unknown: " << compatibility.unknownCommands << L"\n\n"
                << L"Deseja gerar o port nativo agora?";
        if (MessageBoxW(nullptr, summary.str().c_str(), L"Analise concluida", MB_YESNO | MB_ICONQUESTION) != IDYES) {
            CoUninitialize();
            return 0;
        }

        std::filesystem::path out = outputParent / (outputBase + L"-Native-Port");
        if (SafePath::isWithin(report.dataDir, out)) {
            MessageBoxW(nullptr, L"A pasta de saida nao pode ficar dentro de data/.", L"OpenBOR Native Builder", MB_OK | MB_ICONERROR);
            CoUninitialize();
            return 4;
        }
        if (std::filesystem::exists(out)) {
            if (MessageBoxW(nullptr, (L"A pasta de saida ja existe:\n" + out.wstring() + L"\n\nDeseja recriar/atualizar os arquivos gerados?").c_str(),
                            L"Confirmar saida", MB_YESNO | MB_ICONWARNING) != IDYES) {
                CoUninitialize();
                return 0;
            }
        }
        PortGenerator::generate(report, compatibility, out);
        CompatibilityAnalyzer::writeReport(report, compatibility, out / "reports");
        int packageRc = packagePort(out);

        std::wstring done = L"Port gerado em:\n" + out.wstring();
        if(packageRc==0) {
            auto zip = out.parent_path() / (out.filename().wstring() + L"-Portable-Win64.zip");
            done += L"\n\nBuild nativo e pacote Portable Win64 gerados com sucesso:\n" + zip.wstring();
        } else done += L"\n\nO projeto C++ foi gerado, mas o build/pacote automatico falhou. Veja o console/log e os relatorios.";
        done += L"\nGAME COMPATIBILITY: veja reports/compatibility-report.txt (PARTIAL nao e falha de build).\n\nAbrir a pasta de saida agora?";
        if (MessageBoxW(nullptr, done.c_str(), L"Port concluido", MB_YESNO | MB_ICONINFORMATION) == IDYES) {
            auto reveal = packageRc==0 ? out.parent_path() : out;
            ShellExecuteW(nullptr, L"open", reveal.wstring().c_str(), nullptr, nullptr, SW_SHOWNORMAL);
        }
    } catch (const std::exception& e) {
        std::wstring msg = L"Falha ao processar o projeto:\n" + widen(e.what());
        MessageBoxW(nullptr, msg.c_str(), L"OpenBOR Native Builder", MB_OK | MB_ICONERROR);
        CoUninitialize();
        return 10;
    }
    CoUninitialize();
    return 0;
}
#endif

int main(int argc, char** argv) {
#ifdef _WIN32
    if (argc == 1) return runPortableGui();
#endif
    if (argc < 3) { usage(); return 1; }
    const std::string cmd = argv[1];
    const std::filesystem::path supplied = argv[2];
    if (!std::filesystem::exists(supplied)) {
        std::cerr << "Erro: entrada nao encontrada: " << supplied << "\n";
        return 2;
    }

    if (cmd == "package") return packagePort(supplied);
    if (cmd == "test" && std::filesystem::is_directory(supplied / "assets" / "openbor-data")) {
        auto report = ProjectScanner::scan(supplied);
        printScan(report);
        auto compatibility = CompatibilityAnalyzer::analyze(report);
        printCompatibility(compatibility);
        int validation=validateGeneratedPort(supplied, compatibility);
        if(validation!=0) return validation;
        return buildGeneratedRuntime(supplied);
    }

    ResolvedGameInput input;
    try { input = InputResolver::resolve(supplied); }
    catch(const std::exception& e){ std::cerr << "Erro preparando entrada: " << e.what() << "\n"; return 2; }
    const auto game = input.gameRoot;
    std::cout << "Input source: " << input.sourceKind << " | original=" << input.original << " | gameRoot=" << game << "\n";
    if(input.discoveredCandidates.size()>1) std::cout << "[INFO] " << input.discoveredCandidates.size() << " candidatos detectados; usando o de maior compatibilidade estrutural.\n";

    auto report = ProjectScanner::scan(game);
    printScan(report);
    if (cmd == "scan") return report.hasDataDir ? 0 : 3;
    if (!report.hasDataDir) return 3;

    auto compatibility = CompatibilityAnalyzer::analyze(report);
    if (cmd == "analyze") {
        printCompatibility(compatibility);
        auto out = argc >= 4 ? std::filesystem::path(argv[3]) : (std::filesystem::is_regular_file(supplied) ? supplied.parent_path()/(supplied.stem().string()+"-analysis") : game/"reports");
        return writeAnalysis(report, compatibility, out);
    }
    if (cmd == "audit") {
        printCompatibility(compatibility);
        std::cout << "\n";
        ParityAudit::print(std::cout);
        return 0;
    }
    if (cmd == "build" || cmd == "convert") {
        if (argc < 4 && cmd == "build") { usage(); return 1; }
        std::filesystem::path out = argc >= 4 ? std::filesystem::path(argv[3]) : (std::filesystem::is_regular_file(supplied) ? supplied.parent_path()/(supplied.stem().string()+"-Native-Port") : game.parent_path()/(game.filename().string()+"-Native-Port"));
        if(SafePath::isWithin(report.dataDir,out)){ std::cerr << "Erro: a pasta de saida nao pode ficar dentro de data/.\n"; return 5; }
        PortGenerator::generate(report, compatibility, out);
        CompatibilityAnalyzer::writeReport(report, compatibility, out / "reports");
        printCompatibility(compatibility);
        std::cout << "CONVERT SUCCESS: port project generated at " << std::filesystem::absolute(out) << "\n";
        std::cout << "GAME COMPATIBILITY: " << (compatibility.unknownCommands==0 && compatibility.partialCommands==0 ? "PASS" : "PARTIAL") << "\n";
        if(cmd=="build") return buildGeneratedRuntime(out);
        return 0;
    }
    if (cmd == "repair") {
        if (argc < 4) { usage(); return 1; }
        RepairPackage::generate(report, compatibility, argv[3]);
        printCompatibility(compatibility);
        std::cout << "AI Repair package generated at: " << std::filesystem::absolute(argv[3]) / "AI-Repair" << "\n";
        return 0;
    }
    if (cmd == "test") {
        printCompatibility(compatibility);
        return compatibility.models > 0 || compatibility.stages > 0 ? 0 : 4;
    }
    usage();
    return 1;
}
