#include "SafePath.hpp"
#include <algorithm>
#include <cctype>

namespace {
std::string lower(std::string s){
    std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c){ return static_cast<char>(std::tolower(c)); });
    return s;
}
}

namespace SafePath {
std::string normalizeOpenBOR(std::string raw){
    for(char& c: raw) if(c=='\\') c='/';
    while(raw.rfind("./",0)==0) raw.erase(0,2);
    auto lo=lower(raw);
    if(lo.rfind("data/",0)==0) raw.erase(0,5);
    return std::filesystem::path(raw).lexically_normal().generic_string();
}

bool isSafeRelative(const std::filesystem::path& relative){
    if(relative.empty() || relative.is_absolute() || relative.has_root_name() || relative.has_root_directory()) return false;
    for(const auto& part: relative){
        if(part=="..") return false;
    }
    return true;
}

bool isWithin(const std::filesystem::path& root, const std::filesystem::path& candidate){
    std::error_code ec;
    auto base=std::filesystem::weakly_canonical(root,ec);
    if(ec){ ec.clear(); base=std::filesystem::absolute(root,ec).lexically_normal(); }
    ec.clear();
    auto full=std::filesystem::weakly_canonical(candidate,ec);
    if(ec){ ec.clear(); full=std::filesystem::absolute(candidate,ec).lexically_normal(); }
    if(base.empty() || full.empty()) return false;
    auto rel=full.lexically_relative(base);
    if(rel.empty()) return full==base;
    if(rel.is_absolute()) return false;
    for(const auto& part: rel) if(part=="..") return false;
    return true;
}

std::filesystem::path resolveWithin(const std::filesystem::path& root, const std::string& raw){
    auto normalized=normalizeOpenBOR(raw);
    std::filesystem::path rel(normalized);
    if(!isSafeRelative(rel)) return {};
    auto candidate=(root/rel).lexically_normal();
    if(!isWithin(root,candidate)) return {};
    return candidate;
}
}
