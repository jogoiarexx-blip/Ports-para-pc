#include "TextDatabase.hpp"
#include <fstream>
#include <sstream>
#include <algorithm>
#include <cctype>

namespace {
std::string trim(std::string s) {
    auto notSpace = [](unsigned char c){ return !std::isspace(c); };
    s.erase(s.begin(), std::find_if(s.begin(), s.end(), notSpace));
    s.erase(std::find_if(s.rbegin(), s.rend(), notSpace).base(), s.end());
    return s;
}
}

std::vector<TextEntry> TextDatabase::parse(const std::filesystem::path& file) {
    std::ifstream in(file);
    std::vector<TextEntry> out;
    if (!in) return out;
    std::string line;
    std::size_t lineNo = 0;
    while (std::getline(in, line)) {
        ++lineNo;
        auto semi = line.find('#');
        if (semi != std::string::npos) line.resize(semi);
        line = trim(line);
        if (line.empty()) continue;
        std::istringstream ss(line);
        TextEntry e;
        e.line = lineNo;
        ss >> e.key;
        std::string v;
        while (ss >> v) e.values.push_back(v);
        if (!e.key.empty()) out.push_back(std::move(e));
    }
    return out;
}
