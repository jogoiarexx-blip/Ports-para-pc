#include "LevelParser.hpp"
#include "TextDatabase.hpp"
#include "SafePath.hpp"
#include <algorithm>
#include <cctype>

namespace {
std::string lower(std::string s){
    std::transform(s.begin(),s.end(),s.begin(),[](unsigned char c){return (char)std::tolower(c);});
    return s;
}
int toInt(const std::string& s, int fallback=0){ try{return std::stoi(s);}catch(...){return fallback;} }
float toFloat(const std::string& s, float fallback=0.0f){ try{return std::stof(s);}catch(...){return fallback;} }
std::string normalizePath(std::string s){ return SafePath::normalizeOpenBOR(std::move(s)); }
std::filesystem::path resolveDataPath(const std::filesystem::path& dataDir, std::string path){
    return SafePath::resolveWithin(dataDir, path);
}
}

std::vector<LevelSetDef> LevelParser::parseLevelSets(const std::filesystem::path& levelsTxt){
    std::vector<LevelSetDef> out;
    LevelSetDef* current=nullptr;
    int setOrder=0;
    std::string pendingBranch;
    for(const auto& e:TextDatabase::parse(levelsTxt)){
        auto key=lower(e.key);
        if(key=="set" && !e.values.empty()){
            out.push_back(LevelSetDef{});
            current=&out.back();
            current->name=e.values[0];
            current->order=setOrder++;
            pendingBranch.clear();
        } else if(current && key=="branch" && !e.values.empty()){
            // In OpenBOR levels.txt, `branch name` labels the next level-order entry
            // so jumptobranch(name, ...) can warp to it. It is not a stage-file event.
            pendingBranch=e.values[0];
        } else if(current && key=="z" && e.values.size()>=2){
            current->zMin=toInt(e.values[0],160);
            current->zMax=toInt(e.values[1],232);
            if(e.values.size()>=3) current->backgroundHeight=toInt(e.values[2],160);
        } else if(current && key=="file" && !e.values.empty()){
            current->levelFiles.push_back(normalizePath(e.values[0]));
            current->levelBranches.push_back(pendingBranch);
            current->levelZMin.push_back(current->zMin);
            current->levelZMax.push_back(current->zMax);
            current->levelBackgroundHeight.push_back(current->backgroundHeight);
            pendingBranch.clear();
        }
    }
    return out;
}

VideoProfile LevelParser::parseVideo(const std::filesystem::path& dataDir){
    VideoProfile out;
    auto video=dataDir/"video.txt";
    if(!std::filesystem::exists(video)) return out;
    out.found=true;
    out.source="data/video.txt";
    for(const auto& e:TextDatabase::parse(video)){
        auto key=lower(e.key);
        if(e.values.empty()) continue;
        if(key=="video"||key=="videomode") out.videoMode=toInt(e.values[0],out.videoMode);
        else if(key=="hresolution"||key=="resolutionx"||key=="width") out.hResolution=std::max(160,toInt(e.values[0],out.hResolution));
        else if(key=="vresolution"||key=="resolutiony"||key=="height") out.vResolution=std::max(120,toInt(e.values[0],out.vResolution));
    }
    // OpenBOR video modes historically map to a logical resolution when explicit pixels are absent.
    if(out.hResolution==320 && out.vResolution==240 && out.videoMode!=0){
        switch(out.videoMode){
            case 0: break;
            case 1: out.hResolution=480; out.vResolution=272; break;
            case 2: out.hResolution=640; out.vResolution=480; break;
            case 3: out.hResolution=720; out.vResolution=480; break;
            case 4: out.hResolution=960; out.vResolution=540; break;
            default: break;
        }
    }
    return out;
}

StageDef LevelParser::parseStage(const std::filesystem::path& stageFile,
                                 const std::filesystem::path& root,
                                 const LevelSetDef& levelSet){
    StageDef out;
    out.setName=levelSet.name;
    out.setOrder=levelSet.order;
    out.zMin=levelSet.zMin;
    out.zMax=levelSet.zMax;
    out.backgroundHeight=levelSet.backgroundHeight;
    std::error_code ec;
    out.sourceFile=std::filesystem::relative(stageFile,root,ec).generic_string();
    if(ec) out.sourceFile=stageFile.generic_string();

    SpawnDef pending;
    bool haveSpawn=false;
    int pendingSequence=-1;
    int nextSequence=0;
    auto flushSpawn=[&](){
        if(!haveSpawn) return;
        if(pending.alias.empty()) pending.alias=pending.model;
        out.spawns.push_back(pending);
        out.instructions.push_back(StageInstructionDef{pendingSequence<0?nextSequence++:pendingSequence,0,pending.id});
        pending=SpawnDef{};
        pendingSequence=-1;
        haveSpawn=false;
    };
    int nextSpawnId=0;
    int nextEventId=0;
    int pendingEventId=-1; // wait/group/blockade may bind to the following `at` command.
    auto finalizePendingEvent=[&](){
        if(pendingEventId<0) return;
        for(auto& ev:out.events){
            if(ev.id!=pendingEventId) continue;
            // Backward-compatible shorthand: if no following `at` arrived, a lone
            // `blockade N` still uses N as its trigger as older builder versions did.
            if(ev.kind=="blockade" && !ev.hasAt && ev.value!=0){ ev.at=ev.value; ev.hasAt=true; }
            break;
        }
        pendingEventId=-1;
    };
    for(const auto& e:TextDatabase::parse(stageFile)){
        auto key=lower(e.key);
        if(key!="at") finalizePendingEvent();
        if((key=="background") && !e.values.empty()){
            out.background=normalizePath(e.values[0]);
            LayerDef layer; layer.kind="background"; layer.path=out.background; layer.xRatio=0.5f; layer.zRatio=0.5f;
            if(e.values.size()>1) layer.xRatio=toFloat(e.values[1],0.5f);
            if(e.values.size()>2) layer.zRatio=toFloat(e.values[2],0.5f);
            if(e.values.size()>3) layer.xOffset=toInt(e.values[3]);
            if(e.values.size()>4) layer.zOffset=toInt(e.values[4]);
            if(e.values.size()>5) layer.xSpacing=toInt(e.values[5]);
            if(e.values.size()>6) layer.zSpacing=toInt(e.values[6]);
            if(e.values.size()>7) layer.xRepeat=toInt(e.values[7]);
            if(e.values.size()>8) layer.zRepeat=toInt(e.values[8]);
            out.layers.push_back(layer);
        } else if(key=="bglayer" && !e.values.empty()){
            LayerDef layer; layer.kind="bglayer"; layer.path=normalizePath(e.values[0]); layer.xRatio=0.5f; layer.zRatio=0.5f;
            if(e.values.size()>1) layer.xRatio=toFloat(e.values[1],0.5f);
            if(e.values.size()>2) layer.zRatio=toFloat(e.values[2],0.5f);
            if(e.values.size()>3) layer.xOffset=toInt(e.values[3]);
            if(e.values.size()>4) layer.zOffset=toInt(e.values[4]);
            if(e.values.size()>5) layer.xSpacing=toInt(e.values[5]);
            if(e.values.size()>6) layer.zSpacing=toInt(e.values[6]);
            if(e.values.size()>7) layer.xRepeat=toInt(e.values[7]);
            if(e.values.size()>8) layer.zRepeat=toInt(e.values[8]);
            out.layers.push_back(layer);
        } else if(key=="fglayer" && !e.values.empty()){
            // OpenBOR fglayer syntax differs from bglayer: argument #2 is the layer Z/depth.
            LayerDef layer; layer.kind="fglayer"; layer.path=normalizePath(e.values[0]); layer.xRatio=1.0f; layer.zRatio=1.0f;
            if(e.values.size()>1) layer.zOrder=toInt(e.values[1]);
            if(e.values.size()>2) layer.xRatio=toFloat(e.values[2],1.0f);
            if(e.values.size()>3) layer.zRatio=toFloat(e.values[3],1.0f);
            if(e.values.size()>4) layer.xOffset=toInt(e.values[4]);
            if(e.values.size()>5) layer.zOffset=toInt(e.values[5]);
            if(e.values.size()>6) layer.xSpacing=toInt(e.values[6]);
            if(e.values.size()>7) layer.zSpacing=toInt(e.values[7]);
            if(e.values.size()>8) layer.xRepeat=toInt(e.values[8]);
            if(e.values.size()>9) layer.zRepeat=toInt(e.values[9]);
            out.layers.push_back(layer);
        } else if((key=="panel" || key=="frontpanel") && !e.values.empty()){
            auto path=normalizePath(e.values[0]);
            if(key=="panel") out.panels.push_back(path);
            LayerDef layer; layer.kind=key; layer.path=path; out.layers.push_back(layer);
        } else if(key=="music" && !e.values.empty()){
            out.music=normalizePath(e.values[0]);
            if(e.values.size()>=2) out.musicLoop=toInt(e.values[1],1)!=0;
        } else if(key=="direction" && !e.values.empty()){
            out.direction=lower(e.values[0]);
        } else if(key=="type" && !e.values.empty()){
            out.type=lower(e.values[0]);
            // OpenBOR level type 0 is often a fixed/special stage; 1 is side-scroll.
            if(out.type=="0" || out.type=="none") out.cameraType=1;
        } else if(key=="cameratype" && !e.values.empty()){
            out.cameraType=toInt(e.values[0],0);
        } else if((key=="scrollspeed" || key=="scrollx") && !e.values.empty()){
            out.scrollSpeed=toInt(e.values[0],0);
            StageEventDef ev; ev.id=nextEventId++; ev.kind=key; ev.value=out.scrollSpeed; out.events.push_back(ev); out.instructions.push_back(StageInstructionDef{nextSequence++,1,ev.id});
        } else if(key=="spawn1" && e.values.size()>=3){
            out.playerStartX=toInt(e.values[0],80);
            out.playerStartZ=out.zMin+toInt(e.values[1],40);
            out.playerStartA=toInt(e.values[2],0);
        } else if((key=="wall" || key=="platform" || key=="hole" || key=="obstacle") && e.values.size()>=4){
            GeometryDef g; g.kind=key; g.x=toInt(e.values[0]); g.z=toInt(e.values[1]); g.w=toInt(e.values[2]); g.h=toInt(e.values[3]);
            if(e.values.size()>4) g.depth=toInt(e.values[4]);
            if(e.values.size()>5) g.altitude=toInt(e.values[5]);
            out.geometry.push_back(g);
        } else if(key=="next" && !e.values.empty()){
            out.nextStage=normalizePath(e.values[0]);
        } else if(key=="branch" && !e.values.empty()){
            out.branchStage=normalizePath(e.values[0]);
            StageEventDef ev; ev.id=nextEventId++; ev.kind="branch"; ev.text=out.branchStage; out.events.push_back(ev); out.instructions.push_back(StageInstructionDef{nextSequence++,1,ev.id});
        } else if(key=="levelscript" && !e.values.empty()){
            out.levelScript=normalizePath(e.values[0]);
        } else if(key=="endlevel" || key=="end"){
            out.endLevel=true;
        } else if((key=="wait" || key=="group" || key=="blockade" || key=="nojoin") || (key=="at" && !haveSpawn)){
            if(key=="at" && !haveSpawn){
                const int at=toInt(e.values.empty()?"0":e.values[0]);
                bool attached=false;
                if(pendingEventId>=0){
                    for(auto& ev:out.events){
                        if(ev.id==pendingEventId){ ev.at=at; ev.hasAt=true; attached=true; break; }
                    }
                    pendingEventId=-1;
                }
                if(!attached){
                    // A truly bare `at` is retained as a scroll marker.
                    StageEventDef ev; ev.id=nextEventId++; ev.kind="scrollat"; ev.at=at; ev.hasAt=true; out.events.push_back(ev); out.instructions.push_back(StageInstructionDef{nextSequence++,1,ev.id});
                }
            } else if(key!="at"){
                StageEventDef ev; ev.id=nextEventId++; ev.kind=key;
                if(key=="group"){
                    // OpenBOR group {min} {max}; it normally binds to the following `at`.
                    ev.value=e.values.empty()?0:toInt(e.values[0]);
                    ev.group=e.values.size()>1?toInt(e.values[1]):ev.value;
                    if(ev.group<ev.value) ev.group=ev.value;
                    pendingEventId=ev.id;
                } else if(key=="wait"){
                    // Canonical form is `wait` then `at N`. Keep legacy shorthand `wait N` too.
                    if(!e.values.empty()){ev.at=toInt(e.values[0]);ev.hasAt=true;pendingEventId=-1;}else pendingEventId=ev.id;
                } else if(key=="blockade"){
                    // First argument is the backward-scroll floor; canonical files can
                    // bind a separate trigger with the immediately following `at`.
                    if(!e.values.empty()) ev.value=toInt(e.values[0]);
                    if(e.values.size()>1){ev.at=toInt(e.values[1]);ev.hasAt=true;pendingEventId=-1;}
                    else pendingEventId=ev.id;
                } else {
                    if(!e.values.empty()) ev.value=toInt(e.values[0]);
                }
                out.events.push_back(ev);
                out.instructions.push_back(StageInstructionDef{nextSequence++,1,ev.id});
            }
        } else if((key=="spawn") && !e.values.empty()){
            flushSpawn();
            pending=SpawnDef{};
            pending.id=nextSpawnId++;
            pendingSequence=nextSequence++;
            pending.model=e.values[0];
            pending.spawnType=0;
            haveSpawn=true;
        } else if(haveSpawn && key=="alias" && !e.values.empty()){
            pending.alias=e.values[0];
        } else if(haveSpawn && key=="item" && !e.values.empty()){
            // OpenBOR "item" under a spawn is the drop, not a new entity.
            pending.item=e.values[0];
            pending.spawnType = pending.spawnType==0 ? 0 : pending.spawnType;
        } else if(!haveSpawn && (key=="item" || key=="weapon") && !e.values.empty()){
            pending=SpawnDef{};
            pending.id=nextSpawnId++;
            pendingSequence=nextSequence++;
            pending.model=e.values[0];
            pending.spawnType = key=="weapon" ? 2 : 1;
            haveSpawn=true;
        } else if(haveSpawn && (key=="colourmap" || key=="colormap" || key=="palette") && !e.values.empty()){
            pending.map=e.values[0];
        } else if(haveSpawn && key=="health" && !e.values.empty()){
            pending.health=toInt(e.values[0],-1);
        } else if(haveSpawn && key=="score" && !e.values.empty()){
            pending.score=toInt(e.values[0],0);
        } else if(haveSpawn && key=="spawnscript" && !e.values.empty()){
            pending.spawnScript=normalizePath(e.values[0]);
        } else if(haveSpawn && key=="coords" && !e.values.empty()){
            pending.x=toInt(e.values[0]);
            if(e.values.size()>1) pending.z=toInt(e.values[1],200);
            if(e.values.size()>2) pending.a=toInt(e.values[2]);
            if(e.values.size()>3) pending.y=toInt(e.values[3]);
        } else if(haveSpawn && key=="boss"){
            pending.boss = e.values.empty() || toInt(e.values[0],1)!=0;
            if(pending.boss) pending.spawnType=4;
        } else if(haveSpawn && key=="flip" && !e.values.empty()){
            pending.flip=toInt(e.values[0])!=0;
        } else if(haveSpawn && key=="at" && !e.values.empty()){
            pending.at=toInt(e.values[0]);
            pending.hasAt=true;
        } else if(haveSpawn && (key=="spawn" || key=="set" || key=="file")){
            flushSpawn();
        }
    }
    finalizePendingEvent();
    flushSpawn();

    // Stable order: trigger position, then original declaration index.
    // Spawns without "at" are immediate (at = 0) but keep declaration order among themselves.
    std::stable_sort(out.spawns.begin(), out.spawns.end(), [](const SpawnDef& a, const SpawnDef& b){
        if(a.at!=b.at) return a.at<b.at;
        return a.id<b.id;
    });
    std::stable_sort(out.events.begin(), out.events.end(), [](const StageEventDef& a, const StageEventDef& b){
        if(a.at!=b.at) return a.at<b.at;
        return a.id<b.id;
    });
    std::stable_sort(out.instructions.begin(), out.instructions.end(), [](const StageInstructionDef& a,const StageInstructionDef& b){ return a.sequence<b.sequence; });
    return out;
}

std::vector<StageDef> LevelParser::parseAll(const std::filesystem::path& dataDir,
                                            const std::filesystem::path& root){
    std::vector<StageDef> out;
    auto levelsTxt=dataDir/"levels.txt";
    if(!std::filesystem::exists(levelsTxt)) return out;
    auto sets=parseLevelSets(levelsTxt);
    int order=0;
    for(const auto& set:sets){
        for(std::size_t levelIndex=0; levelIndex<set.levelFiles.size(); ++levelIndex){
            const auto& rel=set.levelFiles[levelIndex];
            auto stageFile=resolveDataPath(dataDir,rel);
            if(std::filesystem::exists(stageFile)){
                LevelSetDef effective=set;
                if(levelIndex<set.levelZMin.size()) effective.zMin=set.levelZMin[levelIndex];
                if(levelIndex<set.levelZMax.size()) effective.zMax=set.levelZMax[levelIndex];
                if(levelIndex<set.levelBackgroundHeight.size()) effective.backgroundHeight=set.levelBackgroundHeight[levelIndex];
                auto stage=parseStage(stageFile,root,effective);
                if(levelIndex<set.levelBranches.size()) stage.branchName=set.levelBranches[levelIndex];
                stage.order=order++;
                out.push_back(std::move(stage));
            }
        }
    }
    return out;
}
