#include "CompatibilityAnalyzer.hpp"
#include "TextDatabase.hpp"
#include "LevelParser.hpp"
#include "CharacterParser.hpp"
#include <algorithm>
#include <cctype>
#include <fstream>
#include <map>
#include <regex>
#include <set>
#include <sstream>

namespace {
std::string lower(std::string s){std::transform(s.begin(),s.end(),s.begin(),[](unsigned char c){return static_cast<char>(std::tolower(c));});return s;}
bool textLike(const std::filesystem::path&p){auto e=lower(p.extension().string());return e==".txt"||e==".c"||e==".h"||e==".cfg";}
std::vector<std::string> scriptUnsupported(const std::filesystem::path& path){
 std::ifstream in(path); if(!in) return {}; std::ostringstream ss;ss<<in.rdbuf();auto src=ss.str(),lo=lower(src);std::vector<std::string> out;auto add=[&](std::string s){if(std::find(out.begin(),out.end(),s)==out.end())out.push_back(std::move(s));};
 // v0.22 handles object-like and function-like #define plus include/import preprocessing and a broader OpenBORScript API surface.
 static const std::set<std::string> allowed={
  "main","if","while","for","switch","getglobalvar","setglobalvar","clearglobalvar","getglobalvarindex","setglobalvarindex","maxglobalvarindex",
  "getindexedvar","setindexedvar","clearindexedvar","getlocalvar","setlocalvar","clearlocalvar","getlocalvarindex","setlocalvarindex",
  "array","size","get","set","add","delete","next","previous","reset","value","key","free",
  "isempty","rand","null","openborconstant","openborvariant","changeopenborvariant","setopenborvariant","getentityproperty","get_entity_property",
  "changeentityproperty","change_entity_property","setentityproperty","performattack","perform_attack","setanimation","changeanimation","damageentity","damage_entity",
  "killentity","kill_entity","playerkeys","getplayerproperty","get_player_property","changeplayerproperty","change_player_property","log","printf","debug","rgbcolor",
  "playmusic","pausemusic","loadsample","unloadsample","playsample","getentity","findtarget","checkrange","getentityvar","get_entity_var","setentityvar","set_entity_var","clearentityvar","clear_entity_var","clearspawnentry","clear_spawn_entry","setspawnentry","set_spawn_entry","spawn","spawnentity","spawn_entity","setidle","updateframe","getmodelproperty","get_model_property","getlevelproperty","get_level_property","changelevelproperty","setlevelproperty","set_level_property","drawdot","drawline","drawbox","drawstring","drawsprite","loadsprite","freesprite","getgfxproperty","get_gfx_property","rgbcolour"
 };
 std::set<std::string> defined;
 std::regex macroDef(R"(#\s*define\s+([A-Za-z_][A-Za-z0-9_]*)\s*\()");
 for(std::sregex_iterator m(src.begin(),src.end(),macroDef),me;m!=me;++m) defined.insert(lower((*m)[1].str()));
 std::regex def(R"((?:void|int|float|char|string|mixed|decimal|pointer)\s+([A-Za-z_][A-Za-z0-9_]*)\s*\()");
 for(std::sregex_iterator i(src.begin(),src.end(),def),e;i!=e;++i)defined.insert(lower((*i)[1].str()));
 // Include/imported helper functions belong to the same script compilation unit after
 // v0.19 preprocessing. Teach the analyzer about them so supported includes do not
 // produce false "api/function" warnings.
 std::filesystem::path dataRoot;
 for(auto cur=path.parent_path(); !cur.empty(); cur=cur.parent_path()){
  auto leaf=lower(cur.filename().string());
  if(leaf=="data" || leaf=="openbor-data" || std::filesystem::exists(cur/"models.txt") || std::filesystem::exists(cur/"levels.txt")){
   dataRoot=cur; break;
  }
  if(cur==cur.root_path()) break;
 }
 std::regex incRe(R"(#\s*(?:include|import)\s*["<]([^">]+)[">])", std::regex::icase);
 for(std::sregex_iterator i(src.begin(),src.end(),incRe),e;i!=e;++i){
  std::string rel=(*i)[1].str(); std::replace(rel.begin(),rel.end(),'\\','/');
  std::filesystem::path inc;
  auto lr=lower(rel);
  if(!dataRoot.empty() && lr.rfind("data/",0)==0) inc=dataRoot/std::filesystem::path(rel.substr(5));
  else inc=path.parent_path()/std::filesystem::path(rel);
  std::ifstream imported(inc.lexically_normal());
  if(!imported) continue;
  std::ostringstream importedText; importedText<<imported.rdbuf(); auto body=importedText.str();
  for(std::sregex_iterator d(body.begin(),body.end(),def),de;d!=de;++d) defined.insert(lower((*d)[1].str()));
 }
 std::regex call(R"(([A-Za-z_][A-Za-z0-9_]*)\s*\()");
 for(std::sregex_iterator i(src.begin(),src.end(),call),e;i!=e;++i){auto n=lower((*i)[1].str());if(!allowed.contains(n)&&!defined.contains(n)&&n!="void"&&n!="int"&&n!="float"&&n!="char"&&n!="string"&&n!="mixed"&&n!="decimal"&&n!="pointer")add("api/function:"+n);}
 return out;
}
std::string jsonEscape(const std::string& s){
    std::string o; o.reserve(s.size());
    for(char c:s){ if(c=='\\'||c=='"'){o.push_back('\\'); o.push_back(c);} else if(c=='\n') o+="\\n"; else if(c=='\r') continue; else o.push_back(c); }
    return o;
}
}

CompatibilityReport CompatibilityAnalyzer::analyze(const ScanReport& scan){
    CompatibilityReport out;
    if(!scan.hasDataDir) return out;
    auto video = LevelParser::parseVideo(scan.dataDir);
    if(video.found){ out.logicalWidth=video.hResolution; out.logicalHeight=video.vResolution; out.openborVersionHint = "video.txt present (mode "+std::to_string(video.videoMode)+")"; }
    else out.openborVersionHint = "video.txt absent; logical resolution defaults to 320x240 until a project declares otherwise";

    auto characters = CharacterParser::parseAll(scan.dataDir, scan.root);
    out.models = characters.size();
    for(const auto& c: characters) out.animations += c.animations.size();
    out.stages = LevelParser::parseAll(scan.dataDir, scan.root).size();

    for(const auto& entry: std::filesystem::recursive_directory_iterator(scan.dataDir)){
        if(!entry.is_regular_file()) continue;
        auto ext=lower(entry.path().extension().string());
        if(ext==".wav"||ext==".bor"||ext==".ogg"||ext==".mp3"||ext==".flac") ++out.audioFiles;
        if(!textLike(entry.path())) continue;
        ++out.scannedTextFiles;
        if(ext==".c"||ext==".h"){
            ++out.scripts;
            auto unsupported=scriptUnsupported(entry.path());
            ++out.recognizedCommands;
            if(!unsupported.empty()){
                CompatibilityIssue issue;
                issue.level=CompatibilityLevel::Yellow;
                issue.status=CommandStatus::Partial;
                issue.parser=true; issue.runtime=false;
                issue.file=std::filesystem::relative(entry.path(),scan.root);
                issue.line=1; issue.command="script-file";
                issue.message="ScriptVM v0.22 covers the extended C-like core and basic preprocessing, but this file uses: ";
                for(std::size_t i=0;i<unsupported.size();++i){ if(i) issue.message+=", "; issue.message+=unsupported[i]; }
                issue.message+=". Logged, not silently dropped.";
                out.issues.push_back(std::move(issue));
                ++out.partialCommands;
            }
            continue;
        }
        for(const auto& item: TextDatabase::parse(entry.path())){
            const auto cmd=lower(item.key);
            ++out.commandUsage[cmd];
            auto info=CommandRegistry::lookup(cmd);
            out.commandStatus[cmd]=info.status;
            CompatibilityIssue issue;
            issue.file=std::filesystem::relative(entry.path(),scan.root);
            issue.line=item.line;
            issue.command=cmd;
            issue.status=info.status;
            issue.parser=info.parser;
            issue.runtime=info.runtime;
            issue.message = info.note?info.note:"";
            if(info.status==CommandStatus::Supported){ ++out.supportedCommands; ++out.recognizedCommands; continue; }
            if(info.status==CommandStatus::IgnoredSafely){ ++out.recognizedCommands; continue; }
            if(info.status==CommandStatus::Partial){ ++out.partialCommands; ++out.recognizedCommands; issue.level=CompatibilityLevel::Yellow; }
            else if(info.status==CommandStatus::Unsupported){ ++out.unsupportedCommands; ++out.recognizedCommands; issue.level=CompatibilityLevel::Red; }
            else { ++out.unknownCommands; issue.level=CompatibilityLevel::Yellow; issue.status=CommandStatus::Unknown; if(issue.message.empty()) issue.message="Uncatalogued command. Logged; conversion continues."; }
            out.issues.push_back(std::move(issue));
        }
    }
    return out;
}

const char* CompatibilityAnalyzer::levelName(CompatibilityLevel level){
    switch(level){case CompatibilityLevel::Green:return"GREEN";case CompatibilityLevel::Yellow:return"YELLOW";case CompatibilityLevel::Red:return"RED";}
    return"UNKNOWN";
}

void CompatibilityAnalyzer::writeReport(const ScanReport& scan, const CompatibilityReport& report, const std::filesystem::path& outDir){
    std::filesystem::create_directories(outDir);
    const double total = (double)std::max<std::size_t>(1, report.supportedCommands+report.partialCommands+report.unsupportedCommands+report.unknownCommands);
    auto pct=[&](std::size_t n){ return (int)(100.0*(double)n/total); };

    std::ofstream txt(outDir/"compatibility-report.txt");
    txt << "OPENBOR CONVERSION REPORT\n\n";
    txt << "Game: " << scan.root.filename().string() << "\n";
    txt << "Source: " << scan.root.generic_string() << "\n";
    txt << "OpenBOR hint: " << report.openborVersionHint << "\n";
    txt << "Logical resolution: " << report.logicalWidth << "x" << report.logicalHeight << "\n";
    txt << "Models: " << report.models << "\n";
    txt << "Stages: " << report.stages << "\n";
    txt << "Animations: " << report.animations << "\n";
    txt << "Scripts: " << report.scripts << "\n";
    txt << "Audio files: " << report.audioFiles << "\n";
    txt << "Text files: " << report.scannedTextFiles << "\n\n";
    txt << "Parser occurrences:\n";
    txt << "  SUPPORTED .... " << report.supportedCommands << " (" << pct(report.supportedCommands) << "%)\n";
    txt << "  PARTIAL ...... " << report.partialCommands << " (" << pct(report.partialCommands) << "%)\n";
    txt << "  UNSUPPORTED .. " << report.unsupportedCommands << "\n";
    txt << "  UNKNOWN ...... " << report.unknownCommands << "\n\n";
    txt << "Status means parser support AND runtime support. A parsed-but-not-executed command is PARTIAL.\n\n";
    txt << "Command registry:\n";
    for(const auto& [name,count]: report.commandUsage){
        auto st = report.commandStatus.count(name)? CommandRegistry::statusName(report.commandStatus.at(name)) : "UNKNOWN";
        txt << "  " << name << " x" << count << " -> " << st << "\n";
    }
    txt << "\nIssues (file:line command impact):\n";
    for(const auto& issue: report.issues){
        txt << "  [" << CommandRegistry::statusName(issue.status) << "] "
            << issue.file.generic_string() << ":" << issue.line
            << " " << issue.command;
        if(!issue.message.empty()) txt << " - " << issue.message;
        txt << "\n";
    }

    std::ofstream json(outDir/"analysis.json");
    json << "{\n";
    json << "  \"game\": \"" << jsonEscape(scan.root.filename().string()) << "\",\n";
    json << "  \"logicalWidth\": " << report.logicalWidth << ",\n";
    json << "  \"logicalHeight\": " << report.logicalHeight << ",\n";
    json << "  \"models\": " << report.models << ",\n";
    json << "  \"stages\": " << report.stages << ",\n";
    json << "  \"animations\": " << report.animations << ",\n";
    json << "  \"scripts\": " << report.scripts << ",\n";
    json << "  \"audioFiles\": " << report.audioFiles << ",\n";
    json << "  \"supported\": " << report.supportedCommands << ",\n";
    json << "  \"partial\": " << report.partialCommands << ",\n";
    json << "  \"unsupported\": " << report.unsupportedCommands << ",\n";
    json << "  \"unknown\": " << report.unknownCommands << ",\n";
    json << "  \"commands\": {\n";
    std::size_t i=0;
    for(const auto& [name,count]: report.commandUsage){
        auto st = report.commandStatus.count(name)? CommandRegistry::statusName(report.commandStatus.at(name)) : "UNKNOWN";
        json << "    \"" << jsonEscape(name) << "\": {\"count\": " << count << ", \"status\": \"" << st << "\"}";
        if(++i!=report.commandUsage.size()) json << ",";
        json << "\n";
    }
    json << "  }\n}\n";
}
