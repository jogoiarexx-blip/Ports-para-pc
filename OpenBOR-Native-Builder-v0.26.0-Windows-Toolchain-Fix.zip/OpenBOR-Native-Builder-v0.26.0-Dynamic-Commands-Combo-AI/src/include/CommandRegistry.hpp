#pragma once
#include <string>
#include <string_view>

// Central OpenBOR command registry.
// PARSER support means the converter records the command.
// RUNTIME support means the generated C++ runtime executes it.
// A command is never marked fully supported from parser recognition alone.
enum class CommandStatus {
    Supported,      // parser + runtime
    Partial,        // parser yes, runtime incomplete
    Unsupported,    // known, runtime no
    IgnoredSafely,  // documented no-op / cosmetic
    Unknown
};

struct CommandInfo {
    CommandStatus status = CommandStatus::Unknown;
    bool parser = false;
    bool runtime = false;
    const char* note = "";
};

class CommandRegistry {
public:
    static CommandInfo lookup(std::string_view command);
    static const char* statusName(CommandStatus status);
    static std::string classifyLine(std::string_view command);
};
