#pragma once
#include "CompatibilityAnalyzer.hpp"
#include "ProjectScanner.hpp"
#include <filesystem>
class RepairPackage {
public:
    static void generate(const ScanReport& scan, const CompatibilityReport& compatibility,
                         const std::filesystem::path& outDir);
};
