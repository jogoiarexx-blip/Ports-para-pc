#pragma once
#include <filesystem>
#include <string>

namespace SafePath {
std::string normalizeOpenBOR(std::string raw);
bool isSafeRelative(const std::filesystem::path& relative);
bool isWithin(const std::filesystem::path& root, const std::filesystem::path& candidate);
std::filesystem::path resolveWithin(const std::filesystem::path& root, const std::string& raw);
}
