#pragma once
#include <filesystem>
#include <string>
#include <vector>

struct HitBoxDef { int x=0,y=0,w=0,h=0; };
struct AttackBoxDef { int x=0,y=0,w=0,h=0,damage=0,type=0,fallForce=0,penetration=0,guardCost=0,juggleCost=0,pauseTime=0,tag=0; };
struct DrawMethodDef {
    bool enabled = false;
    float scaleX = 1.0f;
    float scaleY = 1.0f;
    bool flipX = false;
    bool flipY = false;
    float shiftX = 0.0f;
    int alphaMode = 0;
    int remap = 0;
    int fillColor = 0;
    int rotate = 0;
    bool flipRotate = false;
};
struct FrameDef {
    std::string sprite;
    int delay = 1;
    int offsetX = 0;
    int offsetY = 0;
    bool hasBBox = false;
    HitBoxDef bbox;
    bool hasAttack = false;
    AttackBoxDef attack;
    bool knockdown = false;
    int dropVx = 0;
    int dropVy = -3;
    int pauseTime = 0;
    std::string sound;
    float moveX = 0.0f;
    float moveZ = 0.0f;
    float moveA = 0.0f;
    DrawMethodDef draw;
};
struct CommandDef { std::string sequence; std::string targetAnimation; };
struct CancelDef {
    int startFrame = 0;
    int endFrame = 0;
    int hits = 0;
    std::string command;
    std::string targetAnimation;
};
struct AnimationDef {
    std::string name;
    std::vector<FrameDef> frames;
    bool loop = false;
    int loopStart = 0;
    int loopEnd = -1;
    int flipFrame = -1;
    int jumpFrame = -1;
    float jumpVelocityY = 0.0f;
    float jumpVelocityX = 0.0f;
    float jumpVelocityZ = 0.0f;
    int throwFrame = -1;
    int tossFrame = -1;
    int projectileOffsetY = 70;
    float projectileVelocityX = 2.0f;
    float projectileVelocityY = 0.0f;
    float projectileVelocityZ = 0.0f;
    std::string custKnife;
    std::string custBomb;
    int weaponFrame = -1;
    int weaponIndex = 0;
    int followAnim = 0;
    int followCond = 0;
    int counterStart = -1;
    int counterEnd = -1;
    int counterCond = 0;
    bool counterTakesDamage = true;
    // v0.26: OpenBOR animation activation ranges used by dynamic combostyle=1.
    bool hasRangeX = false;
    float rangeXMin = 0.0f;
    float rangeXMax = 75.0f;
    bool hasRangeZ = false;
    float rangeZMin = 0.0f;
    float rangeZMax = 0.0f;
    bool hasRangeA = false;
    float rangeAMin = -1000.0f;
    float rangeAMax = 1000.0f;
    std::vector<CancelDef> cancels;
    std::string custEntity;
    int spawnFrame = -1;
    float spawnOffsetX = 0.0f;
    float spawnOffsetZ = 0.0f;
    float spawnOffsetA = 0.0f;
    bool spawnScreenRelative = false;
    bool summonFrame = false;
    int unsummonFrame = -1;
};
struct PaletteRemapDef { std::string source; std::string target; };
struct CharacterDef {
    std::string sourceFile;
    std::string modelName; // External registry name from models.txt (load/know alias)
    std::string name;      // Internal OpenBOR name from the model file
    std::string type = "none";
    std::string subtype;
    int health = 100;
    float speed = 1.0f;
    float runSpeed = 0.0f;
    int jumpHeight = 4;
    int jumpMoveX = 0;
    int jumpMoveZ = 0;
    int jugglePoints = 4;
    int grabDistance = 30;
    int blockOdds = -1;
    int blockPain = 0;
    int blockThreshold = 0;
    int guardPoints = 0;
    int guardRate = 2;
    bool blockBack = false;
    // v0.24: Combo, follow/counter/cancel, weapons and child-spawn metadata.
    std::vector<int> attackChain;
    int comboStyle = 0;
    int comboDelay = 100;
    std::string subEntityModel;
    int weaponNumber = 0;
    int shootNum = 0;
    int reloadAmount = 0;
    // v0.25: command-input, weapon loss/drop and child lifecycle/follow compatibility.
    std::vector<CommandDef> commands;
    bool weaponLossDefined = false;
    int weaponLossFlag = 0;
    int weaponLossIndex = 0;
    int weaponDropCounter = 3;
    bool typeShot = false;
    bool animalWeapon = false;
    int summonKill = 0;
    float childFollowOffsetX = 0.0f;
    float childFollowOffsetY = 0.0f;
    float childFollowOffsetZ = 0.0f;
    float childFollowRange = 100.0f;
    float childRecallRange = 300.0f;
    // v0.26: per-axis follow/recall and model-copy compatibility.
    float childFollowRangeXMin = -100.0f, childFollowRangeXMax = 100.0f;
    float childFollowRangeYMin = -100.0f, childFollowRangeYMax = 100.0f;
    float childFollowRangeZMin = -100.0f, childFollowRangeZMax = 100.0f;
    float childRecallRangeXMin = -300.0f, childRecallRangeXMax = 300.0f;
    float childRecallRangeYMin = -300.0f, childRecallRangeYMax = 300.0f;
    float childRecallRangeZMin = -300.0f, childRecallRangeZMax = 300.0f;
    float childRecallOffsetX = 0.0f, childRecallOffsetY = 0.0f, childRecallOffsetZ = 0.0f;
    std::string childRecallAnimation = "respawn";
    int childDirectionAdjust = 0;
    int modelCopyFlags = 0; // 1=no_basic, 2=no_weapon, 4=no_script
    // v0.23: Generic OpenBOR AI/faction/grab/projectile behavior.
    int aggression = 0;
    int aiAttack = 0;
    int aiMove = 1;
    int canDamageMask = 0;
    int hostileMask = 0;
    int projectileHitMask = 0;
    bool noGrab = false;
    int grabForce = 0;
    int grabResistance = 0;
    int throwDamage = 0;
    float throwDistance = 0.0f;
    float throwHeight = 0.0f;
    int bounce = 0;
    float bounceFactor = 0.5f;
    bool subjectToGravity = false;
    std::string knifeModel;
    std::string bombModel;
    std::string projectModel;
    std::vector<std::string> weapons;
    std::string palettePath;
    std::vector<std::string> alternatePalettes;
    std::vector<PaletteRemapDef> paletteRemaps;
    std::vector<AnimationDef> animations;
    std::string thinkScript;
    std::string updateScript;
    std::string keyScript;
    std::string onMoveXScript;
    std::string onMoveZScript;
    std::string onBlockAScript;
    std::string onBlockYScript;
    std::string onBlockZScript;
    std::string onBlockSScript;
    std::string onBlockWScript;
    std::string onBlockOScript;
    std::string onBlockPScript;
    std::string didBlockScript;
    std::string onDoAttackScript;
    std::string onKillScript;
    std::string onEntityCollisionScript;
    std::string onModelCopyScript;
    std::string animationScript;
    std::string takeDamageScript;
    std::string didHitScript;
    std::string onDrawScript;
    std::string onSpawnScript;
    std::string onDeathScript;
    std::string onPainScript;
    std::string onFallScript;
};

class CharacterParser {
public:
    static CharacterDef parse(const std::filesystem::path& file, const std::filesystem::path& root);
    static std::vector<CharacterDef> parseAll(const std::filesystem::path& dataDir, const std::filesystem::path& root);
};
