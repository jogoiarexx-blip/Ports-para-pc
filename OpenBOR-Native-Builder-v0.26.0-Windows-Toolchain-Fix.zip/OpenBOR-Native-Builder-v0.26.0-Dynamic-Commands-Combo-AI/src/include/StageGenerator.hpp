#pragma once
#include "LevelParser.hpp"
#include <filesystem>
#include <vector>
class StageGenerator {
public:
    static void generate(const std::vector<StageDef>& stages, const std::filesystem::path& outDir);
};
