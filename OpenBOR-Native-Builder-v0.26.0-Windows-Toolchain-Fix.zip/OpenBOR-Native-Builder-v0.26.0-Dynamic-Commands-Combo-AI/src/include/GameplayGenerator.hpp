#pragma once
#include "CharacterParser.hpp"
#include <filesystem>
#include <vector>
class GameplayGenerator {
public:
    static void generate(const std::vector<CharacterDef>& characters, const std::filesystem::path& outDir);
};
