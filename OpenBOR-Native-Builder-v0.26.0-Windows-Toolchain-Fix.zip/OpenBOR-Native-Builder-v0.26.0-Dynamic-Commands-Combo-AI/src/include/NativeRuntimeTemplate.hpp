#pragma once
#include <filesystem>
class NativeRuntimeTemplate {
public:
    static void generate(const std::filesystem::path& outDir);
};
