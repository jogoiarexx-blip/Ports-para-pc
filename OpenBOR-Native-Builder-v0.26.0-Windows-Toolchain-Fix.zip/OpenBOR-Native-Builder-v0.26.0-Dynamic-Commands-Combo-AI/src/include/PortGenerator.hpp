#pragma once
#include "ProjectScanner.hpp"
#include "CompatibilityAnalyzer.hpp"
#include <filesystem>

class PortGenerator {
public:
    static void generate(const ScanReport& report, const CompatibilityReport& compatibility,
                         const std::filesystem::path& outDir);
};
