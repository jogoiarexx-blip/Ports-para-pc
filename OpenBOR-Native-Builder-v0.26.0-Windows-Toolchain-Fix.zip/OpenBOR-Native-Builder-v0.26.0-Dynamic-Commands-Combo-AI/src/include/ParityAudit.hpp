#pragma once
#include <filesystem>
#include <iosfwd>
class ParityAudit {
public:
    static void print(std::ostream& out);
    static void writeMarkdown(const std::filesystem::path& path);
};
