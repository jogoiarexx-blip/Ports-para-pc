#pragma once
#include <filesystem>
#include <string>
#include <vector>

struct ResolvedGameInput {
    std::filesystem::path original;
    std::filesystem::path gameRoot;
    std::filesystem::path workspace;
    std::string sourceKind; // folder, zip, pak, openbor-package
    std::vector<std::filesystem::path> discoveredCandidates;
    bool temporary = false;

    ResolvedGameInput() = default;
    ResolvedGameInput(const ResolvedGameInput&) = delete;
    ResolvedGameInput& operator=(const ResolvedGameInput&) = delete;
    ResolvedGameInput(ResolvedGameInput&& other) noexcept;
    ResolvedGameInput& operator=(ResolvedGameInput&& other) noexcept;
    ~ResolvedGameInput();
};

class InputResolver {
public:
    // Accepts a game folder, a ZIP containing an OpenBOR game/engine package,
    // or a bare OpenBOR .pak. For archives, files are unpacked into an isolated
    // temporary workspace and the best game root is selected automatically.
    static ResolvedGameInput resolve(const std::filesystem::path& input);

    // Public for regression tests and diagnostic tools.
    static bool extractOpenBorPak(const std::filesystem::path& pak,
                                  const std::filesystem::path& destination,
                                  std::string* error = nullptr);
};
