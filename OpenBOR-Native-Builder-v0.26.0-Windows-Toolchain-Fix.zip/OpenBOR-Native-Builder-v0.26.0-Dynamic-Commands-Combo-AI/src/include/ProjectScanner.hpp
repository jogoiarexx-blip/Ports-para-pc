#pragma once
#include <filesystem>
#include <string>
#include <vector>

struct ScanReport {
    std::filesystem::path root;
    std::filesystem::path dataDir;
    bool hasDataDir = false;
    bool hasModels = false;
    bool hasLevels = false;
    bool hasMenu = false;
    bool hasVideo = false;
    bool hasLifebar = false;
    bool hasScriptConfig = false;
    bool hasTitleBackground = false;
    bool hasSelectBackground = false;
    bool hasLoadingBackground = false;
    std::size_t files = 0;
    std::size_t images = 0;
    std::size_t audio = 0;
    std::size_t text = 0;
    std::vector<std::string> warnings;
};

class ProjectScanner {
public:
    static ScanReport scan(const std::filesystem::path& root);
};
