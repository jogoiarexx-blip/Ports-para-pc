int helper_value(){
  return 2;
}
