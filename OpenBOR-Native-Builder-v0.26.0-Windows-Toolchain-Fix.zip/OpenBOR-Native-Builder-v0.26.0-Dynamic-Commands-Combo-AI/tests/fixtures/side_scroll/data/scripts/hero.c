#define READY_VALUE 1
#include "data/scripts/helper.c"

void main(){
  void self = getlocalvar("self");
  int hp = getentityproperty(self, "health");
  int loops = 0;
  do {
    loops += 1;
  } while(loops < helper_value());

  switch(loops){
    case 2:
      setlocalvar("ready", READY_VALUE);
      break;
    default:
      setlocalvar("ready", 0);
      break;
  }

  int marker = (hp > 0) ? 3 : 4;
  setlocalvar("marker", marker);
}
