void main(){
  setglobalvar("levelscript_loaded", 1);
}
