#include "LevelParser.hpp"
#include "CharacterParser.hpp"
#include "CompatibilityAnalyzer.hpp"
#include "ProjectScanner.hpp"
#include "CommandRegistry.hpp"
#include "PortGenerator.hpp"
#include "SafePath.hpp"
#include "InputResolver.hpp"
#include <filesystem>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>
#include <cstdint>
#include <cmath>
#include <cstdlib>

static int gFails = 0;
#define CHECK(cond, msg) do { if(!(cond)){ std::cerr << "FAIL: " << msg << "\n"; ++gFails; } else { std::cout << "PASS: " << msg << "\n"; } } while(0)

static void writeU32(std::ofstream& f, std::uint32_t v){ char b[4]={(char)(v&255),(char)((v>>8)&255),(char)((v>>16)&255),(char)((v>>24)&255)}; f.write(b,4); }
static bool createTestPak(const std::filesystem::path& out){
    struct Entry{std::string name,data;std::uint32_t off=0;};
    std::vector<Entry> e={
      {"data/models.txt","know Hero\nload Hero data/chars/hero.txt\n"},
      {"data/levels.txt","set Test\nfile data/levels/stage.txt\n"},
      {"data/chars/hero.txt","name Hero\ntype player\nanim idle\ndelay 8\nframe none\n"},
      {"data/levels/stage.txt","direction right\nspawn Hero\ncoords 10 200 0\nat 0\n"}
    };
    std::ofstream f(out,std::ios::binary|std::ios::trunc);if(!f)return false;f.write("PACK",4);writeU32(f,0);
    for(auto& x:e){x.off=(std::uint32_t)f.tellp();f.write(x.data.data(),(std::streamsize)x.data.size());}
    auto index=(std::uint32_t)f.tellp();for(const auto& x:e){writeU32(f,(std::uint32_t)(12+x.name.size()+1));writeU32(f,x.off);writeU32(f,(std::uint32_t)x.data.size());f.write(x.name.c_str(),(std::streamsize)x.name.size()+1);}
    writeU32(f,index);return (bool)f;
}

int main(){
    namespace fs = std::filesystem;
#ifdef OBNB_SOURCE_DIR
    fs::path sourceDir = OBNB_SOURCE_DIR;
#else
    fs::path sourceDir = fs::current_path();
#endif
    fs::path fixtureA = sourceDir / "tests/fixtures/side_scroll";
    fs::path fixtureB = sourceDir / "tests/fixtures/wide_res";


    auto scanA = ProjectScanner::scan(fixtureA);
    CHECK(scanA.hasDataDir, "fixture A has data/");
    CHECK(scanA.hasModels && scanA.hasLevels && scanA.hasVideo, "fixture A detects models/levels/video");
    auto compA = CompatibilityAnalyzer::analyze(scanA);
    CHECK(compA.logicalWidth==320 && compA.logicalHeight==240, "fixture A resolution 320x240 from video.txt");
    CHECK(compA.models==3, "fixture A models == 3");
    CHECK(compA.stages==2, "fixture A stages == 2");
    CHECK(compA.animations>=6, "fixture A animations parsed");
    CHECK(compA.scripts>=1, "fixture A script counted");
    CHECK(true, "unknown-command accounting checked on fixture B below");

    auto stages = LevelParser::parseAll(scanA.dataDir, scanA.root);
    CHECK(stages.size()==2, "parseAll returns both stages");
    CHECK(stages[0].direction=="right", "stage1 direction");
    CHECK(stages[1].cameraType==1, "stage2 fixed camera from cameratype");
    CHECK(stages[1].direction=="up", "vertical/up direction preserved");
    bool sawBgLayer=false,sawFgLayer=false;
    for(const auto& l:stages[0].layers){
        if(l.kind=="bglayer" && std::abs(l.xRatio-0.25f)<0.001f && l.xSpacing==4 && l.xRepeat==3) sawBgLayer=true;
        if(l.kind=="fglayer" && l.zOrder==25 && std::abs(l.xRatio-0.75f)<0.001f && l.xOffset==5) sawFgLayer=true;
    }
    CHECK(sawBgLayer, "bglayer floating ratio/spacing/repeat parsed with OpenBOR argument order");
    CHECK(sawFgLayer, "fglayer Z depth and floating ratio parsed with correct OpenBOR argument order");
    CHECK(stages[0].levelScript=="scripts/level1.c", "levelscript path preserved");
    CHECK(!stages[0].spawns.empty(), "stage1 has spawns");
    // Sorted by `at`, then declaration id. The 600 spawn must come before boss 700 and late thug 1400.
    CHECK(stages[0].spawns.front().at <= stages[0].spawns.back().at, "spawns sorted by at");
    bool sawBossBeforeLate = false;
    int prevAt = -1;
    for(const auto& s: stages[0].spawns){
        CHECK(s.at>=prevAt, "spawn order is stable and non-decreasing");
        prevAt = s.at;
        if(s.boss && s.at==700) sawBossBeforeLate = true;
        if(s.at==1400) CHECK(sawBossBeforeLate, "boss at 700 is ordered before thug at 1400 even if declared earlier");
        if(s.model=="Boss" && s.at==700) CHECK(s.boss, "boss flag sticks to the boss spawn");
        if(s.alias=="EarlyThug"){ CHECK(s.item=="knife", "item drop stays on the spawn"); CHECK(s.map=="2", "colormap preserved"); }
    }
    bool sawWait=false, sawBlock=false;
    for(const auto& ev: stages[0].events){
        if(ev.kind=="wait") sawWait=true;
        if(ev.kind=="blockade") sawBlock=true;
        CHECK(ev.state==SpawnState::NotTriggered, "events start NOT_TRIGGERED");
    }
    CHECK(sawWait && sawBlock, "wait and blockade captured as one-shot events");

    // Canonical OpenBOR event form: wait/group/blockade can bind to the immediately
    // following `at`, while blockade keeps its own backtracking floor value.
    fs::path eventRoot="/tmp/obor-v018-event-fixture";
    fs::remove_all(eventRoot); fs::create_directories(eventRoot/"data/levels");
    {
        std::ofstream f(eventRoot/"data/levels/events.txt");
        f << "wait\n";
        f << "at 100\n";
        f << "group 2 5\n";
        f << "at 200\n";
        f << "blockade 150\n";
        f << "at 250\n";
    }
    LevelSetDef eventSet; eventSet.name="Events";
    auto eventStage=LevelParser::parseStage(eventRoot/"data/levels/events.txt",eventRoot,eventSet);
    bool canonicalWait=false, canonicalGroup=false, canonicalBlockade=false;
    for(const auto& ev:eventStage.events){
        if(ev.kind=="wait" && ev.hasAt && ev.at==100) canonicalWait=true;
        if(ev.kind=="group" && ev.hasAt && ev.at==200 && ev.value==2 && ev.group==5) canonicalGroup=true;
        if(ev.kind=="blockade" && ev.hasAt && ev.at==250 && ev.value==150) canonicalBlockade=true;
    }
    CHECK(canonicalWait, "canonical wait + at binding");
    CHECK(canonicalGroup, "canonical group min/max + at binding");
    CHECK(canonicalBlockade, "canonical blockade floor + distinct at binding");

    // v0.20 campaign branching: OpenBOR branch labels live in levels.txt and label
    // the next `file` entry. Per-file z settings must also follow the order list.
    fs::path branchRoot="/tmp/obor-v020-branch-fixture";
    fs::remove_all(branchRoot); fs::create_directories(branchRoot/"data/levels");
    {
        std::ofstream f(branchRoot/"data/levels.txt");
        f << "set Route\n";
        f << "branch start\n";
        f << "z 100 180 90\n";
        f << "file data/levels/a.txt\n";
        f << "z 210 300 170\n";
        f << "branch alternate\n";
        f << "file data/levels/b.txt\n";
    }
    {std::ofstream(branchRoot/"data/levels/a.txt") << "direction right\n"; std::ofstream(branchRoot/"data/levels/b.txt") << "direction right\n";}
    auto branchStages=LevelParser::parseAll(branchRoot/"data",branchRoot);
    CHECK(branchStages.size()==2, "levels.txt branch fixture parses both stages");
    if(branchStages.size()==2){
        CHECK(branchStages[0].branchName=="start", "branch label attaches to first following file");
        CHECK(branchStages[1].branchName=="alternate", "second branch label attaches to its following file");
        CHECK(branchStages[0].zMin==100 && branchStages[0].zMax==180 && branchStages[0].backgroundHeight==90, "per-level z metadata preserved for first branch");
        CHECK(branchStages[1].zMin==210 && branchStages[1].zMax==300 && branchStages[1].backgroundHeight==170, "per-level z metadata preserved after z change");
    }
    CHECK(!stages[0].instructions.empty(), "unified stage instruction stream generated");
    if(stages[0].instructions.size()>=5){
        for(std::size_t i=1;i<stages[0].instructions.size();++i) CHECK(stages[0].instructions[i-1].sequence < stages[0].instructions[i].sequence, "stage instruction order preserves source sequence");
        CHECK(stages[0].instructions[0].kind==0 && stages[0].instructions[1].kind==0 && stages[0].instructions[2].kind==1, "spawn/event cross-type order is preserved");
    }

    auto chars = CharacterParser::parseAll(scanA.dataDir, scanA.root);
    const CharacterDef* bossAlias=nullptr;
    for(const auto& c: chars) if(c.modelName=="Boss") bossAlias=&c;
    CHECK(bossAlias!=nullptr, "models.txt registry alias is preserved");
    if(bossAlias) CHECK(bossAlias->name=="BossGeneric", "registry alias can differ from internal model name");
    const CharacterDef* hero=nullptr;
    for(const auto& c: chars) if(c.type=="player") hero=&c;
    CHECK(hero!=nullptr, "player model detected by type, not by name");
    if(hero){
        CHECK(hero->health==120, "hero health");
        bool sawInfinite=false, sawNone=false, sawAttack=false;
        for(const auto& a: hero->animations){
            for(const auto& f: a.frames){
                if(f.delay<0) sawInfinite=true;
                if(f.sprite=="none") sawNone=true;
                if(f.hasAttack) sawAttack=true;
            }
        }
        CHECK(sawInfinite, "delay infinite");
        CHECK(sawNone, "frame none");
        CHECK(sawAttack, "per-frame attack box");
        CHECK(!hero->animationScript.empty(), "animationscript recorded");
        bool sawFlipFrame=false;
        for(const auto& a:hero->animations) if(a.name=="walk" && a.flipFrame==1) sawFlipFrame=true;
        CHECK(sawFlipFrame, "flipframe parsed into animation metadata");
    }


    // v0.20 palette/remap parsing: image- and ACT-based references are preserved
    // so the generated runtime can select per-entity/per-player color maps.
    fs::path paletteRoot="/tmp/obor-v020-palette-fixture";
    fs::remove_all(paletteRoot); fs::create_directories(paletteRoot/"data/chars");
    fs::path paletteModel=paletteRoot/"data/chars/colorhero.txt";
    {
        std::ofstream f(paletteModel);
        f << "name ColorHero\n";
        f << "type player\n";
        f << "palette data/palettes/base.act\n";
        f << "alternatepal data/palettes/blue.act\n";
        f << "remap data/palettes/source.gif data/palettes/red.gif\n";
        f << "anim idle\ndelay 8\nframe none\n";
    }
    { std::ofstream f(paletteRoot/"data/models.txt"); f << "load ColorHeroAlias data/chars/colorhero.txt\n"; }
    auto colorChars=CharacterParser::parseAll(paletteRoot/"data",paletteRoot);
    CHECK(colorChars.size()==1, "palette fixture model registered through models.txt");
    if(!colorChars.empty()){
        const auto& colorHero=colorChars.front();
        CHECK(colorHero.modelName=="ColorHeroAlias", "palette fixture keeps external model alias");
        CHECK(colorHero.palettePath=="palettes/base.act", "base palette path normalized relative to data/");
        CHECK(colorHero.alternatePalettes.size()==1 && colorHero.alternatePalettes[0]=="palettes/blue.act", "alternatepal parsed and normalized");
        CHECK(colorHero.paletteRemaps.size()==1 && colorHero.paletteRemaps[0].source=="palettes/source.gif" && colorHero.paletteRemaps[0].target=="palettes/red.gif", "remap source/target parsed and normalized");
    }

    auto info = CommandRegistry::lookup("animationscript");
    CHECK(info.parser && info.status==CommandStatus::Partial, "animationscript is PARTIAL (parser yes, runtime partial) not fake SUPPORTED");
    auto delay = CommandRegistry::lookup("delay");
    CHECK(delay.status==CommandStatus::Supported && delay.runtime, "delay is SUPPORTED with runtime");
    auto flipframe = CommandRegistry::lookup("flipframe");
    CHECK(flipframe.status==CommandStatus::Supported && flipframe.runtime, "flipframe is SUPPORTED with runtime");
    auto levelscript = CommandRegistry::lookup("levelscript");
    CHECK(levelscript.parser && levelscript.runtime && levelscript.status==CommandStatus::Partial, "levelscript is executed with ScriptVM and honestly marked PARTIAL");
    bool falseScriptWarning=false;
    for(const auto& issue:compA.issues) if(issue.command=="script-file") falseScriptWarning=true;
    CHECK(!falseScriptWarning, "supported switch/do/include script has no false script-file warning");
    fs::path macroRoot="/tmp/obor-v020-macro-fixture"; fs::remove_all(macroRoot); fs::create_directories(macroRoot/"data");
    {std::ofstream(macroRoot/"data/models.txt") << "load Hero data/hero.txt\n"; std::ofstream(macroRoot/"data/levels.txt") << "set T\nfile data/stage.txt\n"; std::ofstream(macroRoot/"data/hero.txt") << "name Hero\ntype player\nanim idle\nframe none\n"; std::ofstream(macroRoot/"data/stage.txt") << "levelscript data/test.c\n"; std::ofstream(macroRoot/"data/test.c") << "#define TWICE(x) ((x)+(x))\nvoid main(){ int a=TWICE(4); log(a); }\n";}
    auto macroScan=ProjectScanner::scan(macroRoot); auto macroComp=CompatibilityAnalyzer::analyze(macroScan); bool macroWarning=false; for(const auto&i:macroComp.issues) if(i.command=="script-file") macroWarning=true; CHECK(!macroWarning, "function-like #define is recognized by compatibility analyzer");
    // v0.21 script-event coverage: model key/move/collision hooks and spawn-entry scripts
    // are not only preserved; the generated runtime has dedicated firing paths for them.
    fs::path scriptRoot="/tmp/obor-v021-script-hooks";fs::remove_all(scriptRoot);fs::create_directories(scriptRoot/"data/chars");fs::create_directories(scriptRoot/"data/levels");fs::create_directories(scriptRoot/"data/scripts");
    {std::ofstream(scriptRoot/"data/models.txt") << "load HookHero data/chars/hookhero.txt\n";std::ofstream(scriptRoot/"data/levels.txt") << "set H\nfile data/levels/h.txt\n";
     std::ofstream(scriptRoot/"data/chars/hookhero.txt") << "name HookHero\ntype player\nkeyscript data/scripts/keymodel.c\nonmovexscript data/scripts/movex.c\nonmovezscript data/scripts/movez.c\nonentitycollision data/scripts/collision.c\ntakedamagescript data/scripts/take.c\ndidhitscript data/scripts/hit.c\nanim idle\ndelay 8\nframe none\n";
     std::ofstream(scriptRoot/"data/levels/h.txt") << "spawn HookHero\ncoords 40 200 0\nspawnscript data/scripts/spawn.c\nat 0\n";
     std::ofstream(scriptRoot/"data/scripts/keymodel.c") << "void main(){ int p=getlocalvar(\"player\"); if(playerkeys(p,1,\"attack\")){ void self=getlocalvar(\"self\"); setentityvar(self,\"pressed\",1); updateframe(self,0); } }\n";
     std::ofstream(scriptRoot/"data/scripts/movex.c") << "void main(){ void self=getlocalvar(\"self\"); changeentityproperty(self,\"velocity\",0,0,0); }\n";
     std::ofstream(scriptRoot/"data/scripts/movez.c") << "void main(){ void self=getlocalvar(\"self\"); setidle(self); }\n";
     std::ofstream(scriptRoot/"data/scripts/collision.c") << "void main(){ void self=getlocalvar(\"self\"); void target=findtarget(self); if(target && checkrange(self,target)){ setentityvar(self,\"near\",1); } }\n";
     std::ofstream(scriptRoot/"data/scripts/take.c") << "void main(){ void attacker=getlocalvar(\"attacker\"); int damage=getlocalvar(\"damage\"); log(damage); }\n";
     std::ofstream(scriptRoot/"data/scripts/hit.c") << "void main(){ void target=getlocalvar(\"damagetaker\"); int t=getlocalvar(\"attacktype\"); log(t); }\n";
     std::ofstream(scriptRoot/"data/scripts/spawn.c") << "void main(){ void self=getlocalvar(\"self\"); setentityvar(self,\"spawnx\",getlocalvar(\"spawnx\")); }\n";
     std::ofstream(scriptRoot/"data/scripts/key1.c") << "void main(){ setglobalvar(\"global_key_seen\",1); }\n";
     std::ofstream(scriptRoot/"data/scripts/keyall.c") << "void main(){ setglobalvar(\"keyall_seen\",1); }\n";}
    auto hookScan=ProjectScanner::scan(scriptRoot);auto hookChars=CharacterParser::parseAll(hookScan.dataDir,hookScan.root);auto hookStages=LevelParser::parseAll(hookScan.dataDir,hookScan.root);auto hookComp=CompatibilityAnalyzer::analyze(hookScan);
    CHECK(hookChars.size()==1 && hookChars[0].keyScript=="data/scripts/keymodel.c", "keyscript parsed for player model");
    CHECK(!hookChars.empty() && !hookChars[0].onMoveXScript.empty() && !hookChars[0].onMoveZScript.empty() && !hookChars[0].onEntityCollisionScript.empty(), "move/collision model hooks parsed");
    CHECK(!hookStages.empty() && !hookStages[0].spawns.empty() && hookStages[0].spawns[0].spawnScript=="scripts/spawn.c", "spawnscript parsed and normalized on spawn entry");
    auto keyInfo=CommandRegistry::lookup("keyscript"), spawnScriptInfo=CommandRegistry::lookup("spawnscript");
    CHECK(keyInfo.runtime && keyInfo.status==CommandStatus::Partial, "keyscript now has a runtime firing path");
    CHECK(spawnScriptInfo.runtime && spawnScriptInfo.status==CommandStatus::Partial, "spawnscript now has a runtime firing path");
    bool hookApiWarning=false;for(const auto&i:hookComp.issues)if(i.command=="script-file")hookApiWarning=true;CHECK(!hookApiWarning, "v0.21 supported script APIs do not produce false compatibility warnings");


    // v0.22 block/guard + direct drawing + modern property constants.
    fs::path blockRoot="/tmp/obor-v022-block-fixture";fs::remove_all(blockRoot);fs::create_directories(blockRoot/"data/chars");fs::create_directories(blockRoot/"data/levels");fs::create_directories(blockRoot/"data/scripts");
    {std::ofstream(blockRoot/"data/models.txt") << "load Guard data/chars/guard.txt\n";std::ofstream(blockRoot/"data/levels.txt") << "set B\nfile data/levels/b.txt\n";
     std::ofstream(blockRoot/"data/chars/guard.txt") << "name Guard\ntype enemy\nblockodds 3\nblockpain 12\nthold 4\nguardpoints 40\nguardrate 2\nblockback 1\ndidblockscript data/scripts/block.c\nonblockwscript data/scripts/wall.c\nanim idle\nframe none\nanim block\nframe none\n";
     std::ofstream(blockRoot/"data/levels/b.txt") << "spawn Guard\ncoords 80 200 0\nat 0\n";
     std::ofstream(blockRoot/"data/scripts/block.c") << "void main(){ void self=getlocalvar(\"self\"); void m=getentityproperty(self,openborconstant(\"ENTITY_PROPERTY_MODELDATA\")); int gp=getentityproperty(self,openborconstant(\"ENTITY_PROPERTY_GUARD_POINTS\")); drawbox(4,4,32,6,100,rgbcolor(30,200,80)); drawline(4,12,36,12,101,rgbcolor(255,255,255)); log(getmodelproperty(m,openborconstant(\"MODEL_PROPERTY_BLOCK_ODDS\"))); }\n";
     std::ofstream(blockRoot/"data/scripts/wall.c") << "void main(){ drawdot(1,1,100,rgbcolor(255,0,0)); }\n";}
    auto blockScan=ProjectScanner::scan(blockRoot);auto blockChars=CharacterParser::parseAll(blockScan.dataDir,blockScan.root);auto blockComp=CompatibilityAnalyzer::analyze(blockScan);
    CHECK(blockChars.size()==1, "v0.22 blocking fixture model parsed");
    if(!blockChars.empty()){CHECK(blockChars[0].blockOdds==3 && blockChars[0].blockPain==12 && blockChars[0].blockThreshold==4, "block odds/pain/threshold parsed");CHECK(blockChars[0].guardPoints==40 && blockChars[0].guardRate==2 && blockChars[0].blockBack, "guard points/rate/blockback parsed");CHECK(!blockChars[0].didBlockScript.empty() && !blockChars[0].onBlockWScript.empty(), "didblock and wall block hooks parsed");}
    CHECK(CommandRegistry::lookup("guardpoints").runtime, "guardpoints registered as runtime-supported");
    CHECK(CommandRegistry::lookup("didblockscript").runtime, "didblockscript has runtime firing path");
    bool blockApiWarning=false;for(const auto&i:blockComp.issues)if(i.command=="script-file")blockApiWarning=true;CHECK(!blockApiWarning, "v0.22 drawing/model-property APIs do not produce false warnings");

    // v0.23 advanced combat/AI/projectile model metadata.
    fs::path aiRoot="/tmp/obor-v023-ai-fixture";fs::remove_all(aiRoot);fs::create_directories(aiRoot/"data/chars");fs::create_directories(aiRoot/"data/levels");fs::create_directories(aiRoot/"data/scripts");
    {std::ofstream(aiRoot/"data/models.txt") << "load Hunter data/chars/hunter.txt\n";std::ofstream(aiRoot/"data/levels.txt") << "set AI\nfile data/levels/ai.txt\n";
     std::ofstream(aiRoot/"data/chars/hunter.txt") << "name Hunter\ntype enemy\naggression 42\naiattack 131081\naimove 65538\ncandamage 4\nhostile 4\nprojectilehit 8\nnograb 1\ngrabforce 5\ngrabresistance 7\nthrowdamage 33\nthrowdist 48\nthrowheight 6\nbounce 2\nbouncefactor 0.6\nsubject_to_gravity 1\nondoattackscript data/scripts/attack.c\nanim idle\nframe none\nanim attack1\nattack 0 0 20 20 5\nframe none\nanim attack4\nattack4 0 0 20 20 8\nframe none\n";
     std::ofstream(aiRoot/"data/levels/ai.txt") << "spawn Hunter\ncoords 80 200 0\nat 0\n";std::ofstream(aiRoot/"data/scripts/attack.c") << "void main(){ performattack(getlocalvar(\"self\"), \"attack4\"); }\n";}
    auto aiScan=ProjectScanner::scan(aiRoot);auto aiChars=CharacterParser::parseAll(aiScan.dataDir,aiScan.root);
    CHECK(aiChars.size()==1, "v0.23 AI fixture model parsed");
    if(!aiChars.empty()){const auto& c=aiChars[0];CHECK(c.aggression==42 && c.aiAttack==131081 && c.aiMove==65538, "aggression/aiattack/aimove parsed");CHECK(c.canDamageMask==4 && c.hostileMask==4 && c.projectileHitMask==8, "faction/projectile masks parsed");CHECK(c.noGrab && c.grabForce==5 && c.grabResistance==7, "grab restrictions parsed");CHECK(c.throwDamage==33 && std::abs(c.throwDistance-48.0f)<0.001f && std::abs(c.throwHeight-6.0f)<0.001f, "model throw tuning parsed");CHECK(c.bounce==2 && std::abs(c.bounceFactor-0.6f)<0.001f && c.subjectToGravity, "projectile gravity/bounce parsed");CHECK(!c.onDoAttackScript.empty(), "ondoattackscript preserved");}
    CHECK(CommandRegistry::lookup("aiattack").runtime && CommandRegistry::lookup("aimove").runtime, "AI commands registered for runtime");
    CHECK(CommandRegistry::lookup("projectilehit").runtime && CommandRegistry::lookup("bouncefactor").runtime, "projectile behavior commands registered for runtime");
    CHECK(CommandRegistry::lookup("ondoattackscript").runtime, "ondoattackscript has runtime firing path");
    fs::path aiOut="/tmp/obor-v023-ai-port";fs::remove_all(aiOut);auto aiComp=CompatibilityAnalyzer::analyze(aiScan);PortGenerator::generate(aiScan,aiComp,aiOut);
    {std::ifstream in(aiOut/"runtime/src/Engine.cpp");std::string body((std::istreambuf_iterator<char>(in)),{});CHECK(body.find("AI_NOATTACK")!=std::string::npos && body.find("highestAttackIndex")!=std::string::npos, "generated runtime contains advanced AI and attack4+ combo logic");CHECK(body.find("Projectile bounce")!=std::string::npos && body.find("targetAllowed")!=std::string::npos, "generated runtime contains bounce/faction-aware projectile logic");CHECK(body.find("script-player-performattack")!=std::string::npos && body.find("entity-ondoattack")!=std::string::npos, "performattack/ondoattack are stateful runtime events");CHECK(body.find("cp.equippedWeapon")!=std::string::npos && body.find("tryPickupWeapon(cp)")!=std::string::npos, "coop players keep independent equipped-weapon/projectile state");}


    // v0.24 combo/cancel/follow/counter + weapon model + child spawn parity.
    fs::path comboRoot="/tmp/obor-v024-combo-fixture";fs::remove_all(comboRoot);fs::create_directories(comboRoot/"data/chars");fs::create_directories(comboRoot/"data/levels");
    {std::ofstream(comboRoot/"data/models.txt") << "load ComboHero data/chars/combo.txt\nload BladeGun data/chars/weapon.txt\nload Minion data/chars/minion.txt\nload Bullet data/chars/bullet.txt\n";
     std::ofstream(comboRoot/"data/levels.txt") << "set C\nfile data/levels/c.txt\n";
     std::ofstream(comboRoot/"data/chars/combo.txt") << "name ComboHero\ntype player\natchain 1 1 2 3\ncombostyle 2\ncombodelay 80\nweapons BladeGun\nsubentity Minion\nanim idle\nframe none\nanim attack1\nfollowanim 2\nfollowcond 3\ncounterrange 0 2 3 0\ncancel 0 2 1 a2 freespecial2\ncustentity Minion\nspawnframe 1 12 3 0 0\nweaponframe 1 1\nattack 0 0 20 20 5\nframe none\nframe none\nanim attack2\nattack 0 0 20 20 6\nframe none\nanim attack3\nattack 0 0 20 20 7\nframe none\nanim follow2\nattack 0 0 22 20 9\nframe none\nanim freespecial2\nattack 0 0 24 20 10\nframe none\n";
     std::ofstream(comboRoot/"data/chars/weapon.txt") << "name BladeGun\ntype none\nshootnum 3\nproject Bullet\nanim idle\nframe none\nanim attack1\nthrowframe 0 0 3 0\nframe none\n";
     std::ofstream(comboRoot/"data/chars/minion.txt") << "name Minion\ntype enemy\nanim idle\nframe none\n";
     std::ofstream(comboRoot/"data/chars/bullet.txt") << "name Bullet\ntype projectile\nanim idle\nattack 0 0 8 8 3\nframe none\n";
     std::ofstream(comboRoot/"data/levels/c.txt") << "spawn ComboHero\ncoords 60 200 0\nat 0\n";}
    auto comboScan=ProjectScanner::scan(comboRoot);auto comboChars=CharacterParser::parseAll(comboScan.dataDir,comboScan.root);const CharacterDef* comboHero=nullptr;const CharacterDef* weaponModel=nullptr;for(const auto&c:comboChars){if(c.modelName=="ComboHero")comboHero=&c;if(c.modelName=="BladeGun")weaponModel=&c;}
    CHECK(comboHero!=nullptr && weaponModel!=nullptr, "v0.24 combo/weapon fixture models parsed");
    if(comboHero){CHECK(comboHero->attackChain.size()==4 && comboHero->attackChain[0]==1 && comboHero->attackChain[2]==2 && comboHero->comboStyle==2 && comboHero->comboDelay==80, "atchain/combostyle/combodelay metadata preserved");CHECK(comboHero->weapons.size()==1 && comboHero->weapons[0]=="BladeGun" && comboHero->subEntityModel=="Minion", "weapon list and subentity metadata preserved");bool advancedAnim=false;for(const auto&a:comboHero->animations)if(a.name=="attack1"){advancedAnim=a.followAnim==2&&a.followCond==3&&a.counterStart==0&&a.counterEnd==2&&!a.counterTakesDamage&&!a.cancels.empty()&&a.spawnFrame==1&&a.weaponFrame==1;}CHECK(advancedAnim,"follow/counter/cancel/spawnframe/weaponframe parsed on animation");}
    if(weaponModel)CHECK(weaponModel->shootNum==3 && weaponModel->projectModel=="Bullet", "limited-use weapon model and projectile parsed");
    CHECK(CommandRegistry::lookup("atchain").runtime && CommandRegistry::lookup("cancel").runtime && CommandRegistry::lookup("counterrange").runtime, "combo/cancel/counter commands have runtime paths");
    CHECK(CommandRegistry::lookup("weapons").runtime && CommandRegistry::lookup("spawnframe").runtime && CommandRegistry::lookup("summonframe").runtime, "weapon/child-spawn commands have runtime paths");
    fs::path comboOut="/tmp/obor-v024-combo-port";fs::remove_all(comboOut);auto comboComp=CompatibilityAnalyzer::analyze(comboScan);PortGenerator::generate(comboScan,comboComp,comboOut);
    {std::ifstream in(comboOut/"runtime/src/Engine.cpp");std::string body((std::istreambuf_iterator<char>(in)),{});CHECK(body.find("cancelTarget")!=std::string::npos && body.find("counterFor")!=std::string::npos && body.find("followConditionPass")!=std::string::npos, "generated runtime contains cancel/counter/follow execution");CHECK(body.find("findActionAnimation")!=std::string::npos && body.find("weaponUses")!=std::string::npos, "generated runtime overlays weapon animations and limited uses");CHECK(body.find("summonedChild")!=std::string::npos && body.find("queueChildSpawn")!=std::string::npos, "generated runtime contains spawnframe/summonframe child lifecycle");}


    // v0.25 native command history + weapon loss/drop + child lifecycle/follow metadata.
    fs::path lifeRoot="/tmp/obor-v025-lifecycle-fixture";fs::remove_all(lifeRoot);fs::create_directories(lifeRoot/"data/chars");fs::create_directories(lifeRoot/"data/levels");
    {std::ofstream(lifeRoot/"data/models.txt") << "load LifeHero data/chars/hero.txt\nload GunModel data/chars/gun.txt\nload GunItem data/chars/item.txt\nload Pet data/chars/pet.txt\n";
     std::ofstream(lifeRoot/"data/levels.txt") << "set L\nfile data/levels/l.txt\n";
     std::ofstream(lifeRoot/"data/chars/hero.txt") << "name LifeHero\ntype player\nweapons GunModel LifeHero\nweaploss 1 0\ncom f a 1\nsubentity Pet\nsummonkill 1\nanim idle\nframe none\nanim attack1\nsummonframe 0 8 0 0 0\nunsummonframe 1\nframe none\nframe none\nanim freespecial1\nattack 0 0 20 20 9\nframe none\n";
     std::ofstream(lifeRoot/"data/chars/gun.txt") << "name GunModel\ntype none\nshootnum 2\ntypeshot 1\nweaploss 2 0\nanim idle\nframe none\nanim attack1\nframe none\n";
     std::ofstream(lifeRoot/"data/chars/item.txt") << "name GunItem\ntype item\nsubtype weapon\nweapnum 1\ncounter 3\nanim idle\nframe none\nanim respawn\nframe none\n";
     std::ofstream(lifeRoot/"data/chars/pet.txt") << "name Pet\ntype npc\nsubtype follow\nchild_follow_offset_x 18\nchild_follow_offset_z 4\nchild_follow_range_base_max 90\nchild_follow_range_recall_base_max 260\nanim idle\nframe none\nanim walk\nframe none\n";
     std::ofstream(lifeRoot/"data/levels/l.txt") << "spawn GunItem\ncoords 80 200 0\nat 0\n";}
    auto lifeScan=ProjectScanner::scan(lifeRoot);auto lifeChars=CharacterParser::parseAll(lifeScan.dataDir,lifeScan.root);const CharacterDef*lifeHero=nullptr,*gun=nullptr,*item=nullptr,*pet=nullptr;for(const auto&c:lifeChars){if(c.modelName=="LifeHero")lifeHero=&c;else if(c.modelName=="GunModel")gun=&c;else if(c.modelName=="GunItem")item=&c;else if(c.modelName=="Pet")pet=&c;}
    CHECK(lifeHero&&gun&&item&&pet,"v0.25 lifecycle fixture models parsed");
    if(lifeHero){CHECK(lifeHero->commands.size()==1&&lifeHero->commands[0].sequence=="f a"&&lifeHero->commands[0].targetAnimation=="1","com command sequence/target parsed");CHECK(lifeHero->weaponLossDefined&&lifeHero->weaponLossFlag==1&&lifeHero->summonKill==1,"base weaploss and summonkill parsed");bool lifeAnim=false;for(const auto&a:lifeHero->animations)if(a.name=="attack1")lifeAnim=a.summonFrame&&a.spawnFrame==0&&a.unsummonFrame==1;CHECK(lifeAnim,"summonframe + unsummonframe parsed");}
    if(gun)CHECK(gun->weaponLossDefined&&gun->weaponLossFlag==2&&gun->shootNum==2&&gun->typeShot,"weapon-specific weaploss overrides base and typeshot parsed");
    if(item)CHECK(item->weaponDropCounter==3&&item->weaponNumber==1,"weapon pickup drop counter/index parsed");
    if(pet)CHECK(std::abs(pet->childFollowOffsetX-18.0f)<0.01f&&std::abs(pet->childFollowRange-90.0f)<0.01f&&std::abs(pet->childRecallRange-260.0f)<0.01f,"child follow/recall tuning parsed");
    CHECK(CommandRegistry::lookup("com").runtime&&CommandRegistry::lookup("weaploss").runtime&&CommandRegistry::lookup("unsummonframe").runtime,"v0.25 command/weapon-loss/child-lifecycle registry paths active");
    fs::path lifeOut="/tmp/obor-v025-lifecycle-port";fs::remove_all(lifeOut);auto lifeComp=CompatibilityAnalyzer::analyze(lifeScan);PortGenerator::generate(lifeScan,lifeComp,lifeOut);
    {std::ifstream in(lifeOut/"runtime/src/Engine.cpp");std::string body((std::istreambuf_iterator<char>(in)),{});CHECK(body.find("commandTarget")!=std::string::npos&&body.find("recordInputHistory")!=std::string::npos,"generated runtime contains native COM input history matcher");CHECK(body.find("dropPlayerWeapon")!=std::string::npos&&body.find("flushWeaponDrops")!=std::string::npos,"generated runtime contains physical weapon loss/drop lifecycle");CHECK(body.find("unsummonChildren")!=std::string::npos&&body.find("updateChildFollowing")!=std::string::npos,"generated runtime contains unsummon and child follow/recall lifecycle");}


    // v0.26 timed commands, dynamic combostyle=1, per-axis child follow and model-copy flags.
    fs::path v26Root="/tmp/obor-v026-command-combo-fixture";fs::remove_all(v26Root);fs::create_directories(v26Root/"data/chars");fs::create_directories(v26Root/"data/levels");
    {std::ofstream(v26Root/"data/models.txt") << "load DynamicHero data/chars/hero.txt\nload NoBasicWeapon data/chars/weapon.txt\nload SmartPet data/chars/pet.txt\n";
     std::ofstream(v26Root/"data/levels.txt") << "set V26\nfile data/levels/l.txt\n";
     std::ofstream(v26Root/"data/chars/hero.txt") << "name DynamicHero\ntype player\natchain 1 2 5 0 3 3 6 0 4 0\ncombostyle 1\ncombodelay 90\nweapons NoBasicWeapon\ncom f[3][8] + a -> b +[2] -> ~a :[10] 1\nanim idle\nframe none\nanim attack1\nrange 0 20\nframe none\nanim attack2\nrange 0 28\nrangez 0 12\nframe none\nanim attack3\nrange 29 60\nframe none\nanim attack4\nrange 61 120\nframe none\nanim attack5\nframe none\nanim attack6\nframe none\nanim freespecial1\nframe none\n";
     std::ofstream(v26Root/"data/chars/weapon.txt") << "name NoBasicWeapon\ntype none\nmodelflag no_basic no_script\nanim attack1\nframe none\n";
     std::ofstream(v26Root/"data/chars/pet.txt") << "name SmartPet\ntype npc\nsubtype follow\nchild_follow_offset_x 10\nchild_follow_range_x_min -30\nchild_follow_range_x_max 40\nchild_follow_range_z_min -12\nchild_follow_range_z_max 12\nchild_follow_range_recall_x_min -150\nchild_follow_range_recall_x_max 170\nchild_follow_recall_offset_x 6\nchild_follow_recall_offset_z 3\nchild_follow_recall_animation spawn\nchild_follow_direction_adjust_config toward\nanim idle\nframe none\nanim walk\nframe none\nanim spawn\nframe none\n";
     std::ofstream(v26Root/"data/levels/l.txt") << "spawn SmartPet\ncoords 100 200 0\nat 0\n";}
    auto v26Scan=ProjectScanner::scan(v26Root);auto v26Chars=CharacterParser::parseAll(v26Scan.dataDir,v26Scan.root);const CharacterDef*dyn=nullptr,*noBasic=nullptr,*smartPet=nullptr;for(const auto&c:v26Chars){if(c.modelName=="DynamicHero")dyn=&c;else if(c.modelName=="NoBasicWeapon")noBasic=&c;else if(c.modelName=="SmartPet")smartPet=&c;}
    CHECK(dyn&&noBasic&&smartPet,"v0.26 dynamic command/combo fixture models parsed");
    if(dyn){CHECK(dyn->comboStyle==1&&dyn->attackChain.size()==10&&dyn->attackChain[3]==0,"combostyle=1 preserves zero-separated atchain branches");CHECK(dyn->commands.size()==1&&dyn->commands[0].sequence.find("f[3][8]")!=std::string::npos&&dyn->commands[0].sequence.find(":[10]")!=std::string::npos,"timed hold/chord/sequence command syntax preserved");bool range2=false,range3=false;for(const auto&a:dyn->animations){if(a.name=="attack2")range2=a.hasRangeX&&a.hasRangeZ&&std::abs(a.rangeXMax-28.0f)<0.01f;if(a.name=="attack3")range3=a.hasRangeX&&std::abs(a.rangeXMin-29.0f)<0.01f;}CHECK(range2&&range3,"range/rangez metadata parsed for dynamic combo branches");}
    if(noBasic)CHECK((noBasic->modelCopyFlags&1)!=0&&(noBasic->modelCopyFlags&4)!=0,"modelflag no_basic/no_script parsed");
    if(smartPet)CHECK(std::abs(smartPet->childFollowRangeXMin+30.0f)<0.01f&&std::abs(smartPet->childRecallRangeXMax-170.0f)<0.01f&&smartPet->childRecallAnimation=="spawn"&&smartPet->childDirectionAdjust==6,"per-axis child follow/recall/direction metadata parsed");
    CHECK(CommandRegistry::lookup("range").runtime&&CommandRegistry::lookup("modelflag").runtime,"v0.26 dynamic range/model-copy registry paths active");
    fs::path v26Out="/tmp/obor-v026-command-combo-port";fs::remove_all(v26Out);auto v26Comp=CompatibilityAnalyzer::analyze(v26Scan);PortGenerator::generate(v26Scan,v26Comp,v26Out);
    {std::ifstream in(v26Out/"runtime/src/Engine.cpp");std::string body((std::istreambuf_iterator<char>(in)),{});CHECK(body.find("ParsedCommandStep")!=std::string::npos&&body.find("holdTrigger")!=std::string::npos&&body.find("sequenceGrace")!=std::string::npos,"generated runtime contains timed OpenBOR command matcher");CHECK(body.find("dynamicChainAttackNumber")!=std::string::npos&&body.find("attackRangePass")!=std::string::npos,"generated runtime contains combostyle=1 range branch selection");CHECK(body.find("tryEntityPickupWeapon")!=std::string::npos,"generated runtime contains AI weapon seek/pickup path");CHECK(body.find("childRecallOffsetX")!=std::string::npos&&body.find("childDirectionAdjust")!=std::string::npos,"generated runtime contains advanced child follow/recall behavior");}

    auto mystery = CommandRegistry::lookup("customwave");
    CHECK(mystery.status==CommandStatus::Unknown, "customwave is UNKNOWN");

    auto scanB = ProjectScanner::scan(fixtureB);
    auto compB = CompatibilityAnalyzer::analyze(scanB);
    CHECK(compB.logicalWidth==480 && compB.logicalHeight==272, "fixture B resolution is not hardcoded 320x240");
    auto stagesB = LevelParser::parseAll(scanB.dataDir, scanB.root);
    CHECK(stagesB.size()==1, "fixture B one stage");
    CHECK(compB.unknownCommands>=1, "fixture B unknown customwave recorded");
    if(!stagesB.empty() && stagesB[0].spawns.size()>=2){
        CHECK(stagesB[0].spawns[0].at==50, "earlier `at` wins regardless of declaration order");
        CHECK(stagesB[0].spawns[0].alias=="SecondButEarlier", "alias preserved");
    }
    // Tab-indented model still parses.
    CHECK(compB.models==1, "tab-indented model parsed");

    fs::path outA = "/tmp/obor-port-a";
    fs::path outB = "/tmp/obor-port-b";
    fs::remove_all(outA); fs::remove_all(outB);
    PortGenerator::generate(scanA, compA, outA);
    PortGenerator::generate(scanB, compB, outB);
    CHECK(fs::exists(outA/"runtime"/"generated"/"GeneratedStages.cpp"), "port A stages generated");
    CHECK(fs::exists(outA/"runtime"/"src"/"Engine.cpp"), "port A engine generated");
    {
        std::ifstream in(outA/"runtime"/"generated"/"GeneratedStages.cpp");
        std::string body((std::istreambuf_iterator<char>(in)), {});
        CHECK(body.find("const Stage kStages[]")!=std::string::npos, "generated stage table present");
        CHECK(body.find("Boss")!=std::string::npos, "boss model name comes from data");
        // spawn order in generated table follows sorted at
        auto p50 = body.find("EarlyThug");
        auto pBoss = body.find("\"Boss\"");
        auto pLate = body.find("at=900");
        CHECK(pBoss!=std::string::npos, "boss spawn emitted");
        (void)p50; (void)pLate;
    }
    {
        std::ifstream in(outA/"runtime"/"generated"/"GeneratedCharacters.cpp");
        std::string body((std::istreambuf_iterator<char>(in)), {});
        CHECK(body.find("\"Boss\", \"BossGeneric\"")!=std::string::npos, "generated character keeps models.txt alias and internal name");
    }
    {
        std::ifstream in(outA/"runtime"/"generated"/"GeneratedCharacters.hpp");
        std::string body((std::istreambuf_iterator<char>(in)), {});
        CHECK(body.find("struct PaletteRemap")!=std::string::npos && body.find("alternatePalettes")!=std::string::npos, "generated character schema carries palette/remap metadata");
    }
    {
        std::ifstream in(outA/"runtime"/"src"/"Engine.cpp");
        std::string body((std::istreambuf_iterator<char>(in)), {});
        CHECK(body.find("cameraMaxX_")!=std::string::npos, "camera no longer rewinds (cameraMaxX_)");
        CHECK(body.find("spawnState_")!=std::string::npos, "spawn state machine emitted");
        CHECK(body.find("while(nextSpawn_") == std::string::npos, "old rewind-prone spawn cursor removed");
        CHECK(body.find("c.modelName")!=std::string::npos, "runtime resolves external model aliases");
        CHECK(body.find("groupMin_")!=std::string::npos && body.find("groupMax_")!=std::string::npos, "runtime emits group min/max wave control");
        CHECK(body.find("backtrackFloor_")!=std::string::npos, "runtime emits blockade backtrack floor");
        CHECK(body.find("player-animation-frame")!=std::string::npos, "animationscript is frame-entry driven");
        CHECK(body.find("loadsample")!=std::string::npos && body.find("playsample")!=std::string::npos, "script audio APIs emitted");
        CHECK(body.find("backgroundLayers_")!=std::string::npos && body.find("foregroundLayers_")!=std::string::npos, "runtime emits parallax background/foreground layer rendering");
        CHECK(body.find("levelscript")!=std::string::npos, "runtime executes per-level levelscript");
        CHECK(body.find("jumptobranch")!=std::string::npos && body.find("pendingBranchTarget_")!=std::string::npos, "runtime implements ScriptVM campaign branch jumps");
        CHECK(body.find("current_branch")!=std::string::npos, "runtime exposes current_branch to scripts");
        CHECK(body.find("previousCamera")!=std::string::npos && body.find("scrollSpeed")!=std::string::npos, "runtime applies stage scrollspeed to camera movement");
        CHECK(body.find("applyCharacterPalette")!=std::string::npos && body.find("loadPaletteColors")!=std::string::npos, "runtime emits image/ACT palette remapping");
        CHECK(body.find("reactionAnimation")!=std::string::npos, "runtime emits attack-type-specific pain/fall/rise reactions");
        CHECK(body.find("entityFromHandle")!=std::string::npos, "runtime validates script entity handles against stable runtime entities");
        CHECK(body.find("setentityvar")!=std::string::npos && body.find("findtarget")!=std::string::npos && body.find("setspawnentry")!=std::string::npos, "runtime emits expanded entity/target/spawn ScriptVM APIs");
        CHECK(body.find("global-key-all")!=std::string::npos && body.find("global-key-player")!=std::string::npos, "runtime fires global keyN.c and keyall.c scripts");
        CHECK(body.find("spawnscript")!=std::string::npos && body.find("spawnx")!=std::string::npos && body.find("spawnat")!=std::string::npos, "runtime fires spawnscript with spawn locals");
        CHECK(body.find("damagetaker")!=std::string::npos && body.find("attacker")!=std::string::npos && body.find("attacktype")!=std::string::npos, "runtime supplies combat event locals to didhit/takedamage hooks");
        CHECK(body.find("playerkeys")!=std::string::npos && body.find("updateframe")!=std::string::npos && body.find("setidle")!=std::string::npos, "runtime emits key-state, updateframe and setidle APIs");
        CHECK(body.find("tryBlockEntity")!=std::string::npos && body.find("tryBlockPlayer")!=std::string::npos, "generated runtime includes native block resolution");
        CHECK(body.find("drawbox")!=std::string::npos && body.find("loadsprite")!=std::string::npos, "generated runtime includes direct-drawing APIs");
        CHECK(body.find("getmodelproperty")!=std::string::npos && body.find("getlevelproperty")!=std::string::npos, "generated runtime includes model/level property APIs");
    }
    {
        std::ifstream in(outA/"runtime"/"include"/"Engine.hpp");
        std::string body((std::istreambuf_iterator<char>(in)), {});
        CHECK(body.find("std::deque<RuntimeEntity>")!=std::string::npos, "runtime uses stable entity storage for script self/entity handles");
    }
    {
        std::ifstream in(outA/"runtime"/"src"/"ScriptVM.cpp");
        std::string body((std::istreambuf_iterator<char>(in)), {});
        CHECK(body.find("switchStatement")!=std::string::npos, "ScriptVM emits switch support");
        CHECK(body.find("preprocessScript")!=std::string::npos, "ScriptVM emits preprocessor include/define support");
        CHECK(body.find("FunctionMacro")!=std::string::npos && body.find("expandFunctionMacros")!=std::string::npos, "ScriptVM emits function-like macro expansion");
        CHECK(body.find("expected while after do")!=std::string::npos, "ScriptVM emits do/while support");
    }
    {
        std::ifstream in(outA/"runtime"/"include"/"AudioSystem.hpp");
        std::string body((std::istreambuf_iterator<char>(in)), {});
        CHECK(body.find("effectVoices_")!=std::string::npos, "audio runtime supports overlapping active effects");
        CHECK(body.find("pauseMusic")!=std::string::npos, "audio runtime exposes music pause API");
    }
    {
        std::ifstream in(outA/"runtime"/"src"/"AudioDecoder.cpp");
        std::string body((std::istreambuf_iterator<char>(in)), {});
        CHECK(body.find("tag==3")!=std::string::npos, "WAV decoder includes IEEE float32 path");
        CHECK(body.find("bits==24")!=std::string::npos && body.find("bits==32")!=std::string::npos, "WAV decoder includes 24/32-bit PCM paths");
        CHECK(body.find("decodeMediaFoundation")!=std::string::npos && body.find("MFCreateSourceReaderFromURL")!=std::string::npos, "Windows runtime emits Media Foundation compressed-audio decoder");
    }
    {
        std::ifstream in(outB/"config"/"port.ini");
        std::string body((std::istreambuf_iterator<char>(in)), {});
        CHECK(body.find("logical_width=480")!=std::string::npos, "port B records 480 width");
        CHECK(body.find("logical_height=272")!=std::string::npos, "port B records 272 height");
    }
    {
        std::ifstream in(outB/"config"/"openbor-video.ini");
        std::string body((std::istreambuf_iterator<char>(in)), {});
        CHECK(body.find("logical_width=480")!=std::string::npos && body.find("logical_height=272")!=std::string::npos, "PortGenerator always writes detected video resolution");
    }
    {
        std::ifstream in(outA/"runtime"/"src"/"main.cpp");
        std::string body((std::istreambuf_iterator<char>(in)), {});
        CHECK(body.find("executableDir")!=std::string::npos, "generated runtime roots itself at executable directory");
        CHECK(body.find("argv[i][0]!=\'-\'")!=std::string::npos, "generated runtime does not mistake CLI flags such as --headless for the port root");
    }
    CompatibilityAnalyzer::writeReport(scanA, compA, outA/"reports");
    CHECK(fs::exists(outA/"reports"/"analysis.json"), "analysis.json");
    CHECK(fs::exists(outA/"reports"/"compatibility-report.txt"), "compatibility-report.txt");

    // Real traversal guard exercises the same helper used by parsers/generator input handling.
    CHECK(SafePath::resolveWithin(scanA.dataDir, "../secret.txt").empty(), "path traversal outside data/ is rejected");
    CHECK(SafePath::resolveWithin(scanA.dataDir, "data/chars/hero/hero.txt") == fs::weakly_canonical(scanA.dataDir/"chars/hero/hero.txt"), "valid OpenBOR data path resolves inside data/");

    // A generated port is a valid input for the test/scan path.
    auto generatedScan = ProjectScanner::scan(outA);
    CHECK(generatedScan.hasDataDir && generatedScan.dataDir.filename()=="openbor-data", "generated port layout assets/openbor-data is recognized");
    auto generatedComp = CompatibilityAnalyzer::analyze(generatedScan);
    bool generatedFalseScriptWarning=false;
    for(const auto& issue:generatedComp.issues) if(issue.command=="script-file") generatedFalseScriptWarning=true;
    CHECK(!generatedFalseScriptWarning, "generated port include/import analysis has no false script warning");

    // v0.20 universal input: bare OpenBOR PAK and ZIP package are resolved without
    // requiring the user to unpack/rearrange the game first.
    fs::path pakPath="/tmp/obor-v020-test.pak";fs::remove(pakPath);CHECK(createTestPak(pakPath), "synthetic OpenBOR PAK fixture created");
    try{ auto pakInput=InputResolver::resolve(pakPath);auto pakScan=ProjectScanner::scan(pakInput.gameRoot);CHECK(pakInput.sourceKind=="pak", "bare .pak input recognized");CHECK(pakScan.hasModels&&pakScan.hasLevels, "bare .pak extracted into analyzable OpenBOR data/"); }catch(const std::exception&e){std::cerr<<"FAIL: PAK resolver exception: "<<e.what()<<"\n";++gFails;}

    fs::path zipSrc="/tmp/obor-v020-zip-src",zipPath="/tmp/obor-v020-game.zip";fs::remove_all(zipSrc);fs::remove(zipPath);fs::create_directories(zipSrc/"Bundle/MyGame");fs::copy(fixtureA,zipSrc/"Bundle/MyGame",fs::copy_options::recursive|fs::copy_options::overwrite_existing);
    {auto old=fs::current_path();fs::current_path(zipSrc);int rc=std::system((std::string("cmake -E tar cf ")+zipPath.string()+" --format=zip Bundle").c_str());fs::current_path(old);CHECK(rc==0&&fs::exists(zipPath), "ZIP fixture created");}
    try{ auto zipInput=InputResolver::resolve(zipPath);auto zipScan=ProjectScanner::scan(zipInput.gameRoot);CHECK(zipInput.sourceKind=="zip", "ZIP input recognized");CHECK(zipScan.hasModels&&zipScan.hasLevels, "nested ZIP game root auto-detected"); }catch(const std::exception&e){std::cerr<<"FAIL: ZIP resolver exception: "<<e.what()<<"\n";++gFails;}

    fs::path openborZipSrc="/tmp/obor-v020-openbor-zip-src",openborZip="/tmp/obor-v020-openbor-package.zip";fs::remove_all(openborZipSrc);fs::remove(openborZip);fs::create_directories(openborZipSrc/"OpenBOR/Paks");fs::copy_file(pakPath,openborZipSrc/"OpenBOR/Paks/TestGame.pak");
    {auto old=fs::current_path();fs::current_path(openborZipSrc);int rc=std::system((std::string("cmake -E tar cf ")+openborZip.string()+" --format=zip OpenBOR").c_str());fs::current_path(old);CHECK(rc==0&&fs::exists(openborZip), "OpenBOR engine-style ZIP with Paks/*.pak fixture created");}
    try{ auto packageInput=InputResolver::resolve(openborZip);auto packageScan=ProjectScanner::scan(packageInput.gameRoot);CHECK(packageInput.sourceKind=="openbor-package-zip", "OpenBOR ZIP containing Paks/*.pak recognized");CHECK(packageScan.hasModels&&packageScan.hasLevels, "PAK inside OpenBOR ZIP auto-extracted and analyzed"); }catch(const std::exception&e){std::cerr<<"FAIL: OpenBOR package ZIP resolver exception: "<<e.what()<<"\n";++gFails;}

    std::cout << (gFails? "REGRESSION FAIL " : "REGRESSION PASS ") << gFails << " failures\n";
    return gFails?1:0;
}
