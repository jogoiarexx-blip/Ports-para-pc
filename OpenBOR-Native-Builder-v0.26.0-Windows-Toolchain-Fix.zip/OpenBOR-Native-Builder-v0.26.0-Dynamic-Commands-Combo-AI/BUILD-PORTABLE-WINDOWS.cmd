@echo off
setlocal
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0BUILD-PORTABLE-WINDOWS.ps1"
if errorlevel 1 pause
endlocal
