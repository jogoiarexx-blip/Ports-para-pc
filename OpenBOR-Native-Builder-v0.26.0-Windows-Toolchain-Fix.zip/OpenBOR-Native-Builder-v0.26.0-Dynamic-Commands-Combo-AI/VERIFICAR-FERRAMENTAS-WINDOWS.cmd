@echo off
setlocal
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0VERIFICAR-FERRAMENTAS-WINDOWS.ps1"
echo.
pause
endlocal
