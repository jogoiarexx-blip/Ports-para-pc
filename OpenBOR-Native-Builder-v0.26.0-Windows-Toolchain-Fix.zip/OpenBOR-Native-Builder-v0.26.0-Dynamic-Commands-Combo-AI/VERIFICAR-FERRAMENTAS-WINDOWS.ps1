$ErrorActionPreference = "SilentlyContinue"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path

function First-Existing($paths) {
    foreach ($p in $paths) { if ($p -and (Test-Path $p)) { return $p } }
    return $null
}

$cmakeCmd = Get-Command cmake.exe -ErrorAction SilentlyContinue
$cmake = if ($cmakeCmd) { $cmakeCmd.Source } else {
    First-Existing @(
        (Join-Path $Root "tools\cmake\bin\cmake.exe"),
        "$env:ProgramFiles\CMake\bin\cmake.exe",
        "${env:ProgramFiles(x86)}\CMake\bin\cmake.exe",
        "$env:ProgramFiles\Microsoft Visual Studio\2022\BuildTools\Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin\cmake.exe"
    )
}

$vswhere = "${env:ProgramFiles(x86)}\Microsoft Visual Studio\Installer\vswhere.exe"
$msvc = $null
if (Test-Path $vswhere) {
    $msvc = & $vswhere -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath
    if ($msvc) { $msvc = $msvc | Select-Object -First 1 }
}

Write-Host "=== Diagnostico OpenBOR Native Builder ===" -ForegroundColor Cyan
if ($cmake) {
    Write-Host "CMake: OK" -ForegroundColor Green
    Write-Host "  $cmake"
    & $cmake --version | Select-Object -First 1
} else {
    Write-Host "CMake: NAO ENCONTRADO" -ForegroundColor Red
}

if ($msvc) {
    Write-Host "MSVC C++: OK" -ForegroundColor Green
    Write-Host "  $msvc"
} else {
    Write-Host "MSVC C++: NAO ENCONTRADO" -ForegroundColor Red
    if (Test-Path $vswhere) { Write-Host "vswhere existe, mas o workload C++ nao esta instalado." -ForegroundColor Yellow }
    else { Write-Host "Visual Studio Installer/vswhere tambem nao foi encontrado." -ForegroundColor Yellow }
}

if ($cmake -and $msvc) { exit 0 } else { exit 1 }
