@echo off
setlocal
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0INSTALAR-FERRAMENTAS-WINDOWS.ps1"
if errorlevel 1 (
  echo.
  echo Falha ao preparar as ferramentas. Veja a mensagem acima.
  pause
) else (
  echo.
  pause
)
endlocal
