@echo off
setlocal
chcp 65001 >nul

echo ================================================
echo OpenBOR Native Builder - Gerar Portable Win64
echo ================================================
echo.
echo 1/2 - Verificando/instalando CMake e MSVC C++...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0INSTALAR-FERRAMENTAS-WINDOWS.ps1"
if errorlevel 1 (
  echo.
  echo Nao foi possivel preparar as ferramentas.
  echo Execute VERIFICAR-FERRAMENTAS-WINDOWS.cmd para diagnostico.
  pause
  exit /b 1
)

echo.
echo 2/2 - Compilando o executavel portatil...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0BUILD-PORTABLE-WINDOWS.ps1"
if errorlevel 1 (
  echo.
  echo Falha na compilacao. Veja a mensagem acima.
  pause
  exit /b 1
)

echo.
echo PRONTO.
echo Abra a pasta dist-portable.
explorer "%~dp0dist-portable"
pause
endlocal
