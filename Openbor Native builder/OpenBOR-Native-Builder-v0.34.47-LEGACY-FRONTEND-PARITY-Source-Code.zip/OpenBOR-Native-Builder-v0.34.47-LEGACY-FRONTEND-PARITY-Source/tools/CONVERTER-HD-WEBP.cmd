@echo off
setlocal
if "%~1"=="" (
  echo Uso: CONVERTER-HD-WEBP.cmd ^<pasta data_hd ou openbor-data-hd^>
  exit /b 2
)
python "%~dp0convert-hd-webp.py" "%~1"
if errorlevel 1 (
  echo.
  echo Requer Python + Pillow com suporte WebP: py -m pip install Pillow
)
endlocal
