#!/usr/bin/env python3
"""Convert a data_hd/openbor-data-hd tree from PNG to exact lossless WebP.
Requires Pillow with WebP support. Verifies decoded RGBA equality before deleting PNGs.
"""
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
from PIL import Image, features
import argparse, os, sys, time

def convert_one(args):
    pstr, method, keep = args
    p=Path(pstr); q=p.with_suffix('.webp')
    with Image.open(p) as src:
        im=src.convert('RGBA'); raw=im.tobytes(); size=im.size
        im.save(q,'WEBP',lossless=True,method=method,exact=True)
    with Image.open(q) as chk:
        chk=chk.convert('RGBA'); ok=chk.size==size and chk.tobytes()==raw
    if ok and not keep: p.unlink()
    return p.stat().st_size if keep and p.exists() else 0, q.stat().st_size, ok, pstr

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('folder', type=Path)
    ap.add_argument('--keep-png', action='store_true')
    ap.add_argument('--method', type=int, default=4, choices=range(0,7))
    ap.add_argument('--workers', type=int, default=max(1,min(16,os.cpu_count() or 4)))
    ns=ap.parse_args()
    if not features.check('webp'):
        print('Pillow was built without WebP support.',file=sys.stderr);return 2
    files=list(ns.folder.rglob('*.png'))
    if not files: print('No PNG files found.');return 0
    original=sum(p.stat().st_size for p in files); start=time.time()
    with ProcessPoolExecutor(max_workers=ns.workers) as ex:
        vals=list(ex.map(convert_one,((str(p),ns.method,ns.keep_png) for p in files),chunksize=3))
    bad=[v for v in vals if not v[2]]
    if bad:
        print(f'ERROR: {len(bad)} pixel mismatches; PNG originals were not deleted for those files.',file=sys.stderr);return 3
    webp=sum(v[1] for v in vals)
    print(f'Converted {len(files)} PNG -> lossless WebP; {original} -> {webp} bytes ({(1-webp/original)*100:.2f}% smaller); pixel mismatches=0; {time.time()-start:.2f}s')
    return 0
if __name__=='__main__': raise SystemExit(main())
