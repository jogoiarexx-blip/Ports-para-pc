# Validação — OpenBOR Native Builder v0.34.40

- Builder Release build: **PASS**
- CTest regression: **PASS — 100%, 0 falhas**
- Final Fight X regeneration: **PASS**
- Final Fight X compatibility: **15.477 SUPPORTED / 0 PARTIAL / 0 UNSUPPORTED / 0 UNKNOWN**
- Generated runtime host build: **PASS**
- Final Fight X headless gameplay smoke: **600 frames PASS**
- HD mode preserved: logical 320x240 / internal render 1280x960
- HD assets preserved: 1.519 overrides

## Structural checks

- `drawFrame()` now queues original sprite + transform metadata rather than generating a transformed bitmap on the primary GPU path.
- Shader path contains `Texture2DArray`, per-instance transform/tint/fill data and `DrawInstanced`.
- Atlas packing is bounded and falls back to dedicated array textures for oversized sprites.
- Legacy blend modes 3-6 still force CPU rendering to preserve established semantics.
- Low-VRAM safety uses sequential residency and only extends a batch with already-resident resources.

## Limitação de validação

The Linux host validates generation, compilation of the cross-platform runtime, compatibility and gameplay smoke. The `_WIN32` D3D11 branch cannot be compiled or visually profiled here because the Windows SDK/D3D11 development environment is not present. The existing automatic CPU fallback is intentionally retained for that reason.
