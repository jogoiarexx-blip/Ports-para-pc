# Validacao — OpenBOR Native Builder v0.34.32

## Build
- CMake configure: PASS
- Release build: PASS
- CTest: 1/1 PASS

## Runtime gerado
- runtime_effects: PASS
- runtime_contacts: PASS
- runtime_grabs: PASS
- runtime_bindings: PASS
- runtime_unicode: PASS
- runtime_terrain: PASS
- runtime_energy: PASS
- runtime_commands: PASS
- runtime_compatibility: PASS
- runtime_endlevel: PASS

## Nova regressao estrutural
`runtime_commands` confirma que a fila final e ordenada por Z, depois sortid e por fim sequencia. Sprites de script foram testados abaixo do jogador, no mesmo Z com sortid menor/maior e acima do jogador. O mesmo teste confirma PANEL_Z, SHADOW_Z, fglayer, FRONTPANEL_Z e HUD_Z.

## Observacao Windows
O fonte precisa ser recompilado por MinGW/MSVC ou CI Windows para gerar um Portable x64 desta revisao. Nenhum binario de versao anterior deve ser renomeado.
