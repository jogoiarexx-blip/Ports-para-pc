# Validação — OpenBOR Native Builder v0.34.39 GPU Batch Crossfeed

## Resultado

- Builder Release compile (host): **PASS**
- CTest regression: **PASS — 100%, 0 falhas**
- Final Fight convertido do zero: **PASS**
- Compatibility Analyzer: **15.477 SUPPORTED / 0 PARTIAL / 0 UNSUPPORTED / 0 UNKNOWN**
- Assets HD preservados: **1.519/1.519**
- Runtime gerado host build: **PASS**
- `openbor-native-builder test`: **PASS**
- Gameplay smoke: **PASS — 600 frames executados**
- Resolução lógica: **320x240**
- Render HD alvo: **1280x960 (4x)**

## Mudança estrutural validada

O caminho D3D11 compatível passa a manter sprites como texturas GPU persistentes, registrar os draws em ordem autorada e agrupar draws consecutivos compatíveis. Em frames aceitos pelo caminho GPU, não é necessário compor a cena inteira em pixels na CPU nem enviar uma superfície 1280x960 completa a cada frame.

Uma superfície BGRA 1280x960 ocupa 4.915.200 bytes. A 60 FPS, o upload integral anterior equivaleria a aproximadamente 281,25 MiB/s de tráfego CPU→GPU, além do custo do compositor CPU.

## Segurança / compatibilidade

- Blend modes suportados pelo novo caminho: 0, 1 e 2.
- Blend legado 3–6 força fallback do frame inteiro para o compositor CPU comprovado.
- Se o caminho GPU falhar, os comandos permanecem disponíveis para rerenderização CPU + apresentação fallback.
- Ordem de desenho é preservada pelo command buffer; batching só combina comandos consecutivos compatíveis.

## Limitação de validação

Este ambiente não possui Windows SDK/headers D3D11. Assim, o código `_WIN32` recebeu cobertura estrutural/regressiva e o runtime host foi compilado/testado, mas a compilação e a inspeção visual do ramo D3D11 no Windows ainda precisam ser executadas em uma máquina Windows.
