# Validação v0.34.43 — JLU Behavioral Regression Suite

- Builder CTest: **100% / 0 failures**.
- Full generated-runtime test suite: **11/11 PASS**.
- Justice League United v3.0: **447 models, 118 stages, 3,835 animations, 25 scripts**.
- JLU compatibility: **92,929 SUPPORTED / 0 PARTIAL / 0 UNSUPPORTED / 0 UNKNOWN**.
- JLU `--behavior-suite=jlu`: **27/27 PASS**.
- JLU smoke: **600 frames / RC=0**.
- Final Fight X analyzer anchor: **15,477 SUPPORTED / 0 PARTIAL / 0 UNSUPPORTED / 0 UNKNOWN**.
- Windows generated build script retains short `%TEMP%` path + Visual Studio 17 2022/MSVC primary toolchain.

## Structural correction discovered by the behavioral suite

`subject_to_gravity` now defaults to enabled in parsed models, matching legacy OpenBOR semantics for normal entities. Explicit `subject_to_gravity 0` continues to disable gravity. Fractional `antigravity` is covered by runtime regression.

## JLU behavior probes

The generated runtime verifies registered-model `loadmodel`, persistent script text objects, branch state, Batman `ironkey.c`, summon/child binding, model-level Batrang throwframe fallback, Vixen five-argument helper dispatch, native grab/throw, and FlechaPIA obstacle blocking.
