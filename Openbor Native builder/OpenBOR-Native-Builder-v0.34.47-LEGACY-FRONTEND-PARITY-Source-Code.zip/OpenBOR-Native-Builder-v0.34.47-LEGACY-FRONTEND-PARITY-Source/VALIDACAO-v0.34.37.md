# Validação — OpenBOR Native Builder v0.34.37

## Builder
- CMake build: PASS
- CTest: PASS (100%, 0 failures)

## Final Fight X reference conversion
- Models: 99
- Stages: 21
- Animations: 1106
- Scripts: 5
- Logical resolution: 320x240
- Compatibility occurrences: 15477 SUPPORTED / 0 PARTIAL / 0 UNSUPPORTED / 0 UNKNOWN
- `openbor-native-builder test`: PASS, generated native runtime compiled and linked successfully in the host environment.

## HD audit
- HD override files: 1519
- Exact 4x matches: 1519
- Missing base counterparts: 0
- Scale mismatches: 0
- Runtime render surface at default strict mode: 1280x960 for 320x240 logical gameplay.

## Gameplay smoke
- 360 frames: PASS
- Stage 1 loaded
- stage spawns executed
- camera combat lock executed
- player damage + knockdown exercised
- legacy OpenBOR music decoded

## Platform note
The Windows-specific WIC/D3D11 path is generated and structurally covered by regression checks, but this Linux validation host does not provide the Windows SDK, so final visual verification of the Windows renderer must be done by building/running the generated project on Windows.
