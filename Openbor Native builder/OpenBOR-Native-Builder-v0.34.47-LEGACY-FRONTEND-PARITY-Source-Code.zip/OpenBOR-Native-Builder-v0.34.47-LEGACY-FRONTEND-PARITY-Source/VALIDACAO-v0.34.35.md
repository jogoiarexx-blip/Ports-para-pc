# Validação — OpenBOR Native Builder v0.34.35

- CTest regression suite
- Generated runtime suite including runtime_legacy_unknowns
- Stage physics: gravity, max fall speed and max toss speed
- Stun without palette remap
- Script-owned TXT/CFG false-UNKNOWN filtering
