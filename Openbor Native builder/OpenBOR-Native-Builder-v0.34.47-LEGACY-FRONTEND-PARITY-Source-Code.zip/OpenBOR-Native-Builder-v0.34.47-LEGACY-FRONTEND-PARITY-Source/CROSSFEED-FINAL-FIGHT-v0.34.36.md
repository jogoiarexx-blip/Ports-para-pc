# OpenBOR Native Builder × Final Fight X — Crossfeed v0.34.36

## Resultado

A melhoria cruzada usa o Final Fight X como caso real de paridade e devolve as correções genéricas ao OpenBOR Native Builder. O port de Final Fight foi então regenerado com a base corrigida.

### Métricas do Final Fight X

| Métrica | Builder v0.34.35 (antes) | Crossfeed v0.34.36 (depois) |
|---|---:|---:|
| Modelos | 99 | 99 |
| Fases | 21 | 21 |
| Animações | 1.106 | 1.106 |
| Scripts | 5 | 5 |
| Ocorrências suportadas | 15.477 | 15.477 |
| PARTIAL | 0 | 0 |
| UNSUPPORTED | 0 | 0 |
| UNKNOWN | 26 | **0** |
| Assets HD preservados | não garantido | **1.519** |
| PNG HD preservados | não garantido | **1.514** |
| GIF HD preservados | não garantido | **5** |

Os 26 UNKNOWN anteriores eram falsos positivos vindos do Léame/README em espanhol com nome mojibake. A análise agora ignora documentação auxiliar com segurança sem esconder comandos reais do jogo.

## Melhorias cruzadas implementadas

### 1. `defense all` legado corrigido
O Final Fight X demonstrou que `defense all` sem fator explícito deve resultar em fator 0 no comportamento legado. O Builder v0.34.35 inventava 1.0. O parser e o analyzer agora preservam o valor legado correto.

**Impacto:** alto em NPCs e personagens que dependem de defesa legada.  
**Pontuação:** 9/10.

### 2. `attackone` promovido a paridade completa no runtime genérico
O runtime agora trava o primeiro alvo quando `attackone=1`, mas permite que quadros de ataque autorados posteriores acertem novamente esse mesmo alvo. Quando `attackone=0`, o mesmo quadro pode atingir múltiplos alvos elegíveis, com deduplicação por quadro.

A lógica foi aplicada a jogador, coop e inimigos em vez de manter um comportamento especial apenas no Final Fight.

**Impacto:** muito alto em combos, multi-hit, throws e ataques com várias caixas.  
**Pontuação:** 10/10.

### 3. Falsos UNKNOWN de documentação removidos
O detector de texto auxiliar foi robustecido para reconhecer o `Léame.txt` corrompido por codificação sem depender de um limite curto de nome. Resultado real no Final Fight: **26 UNKNOWN → 0**.

**Impacto:** médio/alto para diagnóstico e automação.  
**Pontuação:** 8/10.

### 4. Preservação genérica de `data_hd`
O gerador agora procura `data_hd` ou `openbor-data-hd` ao lado do data clássico e copia a árvore completa para `assets/openbor-data-hd`. No Final Fight foram preservados 1.519 replacements HD.

A substituição automática no renderer **não foi habilitada ainda**. Os assets do Final Fight são 4x e precisam de um resolver consciente da escala para não alterar tamanho lógico, offsets, HUD ou colisões. O relatório `reports/hd-override-assets.txt` deixa essa limitação explícita.

**Impacto:** alto para não perder trabalho de remasterização durante novas conversões.  
**Pontuação:** 8/10.

### 5. Final Fight regenerado na base atual
O Final Fight foi regenerado pelo Builder v0.34.36, herdando as melhorias estruturais atuais do runtime e as correções acima. O teste do projeto gerado passou e o runtime host compilou completamente.

**Impacto:** muito alto porque reduz divergência entre o jogo de referência e o Builder.  
**Pontuação:** 9/10.

### 6. Regressões automatizadas adicionadas
A suíte passa a testar explicitamente:
- `defense all` sem fator = legado 0;
- `attackone` com trava de alvo e contatos por quadro;
- preservação de `data_hd` e relatório honesto de ativação;
- geração do runtime sem regressão.

**Impacto:** alto para impedir que as correções sejam perdidas em versões futuras.  
**Pontuação:** 9/10.

## Pontuação técnica resumida

Pontuação interna de engenharia, 0–10; não é benchmark oficial.

| Área | Antes | Depois | Ganho |
|---|---:|---:|---:|
| Compatibilidade/análise | 9,2 | **10,0** | +0,8 |
| Fidelidade de combate legado | 8,8 | **9,6** | +0,8 |
| Regressão/segurança de mudanças | 9,0 | **9,7** | +0,7 |
| Preservação de assets de projetos | 8,0 | **9,5** | +1,5 |
| Sincronia Builder ↔ Final Fight | 8,5 | **9,6** | +1,1 |
| Visual HD do Final Fight especializado | 10,0 | **10,0 preservado** | 0 |

**Média cruzada estimada:** 8,9 → **9,7/10** nas áreas atacadas.

## Validação executada

- CMake/Ninja: Builder v0.34.36 compilado no ambiente host.
- CTest: **100% dos testes passaram (1/1 suíte, 0 falhas)**.
- Final Fight analyze: **15.477 SUPPORTED, 0 PARTIAL, 0 UNSUPPORTED, 0 UNKNOWN**.
- Final Fight convert: **GAME COMPATIBILITY: PASS**.
- Final Fight generated runtime: compilado e linkado com sucesso no ambiente host.
- Estrutura gerada: assets, CMake, GeneratedCharacters, GeneratedStages, Engine e configuração de vídeo passaram nos checks.

## Limite desta entrega

O ambiente usado aqui não possui Windows SDK/headers, então não foi possível gerar um novo `.exe` Win64 do runtime v0.34.36. Os scripts Windows continuam no port gerado para compilar no Windows. O `FinalFightX.exe` especializado v0.3.47 original não foi modificado nem renomeado como se fosse novo.

A próxima melhoria cruzada de maior impacto é integrar `openbor-data-hd` ao renderer com escala lógica 1x/asset 4x, offsets e cache independentes de resolução, reaproveitando as regras de safe-area/HiDPI já provadas pelo Final Fight v0.3.47.
