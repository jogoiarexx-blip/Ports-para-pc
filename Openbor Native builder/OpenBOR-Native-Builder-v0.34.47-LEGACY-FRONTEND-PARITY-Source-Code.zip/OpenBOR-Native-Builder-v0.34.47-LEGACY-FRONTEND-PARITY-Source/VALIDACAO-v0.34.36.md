# Validação — OpenBOR Native Builder v0.34.36 CROSSFEED

- CTest regression suite.
- Final Fight X compatibility scan.
- `defense all` no-factor legacy zero semantics.
- `attackone` target lock + per-frame re-hit semantics.
- Multi-target enemy contacts when `attackone=0`.
- Ancillary mojibake `Léame.txt` false-UNKNOWN suppression.
- Generated runtime source compilation on host.

- HD override preservation regression: generated port retains sibling `data_hd` under `assets/openbor-data-hd` and reports that activation is not automatic yet.
