#include "PathEncoding.hpp"
#include "CharacterParser.hpp"
#include "TextDatabase.hpp"
#include "SafePath.hpp"
#include <algorithm>
#include <cmath>
#include <set>

namespace {
std::string lower(std::string s){std::transform(s.begin(),s.end(),s.begin(),[](unsigned char c){return (char)std::tolower(c);}); return s;}
int toInt(const std::string& s, int d=0){ try { return std::stoi(s); } catch(...) { return d; } }
int landingAttackType(const std::string& value){
    const auto name=lower(value);
    if(name=="attack" || name=="attack1" || name=="normal" || name=="normal1") return 1;
    if(name.rfind("attack",0)==0 && name.size()>6) return toInt(name.substr(6),-1);
    if(name.rfind("normal",0)==0 && name.size()>6) return toInt(name.substr(6),-1);
    if(name=="blast") return 1001;
    if(name=="burn") return 1002;
    if(name=="freeze") return 1003;
    if(name=="shock") return 1004;
    if(name=="steal") return 1005;
    return toInt(name,-1); // -1 selects OpenBOR's landing attack type.
}
float toFloat(const std::string& s, float d=0){ try { return std::stof(s); } catch(...) { return d; } }
// Classic OpenBOR integer movement properties use tenths (e.g. speed 18 == 1.8).
// A few community modules use decimal values directly, so preserve explicit decimal/exponent syntax.
float legacyTenthsOrFloat(const std::string& s, float d=0.0f){
    try {
        const bool explicitFloat=s.find('.')!=std::string::npos || s.find('e')!=std::string::npos || s.find('E')!=std::string::npos;
        const float v=std::stof(s);
        return explicitFloat?v:v/10.0f;
    } catch(...) { return d; }
}
int parseAiMove(const std::vector<std::string>& values){
    int flags=0;
    for(const auto& raw:values){
        const auto v=lower(raw);
        if(v=="chase") flags|=1<<1;
        else if(v=="chasez") flags|=1<<2;
        else if(v=="chasex") flags|=1<<3;
        else if(v=="avoid") flags|=1<<4;
        else if(v=="avoidz") flags|=1<<5;
        else if(v=="avoidx") flags|=1<<6;
        else if(v=="wander") flags|=1<<7;
        else if(v=="biker") flags|=1<<8;
        else if(v=="arrow") flags|=1<<9;
        else if(v=="star") flags|=1<<10;
        else if(v=="bomb") flags|=1<<11;
        else if(v=="nomove") flags|=1<<12;
        else if(v=="ignoreholes") flags|=1<<16;
        else if(v=="notargetidle") flags|=1<<17;
        else { try { flags|=std::stoi(v,nullptr,0); } catch(...) {} }
    }
    return flags==0?1:flags;
}
int typeBit(const std::string& raw){
    auto t=lower(raw);
    if(t=="none") return 1<<0;
    if(t=="player") return 1<<2;
    if(t=="enemy") return 1<<3;
    if(t=="item") return 1<<4;
    if(t=="obstacle") return 1<<5;
    if(t=="projectile") return 1<<6;
    if(t=="steamer") return 1<<7;
    if(t=="shot") return 1<<8;
    if(t=="trap") return 1<<9;
    if(t=="textbox") return 1<<10;
    if(t=="endlevel") return 1<<11;
    if(t=="npc") return 1<<12;
    if(t=="panel") return 1<<13;
    return 0;
}
int parseTypeMask(const std::vector<std::string>& values){
    if(values.empty()) return 0;
    // Preserve numeric legacy masks, but accept the canonical OpenBOR token list
    // (player/enemy/npc/obstacle/shot/etc.) used by modern modules.
    if(values.size()==1){
        const auto& v=values[0];
        try { std::size_t n=0; int x=std::stoi(v,&n,0); if(n==v.size()) return x; } catch(...) {}
    }
    int mask=0;
    for(const auto& v:values){
        auto t=lower(v);
        if(t=="all"){ mask=(1<<0); for(int bit=2;bit<=13;++bit) mask|=(1<<bit); continue; }
        mask|=typeBit(t);
    }
    return mask;
}
int normAngle(int a){ a%=360; if(a<0)a+=360; return a; }
int parsePackedColor(const std::string& raw){
    auto first=raw.find('_');
    if(first!=std::string::npos){
        auto second=raw.find('_',first+1);
        if(second!=std::string::npos){
            int r=std::clamp(toInt(raw.substr(0,first)),0,255);
            int g=std::clamp(toInt(raw.substr(first+1,second-first-1)),0,255);
            int b=std::clamp(toInt(raw.substr(second+1)),0,255);
            return (r<<16)|(g<<8)|b;
        }
    }
    try{return std::stoi(raw,nullptr,0);}catch(...){return 0;}
}
std::string joinValues(const std::vector<std::string>& v, std::size_t first, std::size_t lastExclusive){
    std::string out; for(std::size_t i=first;i<lastExclusive&&i<v.size();++i){ if(!out.empty()) out+=' '; out+=v[i]; } return out;
}
std::string animationCommandCall(const std::vector<std::string>& v){
    if(v.empty()) return {};
    std::string out=v[0]+"(";
    for(std::size_t i=1;i<v.size();++i){ if(i>1) out+=","; out+=v[i]; }
    out+=");";
    return out;
}
void applyDrawMethod(DrawMethodDef& d, const std::vector<std::string>& v){
    if(v.empty()) return;
    auto sub=lower(v[0]);
    auto value=[&](std::size_t i,float def=0.0f){ return i<v.size()?toFloat(v[i],def):def; };
    if(sub=="scale") { d.enabled=true; d.scaleX=value(1,1.0f); d.scaleY=v.size()>2?value(2,d.scaleX):d.scaleX; return; }
    if(sub=="scalex") { d.enabled=true; d.scaleX=value(1,1.0f); return; }
    if(sub=="scaley") { d.enabled=true; d.scaleY=value(1,1.0f); return; }
    if(sub=="flipx") { d.enabled=true; d.flipX=toInt(v.size()>1?v[1]:"0")!=0; return; }
    if(sub=="flipy") { d.enabled=true; d.flipY=toInt(v.size()>1?v[1]:"0")!=0; return; }
    if(sub=="shiftx") { d.enabled=true; d.shiftX=value(1,0.0f); return; }
    if(sub=="alpha") { d.enabled=true; d.alphaMode=toInt(v.size()>1?v[1]:"0"); return; }
    if(sub=="remap") { d.enabled=true; d.remap=toInt(v.size()>1?v[1]:"0"); return; }
    if(sub=="fillcolor") { d.enabled=true; d.fillColor=parsePackedColor(v.size()>1?v[1]:"0"); return; }
    if(sub=="tintmode") { d.enabled=true; d.tintMode=std::clamp(toInt(v.size()>1?v[1]:"0"),0,6); return; }
    if(sub=="tintcolor") { d.enabled=true; d.tintColor=parsePackedColor(v.size()>1?v[1]:"0"); return; }
    if(sub=="rotate") { d.enabled=true; d.rotate=normAngle(toInt(v.size()>1?v[1]:"0")); return; }
    if(sub=="fliprotate") { d.enabled=true; d.flipRotate=toInt(v.size()>1?v[1]:"0")!=0; return; }
    // Legacy positional drawmethod: scaleX scaleY flipX flipY shiftX alpha remap fill rotate flipRotate.
    d.enabled=true;
    d.scaleX=value(0,256.0f)/256.0f;
    d.scaleY=value(1,256.0f)/256.0f;
    d.flipX=toInt(v.size()>2?v[2]:"0")!=0;
    d.flipY=toInt(v.size()>3?v[3]:"0")!=0;
    d.shiftX=value(4,0.0f)/256.0f;
    d.alphaMode=toInt(v.size()>5?v[5]:"0");
    d.remap=toInt(v.size()>6?v[6]:"0");
    d.fillColor=toInt(v.size()>7?v[7]:"0");
    d.rotate=normAngle(toInt(v.size()>8?v[8]:"0"));
    d.flipRotate=toInt(v.size()>9?v[9]:"0")!=0;
}
}

CharacterDef CharacterParser::parse(const std::filesystem::path& file, const std::filesystem::path& root) {
    CharacterDef out;
    out.sourceFile = PathEncoding::utf8(std::filesystem::relative(file, root));
    AnimationDef* currentAnim = nullptr;
    FrameDef state;
    std::string pendingAnimationCommands;
    std::string sharedAnimationScript;

    for (const auto& e : TextDatabase::parse(file)) {
        auto key = lower(e.key);
        if(key=="@script") { if(currentAnim) currentAnim->inlineScript+=e.scriptBody; else sharedAnimationScript+=e.scriptBody; continue; }
        if (key == "name" && !e.values.empty()) out.name = e.values[0];
        else if (key == "type" && !e.values.empty()) out.type = e.values[0];
        else if (key == "subtype" && !e.values.empty()) out.subtype = e.values[0];
        else if (key == "branch" && !e.values.empty()) out.branch = e.values[0];
        else if (key == "health" && !e.values.empty()) out.health = toInt(e.values[0],100);
        else if (key == "flash" && !e.values.empty()) out.flashModel=e.values[0];
        else if (key == "bflash" && !e.values.empty()) out.blockFlashModel=e.values[0];
        else if (key == "noatflash" && !e.values.empty()) out.noAttackFlash=toInt(e.values[0])!=0;
        else if (key == "toflip" && !e.values.empty()) out.flipFlash=toInt(e.values[0])!=0;
        else if (key == "mp" && !e.values.empty()) out.mp = std::max(0,toInt(e.values[0],0));
        else if (key == "mprate" && !e.values.empty()) out.mpRate = std::max(0,toInt(e.values[0],0));
        else if ((key == "parrow" || key == "parrow2") && !e.values.empty()) {
            const auto path=SafePath::normalizeOpenBOR(e.values[0]);
            const int x=e.values.size()>1?toInt(e.values[1],0):0;
            const int y=e.values.size()>2?toInt(e.values[2],0):0;
            if(key=="parrow"){out.playerArrow=path;out.playerArrowX=x;out.playerArrowY=y;}
            else {out.playerArrow2=path;out.playerArrow2X=x;out.playerArrow2Y=y;}
        }
        else if (key == "knockdowncount" && !e.values.empty()) out.knockdownCount = toFloat(e.values[0],0.0f);
        else if (key == "speed" && !e.values.empty()) out.speed = legacyTenthsOrFloat(e.values[0],1.0f);
        else if (key == "speedf" && !e.values.empty()) out.speed = toFloat(e.values[0],1.0f);
        else if (key == "runspeed" && !e.values.empty()) out.runSpeed = toFloat(e.values[0],0.0f);
        else if (key == "jumpspeed" && !e.values.empty()) out.jumpSpeed = legacyTenthsOrFloat(e.values[0],0.0f);
        else if (key == "jumpspeedf" && !e.values.empty()) out.jumpSpeed = toFloat(e.values[0],0.0f);
        else if (key == "walkoffmove" && !e.values.empty()) { out.walkoffMoveX=toInt(e.values[0]); if(e.values.size()>1) out.walkoffMoveZ=toInt(e.values[1]); }
        else if (key == "running" && !e.values.empty()) {
            out.runSpeed=legacyTenthsOrFloat(e.values[0],out.runSpeed);
            if(e.values.size()>1) out.runJumpHeight=toFloat(e.values[1],0.0f);
            if(e.values.size()>2) out.runJumpLength=toFloat(e.values[2],0.0f);
            if(e.values.size()>3) out.runMoveZ=toInt(e.values[3],0)!=0;
            if(e.values.size()>4) out.runLand=toInt(e.values[4],0)!=0;
        }
        else if (key == "jumpheight" && !e.values.empty()) out.jumpHeight = toInt(e.values[0],4);
        else if (key == "jumpmove" && !e.values.empty()) { out.jumpMoveX=toInt(e.values[0]); if(e.values.size()>1) out.jumpMoveZ=toInt(e.values[1]); }
        else if (key == "knife" && !e.values.empty()) out.knifeModel=e.values[0];
        else if (key == "bomb" && !e.values.empty()) out.bombModel=e.values[0];
        else if (key == "project" && !e.values.empty()) out.projectModel=e.values[0];
        else if ((key == "weapon" || key == "weapons") && !e.values.empty()) { for(const auto& w:e.values) out.weapons.push_back(w); }
        else if (key == "weapnum" && !e.values.empty()) out.weaponNumber=std::max(0,toInt(e.values[0],0));
        else if (key == "shootnum" && !e.values.empty()) out.shootNum=std::max(0,toInt(e.values[0],0));
        else if (key == "reload" && !e.values.empty()) out.reloadAmount=std::max(0,toInt(e.values[0],0));
        else if ((key == "com" || key == "cmd") && e.values.size()>=2) { CommandDef c; c.targetAnimation=e.values.back(); c.sequence=joinValues(e.values,0,e.values.size()-1); out.commands.push_back(std::move(c)); }
        else if (key == "weaploss" && !e.values.empty()) { out.weaponLossDefined=true; out.weaponLossFlag=std::clamp(toInt(e.values[0],0),0,3); if(e.values.size()>1) out.weaponLossIndex=std::max(0,toInt(e.values[1],0)); }
        else if (key == "weapon_loss_index" && !e.values.empty()) { out.weaponLossDefined=true; out.weaponLossIndex=std::max(0,toInt(e.values[0],0)); }
        else if (key == "weapon_loss_condition" && !e.values.empty()) {
            out.weaponLossDefined=true;
            // Map modern loss-condition flags to the nearest legacy behavior the compact runtime can enforce.
            bool any=false,fall=false,death=false,stage=false,none=false;
            for(auto v:e.values){v=lower(v); if(v=="none") none=true; else if(v=="fall") fall=true; else if(v=="death") death=true; else if(v=="stage") stage=true; else if(v=="damage"||v=="pain"||v=="grabbed"||v=="grabbing"||v=="land_damage"||v=="default") any=true;}
            if(none&&!any&&!fall&&!death&&!stage) out.weaponLossFlag=3; else if(any) out.weaponLossFlag=0; else if(fall) out.weaponLossFlag=1; else if(death) out.weaponLossFlag=2; else if(stage) out.weaponLossFlag=3;
        }
        else if (key == "counter" && !e.values.empty()) out.weaponDropCounter=std::max(0,toInt(e.values[0],3));
        else if (key == "typeshot" && !e.values.empty()) out.typeShot=toInt(e.values[0],0)!=0;
        else if (key == "animal" && !e.values.empty()) out.animalWeapon=toInt(e.values[0],0)!=0;
        else if (key == "summonkill" && !e.values.empty()) out.summonKill=std::clamp(toInt(e.values[0],0),0,2);
        else if (key == "child_follow_offset_x" && !e.values.empty()) out.childFollowOffsetX=toFloat(e.values[0],0.0f);
        else if (key == "child_follow_offset_y" && !e.values.empty()) out.childFollowOffsetY=toFloat(e.values[0],0.0f);
        else if (key == "child_follow_offset_z" && !e.values.empty()) out.childFollowOffsetZ=toFloat(e.values[0],0.0f);
        else if ((key == "child_follow_range_base_max" || key == "child_follow_range_x_max") && !e.values.empty()) { out.childFollowRange=std::max(1.0f,std::fabs(toFloat(e.values[0],100.0f))); out.childFollowRangeXMax=out.childFollowRange; }
        else if ((key == "child_follow_range_base_min" || key == "child_follow_range_x_min") && !e.values.empty()) out.childFollowRangeXMin=toFloat(e.values[0],-100.0f);
        else if (key == "child_follow_range_y_max" && !e.values.empty()) out.childFollowRangeYMax=toFloat(e.values[0],100.0f);
        else if (key == "child_follow_range_y_min" && !e.values.empty()) out.childFollowRangeYMin=toFloat(e.values[0],-100.0f);
        else if (key == "child_follow_range_z_max" && !e.values.empty()) out.childFollowRangeZMax=toFloat(e.values[0],100.0f);
        else if (key == "child_follow_range_z_min" && !e.values.empty()) out.childFollowRangeZMin=toFloat(e.values[0],-100.0f);
        else if ((key == "child_follow_range_recall_base_max" || key == "child_follow_range_recall_x_max") && !e.values.empty()) { out.childRecallRange=std::max(out.childFollowRange,std::fabs(toFloat(e.values[0],300.0f))); out.childRecallRangeXMax=out.childRecallRange; }
        else if ((key == "child_follow_range_recall_base_min" || key == "child_follow_range_recall_x_min") && !e.values.empty()) out.childRecallRangeXMin=toFloat(e.values[0],-300.0f);
        else if (key == "child_follow_range_recall_y_max" && !e.values.empty()) out.childRecallRangeYMax=toFloat(e.values[0],300.0f);
        else if (key == "child_follow_range_recall_y_min" && !e.values.empty()) out.childRecallRangeYMin=toFloat(e.values[0],-300.0f);
        else if (key == "child_follow_range_recall_z_max" && !e.values.empty()) out.childRecallRangeZMax=toFloat(e.values[0],300.0f);
        else if (key == "child_follow_range_recall_z_min" && !e.values.empty()) out.childRecallRangeZMin=toFloat(e.values[0],-300.0f);
        else if (key == "child_follow_recall_offset_x" && !e.values.empty()) out.childRecallOffsetX=toFloat(e.values[0],0.0f);
        else if (key == "child_follow_recall_offset_y" && !e.values.empty()) out.childRecallOffsetY=toFloat(e.values[0],0.0f);
        else if (key == "child_follow_recall_offset_z" && !e.values.empty()) out.childRecallOffsetZ=toFloat(e.values[0],0.0f);
        else if (key == "child_follow_recall_animation" && !e.values.empty()) out.childRecallAnimation=e.values[0];
        else if (key == "child_follow_direction_adjust_config" && !e.values.empty()) { auto v=lower(e.values[0]); if(v=="same")out.childDirectionAdjust=1;else if(v=="opposite")out.childDirectionAdjust=2;else if(v=="left")out.childDirectionAdjust=3;else if(v=="right")out.childDirectionAdjust=4;else if(v=="away")out.childDirectionAdjust=5;else if(v=="toward")out.childDirectionAdjust=6;else out.childDirectionAdjust=toInt(e.values[0],0); }
        else if (key == "modelflag" && !e.values.empty()) { out.modelCopyFlags=0; for(auto v:e.values){v=lower(v);if(v=="no_basic")out.modelCopyFlags|=1;else if(v=="no_weapon")out.modelCopyFlags|=2;else if(v=="no_script")out.modelCopyFlags|=4;else if(v!="none")out.modelCopyFlags|=std::max(0,toInt(v,0));} }
        else if (key == "subentity" && !e.values.empty()) out.subEntityModel=e.values[0];
        else if (key == "atchain" && !e.values.empty()) { out.attackChain.clear(); for(const auto& v:e.values) out.attackChain.push_back(std::max(0,toInt(v,0))); }
        else if (key == "combostyle" && !e.values.empty()) out.comboStyle=std::clamp(toInt(e.values[0],0),0,2);
        else if (key == "combodelay" && !e.values.empty()) out.comboDelay=std::max(1,toInt(e.values[0],100));
        else if (key == "palette" && !e.values.empty()) out.palettePath=SafePath::normalizeOpenBOR(e.values[0]);
        else if (key == "alternatepal" && !e.values.empty()) out.alternatePalettes.push_back(SafePath::normalizeOpenBOR(e.values[0]));
        else if (key == "remap" && e.values.size()>=2) out.paletteRemaps.push_back({SafePath::normalizeOpenBOR(e.values[0]),SafePath::normalizeOpenBOR(e.values[1])});
        else if (key == "jugglepoints" && !e.values.empty()) out.jugglePoints = toInt(e.values[0],4);
        else if (key == "blockodds" && !e.values.empty()) out.blockOdds = toInt(e.values[0],-1);
        else if (key == "blockpain" && !e.values.empty()) out.blockPain = std::max(0,toInt(e.values[0],0));
        else if ((key == "thold" || key == "blockthreshold") && !e.values.empty()) out.blockThreshold = std::max(0,toInt(e.values[0],0));
        else if (key == "guardpoints" && !e.values.empty()) out.guardPoints = std::max(0,toInt(e.values[0],0));
        else if (key == "guardrate" && !e.values.empty()) out.guardRate = std::max(0,toInt(e.values[0],2));
        else if (key == "blockback" && !e.values.empty()) out.blockBack = toInt(e.values[0],0)!=0;
        else if ((key == "aggression" || key == "agression") && !e.values.empty()) out.aggression = toInt(e.values[0],0);
        else if (key == "stealth" && !e.values.empty()) { out.stealth=std::max(0,toInt(e.values[0],0)); if(e.values.size()>1) out.perception=std::max(0,toInt(e.values[1],0)); }
        else if (key == "aiattack" && !e.values.empty()) out.aiAttack = toInt(e.values[0],0);
        else if (key == "aimove" && !e.values.empty()) out.aiMove = parseAiMove(e.values);
        else if (key == "candamage" && !e.values.empty()) out.canDamageMask = parseTypeMask(e.values);
        else if (key == "hostile" && !e.values.empty()) out.hostileMask = parseTypeMask(e.values);
        else if ((key == "projectilehit" || key == "projectile") && !e.values.empty()) out.projectileHitMask = parseTypeMask(e.values);
        else if (key == "nograb" && !e.values.empty()) out.noGrab = toInt(e.values[0],0)!=0;
        else if ((key == "cantgrab" || key == "notgrab") && !e.values.empty()) {if(toInt(e.values[0],0)==2)out.grabForce=-999999;else out.grabResistance=1;}
        else if (key == "grabforce" && !e.values.empty()) out.grabForce = toInt(e.values[0],0);
        else if ((key == "grabresistance" || key == "grab_resistance" || key == "antigrab") && !e.values.empty()) out.grabResistance = toInt(e.values[0],0);
        else if (key == "makeinv" && !e.values.empty()) out.makeInv = toInt(e.values[0],0);
        else if (key == "playshotno" && !e.values.empty()) out.playShotNo = e.values[0];
        else if (key == "grabback" && !e.values.empty()) out.grabBack = toInt(e.values[0],0)!=0;
        else if (key == "grabfinish" && !e.values.empty()) out.grabFinish = toInt(e.values[0],0)!=0;
        else if (key == "throwframewait" && !e.values.empty()) out.throwFrameWait = std::max(0,toInt(e.values[0],0));
        else if (key == "fastattack" && !e.values.empty()) out.fastAttack = toInt(e.values[0],0)!=0;
        else if (key == "throwdamage" && !e.values.empty()) out.throwDamage = std::max(0,toInt(e.values[0],0));
        else if (key == "throwdist" && !e.values.empty()) out.throwDistance = toFloat(e.values[0],0.0f);
        else if (key == "throwheight" && !e.values.empty()) out.throwHeight = toFloat(e.values[0],0.0f);
        else if (key == "bounce" && !e.values.empty()) out.bounce = std::max(0,toInt(e.values[0],0));
        else if (key == "bouncefactor" && !e.values.empty()) out.bounceFactor = std::max(0.0f,toFloat(e.values[0],0.5f));
        else if ((key == "subject_to_gravity" || key == "subjecttogravity") && !e.values.empty()) out.subjectToGravity = toInt(e.values[0],0)!=0;
        else if (key == "subject_to_basemap" && !e.values.empty()) out.subjectToBasemap=toInt(e.values[0],1)!=0;
        else if (key == "subject_to_screen" && !e.values.empty()) out.subjectToScreen=toInt(e.values[0],0)!=0;
        else if (key == "subject_to_obstacle" && !e.values.empty()) out.subjectToObstacle=toInt(e.values[0],1)!=0;
        else if (key == "subject_to_platform" && !e.values.empty()) out.subjectToPlatform=toInt(e.values[0],1)!=0;
        else if (key == "subject_to_minz" && !e.values.empty()) out.subjectToMinZ=toInt(e.values[0],1)!=0;
        else if (key == "subject_to_maxz" && !e.values.empty()) out.subjectToMaxZ=toInt(e.values[0],1)!=0;
        else if ((key == "setlayer" || key == "layer") && !e.values.empty()) {
            // Older OpenBOR modules (including JLU 3.0) use model-level `layer N`
            // as the legacy spelling of modern `setlayer N`. Keep this alias scoped
            // to character/model parsing so stage-level `layer` retains its own meaning.
            out.setLayer=toInt(e.values[0],0);
        }
        else if (key == "facing" && !e.values.empty()) out.facingAdjust=toInt(e.values[0],0);
        else if (key == "alpha" && !e.values.empty()) out.alphaMode=std::clamp(toInt(e.values[0],0),0,6);
        else if (key == "gfxshadow" && !e.values.empty()) { out.gfxShadow=toInt(e.values[0],0); if(e.values.size()>1) out.gfxShadowBase=std::clamp(toInt(e.values[1],0),0,3); }
        else if (key == "dust" && !e.values.empty()) {
            out.dustFallModel=e.values[0];
            out.dustLandModel=e.values.size()>1?e.values[1]:e.values[0];
            out.dustJumpModel=e.values.size()>2?e.values[2]:"";
        }
        else if (key == "holdblock" && !e.values.empty()) out.holdBlock=toInt(e.values[0],0)!=0;
        else if (key == "riseinv" && !e.values.empty()) { out.riseInv=toInt(e.values[0],0); if(e.values.size()>1) out.riseInvNoBlink=toInt(e.values[1],0)!=0; }
        else if (key == "antigravity" && !e.values.empty()) { float v=toFloat(e.values[0],0.0f); if(std::fabs(v)>1.0f) v/=100.0f; out.antigravity=std::clamp(v,0.0f,1.0f); }
        else if (key == "nopain" && !e.values.empty()) out.noPain=toInt(e.values[0],0)!=0;
        else if (key == "nodrop" && !e.values.empty()) out.noDrop=toInt(e.values[0],0)!=0;
        else if (key == "nodieblink" && !e.values.empty()) out.noDieBlink=toInt(e.values[0],0);
        else if (key == "noquake" && !e.values.empty()) out.noQuake=toInt(e.values[0],0)!=0;
        else if (key == "subject_to_hole" && !e.values.empty()) out.subjectToHole=toInt(e.values[0],1)!=0;
        else if (key == "subject_to_wall" && !e.values.empty()) out.subjectToWall=toInt(e.values[0],1)!=0;
        else if (key == "nomove") { if(!e.values.empty() && toInt(e.values[0],0)!=0) out.noMove=true; if(e.values.size()>1 && toInt(e.values[1],0)!=0) out.noFlip=true; }
        else if (key == "no_adjust_base" && !e.values.empty()) out.noAdjustBase=toInt(e.values[0],0)!=0;
        else if (key == "offscreenkill" && !e.values.empty()) out.offscreenKill=std::max(0,toInt(e.values[0],0));
        else if ((key == "falldie" || key == "death") && !e.values.empty()) out.fallDie=std::clamp(toInt(e.values[0],0),0,2);
        else if (key == "risetime" && !e.values.empty()) { out.riseTime=toInt(e.values[0],0); if(e.values.size()>1) out.riseAttackTime=toInt(e.values[1],-50); }
        else if (key == "riseattacktype" && !e.values.empty()) out.riseAttackType=std::clamp(toInt(e.values[0],0),0,3);
        else if (key == "fmap" && !e.values.empty()) out.freezeMap=toInt(e.values[0],0);
        else if (key == "remove" && !e.values.empty()) out.removeConfig=toInt(e.values[0],0);
        else if (key == "throw" && !e.values.empty()) {
            // Legacy OpenBOR model `throw {distance} {height}` controls how this
            // model behaves when it is the grabbed/throw target. Older builder
            // versions incorrectly treated the first value as a boolean config.
            out.throwDistance=toFloat(e.values[0],0.0f);
            if(e.values.size()>1) out.throwHeight=toFloat(e.values[1],0.0f);
        }
        else if (key == "shadow" && !e.values.empty()) out.shadow = std::clamp(toInt(e.values[0],1),0,6);
        else if (key == "diesound" && !e.values.empty()) out.dieSound = SafePath::normalizeOpenBOR(e.values[0]);
        else if (key == "lifespan" && !e.values.empty()) out.lifespanSeconds = std::max(0.0f,toFloat(e.values[0],0.0f));
        else if (key == "defense" && !e.values.empty()) { DefenseDef d; d.type=lower(e.values[0]); const float legacyDefault=(d.type=="all"&&e.values.size()==1)?0.0f:1.0f; d.factor=e.values.size()>1?toFloat(e.values[1],legacyDefault):legacyDefault; if(e.values.size()>2)d.pain=toFloat(e.values[2],1.0f); if(e.values.size()>3)d.knockdown=toFloat(e.values[3],1.0f); if(e.values.size()>4)d.blockPower=toInt(e.values[4],0); if(e.values.size()>5)d.blockThreshold=toInt(e.values[5],0); if(e.values.size()>6){d.blockRatio=toFloat(e.values[6],0.0f); d.blockRatioDefined=true;} if(e.values.size()>7){d.blockType=toInt(e.values[7],0); d.blockTypeDefined=true;} out.defenses.push_back(std::move(d)); }
        else if (key == "icon" && !e.values.empty()) {
            out.iconPath = SafePath::normalizeOpenBOR(e.values[0]);
            out.iconUsesPalette = e.values.size()>1 && toInt(e.values[1],0)!=0;
        }
        else if (key == "icondie" && !e.values.empty()) out.iconDiePath = SafePath::normalizeOpenBOR(e.values[0]);
        else if (key == "nolife" && !e.values.empty()) out.noLife = toInt(e.values[0],0)!=0;
        else if (key == "lifebarstatus" && !e.values.empty()) {
            // OpenBOR: w h noborder type orientation border shadow graph backfill.
            out.lifeBarStatus = 1;
            out.lifeBarStatusDefined = true;
            out.lifeBarWidth = std::max(1,toInt(e.values[0],100));
            if(e.values.size()>1) out.lifeBarHeight = std::max(1,toInt(e.values[1],5));
            if(e.values.size()>2) out.lifeBarNoBorder = toInt(e.values[2],0);
            if(e.values.size()>3) out.lifeBarType = toInt(e.values[3],0);
            if(e.values.size()>4) out.lifeBarOrientation = toInt(e.values[4],0);
            if(e.values.size()>5) out.lifeBarBorderLayer = toInt(e.values[5],0);
            if(e.values.size()>6) out.lifeBarShadowLayer = toInt(e.values[6],0);
            if(e.values.size()>7) out.lifeBarGraphLayer = toInt(e.values[7],0);
            if(e.values.size()>8) out.lifeBarBackfillLayer = toInt(e.values[8],0);
        }
        else if (key == "lifeposition" && e.values.size()>=2) { out.lifePositionX=toInt(e.values[0],-1); out.lifePositionY=toInt(e.values[1],-1); }
        else if (key == "nameposition" && e.values.size()>=2) { out.namePositionX=toInt(e.values[0],-1); out.namePositionY=toInt(e.values[1],-1); }
        else if (key == "iconposition" && e.values.size()>=2) { out.iconPositionX=toInt(e.values[0],-1); out.iconPositionY=toInt(e.values[1],-1); }
        else if ((key == "grabdistance" || key == "grabin") && !e.values.empty()) out.grabDistance = std::max(8,toInt(e.values[0],30));
        else if (key == "thinkscript" && !e.values.empty()) out.thinkScript=e.values[0];
        else if ((key == "updatescript" || key == "script") && !e.values.empty()) out.updateScript=e.values[0];
        else if (key == "keyscript" && !e.values.empty()) out.keyScript=e.values[0];
        else if (key == "onmovexscript" && !e.values.empty()) out.onMoveXScript=e.values[0];
        else if ((key == "onmoveascript" || key == "onmoveyscript") && !e.values.empty()) out.onMoveYScript=e.values[0];
        else if (key == "onmovezscript" && !e.values.empty()) out.onMoveZScript=e.values[0];
        else if (key == "onblockascript" && !e.values.empty()) out.onBlockAScript=e.values[0];
        else if (key == "onblockyscript" && !e.values.empty()) out.onBlockYScript=e.values[0];
        else if (key == "onblockzscript" && !e.values.empty()) out.onBlockZScript=e.values[0];
        else if (key == "onblocksscript" && !e.values.empty()) out.onBlockSScript=e.values[0];
        else if (key == "onblockwscript" && !e.values.empty()) out.onBlockWScript=e.values[0];
        else if (key == "onblockoscript" && !e.values.empty()) out.onBlockOScript=e.values[0];
        else if (key == "onblockpscript" && !e.values.empty()) out.onBlockPScript=e.values[0];
        else if (key == "didblockscript" && !e.values.empty()) out.didBlockScript=e.values[0];
        else if ((key == "ondoattack" || key == "ondoattackscript") && !e.values.empty()) out.onDoAttackScript=e.values[0];
        else if ((key == "onkillscript" || key == "onkill_script") && !e.values.empty()) out.onKillScript=e.values[0];
        else if (key == "onentitycollision" && !e.values.empty()) out.onEntityCollisionScript=e.values[0];
        else if (key == "onmodelcopy" && !e.values.empty()) out.onModelCopyScript=e.values[0];
        else if (key == "animationscript" && !e.values.empty()) out.animationScript=e.values[0];
        else if ((key == "takedamagescript" || key == "takedamage_script") && !e.values.empty()) out.takeDamageScript=e.values[0];
        else if ((key == "didhitscript" || key == "didhit_script") && !e.values.empty()) out.didHitScript=e.values[0];
        else if ((key == "ondrawscript" || key == "ondraw_script") && !e.values.empty()) out.onDrawScript=e.values[0];
        else if ((key == "onspawnscript" || key == "onspawn_script") && !e.values.empty()) out.onSpawnScript=e.values[0];
        else if ((key == "ondeathscript" || key == "ondeath_script") && !e.values.empty()) out.onDeathScript=e.values[0];
        else if ((key == "onpainscript" || key == "onpain_script") && !e.values.empty()) out.onPainScript=e.values[0];
        else if ((key == "onfallscript" || key == "onfall_script") && !e.values.empty()) out.onFallScript=e.values[0];
        else if (key == "anim" && !e.values.empty()) {
            out.animations.push_back(AnimationDef{});
            out.animations.back().name = e.values[0];
            currentAnim = &out.animations.back();
            state = FrameDef{};
            pendingAnimationCommands.clear();
        } else if (currentAnim) {
            if (key == "loop" && !e.values.empty()) {
                currentAnim->loop = toInt(e.values[0],0)!=0;
                if(e.values.size()>1) currentAnim->loopStart=std::max(0,toInt(e.values[1],0));
                if(e.values.size()>2) currentAnim->loopEnd=toInt(e.values[2],-1);
            }
            else if ((key == "energycost" || key == "mpcost") && !e.values.empty()) {currentAnim->energyCost=std::max(0,toInt(e.values[0]));currentAnim->energyMode=e.values.size()>1?std::clamp(toInt(e.values[1]),0,2):0;currentAnim->energyDisable=e.values.size()>2?toInt(e.values[2]):0;}
            else if (key == "mponly" && !e.values.empty()) currentAnim->energyMode=std::clamp(toInt(e.values[0]),0,2);
            else if (key == "delay" && !e.values.empty()) {
                auto v=lower(e.values[0]);
                state.delay = (v=="infinite" || v=="inf") ? -1 : std::max(0,toInt(e.values[0],1));
            }
            else if (key == "offset" && e.values.size() >= 2) { state.offsetX=toInt(e.values[0]); state.offsetY=toInt(e.values[1]); }
            else if (key == "bbox" && !e.values.empty()) {
                if(lower(e.values[0])=="none") { state.hasBBox=false; state.bbox={}; }
                else if(e.values.size() >= 4) { auto b=HitBoxDef{toInt(e.values[0]),toInt(e.values[1]),toInt(e.values[2]),toInt(e.values[3])}; state.hasBBox=b.w>0&&b.h>0; state.bbox=b; }
            }
            else if (key == "platform" && e.values.size()>=6) {
                PlatformDef p{};
                if(e.values.size()>=8){p.x=toFloat(e.values[0]);p.z=toFloat(e.values[1]);p.lowerLeft=toFloat(e.values[2]);p.upperLeft=toFloat(e.values[3]);p.lowerRight=toFloat(e.values[4]);p.upperRight=toFloat(e.values[5]);p.depth=std::fabs(toFloat(e.values[6]));p.altitude=std::max(0.0f,toFloat(e.values[7]));}
                else {p.x=(float)state.offsetX;p.z=(float)state.offsetY;p.lowerLeft=toFloat(e.values[0]);p.upperLeft=toFloat(e.values[1]);p.lowerRight=toFloat(e.values[2]);p.upperRight=toFloat(e.values[3]);p.depth=std::fabs(toFloat(e.values[4]));p.altitude=std::max(0.0f,toFloat(e.values[5]));}
                state.hasPlatform=p.depth>0.0f&&p.altitude>0.0f;state.platform=p;
            }
            else if ((key == "attack" || (key.rfind("attack",0)==0 && key.size()>6 && std::all_of(key.begin()+6,key.end(),[](unsigned char c){return std::isdigit(c);})) || key=="blast" || key=="burn" || key=="freeze" || key=="shock") && !e.values.empty()) {
                const bool clearLegacyBlast = key=="blast" && e.values.size()==4 &&
                    std::all_of(e.values.begin(),e.values.end(),[](const std::string& v){return toInt(v,0)==0;});
                if(lower(e.values[0])=="none" || (e.values.size()==1 && e.values[0]=="0") || clearLegacyBlast) {
                    const int inheritedForceDirection=state.attack.forceDirection;
                    state.hasAttack=false; state.attack={}; state.attack.forceDirection=inheritedForceDirection;
                    state.knockdown=false; state.dropVx=0; state.dropVy=-3; state.pauseTime=0;
                }
                else if(e.values.size() >= 5) {
                    int type=1; if(key=="blast") type=1001; else if(key=="burn") type=1002; else if(key=="freeze") type=1003; else if(key=="shock") type=1004; else if(key.size()>6) type=std::max(1,toInt(key.substr(6),1));
                    AttackBoxDef a; a.forceDirection=state.attack.forceDirection; a.x=toInt(e.values[0]);a.y=toInt(e.values[1]);a.w=toInt(e.values[2]);a.h=toInt(e.values[3]);a.damage=toInt(e.values[4]);a.type=type;
                    if(key=="blast"){
                        // Legacy blast: x y right down damage no_block no_flash pause_add z.
                        // OpenBOR marks the victim as a falling projectile and launches it
                        // with dropv {3,2.5,0}; landingMode=1 maps that falling-body contact
                        // behavior onto the native runtime.
                        a.fallForce=1;
                        a.landingMode=1;
                        if(e.values.size()>=10){
                            a.fallForce=toInt(e.values[5],1);
                            a.penetration=toInt(e.values[6],0);
                            a.noFlash=toInt(e.values[7],0);
                            a.pauseTime=toInt(e.values[8],0);
                            a.zDepth=std::max(0,toInt(e.values[9],0));
                        }else{
                            if(e.values.size()>5)a.penetration=toInt(e.values[5],0);
                            if(e.values.size()>6)a.noFlash=toInt(e.values[6],0);
                            if(e.values.size()>7)a.pauseTime=toInt(e.values[7],0);
                            if(e.values.size()>8)a.zDepth=std::max(0,toInt(e.values[8],0));
                        }
                        state.dropVx=2.5f;
                        state.dropVy=-3;
                    }
                    else if(key=="burn"){
                        // Legacy burn: x y right down damage knockdown block noflash pausetime z.
                        a.fallForce=e.values.size()>5?toInt(e.values[5],0):0;
                        if(e.values.size()>6)a.penetration=toInt(e.values[6],0);
                        if(e.values.size()>7)a.noFlash=toInt(e.values[7],0);
                        if(e.values.size()>8)a.pauseTime=toInt(e.values[8],0);
                        if(e.values.size()>9)a.zDepth=std::max(0,toInt(e.values[9],0));
                        state.dropVx=0;
                        state.dropVy=a.fallForce>0?-3:0;
                    }
                    else if(key=="freeze"){
                        // Legacy freeze: x y right down damage time block noflash pausetime z.
                        a.freezeTime=e.values.size()>5?std::max(1,toInt(e.values[5],120)):120;
                        if(e.values.size()>6)a.penetration=toInt(e.values[6],0);
                        if(e.values.size()>7)a.noFlash=toInt(e.values[7],0);
                        if(e.values.size()>8)a.pauseTime=toInt(e.values[8],0);
                        if(e.values.size()>9)a.zDepth=std::max(0,toInt(e.values[9],0));
                        state.dropVx=0; state.dropVy=0; a.fallForce=0;
                    }
                    else {
                        // Legacy attack#: x y right down damage power block noflash pausetime z.
                        if(e.values.size()>5)a.fallForce=toInt(e.values[5],0);
                        if(e.values.size()>6)a.penetration=toInt(e.values[6],0);
                        if(e.values.size()>7)a.noFlash=toInt(e.values[7],0);
                        if(e.values.size()>8)a.pauseTime=toInt(e.values[8],0);
                        if(e.values.size()>9)a.zDepth=std::max(0,toInt(e.values[9],0));
                        state.dropVx=0;
                        state.dropVy=a.fallForce>0?-3:0;
                    }
                    state.hasAttack=a.w>0&&a.h>0; state.attack=a; state.knockdown=(key=="blast")||a.fallForce>0; state.pauseTime=a.pauseTime;
                }
            }
            else if (key == "stun" && !e.values.empty() && state.hasAttack) {
                // Legacy stun {time}: preserve the current attack type and collision,
                // but freeze the victim for the authored duration without a palette remap.
                state.attack.freezeTime=std::max(0,toInt(e.values[0],0));
            }
            else if ((key == "attack.effect.hit.flash.disable" || key == "noflash") && !e.values.empty()) state.attack.noFlash=toInt(e.values[0]);
            else if ((key == "noreflect" || key == "attack.reaction.pain.disable") && !e.values.empty()) state.attack.noReflect=toInt(e.values[0],0)!=0;
            else if ((key == "guardcost" || key == "attack.block.cost") && !e.values.empty()) state.attack.guardCost=toInt(e.values[0],0);
            else if ((key == "noblock" || key == "attack.block.penetrate") && !e.values.empty()) state.attack.penetration=toInt(e.values[0],0);
            else if (key == "jugglecost" && !e.values.empty()) state.attack.juggleCost=std::max(0,toInt(e.values[0],0));
            else if ((key == "attack.tag" || key == "tag") && !e.values.empty()) state.attack.tag=toInt(e.values[0],0);
            else if (key == "damageonlanding" && !e.values.empty()) { state.attack.landingDamage=std::max(0,toInt(e.values[0])); state.attack.landingMode=e.values.size()>1?std::clamp(toInt(e.values[1],0),0,2):0; state.attack.landingType=e.values.size()>2?landingAttackType(e.values[2]):-1; }
            else if (key == "fall" && !e.values.empty()) { state.attack.fallForce=toInt(e.values[0],0); state.knockdown = state.attack.fallForce!=0; }
            else if (key == "dropv" && !e.values.empty()) {
                // Legacy dropv {height} {speedx} {speedz}. The compact runtime stores
                // vertical velocity with negative-up convention and horizontal launch in dropVx.
                state.dropVy=-std::abs(toInt(e.values[0],3));
                if(e.values.size()>1) state.dropVx=toFloat(e.values[1],0.0f);
            }
            else if ((key == "pausetime" || key == "attack.reaction.pause.time") && !e.values.empty()) { state.pauseTime=toInt(e.values[0]); state.attack.pauseTime=state.pauseTime; }
            else if (key == "sound" && !e.values.empty()) state.sound=e.values[0];
            else if (key == "idle" && !e.values.empty()) state.idleInterrupt=toInt(e.values[0],0)!=0;
            else if (key == "fshadow" && !e.values.empty()) { auto v=lower(e.values[0]); state.frameShadow=(v=="none")?-1:std::clamp(toInt(e.values[0],0),0,6); }
            else if (key == "move" && !e.values.empty()) state.moveX=toFloat(e.values[0]);
            else if (key == "movez" && !e.values.empty()) state.moveZ=toFloat(e.values[0]);
            else if (key == "movea" && !e.values.empty()) state.moveA=toFloat(e.values[0]);
            else if (key == "seta" && !e.values.empty()) { state.hasSetA=true; state.setA=toFloat(e.values[0],0.0f); }
            else if (key == "drawmethod") applyDrawMethod(state.draw,e.values);
            else if (key == "nodrawmethod") state.draw=DrawMethodDef{};
            else if (key == "attackone" && !e.values.empty()) currentAnim->attackOne=toInt(e.values[0],0)!=0;
            else if (key == "forcedirection" && !e.values.empty()) state.attack.forceDirection=std::clamp(toInt(e.values[0],0),-2,2);
            else if (key == "dropframe" && !e.values.empty()) currentAnim->dropFrame=std::max(-1,toInt(e.values[0],-1));
            else if (key == "chargetime" && !e.values.empty()) currentAnim->chargeTime=std::max(0,(int)std::lround(toFloat(e.values[0],0.0f)*100.0f));
            else if (key == "pbombframe" && !e.values.empty()) {
                // Legacy pbombframe is an alias of tossframe in OpenBOR: first
                // parameter is the trigger frame, second is projectile altitude.
                currentAnim->pBombFrame=std::max(-1,toInt(e.values[0],-1));
                currentAnim->pBombDelay=e.values.size()>1?toInt(e.values[1],70):70;
                currentAnim->tossFrame=currentAnim->pBombFrame;
                currentAnim->projectileOffsetY=currentAnim->pBombDelay;
            }
            else if (key == "flipframe") currentAnim->flipFrame=e.values.empty()?0:toInt(e.values[0],0);
            else if (key == "quakeframe" && !e.values.empty()) { currentAnim->quakeFrame=toInt(e.values[0],-1); if(e.values.size()>1) currentAnim->quakeLoops=std::max(0,toInt(e.values[1],0)); if(e.values.size()>2) currentAnim->quakeIntensity=std::max(0,toInt(e.values[2],0)); }
            else if (key == "hitfx" && !e.values.empty()) currentAnim->hitFx=SafePath::normalizeOpenBOR(e.values[0]);
            else if ((key == "hitflash" || key == "attack.effect.hit.flash.model") && !e.values.empty()) {currentAnim->hitFlash=e.values[0];state.hitFlash=e.values[0];}
            else if ((key == "blockflash" || key == "attack.effect.block.flash.model") && !e.values.empty()) state.blockFlash=e.values[0];
            else if (key == "@cmd" && !e.values.empty()) {
                auto call=animationCommandCall(e.values);
                if(!call.empty()){ if(!pendingAnimationCommands.empty()) pendingAnimationCommands+='\n'; pendingAnimationCommands+=call; }
            }
            else if (key == "landframe" && !e.values.empty()) { currentAnim->landFrame=toInt(e.values[0],-1); if(e.values.size()>1) {currentAnim->landDust=toInt(e.values[1],0);currentAnim->landDustModel=e.values[1];} }
            else if (key == "jumpframe" && !e.values.empty()) { currentAnim->jumpFrame=toInt(e.values[0],-1); if(e.values.size()>1) currentAnim->jumpVelocityY=toFloat(e.values[1]); if(e.values.size()>2) currentAnim->jumpVelocityX=toFloat(e.values[2]); if(e.values.size()>3) currentAnim->jumpVelocityZ=toFloat(e.values[3]); }
            else if (key == "dive" && !e.values.empty()) { currentAnim->hasDive=true; currentAnim->diveVelocityX=toFloat(e.values[0],0.0f); currentAnim->diveVelocityY=e.values.size()>1?toFloat(e.values[1],0.0f):0.0f; }
            else if (key == "custknife" && !e.values.empty()) currentAnim->custKnife=e.values[0];
            else if ((key == "custbomb" || key == "custpbomb") && !e.values.empty()) currentAnim->custBomb=e.values[0];
            else if ((key == "throwframe" || key == "shootframe" || key == "pshotframe") && !e.values.empty()) { currentAnim->throwFrame=toInt(e.values[0],-1); if(e.values.size()>1) currentAnim->projectileOffsetY=toInt(e.values[1],70); }
            else if (key == "tossframe" && !e.values.empty()) { currentAnim->tossFrame=toInt(e.values[0],-1); if(e.values.size()>1) currentAnim->projectileOffsetY=toInt(e.values[1],70); }
            else if (key == "projectile_velocity_x" && !e.values.empty()) currentAnim->projectileVelocityX=toFloat(e.values[0],2.0f);
            else if (key == "projectile_velocity_y" && !e.values.empty()) currentAnim->projectileVelocityY=toFloat(e.values[0],0.0f);
            else if (key == "projectile_velocity_z" && !e.values.empty()) currentAnim->projectileVelocityZ=toFloat(e.values[0],0.0f);
            else if (key == "weaponframe" && !e.values.empty()) { currentAnim->weaponFrame=toInt(e.values[0],-1); if(e.values.size()>1) currentAnim->weaponIndex=toInt(e.values[1],0); }
            else if (key == "followanim" && !e.values.empty()) currentAnim->followAnim=std::max(0,toInt(e.values[0],0));
            else if (key == "followcond" && !e.values.empty()) currentAnim->followCond=std::max(0,toInt(e.values[0],0));
            else if (key == "counterframe" && e.values.size()>=3) { currentAnim->counterStart=currentAnim->counterEnd=std::max(0,toInt(e.values[0],0)); currentAnim->counterCond=std::max(0,toInt(e.values[1],0)); currentAnim->counterTakesDamage=toInt(e.values[2],1)!=0; }
            else if (key == "counterrange" && e.values.size()>=4) { currentAnim->counterStart=std::max(0,toInt(e.values[0],0)); currentAnim->counterEnd=std::max(currentAnim->counterStart,toInt(e.values[1],currentAnim->counterStart)); currentAnim->counterCond=std::max(0,toInt(e.values[2],0)); currentAnim->counterTakesDamage=toInt(e.values[3],1)!=0; }
            else if (key == "range" && e.values.size()>=2) { currentAnim->hasRangeX=true; currentAnim->rangeXMin=toFloat(e.values[0],0.0f); currentAnim->rangeXMax=toFloat(e.values[1],75.0f); if(currentAnim->rangeXMin>currentAnim->rangeXMax)std::swap(currentAnim->rangeXMin,currentAnim->rangeXMax); }
            else if (key == "rangez" && e.values.size()>=2) { currentAnim->hasRangeZ=true; currentAnim->rangeZMin=toFloat(e.values[0],0.0f); currentAnim->rangeZMax=toFloat(e.values[1],0.0f); if(currentAnim->rangeZMin>currentAnim->rangeZMax)std::swap(currentAnim->rangeZMin,currentAnim->rangeZMax); }
            else if (key == "rangea" && e.values.size()>=2) { currentAnim->hasRangeA=true; currentAnim->rangeAMin=toFloat(e.values[0],-1000.0f); currentAnim->rangeAMax=toFloat(e.values[1],1000.0f); if(currentAnim->rangeAMin>currentAnim->rangeAMax)std::swap(currentAnim->rangeAMin,currentAnim->rangeAMax); }
            else if (key == "cancel" && e.values.size()>=5) { CancelDef c; c.startFrame=std::max(0,toInt(e.values[0],0)); c.endFrame=std::max(c.startFrame,toInt(e.values[1],c.startFrame)); c.hits=std::max(0,toInt(e.values[2],0)); c.command=joinValues(e.values,3,e.values.size()-1); c.targetAnimation=e.values.back(); currentAnim->cancels.push_back(std::move(c)); }
            else if (key == "custentity" && !e.values.empty()) currentAnim->custEntity=e.values[0];
            else if ((key == "spawnframe" || key == "summonframe") && !e.values.empty()) { currentAnim->spawnFrame=std::max(0,toInt(e.values[0],0)); if(e.values.size()>1) currentAnim->spawnOffsetX=toFloat(e.values[1],0.0f); if(e.values.size()>2) currentAnim->spawnOffsetZ=toFloat(e.values[2],0.0f); if(e.values.size()>3) currentAnim->spawnOffsetA=toFloat(e.values[3],0.0f); if(e.values.size()>4) currentAnim->spawnScreenRelative=toInt(e.values[4],0)!=0; currentAnim->summonFrame=(key=="summonframe"); }
            else if (key == "unsummonframe" && !e.values.empty()) currentAnim->unsummonFrame=std::max(0,toInt(e.values[0],0));
            else if (key == "frame" && !e.values.empty()) {
                FrameDef committed=state;
                committed.sprite=e.values[0];
                committed.animationCommand=pendingAnimationCommands;
                currentAnim->frames.push_back(committed);
                pendingAnimationCommands.clear();
                state.sound.clear();
            }
        }
    }
    for(auto& animation:out.animations) animation.inlineScript=sharedAnimationScript+animation.inlineScript;
    if (out.name.empty()) out.name = PathEncoding::utf8(file.stem());
    return out;
}

std::vector<CharacterDef> CharacterParser::parseAll(const std::filesystem::path& dataDir, const std::filesystem::path& root) {
    std::vector<CharacterDef> out;
    if (!std::filesystem::exists(dataDir)) return out;

    const auto models = SafePath::resolveWithin(dataDir,"models.txt");
    if (std::filesystem::exists(models)) {
        const auto modelEntries = TextDatabase::parse(models);
        bool globalBlockRatio=false, globalMpBlock=false, noChipDeath=false, globalNoCost=false;
        for(const auto& e:modelEntries){
            auto key=lower(e.key);
            if(key=="nocost"&&!e.values.empty()) globalNoCost=toInt(e.values[0])!=0;
            else if(key=="blockratio"&&!e.values.empty()) globalBlockRatio=toInt(e.values[0],0)!=0;
            else if(key=="mpblock"&&!e.values.empty()) globalMpBlock=toInt(e.values[0],0)!=0;
            else if(key=="nochipdeath"&&!e.values.empty()) noChipDeath=toInt(e.values[0],0)!=0;
        }
        // models.txt is the authoritative OpenBOR model registry. Both `load` and
        // `know` register a model name/path; the difference in OpenBOR is eager vs.
        // on-demand resource loading. The generated native port keeps model metadata
        // registered up front but still loads sprites/audio lazily when an entity is used,
        // so both forms must be present in the generated registry.
        std::set<std::string> seenRegistryKeys;
        for (const auto& e : modelEntries) {
            auto key = lower(e.key);
            if ((key != "load" && key != "know") || e.values.empty()) continue;

            std::string registryName;
            std::string rawPath;
            if (e.values.size() >= 2) {
                registryName = e.values[0];
                rawPath = e.values[1];
            } else {
                rawPath = e.values[0];
                registryName = PathEncoding::utf8(PathEncoding::path(rawPath).stem());
            }

            auto modelFile = SafePath::resolveWithin(dataDir, rawPath);
            if (modelFile.empty() || !std::filesystem::is_regular_file(modelFile)) continue;
            auto parsed = parse(modelFile, root);
            if (parsed.animations.empty()) continue;
            parsed.modelName = registryName.empty() ? parsed.name : registryName;
            if (parsed.name.empty()) parsed.name = parsed.modelName;
            std::string dedupeKey = lower(parsed.modelName) + "\n" + PathEncoding::utf8(modelFile.lexically_normal());
            if (!seenRegistryKeys.insert(dedupeKey).second) continue;
            parsed.globalNoCost=globalNoCost; parsed.globalBlockRatio=globalBlockRatio; parsed.globalMpBlock=globalMpBlock; parsed.noChipDeath=noChipDeath;
            out.push_back(std::move(parsed));
        }
        if (!out.empty()) return out;
    }

    // Compatibility fallback for incomplete projects that omit/break models.txt.
    // This is deliberately secondary: valid projects must follow their registry.
    for (const auto& entry : std::filesystem::recursive_directory_iterator(dataDir)) {
        if (!entry.is_regular_file() || lower(PathEncoding::utf8(entry.path().extension())) != ".txt") continue;
        auto parsed = parse(entry.path(), root);
        if (!parsed.animations.empty() && !parsed.name.empty()) {
            parsed.modelName = parsed.name;
            out.push_back(std::move(parsed));
        }
    }
    return out;
}
