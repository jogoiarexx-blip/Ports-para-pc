#include "PathEncoding.hpp"
#include "RepairPackage.hpp"
#include <algorithm>
#include <cctype>
#include <fstream>
#include <map>
#include <optional>
#include <regex>
#include <set>
#include <sstream>
#include <vector>
namespace {
std::string escapeJson(const std::string& s) {
    std::string out;
    for (char c : s) {
        switch (c) {
            case '\\': out += "\\\\"; break;
            case '"': out += "\\\""; break;
            case '\n': out += "\\n"; break;
            case '\r': break;
            case '\t': out += "\\t"; break;
            default: out += c; break;
        }
    }
    return out;
}
std::string lower(std::string s){for(char&c:s)c=(char)std::tolower((unsigned char)c);return s;}
std::vector<std::string> splitArgs(const std::string& line){
    std::vector<std::string> out;std::string cur;bool quote=false;char qc=0;
    for(std::size_t i=0;i<line.size();++i){char c=line[i];
        if(quote){cur+=c;if(c==qc&&(i==0||line[i-1]!='\\'))quote=false;continue;}
        if(c=='"'||c=='\''){quote=true;qc=c;cur+=c;continue;}
        if(std::isspace((unsigned char)c)){if(!cur.empty()){out.push_back(cur);cur.clear();}}else cur+=c;
    }
    if(!cur.empty()) out.push_back(cur);
    return out;
}
std::optional<std::pair<int,int>> parseArityMismatch(const std::string& msg){
    static const std::regex re(R"(expects\s+(\d+)\s+argument\(s\),\s+call\s+provides\s+(\d+))",std::regex::icase);
    std::smatch m;if(!std::regex_search(msg,m,re))return std::nullopt;
    return std::pair<int,int>{std::stoi(m[1].str()),std::stoi(m[2].str())};
}
struct SuggestedRepair{std::filesystem::path file;std::size_t line=0;std::string before,after,reason;};
std::optional<SuggestedRepair> inferTrailingHelperArgument(const ScanReport& scan,const CompatibilityIssue& issue){
    if(issue.command!="@cmd"||issue.line==0)return std::nullopt;
    auto arity=parseArityMismatch(issue.message);if(!arity||arity->first!=arity->second+1)return std::nullopt;
    const auto src=scan.root/issue.file;std::ifstream in(src);if(!in)return std::nullopt;
    std::vector<std::string> lines;std::string line;while(std::getline(in,line)){if(!line.empty()&&line.back()=='\r')line.pop_back();lines.push_back(line);}if(issue.line>lines.size())return std::nullopt;
    const auto target=splitArgs(lines[issue.line-1]);if(target.size()<2||lower(target[0])!="@cmd")return std::nullopt;const std::string fn=lower(target[1]);
    const int expected=arity->first,provided=arity->second;if((int)target.size()-2!=provided)return std::nullopt;
    std::set<std::string> candidates;int witnesses=0;
    for(std::size_t i=0;i<lines.size();++i){if(i+1==issue.line)continue;auto t=splitArgs(lines[i]);if(t.size()<2||lower(t[0])!="@cmd"||lower(t[1])!=fn)continue;if((int)t.size()-2!=expected)continue;
        candidates.insert(t[2+provided]);++witnesses;
    }
    if(witnesses<2||candidates.size()!=1)return std::nullopt;
    const std::string inferred=*candidates.begin();SuggestedRepair r;r.file=issue.file;r.line=issue.line;r.before=lines[issue.line-1];r.after=r.before;
    auto commentPos=r.after.find("//");if(commentPos!=std::string::npos){std::string head=r.after.substr(0,commentPos);while(!head.empty()&&std::isspace((unsigned char)head.back()))head.pop_back();r.after=head+" "+inferred+" "+r.after.substr(commentPos);}
    else r.after+=" "+inferred;
    std::ostringstream why;why<<"high-confidence trailing argument inference: @cmd "<<fn<<" expects "<<expected<<", target provides "<<provided<<", and "<<witnesses<<" valid sibling call(s) unanimously use trailing value "<<inferred;r.reason=why.str();return r;
}
}
void RepairPackage::generate(const ScanReport& scan, const CompatibilityReport& compatibility,
                             const std::filesystem::path& outDir) {
    const auto repair = outDir / "AI-Repair";
    std::filesystem::create_directories(repair / "original-sources");
    std::filesystem::create_directories(repair / "suggested-sources");
    std::filesystem::create_directories(repair / "logs");
    std::set<std::filesystem::path> copied;
    for (const auto& issue : compatibility.issues) {
        if (!copied.insert(issue.file).second) continue;
        auto src = scan.root / issue.file;
        if (!std::filesystem::exists(src)) continue;
        auto dst = repair / "original-sources" / issue.file;
        std::filesystem::create_directories(dst.parent_path());
        std::filesystem::copy_file(src, dst, std::filesystem::copy_options::overwrite_existing);
    }
    std::vector<SuggestedRepair> suggestions;
    for(const auto& issue:compatibility.issues)if(auto r=inferTrailingHelperArgument(scan,issue))suggestions.push_back(*r);
    std::map<std::filesystem::path,std::vector<SuggestedRepair>> byFile;for(const auto&r:suggestions)byFile[r.file].push_back(r);
    for(auto&[rel,reps]:byFile){auto src=scan.root/rel;std::ifstream in(src);if(!in)continue;std::vector<std::string> lines;std::string line;while(std::getline(in,line)){if(!line.empty()&&line.back()=='\r')line.pop_back();lines.push_back(line);}std::sort(reps.begin(),reps.end(),[](const auto&a,const auto&b){return a.line<b.line;});for(const auto&r:reps)if(r.line&&r.line<=lines.size())lines[r.line-1]=r.after;auto dst=repair/"suggested-sources"/rel;std::filesystem::create_directories(dst.parent_path());std::ofstream out(dst);for(const auto&l:lines)out<<l<<"\n";}
    std::ofstream json(repair / "issues.json");
    json << "{\n  \"source\": \"" << escapeJson(PathEncoding::utf8(scan.root)) << "\",\n  \"issues\": [\n";
    for (std::size_t i = 0; i < compatibility.issues.size(); ++i) {
        const auto& v = compatibility.issues[i];
        json << "    {\"level\":\"" << CompatibilityAnalyzer::levelName(v.level)
             << "\",\"file\":\"" << escapeJson(PathEncoding::utf8(v.file))
             << "\",\"line\":" << v.line
             << ",\"command\":\"" << escapeJson(v.command)
             << "\",\"message\":\"" << escapeJson(v.message) << "\"}";
        if (i + 1 != compatibility.issues.size()) json << ',';
        json << "\n";
    }
    json << "  ],\n  \"suggested_repairs\": [\n";
    for(std::size_t i=0;i<suggestions.size();++i){const auto&r=suggestions[i];json<<"    {\"confidence\":\"high\",\"file\":\""<<escapeJson(PathEncoding::utf8(r.file))<<"\",\"line\":"<<r.line<<",\"before\":\""<<escapeJson(r.before)<<"\",\"after\":\""<<escapeJson(r.after)<<"\",\"reason\":\""<<escapeJson(r.reason)<<"\"}"<<(i+1<suggestions.size()?",":"")<<"\n";}
    json << "  ]\n}\n";
    std::ofstream patch(repair/"suggested-repairs.patch");
    for(const auto&r:suggestions){patch<<"--- a/"<<PathEncoding::utf8(r.file)<<"\n+++ b/"<<PathEncoding::utf8(r.file)<<"\n@@ -"<<r.line<<",1 +"<<r.line<<",1 @@\n-"<<r.before<<"\n+"<<r.after<<"\n# "<<r.reason<<"\n";}
    std::ofstream md(repair / "README-AI-REPAIR.md");
    md << "# AI Repair Package\n\nPacote gerado pelo OpenBOR Native Builder. O conteudo original nunca e alterado silenciosamente. Use `issues.json` para incompatibilidades e `suggested-repairs.patch`/`suggested-sources` apenas quando houver uma inferencia marcada como alta confianca.\n\n"
          "## Fluxo sugerido\n\n1. Corrigir itens RED primeiro.\n2. Revisar itens YELLOW.\n3. Para reparos sugeridos, comparar original-sources/ com suggested-sources/ e aplicar somente se fizer sentido para o mod.\n4. Recompilar o runtime.\n5. Rodar testes e anexar `runtime.log`.\n6. Incorporar correcoes realmente genericas ao conversor.\n\n";
    if(suggestions.empty())md<<"Nenhum reparo automatico de alta confianca foi inferido.\n";else md<<"Reparos sugeridos de alta confianca: "<<suggestions.size()<<". O PAK/fonte original permanece intacto.\n";
    std::ofstream log(repair / "logs" / "runtime.log");
    log << "Runtime log placeholder. The generated native runtime will write diagnostics here.\n";
}
