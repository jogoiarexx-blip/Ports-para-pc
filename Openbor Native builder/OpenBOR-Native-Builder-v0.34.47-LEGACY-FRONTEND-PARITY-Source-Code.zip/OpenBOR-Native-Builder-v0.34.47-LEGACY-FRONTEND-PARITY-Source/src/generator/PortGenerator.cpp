#include "PathEncoding.hpp"
#include "PortGenerator.hpp"
#include "NativeRuntimeTemplate.hpp"
#include "RepairPackage.hpp"
#include "CharacterParser.hpp"
#include "GameplayGenerator.hpp"
#include "LevelParser.hpp"
#include "StageGenerator.hpp"
#include "ParityAudit.hpp"
#include "SafePath.hpp"
#include <fstream>
#include <filesystem>
#include <cctype>
#include <stdexcept>


namespace {
void copyTreeSafe(const std::filesystem::path& source, const std::filesystem::path& target){
    std::filesystem::create_directories(target);
    std::error_code ec;
    for(std::filesystem::recursive_directory_iterator it(source, std::filesystem::directory_options::skip_permission_denied, ec), end; it!=end; it.increment(ec)){
        if(ec){ ec.clear(); continue; }
        const auto& entry=*it;
        if(entry.is_symlink(ec)){ if(entry.is_directory(ec)) it.disable_recursion_pending(); continue; }
        auto rel=std::filesystem::relative(entry.path(), source, ec);
        if(ec || !SafePath::isSafeRelative(rel)){ ec.clear(); if(entry.is_directory(ec)) it.disable_recursion_pending(); continue; }
        auto dest=target/rel;
        if(entry.is_directory(ec)) std::filesystem::create_directories(dest,ec);
        else if(entry.is_regular_file(ec)){
            std::filesystem::create_directories(dest.parent_path(),ec);
            ec.clear();
            std::filesystem::copy_file(entry.path(),dest,std::filesystem::copy_options::overwrite_existing,ec);
        }
        ec.clear();
    }
}
}

void PortGenerator::generate(const ScanReport& report, const CompatibilityReport& compatibility,
                             const std::filesystem::path& outDir) {
    if(report.hasDataDir && SafePath::isWithin(report.dataDir, outDir))
        throw std::runtime_error("Output folder must not be inside the source data/ directory.");
    std::filesystem::create_directories(outDir / "assets");
    std::filesystem::create_directories(outDir / "runtime");
    std::filesystem::create_directories(outDir / "config");
    std::filesystem::create_directories(outDir / "reports");

    bool preservedHdOverride = false;
    std::filesystem::path hdOverrideSource;
    if (report.hasDataDir) {
        auto target = outDir / "assets" / "openbor-data";
        std::filesystem::create_directories(target);
        copyTreeSafe(report.dataDir, target);

        // Final Fight X HD crossfeed: preserve optional high-resolution replacement
        // trees next to the classic data directory. The generated runtime resolves
        // validated scale-aware overrides without changing logical geometry and
        // falls back to classic assets when an override is incompatible.
        auto leaf = PathEncoding::utf8(report.dataDir.filename());
        for (auto& c : leaf) c = (char)std::tolower((unsigned char)c);
        std::vector<std::filesystem::path> hdCandidates;
        if (leaf == "data") hdCandidates.push_back(report.dataDir.parent_path() / "data_hd");
        if (leaf == "openbor-data") {
            hdCandidates.push_back(report.dataDir.parent_path() / "openbor-data-hd");
            hdCandidates.push_back(report.dataDir.parent_path() / "data_hd");
        }
        for (const auto& candidate : hdCandidates) {
            if (std::filesystem::is_directory(candidate)) {
                hdOverrideSource = candidate;
                copyTreeSafe(candidate, outDir / "assets" / "openbor-data-hd");
                preservedHdOverride = true;
                break;
            }
        }
    }

    std::ofstream cfg(outDir / "config" / "port.ini");
    cfg << "[port]\nformat_version=3\nsource=OpenBOR\nruntime=native-cpp\nbuilder=0.34.47\ncompatibility_scan=true\nai_repair_package=true\n"
        << "logical_width=" << compatibility.logicalWidth << "\nlogical_height=" << compatibility.logicalHeight << "\n";
    std::ofstream videoCfg(outDir / "config" / "openbor-video.ini", std::ios::trunc);
    videoCfg << "logical_width=" << compatibility.logicalWidth << "\nlogical_height=" << compatibility.logicalHeight << "\n";

    std::ofstream rep(outDir / "reports" / "compatibility.txt");
    rep << "OpenBOR Native Builder - Compatibility Report\n";
    rep << "Files: " << report.files << "\nImages: " << report.images << "\nAudio: " << report.audio
        << "\nText/script-like: " << report.text << "\n";
    rep << "models.txt: " << (report.hasModels ? "OK" : "MISSING") << "\n";
    rep << "levels.txt: " << (report.hasLevels ? "OK" : "MISSING") << "\n";
    rep << "Scanned text files: " << compatibility.scannedTextFiles << "\n";
    rep << "Recognized commands: " << compatibility.recognizedCommands << "\n";
    rep << "Unknown commands: " << compatibility.unknownCommands << "\n";
    rep << "Issues: " << compatibility.issues.size() << "\n\n";
    for (const auto& issue : compatibility.issues) {
        rep << '[' << CompatibilityAnalyzer::levelName(issue.level) << "] "
            << PathEncoding::utf8(issue.file) << ':' << issue.line << " command=" << issue.command
            << " - " << issue.message << "\n";
    }
    for (const auto& w : report.warnings) rep << "[WARNING] " << w << "\n";

    std::ofstream commands(outDir / "reports" / "command-usage.csv");
    commands << "command,count\n";
    for (const auto& [name, count] : compatibility.commandUsage) commands << name << ',' << count << "\n";

    std::ofstream special(outDir / "reports" / "openbor-special-files.txt");
    special << "OpenBOR special/global files audit\n\n";
    special << "menu.txt: " << (report.hasMenu ? "FOUND - renamekey/disablekey are consumed by the native controls frontend" : "not present - native fallback labels are used") << "\n";
    special << "video.txt: " << (report.hasVideo ? "FOUND - preserved; native D3D11 renderer settings are generated separately in graphics.ini" : "not present") << "\n";
    special << "lifebar.txt: " << (report.hasLifebar ? "FOUND - preserved; custom lifebar layout still partial" : "not present") << "\n";
    special << "script.txt: " << (report.hasScriptConfig ? "FOUND - scripting compatibility required" : "not present") << "\n";
    special << "bgs/title.(gif/png/bmp): " << (report.hasTitleBackground ? "FOUND - used by native Title/Press Start and menu flow" : "not present - generated menu uses fallback background") << "\n";
    special << "bgs/select.(gif/png/bmp): " << (report.hasSelectBackground ? "FOUND - used as native Character Select background; original model select animations are rendered over it" : "not present - generated select background is used") << "\n";
    special << "bgs/loading/loading2: " << (report.hasLoadingBackground ? "FOUND - native loading flow selects 1P/2P background without artificial 250ms delay" : "not present") << "\n";

    std::ofstream audioReport(outDir / "reports" / "audio-compatibility.txt");
    audioReport << "OpenBOR Native Builder 0.34.47 - Audio Compatibility Report\n";
    audioReport << "Supported directly: legacy .bor ADPCM plus PCM/float WAV.\n";
    audioReport << "Windows compressed-audio backend: Media Foundation decodes MP3/FLAC and attempts OGG/OGA/AAC/M4A when a system codec is available, then XAudio2 plays decoded PCM.\n\n";
    if (report.hasDataDir) {
        for (const auto& e : std::filesystem::recursive_directory_iterator(report.dataDir)) {
            if (!e.is_regular_file()) continue;
            auto ext=PathEncoding::utf8(e.path().extension()); for(auto& c:ext)c=(char)std::tolower((unsigned char)c);
            if(ext==".bor"||ext==".wav"||ext==".ogg"||ext==".mp3"||ext==".flac") {
                auto rel=PathEncoding::utf8(std::filesystem::relative(e.path(), report.root));
                const char* status=(ext==".bor"||ext==".wav")?"NATIVE":"WINDOWS_MEDIA_FOUNDATION";
                audioReport << status << "\t" << rel << "\t" << std::filesystem::file_size(e.path()) << " bytes\n";
            }
        }
    }

    std::ofstream graphicsReport(outDir / "reports" / "graphics-backend.txt");
    graphicsReport << "OpenBOR Native Builder v0.34.47 - Graphics Backend\n\n";
    graphicsReport << "Windows primary backend: Direct3D 11 final-frame post-processing with hardware device, WARP fallback and Win32/GDI presentation fallback.\n";
    graphicsReport << "UI layer: original OpenBOR bitmap fonts are rendered as cached sprite glyphs on the logical surface; DirectWrite remains a Unicode/missing-font fallback. Sprite decoding remains WIC-compatible and preserves OpenBOR palette-index-0 transparency.\n";
    graphicsReport << "Upscale modes: original/nearest, sharp-bilinear, CAS-style sharpen, xBRZ-like edge-aware smoothing.\n";
    graphicsReport << "Filters: CRT mask, scanlines, optional curvature, bloom, contrast, saturation, banding reduction, configurable sharpen.\n";
    graphicsReport << "Image modes: pixel-perfect, keep 4:3, crop-fill 16:9 without stretching, integer 2x/3x/4x, nearest/bilinear.\n";
    graphicsReport << "Performance: V-Sync on/off, 60/120/144/unlimited FPS, presets Original/Improved/CRT/Sharp.\n";
    graphicsReport << "v0.34.38: direct premultiplied software compositing eliminates per-sprite CreateDIBSection/CreateCompatibleDC churn; decoded sprites and expensive drawmethod transforms use bounded LRU-style caches.\n";
    graphicsReport << "v0.34.39 GPU path: persistent D3D11 sprite textures, sequence-preserving command buffering, same-texture batching, cached back-buffer RTV, and automatic CPU fallback for legacy blend modes 3-6.\n";
    graphicsReport << "v0.34.40 shader/atlas path: drawmethod flip/scale/shear/rotation/fill/tint remain as compact instance parameters; vertex/pixel shaders transform the original sprite, DrawInstanced batches commands, and a 2D atlas stored in Texture2DArray reduces texture binds across differently-sized sprites.\n";
    graphicsReport << "HD format preference: lossless WebP is tried before PNG when prefer_webp=true; WIC decode failure falls through to the next available override/original.\n";
    graphicsReport << "Important: GPU post-processing and HD supersampling operate only in the renderer; hitboxes, physics, entity coordinates and OpenBOR timing data remain in logical coordinates.\n";

    std::ofstream fontReport(outDir / "reports" / "bitmap-font-audit.txt");
    fontReport << "OpenBOR Native Builder v0.34.47 - Bitmap Font Audit\n\n";
    fontReport << "Runtime behavior: original OpenBOR font sheets are split into a 16x16 glyph grid once at startup, cached as sprite glyphs and rendered through the same GPU sprite batching/atlas path.\n";
    fontReport << "Selection behavior: OpenBOR font 0/1/2 roles are preserved for normal/highlighted/headline menu text. Glyphs are clipped to authored alpha bounds and advanced with variable token widths unless menu.txt fontmonospace requests fixed cells. DirectWrite is fallback only for Unicode or missing bitmap fonts.\n\n";
    static const char* fontNames[]={"font.gif","font2.gif","font3.gif","font4.gif","font5.gif","font6.gif","font7.gif","font8.gif","ofont.gif","ofont2.gif","ofont3.gif","ofont4.gif","ofont5.gif","ofont6.gif","ofont7.gif","ofont8.gif"};
    std::size_t foundFonts=0;
    for(auto* name:fontNames){auto fp=report.dataDir/"sprites"/name;bool exists=std::filesystem::exists(fp);if(exists)++foundFonts;fontReport<<(exists?"FOUND\t":"MISSING\t")<<"sprites/"<<name<<"\n";}
    fontReport << "\nfound_font_sheets="<<foundFonts<<"\n";
    fontReport << "directwrite_role=fallback-only\n";

    std::ofstream hdReport(outDir / "reports" / "hd-override-assets.txt");
    hdReport << "OpenBOR Native Builder v0.34.47 - HD Override Resolver\n\n";
    if (preservedHdOverride) {
        hdReport << "Status: PRESERVED\n";
        hdReport << "Source: " << PathEncoding::utf8(hdOverrideSource) << "\n";
        hdReport << "Destination: assets/openbor-data-hd\n";
        hdReport << "Runtime activation: ENABLED - scale-aware runtime override resolver\n";
        hdReport << "Preferred HD format: WebP (lossless recommended), with PNG/GIF/BMP/PCX fallback.\n";
        hdReport << "Performance cache: decoded sprite cache plus a CPU-only drawmethod transform cache for fallback frames; the primary D3D11 path keeps one original sprite and applies drawmethod transforms in shaders.\n";
        hdReport << "GPU packing: small/medium sprites are shelf-packed into Texture2DArray atlas layers; oversized images use persistent dedicated array textures.\n";
        hdReport << "Safety: every HD image is dimension-checked against its original at load time; non-uniform/mismatched overrides fall back to the original asset.\n";
        hdReport << "Logical gameplay coordinates remain unchanged while the renderer supersamples the internal surface according to hd_render_scale.\n";
    } else {
        hdReport << "Status: none detected next to the source data directory.\n";
    }

    std::ofstream inputReport(outDir / "reports" / "input-multiplayer.txt");
    inputReport << "OpenBOR Native Builder v0.34.47 - Input / Local Multiplayer\n\n";
    inputReport << "Players: native local simulation supports 1-4 players in the generated runtime.\n";
    inputReport << "Character Select: P1 is always available; P2-P4 can join with A/Start and leave with B. Each joined pad can change character with D-pad left/right.\n";
    inputReport << "Keyboard: P1 movement/actions are remappable in the Controls menu and persisted in graphics.ini.\n";
    inputReport << "Gamepad: attack/jump/pickup/dash/grab/throw button masks are remappable; controller slot 1-4 is selectable per local player.\n";
    inputReport << "Gameplay: extra local players have independent position, animation, HP, attack/jump state, enemy targeting, damage reception and HUD bars.\n";
    inputReport << "Save/Continue: active party, selected characters and HP are preserved in saves/slot1.sav.\n";
    inputReport << "Known partial areas: advanced per-player weapon ownership, grab/throw ownership and exact OpenBOR multiplayer edge cases remain compatibility work.\n\n";

    std::ofstream scriptReport(outDir / "reports" / "script-vm-compatibility.txt");
    scriptReport << "OpenBOR Native Builder v0.34.47 - Script VM Compatibility\n\n";
    scriptReport << "Implemented syntax: C-like main(), variables, assignments, arithmetic/comparison/logical/bitwise expressions, if/else, for/while/do, switch/case, ternary expressions, break/continue/return, arrays, string/number/bool literals, plus object-like/function-like #define and #include/#import preprocessing.\n";
    scriptReport << "Implemented VM storage: local/global variables and persistent per-entity local context.\n";
    scriptReport << "Host APIs: openborconstant/openborvariant/changeopenborvariant, getentity/findtarget/checkrange, get/changeentityproperty, get/set/clearentityvar, get/changeplayerproperty/playerkeys, clear/setspawnentry+spawn, performattack/setanimation/setidle/updateframe, damageentity, killentity, jumptobranch, playmusic/pausemusic, loadsample/playsample/unloadsample, native subscreens, setdrawmethod/changedrawmethod, drawsprite/drawscreen/drawspriteq/clearspriteq, log plus local/global/indexed var helpers.\n";
    scriptReport << "Hooks wired: think, update, keyscript/global keyN.c/keyall.c, onmovex/onmovez, entity-collision, animation (on frame entry), spawnscript, take-damage, did-hit, on-draw, on-spawn, on-death, on-pain and on-fall.\n";
    scriptReport << "Fallback: unmapped engine APIs are logged diagnostically and preserved in AI-Repair instead of being silently dropped. Advanced drawmethod clip/channel/center/repeat/water properties remain partial; direct drawing now shares Z/sortid ordering with native gameplay layers and HUD.\n";
    scriptReport << "v0.34.47 performance: static script files and authored animation commands cache their preprocessed/tokenized programs; repeated update/think/key hooks reuse tokens instead of preprocessing and lexing the same source every invocation.\n\n";
    if (report.hasDataDir) {
        for (const auto& e : std::filesystem::recursive_directory_iterator(report.dataDir)) {
            if (!e.is_regular_file()) continue;
            auto ext=PathEncoding::utf8(e.path().extension()); for(auto& c:ext)c=(char)std::tolower((unsigned char)c);
            if(ext==".c"||ext==".h") scriptReport << "VM_CANDIDATE\t" << PathEncoding::utf8(std::filesystem::relative(e.path(), report.root)) << "\n";
        }
    }

    auto characters = CharacterParser::parseAll(report.dataDir, report.root);
    GameplayGenerator::generate(characters, outDir);
    auto stages = LevelParser::parseAll(report.dataDir, report.root);
    StageGenerator::generate(stages, outDir);

    // v0.34.47: audit authored presentation flow separately from parser coverage.
    // A port can report 100% commands while still skipping logo/intro/title/select
    // screens, so keep a concrete count of the OpenBOR presentation entries that
    // made it into native metadata.
    std::size_t selectEntries=0, preSceneFiles=0, postSceneFiles=0, cutsceneAnimations=0;
    for(const auto& st:stages){
        if(!st.selectFile.empty()) ++selectEntries;
        preSceneFiles += st.preSceneFiles.size();
        postSceneFiles += st.postSceneFiles.size();
        cutsceneAnimations += st.sceneAnimations.size()+st.postSceneAnimations.size();
    }
    auto dataPath=outDir/"assets"/"openbor-data";
    auto existsAny=[&](std::initializer_list<const char*> rels){for(auto r:rels)if(std::filesystem::exists(dataPath/r))return true;return false;};
    std::ofstream flow(outDir/"reports"/"frontend-flow.txt");
    flow << "OpenBOR Native Builder v0.34.47 - Authored Frontend/Campaign Flow\n\n";
    flow << "logo_background=" << (existsAny({"bgs/logo.gif","bgs/logo.png","bgs/logo.bmp"})?"YES":"NO") << "\n";
    flow << "intro_scene=" << (std::filesystem::exists(dataPath/"scenes"/"intro.txt")?"YES":"NO") << "\n";
    flow << "title_background=" << (existsAny({"bgs/title.gif","bgs/title.png","bgs/title.bmp"})?"YES":"NO") << "\n";
    flow << "completed_title_background=" << (existsAny({"bgs/titleb.gif","bgs/titleb.png","bgs/titleb.bmp"})?"YES":"NO") << "\n";
    flow << "howto_scene=" << (std::filesystem::exists(dataPath/"scenes"/"howto.txt")?"YES":"NO") << "\n";
    flow << "gameover_background=" << (existsAny({"bgs/gameover.gif","bgs/gameover.png","bgs/gameover.bmp"})?"YES":"NO") << "\n";
    flow << "hiscore_background=" << (existsAny({"bgs/hiscore.gif","bgs/hiscore.png","bgs/hiscore.bmp"})?"YES":"NO") << "\n";
    flow << "complete_background=" << (existsAny({"bgs/complete.gif","bgs/complete.png","bgs/complete.bmp"})?"YES":"NO") << "\n";
    flow << "loading_1p=" << (existsAny({"bgs/loading.gif","bgs/loading.png","bgs/loading.bmp"})?"YES":"NO") << "\n";
    flow << "loading_2p=" << (existsAny({"bgs/loading2.gif","bgs/loading2.png","bgs/loading2.bmp"})?"YES":"NO") << "\n";
    flow << "campaign_select_entries=" << selectEntries << "\n";
    flow << "campaign_pre_scene_files=" << preSceneFiles << "\n";
    flow << "campaign_post_scene_files=" << postSceneFiles << "\n";
    flow << "generated_cutscene_animation_steps=" << cutsceneAnimations << "\n";
    flow << "startup_order=logo -> logo scene -> intro -> title/press start -> titleb main menu\n"
         << "main_menu=Start Game -> Options -> How To Play -> Hall Of Fame -> Quit\n"
         << "start_game_menu=Choose Mode -> New Game / Load Game / Back\n"
         << "game_mode_layout=Game Mode -> 5 campaigns per page -> Back\n"
         << "font_layout=variable-width clipped glyphs + font0/font1/font2 legacy roles\n";
    flow << "runtime_notes=HOW TO PLAY, GAME OVER, HALL OF FAME, titleb-after-press-start, stage complete and per-stage select backgrounds are restored when the authored assets exist.\n";

    NativeRuntimeTemplate::generate(outDir);
    ParityAudit::writeMarkdown(outDir / "reports" / "openbor-parity.md");
    RepairPackage::generate(report, compatibility, outDir);

    std::ofstream readme(outDir / "README-PORT.txt");
    readme << "Generated by OpenBOR Native Builder 0.34.47\n\n";
    readme << "v0.34.47 LEGACY-FRONTEND-PARITY: restores the OpenBOR title/titleb menu state machine (Start Game, Options, How To Play, Hall Of Fame, Quit; Choose Mode; Game Mode; Load Game), uses variable-width clipped font.gif/font2... glyph metrics and menu.txt fontmonospace, and preserves the v0.34.46 Windows profiler/bitmap-font path. DirectWrite is fallback only.\n\n";

    readme << "Runtime reliability: use DIAGNOSTICO.cmd for preflight, SMOKE-TESTE.cmd for a 600-frame gameplay loop, and MEDIR-FPS-WINDOWS.cmd for a 3600-frame unlimited/V-Sync-off performance pass. Runtime startup/crash logs remain beside the game executable. Save format V2 preserves player combat state, and player spawn points are adjusted away from authored wall/hole geometry when necessary.\n\n";
    readme << "This project contains the preserved OpenBOR assets, compatibility diagnostics, an AI repair package and a compilable C++ runtime skeleton.\n";
    readme << "Character, animation, frame, delay, offset, bbox and basic attack data are translated into generated C++ structures. The preview runtime now plays frame timing, loads sprite images on Windows through WIC, applies OpenBOR offsets and can draw bbox/attack debug overlays. Legacy OpenBOR palette-index transparency is emulated before presentation; source alpha/shadows are preserved. Windows ports now use a Direct3D 11 post-process backend with original OpenBOR bitmap-font UI with DirectWrite fallback, hardware/WARP/GDI fallback, selectable upscale modes, CRT/image filters, pixel-perfect/aspect/integer scaling, V-Sync and graphics presets. Legacy .bor music is now identified as OpenBOR ADPCM and decoded to PCM before playback; raw .bor bytes are never sent to XAudio2. Music/effects/master volumes are separated in runtime configuration. v0.5 adds PCM WAV decoding, WAV smpl loop metadata, automatic preview-music selection, config loading, runtime volume hotkeys and an audio compatibility report. v0.6 adds levels.txt parsing, generated native stage data, background loading, stage music selection, player start positions, keyboard movement, camera scrolling, Z-lane clamping and spawn triggers with basic enemy preview entities. On Windows, MP3/FLAC and other compressed formats use Media Foundation; OGG is attempted when a system codec is present. Non-Windows generated runtimes still preserve unsupported compressed audio with diagnostics.\n";
}
