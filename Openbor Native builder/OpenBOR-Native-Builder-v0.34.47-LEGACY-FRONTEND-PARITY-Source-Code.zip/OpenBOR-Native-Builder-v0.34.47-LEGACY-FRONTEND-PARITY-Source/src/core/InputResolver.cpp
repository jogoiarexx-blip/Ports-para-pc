#include "ProcessRunner.hpp"
#include "PathEncoding.hpp"
#include "InputResolver.hpp"
#include "SafePath.hpp"
#include <algorithm>
#include <array>
#include <chrono>
#include <cctype>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <limits>
#include <sstream>
#include <stdexcept>
#include <system_error>

#ifdef _WIN32
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#endif

namespace {
std::string lower(std::string s){
    std::transform(s.begin(),s.end(),s.begin(),[](unsigned char c){return static_cast<char>(std::tolower(c));});
    return s;
}

#ifdef _WIN32
std::string psSingleQuote(const std::filesystem::path& p){
    std::string s=PathEncoding::utf8(p),out="'";for(char c:s){if(c=='\'')out+="''";else out+=c;}out+="'";return out;
}
#endif

std::filesystem::path makeWorkspace(){
    std::error_code ec;
    auto base=std::filesystem::temp_directory_path(ec);
    if(ec) base=std::filesystem::current_path();
    base/="OpenBOR-Native-Builder";
    std::filesystem::create_directories(base,ec);
    const auto ticks=std::chrono::high_resolution_clock::now().time_since_epoch().count();
#ifdef _WIN32
    const auto pid=static_cast<unsigned long long>(GetCurrentProcessId());
#else
    const auto pid=static_cast<unsigned long long>(ticks & 0xffffu);
#endif
    auto out=base/("session-"+std::to_string(static_cast<unsigned long long>(ticks))+"-"+std::to_string(pid));
    if(!std::filesystem::create_directories(out,ec) || ec) throw std::runtime_error("Nao foi possivel criar area temporaria: "+PathEncoding::utf8(out));
    return out;
}

enum class ArchiveKind { Unknown, Zip, Rar, Pak };

ArchiveKind sniffArchiveKind(const std::filesystem::path& file){
    std::ifstream in(file,std::ios::binary);if(!in)return ArchiveKind::Unknown;
    std::array<unsigned char,8>b{};in.read(reinterpret_cast<char*>(b.data()),(std::streamsize)b.size());auto n=in.gcount();
    if(n>=4&&b[0]=='P'&&b[1]=='A'&&b[2]=='C'&&b[3]=='K')return ArchiveKind::Pak;
    if(n>=4&&b[0]=='P'&&b[1]=='K'&&(b[2]==3||b[2]==5||b[2]==7)&&(b[3]==4||b[3]==6||b[3]==8))return ArchiveKind::Zip;
    if(n>=7&&b[0]=='R'&&b[1]=='a'&&b[2]=='r'&&b[3]=='!'&&b[4]==0x1a&&b[5]==0x07&&(b[6]==0x00||b[6]==0x01))return ArchiveKind::Rar;
    return ArchiveKind::Unknown;
}

#ifdef _WIN32
std::filesystem::path find7Zip(){
    wchar_t found[32768]{};DWORD n=SearchPathW(nullptr,L"7z.exe",nullptr,(DWORD)std::size(found),found,nullptr);
    if(n>0&&n<std::size(found))return std::filesystem::path(found);
    std::vector<std::filesystem::path> c;
    if(const wchar_t* pf=_wgetenv(L"ProgramFiles"))c.push_back(std::filesystem::path(pf)/L"7-Zip"/L"7z.exe");
    if(const wchar_t* pfx=_wgetenv(L"ProgramFiles(x86)"))c.push_back(std::filesystem::path(pfx)/L"7-Zip"/L"7z.exe");
    for(const auto& p:c)if(std::filesystem::exists(p))return p;return {};
}
#endif

bool extractArchive(const std::filesystem::path& archive,const std::filesystem::path& destination,ArchiveKind kind,std::string& error){
    std::error_code ec;std::filesystem::create_directories(destination,ec);
    if(ec){error="falha criando destino do arquivo: "+ec.message();return false;}
#ifdef _WIN32
    int psRc=-1;
    if(kind==ArchiveKind::Zip){
        // Expand-Archive is reliable for ordinary ZIPs, but must not be used for
        // RAR files merely renamed to .zip (seen in real OpenBOR packages).
        std::string script="Expand-Archive -LiteralPath "+psSingleQuote(archive)+" -DestinationPath "+psSingleQuote(destination)+" -Force";
        psRc=ProcessRunner::run({"powershell.exe","-NoProfile","-NonInteractive","-ExecutionPolicy","Bypass","-Command",script});
        if(psRc==0)return true;
    }
    // Windows tar.exe is bsdtar/libarchive on supported Windows releases and can
    // identify archives by their content rather than by their extension.
    int tarRc=ProcessRunner::run({"tar.exe","-xf",PathEncoding::utf8(archive),"-C",PathEncoding::utf8(destination)});
    if(tarRc==0)return true;
    auto seven=find7Zip();int sevenRc=-1;
    if(!seven.empty())sevenRc=ProcessRunner::run({PathEncoding::utf8(seven),"x","-y","-o"+PathEncoding::utf8(destination),PathEncoding::utf8(archive)});
    if(sevenRc==0)return true;
    if(kind==ArchiveKind::Rar)error="RAR detectado pelo conteudo, mas tar.exe/7-Zip nao conseguiram extrair (codigos "+std::to_string(tarRc)+"/"+std::to_string(sevenRc)+"). Instale 7-Zip ou extraia o RAR e selecione a pasta do jogo.";
    else error="PowerShell/tar.exe/7-Zip nao conseguiram extrair o arquivo (codigos "+std::to_string(psRc)+"/"+std::to_string(tarRc)+"/"+std::to_string(sevenRc)+")";
    return false;
#else
    auto old=std::filesystem::current_path();std::filesystem::current_path(destination,ec);
    if(ec){error="falha acessando destino do arquivo: "+ec.message();return false;}
    int rc=ProcessRunner::run({"cmake","-E","tar","xf",PathEncoding::utf8(std::filesystem::absolute(archive))});
    if(rc!=0&&kind==ArchiveKind::Rar)rc=ProcessRunner::run({"bsdtar","-xf",PathEncoding::utf8(std::filesystem::absolute(archive))});
    if(rc!=0&&kind==ArchiveKind::Rar)rc=ProcessRunner::run({"7z","x","-y",PathEncoding::utf8(std::filesystem::absolute(archive))});
    std::filesystem::current_path(old,ec);
    if(rc!=0){error=kind==ArchiveKind::Rar?"RAR detectado, mas nenhum extrator RAR compativel conseguiu abri-lo":"nao foi possivel extrair o arquivo";return false;}
    return true;
#endif
}

std::filesystem::path candidateDataDir(const std::filesystem::path& root){
    auto normal=SafePath::resolveWithin(root,"data");if(std::filesystem::is_directory(normal))return normal;
    auto portable=(root/"assets"/"openbor-data").lexically_normal();if(std::filesystem::is_directory(portable))return portable;
    return {};
}

int candidateScore(const std::filesystem::path& root){
    const auto data=candidateDataDir(root);
    if(data.empty()) return -1;
    int score=10;
    if(std::filesystem::exists(SafePath::resolveWithin(data,"models.txt"))) score+=1000;
    if(std::filesystem::exists(SafePath::resolveWithin(data,"levels.txt"))) score+=900;
    if(std::filesystem::exists(SafePath::resolveWithin(data,"video.txt"))) score+=40;
    if(std::filesystem::exists(SafePath::resolveWithin(data,"menu.txt"))) score+=30;
    if(std::filesystem::exists(SafePath::resolveWithin(data,"script.txt"))) score+=20;
    std::error_code ec; int txt=0;
    for(std::filesystem::recursive_directory_iterator it(data,std::filesystem::directory_options::skip_permission_denied,ec),end;it!=end && txt<200;++it){
        if(ec){ec.clear();continue;} if(it->is_regular_file(ec)){auto e=lower(PathEncoding::utf8(it->path().extension()));if(e==".txt"||e==".c")++txt;}
    }
    return score+std::min(txt,200);
}

std::vector<std::filesystem::path> discoverRoots(const std::filesystem::path& base){
    std::vector<std::pair<int,std::filesystem::path>> scored;
    std::error_code ec;
    auto add=[&](const std::filesystem::path& root){int s=candidateScore(root);if(s>=0)scored.push_back({s,root});};
    add(base);
    if(lower(PathEncoding::utf8(base.filename()))=="data" && std::filesystem::is_directory(base)) add(base.parent_path());
    for(std::filesystem::recursive_directory_iterator it(base,std::filesystem::directory_options::skip_permission_denied,ec),end;it!=end;++it){
        if(ec){ec.clear();continue;}
        if(!it->is_directory(ec)) continue;
        auto rel=it->path().lexically_relative(base);
        if(std::distance(rel.begin(),rel.end())>10){it.disable_recursion_pending();continue;}
        auto leaf=lower(PathEncoding::utf8(it->path().filename()));
        if(leaf=="data") add(it->path().parent_path());
        else if(leaf=="openbor-data"&&lower(PathEncoding::utf8(it->path().parent_path().filename()))=="assets") add(it->path().parent_path().parent_path());
    }
    std::sort(scored.begin(),scored.end(),[](const auto&a,const auto&b){if(a.first!=b.first)return a.first>b.first;return PathEncoding::utf8(a.second)<PathEncoding::utf8(b.second);});
    std::vector<std::filesystem::path> out;
    for(auto& [s,p]:scored){(void)s;std::error_code c;auto canon=std::filesystem::weakly_canonical(p,c);if(c)canon=std::filesystem::absolute(p).lexically_normal();if(std::find(out.begin(),out.end(),canon)==out.end())out.push_back(canon);}
    return out;
}

std::vector<std::filesystem::path> findPaks(const std::filesystem::path& base){
    std::vector<std::filesystem::path> out;std::error_code ec;
    if(std::filesystem::is_regular_file(base,ec)&&lower(PathEncoding::utf8(base.extension()))==".pak")return {base};
    for(std::filesystem::recursive_directory_iterator it(base,std::filesystem::directory_options::skip_permission_denied,ec),end;it!=end;++it){
        if(ec){ec.clear();continue;}if(it->is_regular_file(ec)&&lower(PathEncoding::utf8(it->path().extension()))==".pak")out.push_back(it->path());
    }
    std::sort(out.begin(),out.end());return out;
}

bool readU32(std::ifstream& in,std::uint32_t& v){
    std::array<unsigned char,4>b{}; if(!in.read(reinterpret_cast<char*>(b.data()),4))return false;
    v=(std::uint32_t)b[0]|((std::uint32_t)b[1]<<8)|((std::uint32_t)b[2]<<16)|((std::uint32_t)b[3]<<24);return true;
}

std::filesystem::path chooseBest(const std::vector<std::filesystem::path>& roots){return roots.empty()?std::filesystem::path{}:roots.front();}
}

ResolvedGameInput::ResolvedGameInput(ResolvedGameInput&& other) noexcept {
    original=std::move(other.original);gameRoot=std::move(other.gameRoot);workspace=std::move(other.workspace);sourceKind=std::move(other.sourceKind);discoveredCandidates=std::move(other.discoveredCandidates);temporary=other.temporary;other.temporary=false;
}
ResolvedGameInput& ResolvedGameInput::operator=(ResolvedGameInput&& other) noexcept {
    if(this!=&other){if(temporary&&!workspace.empty()){std::error_code ec;std::filesystem::remove_all(workspace,ec);}original=std::move(other.original);gameRoot=std::move(other.gameRoot);workspace=std::move(other.workspace);sourceKind=std::move(other.sourceKind);discoveredCandidates=std::move(other.discoveredCandidates);temporary=other.temporary;other.temporary=false;}return *this;
}
ResolvedGameInput::~ResolvedGameInput(){if(temporary&&!workspace.empty()){std::error_code ec;std::filesystem::remove_all(workspace,ec);}}

bool InputResolver::extractOpenBorPak(const std::filesystem::path& pak,const std::filesystem::path& destination,std::string* error){
    auto fail=[&](std::string m){if(error)*error=std::move(m);return false;};
    std::ifstream in(pak,std::ios::binary);if(!in)return fail("nao foi possivel abrir PAK");
    in.seekg(0,std::ios::end);auto end=in.tellg();if(end<12)return fail("PAK pequeno/invalido");const auto fileSize=static_cast<std::uint64_t>(end);
    in.seekg(0);char sig[4]{};if(!in.read(sig,4)||std::string(sig,4)!="PACK")return fail("assinatura PACK nao encontrada");
    std::uint32_t version=0;if(!readU32(in,version))return fail("cabecalho PAK truncado");(void)version;
    in.seekg(static_cast<std::streamoff>(fileSize-4));std::uint32_t indexOffset=0;if(!readU32(in,indexOffset))return fail("rodape PAK truncado");
    if(indexOffset<8 || static_cast<std::uint64_t>(indexOffset)>=fileSize-4)return fail("offset do indice PAK invalido");
    const std::uint64_t indexEnd=fileSize-4;std::uint64_t cursor=indexOffset;std::error_code ec;std::filesystem::create_directories(destination,ec);if(ec)return fail("falha criando pasta para PAK: "+ec.message());
    std::size_t count=0;std::uint64_t totalWritten=0;constexpr std::uint64_t kMaxFiles=200000,kMaxExpanded=16ull*1024ull*1024ull*1024ull;
    while(cursor+12<=indexEnd){
        in.seekg(static_cast<std::streamoff>(cursor));std::uint32_t recordSize=0,offset=0,size=0;if(!readU32(in,recordSize)||!readU32(in,offset)||!readU32(in,size))return fail("indice PAK truncado");
        if(recordSize<13)break; // defensive terminator/invalid record
        if(cursor+recordSize>indexEnd)return fail("registro PAK ultrapassa o indice");
        const std::uint32_t nameBytes=recordSize-12;if(nameBytes>64*1024)return fail("nome PAK excessivamente grande");
        std::string name(nameBytes,'\0');if(!in.read(name.data(),nameBytes))return fail("nome PAK truncado");auto zero=name.find('\0');if(zero!=std::string::npos)name.resize(zero);
        for(char& c : name) {
            if(c=='\\') c='/';
        }
        while(name.rfind("./",0)==0) name.erase(0,2);
        while(name.rfind("/",0)==0) name.erase(0,1);
        if(name.empty()){cursor+=recordSize;continue;}
        auto rel=PathEncoding::path(name);if(!SafePath::isSafeRelative(rel))return fail("caminho inseguro dentro do PAK: "+name);
        if(static_cast<std::uint64_t>(offset)+size>indexOffset)return fail("arquivo PAK aponta para fora da area de dados: "+name);
        if(++count>kMaxFiles) return fail("PAK excede limite defensivo de arquivos");
        totalWritten += size;
        if(totalWritten>kMaxExpanded) return fail("PAK excede limite defensivo de extracao");
        auto relGeneric=lower(PathEncoding::utf8(rel));std::filesystem::path outRel;
        if(lower(relGeneric).rfind("data/",0)==0) outRel=std::filesystem::path("data")/PathEncoding::path(relGeneric.substr(5)); else outRel=std::filesystem::path("data")/rel;
        auto out=(destination/outRel).lexically_normal();if(!SafePath::isWithin(destination,out))return fail("tentativa de traversal no PAK: "+name);
        std::filesystem::create_directories(out.parent_path(),ec);if(ec)return fail("falha criando pasta do PAK: "+ec.message());
        std::ofstream f(out,std::ios::binary|std::ios::trunc);if(!f)return fail("falha criando arquivo extraido: "+PathEncoding::utf8(out));
        in.seekg(static_cast<std::streamoff>(offset));std::array<char,64*1024> buf{};std::uint32_t left=size;while(left){auto n=std::min<std::uint32_t>(left,(std::uint32_t)buf.size());if(!in.read(buf.data(),n))return fail("dados PAK truncados em: "+name);f.write(buf.data(),n);if(!f)return fail("falha gravando arquivo PAK: "+name);left-=n;}
        cursor+=recordSize;
    }
    if(count==0)return fail("nenhum arquivo valido encontrado no PAK");
    return true;
}

ResolvedGameInput InputResolver::resolve(const std::filesystem::path& input){
    std::error_code ec;auto original=std::filesystem::weakly_canonical(std::filesystem::absolute(input),ec);if(ec)original=std::filesystem::absolute(input).lexically_normal();
    if(!std::filesystem::exists(original))throw std::runtime_error("Entrada nao encontrada: "+PathEncoding::utf8(original));
    ResolvedGameInput r;r.original=original;
    if(std::filesystem::is_directory(original)){
        auto roots=discoverRoots(original);if(!roots.empty()){r.gameRoot=chooseBest(roots);r.discoveredCandidates=std::move(roots);r.sourceKind=(r.gameRoot==original?"folder":"openbor-package-folder");return r;}
        auto paks=findPaks(original);if(paks.empty())throw std::runtime_error("Nenhum data/ nem arquivo .pak OpenBOR foi encontrado dentro da pasta.");
        r.workspace=makeWorkspace();r.temporary=true;r.sourceKind="openbor-package-folder";std::vector<std::filesystem::path> all;
        for(std::size_t i=0;i<paks.size();++i){auto d=r.workspace/PathEncoding::path("pak-"+std::to_string(i)+"-"+PathEncoding::utf8(paks[i].stem()));std::string err;if(!extractOpenBorPak(paks[i],d,&err)){std::cerr<<"[WARN] PAK ignorado "<<PathEncoding::utf8(paks[i])<<": "<<err<<"\n";continue;}auto roots2=discoverRoots(d);all.insert(all.end(),roots2.begin(),roots2.end());}
        if(all.empty()) throw std::runtime_error("Arquivos .pak encontrados, mas nenhum projeto OpenBOR valido foi extraido.");
        std::sort(all.begin(),all.end(),[](const auto&a,const auto&b){return candidateScore(a)>candidateScore(b);});
        r.discoveredCandidates=all;
        r.gameRoot=all.front();
        return r;
    }
    const auto ext=lower(PathEncoding::utf8(original.extension()));auto kind=sniffArchiveKind(original);r.workspace=makeWorkspace();r.temporary=true;
    if(kind==ArchiveKind::Pak||(kind==ArchiveKind::Unknown&&ext==".pak")){
        r.sourceKind="pak";auto d=r.workspace/"pak";std::string err;if(!extractOpenBorPak(original,d,&err))throw std::runtime_error("Falha ao extrair PAK: "+err);auto roots=discoverRoots(d);if(roots.empty())throw std::runtime_error("PAK extraido, mas data/models.txt ou estrutura OpenBOR nao foi encontrada.");r.discoveredCandidates=roots;r.gameRoot=roots.front();return r;
    }
    if(kind==ArchiveKind::Unknown){
        if(ext==".zip")kind=ArchiveKind::Zip;else if(ext==".rar")kind=ArchiveKind::Rar;
        else throw std::runtime_error("Formato de entrada nao suportado. Use pasta, .zip, .rar ou .pak.");
    }
    if(kind!=ArchiveKind::Zip&&kind!=ArchiveKind::Rar)throw std::runtime_error("Arquivo reconhecido, mas o tipo de pacote ainda nao e suportado.");
    r.sourceKind=kind==ArchiveKind::Rar?(ext==".zip"?"rar-mislabeled-zip":"rar"):"zip";
    auto unpack=r.workspace/(kind==ArchiveKind::Rar?"rar":"zip");std::string err;if(!extractArchive(original,unpack,kind,err))throw std::runtime_error("Falha ao extrair "+std::string(kind==ArchiveKind::Rar?"RAR":"ZIP")+": "+err);
    auto roots=discoverRoots(unpack);
    if(!roots.empty()){r.discoveredCandidates=roots;r.gameRoot=roots.front();return r;}
    auto paks=findPaks(unpack);std::vector<std::filesystem::path> all;
    for(std::size_t i=0;i<paks.size();++i){auto d=r.workspace/PathEncoding::path("pak-"+std::to_string(i)+"-"+PathEncoding::utf8(paks[i].stem()));std::string pe;if(!extractOpenBorPak(paks[i],d,&pe)){std::cerr<<"[WARN] PAK no arquivo ignorado "<<PathEncoding::utf8(paks[i])<<": "<<pe<<"\n";continue;}auto rr=discoverRoots(d);all.insert(all.end(),rr.begin(),rr.end());}
    if(all.empty())throw std::runtime_error(std::string(kind==ArchiveKind::Rar?"RAR":"ZIP")+" extraido, mas nenhum data/, assets/openbor-data ou .pak OpenBOR valido foi encontrado.");
    std::sort(all.begin(),all.end(),[](const auto&a,const auto&b){return candidateScore(a)>candidateScore(b);});r.sourceKind=kind==ArchiveKind::Rar?"openbor-package-rar":"openbor-package-zip";r.discoveredCandidates=all;r.gameRoot=all.front();return r;
}
