#pragma once
#include "PathEncoding.hpp"
#include <vector>
#include <cstdlib>
#ifdef _WIN32
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#endif
namespace ProcessRunner {
inline int run(const std::vector<std::string>& args){
 if(args.empty())return -1;
#ifdef _WIN32
 // Launch UTF-16 arguments directly, without CMD expansion of file names.
 std::wstring command;
 for(const auto& s:args){
  if(!command.empty())command+=L' ';
  command+=L'"';unsigned slashes=0;
  for(wchar_t c:PathEncoding::path(s).wstring()){
   if(c==L'\\'){++slashes;continue;}
   command.append(c==L'"'?slashes*2+1:slashes,L'\\');slashes=0;command+=c;
  }
  command.append(slashes*2,L'\\');command+=L'"';
 }
 STARTUPINFOW startup{};startup.cb=sizeof(startup);PROCESS_INFORMATION process{};
 if(!CreateProcessW(nullptr,command.data(),nullptr,nullptr,TRUE,0,nullptr,nullptr,&startup,&process))return -1;
 CloseHandle(process.hThread);DWORD code=1;
 if(WaitForSingleObject(process.hProcess,INFINITE)==WAIT_OBJECT_0)GetExitCodeProcess(process.hProcess,&code);
 CloseHandle(process.hProcess);return static_cast<int>(code);
#else
 std::string command;
 for(const auto& s:args){if(!command.empty())command+=' ';command+='\'';for(char c:s){if(c=='\'')command+="'\\''";else command+=c;}command+='\'';}
 return std::system(command.c_str());
#endif
}
}
