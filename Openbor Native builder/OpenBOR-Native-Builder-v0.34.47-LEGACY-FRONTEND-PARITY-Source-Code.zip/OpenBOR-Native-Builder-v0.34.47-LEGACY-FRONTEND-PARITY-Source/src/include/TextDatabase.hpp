#pragma once
#include <filesystem>
#include <string>
#include <vector>

struct TextEntry {
    std::string key;
    std::vector<std::string> values;
    std::size_t line = 0;
    std::string scriptBody;
};

class TextDatabase {
public:
    static std::vector<TextEntry> parse(const std::filesystem::path& file);
};
