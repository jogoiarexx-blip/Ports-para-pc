#pragma once
#include "ProjectScanner.hpp"
#include "CommandRegistry.hpp"
#include <filesystem>
#include <map>
#include <set>
#include <string>
#include <vector>

enum class CompatibilityLevel { Green, Yellow, Red };

struct CompatibilityIssue {
    CompatibilityLevel level = CompatibilityLevel::Green;
    std::filesystem::path file;
    std::size_t line = 0;
    std::string command;
    std::string message;
    CommandStatus status = CommandStatus::Unknown;
    bool parser = false;
    bool runtime = false;
};

struct AnimationCommandDiagnostic {
    std::filesystem::path file;
    std::size_t line=0;
    std::string function,helper,detail;
    CommandStatus status=CommandStatus::Partial;
};

struct CompatibilityReport {
    std::size_t scannedTextFiles = 0;
    std::size_t recognizedCommands = 0;
    std::size_t unknownCommands = 0;
    std::size_t supportedCommands = 0;
    std::size_t partialCommands = 0;
    std::size_t unsupportedCommands = 0;
    std::size_t models = 0;
    std::size_t stages = 0;
    std::size_t animations = 0;
    std::size_t scripts = 0;
    std::size_t audioFiles = 0;
    int logicalWidth = 320;
    int logicalHeight = 240;
    std::string openborVersionHint;
    std::map<std::string, std::size_t> commandUsage;
    std::map<std::string, CommandStatus> commandStatus;
    std::vector<CompatibilityIssue> issues;
    std::vector<AnimationCommandDiagnostic> animationCommands;
    std::map<std::string,std::map<CommandStatus,std::size_t>> commandStatusCounts;
};

class CompatibilityAnalyzer {
public:
    static CompatibilityReport analyze(const ScanReport& scan);
    static const char* levelName(CompatibilityLevel level);
    static void writeReport(const ScanReport& scan, const CompatibilityReport& report, const std::filesystem::path& outDir);
};
