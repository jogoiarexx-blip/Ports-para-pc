#pragma once
#include <filesystem>
#include <string>
#include <string_view>
#include <cstdint>
namespace PathEncoding {
inline bool validUtf8(std::string_view s){
 for(std::size_t i=0;i<s.size();){auto c=static_cast<unsigned char>(s[i++]);if(c<128)continue;
  unsigned n;std::uint32_t code,min;
  if(c>=0xc2&&c<=0xdf){n=1;code=c&31;min=128;}
  else if(c>=0xe0&&c<=0xef){n=2;code=c&15;min=0x800;}
  else if(c>=0xf0&&c<=0xf4){n=3;code=c&7;min=0x10000;}
  else return false;
  if(i+n>s.size())return false;
  while(n--){auto b=static_cast<unsigned char>(s[i++]);if((b&0xc0)!=0x80)return false;code=(code<<6)|(b&63);}
  if(code<min||code>0x10ffff||(code>=0xd800&&code<=0xdfff))return false;
 }return true;
}
inline void appendUtf8(std::string& s,std::uint32_t c){
 if(c<128)s+=static_cast<char>(c);
 else if(c<0x800){s+=static_cast<char>(0xc0|(c>>6));s+=static_cast<char>(0x80|(c&63));}
 else{s+=static_cast<char>(0xe0|(c>>12));s+=static_cast<char>(0x80|((c>>6)&63));s+=static_cast<char>(0x80|(c&63));}
}
// Keep valid UTF-8 unchanged; decode legacy OpenBOR Windows-1252 bytes explicitly.
inline std::string text(std::string_view s){
 if(validUtf8(s))return std::string(s);
 static constexpr std::uint16_t cp[32]={0x20ac,0x81,0x201a,0x192,0x201e,0x2026,0x2020,0x2021,0x2c6,0x2030,0x160,0x2039,0x152,0x8d,0x17d,0x8f,0x90,0x2018,0x2019,0x201c,0x201d,0x2022,0x2013,0x2014,0x2dc,0x2122,0x161,0x203a,0x153,0x9d,0x17e,0x178};
 std::string out;for(unsigned char c:s)appendUtf8(out,c>=128&&c<160?cp[c-128]:c);return out;
}
inline std::filesystem::path path(std::string_view bytes){auto s=text(bytes);return std::filesystem::path(std::u8string(reinterpret_cast<const char8_t*>(s.data()),s.size()));}
inline std::string utf8(const std::filesystem::path& p){auto s=p.generic_u8string();return std::string(reinterpret_cast<const char*>(s.data()),s.size());}
}
