#include "ParityAudit.hpp"
#include <fstream>
#include <ostream>
#include <string>
#include <vector>
namespace {
struct Item { const char* category; const char* feature; const char* status; const char* detail; };
const std::vector<Item> items = {
 {"Frontend","Main menu","GREEN","Native frontend preserves original title/select backgrounds when present and exposes campaign/level-set selection before character selection."},
 {"Frontend","Pause menu","GREEN","Continue, Options, Restart Stage, Main Menu and Quit are available."},
 {"Frontend","Options persistence","GREEN","Audio, FPS, debug overlays and next-start video settings are saved to graphics.ini."},
 {"Frontend","Keyboard/gamepad input","GREEN","P1 keyboard actions can be rebound in the Controls menu; XInput action buttons are remappable and controller slots are configurable per player."},
 {"Frontend","Character select","GREEN","Native Character Select uses bgs/select when present, renders original model select animations, supports P2-P4 join/leave, and honors per-set skipselect."},
 {"Frontend","Save/Continue campaign","GREEN","Stage, active local party, selected characters and each player HP are persisted to a portable native save. Legacy OpenBOR save binaries are intentionally not reused."},
 {"Frontend","Hall of Fame / high scores","YELLOW","Authored bgs/hiscore is now shown through a native Hall-of-Fame state; exact legacy ranking/name-entry semantics remain partial."},
 {"Frontend","Game Over / Continue","GREEN","Player death uses authored gameover scene/background when present, then opens Continue using the portable campaign save. Exact legacy credit/result edge cases remain partial."},
 {"Rendering","Palette index 0 transparency","GREEN","Legacy indexed GIF transparency is recovered instead of rendering opaque magenta/palette colors."},
 {"Rendering","PNG/GIF/BMP alpha","GREEN","Source alpha is preserved and alpha blended by the Win32 renderer."},
 {"Rendering","PCX decoding","YELLOW","Legacy extension lookup includes PCX, but the current WIC path is not a guaranteed PCX decoder."},
 {"Rendering","drawmethod scale / rotate / flip / shift / fill","GREEN","Per-frame drawmethod state is persistent and executed by the native renderer with nearest-neighbor transforms."},
 {"Rendering","Legacy alpha blend modes","YELLOW","A software compositor now executes modes 1-6 instead of reducing them to opacity. Exact indexed-palette/LUT edge cases can still differ from historical OpenBOR builds."},
 {"Rendering","Palette remap","YELLOW","Remap metadata is preserved, but exact indexed-palette remap tables are not yet reproduced for every legacy asset."},
 {"Rendering","Palette/remap/alternatepal","YELLOW","Image- and ACT-based remaps now run per entity/player. Duplicate-color/index-only historical edge cases can still differ."},
 {"Rendering","Background/foreground layers and parallax","YELLOW","Background/bglayer backdrops, panel/frontpanel placement and fglayer Z ordering now share the native scene compositor; exact legacy repeat/water/neon/palette-layer edge cases remain partial."},
 {"Rendering","Shadows/lighting/quake","YELLOW","Source alpha shadows render, but OpenBOR shadow commands, lighting and quake behavior are incomplete."},
 {"Rendering","GPU backend","GREEN","Windows ports render the logical OpenBOR frame through Direct3D 11 shaders with hardware acceleration and WARP/GDI fallback; Direct2D/DirectWrite handle native UI text on the logical surface."},
 {"Rendering","GPU post-processing/upscale","GREEN","Original nearest, sharp-bilinear, CAS-style sharpen and xBRZ-like edge smoothing are selectable without changing gameplay coordinates, sprites or hitboxes."},
 {"Rendering","CRT/image filters","GREEN","Scanlines, light CRT mask, optional curvature, bloom, contrast, saturation, banding reduction and configurable sharpening are applied as final GPU post-processing."},
 {"Rendering","Aspect/integer scaling","GREEN","Pixel-perfect, 4:3 preservation, crop-based 16:9 fill without stretching, integer 2x/3x/4x and nearest/bilinear texture filtering are available."},
 {"Animation","frame/delay/offset/bbox/attack persistence","GREEN","OpenBOR frame-state persistence, loops, infinite delay and invisible frames are handled."},
 {"Animation","move/movea/movez","GREEN","Frame-driven X/Z/altitude movement is applied once when each animation frame becomes active."},
 {"Animation","velocity/flipframe","YELLOW","flipframe is applied on frame entry. Persistent velocity and some automatic-facing timing rules still need tighter OpenBOR parity."},
 {"Animation","Animation scripts/events","YELLOW","animationscript now fires on animation-frame entry instead of every tick. Unsupported APIs remain logged rather than silently ignored."},
 {"Stages","Basic levels/spawns/panels/music","GREEN","levels.txt, stage files, horizontal camera, panels, music and at-based spawns are generated; cross-type source order is preserved in StageInstruction."},
 {"Stages","wall/platform/hole geometry","YELLOW","Basic rectangular collision, pit reset/damage and platform regions are implemented; complex elevation/moving-platform semantics remain partial."},
 {"Stages","multi-stage/loading/next/end","GREEN","Sequential stages, loading, save checkpoints, Continue and campaign end are implemented. `at` now follows OpenBOR scroll coordinates, group-delayed spawns use current-screen coords, and wait/group/blockade execute in StageInstruction order; conditional branch remains partial."},
 {"Stages","Vertical/alternate scroll directions","YELLOW","Direction metadata is preserved, but runtime camera/gameplay is primarily horizontal."},
 {"Stages","Multiple stages/sets campaign flow","GREEN","Automatic stage completion, loading, sequential/next transitions and portable checkpoints are generated; complex conditional set branching remains partial."},
 {"Combat","Basic attacks/damage/knockdown/juggle/grab/throw","GREEN","Core beat-em-up combat works in the generated runtime."},
 {"Combat","OpenBOR AI movement/attack flags","YELLOW","aggression, common aimove modes, aiattack NOATTACK/LONG/MELEE/ALWAYS/DODGE/DODGEMOVE and basic hole avoidance now influence native enemies. Exact historical thinker timing remains partial."},
 {"Combat","Block/guard/counter/chains/cancel/special systems","YELLOW","Native blocking consumes guard data; atchain/combodelay, follow conditions, counter windows and common cancel inputs execute natively. Dynamic combostyle=1 zero-separated branches execute natively; full historical command buffering and some onblock variants remain partial."},
 {"Combat","attack4+ combo discovery","GREEN","Player and local coop combo chains automatically discover attack4+ animations instead of stopping at attack3."},
 {"Entities","Items/weapons/projectiles/obstacles","YELLOW","Projectile gravity/bounce and faction masks run natively; weapon-model overlays, indexed weapon swaps, limited ammo/reload and basic spawnframe/summonframe children execute. Exact weapon loss/drop/model-copy and advanced child bind/follow behavior remain partial."},
 {"Audio","Legacy .bor ADPCM","GREEN","Compressed .bor data is decoded before playback instead of being misread as PCM."},
 {"Audio","PCM WAV","GREEN","PCM 8/16/24/32-bit and IEEE float32 WAV decoding is supported; loop metadata remains available to the runtime."},
 {"Audio","OGG/MP3/FLAC","YELLOW","Windows runtime decodes MP3/FLAC with Media Foundation and attempts OGG when a system codec is present; codec availability can vary."},
 {"Audio","Numeric sample IDs / full sound bank","YELLOW","Script loadsample/playsample/unloadsample and overlapping file-based effects work; exact OpenBOR channel IDs and full sample-table semantics remain partial."},
 {"Input","Keyboard player 1","GREEN","Movement, attack, jump, run, dash, grab/throw and pickup are mapped."},
 {"Input","XInput gamepad","GREEN","XInput analog/D-pad/buttons are supported with remappable action buttons and a configurable controller slot for each local player."},
 {"Input","2-4 player local multiplayer","GREEN","Generated runtime simulates up to four local players with independent movement, animation, HP, attack/jump state, enemy targeting, damage and HUD bars. Advanced per-player weapon/grab edge cases remain partial."},
 {"Scripting","OpenBOR C/script hooks","YELLOW","Compatibility VM supports user functions, parameters/returns, control flow, arrays, macros/includes, stable entity handles, modern entity/model/level property access, global update/updated scripts, ondoattack and a stateful performattack(), native subscreens, legacy drawmethod state and a shared Z/sortid scene queue with native actors/layers/HUD. Advanced named drawmethod properties remain partial."},
 {"System","Title/select/cutscene frontend flow","GREEN","Authored logo/intro/title/titleb/howto/gameover/hiscore/loading/complete assets and ordered campaign scene/select entries are routed through the native frontend/cutscene flow when present."},
 {"System","Custom bitmap fonts / exact legacy menu layout","GREEN","Original OpenBOR font.gif/font2... sheets are decoded into clipped variable-width glyph sprites; menu font 0/1/2 roles and fontmonospace are preserved, with DirectWrite only as Unicode/missing-font fallback."}
};
void render(std::ostream& o){
 o << "OpenBOR Native Builder 0.34.47 - Parity Audit\n\n";
 o << "Status: GREEN = native behavior implemented; YELLOW = known but partial; RED = major compatibility layer still required.\n\n";
 std::string last;
 for(const auto& i:items){ if(last!=i.category){ last=i.category; o << "## "<<i.category<<"\n\n"; } o << "- ["<<i.status<<"] "<<i.feature<<" - "<<i.detail<<"\n"; }
 o << "\n## Highest priority remaining\n\n"
      "1. Unify native gameplay/background/interface rendering with the ScriptVM sprite queue, then expand advanced drawmethod properties (clip/channel/center/repeat/water) and specialized model/level/entity helpers. Subscreens, legacy setdrawmethod/changedrawmethod and file-stream APIs are now native.\n"
      "2. Complete remaining StageInstruction conditional-control and alternate-scroll edge cases; level-set boundaries, end markers, nojoin/canjoin and ifcomplete unlock gating are now native.\n"
      "3. Rendering parity: exact indexed-palette remap/LUT edge cases, multilayer/parallax and historical shadow/lighting semantics; the Direct3D 11 post-process backend is now implemented.\n"
      "4. Hall-of-Fame name entry, remaining credits/results edge cases and version-specific legacy UI details; the core title/titleb menu layout, bitmap-font metrics and authored title/select/cutscene flow are now native.\n"
      "5. Refine advanced multiplayer edge cases: grab/throw ownership and OpenBOR-specific join/continue rules.\n"
      "6. Finish dynamic combostyle=1, exact command buffering, weapon loss/model-copy and advanced child bind/follow/unsummon semantics.\n"
      "7. Complete OpenBOR sample-bank semantics and provide an embedded OGG fallback when Windows lacks a codec.\n";
}
}
void ParityAudit::print(std::ostream& out){ render(out); }
void ParityAudit::writeMarkdown(const std::filesystem::path& path){ std::ofstream f(path); if(f) render(f); }
