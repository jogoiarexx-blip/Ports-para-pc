# Validação v0.34.41

- Builder Release compile: PASS.
- CTest regression: 100% / 0 failures.
- JLU v3.0 original PAK analyze: 447 models, 118 stages, 3,835 animations, 25 scripts; 92,928 supported, 1 partial, 0 unsupported, 0 unknown.
- Remaining original partial is source-authored: Vixen `@cmd position` provides 4 args while helper requires 5.
- AI-Repair inferred the missing final value `0` from 6 unanimous valid sibling calls and emitted a separate auditable patch.
- JLU repaired copy analyze: 92,929 supported, 0 partial, 0 unsupported, 0 unknown.
- Generated JLU runtime host compile: PASS.
- JLU smoke gameplay: 600 frames PASS (`RC=0`) with stage spawns, projectile hit, damage, child spawn and PCM effects.
