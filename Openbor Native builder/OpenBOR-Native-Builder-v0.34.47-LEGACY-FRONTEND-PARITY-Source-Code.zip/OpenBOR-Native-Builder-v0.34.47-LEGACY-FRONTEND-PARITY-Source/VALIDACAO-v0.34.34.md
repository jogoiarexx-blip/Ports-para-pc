# Validacao — OpenBOR Native Builder v0.34.34

## Cobertura da rodada

A fixture `runtime_legacy_unknowns` exercita `parrow`, `parrow2`, `mprate`, `typemp`, `idle`, `fshadow`, `dive`, `freeze` e `allowselect`.

A validacao exige:

- parser transportar os argumentos;
- CommandRegistry e CompatibilityAnalyzer marcarem apenas as formas implementadas como SUPPORTED;
- runtime filtrar `allowselect`;
- `makeinv` abrir a janela usada por `parrow`;
- `freeze` causar dano, congelar pelo tempo autorado e aplicar/restaurar mapa;
- `typemp 1` recuperar `mprate` ao acertar;
- `dive` mover o ator.

## Resultado esperado

- CTest: 1/1 PASS.
- Runtime: 11/11 PASS.
