#include "PathEncoding.hpp"
#include "ScriptVM.hpp"
#include "AudioDecoder.hpp"
#include <fstream>
#include <iostream>
#include <stdexcept>
void check(bool ok,const char* msg){if(!ok)throw std::runtime_error(msg);std::cout<<"PASS: "<<msg<<"\n";}
int main(){try{
 namespace fs=std::filesystem;
 check(PathEncoding::validUtf8("\xf0\x9f\x8e\xae"),"supplementary Unicode accepted");
 check(!PathEncoding::validUtf8("\xc0\xaf"),"overlong UTF-8 rejected");
 check(!PathEncoding::validUtf8("\xed\xa0\x80"),"UTF-8 surrogate rejected");
 check(!PathEncoding::validUtf8("\xf4\x90\x80\x80"),"above Unicode maximum rejected");
 check(!PathEncoding::validUtf8("\xe2\x82"),"truncated UTF-8 rejected");
 check(PathEncoding::text("\x80\x93\x94")=="\xe2\x82\xac\xe2\x80\x9c\xe2\x80\x9d","Windows-1252 euro and quotes decoded");
 std::string name="a\xc3\xa7\xc3\xa3o";
 check(PathEncoding::utf8(PathEncoding::path(name))==name,"Unicode path round-trip");
 check(PathEncoding::text("a\xe7\xe3o")==name,"legacy accents decoded");
 auto root=fs::temp_directory_path()/PathEncoding::path("obor-unicode-a\xc3\xa7\xc3\xa3o-\xe6\xb8\xb8\xe6\x88\x8f-\xf0\x9f\x8e\xae");
 fs::remove_all(root);fs::create_directories(root/"scripts");
 std::string helper="scripts/"+name+".c";
 std::ofstream(root/PathEncoding::path(helper))<<"void mark(){setlocalvar(\"value\",34);}\nvoid main(){mark();}\n";
 std::ofstream(root/"scripts"/"utf8.c")<<"#include \"data/"<<helper<<"\"\nvoid main(){mark();}\n";
 std::ofstream(root/"scripts"/"legacy.c")<<"#include \"data/scripts/a\xe7\xe3o.c\"\nvoid main(){mark();}\n";
 ScriptVM vm;vm.setRoot(root);ScriptContext ctx;
 for(const auto& path:std::vector<std::string>{helper,"scripts/a\xe7\xe3o.c","scripts/utf8.c","scripts/legacy.c"}){
  ctx.local.clear();auto result=vm.runFile(path,ctx);check(result.ok&&result.unsupported.empty()&&std::get<double>(ctx.local.at("value"))==34,"script and include with Unicode/legacy reference executed");
 }
 check(!vm.runFile("../escape.c",ctx).ok,"runtime traversal still rejected");
 auto audio=root/PathEncoding::path(name+".wav");
 {std::ofstream f(audio,std::ios::binary);auto u16=[&](unsigned n){f.put(static_cast<char>(n));f.put(static_cast<char>(n>>8));};auto u32=[&](unsigned n){u16(n&65535);u16(n>>16);};
  f.write("RIFF",4);u32(38);f.write("WAVEfmt ",8);u32(16);u16(1);u16(1);u32(22050);u32(44100);u16(2);u16(16);f.write("data",4);u32(2);u16(42);
 }
 DecodedAudio decoded;std::string error;check(AudioDecoder::decodeFile(audio,decoded,error),"audio opened under Unicode path");check(decoded.sampleRate==22050&&decoded.pcm.size()==1&&decoded.pcm[0]==42,"audio sample preserved");
 fs::remove_all(root);std::cout<<"RUNTIME UNICODE PASS\n";return 0;
}catch(const std::exception& e){std::cerr<<"FAIL: "<<e.what()<<"\n";return 1;}}
