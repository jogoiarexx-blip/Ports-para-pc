#include "Engine.hpp"
#include <fstream>
#include <iostream>
#include <stdexcept>

struct RuntimeCompatibilityTest {
  static void check(bool ok,const char* label){if(!ok)throw std::runtime_error(label);std::cout<<"PASS: "<<label<<"\n";}
  static double global(const Engine& e,const char* key){auto i=e.scriptVm_.globals().find(key);if(i==e.scriptVm_.globals().end())return 0;if(auto n=std::get_if<double>(&i->second))return *n;if(auto b=std::get_if<bool>(&i->second))return *b?1:0;return 0;}
  static void run(const std::filesystem::path& root){
    Engine e;check(e.initialize(root),"contacts fixture initializes");e.config_.autoPreviewMusic=false;e.config_.knockback=0;
    auto hero=*e.findCharacter("Hero"),enemy=*e.findCharacter("Enemy");
    auto idle=*e.findAnimation(&hero,"idle");
    auto hit=*e.findAnimation(&hero,"attack1");auto frame=hit.frames[0];
    frame.attack.type=1;frame.attack.damage=10;frame.delay=4;frame.knockdown=false;frame.hitFlash="";
    generated::Frame blastFrames[2]={frame,frame};
    generated::Animation bombAnims[3]={idle,hit,hit};
    bombAnims[1].name="attack1";bombAnims[2].name="attack2";
    for(int i=1;i<3;++i){bombAnims[i].frames=blastFrames;bombAnims[i].frameCount=2;bombAnims[i].loop=false;}
    auto bomb=hero;bomb.name="TestBomb";bomb.type="projectile";bomb.animations=bombAnims;bomb.animationCount=3;
    bomb.removeConfig=1;bomb.subjectToGravity=true;bomb.projectileHitMask=1<<3;
    auto victim=[&](float x){RuntimeEntity t;t.model=&enemy;t.animation.setAnimation(e.findAnimation(&enemy,"idle"));t.worldX=x;t.z=180;t.health=t.maxHealth=100;t.facing=1;return t;};
    auto reset=[&](){e.projectiles_.clear();e.entities_.clear();e.coopPlayers_.clear();e.pendingChildSpawns_.clear();e.playerAttackTicks_=0;e.playerWorldX_=10;e.playerZ_=180;e.playerAlive_=true;};
    reset();e.entities_.push_back(victim(100));e.spawnProjectile(&bomb,100,180,-1,1,2,0,0,true,true);
    e.resolveCombat();auto& p=e.projectiles_[0];
    check(p.alive&&p.exploded&&std::string(p.animation.animation()->name)=="attack2","bomb impact selects attack2 instead of disappearing");
    check(p.vx==0&&p.vy==0&&p.vz==0&&!p.subjectToGravity&&p.altitude==-1,"contact detonation stops motion at contact altitude");
    check(p.life==9,"explosion lifetime follows both frame delays");
    int impactHp=e.entities_[0].health;e.resolveCombat();int blastHp=e.entities_[0].health;
    check(impactHp==99&&blastHp==89,"impact and explosion use separate contact and blast damage");
    e.resolveCombat();check(e.entities_[0].health==blastHp,"persistent explosion does not damage same target every tick");
    e.entities_.push_back(victim(105));e.resolveCombat();check(e.entities_[1].health==90,"explosion can damage another target once");
    for(int i=0;i<8;++i)e.updateProjectiles();check(e.projectiles_.size()==1,"explosion remains through final frame delay");
    e.updateProjectiles();check(e.projectiles_.empty(),"explosion is removed after animation duration");
    reset();e.spawnProjectile(&bomb,100,180,-0.1f,1,0,-1,0,true,true);e.updateProjectiles();
    check(e.projectiles_.size()==1&&std::string(e.projectiles_[0].animation.animation()->name)=="attack1","ground detonation selects attack1");
    auto missing=bomb;missing.animationCount=1;
    RuntimeProjectile q;q.model=&missing;q.bomb=true;q.alive=true;
    check(!e.detonateProjectile(q,true)&&!q.alive,"contact without attack2 honors remove one");
    missing.removeConfig=0;q.alive=true;
    check(!e.detonateProjectile(q,true)&&q.alive,"contact without attack2 honors remove zero");
    reset();auto piercing=bomb;piercing.subjectToGravity=false;piercing.removeConfig=0;
    e.entities_.push_back(victim(100));e.entities_.push_back(victim(105));
    e.spawnProjectile(&piercing,100,180,0,1,0,0,0,false,true);e.projectiles_[0].animation.setAnimation(&bombAnims[1]);
    e.resolveCombat();check(e.projectiles_[0].alive&&e.entities_[0].health==90&&e.entities_[1].health==90,"remove zero permits piercing multiple targets");
    e.resolveCombat();check(e.entities_[0].health==90&&e.entities_[1].health==90,"piercing projectile prevents repeated damage while overlapping");
    reset();piercing.removeConfig=1;e.entities_.push_back(victim(100));e.entities_.push_back(victim(105));
    e.spawnProjectile(&piercing,100,180,0,1,0,0,0,false,true);e.projectiles_[0].animation.setAnimation(&bombAnims[1]);
    e.resolveCombat();check(!e.projectiles_[0].alive&&e.entities_[0].health==90&&e.entities_[1].health==100,"remove one stops projectile after first contact");
    reset();auto owner=hero;owner.canDamageMask=(1<<3);auto neutral=piercing;neutral.type="none";neutral.canDamageMask=0;neutral.projectileHitMask=0;neutral.removeConfig=0;
    e.entities_.push_back(victim(100));e.spawnProjectile(&neutral,100,180,0,1,0,0,0,false,false,&owner);e.projectiles_[0].animation.setAnimation(&bombAnims[1]);
    e.resolveCombat();check(e.entities_[0].health==90,"type-none projectile inherits owner candamage faction mask");
    reset();e.spawnProjectile(&bomb,100,180,0,1,0,0,0,true,true);e.detonateProjectile(e.projectiles_[0],true);
    auto empty=frame;empty.hasAttack=false;auto noAttack=bombAnims[2];noAttack.frames=&empty;noAttack.frameCount=1;e.projectiles_[0].animation.setAnimation(&noAttack);
    e.entities_.push_back(victim(100));e.resolveCombat();check(e.entities_[0].health==100,"explosion without attack box does not invent bbox damage");

    // Only the player owns a collision hook. The enemy's lack of hook must not suppress it.
    std::filesystem::create_directories(root/"assets/openbor-data/scripts");
    std::ofstream(root/"assets/openbor-data/scripts/contact.c")<<"void main(){setglobalvar(\"contactCount\",getglobalvar(\"contactCount\")+1);setglobalvar(\"contactValid\",getentityproperty(getlocalvar(\"target\"),\"exists\"));}";
    auto scripted=hero;scripted.onEntityCollisionScript="data/scripts/contact.c";
    reset();e.playerModel_=&scripted;e.player_.setAnimation(&idle);e.playerWorldX_=100;e.entities_.push_back(victim(100));
    e.resolveCombat();check(global(e,"contactCount")==1&&global(e,"contactValid")==1,"unilateral player collision hook receives target handle");
    check(!e.playerScriptCtx_.local.contains("target")&&!e.playerScriptCtx_.local.contains("other")&&!e.playerScriptCtx_.other,"collision target locals do not leak into next hook");
    e.playerAlive_=false;e.resolveCombat();check(global(e,"contactCount")==1,"dead player does not fire collision hooks");
    RuntimeCoopPlayer cp;cp.model=&scripted;cp.animation.setAnimation(&idle);cp.worldX=100;cp.z=180;cp.facing=1;e.coopPlayers_.push_back(cp);
    e.resolveCombat();check(global(e,"contactCount")==2,"cooperative player receives unilateral collision hook");
    e.entities_[0].visible=false;e.resolveCombat();check(global(e,"contactCount")==2,"invisible removed entity does not emit collision");
  }
};
int main(int argc,char** argv){try{if(argc!=2)return 2;RuntimeCompatibilityTest::run(argv[1]);std::cout<<"RUNTIME CONTACTS PASS\n";return 0;}catch(const std::exception& e){std::cerr<<"FAIL: "<<e.what()<<"\n";return 1;}}
