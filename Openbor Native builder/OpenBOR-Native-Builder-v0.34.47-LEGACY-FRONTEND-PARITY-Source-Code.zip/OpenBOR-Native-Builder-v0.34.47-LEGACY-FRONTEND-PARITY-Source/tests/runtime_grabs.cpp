#include "Engine.hpp"
#include <iostream>
#include <stdexcept>
struct RuntimeCompatibilityTest {
 static void check(bool v,const char*s){if(!v)throw std::runtime_error(s);std::cout<<"PASS: "<<s<<"\n";}
 static void run(const std::filesystem::path&root){
  Engine e;check(e.initialize(root),"grab fixture initializes");e.config_.autoPreviewMusic=false;
  auto originalHero=e.findCharacter("Hero"),originalEnemy=e.findCharacter("Enemy");generated::Character hero=*originalHero,enemy=*originalEnemy;
  auto reset=[&](int force,int resistance){hero=*originalHero;enemy=*originalEnemy;hero.grabForce=force;enemy.grabResistance=resistance;enemy.noGrab=false;e.playerModel_=&hero;e.playerAlive_=true;e.playerAttackTicks_=0;e.playerAltitude_=0;e.playerWorldX_=100;e.playerZ_=180;e.player_.setAnimation(e.findAnimation(originalHero,"idle"));e.grabbedEntity_=-1;e.entities_.clear();RuntimeEntity victim;victim.model=&enemy;victim.health=victim.maxHealth=100;victim.worldX=115;victim.z=180;victim.animation.setAnimation(e.findAnimation(originalEnemy,"idle"));e.entities_.push_back(victim);};
  reset(0,0);e.tryGrabNearest();check(e.grabbedEntity_==0&&e.entities_[0].grabbed,"zero force equals zero resistance and permits grab");
  reset(1,1);e.tryGrabNearest();check(e.grabbedEntity_==0,"equal positive force and resistance permits grab");
  reset(0,1);e.tryGrabNearest();check(e.grabbedEntity_==-1,"cantgrab-style resistance prevents ordinary force");
  reset(2,1);e.tryGrabNearest();check(e.grabbedEntity_==0,"stronger force can grab cantgrab 1 target");
  reset(-999999,0);e.tryGrabNearest();check(e.grabbedEntity_==-1,"cantgrab 2 force prevents ordinary actor grab");
  reset(-2,-1);e.tryGrabNearest();check(e.grabbedEntity_==-1,"negative force weaker than negative resistance is rejected");
  reset(-1,-1);e.tryGrabNearest();check(e.grabbedEntity_==0,"equal negative force and resistance retains source comparison");
  reset(100,0);enemy.noGrab=true;e.tryGrabNearest();check(e.grabbedEntity_==-1,"separate nograb restriction still prevents grab");
  reset(1,0);e.entities_[0].altitude=-0.1f;e.tryGrabNearest();check(e.grabbedEntity_==-1,"airborne target at OpenBOR threshold is rejected");
  reset(1,0);e.entities_[0].altitude=-0.05f;e.tryGrabNearest();check(e.grabbedEntity_==0,"target below airborne threshold remains eligible");
  reset(1,0);e.playerAltitude_=-2.01f;e.tryGrabNearest();check(e.grabbedEntity_==-1,"acting player outside walkoff height range cannot grab");
  reset(1,0);e.playerAltitude_=-2;e.tryGrabNearest();check(e.grabbedEntity_==0,"walkoff height boundary remains inclusive");
  reset(1,0);generated::Animation moving=*e.player_.animation();generated::Frame movingFrame=*e.player_.frame();movingFrame.moveX=1;moving.frames=&movingFrame;moving.frameCount=1;e.player_.setAnimation(&moving);e.tryGrabNearest();check(e.grabbedEntity_==-1,"animation planar movement prevents grab");
  reset(1,0);e.playerScriptVelocityX_=1;e.tryGrabNearest();check(e.grabbedEntity_==0,"script velocity is not confused with animation move metadata");
  reset(1,0);e.playerAttackTicks_=3;e.tryGrabNearest();check(e.grabbedEntity_==-1,"active attack still rejects new grab");
  reset(1,0);e.entities_[0].worldX=500;e.tryGrabNearest();check(e.grabbedEntity_==-1,"target outside grab range is rejected");
  reset(-999999,1);std::vector<std::string> u;auto property=[&](std::uintptr_t h,const char*k){return std::get<double>(e.callScriptFunction("getentityproperty",{h,std::string(k)},e.playerScriptCtx_,u));};
  check(property(1,"grabforce")==-999999,"entity property exposes actor legacy grab force to helpers");
  check(property((std::uintptr_t)&e.entities_[0],"grabresistance")==1,"entity property exposes defender resistance to helpers");
  RuntimeCoopPlayer cp;cp.model=&hero;cp.alive=true;e.coopPlayers_.push_back(cp);check(property(2,"grabforce")==-999999,"cooperative property exposes the same model grab force");
  check(u.empty(),"grab property reads introduce no unmapped APIs");
 }
};
int main(int argc,char**argv){try{if(argc!=2)return 2;RuntimeCompatibilityTest::run(argv[1]);std::cout<<"RUNTIME GRABS PASS\n";return 0;}catch(const std::exception&e){std::cerr<<"FAIL: "<<e.what()<<"\n";return 1;}}
