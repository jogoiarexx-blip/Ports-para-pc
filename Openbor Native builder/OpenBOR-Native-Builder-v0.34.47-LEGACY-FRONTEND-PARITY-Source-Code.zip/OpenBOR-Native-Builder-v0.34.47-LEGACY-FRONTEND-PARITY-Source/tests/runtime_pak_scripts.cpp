#include "ScriptVM.hpp"
#include <iostream>
#include <set>
#include <stdexcept>
struct SoundProbe:ScriptHost {
 std::set<std::string> seen;
 int played=0;bool valid=true;
 ScriptValue callScriptFunction(const std::string& name,const std::vector<ScriptValue>& a,ScriptContext&,std::vector<std::string>& unsupported)override{
  if(name=="loadsample"){seen.insert(std::get<std::string>(a.at(0)));return 3.0;}
  if(name=="openborvariant"&&std::get<std::string>(a.at(0))=="effectvol")return 100.0;
  if(name=="playsample"){++played;valid=valid&&std::get<double>(a.at(0))==3&&std::get<double>(a.at(2))==100&&std::get<double>(a.at(3))==100&&std::get<double>(a.at(4))==100;return 1.0;}
  unsupported.push_back(name);return {};
 }
};
void check(bool v,const char*msg){if(!v)throw std::runtime_error(msg);std::cout<<"PASS: "<<msg<<"\n";}
int main(int argc,char**argv){try{
 if(argc!=2)return 2;ScriptVM vm;vm.setRoot(std::filesystem::path(argv[1])/"assets/openbor-data");SoundProbe host;vm.setHost(&host);ScriptContext ctx;
 for(int i=0;i<600;++i){auto r=vm.runAnimationCommand("data/scripts/randsound.c","randSound2(\"wantsome.wav\",\"shebitch.wav\",\"letsgo.wav\",\"gotya.wav\",\"getsome.wav\",\"sucker.wav\");",ctx);if(!r.ok||!r.unsupported.empty())throw std::runtime_error(r.error+" unmapped sound API");}
 check(host.played==600,"actual Evil Dead helper dispatches one sample per command");
 check(host.valid,"actual helper forwards sample id volume and speed to sound host");
 const std::set<std::string> expected={"data/sounds/wantsome.wav","data/sounds/shebitch.wav","data/sounds/letsgo.wav","data/sounds/gotya.wav","data/sounds/getsome.wav","data/sounds/sucker.wav"};
 check(host.seen==expected,"signed rand and signed remainder reach all six actual helper choices");
 std::cout<<"PAK SCRIPT PASS\n";return 0;
 }catch(const std::exception&e){std::cerr<<"FAIL: "<<e.what()<<"\n";return 1;}}
