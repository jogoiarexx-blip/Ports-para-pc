#include "Engine.hpp"
#include <iostream>
#include <stdexcept>
struct RuntimeCompatibilityTest {
  static void check(bool ok,const char* message){if(!ok)throw std::runtime_error(message);std::cout<<"PASS: "<<message<<"\n";}
  static void run(const std::filesystem::path& root){
    Engine e;check(e.initialize(root),"effect runtime initializes");e.config_.autoPreviewMusic=false;e.tickCounter_=1;
    const auto* hero=e.findCharacter("Hero");const auto* enemy=e.findCharacter("Enemy");const auto* hitA=e.findCharacter("HitA");const auto* hitB=e.findCharacter("HitB");const auto* guard=e.findCharacter("GuardFx");
    const auto* attack=e.findAnimation(hero,"attack1");check(attack&&attack->frameCount==2&&attack->frames[0].attack.type==18,"generated tables preserve numbered attack type");
    Engine::RectF atk{100,180,24,24},body{100,180,24,24};
    auto queue=[&](const generated::Frame* frame,const generated::Character* target,bool blocked){e.queueAttackFlash(frame,target,blocked,atk,body,100,180,-1);};
    queue(&attack->frames[0],enemy,false);check(e.pendingChildSpawns_.size()==1&&e.pendingChildSpawns_[0].model==hitA,"first frame spawns its own hit effect");
    e.pendingChildSpawns_.clear();queue(&attack->frames[1],enemy,false);check(e.pendingChildSpawns_.size()==1&&e.pendingChildSpawns_[0].model==hitB,"second frame uses the updated effect");
    check(e.pendingChildSpawns_[0].worldX==112&&e.pendingChildSpawns_[0].altitude==12,"hit effect uses the overlap center before knockback");check(e.pendingChildSpawns_[0].facing==1,"toflip selects facing from hit position");
    generated::Character protectedTarget=*enemy;protectedTarget.noAttackFlash=true;
    e.pendingChildSpawns_.clear();queue(&attack->frames[1],&protectedTarget,false);check(e.pendingChildSpawns_[0].model==hitA&&e.pendingChildSpawns_[0].facing==-1,"noatflash uses defender fallback and default effect facing");
    generated::Frame disabled=attack->frames[1];disabled.attack.noFlash=1;e.pendingChildSpawns_.clear();queue(&disabled,enemy,false);check(e.pendingChildSpawns_.empty(),"noflash suppresses all hit effects");
    generated::Frame unknown=attack->frames[1];unknown.hitFlash="Missing";queue(&unknown,enemy,false);check(e.pendingChildSpawns_.size()==1&&e.pendingChildSpawns_[0].model==hitA,"missing custom model falls back to defender flash");
    e.pendingChildSpawns_.clear();queue(&attack->frames[0],enemy,true);check(e.pendingChildSpawns_[0].model==guard,"blocked hit selects defender block effect");
    generated::Frame customBlock=attack->frames[0];customBlock.blockFlash="HitB";e.pendingChildSpawns_.clear();queue(&customBlock,enemy,true);check(e.pendingChildSpawns_[0].model==hitB,"frame blockflash overrides model bflash");
    e.pendingChildSpawns_.clear();queue(&customBlock,&protectedTarget,true);check(e.pendingChildSpawns_[0].model==guard,"noatflash also suppresses incoming block overrides");
    generated::Character noEffect=*enemy;noEffect.flashModel="none";unknown.hitFlash="none";e.pendingChildSpawns_.clear();queue(&unknown,&noEffect,false);check(e.pendingChildSpawns_.empty(),"none plus no fallback spawns no effect");
    e.queueAttackFlash(&attack->frames[0],enemy,false,atk,Engine::RectF{300,180,24,24},300,180,1);check(e.pendingChildSpawns_.empty(),"non-overlapping boxes produce no flash");
    queue(&attack->frames[1],enemy,false);e.entities_.clear();e.flushChildSpawns();check(e.entities_.size()==1&&e.entities_[0].animationEffect,"flash enters the animated effect lifecycle");check(std::get<double>(e.entities_[0].scriptCtx.local["spawn_type"])==9,"flash exposes OpenBOR spawn type nine");
    for(int i=0;i<7;++i)e.updateEntities();check(!e.entities_[0].alive&&!e.entities_[0].visible,"flash disappears after the final animation delay");
    e.entities_.clear();e.pendingChildSpawns_.clear();e.playerWorldX_=100;e.playerZ_=180;e.playerFacing_=1;e.playerAltitude_=0;e.playerAlive_=true;e.playerAttackCooldown_=0;e.startPlayerAttack();
    RuntimeEntity target;target.model=enemy;target.animation.setAnimation(e.findAnimation(enemy,"idle"));target.health=target.maxHealth=100;target.worldX=100;target.z=180;target.facing=1;e.entities_.push_back(target);
    e.resolveCombat();check(e.entities_[0].health==95,"attack18 applies its type-specific defense in real combat");check(e.pendingChildSpawns_.size()==1&&e.pendingChildSpawns_[0].model==hitA,"real player collision queues the frame hit effect");
    e.resolveCombat();check(e.entities_[0].health==95&&e.pendingChildSpawns_.size()==1,"same attack does not repeatedly damage or spawn effects");
    e.entities_[0].lastPlayerAttackId=0;e.entities_[0].worldX=100;e.entities_[0].model=&protectedTarget;e.player_.setFrame(1);e.resolveCombat();check(e.pendingChildSpawns_.size()==2&&e.pendingChildSpawns_.back().model==hitA,"real combat respects defender override suppression");
    e.entities_.clear();e.pendingChildSpawns_.clear();e.playerAttackTicks_=0;e.entities_.push_back(target);RuntimeProjectile p;p.model=hero;p.animation.setAnimation(attack);p.worldX=100;p.z=180;p.fromPlayer=true;p.facing=1;e.projectiles_.push_back(p);e.resolveCombat();check(!e.projectiles_[0].alive&&e.pendingChildSpawns_.size()==1&&e.pendingChildSpawns_[0].model==hitA,"projectile collision spawns its configured hit effect");
    e.projectiles_.clear();e.entities_.clear();e.pendingChildSpawns_.clear();e.playerAlive_=false;RuntimeCoopPlayer cp;cp.model=hero;cp.animation.setAnimation(attack);cp.worldX=100;cp.z=180;cp.facing=1;cp.attackTicks=40;cp.attackId=1;e.coopPlayers_.push_back(cp);e.entities_.push_back(target);e.resolveCombat();
    check(e.entities_[0].health==95&&e.pendingChildSpawns_.size()==1&&e.pendingChildSpawns_[0].model==hitA,"cooperative player collision uses typed damage and frame effect");
    e.coopPlayers_.clear();e.entities_.clear();e.pendingChildSpawns_.clear();e.playerAlive_=true;e.playerAttackTicks_=0;e.playerAttackCooldown_=0;e.playerComboStep_=0;e.playerComboWindow_=0;e.startPlayerAttack();target.blockState=1|16|32;e.entities_.push_back(target);e.resolveCombat();
    check(e.entities_[0].health==100&&e.entities_[0].blocking&&e.pendingChildSpawns_.size()==1&&e.pendingChildSpawns_[0].model==guard,"actual blocked collision preserves health and spawns bflash");
    e.entities_.clear();e.pendingChildSpawns_.clear();target.blockState=0;e.entities_.push_back(target);generated::Frame zeroFrame=attack->frames[0];zeroFrame.attack.damage=0;generated::Animation zeroAttack=*attack;zeroAttack.frames=&zeroFrame;zeroAttack.frameCount=1;e.player_.setAnimation(&zeroAttack);e.playerAttackTicks_=20;++e.playerAttackId_;e.playerAttackContactFrame_=(std::size_t)-1;e.playerAttackFrameHitTargets_.clear();e.playerAttackOneTarget_=0;e.resolveCombat();
    check(e.entities_[0].health==100&&e.pendingChildSpawns_.size()==1&&e.pendingChildSpawns_[0].model==hitA,"zero-damage attack remains a valid contact and flash without HP loss");
  }
};
int main(int argc,char** argv){try{if(argc!=2)return 2;RuntimeCompatibilityTest::run(argv[1]);std::cout<<"RUNTIME EFFECTS PASS\n";return 0;}catch(const std::exception& error){std::cerr<<"FAIL: "<<error.what()<<"\n";return 1;}}
