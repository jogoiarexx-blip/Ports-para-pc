#include "LevelParser.hpp"
#include "CharacterParser.hpp"
#include "CompatibilityAnalyzer.hpp"
#include "ProjectScanner.hpp"
#include "CommandRegistry.hpp"
#include "PortGenerator.hpp"
#include "RepairPackage.hpp"
#include "SafePath.hpp"
#include "InputResolver.hpp"
#include <filesystem>
#include <algorithm>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>
#include <cstdint>
#include <cmath>
#include <cstdlib>

static int gFails = 0;
#define CHECK(cond, msg) do { if(!(cond)){ std::cerr << "FAIL: " << msg << "\n"; ++gFails; } else { std::cout << "PASS: " << msg << "\n"; } } while(0)

static void writeU32(std::ofstream& f, std::uint32_t v){ char b[4]={(char)(v&255),(char)((v>>8)&255),(char)((v>>16)&255),(char)((v>>24)&255)}; f.write(b,4); }
static bool createTestPak(const std::filesystem::path& out){
    struct Entry{std::string name,data;std::uint32_t off=0;};
    std::vector<Entry> e={
      {"data/models.txt","know Hero\nload Hero data/chars/hero.txt\n"},
      {"data/levels.txt","set Test\nfile data/levels/stage.txt\n"},
      {"data/chars/hero.txt","name Hero\ntype player\nanim idle\ndelay 8\nframe none\n"},
      {"data/levels/stage.txt","direction right\nspawn Hero\ncoords 10 200 0\nat 0\n"}
    };
    std::ofstream f(out,std::ios::binary|std::ios::trunc);if(!f)return false;f.write("PACK",4);writeU32(f,0);
    for(auto& x:e){x.off=(std::uint32_t)f.tellp();f.write(x.data.data(),(std::streamsize)x.data.size());}
    auto index=(std::uint32_t)f.tellp();for(const auto& x:e){writeU32(f,(std::uint32_t)(12+x.name.size()+1));writeU32(f,x.off);writeU32(f,(std::uint32_t)x.data.size());f.write(x.name.c_str(),(std::streamsize)x.name.size()+1);}
    writeU32(f,index);return (bool)f;
}

int main(){
    namespace fs = std::filesystem;
#ifdef OBNB_SOURCE_DIR
    fs::path sourceDir = OBNB_SOURCE_DIR;
#else
    fs::path sourceDir = fs::current_path();
#endif
    fs::path fixtureA = sourceDir / "tests/fixtures/side_scroll";
    fs::path fixtureB = sourceDir / "tests/fixtures/wide_res";


    auto scanA = ProjectScanner::scan(fixtureA);
    CHECK(scanA.hasDataDir, "fixture A has data/");
    CHECK(scanA.hasModels && scanA.hasLevels && scanA.hasVideo, "fixture A detects models/levels/video");
    auto compA = CompatibilityAnalyzer::analyze(scanA);
    CHECK(compA.logicalWidth==320 && compA.logicalHeight==240, "fixture A resolution 320x240 from video.txt");
    CHECK(compA.models==3, "fixture A models == 3");
    CHECK(compA.stages==2, "fixture A stages == 2");
    CHECK(compA.animations>=6, "fixture A animations parsed");
    CHECK(compA.scripts>=1, "fixture A script counted");
    CHECK(true, "unknown-command accounting checked on fixture B below");

    auto stages = LevelParser::parseAll(scanA.dataDir, scanA.root);
    CHECK(stages.size()==2, "parseAll returns both stages");
    CHECK(stages[0].direction=="right", "stage1 direction");
    CHECK(stages[1].cameraType==1, "stage2 fixed camera from cameratype");
    CHECK(stages[1].direction=="up", "vertical/up direction preserved");
    {
        fs::path sr="/tmp/obor-v03420-skipselect";fs::remove_all(sr);fs::create_directories(sr/"data/levels");
        std::ofstream(sr/"data/levels.txt") << "set Auto\nskipselect 1\nfile data/levels/a.txt\n";
        std::ofstream(sr/"data/levels/a.txt") << "direction right\n";
        auto ss=LevelParser::parseAll(sr/"data",sr);
        CHECK(ss.size()==1&&ss[0].skipSelect==1,"v0.34.22 levels.txt skipselect is propagated into stage metadata");
        CHECK(CommandRegistry::lookup("skipselect").status==CommandStatus::Supported,"v0.34.22 skipselect registry status is runtime-backed");
    }
    {
        fs::path sr="/tmp/obor-v03422-level-flow";fs::remove_all(sr);fs::create_directories(sr/"data/levels");
        std::ofstream(sr/"data/levels.txt") << "completebg 1\nset Story\nnoshare 1\nfile data/levels/a.txt\n";
        std::ofstream(sr/"data/levels/a.txt") << "direction right\nspawn Enemy\nmap1\ncoords 40 200 0\nat 0\n";
        auto ss=LevelParser::parseAll(sr/"data",sr);
        CHECK(ss.size()==1&&ss[0].completeBg==1&&ss[0].noShare==1,"v0.34.22 completebg/noshare propagate from levels.txt into stage metadata");
        CHECK(!ss.empty()&&!ss[0].spawns.empty()&&ss[0].spawns[0].map=="1","v0.34.22 bare map1 spawn shorthand normalizes to palette map 1");
        CHECK(CommandRegistry::lookup("map1").status==CommandStatus::Supported&&CommandRegistry::lookup("completebg").status==CommandStatus::Supported,"v0.34.22 mapN and completebg are runtime-backed");
        CHECK(CommandRegistry::lookup("noshare").status==CommandStatus::Supported&&CommandRegistry::lookup("nocheats").status==CommandStatus::IgnoredSafely&&CommandRegistry::lookup("nodebug").status==CommandStatus::IgnoredSafely,"v0.34.23 noshare has native per-player pools while policy commands remain explicit");
        fs::path stealthFile=sr/"data/stealth.txt";std::ofstream(stealthFile)<<"name Sneak\ntype enemy\nstealth 5 7\nanim idle\nframe none\n";
        auto sneak=CharacterParser::parse(stealthFile,sr/"data");
        CHECK(sneak.stealth==5&&sneak.perception==7,"v0.34.22 stealth/perception pair is parsed for native target filtering");
    }
    bool sawBgLayer=false,sawFgLayer=false;
    for(const auto& l:stages[0].layers){
        if(l.kind=="bglayer" && std::abs(l.xRatio-0.25f)<0.001f && l.xSpacing==4 && l.xRepeat==3) sawBgLayer=true;
        if(l.kind=="fglayer" && l.zOrder==25 && std::abs(l.xRatio-0.75f)<0.001f && l.xOffset==5) sawFgLayer=true;
    }
    CHECK(sawBgLayer, "bglayer floating ratio/spacing/repeat parsed with OpenBOR argument order");
    CHECK(sawFgLayer, "fglayer Z depth and floating ratio parsed with correct OpenBOR argument order");
    CHECK(stages[0].levelScript=="scripts/level1.c", "levelscript path preserved");
    CHECK(!stages[0].spawns.empty(), "stage1 has spawns");
    // Sorted by `at`, then declaration id. The 600 spawn must come before boss 700 and late thug 1400.
    CHECK(stages[0].spawns.front().at <= stages[0].spawns.back().at, "spawns sorted by at");
    bool sawBossBeforeLate = false;
    int prevAt = -1;
    for(const auto& s: stages[0].spawns){
        CHECK(s.at>=prevAt, "spawn order is stable and non-decreasing");
        prevAt = s.at;
        if(s.boss && s.at==700) sawBossBeforeLate = true;
        if(s.at==1400) CHECK(sawBossBeforeLate, "boss at 700 is ordered before thug at 1400 even if declared earlier");
        if(s.model=="Boss" && s.at==700) CHECK(s.boss, "boss flag sticks to the boss spawn");
        if(s.alias=="EarlyThug"){ CHECK(s.item=="knife", "item drop stays on the spawn"); CHECK(s.map=="2", "colormap preserved"); }
    }
    bool sawWait=false, sawBlock=false;
    for(const auto& ev: stages[0].events){
        if(ev.kind=="wait") sawWait=true;
        if(ev.kind=="blockade") sawBlock=true;
        CHECK(ev.state==SpawnState::NotTriggered, "events start NOT_TRIGGERED");
    }
    CHECK(sawWait && sawBlock, "wait and blockade captured as one-shot events");

    // Canonical OpenBOR event form: wait/group/blockade can bind to the immediately
    // following `at`, while blockade keeps its own backtracking floor value.
    fs::path eventRoot="/tmp/obor-v018-event-fixture";
    fs::remove_all(eventRoot); fs::create_directories(eventRoot/"data/levels");
    {
        std::ofstream f(eventRoot/"data/levels/events.txt");
        f << "wait\n";
        f << "at 100\n";
        f << "group 2 5\n";
        f << "at 200\n";
        f << "blockade 150\n";
        f << "at 250\n";
    }
    LevelSetDef eventSet; eventSet.name="Events";
    auto eventStage=LevelParser::parseStage(eventRoot/"data/levels/events.txt",eventRoot,eventSet);
    bool canonicalWait=false, canonicalGroup=false, canonicalBlockade=false;
    for(const auto& ev:eventStage.events){
        if(ev.kind=="wait" && ev.hasAt && ev.at==100) canonicalWait=true;
        if(ev.kind=="group" && ev.hasAt && ev.at==200 && ev.value==2 && ev.group==5) canonicalGroup=true;
        if(ev.kind=="blockade" && ev.hasAt && ev.at==250 && ev.value==150) canonicalBlockade=true;
    }
    CHECK(canonicalWait, "canonical wait + at binding");
    CHECK(canonicalGroup, "canonical group min/max + at binding");
    CHECK(canonicalBlockade, "canonical blockade floor + distinct at binding");

    // v0.34.28: a single OpenBOR AT entry can carry a spawn and multiple
    // level-control flags. The parser must not drop all but the last pending event.
    fs::path groupedEventRoot="/tmp/obor-v03428-grouped-event-fixture";
    fs::remove_all(groupedEventRoot); fs::create_directories(groupedEventRoot/"data/levels");
    {
        std::ofstream f(groupedEventRoot/"data/levels/mixed.txt");
        f << "spawn Enemy\n";
        f << "coords 40 200\n";
        f << "nojoin 1\n";
        f << "wait\n";
        f << "group 1 2\n";
        f << "blockade 30\n";
        f << "at 120\n";
        f << "canjoin\n";
        f << "at 180\n";
    }
    auto groupedStage=LevelParser::parseStage(groupedEventRoot/"data/levels/mixed.txt",groupedEventRoot,eventSet);
    CHECK(groupedStage.spawns.size()==1 && groupedStage.spawns[0].hasAt && groupedStage.spawns[0].at==120,"v0.34.28 mixed AT binds to the pending spawn");
    bool joinClosed=false,joinOpened=false,mixedWait=false,mixedGroup=false,mixedBlockade=false;
    for(const auto& ev:groupedStage.events){
        if(ev.kind=="nojoin"&&ev.hasAt&&ev.at==120&&ev.value==1)joinClosed=true;
        if(ev.kind=="wait"&&ev.hasAt&&ev.at==120)mixedWait=true;
        if(ev.kind=="group"&&ev.hasAt&&ev.at==120&&ev.value==1&&ev.group==2)mixedGroup=true;
        if(ev.kind=="blockade"&&ev.hasAt&&ev.at==120&&ev.value==30)mixedBlockade=true;
        if(ev.kind=="canjoin"&&ev.hasAt&&ev.at==180&&ev.value==0)joinOpened=true;
    }
    CHECK(joinClosed&&mixedWait&&mixedGroup&&mixedBlockade,"v0.34.28 one AT binds every pending stage-control flag");
    CHECK(joinOpened,"v0.34.28 later canjoin gets its own AT without overwriting the spawn AT");
    CHECK(groupedStage.instructions.size()==6,"v0.34.28 mixed spawn/control entry preserves every source instruction");

    // v0.20 campaign branching: OpenBOR branch labels live in levels.txt and label
    // the next `file` entry. Per-file z settings must also follow the order list.
    fs::path branchRoot="/tmp/obor-v020-branch-fixture";
    fs::remove_all(branchRoot); fs::create_directories(branchRoot/"data/levels");
    {
        std::ofstream f(branchRoot/"data/levels.txt");
        f << "set Route\n";
        f << "branch start\n";
        f << "z 100 180 90\n";
        f << "file data/levels/a.txt\n";
        f << "z 210 300 170\n";
        f << "branch alternate\n";
        f << "file data/levels/b.txt\n";
    }
    {std::ofstream(branchRoot/"data/levels/a.txt") << "direction right\n"; std::ofstream(branchRoot/"data/levels/b.txt") << "direction right\n";}
    auto branchStages=LevelParser::parseAll(branchRoot/"data",branchRoot);
    CHECK(branchStages.size()==2, "levels.txt branch fixture parses both stages");
    if(branchStages.size()==2){
        CHECK(branchStages[0].branchName=="start", "branch label attaches to first following file");
        CHECK(branchStages[1].branchName=="alternate", "second branch label attaches to its following file");
        CHECK(branchStages[0].zMin==100 && branchStages[0].zMax==180 && branchStages[0].backgroundHeight==90, "per-level z metadata preserved for first branch");
        CHECK(branchStages[1].zMin==210 && branchStages[1].zMax==300 && branchStages[1].backgroundHeight==170, "per-level z metadata preserved after z change");
    }
    // v0.34.29 level-set lifecycle: an `end` terminates normal sequential
    // progression but later files remain addressable branch destinations. `ifcomplete`
    // belongs to the set and must propagate to every generated stage in that set.
    fs::path campaignRoot="/tmp/obor-v03429-campaign-fixture";
    fs::remove_all(campaignRoot); fs::create_directories(campaignRoot/"data/levels");
    {
        std::ofstream f(campaignRoot/"data/levels.txt");
        f << "set Story\n";
        f << "file data/levels/story.txt\n";
        f << "end\n";
        f << "branch bonus\n";
        f << "file data/levels/bonus.txt\n";
        f << "set Locked\n";
        f << "ifcomplete 2\n";
        f << "file data/levels/locked.txt\n";
    }
    std::ofstream(campaignRoot/"data/levels/story.txt") << "direction right\n";
    std::ofstream(campaignRoot/"data/levels/bonus.txt") << "direction right\n";
    std::ofstream(campaignRoot/"data/levels/locked.txt") << "direction right\n";
    auto campaignStages=LevelParser::parseAll(campaignRoot/"data",campaignRoot);
    CHECK(campaignStages.size()==3,"v0.34.29 campaign fixture preserves post-end branch destinations and later sets");
    if(campaignStages.size()==3){
        CHECK(campaignStages[0].campaignEnd,"v0.34.29 levels.txt end marks the preceding playable stage terminal");
        CHECK(!campaignStages[1].campaignEnd && campaignStages[1].branchName=="bonus","v0.34.29 post-end stage remains a nonterminal branch destination");
        CHECK(campaignStages[0].setOrder==campaignStages[1].setOrder && campaignStages[2].setOrder!=campaignStages[0].setOrder,"v0.34.29 set boundaries remain explicit in generated metadata");
        CHECK(campaignStages[0].ifComplete==0 && campaignStages[2].ifComplete==2,"v0.34.29 ifcomplete propagates only from its owning level set");
    }
    CHECK(CommandRegistry::lookup("ifcomplete").status==CommandStatus::Supported,"v0.34.29 ifcomplete registry status is runtime-backed");

    CHECK(!stages[0].instructions.empty(), "unified stage instruction stream generated");
    if(stages[0].instructions.size()>=5){
        for(std::size_t i=1;i<stages[0].instructions.size();++i) CHECK(stages[0].instructions[i-1].sequence < stages[0].instructions[i].sequence, "stage instruction order preserves source sequence");
        CHECK(stages[0].instructions[0].kind==0 && stages[0].instructions[1].kind==0 && stages[0].instructions[2].kind==1, "spawn/event cross-type order is preserved");
    }

    auto chars = CharacterParser::parseAll(scanA.dataDir, scanA.root);
    const CharacterDef* bossAlias=nullptr;
    for(const auto& c: chars) if(c.modelName=="Boss") bossAlias=&c;
    CHECK(bossAlias!=nullptr, "models.txt registry alias is preserved");
    if(bossAlias) CHECK(bossAlias->name=="BossGeneric", "registry alias can differ from internal model name");
    const CharacterDef* hero=nullptr;
    for(const auto& c: chars) if(c.type=="player") hero=&c;
    CHECK(hero!=nullptr, "player model detected by type, not by name");
    if(hero){
        CHECK(hero->health==120, "hero health");
        bool sawInfinite=false, sawNone=false, sawAttack=false;
        for(const auto& a: hero->animations){
            for(const auto& f: a.frames){
                if(f.delay<0) sawInfinite=true;
                if(f.sprite=="none") sawNone=true;
                if(f.hasAttack) sawAttack=true;
            }
        }
        CHECK(sawInfinite, "delay infinite");
        CHECK(sawNone, "frame none");
        CHECK(sawAttack, "per-frame attack box");
        CHECK(!hero->animationScript.empty(), "animationscript recorded");
        bool sawFlipFrame=false;
        for(const auto& a:hero->animations) if(a.name=="walk" && a.flipFrame==1) sawFlipFrame=true;
        CHECK(sawFlipFrame, "flipframe parsed into animation metadata");
    }


    // v0.20 palette/remap parsing: image- and ACT-based references are preserved
    // so the generated runtime can select per-entity/per-player color maps.
    fs::path paletteRoot="/tmp/obor-v020-palette-fixture";
    fs::remove_all(paletteRoot); fs::create_directories(paletteRoot/"data/chars");
    fs::path paletteModel=paletteRoot/"data/chars/colorhero.txt";
    {
        std::ofstream f(paletteModel);
        f << "name ColorHero\n";
        f << "type player\n";
        f << "palette data/palettes/base.act\n";
        f << "alternatepal data/palettes/blue.act\n";
        f << "remap data/palettes/source.gif data/palettes/red.gif\n";
        f << "anim idle\ndelay 8\nframe none\n";
    }
    { std::ofstream f(paletteRoot/"data/models.txt"); f << "load ColorHeroAlias data/chars/colorhero.txt\n"; }
    auto colorChars=CharacterParser::parseAll(paletteRoot/"data",paletteRoot);
    CHECK(colorChars.size()==1, "palette fixture model registered through models.txt");
    if(!colorChars.empty()){
        const auto& colorHero=colorChars.front();
        CHECK(colorHero.modelName=="ColorHeroAlias", "palette fixture keeps external model alias");
        CHECK(colorHero.palettePath=="palettes/base.act", "base palette path normalized relative to data/");
        CHECK(colorHero.alternatePalettes.size()==1 && colorHero.alternatePalettes[0]=="palettes/blue.act", "alternatepal parsed and normalized");
        CHECK(colorHero.paletteRemaps.size()==1 && colorHero.paletteRemaps[0].source=="palettes/source.gif" && colorHero.paletteRemaps[0].target=="palettes/red.gif", "remap source/target parsed and normalized");
    }

    auto info = CommandRegistry::lookup("animationscript");
    CHECK(info.parser && info.status==CommandStatus::Partial, "animationscript is PARTIAL (parser yes, runtime partial) not fake SUPPORTED");
    auto delay = CommandRegistry::lookup("delay");
    CHECK(delay.status==CommandStatus::Supported && delay.runtime, "delay is SUPPORTED with runtime");
    auto flipframe = CommandRegistry::lookup("flipframe");
    CHECK(flipframe.status==CommandStatus::Supported && flipframe.runtime, "flipframe is SUPPORTED with runtime");
    auto levelscript = CommandRegistry::lookup("levelscript");
    CHECK(levelscript.parser && levelscript.runtime && levelscript.status==CommandStatus::Partial, "levelscript is executed with ScriptVM and honestly marked PARTIAL");
    bool falseScriptWarning=false;
    for(const auto& issue:compA.issues) if(issue.command=="script-file") falseScriptWarning=true;
    CHECK(!falseScriptWarning, "supported switch/do/include script has no false script-file warning");
    fs::path macroRoot="/tmp/obor-v020-macro-fixture"; fs::remove_all(macroRoot); fs::create_directories(macroRoot/"data");
    {std::ofstream(macroRoot/"data/models.txt") << "load Hero data/hero.txt\n"; std::ofstream(macroRoot/"data/levels.txt") << "set T\nfile data/stage.txt\n"; std::ofstream(macroRoot/"data/hero.txt") << "name Hero\ntype player\nanim idle\nframe none\n"; std::ofstream(macroRoot/"data/stage.txt") << "levelscript data/test.c\n"; std::ofstream(macroRoot/"data/test.c") << "#define TWICE(x) ((x)+(x))\nvoid main(){ int a=TWICE(4); log(a); }\n";}
    auto macroScan=ProjectScanner::scan(macroRoot); auto macroComp=CompatibilityAnalyzer::analyze(macroScan); bool macroWarning=false; for(const auto&i:macroComp.issues) if(i.command=="script-file") macroWarning=true; CHECK(!macroWarning, "function-like #define is recognized by compatibility analyzer");
    fs::path streamApiRoot="/tmp/obor-v03426-stream-api";fs::remove_all(streamApiRoot);fs::create_directories(streamApiRoot/"data/scripts");
    {std::ofstream(streamApiRoot/"data/models.txt") << "load Hero data/hero.txt\n";std::ofstream(streamApiRoot/"data/levels.txt") << "set T\nfile data/stage.txt\n";std::ofstream(streamApiRoot/"data/hero.txt") << "name Hero\ntype player\nanim idle\nframe none\n";std::ofstream(streamApiRoot/"data/stage.txt") << "levelscript data/scripts/stream.c\n";std::ofstream(streamApiRoot/"data/scripts/stream.c") << "void main(){ int f=createfilestream(); filestreamappend(f, \"x\", 1); setfilestreamposition(f,0); getfilestreamposition(f); getfilestreamline(f); savefilestream(f,\"x.txt\"); closefilestream(f); }\n";}
    auto streamApiScan=ProjectScanner::scan(streamApiRoot);auto streamApiComp=CompatibilityAnalyzer::analyze(streamApiScan);bool streamApiWarning=false;for(const auto&i:streamApiComp.issues)if(i.command=="script-file")streamApiWarning=true;CHECK(!streamApiWarning,"v0.34.26 native file-stream APIs do not produce false ScriptVM warnings");
    // v0.21 script-event coverage: model key/move/collision hooks and spawn-entry scripts
    // are not only preserved; the generated runtime has dedicated firing paths for them.
    fs::path scriptRoot="/tmp/obor-v021-script-hooks";fs::remove_all(scriptRoot);fs::create_directories(scriptRoot/"data/chars");fs::create_directories(scriptRoot/"data/levels");fs::create_directories(scriptRoot/"data/scripts");
    {std::ofstream(scriptRoot/"data/models.txt") << "load HookHero data/chars/hookhero.txt\n";std::ofstream(scriptRoot/"data/levels.txt") << "set H\nfile data/levels/h.txt\n";
     std::ofstream(scriptRoot/"data/chars/hookhero.txt") << "name HookHero\ntype player\nkeyscript data/scripts/keymodel.c\nonmovexscript data/scripts/movex.c\nonmovezscript data/scripts/movez.c\nonentitycollision data/scripts/collision.c\ntakedamagescript data/scripts/take.c\ndidhitscript data/scripts/hit.c\nanim idle\ndelay 8\nframe none\n";
     std::ofstream(scriptRoot/"data/levels/h.txt") << "spawn HookHero\ncoords 40 200 0\nspawnscript data/scripts/spawn.c\nat 0\n";
     std::ofstream(scriptRoot/"data/scripts/keymodel.c") << "void main(){ int p=getlocalvar(\"player\"); if(playerkeys(p,1,\"attack\")){ void self=getlocalvar(\"self\"); setentityvar(self,\"pressed\",1); updateframe(self,0); } }\n";
     std::ofstream(scriptRoot/"data/scripts/movex.c") << "void main(){ void self=getlocalvar(\"self\"); changeentityproperty(self,\"velocity\",0,0,0); }\n";
     std::ofstream(scriptRoot/"data/scripts/movez.c") << "void main(){ void self=getlocalvar(\"self\"); setidle(self); }\n";
     std::ofstream(scriptRoot/"data/scripts/collision.c") << "void main(){ void self=getlocalvar(\"self\"); void target=findtarget(self); if(target && checkrange(self,target)){ setentityvar(self,\"near\",1); } }\n";
     std::ofstream(scriptRoot/"data/scripts/take.c") << "void main(){ void attacker=getlocalvar(\"attacker\"); int damage=getlocalvar(\"damage\"); log(damage); }\n";
     std::ofstream(scriptRoot/"data/scripts/hit.c") << "void main(){ void target=getlocalvar(\"damagetaker\"); int t=getlocalvar(\"attacktype\"); log(t); }\n";
     std::ofstream(scriptRoot/"data/scripts/spawn.c") << "void main(){ void self=getlocalvar(\"self\"); setentityvar(self,\"spawnx\",getlocalvar(\"spawnx\")); }\n";
     std::ofstream(scriptRoot/"data/scripts/key1.c") << "void main(){ setglobalvar(\"global_key_seen\",1); }\n";
     std::ofstream(scriptRoot/"data/scripts/keyall.c") << "void main(){ setglobalvar(\"keyall_seen\",1); }\n";}
    auto hookScan=ProjectScanner::scan(scriptRoot);auto hookChars=CharacterParser::parseAll(hookScan.dataDir,hookScan.root);auto hookStages=LevelParser::parseAll(hookScan.dataDir,hookScan.root);auto hookComp=CompatibilityAnalyzer::analyze(hookScan);
    CHECK(hookChars.size()==1 && hookChars[0].keyScript=="data/scripts/keymodel.c", "keyscript parsed for player model");
    CHECK(!hookChars.empty() && !hookChars[0].onMoveXScript.empty() && !hookChars[0].onMoveZScript.empty() && !hookChars[0].onEntityCollisionScript.empty(), "move/collision model hooks parsed");
    CHECK(!hookStages.empty() && !hookStages[0].spawns.empty() && hookStages[0].spawns[0].spawnScript=="scripts/spawn.c", "spawnscript parsed and normalized on spawn entry");
    auto keyInfo=CommandRegistry::lookup("keyscript"), spawnScriptInfo=CommandRegistry::lookup("spawnscript");
    CHECK(keyInfo.runtime && keyInfo.status==CommandStatus::Partial, "keyscript now has a runtime firing path");
    CHECK(spawnScriptInfo.runtime && spawnScriptInfo.status==CommandStatus::Partial, "spawnscript now has a runtime firing path");
    bool hookApiWarning=false;for(const auto&i:hookComp.issues)if(i.command=="script-file")hookApiWarning=true;CHECK(!hookApiWarning, "v0.21 supported script APIs do not produce false compatibility warnings");


    // v0.22 block/guard + direct drawing + modern property constants.
    fs::path blockRoot="/tmp/obor-v022-block-fixture";fs::remove_all(blockRoot);fs::create_directories(blockRoot/"data/chars");fs::create_directories(blockRoot/"data/levels");fs::create_directories(blockRoot/"data/scripts");
    {std::ofstream(blockRoot/"data/models.txt") << "load Guard data/chars/guard.txt\n";std::ofstream(blockRoot/"data/levels.txt") << "set B\nfile data/levels/b.txt\n";
     std::ofstream(blockRoot/"data/chars/guard.txt") << "name Guard\ntype enemy\nblockodds 3\nblockpain 12\nthold 4\nguardpoints 40\nguardrate 2\nblockback 1\ndidblockscript data/scripts/block.c\nonblockwscript data/scripts/wall.c\nanim idle\nframe none\nanim block\nframe none\n";
     std::ofstream(blockRoot/"data/levels/b.txt") << "spawn Guard\ncoords 80 200 0\nat 0\n";
     std::ofstream(blockRoot/"data/scripts/block.c") << "void main(){ void self=getlocalvar(\"self\"); void m=getentityproperty(self,openborconstant(\"ENTITY_PROPERTY_MODELDATA\")); int gp=getentityproperty(self,openborconstant(\"ENTITY_PROPERTY_GUARD_POINTS\")); drawbox(4,4,32,6,100,rgbcolor(30,200,80)); drawline(4,12,36,12,101,rgbcolor(255,255,255)); void scr=allocscreen(16,16); drawboxtoscreen(scr,0,0,8,8,rgbcolor(20,40,60)); drawlinetoscreen(scr,0,0,7,7,rgbcolor(255,255,255)); drawdottoscreen(scr,3,4,rgbcolor(255,0,0)); drawstringtoscreen(scr,1,1,0,\"HUD\"); setdrawmethod(NULL(),1,384,256,1,0,0,0,0,0,0,0); changedrawmethod(NULL(),\"rotate\",15); drawspriteq(scr,0,0,1000,0,0); clearspriteq(); drawscreen(scr,10,20,300,4); free(scr); log(getmodelproperty(m,openborconstant(\"MODEL_PROPERTY_BLOCK_ODDS\"))); }\n";
     std::ofstream(blockRoot/"data/scripts/wall.c") << "void main(){ drawdot(1,1,100,rgbcolor(255,0,0)); }\n";}
    auto blockScan=ProjectScanner::scan(blockRoot);auto blockChars=CharacterParser::parseAll(blockScan.dataDir,blockScan.root);auto blockComp=CompatibilityAnalyzer::analyze(blockScan);
    CHECK(blockChars.size()==1, "v0.22 blocking fixture model parsed");
    if(!blockChars.empty()){CHECK(blockChars[0].blockOdds==3 && blockChars[0].blockPain==12 && blockChars[0].blockThreshold==4, "block odds/pain/threshold parsed");CHECK(blockChars[0].guardPoints==40 && blockChars[0].guardRate==2 && blockChars[0].blockBack, "guard points/rate/blockback parsed");CHECK(!blockChars[0].didBlockScript.empty() && !blockChars[0].onBlockWScript.empty(), "didblock and wall block hooks parsed");}
    CHECK(CommandRegistry::lookup("guardpoints").runtime, "guardpoints registered as runtime-supported");
    CHECK(CommandRegistry::lookup("didblockscript").runtime, "didblockscript has runtime firing path");
    bool blockApiWarning=false;for(const auto&i:blockComp.issues)if(i.command=="script-file")blockApiWarning=true;CHECK(!blockApiWarning, "v0.22 drawing/model-property APIs do not produce false warnings");

    // v0.27 gameplay parity: cutscene metadata, legacy blast/burn, shadows,
    // death/lifespan/landing, defense, boss music, water and original HUD metadata.
    fs::path gp27Root="/tmp/obor-v027-gameplay-fixture";fs::remove_all(gp27Root);fs::create_directories(gp27Root/"data/chars");fs::create_directories(gp27Root/"data/levels");fs::create_directories(gp27Root/"data/scenes");fs::create_directories(gp27Root/"data/scripts");
    {std::ofstream(gp27Root/"data/models.txt") << "blockratio 1\nmpblock 1\nnochipdeath 1\nload Hero27 data/chars/hero27.txt\n";
     std::ofstream(gp27Root/"data/levels.txt") << "set V27\nscene data/scenes/intro.txt\nfile data/levels/stage27.txt\n";
     std::ofstream(gp27Root/"data/chars/hero27.txt") << "name Hero27\ntype player\nmp 80\nknockdowncount 6\nshadow 4\ndiesound data/sounds/die.wav\nlifespan 2.5\ndefense all 0.75 0.8 0.9 2 3\nicon data/sprites/icon.gif\nnolife 0\nlifebarstatus 1\nlifeposition 12 14\nnameposition 16 18\niconposition 3 5\nanimationscript data/scripts/anim.c\nanim fall\nlandframe 1 1\ndelay 4\nframe none\ndelay 4\nframe none\nanim attack1\nattackone 1\n@cmd stamp 7\nblast 0 0 20 20 12 1 1 9 14\nframe none\nanim attack2\nburn 0 0 20 20 7 2 1 1 8 11\nframe none\n";
     std::ofstream(gp27Root/"data/scripts/anim.c") << "void stamp(int x){ setlocalvar(\"stamp\", x); }\n";
     std::ofstream(gp27Root/"data/levels/stage27.txt") << "bossmusic data/music/boss.ogg 240\nwater data/sprites/water.gif 5\nrock 1\nspawn Hero27\ncoords 80 200 0\nboss 1\nat 0\n";
     std::ofstream(gp27Root/"data/scenes/intro.txt") << "music data/music/intro.ogg 1\nanimation data/scenes/intro.gif 0 0 1\n";}
    auto gp27Chars=CharacterParser::parseAll(gp27Root/"data",gp27Root);auto gp27Stages=LevelParser::parseAll(gp27Root/"data",gp27Root);
    CHECK(gp27Chars.size()==1, "v0.27 gameplay fixture character parsed");
    if(!gp27Chars.empty()){
        const auto& c=gp27Chars[0];
        CHECK(c.mp==80 && std::abs(c.knockdownCount-6.0f)<0.001f, "v0.28 mp/knockdowncount parsed");
        CHECK(c.globalBlockRatio && c.globalMpBlock && c.noChipDeath, "v0.29 models.txt global chip rules parsed");
        CHECK(c.shadow==4 && c.dieSound=="sounds/die.wav" && std::abs(c.lifespanSeconds-2.5f)<0.001f, "v0.27 shadow/diesound/lifespan parsed");
        CHECK(c.defenses.size()==1 && std::abs(c.defenses[0].factor-0.75f)<0.001f, "v0.27 defense parsed");
        CHECK(!c.defenses[0].blockRatioDefined && !c.defenses[0].blockTypeDefined, "v0.29 omitted defense chip fields fall back to models.txt globals");
        CHECK(c.iconPath=="sprites/icon.gif" && c.lifePositionX==12 && c.lifePositionY==14 && c.namePositionX==16 && c.namePositionY==18 && c.iconPositionX==3 && c.iconPositionY==5, "v0.27 original HUD metadata parsed");
        bool sawLand=false,sawBlast=false,sawBurn=false,sawCmd=false,sawAttackOne=false;
        for(const auto& a:c.animations){
            if(a.name=="fall" && a.landFrame==1 && a.landDust==1)sawLand=true;
            if(a.name=="attack1" && a.attackOne)sawAttackOne=true;
            for(const auto& f:a.frames) if(f.hasAttack){
                if(f.attack.type==1001){sawBlast=f.attack.fallForce==1&&f.attack.penetration==1&&f.attack.noFlash==1&&f.attack.pauseTime==9&&f.attack.zDepth==14&&std::abs(f.dropVx-2.5f)<0.001f&&f.dropVy==-3;if(f.animationCommand.find("stamp(7);")!=std::string::npos)sawCmd=true;}
                if(f.attack.type==1002)sawBurn=f.attack.fallForce==2&&f.attack.penetration==1&&f.attack.noFlash==1&&f.attack.pauseTime==8&&f.attack.zDepth==11;
            }
        }
        CHECK(sawLand, "v0.27 landframe parsed");CHECK(sawBlast && sawBurn, "v0.32 blast/burn legacy parameter order and reactions parsed");
        CHECK(sawAttackOne, "v0.34.10 attackone is preserved on animation metadata");
        CHECK(sawCmd, "v0.32 @cmd binds generated function call to the immediately following frame");
    }
    CHECK(gp27Stages.size()==1, "v0.27 gameplay fixture stage parsed");
    if(!gp27Stages.empty()){
        const auto& st=gp27Stages[0];
        CHECK(st.bossMusic=="music/boss.ogg" && st.bossMusicOffset==240, "v0.27 bossmusic parsed");
        CHECK(st.waterPath=="sprites/water.gif" && st.waterWarp==5 && st.rockMode==1, "v0.28 water/rock parsed");
        CHECK(!st.preSceneFile.empty() && st.sceneAnimations.size()==1 && st.sceneAnimations[0].path=="scenes/intro.gif", "v0.27 scene/animation cutscene parsed");
    }
    CHECK(CommandRegistry::lookup("blast").runtime && CommandRegistry::lookup("burn").runtime, "v0.27 blast/burn have runtime paths");
    CHECK(CommandRegistry::lookup("@cmd").runtime, "v0.32 @cmd has ScriptVM runtime path");
    CHECK(CommandRegistry::lookup("diesound").runtime && CommandRegistry::lookup("lifespan").runtime, "v0.27 diesound/lifespan have runtime paths");
    CHECK(CommandRegistry::lookup("defense").runtime && CommandRegistry::lookup("bossmusic").runtime && CommandRegistry::lookup("water").runtime && CommandRegistry::lookup("rock").runtime, "v0.28 defense/bossmusic/water/rock have runtime paths");
    CHECK(CommandRegistry::lookup("blockratio").runtime && CommandRegistry::lookup("mpblock").runtime && CommandRegistry::lookup("nochipdeath").runtime, "v0.29 global chip rules have runtime paths");

    // v0.23 advanced combat/AI/projectile model metadata.
    fs::path aiRoot="/tmp/obor-v023-ai-fixture";fs::remove_all(aiRoot);fs::create_directories(aiRoot/"data/chars");fs::create_directories(aiRoot/"data/levels");fs::create_directories(aiRoot/"data/scripts");
    {std::ofstream(aiRoot/"data/models.txt") << "load Hunter data/chars/hunter.txt\n";std::ofstream(aiRoot/"data/levels.txt") << "set AI\nfile data/levels/ai.txt\n";
     std::ofstream(aiRoot/"data/chars/hunter.txt") << "name Hunter\ntype enemy\naggression 42\naiattack 131081\naimove 65538\ncandamage 4\nhostile 4\nprojectilehit 8\nnograb 1\ngrabforce 5\ngrabresistance 7\nthrowdamage 33\nthrowdist 48\nthrowheight 6\nbounce 2\nbouncefactor 0.6\nsubject_to_gravity 1\nondoattackscript data/scripts/attack.c\nanim idle\nframe none\nanim attack1\nattack 0 0 20 20 5\nframe none\nanim attack4\nattack4 0 0 20 20 8\nframe none\n";
     std::ofstream(aiRoot/"data/levels/ai.txt") << "spawn Hunter\ncoords 80 200 0\nat 0\n";std::ofstream(aiRoot/"data/scripts/attack.c") << "void main(){ performattack(getlocalvar(\"self\"), \"attack4\"); }\n";}
    auto aiScan=ProjectScanner::scan(aiRoot);auto aiChars=CharacterParser::parseAll(aiScan.dataDir,aiScan.root);
    CHECK(aiChars.size()==1, "v0.23 AI fixture model parsed");
    if(!aiChars.empty()){const auto& c=aiChars[0];CHECK(c.aggression==42 && c.aiAttack==131081 && c.aiMove==65538, "aggression/aiattack/aimove parsed");CHECK(c.canDamageMask==4 && c.hostileMask==4 && c.projectileHitMask==8, "faction/projectile masks parsed");CHECK(c.noGrab && c.grabForce==5 && c.grabResistance==7, "grab restrictions parsed");CHECK(c.throwDamage==33 && std::abs(c.throwDistance-48.0f)<0.001f && std::abs(c.throwHeight-6.0f)<0.001f, "model throw tuning parsed");CHECK(c.bounce==2 && std::abs(c.bounceFactor-0.6f)<0.001f && c.subjectToGravity, "projectile gravity/bounce parsed");CHECK(!c.onDoAttackScript.empty(), "ondoattackscript preserved");}
    // v0.33 canonical textual faction masks and signed aggression.
    fs::path factionRoot="/tmp/obor-v033-faction-fixture";fs::remove_all(factionRoot);fs::create_directories(factionRoot/"data/chars");
    {std::ofstream(factionRoot/"data/models.txt") << "load MaskEnemy data/chars/mask.txt\nload NoGravity data/chars/nogravity.txt\n";
     std::ofstream(factionRoot/"data/chars/mask.txt") << "name MaskEnemy\ntype enemy\naggression -30\nhostile player npc\ncandamage player npc shot\nprojectilehit enemy obstacle\nanim idle\nframe none\n";
     std::ofstream(factionRoot/"data/chars/nogravity.txt") << "name NoGravity\ntype enemy\nsubject_to_gravity 0\nanim idle\nframe none\n";}
    auto factionChars=CharacterParser::parseAll(factionRoot/"data",factionRoot);
    CHECK(factionChars.size()==2,"v0.33 textual faction fixture parsed");
    const CharacterDef* maskEnemy=nullptr;const CharacterDef* noGravity=nullptr;for(const auto&c:factionChars){if(c.name=="MaskEnemy")maskEnemy=&c;if(c.name=="NoGravity")noGravity=&c;}
    if(maskEnemy){const auto&c=*maskEnemy;CHECK(c.aggression==-30,"v0.33 negative aggression preserved");CHECK(c.hostileMask==((1<<2)|(1<<12)),"v0.33 hostile textual type mask parsed");CHECK(c.canDamageMask==((1<<2)|(1<<12)|(1<<8)),"v0.33 candamage textual type mask parsed");CHECK(c.projectileHitMask==((1<<3)|(1<<5)),"v0.33 projectilehit textual type mask parsed");CHECK(c.subjectToGravity,"OpenBOR default subject_to_gravity remains enabled");}
    CHECK(noGravity && !noGravity->subjectToGravity,"explicit subject_to_gravity 0 overrides the OpenBOR default");
    CHECK(CommandRegistry::lookup("hostile").status==CommandStatus::Supported && CommandRegistry::lookup("candamage").status==CommandStatus::Supported,"v0.33 hostile/candamage are supported after native faction split");
    CHECK(CommandRegistry::lookup("aggression").status==CommandStatus::Supported,"v0.33 signed aggression is supported");
    CHECK(CommandRegistry::lookup("followanim").status==CommandStatus::Supported && CommandRegistry::lookup("followcond").status==CommandStatus::Supported,"v0.33 followanim/followcond execute documented hit conditions");
    CHECK(CommandRegistry::lookup("subentity").status==CommandStatus::Supported && CommandRegistry::lookup("spawnframe").status==CommandStatus::Supported,"v0.33 basic child spawn lifecycle supported");
    CHECK(CommandRegistry::lookup("group").status==CommandStatus::Supported && CommandRegistry::lookup("wait").status==CommandStatus::Supported,"v0.33 group/wait stage flow supported");
    // No-level projects must still emit a compilable zero-stage sentinel.
    fs::path factionOut="/tmp/obor-v033-faction-port-reg";fs::remove_all(factionOut);auto factionScan=ProjectScanner::scan(factionRoot);auto factionComp=CompatibilityAnalyzer::analyze(factionScan);PortGenerator::generate(factionScan,factionComp,factionOut);
    {std::ifstream in(factionOut/"runtime/generated/GeneratedStages.cpp");std::string body((std::istreambuf_iterator<char>(in)),{});CHECK(body.find("const Stage kStages[] = {\n  {},")!=std::string::npos||body.find("\"\",0,0,\"\",\"\",false,nullptr,0")!=std::string::npos,"zero-stage sentinel remains aggregate-initialized and compilable");}

    CHECK(CommandRegistry::lookup("aiattack").runtime && CommandRegistry::lookup("aimove").runtime, "AI commands registered for runtime");
    CHECK(CommandRegistry::lookup("projectilehit").runtime && CommandRegistry::lookup("bouncefactor").runtime, "projectile behavior commands registered for runtime");
    CHECK(CommandRegistry::lookup("ondoattackscript").runtime, "ondoattackscript has runtime firing path");
    fs::path aiOut="/tmp/obor-v023-ai-port";fs::remove_all(aiOut);auto aiComp=CompatibilityAnalyzer::analyze(aiScan);PortGenerator::generate(aiScan,aiComp,aiOut);
    {std::ifstream in(aiOut/"runtime/src/Engine.cpp");std::string body((std::istreambuf_iterator<char>(in)),{});CHECK(body.find("AI_NOATTACK")!=std::string::npos && body.find("highestAttackIndex")!=std::string::npos, "generated runtime contains advanced AI and attack4+ combo logic");CHECK(body.find("Projectile bounce")!=std::string::npos && body.find("targetAllowed")!=std::string::npos, "generated runtime contains bounce/faction-aware projectile logic");CHECK(body.find("script-player-performattack")!=std::string::npos && body.find("entity-ondoattack")!=std::string::npos, "performattack/ondoattack are stateful runtime events");CHECK(body.find("cp.equippedWeapon")!=std::string::npos && body.find("tryPickupWeapon(cp)")!=std::string::npos, "coop players keep independent equipped-weapon/projectile state");}


    // v0.24 combo/cancel/follow/counter + weapon model + child spawn parity.
    fs::path comboRoot="/tmp/obor-v024-combo-fixture";fs::remove_all(comboRoot);fs::create_directories(comboRoot/"data/chars");fs::create_directories(comboRoot/"data/levels");
    {std::ofstream(comboRoot/"data/models.txt") << "load ComboHero data/chars/combo.txt\nload BladeGun data/chars/weapon.txt\nload Minion data/chars/minion.txt\nload Bullet data/chars/bullet.txt\n";
     std::ofstream(comboRoot/"data/levels.txt") << "set C\nfile data/levels/c.txt\n";
     std::ofstream(comboRoot/"data/chars/combo.txt") << "name ComboHero\ntype player\natchain 1 1 2 3\ncombostyle 2\ncombodelay 80\nweapons BladeGun\nsubentity Minion\nanim idle\nframe none\nanim attack1\nfollowanim 2\nfollowcond 3\ncounterrange 0 2 3 0\ncancel 0 2 1 a2 freespecial2\ncustentity Minion\nspawnframe 1 12 3 0 0\nweaponframe 1 1\nattack 0 0 20 20 5\nframe none\nframe none\nanim attack2\nattack 0 0 20 20 6\nframe none\nanim attack3\nattack 0 0 20 20 7\nframe none\nanim follow2\nattack 0 0 22 20 9\nframe none\nanim freespecial2\nattack 0 0 24 20 10\nframe none\n";
     std::ofstream(comboRoot/"data/chars/weapon.txt") << "name BladeGun\ntype none\nshootnum 3\nproject Bullet\nanim idle\nframe none\nanim attack1\nthrowframe 0 0 3 0\nframe none\n";
     std::ofstream(comboRoot/"data/chars/minion.txt") << "name Minion\ntype enemy\nanim idle\nframe none\n";
     std::ofstream(comboRoot/"data/chars/bullet.txt") << "name Bullet\ntype projectile\nanim idle\nattack 0 0 8 8 3\nframe none\n";
     std::ofstream(comboRoot/"data/levels/c.txt") << "spawn ComboHero\ncoords 60 200 0\nat 0\n";}
    auto comboScan=ProjectScanner::scan(comboRoot);auto comboChars=CharacterParser::parseAll(comboScan.dataDir,comboScan.root);const CharacterDef* comboHero=nullptr;const CharacterDef* weaponModel=nullptr;for(const auto&c:comboChars){if(c.modelName=="ComboHero")comboHero=&c;if(c.modelName=="BladeGun")weaponModel=&c;}
    CHECK(comboHero!=nullptr && weaponModel!=nullptr, "v0.24 combo/weapon fixture models parsed");
    if(comboHero){CHECK(comboHero->attackChain.size()==4 && comboHero->attackChain[0]==1 && comboHero->attackChain[2]==2 && comboHero->comboStyle==2 && comboHero->comboDelay==80, "atchain/combostyle/combodelay metadata preserved");CHECK(comboHero->weapons.size()==1 && comboHero->weapons[0]=="BladeGun" && comboHero->subEntityModel=="Minion", "weapon list and subentity metadata preserved");bool advancedAnim=false;for(const auto&a:comboHero->animations)if(a.name=="attack1"){advancedAnim=a.followAnim==2&&a.followCond==3&&a.counterStart==0&&a.counterEnd==2&&!a.counterTakesDamage&&!a.cancels.empty()&&a.spawnFrame==1&&a.weaponFrame==1;}CHECK(advancedAnim,"follow/counter/cancel/spawnframe/weaponframe parsed on animation");}
    if(weaponModel)CHECK(weaponModel->shootNum==3 && weaponModel->projectModel=="Bullet", "limited-use weapon model and projectile parsed");
    CHECK(CommandRegistry::lookup("atchain").runtime && CommandRegistry::lookup("cancel").runtime && CommandRegistry::lookup("counterrange").runtime, "combo/cancel/counter commands have runtime paths");
    CHECK(CommandRegistry::lookup("weapons").runtime && CommandRegistry::lookup("spawnframe").runtime && CommandRegistry::lookup("summonframe").runtime, "weapon/child-spawn commands have runtime paths");
    fs::path comboOut="/tmp/obor-v024-combo-port";fs::remove_all(comboOut);auto comboComp=CompatibilityAnalyzer::analyze(comboScan);PortGenerator::generate(comboScan,comboComp,comboOut);
    {std::ifstream in(comboOut/"runtime/src/Engine.cpp");std::string body((std::istreambuf_iterator<char>(in)),{});CHECK(body.find("cancelTarget")!=std::string::npos && body.find("counterFor")!=std::string::npos && body.find("followConditionPass")!=std::string::npos, "generated runtime contains cancel/counter/follow execution");CHECK(body.find("findActionAnimation")!=std::string::npos && body.find("weaponUses")!=std::string::npos, "generated runtime overlays weapon animations and limited uses");CHECK(body.find("attackOneTarget")!=std::string::npos && body.find("attackFrameHitTargets")!=std::string::npos, "v0.34.36 attackone uses target locking plus per-frame contact de-duplication");CHECK(body.find("summonedChild")!=std::string::npos && body.find("queueChildSpawn")!=std::string::npos, "generated runtime contains spawnframe/summonframe child lifecycle");}


    // v0.25 native command history + weapon loss/drop + child lifecycle/follow metadata.
    fs::path lifeRoot="/tmp/obor-v025-lifecycle-fixture";fs::remove_all(lifeRoot);fs::create_directories(lifeRoot/"data/chars");fs::create_directories(lifeRoot/"data/levels");
    {std::ofstream(lifeRoot/"data/models.txt") << "load LifeHero data/chars/hero.txt\nload GunModel data/chars/gun.txt\nload GunItem data/chars/item.txt\nload Pet data/chars/pet.txt\n";
     std::ofstream(lifeRoot/"data/levels.txt") << "set L\nfile data/levels/l.txt\n";
     std::ofstream(lifeRoot/"data/chars/hero.txt") << "name LifeHero\ntype player\nweapons GunModel LifeHero\nweaploss 1 0\ncom f a 1\nsubentity Pet\nsummonkill 1\nanim idle\nframe none\nanim attack1\nsummonframe 0 8 0 0 0\nunsummonframe 1\nframe none\nframe none\nanim freespecial1\nattack 0 0 20 20 9\nframe none\n";
     std::ofstream(lifeRoot/"data/chars/gun.txt") << "name GunModel\ntype none\nshootnum 2\ntypeshot 1\nweaploss 2 0\nanim idle\nframe none\nanim attack1\nframe none\n";
     std::ofstream(lifeRoot/"data/chars/item.txt") << "name GunItem\ntype item\nsubtype weapon\nweapnum 1\ncounter 3\nanim idle\nframe none\nanim respawn\nframe none\n";
     std::ofstream(lifeRoot/"data/chars/pet.txt") << "name Pet\ntype npc\nsubtype follow\nchild_follow_offset_x 18\nchild_follow_offset_z 4\nchild_follow_range_base_max 90\nchild_follow_range_recall_base_max 260\nanim idle\nframe none\nanim walk\nframe none\n";
     std::ofstream(lifeRoot/"data/levels/l.txt") << "spawn GunItem\ncoords 80 200 0\nat 0\n";}
    auto lifeScan=ProjectScanner::scan(lifeRoot);auto lifeChars=CharacterParser::parseAll(lifeScan.dataDir,lifeScan.root);const CharacterDef*lifeHero=nullptr,*gun=nullptr,*item=nullptr,*pet=nullptr;for(const auto&c:lifeChars){if(c.modelName=="LifeHero")lifeHero=&c;else if(c.modelName=="GunModel")gun=&c;else if(c.modelName=="GunItem")item=&c;else if(c.modelName=="Pet")pet=&c;}
    CHECK(lifeHero&&gun&&item&&pet,"v0.25 lifecycle fixture models parsed");
    if(lifeHero){CHECK(lifeHero->commands.size()==1&&lifeHero->commands[0].sequence=="f a"&&lifeHero->commands[0].targetAnimation=="1","com command sequence/target parsed");CHECK(lifeHero->weaponLossDefined&&lifeHero->weaponLossFlag==1&&lifeHero->summonKill==1,"base weaploss and summonkill parsed");bool lifeAnim=false;for(const auto&a:lifeHero->animations)if(a.name=="attack1")lifeAnim=a.summonFrame&&a.spawnFrame==0&&a.unsummonFrame==1;CHECK(lifeAnim,"summonframe + unsummonframe parsed");}
    if(gun)CHECK(gun->weaponLossDefined&&gun->weaponLossFlag==2&&gun->shootNum==2&&gun->typeShot,"weapon-specific weaploss overrides base and typeshot parsed");
    if(item)CHECK(item->weaponDropCounter==3&&item->weaponNumber==1,"weapon pickup drop counter/index parsed");
    if(pet)CHECK(std::abs(pet->childFollowOffsetX-18.0f)<0.01f&&std::abs(pet->childFollowRange-90.0f)<0.01f&&std::abs(pet->childRecallRange-260.0f)<0.01f,"child follow/recall tuning parsed");
    CHECK(CommandRegistry::lookup("com").runtime&&CommandRegistry::lookup("weaploss").runtime&&CommandRegistry::lookup("unsummonframe").runtime,"v0.25 command/weapon-loss/child-lifecycle registry paths active");
    fs::path lifeOut="/tmp/obor-v025-lifecycle-port";fs::remove_all(lifeOut);auto lifeComp=CompatibilityAnalyzer::analyze(lifeScan);PortGenerator::generate(lifeScan,lifeComp,lifeOut);
    {std::ifstream in(lifeOut/"runtime/src/Engine.cpp");std::string body((std::istreambuf_iterator<char>(in)),{});CHECK(body.find("commandTarget")!=std::string::npos&&body.find("recordInputHistory")!=std::string::npos,"generated runtime contains native COM input history matcher");CHECK(body.find("dropPlayerWeapon")!=std::string::npos&&body.find("flushWeaponDrops")!=std::string::npos,"generated runtime contains physical weapon loss/drop lifecycle");CHECK(body.find("unsummonChildren")!=std::string::npos&&body.find("updateChildFollowing")!=std::string::npos,"generated runtime contains unsummon and child follow/recall lifecycle");}


    // v0.26 timed commands, dynamic combostyle=1, per-axis child follow and model-copy flags.
    fs::path v26Root="/tmp/obor-v026-command-combo-fixture";fs::remove_all(v26Root);fs::create_directories(v26Root/"data/chars");fs::create_directories(v26Root/"data/levels");
    {std::ofstream(v26Root/"data/models.txt") << "load DynamicHero data/chars/hero.txt\nload NoBasicWeapon data/chars/weapon.txt\nload SmartPet data/chars/pet.txt\n";
     std::ofstream(v26Root/"data/levels.txt") << "set V26\nfile data/levels/l.txt\n";
     std::ofstream(v26Root/"data/chars/hero.txt") << "name DynamicHero\ntype player\natchain 1 2 5 0 3 3 6 0 4 0\ncombostyle 1\ncombodelay 90\nweapons NoBasicWeapon\ncom f[3][8] + a -> b +[2] -> ~a :[10] 1\nanim idle\nframe none\nanim attack1\nrange 0 20\nframe none\nanim attack2\nrange 0 28\nrangez 0 12\nframe none\nanim attack3\nrange 29 60\nframe none\nanim attack4\nrange 61 120\nframe none\nanim attack5\nframe none\nanim attack6\nframe none\nanim freespecial1\nframe none\n";
     std::ofstream(v26Root/"data/chars/weapon.txt") << "name NoBasicWeapon\ntype none\nmodelflag no_basic no_script\nanim attack1\nframe none\n";
     std::ofstream(v26Root/"data/chars/pet.txt") << "name SmartPet\ntype npc\nsubtype follow\nchild_follow_offset_x 10\nchild_follow_range_x_min -30\nchild_follow_range_x_max 40\nchild_follow_range_z_min -12\nchild_follow_range_z_max 12\nchild_follow_range_recall_x_min -150\nchild_follow_range_recall_x_max 170\nchild_follow_recall_offset_x 6\nchild_follow_recall_offset_z 3\nchild_follow_recall_animation spawn\nchild_follow_direction_adjust_config toward\nanim idle\nframe none\nanim walk\nframe none\nanim spawn\nframe none\n";
     std::ofstream(v26Root/"data/levels/l.txt") << "spawn SmartPet\ncoords 100 200 0\nat 0\n";}
    auto v26Scan=ProjectScanner::scan(v26Root);auto v26Chars=CharacterParser::parseAll(v26Scan.dataDir,v26Scan.root);const CharacterDef*dyn=nullptr,*noBasic=nullptr,*smartPet=nullptr;for(const auto&c:v26Chars){if(c.modelName=="DynamicHero")dyn=&c;else if(c.modelName=="NoBasicWeapon")noBasic=&c;else if(c.modelName=="SmartPet")smartPet=&c;}
    CHECK(dyn&&noBasic&&smartPet,"v0.26 dynamic command/combo fixture models parsed");
    if(dyn){CHECK(dyn->comboStyle==1&&dyn->attackChain.size()==10&&dyn->attackChain[3]==0,"combostyle=1 preserves zero-separated atchain branches");CHECK(dyn->commands.size()==1&&dyn->commands[0].sequence.find("f[3][8]")!=std::string::npos&&dyn->commands[0].sequence.find(":[10]")!=std::string::npos,"timed hold/chord/sequence command syntax preserved");bool range2=false,range3=false;for(const auto&a:dyn->animations){if(a.name=="attack2")range2=a.hasRangeX&&a.hasRangeZ&&std::abs(a.rangeXMax-28.0f)<0.01f;if(a.name=="attack3")range3=a.hasRangeX&&std::abs(a.rangeXMin-29.0f)<0.01f;}CHECK(range2&&range3,"range/rangez metadata parsed for dynamic combo branches");}
    if(noBasic)CHECK((noBasic->modelCopyFlags&1)!=0&&(noBasic->modelCopyFlags&4)!=0,"modelflag no_basic/no_script parsed");
    if(smartPet)CHECK(std::abs(smartPet->childFollowRangeXMin+30.0f)<0.01f&&std::abs(smartPet->childRecallRangeXMax-170.0f)<0.01f&&smartPet->childRecallAnimation=="spawn"&&smartPet->childDirectionAdjust==6,"per-axis child follow/recall/direction metadata parsed");
    CHECK(CommandRegistry::lookup("range").runtime&&CommandRegistry::lookup("modelflag").runtime,"v0.26 dynamic range/model-copy registry paths active");
    fs::path v26Out="/tmp/obor-v026-command-combo-port";fs::remove_all(v26Out);auto v26Comp=CompatibilityAnalyzer::analyze(v26Scan);PortGenerator::generate(v26Scan,v26Comp,v26Out);
    {std::ifstream in(v26Out/"runtime/src/Engine.cpp");std::string body((std::istreambuf_iterator<char>(in)),{});CHECK(body.find("ParsedCommandStep")!=std::string::npos&&body.find("holdTrigger")!=std::string::npos&&body.find("sequenceGrace")!=std::string::npos,"generated runtime contains timed OpenBOR command matcher");CHECK(body.find("dynamicChainAttackNumber")!=std::string::npos&&body.find("attackRangePass")!=std::string::npos,"generated runtime contains combostyle=1 range branch selection");CHECK(body.find("tryEntityPickupWeapon")!=std::string::npos,"generated runtime contains AI weapon seek/pickup path");CHECK(body.find("childRecallOffsetX")!=std::string::npos&&body.find("childDirectionAdjust")!=std::string::npos,"generated runtime contains advanced child follow/recall behavior");}

    auto mystery = CommandRegistry::lookup("customwave");
    CHECK(mystery.status==CommandStatus::Unknown, "customwave is UNKNOWN");

    auto scanB = ProjectScanner::scan(fixtureB);
    auto compB = CompatibilityAnalyzer::analyze(scanB);
    CHECK(compB.logicalWidth==480 && compB.logicalHeight==272, "fixture B resolution is not hardcoded 320x240");
    auto stagesB = LevelParser::parseAll(scanB.dataDir, scanB.root);
    CHECK(stagesB.size()==1, "fixture B one stage");
    CHECK(compB.unknownCommands>=1, "fixture B unknown customwave recorded");
    if(!stagesB.empty() && stagesB[0].spawns.size()>=2){
        CHECK(stagesB[0].spawns[0].at==50, "earlier `at` wins regardless of declaration order");
        CHECK(stagesB[0].spawns[0].alias=="SecondButEarlier", "alias preserved");
    }
    // Tab-indented model still parses.
    CHECK(compB.models==1, "tab-indented model parsed");

    fs::path outA = "/tmp/obor-port-a";
    fs::path outB = "/tmp/obor-port-b";
    fs::remove_all(outA); fs::remove_all(outB);
    PortGenerator::generate(scanA, compA, outA);
    PortGenerator::generate(scanB, compB, outB);
    CHECK(fs::exists(outA/"runtime"/"generated"/"GeneratedStages.cpp"), "port A stages generated");
    CHECK(fs::exists(outA/"runtime"/"src"/"Engine.cpp"), "port A engine generated");
    {
        std::ifstream in(outA/"runtime"/"generated"/"GeneratedStages.cpp");
        std::string body((std::istreambuf_iterator<char>(in)), {});
        CHECK(body.find("const Stage kStages[]")!=std::string::npos, "generated stage table present");
        CHECK(body.find("Boss")!=std::string::npos, "boss model name comes from data");
        // spawn order in generated table follows sorted at
        auto p50 = body.find("EarlyThug");
        auto pBoss = body.find("\"Boss\"");
        auto pLate = body.find("at=900");
        CHECK(pBoss!=std::string::npos, "boss spawn emitted");
        (void)p50; (void)pLate;
    }
    {
        std::ifstream in(outA/"runtime"/"generated"/"GeneratedCharacters.cpp");
        std::string body((std::istreambuf_iterator<char>(in)), {});
        CHECK(body.find("\"Boss\", \"BossGeneric\"")!=std::string::npos, "generated character keeps models.txt alias and internal name");
    }
    {
        std::ifstream in(outA/"runtime"/"generated"/"GeneratedCharacters.hpp");
        std::string body((std::istreambuf_iterator<char>(in)), {});
        CHECK(body.find("struct PaletteRemap")!=std::string::npos && body.find("alternatePalettes")!=std::string::npos, "generated character schema carries palette/remap metadata");
    }
    {
        std::ifstream in(outA/"runtime"/"src"/"Engine.cpp");
        std::string body((std::istreambuf_iterator<char>(in)), {});
        CHECK(body.find("cameraMaxX_")!=std::string::npos, "camera no longer rewinds (cameraMaxX_)");
        CHECK(body.find("spawnState_")!=std::string::npos, "spawn state machine emitted");
        CHECK(body.find("while(nextSpawn_") == std::string::npos, "old rewind-prone spawn cursor removed");
        CHECK(body.find("c.modelName")!=std::string::npos, "runtime resolves external model aliases");
        CHECK(body.find("groupMin_")!=std::string::npos && body.find("groupMax_")!=std::string::npos, "runtime emits group min/max wave control");
        CHECK(body.find("backtrackFloor_")!=std::string::npos, "runtime emits blockade backtrack floor");
        CHECK(body.find("player-animation-frame")!=std::string::npos, "animationscript is frame-entry driven");
        CHECK(body.find("loadsample")!=std::string::npos && body.find("playsample")!=std::string::npos, "script audio APIs emitted");
        CHECK(body.find("backgroundLayers_")!=std::string::npos && body.find("foregroundLayers_")!=std::string::npos, "runtime emits parallax background/foreground layer rendering");
        CHECK(body.find("levelscript")!=std::string::npos, "runtime executes per-level levelscript");
        CHECK(body.find("jumptobranch")!=std::string::npos && body.find("pendingBranchTarget_")!=std::string::npos, "runtime implements ScriptVM campaign branch jumps");
        CHECK(body.find("current_branch")!=std::string::npos, "runtime exposes current_branch to scripts");
        CHECK(body.find("previousCamera")!=std::string::npos && body.find("scrollSpeed")!=std::string::npos, "runtime applies stage scrollspeed to camera movement");
        CHECK(body.find("applyCharacterPalette")!=std::string::npos && body.find("loadPaletteColors")!=std::string::npos, "runtime emits image/ACT palette remapping");
        CHECK(body.find("reactionAnimation")!=std::string::npos, "runtime emits attack-type-specific pain/fall/rise reactions");
        CHECK(body.find("entityFromHandle")!=std::string::npos, "runtime validates script entity handles against stable runtime entities");
        CHECK(body.find("setentityvar")!=std::string::npos && body.find("findtarget")!=std::string::npos && body.find("setspawnentry")!=std::string::npos, "runtime emits expanded entity/target/spawn ScriptVM APIs");
        CHECK(body.find("modelIsHostileTo")!=std::string::npos && body.find("entity-didhit-entity")!=std::string::npos, "v0.33 runtime separates hostile targeting from candamage and supports entity-vs-entity combat");
        CHECK(body.find("effectiveCombatType")!=std::string::npos && body.find("ownerModel")!=std::string::npos, "v0.34.19 projectile and auxiliary models inherit owner combat faction/masks");
        CHECK(body.find("findSafePlayerSpawnPoint")!=std::string::npos && body.find("spawnPointBlocked")!=std::string::npos, "v0.34.19 player spawn searches around walls and holes");
        CHECK(body.find("save_version=3")!=std::string::npos && body.find("joined_mask=")!=std::string::npos && body.find("consumeRespawnResource")!=std::string::npos && body.find("suspendSave_=true;beginGame();suspendSave_=false")!=std::string::npos, "v0.34.23 Save V3 preserves joined slots and native per-player respawn pools");
        CHECK(body.find("runSmokeGame")!=std::string::npos && body.find("SMOKE GAME OK")!=std::string::npos, "v0.34.19 runtime includes real gameplay smoke mode");CHECK(body.find("runBehaviorSuite")!=std::string::npos&&body.find("behavior-suite-")!=std::string::npos,"v0.34.44 generated engine includes persistent behavioral regression mode");
        CHECK(body.find("FrontendState::TitleScreen")!=std::string::npos && body.find("playStartupFlow")!=std::string::npos && body.find("scenes/intro.txt")!=std::string::npos && body.find("How To Play")!=std::string::npos && body.find("HallOfFame")!=std::string::npos, "v0.34.47 restores authored startup/title/howto/gameover/hiscore frontend flow");
        CHECK(body.find("FrontendState::GameStartMenu")!=std::string::npos && body.find("FrontendState::LoadGameMenu")!=std::string::npos && body.find("Choose Mode")!=std::string::npos && body.find("Game Mode")!=std::string::npos && body.find("readSaveMenuSummary")!=std::string::npos, "v0.34.47 restores OpenBOR Start Game / Choose Mode / Load Game state flow");
        CHECK(body.find("drawLegacyMenuCentered")!=std::string::npos && body.find("drawLegacyMenuColumn")!=std::string::npos && body.find("titleMenuBackground_")!=std::string::npos && body.find("Start Game")!=std::string::npos, "v0.34.47 menu layout uses legacy font metrics and titleb post-start background");
        CHECK(body.find("showLoadingScreen")!=std::string::npos && body.find("bgs/loading2")!=std::string::npos, "v0.34.46 loading flow honors authored 1P/2P loading backgrounds");
        CHECK(body.find("JLU core hero matrix resolves Superman/GL/WW/Aquaman/Cyborg/Shazam/Hawkgirl/BlackCanary")!=std::string::npos, "v0.34.44 JLU behavior suite includes core hero matrix");
        CHECK(body.find("Superman heat vision")!=std::string::npos && body.find("Flash speedT remains bound to player through native bindentity state")!=std::string::npos, "v0.34.44 JLU behavior suite covers authored hero powers and bindings");
        CHECK(body.find("Green Lantern wall construct")!=std::string::npos && body.find("Wonder Woman bomb")!=std::string::npos, "v0.34.44 JLU behavior suite covers construct and bomb semantics");
        CHECK(body.find("kStages[stageIndex_].skipSelect")!=std::string::npos && body.find("else if(accept||gamepadButtonPressedFor")!=std::string::npos, "v0.34.22 frontend honors selected-set skipselect and does not consume Enter twice in Character Select");
        CHECK(body.find("FrontendState::LevelSetSelect")!=std::string::npos && body.find("campaignFirstStages_")!=std::string::npos && body.find("startCampaign")!=std::string::npos, "v0.34.22 frontend exposes multiple levels.txt sets as campaign choices");
        CHECK(body.find("selectBackground_")!=std::string::npos && body.find("drawSelectCharacterPreview")!=std::string::npos && body.find("findAnimation(model,\"select\")")!=std::string::npos, "v0.34.22 character select uses original select background and model select animation");
        CHECK(body.find("loadLegacyMenuConfig")!=std::string::npos && body.find("legacyControlLabel")!=std::string::npos, "v0.34.22 menu.txt renamekey/disablekey metadata reaches native frontend");
        CHECK(body.find("if(name==\"sin\")")!=std::string::npos && body.find("if(name==\"cos\")")!=std::string::npos && body.find("if(name==\"sqrt\")")!=std::string::npos, "v0.34.22 ScriptVM host exposes common math helpers used by OpenBOR scripts");
        CHECK(body.find("k==\"position\"")!=std::string::npos, "v0.33 ScriptVM changeentityproperty position supports common spawn helper scripts");
        CHECK(body.find("global-key-all")!=std::string::npos && body.find("global-key-player")!=std::string::npos, "runtime fires global keyN.c and keyall.c scripts");
        CHECK(body.find("spawnscript")!=std::string::npos && body.find("spawnx")!=std::string::npos && body.find("spawnat")!=std::string::npos, "runtime fires spawnscript with spawn locals");
        CHECK(body.find("damagetaker")!=std::string::npos && body.find("attacker")!=std::string::npos && body.find("attacktype")!=std::string::npos, "runtime supplies combat event locals to didhit/takedamage hooks");
        CHECK(body.find("playerkeys")!=std::string::npos && body.find("updateframe")!=std::string::npos && body.find("setidle")!=std::string::npos, "runtime emits key-state, updateframe and setidle APIs");
        CHECK(body.find("tryBlockEntity")!=std::string::npos && body.find("tryBlockPlayer")!=std::string::npos, "generated runtime includes native block resolution");CHECK(body.find("blockPower<=penetration")!=std::string::npos, "v0.27.1 defense blockpower is compared against attack penetration");CHECK(body.find("threshold=m->blockThreshold+(d?d->blockThreshold:0)")!=std::string::npos, "v0.27.1 per-type blockthreshold combines with model thold");CHECK(body.find("defenseAllowsPain")!=std::string::npos && body.find("defenseAllowsKnockdown")!=std::string::npos, "v0.27.1 per-type pain and knockdown defense semantics emitted");CHECK(body.find("blockedChipDamage")!=std::string::npos && body.find("applyBlockedChip")!=std::string::npos, "v0.28 blockratio/blocktype chip damage emitted");CHECK(body.find("globalBlockRatio")!=std::string::npos && body.find("globalMpBlock")!=std::string::npos && body.find("noChipDeath")!=std::string::npos, "v0.29 global blockratio/mpblock/nochipdeath emitted");CHECK(body.find("blockRatioDefined")!=std::string::npos && body.find("blockTypeDefined")!=std::string::npos, "v0.29 per-defense chip settings preserve global fallback distinction");CHECK(body.find("resolveKnockdown")!=std::string::npos && body.find("knockdownCount")!=std::string::npos, "v0.28 knockdowncount/defense knockdown scaling emitted");CHECK(body.find("loop_offset_bytes")!=std::string::npos, "v0.28 bossmusic byte loop offset emitted");CHECK(body.find("stage_->rockMode")!=std::string::npos && body.find("legacyWaterSurface")!=std::string::npos, "v0.28 water warp speed/rock runtime emitted");CHECK(body.find("rockDx")!=std::string::npos && body.find("rockDy")!=std::string::npos, "v0.29 rock modes move stage while HUD stays outside offset path");
        CHECK(body.find("drawbox")!=std::string::npos && body.find("loadsprite")!=std::string::npos, "generated runtime includes direct-drawing APIs");
        CHECK(body.find("getmodelproperty")!=std::string::npos && body.find("getlevelproperty")!=std::string::npos, "generated runtime includes model/level property APIs");
    }
    {
        std::ifstream in(outA/"runtime"/"CMakeLists.txt");
        std::string body((std::istreambuf_iterator<char>(in)), {});
        CHECK(body.find("-municode")!=std::string::npos, "v0.34.44 MinGW Windows GUI runtime links the authored wWinMain entrypoint");
    }
    {
        std::ifstream in(outA/"runtime"/"src"/"main.cpp");
        std::string body((std::istreambuf_iterator<char>(in)), {});
        CHECK(body.find("findPortRoot")!=std::string::npos && body.find("assets\"/\"openbor-data")!=std::string::npos, "v0.29 generated runtime auto-discovers port root from build subdirectories");
    }
    {
        std::ifstream in(outA/"runtime"/"src"/"Renderer.cpp");
        std::string body((std::istreambuf_iterator<char>(in)), {});
        auto decl=body.find("static unsigned char blendChannel(unsigned char src,unsigned char dst,int mode);");
        auto win=body.find("#ifdef _WIN32");
        CHECK(decl!=std::string::npos && win!=std::string::npos && decl<win, "v0.34.44 Windows CPU fallback sees blendChannel declaration before platform branch");
    }
    {
        std::ifstream in(outA/"runtime"/"include"/"Engine.hpp");
        std::string body((std::istreambuf_iterator<char>(in)), {});
        CHECK(body.find("std::deque<RuntimeEntity>")!=std::string::npos, "runtime uses stable entity storage for script self/entity handles");
    }
    {
        std::ifstream in(outA/"runtime"/"include"/"Renderer.hpp");
        std::string body((std::istreambuf_iterator<char>(in)), {});
        CHECK(body.find("storage.use_count()!=1")!=std::string::npos && body.find("storage.unique()")==std::string::npos, "v0.34.44 generated renderer is C++20-portable across libc++/libstdc++ shared_ptr APIs");
    }
    {
        std::ifstream in(outA/"runtime"/"src"/"ScriptVM.cpp");
        std::string body((std::istreambuf_iterator<char>(in)), {});
        CHECK(body.find("switchStatement")!=std::string::npos, "ScriptVM emits switch support");
        CHECK(body.find("preprocessScript")!=std::string::npos, "ScriptVM emits preprocessor include/define support");
        CHECK(body.find("g_programCache")!=std::string::npos && body.find("std::span<const Tok>")!=std::string::npos && body.find("animCacheKey")!=std::string::npos, "v0.34.46 ScriptVM caches preprocessed/tokenized static programs and animation commands");
        CHECK(body.find("FunctionMacro")!=std::string::npos && body.find("expandFunctionMacros")!=std::string::npos, "ScriptVM emits function-like macro expansion");
        CHECK(body.find("expected while after do")!=std::string::npos, "ScriptVM emits do/while support");
    }
    {
        std::ifstream in(outA/"runtime"/"include"/"AudioSystem.hpp");
        std::string body((std::istreambuf_iterator<char>(in)), {});
        CHECK(body.find("effectVoices_")!=std::string::npos, "audio runtime supports overlapping active effects");
        CHECK(body.find("pauseMusic")!=std::string::npos, "audio runtime exposes music pause API");
    }
    {
        std::ifstream in(outA/"runtime"/"src"/"AudioDecoder.cpp");
        std::string body((std::istreambuf_iterator<char>(in)), {});
        CHECK(body.find("tag==3")!=std::string::npos, "WAV decoder includes IEEE float32 path");
        CHECK(body.find("bits==24")!=std::string::npos && body.find("bits==32")!=std::string::npos, "WAV decoder includes 24/32-bit PCM paths");
        CHECK(body.find("decodeMediaFoundation")!=std::string::npos && body.find("MFCreateSourceReaderFromURL")!=std::string::npos, "Windows runtime emits Media Foundation compressed-audio decoder");
    }
    {
        std::ifstream in(outB/"config"/"port.ini");
        std::string body((std::istreambuf_iterator<char>(in)), {});
        CHECK(body.find("logical_width=480")!=std::string::npos, "port B records 480 width");
        CHECK(body.find("logical_height=272")!=std::string::npos, "port B records 272 height");
    }
    {
        std::ifstream in(outB/"config"/"openbor-video.ini");
        std::string body((std::istreambuf_iterator<char>(in)), {});
        CHECK(body.find("logical_width=480")!=std::string::npos && body.find("logical_height=272")!=std::string::npos, "PortGenerator always writes detected video resolution");
    }
    {
        std::ifstream in(outA/"runtime"/"src"/"main.cpp");
        std::string body((std::istreambuf_iterator<char>(in)), {});
        CHECK(body.find("executableDir")!=std::string::npos, "generated runtime roots itself at executable directory");
        CHECK(body.find("argv[i][0]!=\'-\'")!=std::string::npos, "generated runtime does not mistake CLI flags such as --headless for the port root");
    }
    CompatibilityAnalyzer::writeReport(scanA, compA, outA/"reports");
    CHECK(fs::exists(outA/"reports"/"analysis.json"), "analysis.json");
    CHECK(fs::exists(outA/"reports"/"compatibility-report.txt"), "compatibility-report.txt");

    // Real traversal guard exercises the same helper used by parsers/generator input handling.
    CHECK(SafePath::resolveWithin(scanA.dataDir,"DATA/CHARS/HERO/HERO.TXT")==fs::weakly_canonical(scanA.dataDir/"chars/hero/hero.txt"),"mixed case model references resolve inside data");
    CHECK(SafePath::resolveWithin(scanA.dataDir, "../secret.txt").empty(), "path traversal outside data/ is rejected");
    CHECK(SafePath::resolveWithin(scanA.dataDir, "data/chars/hero/hero.txt") == fs::weakly_canonical(scanA.dataDir/"chars/hero/hero.txt"), "valid OpenBOR data path resolves inside data/");

    // A generated port is a valid input for the test/scan path.
    auto generatedScan = ProjectScanner::scan(outA);
    CHECK(generatedScan.hasDataDir && generatedScan.dataDir.filename()=="openbor-data", "generated port layout assets/openbor-data is recognized");
    try{ auto generatedInput=InputResolver::resolve(outA); CHECK(generatedInput.gameRoot==fs::weakly_canonical(outA), "v0.34.22 generated portable assets/openbor-data folder is accepted as an input root"); }catch(const std::exception&e){std::cerr<<"FAIL: generated-port resolver exception: "<<e.what()<<"\n";++gFails;}
    auto generatedComp = CompatibilityAnalyzer::analyze(generatedScan);
    bool generatedFalseScriptWarning=false;
    for(const auto& issue:generatedComp.issues) if(issue.command=="script-file") generatedFalseScriptWarning=true;
    CHECK(!generatedFalseScriptWarning, "generated port include/import analysis has no false script warning");

    // v0.20 universal input: bare OpenBOR PAK and ZIP package are resolved without
    // requiring the user to unpack/rearrange the game first.
    fs::path pakPath="/tmp/obor-v020-test.pak";fs::remove(pakPath);CHECK(createTestPak(pakPath), "synthetic OpenBOR PAK fixture created");
    try{ auto pakInput=InputResolver::resolve(pakPath);auto pakScan=ProjectScanner::scan(pakInput.gameRoot);CHECK(pakInput.sourceKind=="pak", "bare .pak input recognized");CHECK(pakScan.hasModels&&pakScan.hasLevels, "bare .pak extracted into analyzable OpenBOR data/"); }catch(const std::exception&e){std::cerr<<"FAIL: PAK resolver exception: "<<e.what()<<"\n";++gFails;}

    fs::path zipSrc="/tmp/obor-v020-zip-src",zipPath="/tmp/obor-v020-game.zip";fs::remove_all(zipSrc);fs::remove(zipPath);fs::create_directories(zipSrc/"Bundle/MyGame");fs::copy(fixtureA,zipSrc/"Bundle/MyGame",fs::copy_options::recursive|fs::copy_options::overwrite_existing);
    {auto old=fs::current_path();fs::current_path(zipSrc);int rc=std::system((std::string("cmake -E tar cf ")+zipPath.string()+" --format=zip Bundle").c_str());fs::current_path(old);CHECK(rc==0&&fs::exists(zipPath), "ZIP fixture created");}
    try{ auto zipInput=InputResolver::resolve(zipPath);auto zipScan=ProjectScanner::scan(zipInput.gameRoot);CHECK(zipInput.sourceKind=="zip", "ZIP input recognized");CHECK(zipScan.hasModels&&zipScan.hasLevels, "nested ZIP game root auto-detected"); }catch(const std::exception&e){std::cerr<<"FAIL: ZIP resolver exception: "<<e.what()<<"\n";++gFails;}

    fs::path openborZipSrc="/tmp/obor-v020-openbor-zip-src",openborZip="/tmp/obor-v020-openbor-package.zip";fs::remove_all(openborZipSrc);fs::remove(openborZip);fs::create_directories(openborZipSrc/"OpenBOR/Paks");fs::copy_file(pakPath,openborZipSrc/"OpenBOR/Paks/TestGame.pak");
    {auto old=fs::current_path();fs::current_path(openborZipSrc);int rc=std::system((std::string("cmake -E tar cf ")+openborZip.string()+" --format=zip OpenBOR").c_str());fs::current_path(old);CHECK(rc==0&&fs::exists(openborZip), "OpenBOR engine-style ZIP with Paks/*.pak fixture created");}
    try{ auto packageInput=InputResolver::resolve(openborZip);auto packageScan=ProjectScanner::scan(packageInput.gameRoot);CHECK(packageInput.sourceKind=="openbor-package-zip", "OpenBOR ZIP containing Paks/*.pak recognized");CHECK(packageScan.hasModels&&packageScan.hasLevels, "PAK inside OpenBOR ZIP auto-extracted and analyzed"); }catch(const std::exception&e){std::cerr<<"FAIL: OpenBOR package ZIP resolver exception: "<<e.what()<<"\n";++gFails;}


    // v0.30 legacy unknown-command parity: these commands were present in the
    // Ghosts'n Goblins Dragon Ball compatibility report and must no longer fall
    // through as UNKNOWN. Runtime-backed commands stay honest about partial edges.
    {
        const char* cmds[]={"seta","antigravity","nopain","nodrop","nodieblink","noquake","subject_to_hole",
                            "offscreenkill","falldie","death","risetime","riseattacktype","fmap","remove","throw",
                            "no_adjust_base","quakeframe","hitfx","hitflash","icondie","order","2pitem","lives",
                            "credits","colourdepth"};
        for(const char* c:cmds) CHECK(CommandRegistry::lookup(c).status!=CommandStatus::Unknown, std::string("v0.30 registry recognizes ")+c);
    }
    fs::path legacyRoot="/tmp/obor-v030-legacy-fixture";fs::remove_all(legacyRoot);fs::create_directories(legacyRoot/"data/chars");fs::create_directories(legacyRoot/"data/levels");
    {
        std::ofstream(legacyRoot/"data/models.txt") << "load Legacy data/chars/legacy.txt\n";
        std::ofstream(legacyRoot/"data/levels.txt") << "set Legacy\nlives 5\ncredits 3\nfile data/levels/legacy.txt\n";
        std::ofstream(legacyRoot/"data/levels/legacy.txt") << "panel data/bgs/bg.gif\norder aaaaaaa\nbackground data/bgs/bg.gif\n";
        std::ofstream f(legacyRoot/"data/chars/legacy.txt");
        f << "name Legacy\n"
          << "type enemy\n"
          << "antigravity 100\n"
          << "nopain 1\n"
          << "nodrop 1\n"
          << "nodieblink 1\n"
          << "noquake 1\n"
          << "subject_to_hole 0\n"
          << "no_adjust_base 1\n"
          << "offscreenkill 120\n"
          << "falldie 2\n"
          << "risetime 20 -50\n"
          << "riseattacktype 1\n"
          << "fmap 2\n"
          << "remove 1\n"
          << "throw 1\n"
          << "icon data/sprites/icon.gif\n"
          << "icondie data/sprites/dead.gif\n"
          << "anim attack1\n"
          << "seta 24\n"
          << "quakeframe 0 2 3\n"
          << "hitfx data/sounds/hit.wav\n"
          << "hitflash Flash\n"
          << "attack 0 0 16 16 5\n"
          << "frame none\n";
    }
    auto legacyChars=CharacterParser::parseAll(legacyRoot/"data",legacyRoot);
    CHECK(legacyChars.size()==1,"v0.30 legacy fixture model parsed");
    if(!legacyChars.empty()){
        const auto& c=legacyChars[0];
        CHECK(std::abs(c.antigravity-1.0f)<0.001f && c.noPain && c.noDrop && c.noQuake,"v0.30 antigravity/nopain/nodrop/noquake parsed");
        CHECK(!c.subjectToHole && c.offscreenKill==120 && c.fallDie==2 && c.riseTime==20 && c.riseAttackType==1,"v0.30 hole/offscreen/death/rise metadata parsed");
        CHECK(c.iconDiePath=="sprites/dead.gif","v0.30 icondie parsed");
        CHECK(!c.animations.empty() && !c.animations[0].frames.empty() && c.animations[0].frames[0].hasSetA && std::abs(c.animations[0].frames[0].setA-24.0f)<0.001f,"v0.30 seta persists into committed frame");
        CHECK(c.animations[0].quakeFrame==0 && c.animations[0].quakeLoops==2 && c.animations[0].quakeIntensity==3,"v0.30 quakeframe parsed");
        CHECK(c.animations[0].hitFx=="sounds/hit.wav" && c.animations[0].hitFlash=="Flash","v0.30 hitfx/hitflash parsed");
    }
    auto legacySets=LevelParser::parseLevelSets(legacyRoot/"data/levels.txt");
    CHECK(!legacySets.empty() && legacySets[0].lives==5 && legacySets[0].credits==3,"v0.30 levels.txt lives/credits parsed");
    auto legacyStage=LevelParser::parseStage(legacyRoot/"data/levels/legacy.txt",legacyRoot,legacySets[0]);
    CHECK(legacyStage.panels.size()==7 && legacyStage.panelOrder=="aaaaaaa","v0.34.0 legacy order is a panel sequence rather than a stage number");
    fs::path legacyOut="/tmp/obor-v030-legacy-port";fs::remove_all(legacyOut);auto legacyScan=ProjectScanner::scan(legacyRoot);auto legacyComp=CompatibilityAnalyzer::analyze(legacyScan);PortGenerator::generate(legacyScan,legacyComp,legacyOut);
    {
        std::ifstream in(legacyOut/"runtime/src/Engine.cpp");std::string body((std::istreambuf_iterator<char>(in)),{});
        CHECK(body.find("triggerQuake")!=std::string::npos && body.find("playHitFx")!=std::string::npos,"v0.30 generated runtime includes quakeframe/hitfx execution");
        CHECK(body.find("antigravity")!=std::string::npos && body.find("subjectToHole")!=std::string::npos && body.find("offscreenKill")!=std::string::npos,"v0.30 generated runtime includes physics/hole/offscreen parity");
        CHECK(body.find("hudDeadIconCache_")!=std::string::npos && body.find("iconDiePath")!=std::string::npos,"v0.30 generated runtime includes icondie HUD path");
    }


    // v0.31 registry/HUD/cutscene parity. `know` is a real model-registry entry,
    // not merely a scanner hint, and completed presentation commands must be
    // reported as SUPPORTED; v0.34.24 also composites lifebarstatus component layers.
    {
        const char* supported31[]={"know","animation","shadow","icon","icondie","nolife","lifeposition","nameposition","iconposition","subject_to_hole"};
        for(const char* c:supported31) CHECK(CommandRegistry::lookup(c).status==CommandStatus::Supported,std::string("v0.31 registry supports ")+c);
        CHECK(CommandRegistry::lookup("lifebarstatus").status==CommandStatus::Supported,"v0.34.24 lifebarstatus component layers are natively composited");
    }
    fs::path v31Root="/tmp/obor-v031-registry-hud";fs::remove_all(v31Root);fs::create_directories(v31Root/"data/chars");fs::create_directories(v31Root/"data/levels");
    {
        std::ofstream(v31Root/"data/models.txt") << "load Hero data/chars/hero.txt\nknow LazyEnemy data/chars/lazy.txt\n";
        std::ofstream(v31Root/"data/levels.txt") << "set Test\nfile data/levels/stage.txt\n";
        std::ofstream(v31Root/"data/levels/stage.txt") << "spawn LazyEnemy\ncoords 80 200 0\nat 0\n";
        std::ofstream(v31Root/"data/chars/hero.txt") << "name Hero\ntype player\nanim idle\nframe none\n";
        std::ofstream f(v31Root/"data/chars/lazy.txt");
        f << "name LazyInternal\n"
          << "type enemy\n"
          << "shadow 4\n"
          << "icon data/sprites/lazy.gif 1\n"
          << "icondie data/sprites/lazy-dead.gif\n"
          << "nolife 1\n"
          << "lifebarstatus 280 7 1 1 1 -300 -299 -298 -297\n"
          << "lifeposition 18 218\n"
          << "nameposition 18 227\n"
          << "iconposition 0 218\n"
          << "anim idle\nframe none\n";
    }
    auto v31Chars=CharacterParser::parseAll(v31Root/"data",v31Root);
    CHECK(v31Chars.size()==2,"v0.31 load + know models both enter native registry");
    const CharacterDef* lazy31=nullptr;for(const auto&c:v31Chars)if(c.modelName=="LazyEnemy")lazy31=&c;
    CHECK(lazy31!=nullptr,"v0.31 know preserves external registry alias");
    if(lazy31){
        CHECK(lazy31->name=="LazyInternal" && lazy31->shadow==4,"v0.31 know model definition parsed normally");
        CHECK(lazy31->iconUsesPalette && lazy31->iconDiePath=="sprites/lazy-dead.gif" && lazy31->noLife,"v0.31 icon palette/death/nolife metadata parsed");
        CHECK(lazy31->lifeBarStatusDefined && lazy31->lifeBarWidth==280 && lazy31->lifeBarHeight==7 && lazy31->lifeBarNoBorder==1,"v0.31 lifebarstatus size/border parsed");
        CHECK(lazy31->lifeBarType==1 && lazy31->lifeBarOrientation==1 && lazy31->lifeBarBorderLayer==-300 && lazy31->lifeBarBackfillLayer==-297,"v0.31 lifebarstatus mode/orientation/layers preserved");
        CHECK(lazy31->lifePositionX==18 && lazy31->lifePositionY==218 && lazy31->namePositionY==227 && lazy31->iconPositionY==218,"v0.31 popup HUD positions parsed");
    }
    fs::path v31Out="/tmp/obor-v031-port";fs::remove_all(v31Out);auto v31Scan=ProjectScanner::scan(v31Root);auto v31Comp=CompatibilityAnalyzer::analyze(v31Scan);PortGenerator::generate(v31Scan,v31Comp,v31Out);
    {
        std::ifstream in(v31Out/"runtime/generated/GeneratedCharacters.cpp");std::string body((std::istreambuf_iterator<char>(in)),{});
        CHECK(body.find("LazyEnemy")!=std::string::npos,"v0.31 generated character table contains know-only model");
    }
    {
        std::ifstream in(v31Out/"runtime/src/Engine.cpp");std::string body((std::istreambuf_iterator<char>(in)),{});
        CHECK(body.find("iconUsesPalette")!=std::string::npos && body.find("lifeBarOrientation")!=std::string::npos,"v0.31 generated runtime includes HUD palette/orientation behavior");
        CHECK(body.find("lifeBarShadowLayer")!=std::string::npos && body.find("std::stable_sort(parts.begin(),parts.end()")!=std::string::npos,"v0.34.24 lifebarstatus border/shadow/graph/backfill layer ordering emitted");
    }

    // OpenBOR v7533 stores damageonlanding on the active attack box. It must
    // survive frame inheritance and reach the generated C++ attack table.
    fs::path landRoot="/tmp/obor-v0334-landing";fs::remove_all(landRoot);fs::create_directories(landRoot/"data/chars");
    {std::ofstream(landRoot/"data/models.txt") << "load LandingHero data/chars/hero.txt\n";
     std::ofstream(landRoot/"data/chars/hero.txt") << "name LandingHero\ntype player\nanim attack1\nattack 0 0 16 16 4 1\ndamageonlanding 7 0 attack2\nframe none\ndamageonlanding 8 0\nframe none\n";}
    auto landChars=CharacterParser::parseAll(landRoot/"data",landRoot);
    CHECK(landChars.size()==1 && !landChars[0].animations.empty() && !landChars[0].animations[0].frames.empty() && landChars[0].animations[0].frames[0].attack.landingDamage==7,"v0.33.4 landing damage preserved on the attack frame");
    if(landChars.size()==1 && !landChars[0].animations.empty() && landChars[0].animations[0].frames.size()==2)
        CHECK(landChars[0].animations[0].frames[0].attack.landingMode==0 && landChars[0].animations[0].frames[1].attack.landingMode==0 && landChars[0].animations[0].frames[0].attack.landingType==2 && landChars[0].animations[0].frames[1].attack.landingType==-1,"v0.34.11 landing mode and named/default landing types parsed");
    CHECK(CommandRegistry::lookup("damageonlanding").status==CommandStatus::Partial,"v0.33.4 reports limited landing-damage parity");
    auto landScan=ProjectScanner::scan(landRoot);auto landComp=CompatibilityAnalyzer::analyze(landScan);fs::path landOut="/tmp/obor-v0334-landing-port";fs::remove_all(landOut);PortGenerator::generate(landScan,landComp,landOut);
    {std::ifstream in(landOut/"runtime/generated/GeneratedCharacters.cpp");std::string body((std::istreambuf_iterator<char>(in)),{});CHECK(body.find(",7,0,2,0,0,0}, true")!=std::string::npos && body.find(",8,0,-1,0,0,0}, true")!=std::string::npos,"v0.34.11 generated attack table carries landing mode and landing types");}

    // Final Fight X v1.0.0 uses these legacy forms heavily. Keep them as a
    // focused regression fixture so PARTIAL reductions remain tied to real syntax.
    fs::path ffxRoot="/tmp/obor-v03411-ffx-partials";fs::remove_all(ffxRoot);fs::create_directories(ffxRoot/"data/chars");fs::create_directories(ffxRoot/"data/levels");
    {std::ofstream(ffxRoot/"data/models.txt") << "load FFXHero data/chars/hero.txt\n";
     std::ofstream(ffxRoot/"data/chars/hero.txt") << "name FFXHero\ntype player\naimove chase\ndefense all\nnodieblink 2\nanim attack1\nattack 0 0 16 16 4 1\ndamageonlanding 0 1\nplatform 29 99 -37 -37 41 41 28 1000\nflipframe\nframe none\n";}
    auto ffxChars=CharacterParser::parseAll(ffxRoot/"data",ffxRoot);
    CHECK(ffxChars.size()==1 && ffxChars[0].aiMove==2,"v0.34.11 Final Fight X aimove chase maps to the native chase flag");
    CHECK(ffxChars.size()==1 && ffxChars[0].defenses.size()==1 && ffxChars[0].defenses[0].type=="all" && ffxChars[0].defenses[0].factor==0.0f,"v0.34.36 Final Fight X defense all without factor preserves legacy zero");
    if(ffxChars.size()==1 && !ffxChars[0].animations.empty() && !ffxChars[0].animations[0].frames.empty()){const auto&f=ffxChars[0].animations[0].frames[0];
        CHECK(f.attack.landingDamage==0 && f.attack.landingMode==1,"v0.34.11 Final Fight X damageonlanding 0 1 preserves falling-body mode");
        CHECK(f.hasPlatform && f.platform.x==29 && f.platform.z==99 && f.platform.depth==28 && f.platform.altitude==1000,"v0.34.11 Final Fight X platform geometry is parsed per frame");
        CHECK(ffxChars[0].animations[0].flipFrame==0,"v0.34.16 empty flipframe follows OpenBOR GET_INT_ARG default and flips on frame 0");}
    auto ffxScan=ProjectScanner::scan(ffxRoot);auto ffxComp=CompatibilityAnalyzer::analyze(ffxScan);
    CHECK(ffxComp.commandStatus["damageonlanding"]==CommandStatus::Supported && ffxComp.commandStatus["aimove"]==CommandStatus::Supported && ffxComp.commandStatus["defense"]==CommandStatus::Supported,"v0.34.11 occurrence-aware analyzer closes Final Fight X legacy forms without changing global registry claims");
    fs::path ffxOut="/tmp/obor-v03416-ffx-flip";fs::remove_all(ffxOut);PortGenerator::generate(ffxScan,ffxComp,ffxOut);
    {std::ifstream in(ffxOut/"runtime/src/Renderer.cpp");std::string body((std::istreambuf_iterator<char>(in)),{});CHECK(body.find("transformedOpenBORAnchor")!=std::string::npos&&body.find("if(fx)ax=(double)sw-ax")!=std::string::npos&&body.find("auto anchor=transformedOpenBORAnchor")!=std::string::npos,"v0.34.16 renderer mirrors the sprite pivot around the authored OpenBOR offset");CHECK(body.find("presentD3D11Frame")!=std::string::npos&&body.find("win32-gdi-recovered")!=std::string::npos&&body.find("D3D11 runtime failure; switching permanently")!=std::string::npos,"v0.34.19 D3D11 runtime faults recover to GDI instead of closing the game");}

    fs::path shockRoot="/tmp/obor-v0336-shock";fs::remove_all(shockRoot);fs::create_directories(shockRoot/"data/chars");
    {std::ofstream(shockRoot/"data/models.txt") << "load ShockEnemy data/chars/shock.txt\n";
     std::ofstream(shockRoot/"data/chars/shock.txt") << "name ShockEnemy\ntype enemy\nantigrab 5\nsubject_to_wall 0\nnomove 1 0\nnomove 0 1\nanim attack1\nshock 0 0 16 16 8 0\nframe none\nshock 0 0 16 16 8 1\nframe none\nattack2 0 0 16 16 8 0\nframe none\n";}
    auto shockChars=CharacterParser::parseAll(shockRoot/"data",shockRoot);
    CHECK(shockChars.size()==1 && shockChars[0].grabResistance==5,"v0.33.6 antigrab maps to native grab resistance");
    CHECK(shockChars.size()==1 && !shockChars[0].subjectToWall && CharacterDef{}.subjectToWall,"v0.33.7 wall collision flag respects explicit zero and defaults to enabled");
    CHECK(shockChars.size()==1 && shockChars[0].noMove && shockChars[0].noFlip && !CharacterDef{}.noMove && !CharacterDef{}.noFlip,"v0.33.8 nomove parameters independently set additive movement and facing constraints");
    if(shockChars.size()==1 && !shockChars[0].animations.empty() && shockChars[0].animations[0].frames.size()==3){const auto&frames=shockChars[0].animations[0].frames;
        CHECK(frames[0].attack.type==1004 && !frames[0].knockdown && frames[1].attack.type==1004 && frames[1].knockdown && frames[2].attack.type==2 && !frames[2].knockdown,"v0.33.6 shock and attack2 drop flag are independent of attack type");}
    CHECK(CommandRegistry::lookup("shock").status==CommandStatus::Partial && CommandRegistry::lookup("antigrab").status==CommandStatus::Partial,"v0.33.6 legacy combat directives are classified with their runtime limits");
    auto shockScan=ProjectScanner::scan(shockRoot);auto shockComp=CompatibilityAnalyzer::analyze(shockScan);fs::path shockOut="/tmp/obor-v0336-shock-port";fs::remove_all(shockOut);PortGenerator::generate(shockScan,shockComp,shockOut);
    {std::ifstream in(shockOut/"runtime/src/Engine.cpp");std::string body((std::istreambuf_iterator<char>(in)),{});CHECK(body.find("exactAnimation(c,\"spain\")")!=std::string::npos && body.find("attack.type>=2")==std::string::npos,"v0.33.6 generated runtime uses shock pain and explicit knockdown flag");}
    {std::ifstream in(shockOut/"runtime/src/Engine.cpp");std::string body((std::istreambuf_iterator<char>(in)),{});CHECK(body.find("model->subjectToWall")!=std::string::npos && body.find("applyActorTerrain(cp.model")!=std::string::npos && body.find("applyActorTerrain(e.model")!=std::string::npos && body.find("applyActorTerrain(playerModel_")!=std::string::npos,"v0.33.7 generated runtime gates wall collision for every actor kind");}
    CHECK(CommandRegistry::lookup("subject_to_wall").status==CommandStatus::Partial,"v0.33.7 wall collision is reported with its geometry limits");
    CHECK(CommandRegistry::lookup("nomove").status==CommandStatus::Partial,"v0.33.8 nomove is reported with advanced movement limits");
    {std::ifstream in(shockOut/"runtime/generated/GeneratedCharacters.cpp");std::string body((std::istreambuf_iterator<char>(in)),{});CHECK(body.find("false, true, true, false,")!=std::string::npos,"v0.33.8 generated model retains independent nomove flags");}
    {std::ifstream in(shockOut/"runtime/src/Engine.cpp");std::string body((std::istreambuf_iterator<char>(in)),{});CHECK(body.find("playerModel_->noMove")!=std::string::npos && body.find("cp.model->noMove")!=std::string::npos && body.find("e.model->noMove")!=std::string::npos && body.find("m->noMove")!=std::string::npos && body.find("e.model->noFlip")!=std::string::npos,"v0.33.8 generated runtime uses nomove for player, coop, AI and fall reaction");}

    const auto blocksRoot=fs::path(OBNB_SOURCE_DIR)/"tests/fixtures/runtime_blocks";
    auto blocksChars=CharacterParser::parseAll(blocksRoot/"data",blocksRoot);
    CHECK(blocksChars.size()==3 && blocksChars[0].animations.size()==2 && blocksChars[0].animations[1].inlineScript.find("frame==2")!=std::string::npos,"v0.34.0 preserves model and animation inline bodies");
    CHECK(blocksChars.size()==3 && blocksChars[1].animations[1].landDustModel=="Dust","v0.34.0 landframe preserves named landing effect");
    auto blocksStages=LevelParser::parseAll(blocksRoot/"data",blocksRoot);
    CHECK(!blocksStages.empty() && blocksStages[0].panels.size()==6 && blocksStages[0].panels[3]=="bgs/b.gif","v0.34.0 letter panel order expands and concatenates");
    CHECK(CommandRegistry::lookup("order").status==CommandStatus::Supported && CommandRegistry::lookup("landframe").status==CommandStatus::Supported && CommandRegistry::lookup("@end_script").status==CommandStatus::Supported,"v0.34.0 closed command gaps leave PARTIAL");
    auto blocksScan=ProjectScanner::scan(blocksRoot);auto blocksComp=CompatibilityAnalyzer::analyze(blocksScan);fs::path blocksOut="/tmp/obor-v0340-runtime-port";fs::remove_all(blocksOut);PortGenerator::generate(blocksScan,blocksComp,blocksOut);

    fs::path invalidRoot="/tmp/obor-v0340-invalid";fs::remove_all(invalidRoot);fs::copy(blocksRoot,invalidRoot,fs::copy_options::recursive);
    {std::ofstream(invalidRoot/"data/levels/test.txt",std::ios::app)<<"\norder z\n";std::ofstream(invalidRoot/"data/chars/hero.txt",std::ios::app)<<"\n@script\nbindentity(0, 0, 0, 0, 0, 0, 16);\n@end_script\n";}
    auto invalidScan=ProjectScanner::scan(invalidRoot);auto invalidComp=CompatibilityAnalyzer::analyze(invalidScan);bool invalidOrder=false,inlineApi=false;
    for(const auto&issue:invalidComp.issues){if(issue.command=="order"&&issue.status==CommandStatus::Partial)invalidOrder=true;if(issue.command=="inline-script-api"&&issue.message.find("bindentity")!=std::string::npos)inlineApi=true;}
    CHECK(invalidOrder,"v0.34.0 invalid panel order remains partial");
    CHECK(inlineApi,"v0.34.0 unmapped inline APIs receive explicit partial diagnostics");

    const auto effectsRoot=sourceDir/"tests/fixtures/runtime_effects";
    auto effectsChars=CharacterParser::parseAll(effectsRoot/"data",effectsRoot);
    CHECK(effectsChars.size()==5 && effectsChars[0].animations[1].frames[0].hitFlash=="HitA" && effectsChars[0].animations[1].frames[1].hitFlash=="HitB","v0.34.1 hit flash overrides are preserved per frame");
    CHECK(effectsChars[0].animations[1].frames[0].attack.type==18 && effectsChars[0].animations[1].frames[0].attack.tag==73 && effectsChars[0].animations[1].frames[0].attack.guardCost==4 && effectsChars[0].animations[1].frames[0].attack.penetration==1,"v0.34.1 numeric attack parsing does not swallow dotted attack properties");
    CHECK(effectsChars[0].animations[2].frames[0].hitFlash=="HitB" && effectsChars[0].animations[2].frames[0].blockFlash=="GuardFx" && effectsChars[0].animations[2].frames[0].attack.noFlash==1,"v0.34.1 modern flash aliases are applied");
    CHECK(effectsChars[1].flashModel=="HitA" && effectsChars[1].blockFlashModel=="GuardFx" && effectsChars[3].flipFlash,"v0.34.1 model flash defaults and facing parsed");
    CHECK(CommandRegistry::lookup("attack18").status==CommandStatus::Supported && CommandRegistry::lookup("attackone").status==CommandStatus::Supported && CommandRegistry::lookup("attackgarbage").status==CommandStatus::Unknown,"v0.34.36 attackone runtime parity is fully certified while typed attack boxes remain distinct");
    auto effectsScan=ProjectScanner::scan(effectsRoot);auto effectsComp=CompatibilityAnalyzer::analyze(effectsScan);fs::path effectsOut="/tmp/obor-v0341-effects-port";fs::remove_all(effectsOut);PortGenerator::generate(effectsScan,effectsComp,effectsOut);

    auto energyRoot=sourceDir/"tests/fixtures/runtime_energy";auto energyChars=CharacterParser::parseAll(energyRoot/"data",energyRoot);
    CHECK(energyChars[0].animations[1].energyCost==5 && energyChars[0].animations[2].energyMode==1 && energyChars[0].animations[3].energyCost==7 && energyChars[0].animations[3].energyMode==2 && energyChars[0].animations[4].energyDisable==-1,"v0.34.2 energycost aliases, modes and disable parsed");
    auto energyScan=ProjectScanner::scan(energyRoot);auto energyComp=CompatibilityAnalyzer::analyze(energyScan);fs::path energyOut="/tmp/obor-v0342-energy-port";fs::remove_all(energyOut);PortGenerator::generate(energyScan,energyComp,energyOut);
    CHECK(CommandRegistry::lookup("energycost").runtime && CommandRegistry::lookup("nocost").status==CommandStatus::Partial,"v0.34.2 energy execution and deferred-cost limits reported");

    fs::path energyGlobal="/tmp/obor-v0342-global";fs::remove_all(energyGlobal);fs::copy(energyRoot,energyGlobal,fs::copy_options::recursive);std::ofstream(energyGlobal/"data/models.txt",std::ios::app)<<"nocost 1\n";fs::create_directories(energyGlobal/"data/scripts");std::ofstream(energyGlobal/"data/scripts/toss.c")<<"void main(){tossentity(getlocalvar(\"self\"),3,2,1);}";
    auto energyGlobalChars=CharacterParser::parseAll(energyGlobal/"data",energyGlobal);CHECK(energyGlobalChars[0].globalNoCost,"v0.34.2 global nocost is propagated to models");auto globalComp=CompatibilityAnalyzer::analyze(ProjectScanner::scan(energyGlobal));bool tossWarning=false;for(const auto&issue:globalComp.issues)if(issue.message.find("api/function:tossentity")!=std::string::npos)tossWarning=true;CHECK(!tossWarning,"v0.34.2 implemented toss API is no longer reported as unmapped");

    auto commandRoot=sourceDir/"tests/fixtures/runtime_commands";
    auto commandChars=CharacterParser::parseAll(commandRoot/"data",commandRoot);
    const auto& generatedCmd=commandChars[0].animations[0].frames[0].animationCommand;
    CHECK(generatedCmd.find("collect(\"power # one\",getlocalvar( \"self\" ));")!=std::string::npos,"v0.34.3 cmd preserves quoted spaces, # and nested expressions");
    auto commandScan=ProjectScanner::scan(commandRoot);auto commandComp=CompatibilityAnalyzer::analyze(commandScan);
    CHECK(!commandComp.animationCommands.empty()&&commandComp.animationCommands[0].function=="collect"&&commandComp.animationCommands[0].helper=="DATA/SCRIPTS/helper.C","v0.34.3 cmd diagnostics resolve case-insensitive helper and identify function");
    fs::path commandOut="/tmp/obor-v0343-command-port";fs::remove_all(commandOut);PortGenerator::generate(commandScan,commandComp,commandOut);
    CompatibilityAnalyzer::writeReport(commandScan,commandComp,commandOut/"reports");
    CHECK(fs::exists(commandOut/"reports/animation-command-audit.txt"),"v0.34.3 conversion emits per-call cmd audit");
    fs::path commandAuditRoot="/tmp/obor-v0343-audit";fs::remove_all(commandAuditRoot);fs::create_directories(commandAuditRoot/"data/chars");
    std::ofstream(commandAuditRoot/"data/models.txt")<<"load Hero data/chars/hero.txt\n";
    std::ofstream(commandAuditRoot/"data/chars/hero.txt")<<"name Hero\ntype player\nanim idle\n@cmd setglobalvar \"one\" 2\n@cmd unknown_helper 4\nframe data/chars/a.gif\n@cmd setglobalvar \"one\"\nframe data/chars/a.gif\n@cmd setglobalvar \"orphan\" 1\n";
    auto audited=CompatibilityAnalyzer::analyze(ProjectScanner::scan(commandAuditRoot));
    CHECK(audited.animationCommands.size()==4&&audited.animationCommands[0].status==CommandStatus::Supported&&audited.animationCommands[1].status==CommandStatus::Partial,"v0.34.3 verifies core cmd while retaining unresolved helper");
    CHECK(audited.animationCommands[2].status==CommandStatus::Partial&&audited.animationCommands[3].detail.find("no following")!=std::string::npos,"v0.34.3 malformed argument count and orphan cmd are not certified");
    CHECK(audited.commandStatus.at("@cmd")==CommandStatus::Partial&&audited.commandStatusCounts.at("@cmd").at(CommandStatus::Supported)==1,"v0.34.3 mixed cmd summary preserves unresolved calls and exact counts");
    std::ofstream(commandAuditRoot/"data/chars/hero.txt")<<"name Hero\ntype player\nanim idle\n@cmd setglobalvar \"bad\" NULL(1)\nframe none\n";
    auto badNested=CompatibilityAnalyzer::analyze(ProjectScanner::scan(commandAuditRoot));CHECK(badNested.animationCommands[0].status==CommandStatus::Partial,"v0.34.3 malformed nested cmd API arguments remain partial");

    fs::path helperAuditRoot="/tmp/obor-v03410-helper-audit";fs::remove_all(helperAuditRoot);fs::create_directories(helperAuditRoot/"data/chars");fs::create_directories(helperAuditRoot/"data/scripts");
    std::ofstream(helperAuditRoot/"data/models.txt")<<"load Hero data/chars/hero.txt\n";
    std::ofstream(helperAuditRoot/"data/scripts/helper.c")<<"void stamp(int x){ setlocalvar(\"stamp\",x); }\n";
    std::ofstream(helperAuditRoot/"data/chars/hero.txt")<<"name Hero\ntype player\nanimationscript data/old/location/helper.c\nanim idle\n@cmd stamp 7\nframe none\n";
    auto helperAudited=CompatibilityAnalyzer::analyze(ProjectScanner::scan(helperAuditRoot));
    CHECK(helperAudited.animationCommands.size()==1&&helperAudited.animationCommands[0].status==CommandStatus::Supported,"v0.34.10 supported custom @cmd helper is certified and unique-basename relocation is resolved");
    fs::path includeHelperRoot="/tmp/obor-v03421-helper-include";fs::remove_all(includeHelperRoot);fs::create_directories(includeHelperRoot/"data/chars");fs::create_directories(includeHelperRoot/"data/scripts/library");
    std::ofstream(includeHelperRoot/"data/models.txt")<<"load Hero data/chars/hero.txt\n";
    std::ofstream(includeHelperRoot/"data/scripts/library/move.h")<<"void dashstep(int x){ setlocalvar(\"dx\",x); }\n";
    std::ofstream(includeHelperRoot/"data/scripts/helper.c")<<"#include \"data/scripts/library/move.h\"\nvoid main(){}\n";
    std::ofstream(includeHelperRoot/"data/chars/hero.txt")<<"name Hero\ntype player\nanimationscript data/scripts/helper.c\nanim idle\n@cmd dashstep 4\nframe none\n";
    auto includeHelperAudit=CompatibilityAnalyzer::analyze(ProjectScanner::scan(includeHelperRoot));
    CHECK(includeHelperAudit.animationCommands.size()==1&&includeHelperAudit.animationCommands[0].status==CommandStatus::Supported,"v0.34.22 @cmd helper arity resolves functions defined through nested includes");
    CHECK(CommandRegistry::lookup("disablehof").status==CommandStatus::IgnoredSafely&&CommandRegistry::lookup("disablegameover").status==CommandStatus::Partial&&CommandRegistry::lookup("alwaysupdate").status==CommandStatus::Partial,"v0.34.22 legacy frontend/script policy commands are classified instead of UNKNOWN");

    fs::path commentScriptRoot="/tmp/obor-v03421-comment-script";fs::remove_all(commentScriptRoot);fs::create_directories(commentScriptRoot/"data/scripts");
    std::ofstream(commentScriptRoot/"data/models.txt")<<"";
    std::ofstream(commentScriptRoot/"data/scripts/comments.c")<<"void main(){ setlocalvar(\"text\",\"fakecall() spawnB()\"); /* distance(1,2); */ // spawn01(3)\n setlocalvar(\"ok\",1); }\n";
    auto commentScriptComp=CompatibilityAnalyzer::analyze(ProjectScanner::scan(commentScriptRoot));bool commentFalseWarning=false;for(const auto&i:commentScriptComp.issues)if(i.command=="script-file")commentFalseWarning=true;
    CHECK(!commentFalseWarning,"v0.34.22 script compatibility ignores function-like text inside comments and string literals");

    fs::path movementFile="/tmp/obor-v03421-movement.txt";
    std::ofstream(movementFile)<<"name Runner\ntype player\nspeed 18\nrunning 21 4 2 1 1\njumpspeed 20\nwalkoffmove 2 1\nanim idle\nframe none\n";
    auto legacyMove=CharacterParser::parse(movementFile,movementFile.parent_path());
    CHECK(std::fabs(legacyMove.speed-1.8f)<0.001f&&std::fabs(legacyMove.runSpeed-2.1f)<0.001f&&std::fabs(legacyMove.jumpSpeed-2.0f)<0.001f,"v0.34.22 legacy integer speed/running/jumpspeed use OpenBOR tenths");
    CHECK(legacyMove.walkoffMoveX==2&&legacyMove.walkoffMoveZ==1,"v0.34.22 walkoffmove metadata is preserved");
    std::ofstream(movementFile)<<"name Runner\ntype player\nspeed 2.5\nspeedf 1.75\njumpspeedf 2.25\nanim idle\nframe none\n";
    auto floatMove=CharacterParser::parse(movementFile,movementFile.parent_path());
    CHECK(std::fabs(floatMove.speed-1.75f)<0.001f&&std::fabs(floatMove.jumpSpeed-2.25f)<0.001f,"v0.34.22 explicit decimal/speedf/jumpspeedf values remain direct floats");
    CHECK(CommandRegistry::lookup("jumpspeed").status==CommandStatus::Supported&&CommandRegistry::lookup("walkoffmove").status==CommandStatus::Supported,"v0.34.22 jumpspeed and walkoffmove have native runtime behavior");

    fs::path bindingAuditRoot="/tmp/obor-v0346-binding-audit";fs::remove_all(bindingAuditRoot);fs::create_directories(bindingAuditRoot/"data/scripts");
    std::ofstream(bindingAuditRoot/"data/models.txt")<<"";
    auto bindingIssue=[&](const std::string& body){std::ofstream(bindingAuditRoot/"data/scripts/bind.c")<<body;auto report=CompatibilityAnalyzer::analyze(ProjectScanner::scan(bindingAuditRoot));return std::any_of(report.issues.begin(),report.issues.end(),[](const auto&i){return i.command=="script-file";});};
    CHECK(!bindingIssue("void main(){bindentity(getlocalvar(\"self\"),NULL());}"),"v0.34.6 basic unbind is mapped in script analysis");
    CHECK(!bindingIssue("void main(){bindentity(getlocalvar(\"self\"),getlocalvar(\"other\"),1,2,3,1,4);}"),"v0.34.6 literal supported binding flags are mapped");
    CHECK(bindingIssue("void main(){bindentity(getlocalvar(\"self\"),getlocalvar(\"other\"),1,2,3,1,16);}"),"v0.34.6 defined animation binding remains partial");
    CHECK(bindingIssue("void main(){bindentity(getlocalvar(\"self\"),getlocalvar(\"other\"),1,2,3,1,getglobalvar(\"flags\"));}"),"v0.34.6 dynamic binding config remains partial");
    fs::path legacyGrabFile="/tmp/obor-v0347-grab.txt";
    auto parseLegacyGrab=[&](const std::string& commands){std::ofstream(legacyGrabFile)<<"name GrabTest\ntype enemy\n"<<commands<<"\nanim idle\nframe none\n";return CharacterParser::parse(legacyGrabFile,legacyGrabFile.parent_path());};
    auto grabOne=parseLegacyGrab("cantgrab 1");CHECK(!grabOne.noGrab&&grabOne.grabResistance==1&&grabOne.grabForce==0,"v0.34.7 cantgrab 1 sets resistance without absolute immunity");
    auto grabTwo=parseLegacyGrab("cantgrab 2");CHECK(!grabTwo.noGrab&&grabTwo.grabForce==-999999&&grabTwo.grabResistance==0,"v0.34.7 cantgrab 2 reduces attacker force without defending immunity");
    CHECK(parseLegacyGrab("cantgrab 0").grabResistance==1,"v0.34.7 cantgrab 0 follows supplied v7533 legacy branch");
    CHECK(parseLegacyGrab("notgrab 2").grabForce==-999999,"v0.34.7 notgrab alias follows cantgrab mapping");
    auto grabOrder=parseLegacyGrab("cantgrab 2\ngrabforce 5\ncantgrab 1\nantigrab 7");CHECK(grabOrder.grabForce==5&&grabOrder.grabResistance==7,"v0.34.7 grab tuning respects later directives");
    CHECK(parseLegacyGrab("antigrab 7\ncantgrab 1").grabResistance==1,"v0.34.7 cantgrab overwrites earlier resistance");
    CHECK(CommandRegistry::lookup("cantgrab").status==CommandStatus::Supported&&CommandRegistry::lookup("notgrab").status==CommandStatus::Supported,"v0.34.7 verified legacy grab commands are supported");
    auto terrainRoot=sourceDir/"tests/fixtures/runtime_terrain";auto terrainScan=ProjectScanner::scan(terrainRoot);auto terrainStages=LevelParser::parseAll(terrainRoot/"data",terrainRoot);
    CHECK(terrainStages[0].geometry[0].openborShape&&std::fabs(terrainStages[0].geometry[0].shape[0]-100.25f)<0.001f&&terrainStages[0].geometry[0].shape[6]==40,"v0.34.4 terrain preserves float origins and four corners/depth");
    auto terrainComp=CompatibilityAnalyzer::analyze(terrainScan);bool terrainWarning=false;for(const auto&issue:terrainComp.issues)if(issue.command=="script-file"&&issue.message.find("checkhole")!=std::string::npos)terrainWarning=true;
    CHECK(!terrainWarning,"v0.34.4 implemented terrain queries are no longer unmapped script APIs");
    fs::path terrainOut="/tmp/obor-v0344-terrain-port";fs::remove_all(terrainOut);PortGenerator::generate(terrainScan,terrainComp,terrainOut);

    fs::path v3424Root="/tmp/obor-v03424-visual-combat";fs::remove_all(v3424Root);fs::create_directories(v3424Root/"data/chars");fs::create_directories(v3424Root/"data/levels");
    std::ofstream(v3424Root/"data/models.txt")<<"load Hero data/chars/hero.txt\nload Boss data/chars/boss.txt\n";
    std::ofstream(v3424Root/"data/levels.txt")<<"set Test\nfile data/levels/a.txt\n";
    std::ofstream(v3424Root/"data/levels/a.txt")<<"spawn Boss\ncoords 100 200 0\nat 0\n";
    std::ofstream(v3424Root/"data/chars/hero.txt")<<"name Hero\ntype player\nanim idle\nframe none\n";
    std::ofstream(v3424Root/"data/chars/boss.txt")<<"name Boss\ntype enemy\ngfxshadow 1 3\nfalldie 2\nfmap 1\nlifebarstatus 300 10 0 1 0 2 2 2 0\natchain 1 4 0 2 2 3 0\ncombostyle 1\nanim idle\ndrawmethod 512 512 0 0 0 0 -1 0 0 0\nframe none\nanim fall\nframe none\nanim death\nframe none\n";
    auto v3424Scan=ProjectScanner::scan(v3424Root);auto v3424Comp=CompatibilityAnalyzer::analyze(v3424Scan);auto v3424Chars=CharacterParser::parseAll(v3424Scan.dataDir,v3424Scan.root);
    const CharacterDef* boss3424=nullptr;for(const auto&c:v3424Chars)if(c.modelName=="Boss")boss3424=&c;
    CHECK(boss3424&&boss3424->gfxShadow==1&&boss3424->gfxShadowBase==3&&boss3424->fallDie==2&&boss3424->freezeMap==1,"v0.34.24 gfxshadow base/falldie/fmap metadata parsed");
    CHECK(v3424Comp.commandStatus.at("gfxshadow")==CommandStatus::Supported&&v3424Comp.commandStatus.at("falldie")==CommandStatus::Supported&&v3424Comp.commandStatus.at("fmap")==CommandStatus::Supported,"v0.34.24 shadow/death/freeze-map occurrences are runtime-backed");
    CHECK(v3424Comp.commandStatus.at("drawmethod")==CommandStatus::Supported&&v3424Comp.commandStatus.at("atchain")==CommandStatus::Supported&&v3424Comp.commandStatus.at("lifebarstatus")==CommandStatus::Supported,"v0.34.24 positional drawmethod/branch atchain/lifebar layers are certified");
    fs::path v3424Out="/tmp/obor-v03424-port";fs::remove_all(v3424Out);PortGenerator::generate(v3424Scan,v3424Comp,v3424Out);{std::ifstream in(v3424Out/"runtime/src/Engine.cpp");std::string body((std::istreambuf_iterator<char>(in)),{});CHECK(body.find("deathFollowDeath")!=std::string::npos&&body.find("preFreezePaletteMap")!=std::string::npos&&body.find("gfxShadowBase")!=std::string::npos,"v0.34.24 runtime emits chained death, freeze-map restoration and shadowbase behavior");}


    fs::path v3425Root="/tmp/obor-v03425-water";fs::remove_all(v3425Root);fs::create_directories(v3425Root/"data/chars");fs::create_directories(v3425Root/"data/levels");
    std::ofstream(v3425Root/"data/models.txt")<<"load Hero data/chars/hero.txt\n";
    std::ofstream(v3425Root/"data/levels.txt")<<"set Water\nfile data/levels/a.txt\n";
    std::ofstream(v3425Root/"data/levels/a.txt")<<"z 160 232 160\nwater data/sprites/water.gif 15\nrock 3\n";
    std::ofstream(v3425Root/"data/chars/hero.txt")<<"name Hero\ntype player\nanim idle\nframe none\n";
    auto v3425Scan=ProjectScanner::scan(v3425Root);auto v3425Comp=CompatibilityAnalyzer::analyze(v3425Scan);
    CHECK(v3425Comp.commandStatus.at("water")==CommandStatus::Supported&&v3425Comp.commandStatus.at("rock")==CommandStatus::Supported,"v0.34.25 legacy water warp and rock 0-3 are certified runtime-backed");
    fs::path v3425Out="/tmp/obor-v03425-port";fs::remove_all(v3425Out);PortGenerator::generate(v3425Scan,v3425Comp,v3425Out);{std::ifstream in(v3425Out/"runtime/src/Engine.cpp");std::string body((std::istreambuf_iterator<char>(in)),{});CHECK(body.find("legacyWaterSurface")!=std::string::npos&&body.find("independently for each scanline")!=std::string::npos&&body.find("scale=0.76+0.42*t")!=std::string::npos,"v0.34.25 generated runtime contains sine-scanline and perspective water transforms");}

    fs::path includeRecoverRoot="/tmp/obor-v03425-include-recover";fs::remove_all(includeRecoverRoot);fs::create_directories(includeRecoverRoot/"data/scripts/moved");
    std::ofstream(includeRecoverRoot/"data/models.txt")<<"";
    std::ofstream(includeRecoverRoot/"data/scripts/moved/move.h")<<"void rescued(int x){setlocalvar(\"r\",x);}\n";
    std::ofstream(includeRecoverRoot/"data/scripts/test.c")<<"#include \"data/scripts/old/move.h\"\nvoid main(){rescued(3);}\n";
    auto includeRecoverComp=CompatibilityAnalyzer::analyze(ProjectScanner::scan(includeRecoverRoot));bool includeRecoverIssue=false;for(const auto&i:includeRecoverComp.issues)if(i.command=="script-file")includeRecoverIssue=true;
    CHECK(!includeRecoverIssue,"v0.34.25 missing include is recovered by unique relocated basename");

    fs::path includeRedundantRoot="/tmp/obor-v03425-include-redundant";fs::remove_all(includeRedundantRoot);fs::create_directories(includeRedundantRoot/"data/scripts");
    std::ofstream(includeRedundantRoot/"data/models.txt")<<"";
    std::ofstream(includeRedundantRoot/"data/scripts/test.c")<<"#include \"data/scripts/library/obsolete.h\"\nvoid main(){setlocalvar(\"ok\",1);}\n";
    auto includeRedundantComp=CompatibilityAnalyzer::analyze(ProjectScanner::scan(includeRedundantRoot));bool includeRedundantIssue=false;for(const auto&i:includeRedundantComp.issues)if(i.command=="script-file")includeRedundantIssue=true;
    CHECK(!includeRedundantIssue,"v0.34.25 unreferenced missing legacy include no longer makes the whole script PARTIAL");
    std::ofstream(includeRedundantRoot/"data/scripts/test.c")<<"#include \"data/scripts/library/needed.h\"\nvoid main(){missinghelper(1);}\n";
    auto includeBrokenComp=CompatibilityAnalyzer::analyze(ProjectScanner::scan(includeRedundantRoot));bool includeBrokenIssue=false;for(const auto&i:includeBrokenComp.issues)if(i.command=="script-file"&&i.message.find("api/function:missinghelper")!=std::string::npos&&i.message.find("include-missing:data/scripts/library/needed.h")!=std::string::npos)includeBrokenIssue=true;
    CHECK(includeBrokenIssue,"v0.34.25 missing include remains PARTIAL when an unresolved symbol proves it is required");


    // JLU crossfeed: older modules use model-level `layer N` as the legacy
    // spelling of setlayer, and numbered normal defense classes map directly to
    // attack types. Keep layer occurrence-aware so stage-level layer syntax is
    // not accidentally certified as model metadata.
    fs::path jluModelRoot="/tmp/obor-v03441-jlu-model-semantics";fs::remove_all(jluModelRoot);fs::create_directories(jluModelRoot/"data/chars");fs::create_directories(jluModelRoot/"data/levels");
    std::ofstream(jluModelRoot/"data/models.txt")<<"load Hero data/chars/hero.txt\n";
    std::ofstream(jluModelRoot/"data/levels.txt")<<"set Test\nfile data/levels/a.txt\n";
    std::ofstream(jluModelRoot/"data/levels/a.txt")<<"z 160 232 160\n";
    std::ofstream(jluModelRoot/"data/chars/hero.txt")<<"name Hero\ntype player\nlayer 300\ndefense normal2 0.5 0 0 0.2\ndefense normal9 0.2 0 0 0\nanim idle\nframe none\n";
    auto jluModelScan=ProjectScanner::scan(jluModelRoot);auto jluModelChars=CharacterParser::parseAll(jluModelScan.dataDir,jluModelScan.root);auto jluModelComp=CompatibilityAnalyzer::analyze(jluModelScan);
    CHECK(jluModelChars.size()==1&&jluModelChars[0].setLayer==300,"v0.34.41 JLU legacy model layer aliases setlayer without changing stage syntax");
    CHECK(jluModelChars.size()==1&&jluModelChars[0].defenses.size()==2&&jluModelChars[0].defenses[0].type=="normal2"&&jluModelChars[0].defenses[1].type=="normal9","v0.34.41 JLU numbered normal defenses persist as typed native defenses");
    CHECK(jluModelComp.commandStatus["layer"]==CommandStatus::Supported&&jluModelComp.commandStatus["defense"]==CommandStatus::Supported,"v0.34.41 JLU model-layer and normalN defense occurrences are certified runtime-backed");

    fs::path jluKeyRoot="/tmp/obor-v03441-jlu-keyscript";fs::remove_all(jluKeyRoot);fs::create_directories(jluKeyRoot/"data/chars");fs::create_directories(jluKeyRoot/"data/scripts");
    std::ofstream(jluKeyRoot/"data/models.txt")<<"load Hero data/chars/hero.txt\n";
    std::ofstream(jluKeyRoot/"data/chars/hero.txt")<<"name Hero\ntype player\nkeyscript data/scripts/ironkey.c\nanim idle\nframe none\n";
    std::ofstream(jluKeyRoot/"data/scripts/ironkey.c")<<"void main(){int p=getlocalvar(\"player\"); void e=getplayerproperty(p,\"entity\"); int j=playerkeys(p,1,\"jump\"); int r=playerkeys(p,2,\"attack\"); if(j){changeentityproperty(e,\"animation\",openborconstant(\"ANI_JUMP\"),2);} if(r){updateframe(e,1);}}\n";
    auto jluKeyScan=ProjectScanner::scan(jluKeyRoot);auto jluKeyComp=CompatibilityAnalyzer::analyze(jluKeyScan);
    CHECK(jluKeyComp.commandStatus["keyscript"]==CommandStatus::Supported,"v0.34.41 JLU keyscript is certified when its helper is fully ScriptVM-supported");
    fs::path jluShadowRoot="/tmp/obor-v03441-jlu-shadow";fs::remove_all(jluShadowRoot);fs::create_directories(jluShadowRoot/"data/chars");fs::create_directories(jluShadowRoot/"data/levels");
    std::ofstream(jluShadowRoot/"data/models.txt")<<"load Hero data/chars/hero.txt\n";std::ofstream(jluShadowRoot/"data/chars/hero.txt")<<"name Hero\ntype player\ngfxshadow 1\nanim idle\nframe none\n";std::ofstream(jluShadowRoot/"data/levels.txt")<<"set Test\nfile data/levels/a.txt\n";std::ofstream(jluShadowRoot/"data/levels/a.txt")<<"shadowcolor -2\nat 0\nshadowalpha 3\nat 0\n";
    auto jluShadowScan=ProjectScanner::scan(jluShadowRoot);auto jluShadowComp=CompatibilityAnalyzer::analyze(jluShadowScan);CHECK(jluShadowComp.commandStatus["shadowcolor"]==CommandStatus::Supported,"v0.34.41 shadowcolor -2 is certified as no-fill gfxshadow mode");
    fs::path jluShadowOut="/tmp/obor-v03441-jlu-shadow-port";fs::remove_all(jluShadowOut);PortGenerator::generate(jluShadowScan,jluShadowComp,jluShadowOut);{std::ifstream in(jluShadowOut/"runtime/src/Engine.cpp");std::string body((std::istreambuf_iterator<char>(in)),{});CHECK(body.find("shadowColor==-2)shadowFrame.draw.fillColor=0")!=std::string::npos,"v0.34.41 generated renderer preserves -2 no-fill shadow semantics");}
    fs::path jluKeyOut="/tmp/obor-v03441-jlu-keyscript-port";fs::remove_all(jluKeyOut);PortGenerator::generate(jluKeyScan,jluKeyComp,jluKeyOut);{std::ifstream in(jluKeyOut/"runtime/src/Engine.cpp");std::string body((std::istreambuf_iterator<char>(in)),{});CHECK(body.find("playerNewKeys_[0]||playerReleasedKeys_[0]")!=std::string::npos&&body.find("runModelScript(playerModel_->keyScript")!=std::string::npos&&body.find("state==2?playerReleasedKeys_")!=std::string::npos,"v0.34.41 keyscript runs on transitions with same-tick held/new/released playerkeys state");}
    fs::path jluHoleRoot="/tmp/obor-v03441-jlu-hole";fs::remove_all(jluHoleRoot);fs::create_directories(jluHoleRoot/"data/chars");fs::create_directories(jluHoleRoot/"data/levels");
    std::ofstream(jluHoleRoot/"data/models.txt")<<"load Hero data/chars/hero.txt\n";
    std::ofstream(jluHoleRoot/"data/chars/hero.txt")<<"name Hero\ntype player\nsubject_to_hole 1\nno_adjust_base 0\ndefense pit 1 0 0 1\nanim idle\nframe none\nanim fall\nframe none\n";
    std::ofstream(jluHoleRoot/"data/levels.txt")<<"set Test\nfile data/levels/a.txt\n";
    std::ofstream(jluHoleRoot/"data/levels/a.txt")<<"z 160 232 160\nhole 100 220 0 20 80 100 40\n";
    auto jluHoleScan=ProjectScanner::scan(jluHoleRoot);auto jluHoleComp=CompatibilityAnalyzer::analyze(jluHoleScan);
    CHECK(jluHoleComp.commandStatus["hole"]==CommandStatus::Supported&&jluHoleComp.commandStatus["no_adjust_base"]==CommandStatus::Supported,"v0.34.41 native holes and no_adjust_base are fully runtime-backed");
    fs::path jluHoleOut="/tmp/obor-v03441-jlu-hole-port";fs::remove_all(jluHoleOut);PortGenerator::generate(jluHoleScan,jluHoleComp,jluHoleOut);{std::ifstream in(jluHoleOut/"runtime/src/Engine.cpp");std::string body((std::istreambuf_iterator<char>(in)),{});CHECK(body.find("Pit death P1 ATK_PIT")!=std::string::npos&&body.find("AI_IGNOREHOLES=0x00010000")!=std::string::npos&&body.find("model&&model->noAdjustBase")!=std::string::npos&&body.find("if(k==\"atk_pit\")return 1006.0")!=std::string::npos,"v0.34.41 generated runtime implements pit fall/death, AI avoidance, no_adjust_base and ATK_PIT constant");}

    fs::path jluBasemapRoot="/tmp/obor-v03441-jlu-basemap";fs::remove_all(jluBasemapRoot);fs::create_directories(jluBasemapRoot/"data/chars");fs::create_directories(jluBasemapRoot/"data/levels");
    std::ofstream(jluBasemapRoot/"data/models.txt")<<"load RampHero data/chars/hero.txt\n";
    std::ofstream(jluBasemapRoot/"data/chars/hero.txt")<<"name RampHero\ntype player\nsubject_to_basemap 1\nanim idle\nframe none\n";
    std::ofstream(jluBasemapRoot/"data/levels.txt")<<"set Test\nfile data/levels/ramp.txt\n";
    std::ofstream(jluBasemapRoot/"data/levels/ramp.txt")<<"z 160 232 160\nbasemap 10 160 100 60 -20 40\n";
    auto jluBasemapScan=ProjectScanner::scan(jluBasemapRoot);auto jluBasemapChars=CharacterParser::parseAll(jluBasemapScan.dataDir,jluBasemapScan.root);auto jluBasemapStages=LevelParser::parseAll(jluBasemapScan.dataDir,jluBasemapScan.root);auto jluBasemapComp=CompatibilityAnalyzer::analyze(jluBasemapScan);
    CHECK(jluBasemapChars.size()==1&&jluBasemapChars[0].subjectToBasemap,"v0.34.41 subject_to_basemap is preserved on generated model metadata");
    CHECK(jluBasemapStages.size()==1&&jluBasemapStages[0].geometry.size()==1&&jluBasemapStages[0].geometry[0].kind=="basemap"&&jluBasemapStages[0].geometry[0].x==10&&jluBasemapStages[0].geometry[0].z==160&&jluBasemapStages[0].geometry[0].w==100&&jluBasemapStages[0].geometry[0].h==60&&jluBasemapStages[0].geometry[0].depth==-20&&jluBasemapStages[0].geometry[0].altitude==40,"v0.34.41 basemap x/z/size/min/max ramp metadata parses without loss");
    CHECK(jluBasemapComp.commandStatus["subject_to_basemap"]==CommandStatus::Supported&&jluBasemapComp.commandStatus["basemap"]==CommandStatus::Supported,"v0.34.41 basemap participation and static ramp are certified runtime-backed");
    fs::path jluBasemapOut="/tmp/obor-v03441-jlu-basemap-port";fs::remove_all(jluBasemapOut);PortGenerator::generate(jluBasemapScan,jluBasemapComp,jluBasemapOut);{std::ifstream in(jluBasemapOut/"runtime/src/Engine.cpp");std::string body((std::istreambuf_iterator<char>(in)),{});CHECK(body.find("subject->subjectToBasemap")!=std::string::npos&&body.find("ground=(float)g.depth+((float)g.altitude-(float)g.depth)*t")!=std::string::npos&&body.find("subject->subjectToPlatform")!=std::string::npos,"v0.34.41 generated terrain query combines static basemap slopes with independent dynamic-platform participation");}

    const auto legacyUnknownRoot=sourceDir/"tests/fixtures/runtime_legacy_unknowns";
    auto legacyUnknownChars=CharacterParser::parseAll(legacyUnknownRoot/"data",legacyUnknownRoot);
    const CharacterDef* legacyHero=nullptr;for(const auto&c:legacyUnknownChars)if(c.name=="Hero")legacyHero=&c;
    CHECK(legacyHero&&legacyHero->mpRate==3&&legacyHero->playerArrow=="sprites/p1.gif"&&legacyHero->playerArrowX==2&&legacyHero->playerArrowY==3,"v0.34.34 mprate and parrow are parsed into native model metadata");
    CHECK(legacyHero&&legacyHero->playerArrow2=="sprites/p2.gif"&&legacyHero->playerArrow2X==4&&legacyHero->playerArrow2Y==5,"v0.34.34 parrow2 keeps player-specific sprite and offsets");
    if(legacyHero){const AnimationDef*idle=nullptr,*attack=nullptr;for(const auto&a:legacyHero->animations){if(a.name=="idle")idle=&a;if(a.name=="attack1")attack=&a;}
      CHECK(idle&&!idle->frames.empty()&&idle->frames[0].idleInterrupt&&idle->frames[0].frameShadow==3,"v0.34.34 idle and fshadow persist on the authored frame");
      CHECK(attack&&attack->hasDive&&std::fabs(attack->diveVelocityX-1.5f)<0.001f&&std::fabs(attack->diveVelocityY-2.5f)<0.001f,"v0.34.34 dive velocities persist on the animation");
      CHECK(attack&&!attack->frames.empty()&&attack->frames[0].hasAttack&&attack->frames[0].attack.type==1003&&attack->frames[0].attack.freezeTime==17&&attack->frames[0].attack.noFlash==1&&attack->frames[0].attack.pauseTime==3&&attack->frames[0].attack.zDepth==6,"v0.34.34 freeze preserves attack type, duration, flash, pause and z arguments");
      const AnimationDef* stunAttack=nullptr;for(const auto&a:legacyHero->animations)if(a.name=="attack2")stunAttack=&a;
      CHECK(stunAttack&&!stunAttack->frames.empty()&&stunAttack->frames[0].hasAttack&&stunAttack->frames[0].attack.type==1&&stunAttack->frames[0].attack.freezeTime==11,"v0.34.35 stun modifies an existing normal attack without converting it to freeze damage");}
    auto legacyUnknownStages=LevelParser::parseAll(legacyUnknownRoot/"data",legacyUnknownRoot);
    CHECK(!legacyUnknownStages.empty()&&legacyUnknownStages[0].typeMp==1&&legacyUnknownStages[0].allowSelect.size()==1&&legacyUnknownStages[0].allowSelect[0]=="Hero","v0.34.34 typemp and allowselect reach native stage metadata");
    CHECK(!legacyUnknownStages.empty()&&std::fabs(legacyUnknownStages[0].gravity+5.0f)<0.001f&&std::fabs(legacyUnknownStages[0].maxFallSpeed+20.0f)<0.001f&&std::fabs(legacyUnknownStages[0].maxTossSpeed-40.0f)<0.001f,"v0.34.35 level gravity and fall/toss caps are parsed");
    for(const auto*cmd:{"parrow","parrow2","mprate","idle","fshadow","dive","freeze","allowselect","typemp"})CHECK(CommandRegistry::lookup(cmd).status==CommandStatus::Supported,"v0.34.34 high-frequency JLU legacy directive is centrally supported");
    for(const auto*cmd:{"gravity","maxfallspeed","maxtossspeed","stun","agression"})CHECK(CommandRegistry::lookup(cmd).status==CommandStatus::Supported,"v0.34.35 legacy physics/stun directive is centrally supported");
    CHECK(CommandRegistry::lookup("subject_to_basemap").status==CommandStatus::Supported&&CommandRegistry::lookup("basemap").status==CommandStatus::Supported,"v0.34.41 basemap model/stage directives are runtime-backed rather than compatibility placeholders");
    auto legacyUnknownScan=ProjectScanner::scan(legacyUnknownRoot);auto legacyUnknownComp=CompatibilityAnalyzer::analyze(legacyUnknownScan);
    CHECK(legacyUnknownComp.unknownCommands==0,"v0.34.34 targeted legacy fixture produces zero UNKNOWN commands");
    CHECK(legacyUnknownComp.commandUsage.count("projectilename")==0&&legacyUnknownComp.commandUsage.count("vx")==0&&legacyUnknownComp.commandUsage.count("x")==0,"v0.34.35 script-owned text tables no longer pollute command UNKNOWN counts");
    CHECK(legacyUnknownComp.commandStatus["parrow"]==CommandStatus::Supported&&legacyUnknownComp.commandStatus["parrow2"]==CommandStatus::Supported&&legacyUnknownComp.commandStatus["mprate"]==CommandStatus::Supported&&legacyUnknownComp.commandStatus["idle"]==CommandStatus::Supported&&legacyUnknownComp.commandStatus["fshadow"]==CommandStatus::Supported&&legacyUnknownComp.commandStatus["dive"]==CommandStatus::Supported&&legacyUnknownComp.commandStatus["freeze"]==CommandStatus::Supported&&legacyUnknownComp.commandStatus["allowselect"]==CommandStatus::Supported,"v0.34.34 analyzer reports implemented JLU compatibility cluster as supported");
    fs::path legacyUnknownOut="/tmp/obor-v03434-legacy-unknowns";fs::remove_all(legacyUnknownOut);PortGenerator::generate(legacyUnknownScan,legacyUnknownComp,legacyUnknownOut);
    {std::ifstream in(legacyUnknownOut/"runtime/src/Engine.cpp");std::string body((std::istreambuf_iterator<char>(in)),{});CHECK(body.find("selectablePlayers() const")!=std::string::npos&&body.find("queueRespawnArrow")!=std::string::npos&&body.find("stage_->typeMp==1")!=std::string::npos&&body.find("attackType==1003")!=std::string::npos,"v0.34.34 generated runtime contains allowselect, parrow, mprate and freeze execution paths");}
    {std::ifstream in(legacyUnknownOut/"runtime/generated/GeneratedCharacters.cpp");std::string body((std::istreambuf_iterator<char>(in)),{});CHECK(body.find("sprites/p1.gif")!=std::string::npos&&body.find("sprites/p2.gif")!=std::string::npos,"v0.34.34 generated character tables retain parrow assets");}

    fs::path hdPreserveRoot="/tmp/obor-v03436-hd-preserve";fs::remove_all(hdPreserveRoot);fs::create_directories(hdPreserveRoot/"data/chars");fs::create_directories(hdPreserveRoot/"data_hd/sprites");
    std::ofstream(hdPreserveRoot/"data/models.txt")<<"load Hero data/chars/hero.txt\n";
    std::ofstream(hdPreserveRoot/"data/chars/hero.txt")<<"name Hero\ntype player\nanim idle\nframe none\n";
    std::ofstream(hdPreserveRoot/"data_hd/sprites/hero.png")<<"HD";
    auto hdPreserveScan=ProjectScanner::scan(hdPreserveRoot);auto hdPreserveComp=CompatibilityAnalyzer::analyze(hdPreserveScan);fs::path hdPreserveOut="/tmp/obor-v03436-hd-preserve-port";fs::remove_all(hdPreserveOut);PortGenerator::generate(hdPreserveScan,hdPreserveComp,hdPreserveOut);
    CHECK(fs::exists(hdPreserveOut/"assets/openbor-data-hd/sprites/hero.png"),"v0.34.36 optional data_hd tree is preserved in generated ports");
    {std::ifstream in(hdPreserveOut/"reports/frontend-flow.txt");std::string body((std::istreambuf_iterator<char>(in)),{});CHECK(body.find("OpenBOR Native Builder v0.34.47")!=std::string::npos&&body.find("campaign_select_entries=")!=std::string::npos&&body.find("startup_order=logo -> logo scene -> intro -> title/press start -> titleb main menu")!=std::string::npos&&body.find("main_menu=Start Game -> Options -> How To Play -> Hall Of Fame -> Quit")!=std::string::npos&&body.find("start_game_menu=Choose Mode -> New Game / Load Game / Back")!=std::string::npos,"v0.34.47 emits legacy frontend/campaign flow audit");}
    {std::ifstream in(hdPreserveOut/"reports/hd-override-assets.txt");std::string body((std::istreambuf_iterator<char>(in)),{});CHECK(body.find("PRESERVED")!=std::string::npos&&body.find("Runtime activation: ENABLED")!=std::string::npos,"v0.34.37 HD preservation report confirms scale-aware runtime activation");}
    {std::ifstream in(hdPreserveOut/"runtime/src/Renderer.cpp");std::string body((std::istreambuf_iterator<char>(in)),{});CHECK(body.find("findHdOverride")!=std::string::npos&&body.find("validHdScale")!=std::string::npos&&body.find("renderScaleFactor")!=std::string::npos,"v0.34.37 generated renderer resolves validated HD overrides on a supersampled surface");CHECK(body.find("spriteLogicalWidth")!=std::string::npos&&body.find("logicalWidth=base.width")!=std::string::npos,"v0.34.37 HD sprites retain original logical dimensions for offsets/hitbox-safe rendering");}
    {std::ifstream in(hdPreserveOut/"runtime/src/Engine.cpp");std::string body((std::istreambuf_iterator<char>(in)),{});CHECK(body.find("engineSpriteLogicalWidth")!=std::string::npos&&body.find("panelX+=engineSpriteLogicalWidth(p)")!=std::string::npos&&body.find("getgfxproperty")!=std::string::npos,"v0.34.37 HD physical dimensions never leak into stage layout or script-visible sprite geometry");}
    {std::ifstream in(hdPreserveOut/"runtime/src/Renderer.cpp");std::string body((std::istreambuf_iterator<char>(in)),{});CHECK(body.find("setBitmapFontRoot")!=std::string::npos&&body.find("sliceFontGlyph")!=std::string::npos&&body.find("fontmonospace")!=std::string::npos&&body.find("glyphs[(std::size_t)ch].advance")!=std::string::npos&&body.find("ofont.gif")==std::string::npos&&body.find("drawOpenBorText")!=std::string::npos,"v0.34.47 generated renderer uses clipped variable-width OpenBOR bitmap glyphs and fontmonospace without fake ofont selection");CHECK(body.find("#include <fstream>")!=std::string::npos,"v0.34.47 Windows fontmonospace parser includes fstream and remains cross-compiler safe");}
    {std::ifstream in(hdPreserveOut/"runtime/src/main.cpp");std::string body((std::istreambuf_iterator<char>(in)),{});CHECK(body.find("--profile-game")!=std::string::npos&&body.find("--profile-frames=")!=std::string::npos&&body.find("runPerformanceGame")!=std::string::npos,"v0.34.46 generated runtime exposes deterministic Windows performance profiling mode");}
    {std::ifstream in(hdPreserveOut/"runtime/src/Engine.cpp");std::string body((std::istreambuf_iterator<char>(in)),{});CHECK(body.find("performance-windows.txt")!=std::string::npos&&body.find("renderer_render_ms_per_frame")!=std::string::npos&&body.find("bitmap_fonts")!=std::string::npos,"v0.34.46 performance report records FPS, render/present timing and bitmap-font activation");}
    {std::ifstream in(hdPreserveOut/"config/graphics.ini");std::string body((std::istreambuf_iterator<char>(in)),{});CHECK(body.find("use_hd_assets=true")!=std::string::npos&&body.find("hd_render_scale=4")!=std::string::npos&&body.find("hd_strict_scale=true")!=std::string::npos,"v0.34.37 generated config enables strict 4x HD renderer mode");}

    {std::ifstream in(hdPreserveOut/"runtime/src/Renderer.cpp");std::string body((std::istreambuf_iterator<char>(in)),{});CHECK(body.find("renderGpuCommands")!=std::string::npos&&body.find("gpuTextureFor")!=std::string::npos&&body.find("D3D11_USAGE_IMMUTABLE")!=std::string::npos&&body.find("d3d11-gpu-batched")!=std::string::npos,"v0.34.39 renderer emits persistent D3D11 sprite textures and GPU command batching");CHECK(body.find("c.mode>2")!=std::string::npos&&body.find("renderCpuCommands")!=std::string::npos,"v0.34.39 preserves exact legacy blend fallback for unsupported GPU blend modes");}
    {std::ifstream in(hdPreserveOut/"config/graphics.ini");std::string body((std::istreambuf_iterator<char>(in)),{});CHECK(body.find("gpu_sprite_batching=true")!=std::string::npos&&body.find("gpu_texture_cache_mb=512")!=std::string::npos,"v0.34.39 generated config exposes GPU batching and persistent texture-cache budget");}
    {std::ifstream in(hdPreserveOut/"runtime/src/Renderer.cpp");std::string body((std::istreambuf_iterator<char>(in)),{});CHECK(body.find("Texture2DArray Sprite")!=std::string::npos&&body.find("DrawInstanced")!=std::string::npos&&body.find("SpriteInstance")!=std::string::npos,"v0.34.40 renderer moves frame transforms into instanced D3D11 shaders");CHECK(body.find("uploadAtlasGpuTexture")!=std::string::npos&&body.find("D3D11_SRV_DIMENSION_TEXTURE2DARRAY")!=std::string::npos&&body.find("gpuAtlasGroups_")!=std::string::npos,"v0.34.40 renderer packs differently-sized sprites into Texture2DArray atlas groups");CHECK(body.find("cmd.frameTransform=true")!=std::string::npos&&body.find("transformOpenBORSprite(c.image,c.draw,c.entityFlip)")!=std::string::npos,"v0.34.40 drawFrame defers transforms while CPU fallback keeps exact legacy materialization");}
    {std::ifstream in(hdPreserveOut/"config/graphics.ini");std::string body((std::istreambuf_iterator<char>(in)),{});CHECK(body.find("gpu_shader_transforms=true")!=std::string::npos&&body.find("gpu_texture_atlas=true")!=std::string::npos&&body.find("gpu_atlas_size=1024")!=std::string::npos&&body.find("gpu_atlas_layers=8")!=std::string::npos,"v0.34.40 generated config exposes shader transforms and bounded atlas-array packing");}
    {std::ifstream in(hdPreserveOut/"BUILD-PORTABLE-WINDOWS.ps1");std::string body((std::istreambuf_iterator<char>(in)),{});CHECK(body.find("OpenBOR-Native-Build")!=std::string::npos&&body.find("[IO.Path]::GetTempPath()")!=std::string::npos,"v0.34.42 generated Windows build uses a short TEMP build tree");CHECK(body.find("Visual Studio 17 2022")!=std::string::npos&&body.find("Visual Studio 18 2026")==std::string::npos,"v0.34.42 generated Windows build targets installed VS2022 instead of speculative VS2026");CHECK(body.find("Get-Command clang-cl.exe")!=std::string::npos,"v0.34.42 ClangCL fallback is conditional on the tool actually being installed");}
    {std::ifstream in(sourceDir/"src/main.cpp");std::string body((std::istreambuf_iterator<char>(in)),{});CHECK(body.find("temp_directory_path()/\"OpenBOR-Native-Builder\"")!=std::string::npos&&body.find("Visual Studio 18 2026")==std::string::npos,"v0.34.42 Builder package/build command also uses short TEMP paths and no VS2026 probe");CHECK(body.find("static const char* kVersion = \"0.34.47\"")!=std::string::npos,"v0.34.47 CLI metadata matches release version");}
    {std::ifstream in(hdPreserveOut/"runtime/src/Renderer.cpp");std::string body((std::istreambuf_iterator<char>(in)),{});CHECK(body.find("cpuBlitImage")!=std::string::npos&&body.find("spriteCache_")!=std::string::npos&&body.find("transformCache_")!=std::string::npos,"v0.34.38 generated renderer retains bounded CPU fallback plus sprite/transform caches");CHECK(body.find("findHdOverrides")!=std::string::npos&&body.find(".webp")!=std::string::npos&&body.find("preferWebp")!=std::string::npos,"v0.34.38 HD resolver prefers WebP while retaining fallback candidates");CHECK(body.find("needsPixelTransform")!=std::string::npos,"v0.34.38 identity draw fast path avoids unnecessary transform allocation");}
    {std::ifstream in(hdPreserveOut/"config/graphics.ini");std::string body((std::istreambuf_iterator<char>(in)),{});CHECK(body.find("prefer_webp=true")!=std::string::npos&&body.find("sprite_cache_mb=384")!=std::string::npos&&body.find("transform_cache_mb=192")!=std::string::npos,"v0.34.38 generated config exposes WebP preference and cache budgets");}

    fs::path jluArityRoot="/tmp/obor-v03441-jlu-arity";fs::remove_all(jluArityRoot);fs::create_directories(jluArityRoot/"data/chars");fs::create_directories(jluArityRoot/"data/scripts");
    std::ofstream(jluArityRoot/"data/models.txt")<<"load Vixen data/chars/vixen.txt\n";
    std::ofstream(jluArityRoot/"data/scripts/grabscript.c")<<"void position(int Frame,float dx,float dy,float dz,int face){ setlocalvar(\"face\",face); }\n";
    std::ofstream(jluArityRoot/"data/chars/vixen.txt")<<"name Vixen\ntype player\nanimationscript data/scripts/grabscript.c\nanim attack1\n@cmd position 1 -20 -25 0\nframe none\n";
    auto jluArityComp=CompatibilityAnalyzer::analyze(ProjectScanner::scan(jluArityRoot));bool exactArityDiagnostic=false;for(const auto&i:jluArityComp.issues)if(i.command=="@cmd"&&i.message.find("expects 5")!=std::string::npos&&i.message.find("provides 4")!=std::string::npos&&i.message.find("CHECKARG")!=std::string::npos)exactArityDiagnostic=true;
    CHECK(exactArityDiagnostic,"v0.34.41 malformed custom helper calls report exact authored arity mismatch and legacy CHECKARG behavior");
    // Repair packages may suggest a fix only when a missing trailing helper
    // argument is recoverable from multiple unanimous valid sibling calls. The
    // authored source itself remains untouched and therefore still reports PARTIAL.
    std::ofstream(jluArityRoot/"data/chars/vixen.txt")<<"name Vixen\ntype player\nanimationscript data/scripts/grabscript.c\nanim attack1\n@cmd position 1 10 20 0 0\nframe none\n@cmd position 1 -20 -25 0\nframe none\n@cmd position 1 30 40 0 0\nframe none\n";
    auto jluRepairScan=ProjectScanner::scan(jluArityRoot);auto jluRepairComp=CompatibilityAnalyzer::analyze(jluRepairScan);fs::path jluRepairOut="/tmp/obor-v03441-jlu-repair";fs::remove_all(jluRepairOut);RepairPackage::generate(jluRepairScan,jluRepairComp,jluRepairOut);
    {std::ifstream in(jluRepairOut/"AI-Repair/suggested-sources/data/chars/vixen.txt");std::string body((std::istreambuf_iterator<char>(in)),{});CHECK(body.find("@cmd position 1 -20 -25 0 0")!=std::string::npos,"v0.34.41 repair package infers unanimous missing trailing helper argument without editing original source");}
    {std::ifstream in(jluRepairOut/"AI-Repair/suggested-repairs.patch");std::string body((std::istreambuf_iterator<char>(in)),{});CHECK(body.find("high-confidence trailing argument inference")!=std::string::npos&&body.find("-@cmd position 1 -20 -25 0")!=std::string::npos&&body.find("+@cmd position 1 -20 -25 0 0")!=std::string::npos,"v0.34.41 repair package emits auditable high-confidence patch for authored arity defect");}
    CHECK(jluRepairComp.partialCommands>0,"v0.34.41 repair suggestion never lies about original compatibility; authored defect remains PARTIAL until user applies the suggested source");

    fs::path jluDyingRoot="/tmp/obor-v03441-jlu-dying";fs::remove_all(jluDyingRoot);fs::create_directories(jluDyingRoot/"data/chars");fs::create_directories(jluDyingRoot/"data/levels");
    std::ofstream(jluDyingRoot/"data/models.txt")<<"load Doom data/chars/doom.txt\n";
    std::ofstream(jluDyingRoot/"data/chars/doom.txt")<<"name Doom\ntype enemy\npalette none\nanim idle\nframe none\n";
    std::ofstream(jluDyingRoot/"data/levels.txt")<<"set Test\nfile data/levels/a.txt\n";
    std::ofstream(jluDyingRoot/"data/levels/a.txt")<<"spawn Doom\ndying 1 300 100\ncoords 100 200\nat 0\n";
    auto jluDyingScan=ProjectScanner::scan(jluDyingRoot);auto jluDyingComp=CompatibilityAnalyzer::analyze(jluDyingScan);
    CHECK(jluDyingComp.commandStatus["dying"]==CommandStatus::Supported,"v0.34.41 dying is certified with the exact legacy two-threshold stateful cadence");
    fs::path jluDyingOut="/tmp/obor-v03441-jlu-dying-port";fs::remove_all(jluDyingOut);PortGenerator::generate(jluDyingScan,jluDyingComp,jluDyingOut);{std::ifstream in(jluDyingOut/"runtime/src/Engine.cpp");std::string body((std::istreambuf_iterator<char>(in)),{});CHECK(body.find("legacyNow=(tickCounter_*200ull)/60ull")!=std::string::npos&&body.find("(t%20ull)<5ull")!=std::string::npos&&body.find("e.dyingFlashOn||e.health<=0")!=std::string::npos&&body.find("resolveCombat(); updateDyingFlashes();")!=std::string::npos,"v0.34.41 generated dying emulates OpenBOR GAME_SPEED=200 cadence and stateful palette toggles after combat");}

    fs::path jluNoReflectRoot="/tmp/obor-v03441-jlu-noreflect";fs::remove_all(jluNoReflectRoot);fs::create_directories(jluNoReflectRoot/"data/chars");
    std::ofstream(jluNoReflectRoot/"data/models.txt")<<"load Poison data/chars/poison.txt\n";
    std::ofstream(jluNoReflectRoot/"data/chars/poison.txt")<<"name Poison\ntype projectile\nanim idle\nattack 0 0 20 20 5 1 1 0 0 0\nnoreflect 1\nframe none\n";
    auto jluNoReflectChars=CharacterParser::parseAll(jluNoReflectRoot/"data",jluNoReflectRoot);auto jluNoReflectScan=ProjectScanner::scan(jluNoReflectRoot);auto jluNoReflectComp=CompatibilityAnalyzer::analyze(jluNoReflectScan);
    CHECK(!jluNoReflectChars.empty()&&!jluNoReflectChars[0].animations.empty()&&!jluNoReflectChars[0].animations[0].frames.empty()&&jluNoReflectChars[0].animations[0].frames[0].attack.noReflect==1,"v0.34.41 noreflect is preserved on the authored attack box");
    CHECK(jluNoReflectComp.commandStatus["noreflect"]==CommandStatus::Supported,"v0.34.41 noreflect is certified as attack reaction suppression rather than projectile reflection metadata");
    fs::path jluNoReflectOut="/tmp/obor-v03441-jlu-noreflect-port";fs::remove_all(jluNoReflectOut);PortGenerator::generate(jluNoReflectScan,jluNoReflectComp,jluNoReflectOut);{std::ifstream in(jluNoReflectOut/"runtime/src/Engine.cpp");std::string body((std::istreambuf_iterator<char>(in)),{});CHECK(body.find("knockdown=suppressReaction?false")!=std::string::npos&&body.find("launchX=suppressReaction?0.0f")!=std::string::npos&&body.find("attack.noReflect!=0")!=std::string::npos,"v0.34.41 noreflect keeps damage while suppressing PAIN/FALL reaction and displacement");}

    fs::path jluCleanupRoot="/tmp/obor-v03441-jlu-cleanup";fs::remove_all(jluCleanupRoot);fs::create_directories(jluCleanupRoot/"data/chars");fs::create_directories(jluCleanupRoot/"data/scripts");
    std::ofstream(jluCleanupRoot/"data/models.txt")<<"load Typo data/chars/typo.txt\nload Hit data/chars/hit.txt\n";
    std::ofstream(jluCleanupRoot/"data/chars/typo.txt")<<"name Typo\ntype obstacle\nshadown 0\nanim idle\ndela 4\nframe none\n";
    std::ofstream(jluCleanupRoot/"data/scripts/hit.c")<<"void main(){ setglobalvar(\"hit\",1); }\n";
    std::ofstream(jluCleanupRoot/"data/chars/hit.txt")<<"name Hit\ntype item\ndidhitscript data/scripts/hit.c\nanim idle\nframe none\n";
    auto jluCleanupComp=CompatibilityAnalyzer::analyze(ProjectScanner::scan(jluCleanupRoot));
    CHECK(jluCleanupComp.commandStatus["dela"]==CommandStatus::IgnoredSafely&&jluCleanupComp.commandStatus["shadown"]==CommandStatus::IgnoredSafely,"v0.34.41 inert JLU source typos match OpenBOR unknown-command behavior without aliasing delay/shadow");
    CHECK(jluCleanupComp.commandStatus["didhitscript"]==CommandStatus::Supported,"v0.34.41 fully supported didhitscript helper is certified by occurrence analysis");
    fs::path jluInactivePaletteRoot="/tmp/obor-v03441-jlu-inactive-palette";fs::remove_all(jluInactivePaletteRoot);fs::create_directories(jluInactivePaletteRoot/"data/chars");
    std::ofstream(jluInactivePaletteRoot/"data/models.txt")<<"load Live data/chars/live.txt\n";
    std::ofstream(jluInactivePaletteRoot/"data/chars/live.txt")<<"name Live\ntype player\npalette data/chars/live/missing.gif\nanim idle\nframe none\n";
    std::ofstream(jluInactivePaletteRoot/"data/chars/backup.txt")<<"name Backup\ntype enemy\npalette data/chars/old/missing.gif\nalternatepal data/chars/old/missing2.gif\nremap data/chars/old/a.gif data/chars/old/b.gif\nanim idle\nframe none\n";
    auto jluInactivePaletteComp=CompatibilityAnalyzer::analyze(ProjectScanner::scan(jluInactivePaletteRoot));
    CHECK(jluInactivePaletteComp.commandStatusCounts["palette"][CommandStatus::Partial]==1&&jluInactivePaletteComp.commandStatusCounts["palette"][CommandStatus::IgnoredSafely]==1,"v0.34.41 unresolved palette remains partial for live models but inactive backup model palettes are ignored safely");
    CHECK(jluInactivePaletteComp.commandStatusCounts["alternatepal"][CommandStatus::IgnoredSafely]==1&&jluInactivePaletteComp.commandStatusCounts["remap"][CommandStatus::IgnoredSafely]==1,"v0.34.41 inactive unregistered model remaps do not lower playable-module compatibility");
    fs::path jluTextRoot="/tmp/obor-v03441-jlu-textobj";fs::remove_all(jluTextRoot);fs::create_directories(jluTextRoot/"data/chars");fs::create_directories(jluTextRoot/"data/scripts");
    std::ofstream(jluTextRoot/"data/models.txt")<<"load Hero data/chars/hero.txt\n";
    std::ofstream(jluTextRoot/"data/chars/hero.txt")<<"name Hero\ntype player\nanim idle\nframe none\n";
    std::ofstream(jluTextRoot/"data/scripts/update.c")<<"void main(){ settextobj(3,10,20,1,4,\"READY\",openborvariant(\"elapsed_time\")+60); changetextobjproperty(3,\"x\",12); }\n";
    auto jluTextScan=ProjectScanner::scan(jluTextRoot);auto jluTextComp=CompatibilityAnalyzer::analyze(jluTextScan);bool textWarning=false;for(const auto&i:jluTextComp.issues)if(i.command=="script-file"&&i.message.find("settextobj")!=std::string::npos)textWarning=true;CHECK(!textWarning,"v0.34.41 ScriptVM analyzer accepts persistent text-object APIs");
    std::ofstream(jluTextRoot/"data/scripts/load.c")<<"void main(){ void m=loadmodel(\"Hero\"); if(m!=NULL()){ setglobalvar(\"loaded\",1); } }\n";
    auto jluLoadComp=CompatibilityAnalyzer::analyze(ProjectScanner::scan(jluTextRoot));bool loadWarning=false;for(const auto&i:jluLoadComp.issues)if(i.command=="script-file"&&i.message.find("loadmodel")!=std::string::npos)loadWarning=true;CHECK(!loadWarning,"v0.34.41 ScriptVM analyzer accepts OpenBOR loadmodel for models predeclared in generated models.txt registry");
    fs::path jluTextOut="/tmp/obor-v03441-jlu-textobj-port";fs::remove_all(jluTextOut);PortGenerator::generate(jluTextScan,jluTextComp,jluTextOut);{std::ifstream in(jluTextOut/"runtime/src/Engine.cpp");std::string body((std::istreambuf_iterator<char>(in)),{});CHECK(body.find("if(name==\"settextobj\")")!=std::string::npos&&body.find("scriptTextObjects_")!=std::string::npos&&body.find("loadmodel-unregistered:")!=std::string::npos,"v0.34.41 generated runtime implements persistent text objects and registered-model loadmodel shim");}

    fs::path removeRoot="/tmp/obor-v0349-remove";fs::create_directories(removeRoot);
    std::ofstream(removeRoot/"default.txt")<<"name Shot\ntype projectile\nanim idle\nframe none\n";
    std::ofstream(removeRoot/"pierce.txt")<<"name Shot\ntype projectile\nremove 0\nanim idle\nframe none\n";
    CHECK(CharacterParser::parse(removeRoot/"default.txt",removeRoot).removeConfig==1,"v0.34.9 projectile default remove follows OpenBOR v7533");
    CHECK(CharacterParser::parse(removeRoot/"pierce.txt",removeRoot).removeConfig==0,"v0.34.9 explicit remove zero overrides projectile default");

    std::cout << (gFails? "REGRESSION FAIL " : "REGRESSION PASS ") << gFails << " failures\n";
    return gFails?1:0;
}
