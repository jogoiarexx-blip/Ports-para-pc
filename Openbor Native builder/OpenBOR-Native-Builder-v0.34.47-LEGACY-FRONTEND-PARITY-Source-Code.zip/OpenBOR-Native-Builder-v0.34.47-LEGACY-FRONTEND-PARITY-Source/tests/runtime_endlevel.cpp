#include "Engine.hpp"
#include <iostream>
#include <stdexcept>

struct RuntimeCompatibilityTest {
  static void check(bool ok,const char* message){if(!ok)throw std::runtime_error(message);std::cout<<"PASS: "<<message<<"\n";}
  static RuntimeEntity portal(Engine& e,const generated::Character* model){RuntimeEntity out;out.model=model;out.worldX=e.playerWorldX_;out.z=e.playerZ_;out.facing=1;out.alive=true;out.visible=true;out.animation.setAnimation(e.findAnimation(model,"idle"));return out;}
  static void run(const std::filesystem::path& root){
    Engine e;check(e.initialize(root),"endlevel fixture initializes");e.config_.autoPreviewMusic=false;
    check(e.resolveBranchTarget("ALTERNATE")==1,"branch resolver is case-insensitive and targets levels.txt branch labels");
    auto* any=e.findCharacter("EndAny");auto* both=e.findCharacter("EndBoth");
    check(any&&both,"endlevel models are generated");
    check(any->branch&&std::string(any->branch)=="AlTeRnAtE","model branch metadata reaches generated runtime data");

    e.entities_.clear();e.stageComplete_=false;e.pendingBranchTarget_=(std::size_t)-1;e.pendingBranchImmediate_=false;e.coopPlayers_.clear();
    e.entities_.push_back(portal(e,any));
    auto trigger=e.bboxFor(e.entities_.back().animation.frame(),e.entities_.back().worldX,e.entities_.back().z+e.entities_.back().altitude,e.entities_.back().facing);
    auto hero=e.bboxFor(e.player_.frame(),e.playerWorldX_,e.playerZ_+e.playerAltitude_,e.playerFacing_);
    check(e.playerAlive_&&Engine::overlaps(trigger,hero),"test fixture places active P1 inside endlevel marker");
    e.updateEndLevelTriggers();
    check(e.stageComplete_&&e.pendingBranchTarget_==1,"touching TYPE_ENDLEVEL finishes stage and selects model branch");

    e.entities_.clear();e.stageComplete_=false;e.pendingBranchTarget_=(std::size_t)-1;e.pendingBranchImmediate_=false;e.coopPlayers_.clear();
    RuntimeCoopPlayer cp;cp.model=e.playerModel_;cp.playerSlot=1;cp.alive=true;cp.worldX=e.playerWorldX_+100;cp.z=e.playerZ_;cp.animation.setAnimation(e.findAnimation(cp.model,"idle"));e.coopPlayers_.push_back(std::move(cp));
    e.entities_.push_back(portal(e,both));e.updateEndLevelTriggers();
    check(!e.stageComplete_&&e.pendingBranchTarget_==(std::size_t)-1,"SUBTYPE_BOTH waits for every active player");
    e.coopPlayers_[0].worldX=e.playerWorldX_;e.updateEndLevelTriggers();
    check(e.stageComplete_&&e.pendingBranchTarget_==1,"SUBTYPE_BOTH completes when every active player touches marker");
  }
};
int main(int argc,char** argv){try{if(argc!=2)return 2;RuntimeCompatibilityTest::run(argv[1]);std::cout<<"RUNTIME ENDLEVEL PASS\n";return 0;}catch(const std::exception& error){std::cerr<<"FAIL: "<<error.what()<<"\n";return 1;}}
