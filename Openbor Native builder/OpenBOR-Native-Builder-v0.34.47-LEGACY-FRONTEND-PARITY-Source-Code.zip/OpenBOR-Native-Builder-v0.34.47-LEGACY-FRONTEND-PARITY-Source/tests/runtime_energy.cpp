#include "Engine.hpp"
#include <iostream>
#include <stdexcept>
struct RuntimeCompatibilityTest {
 static void check(bool ok,const char* msg){if(!ok)throw std::runtime_error(msg);std::cout<<"PASS: "<<msg<<"\n";}
 static void run(const std::filesystem::path& root){
  Engine e;check(e.initialize(root),"energy runtime initializes");e.config_.autoPreviewMusic=false;e.tickCounter_=1;
  const auto*hero=e.findCharacter("Hero");const auto*idle=e.findAnimation(hero,"idle");
  auto reset=[&](int hp,int mp){e.playerModel_=hero;e.playerHealth_=hp;e.playerMp_=mp;e.playerAlive_=true;e.player_.setAnimation(idle);e.playerEnergyPending_={};e.playerAttackTicks_=e.playerAttackCooldown_=e.playerComboWindow_=e.playerComboStep_=e.playerHitStun_=e.playerFallTicks_=e.playerRecoveryTicks_=0;e.playerAttackHasHit_=false;e.playerQueuedAttack_=false;e.stageLength_=1000;e.playerWorldX_=100;e.playerZ_=180;e.playerAltitude_=0;e.playerFacing_=1;e.entities_.clear();};
  auto perform=[&](const char*name,std::uintptr_t handle=1){std::vector<std::string> unsupported;auto r=e.callScriptFunction("performattack",{handle,std::string(name)},e.playerScriptCtx_,unsupported);auto b=std::get_if<bool>(&r);return b&&*b;};
  reset(100,20);e.startPlayerAttack();check(e.playerMp_==15&&e.playerHealth_==100,"default mode pays full MP cost when affordable");e.startPlayerAttack();check(e.playerMp_==15,"repeated input during active attack does not charge again");
  reset(100,3);e.startPlayerAttack();check(e.playerMp_==3&&e.playerHealth_==95,"insufficient MP falls back to full HP cost without splitting");
  reset(5,3);e.startPlayerAttack();check(e.playerAttackTicks_==0&&e.player_.animation()==idle&&e.playerHealth_==5&&e.playerMp_==3,"HP equal to cost rejects attack without changing animation or resources");
  reset(3,3);e.startPlayerAttack();check(e.playerAttackTicks_==0,"combined insufficient HP and MP cannot pay by pooling");
  reset(100,8);check(perform("freespecial")&&e.playerMp_==0&&e.playerHealth_==100,"MP-only move can spend exactly the available MP");
  reset(100,7);check(!perform("freespecial")&&e.playerMp_==7&&e.player_.animation()==idle,"MP-only move rejects HP fallback and preserves state");
  reset(8,20);check(perform("attack2")&&e.playerHealth_==1&&e.playerMp_==20,"HP-only alias pays HP and keeps MP intact");
  reset(7,20);check(!perform("attack2")&&e.playerHealth_==7&&e.playerMp_==20,"HP-only move cannot spend the last HP");
  reset(100,20);check(!perform("attack3")&&e.player_.animation()==idle,"disabled animation refuses script activation");
  RuntimeCoopPlayer cp;cp.model=hero;cp.health=cp.maxHealth=100;cp.mp=cp.maxMp=20;cp.animation.setAnimation(idle);e.coopPlayers_.push_back(cp);check(perform("attack1",2)&&e.coopPlayers_[0].mp==15&&e.playerMp_==20,"cooperative actor pays its own resource pool");e.coopPlayers_.clear();
  generated::Character ai=*hero;ai.type="enemy";RuntimeEntity actor;actor.model=&ai;actor.health=100;actor.mp=20;actor.animation.setAnimation(idle);e.entities_.push_back(actor);check(perform("attack1",(std::uintptr_t)&e.entities_[0])&&e.entities_[0].mp==15,"scripted enemy attack pays its own MP");
  generated::Character deferred=*hero;deferred.globalNoCost=true;
  reset(100,0);e.playerModel_=&deferred;e.startPlayerAttack();check(e.playerHealth_==100&&e.playerEnergyPending_.animation,"nocost defers payment until contact animation ends");
  for(int i=0;i<8;++i){e.updatePlayer();e.loadCurrentPlayerSprite();}check(e.playerHealth_==100&&!e.playerEnergyPending_.animation,"missed deferred attack finishes without a charge");
  reset(100,0);e.playerModel_=&deferred;e.startPlayerAttack();RuntimeEntity victim;victim.model=e.findCharacter("Enemy");victim.animation.setAnimation(e.findAnimation(victim.model,"idle"));victim.health=victim.maxHealth=100;victim.worldX=100;victim.z=180;victim.facing=1;e.entities_.push_back(victim);e.resolveCombat();
  check(e.entities_[0].health==90&&e.playerHealth_==100&&e.playerEnergyPending_.hit,"real collision arms deferred cost while preserving HP during animation");e.resolveCombat();for(int i=0;i<8;++i){e.updatePlayer();e.loadCurrentPlayerSprite();}check(e.playerHealth_==95&&!e.playerEnergyPending_.animation,"successful deferred attack is charged once on completion");
  auto toss=[&](std::uintptr_t p,double lift,double vx,double vz){std::vector<std::string> unsupported;auto r=e.callScriptFunction("tossentity",{p,lift,vx,vz},e.playerScriptCtx_,unsupported);auto b=std::get_if<bool>(&r);return b&&*b&&unsupported.empty();};
  reset(100,20);check(toss(1,3,2,1)&&e.playerAltitude_==-0.5f&&e.playerVerticalVelocity_==-3,"tossentity launches player with OpenBOR upward sign");e.updatePlayer();check(e.playerWorldX_==102&&e.playerZ_==181&&e.playerAltitude_<-0.5f,"player launch advances horizontal and vertical motion");
  float beforeAltitude=e.playerAltitude_,beforeVy=e.playerVerticalVelocity_;check(toss(1,0,-2,0)&&e.playerAltitude_==beforeAltitude&&e.playerVerticalVelocity_==beforeVy,"zero lift changes planar velocity without resetting airborne height");
  check(!toss(0,3,1,1)&&!toss(999999,3,1,1),"invalid toss handles are rejected");
  e.coopPlayers_.push_back(cp);check(toss(2,2,3,-1)&&e.coopPlayers_[0].jumping&&e.coopPlayers_[0].verticalVelocity==-2,"tossentity supports cooperative actor");e.tickCounter_=70;e.updateCoopPlayers();check(e.coopPlayers_[0].worldX==cp.worldX+3&&e.coopPlayers_[0].altitude<0,"cooperative launch moves through the actual update loop");e.coopPlayers_.clear();
  actor.model=e.findCharacter("HitA");actor.altitude=0;actor.worldX=100;actor.z=180;e.entities_.push_back(actor);check(toss((std::uintptr_t)&e.entities_[0],2,4,1)&&e.entities_[0].verticalVelocity==-2,"tossentity supports runtime entity");e.updateEntities();check(e.entities_[0].worldX==104&&e.entities_[0].z==181&&e.entities_[0].altitude<0,"entity launch advances through its physics update");
  std::vector<std::string> unsupported;
  auto call=[&](const char*n,std::vector<ScriptValue> args){return e.callScriptFunction(n,args,e.playerScriptCtx_,unsupported);};
  reset(100,20);e.playerScriptVelocityX_=2;e.playerScriptVelocityZ_=3;e.playerVerticalVelocity_=-4;
  call("changeentityproperty",{std::uintptr_t(1),std::string("velocity"),6.0});
  check(e.playerScriptVelocityX_==6&&e.playerScriptVelocityZ_==3&&e.playerVerticalVelocity_==-4,"omitted velocity axes preserve player movement");
  call("changeentityproperty",{std::uintptr_t(1),std::string("velocity"),std::uintptr_t(0),std::uintptr_t(0),5.0});
  check(e.playerScriptVelocityX_==6&&e.playerScriptVelocityZ_==3&&e.playerVerticalVelocity_==-5,"NULL velocity axes are preserved and upward sign is converted");
  check(std::get<double>(call("getentityproperty",{std::uintptr_t(1),std::string("tossv")}))==5,"tossv reads OpenBOR upward sign");
  call("changeentityproperty",{std::uintptr_t(1),std::string("position"),std::uintptr_t(0),std::uintptr_t(0),12.0});
  check(e.playerWorldX_==100&&e.playerZ_==180&&e.playerAltitude_==-12,"NULL position axes preserve coordinates");
  e.coopPlayers_.push_back(cp);call("changeentityproperty",{std::uintptr_t(2),std::string("velocity"),2.0,3.0,4.0});
  check(e.coopPlayers_[0].scriptVelocityX==2&&e.coopPlayers_[0].scriptVelocityZ==3&&e.coopPlayers_[0].verticalVelocity==-4,"cooperative velocity uses OpenBOR sign");
  e.entities_.push_back(actor);auto handle=std::uintptr_t((std::uintptr_t)&e.entities_.back());
  call("changeentityproperty",{handle,std::string("velocity"),2.0,3.0,4.0});call("changeentityproperty",{handle,std::string("velocity"),std::uintptr_t(0),8.0});
  check(e.entities_.back().scriptVelocityX==2&&e.entities_.back().scriptVelocityZ==8&&e.entities_.back().verticalVelocity==-4,"entity velocity preserves NULL and omitted axes");
  check(std::get<double>(call("getentityproperty",{handle,std::string("tossv")}))==4,"entity tossv returns upward velocity");
  e.playerScriptCtx_.player=true;e.playerScriptCtx_.playerIndex=0;
  check(std::get<double>(call("killentity",{std::uintptr_t(0)}))==0&&e.playerAlive_,"killentity NULL does not kill current context actor");
  check(std::get<double>(call("killentity",{handle}))==1&&!e.entities_.back().alive&&!e.entities_.back().visible,"direct killentity removes entity immediately");
  check(std::get<double>(call("killentity",{std::uintptr_t(999999)}))==0,"invalid killentity handle returns zero");
  check(std::get<double>(call("killentity",{std::uintptr_t(2)}))==1&&!e.coopPlayers_[0].alive&&e.playerAlive_,"direct killentity affects only selected cooperative actor");
  check(std::get<double>(call("openborvariant",{std::string("effectvol")}))==100,"effectvol prevents random sound helpers from receiving zero gain");
  reset(100,20);call("changeentityproperty",{std::uintptr_t(1),std::string("antigravity"),1.0});toss(1,3,0,0);e.updatePlayer();
  check(e.playerVerticalVelocity_==-3&&std::get<double>(call("getentityproperty",{std::uintptr_t(1),std::string("antigravity")}))==1,"script antigravity changes actual player physics");
  call("changeentityproperty",{std::uintptr_t(1),std::string("antigravity"),0.5});e.updatePlayer();
  check(std::abs(e.playerVerticalVelocity_-(-3+e.config_.gravity*0.5f))<0.0001,"fractional antigravity uses proportional acceleration");
  e.entities_.push_back(actor);handle=(std::uintptr_t)&e.entities_.back();call("changeentityproperty",{handle,std::string("antigravity"),1.0});toss(handle,3,0,0);e.updateEntities();
  check(e.entities_.back().verticalVelocity==-3&&hero->antigravity==0,"entity antigravity override leaves shared model unchanged");
  check(unsupported.empty(),"tested movement removal and volume subset has no unsupported calls");

  Engine saveEngine;check(saveEngine.initialize(root),"Save V3 fixture initializes");saveEngine.config_.autoPreviewMusic=false;
  saveEngine.playerHealth_=63;saveEngine.playerMp_=11;saveEngine.playerPaletteMap_=3;saveEngine.playerScore_=98765;saveEngine.livesRemaining_=4;saveEngine.creditsRemaining_=7;
  saveEngine.equippedWeapon_=saveEngine.findCharacter("HitA");saveEngine.weaponUses_=12;saveEngine.weaponItemModel_=saveEngine.findCharacter("HitB");saveEngine.weaponDropsRemaining_=2;
  saveEngine.saveProgress();
  saveEngine.playerHealth_=1;saveEngine.playerMp_=0;saveEngine.playerPaletteMap_=0;saveEngine.playerScore_=0;saveEngine.livesRemaining_=1;saveEngine.creditsRemaining_=0;saveEngine.equippedWeapon_=nullptr;saveEngine.weaponUses_=0;saveEngine.weaponItemModel_=nullptr;saveEngine.weaponDropsRemaining_=0;
  check(saveEngine.loadProgress(),"Save V3 slot reloads");
  check(saveEngine.playerHealth_==63&&saveEngine.playerMp_==11&&saveEngine.playerPaletteMap_==3&&saveEngine.playerScore_==98765,"Save V3 restores P1 health MP palette and score");
  check(saveEngine.livesRemaining_==4&&saveEngine.creditsRemaining_==7,"Save V3 restores P1 lives and credits");
  check(saveEngine.equippedWeapon_&&std::string(saveEngine.equippedWeapon_->name)=="HitA"&&saveEngine.weaponUses_==12&&saveEngine.weaponItemModel_&&std::string(saveEngine.weaponItemModel_->name)=="HitB"&&saveEngine.weaponDropsRemaining_==2,"Save V3 restores equipped/item weapon state");

  Engine poolEngine;check(poolEngine.initialize(root),"noshare runtime fixture initializes");poolEngine.config_.autoPreviewMusic=false;
  generated::Stage noShareStage=*poolEngine.stage_;noShareStage.noShare=1;noShareStage.lives=3;noShareStage.credits=2;poolEngine.stage_=&noShareStage;poolEngine.livesRemaining_=3;poolEngine.creditsRemaining_=2;
  RuntimeCoopPlayer p2;p2.playerSlot=1;p2.model=hero;p2.maxHealth=p2.health=100;p2.maxMp=p2.mp=20;p2.livesRemaining=3;p2.creditsRemaining=2;p2.alive=false;p2.animation.setAnimation(idle);poolEngine.coopPlayers_.push_back(p2);
  check(poolEngine.consumeRespawnResource(1)&&poolEngine.coopPlayers_[0].livesRemaining==2&&poolEngine.coopPlayers_[0].creditsRemaining==2&&poolEngine.livesRemaining_==3&&poolEngine.creditsRemaining_==2,"noshare P2 death consumes only P2 life pool");
  poolEngine.coopPlayers_[0].livesRemaining=1;check(poolEngine.consumeRespawnResource(1)&&poolEngine.coopPlayers_[0].creditsRemaining==1&&poolEngine.coopPlayers_[0].livesRemaining==3,"noshare P2 continue consumes only P2 credit and resets P2 lives");
  noShareStage.noShare=0;poolEngine.livesRemaining_=3;poolEngine.creditsRemaining_=2;poolEngine.coopPlayers_[0].livesRemaining=9;poolEngine.coopPlayers_[0].creditsRemaining=9;check(poolEngine.consumeRespawnResource(1)&&poolEngine.livesRemaining_==2&&poolEngine.coopPlayers_[0].livesRemaining==9,"shared campaign keeps cooperative respawns on common pool");

  Engine sparseSave;check(sparseSave.initialize(root),"Save V3 sparse player fixture initializes");sparseSave.config_.autoPreviewMusic=false;sparseSave.joinedPlayers_[0]=true;sparseSave.joinedPlayers_[1]=false;sparseSave.joinedPlayers_[2]=true;sparseSave.joinedPlayers_[3]=false;sparseSave.config_.activePlayers=2;
  RuntimeCoopPlayer p3;p3.playerSlot=2;p3.model=hero;p3.maxHealth=100;p3.health=0;p3.maxMp=20;p3.mp=7;p3.paletteMap=2;p3.score=321;p3.livesRemaining=2;p3.creditsRemaining=5;p3.alive=false;p3.animation.setAnimation(idle);sparseSave.coopPlayers_.clear();sparseSave.coopPlayers_.push_back(p3);sparseSave.saveProgress();
  sparseSave.coopPlayers_.clear();for(int i=0;i<4;++i)sparseSave.joinedPlayers_[i]=(i==0);check(sparseSave.loadProgress(),"Save V3 reloads sparse cooperative slot");
  check(sparseSave.joinedPlayers_[2]&&!sparseSave.joinedPlayers_[1]&&sparseSave.coopPlayers_.size()==1&&sparseSave.coopPlayers_[0].playerSlot==2,"Save V3 joined mask preserves P3 without inventing P2");
  check(!sparseSave.coopPlayers_[0].alive&&sparseSave.coopPlayers_[0].health==0&&sparseSave.coopPlayers_[0].livesRemaining==2&&sparseSave.coopPlayers_[0].creditsRemaining==5,"Save V3 preserves eliminated P3 and its independent continue pool");

 }
};
int main(int argc,char**argv){try{if(argc!=2)return 2;RuntimeCompatibilityTest::run(argv[1]);std::cout<<"RUNTIME ENERGY PASS\n";return 0;}catch(const std::exception&error){std::cerr<<"FAIL: "<<error.what()<<"\n";return 1;}}
