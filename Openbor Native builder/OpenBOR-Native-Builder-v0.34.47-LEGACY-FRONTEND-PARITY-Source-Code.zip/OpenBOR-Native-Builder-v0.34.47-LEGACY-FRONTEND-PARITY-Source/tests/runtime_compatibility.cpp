#include "Engine.hpp"
#include <iostream>
#include <stdexcept>

struct RuntimeCompatibilityTest {
  static void check(bool ok,const char* message){if(!ok)throw std::runtime_error(message);std::cout<<"PASS: "<<message<<"\n";}
  static double global(const Engine& e,const char* key){auto it=e.scriptVm_.globals().find(key);if(it==e.scriptVm_.globals().end())return 0;auto n=std::get_if<double>(&it->second);return n?*n:0;}
  static void run(const std::filesystem::path& root){
    std::error_code cleanupEc;std::filesystem::remove_all(root/"saves",cleanupEc);
    Engine e;check(e.initialize(root),"generated runtime initializes");e.config_.autoPreviewMusic=false;e.tickCounter_=1;
    check(e.campaignFirstStages_.size()==2&&e.campaignRequirements_.size()==2,"campaign selector preserves two level sets and unlock metadata");
    check(e.campaignRequirements_[1]==1&&e.campaignLocked(1),"ifcomplete locks the second level set before any completion");
    auto initialStage=e.stageIndex_;e.startCampaign(1);check(e.stageIndex_==initialStage&&e.frontendState_==Engine::FrontendState::LevelSetSelect,"locked campaign cannot be started");
    check(e.stage_->campaignEnd&&e.sequentialCampaignTarget()==(std::size_t)-1,"levels.txt end stops default progression before the next set");
    e.finishCampaign();check(e.completionCount_==1&&!e.campaignLocked(1)&&std::filesystem::exists(root/"saves"/"unlocks.ini"),"campaign completion persists and unlocks ifcomplete requirement");
    e.startCampaign(1);check(e.stageIndex_==1&&e.frontendState_==Engine::FrontendState::CharacterSelect,"unlocked campaign becomes selectable without crossing set boundaries");
    e.stageIndex_=0;check(e.loadStage(0,false),"runtime returns to primary fixture stage after unlock flow");
    check(e.stage_->panelCount==6,"panel order expands repetitions");
    check(std::string(e.stage_->panels[0])=="bgs/a.gif"&&std::string(e.stage_->panels[1])=="bgs/b.gif"&&std::string(e.stage_->panels[3])=="bgs/b.gif","panel order preserves letters and directive order");
    check(e.stageLength_>=(float)(120+e.config_.logicalWidth),"stage length keeps authored at positions reachable without wide panels");
    e.cameraX_=99.0f;e.processStageInstructions();check(e.entities_.empty(),"at trigger uses OpenBOR scroll position instead of the viewport right edge");
    check(e.noJoin_,"nojoin stage control closes in-progress join gate at authored trigger");
    check(!e.joinPlayerSlot(1),"closed nojoin gate rejects an in-progress P2 join");
    e.cameraX_=100.0f;e.processStageInstructions();check(e.entities_.size()==1&&std::abs(e.entities_[0].worldX-140.0f)<0.01f,"spawn coords X is relative to the screen at the actual at trigger");
    e.entities_[0].alive=false;e.cameraX_=150.0f;e.processStageInstructions();check(!e.noJoin_,"canjoin reopens the in-progress join gate in source order");
    check(e.entities_.size()==2&&std::abs(e.entities_[1].worldX-200.0f)<0.01f,"group-delayed spawn uses the current screen position, not authored at plus coords");
    e.config_.maxPlayers=2;check(e.joinPlayerSlot(1),"open join gate creates a late P2 runtime actor");check(e.coopPlayers_.size()==1&&e.coopPlayers_[0].playerSlot==1&&e.joinedPlayers_[1],"late join preserves OpenBOR player slot identity");
    {ScriptContext c;std::vector<std::string> u;auto state=e.callScriptFunction("openborvariant",{std::string("nojoin")},c,u);auto value=std::get_if<double>(&state);check(value&&std::abs(*value)<0.01,"ScriptVM exposes the native nojoin state");e.callScriptFunction("changeopenborvariant",{std::string("nojoin"),1.0},c,u);check(e.noJoin_,"changeopenborvariant can close the native join gate");e.callScriptFunction("changeopenborvariant",{std::string("nojoin"),0.0},c,u);}
    e.coopPlayers_.clear();e.joinedPlayers_[1]=false;e.config_.activePlayers=1;e.entities_.clear();
    {float oldLength=e.stageLength_,oldCamera=e.cameraX_;int oldDir=e.scrollDir_;e.stageLength_=1000.0f;e.scrollDir_=-1;e.cameraX_=680.0f;check(std::abs(e.stageScrollPosition())<0.01f&&!e.reachedStagePosition(1,true),"left stage at=0 starts at the right edge");e.cameraX_=580.0f;check(std::abs(e.stageScrollPosition()-100.0f)<0.01f&&e.reachedStagePosition(100,true),"left stage at positions are measured from the right edge");e.stageLength_=oldLength;e.cameraX_=oldCamera;e.scrollDir_=oldDir;}
    e.loadCurrentPlayerSprite();check(global(e,"helperFrames")==1,"animationscript main runs even without cmd");
    check(global(e,"shared")==1,"model inline script executes on frame entry");
    e.startPlayerAttack();e.loadCurrentPlayerSprite();
    for(int i=0;i<45;++i){e.updatePlayer();e.loadCurrentPlayerSprite();}
    check(e.playerAttackTicks_>0&&e.player_.frameIndex()==2,"long attack reaches its last frame before ending");
    check(global(e,"lastAttackFrame")==1&&global(e,"stamp")==9,"inline script and multiple cmd calls execute once in frame order");
    check(global(e,"helperFrames")==4,"helper main coexists with generated inline and cmd code");
    for(int i=0;i<17;++i){e.updatePlayer();e.loadCurrentPlayerSprite();}
    check(e.playerAttackTicks_==0&&std::string(e.player_.animation()->name)=="idle","attack returns to idle after actual frame delays");
    RuntimeEntity victim;victim.model=e.findCharacter("Enemy");victim.animation.setAnimation(e.findAnimation(victim.model,"fall"));victim.worldX=120;victim.z=200;victim.altitude=-0.1f;victim.verticalVelocity=1;victim.fallTicks=28;e.entities_.push_back(victim);
    e.updateEntities();check(e.entities_[0].animation.frameIndex()==1&&e.entities_[0].recoveryTicks>=16,"landing resumes the requested frame for its remaining duration");
    check(e.pendingChildSpawns_.size()==1&&e.pendingChildSpawns_[0].model==e.findCharacter("Dust"),"landing queues the named dust model once");e.applyLandFrame(e.entities_[0].animation,120,200,1);check(e.pendingChildSpawns_.size()==1,"landframe does not rewind or spawn again at its landing frame");e.flushChildSpawns();
    check(e.entities_.size()==2&&e.entities_[1].animationEffect,"landing dust enters runtime as a temporary animation effect");
    auto spawnType=std::get_if<double>(&e.entities_[1].scriptCtx.local["spawn_type"]);check(spawnType&&*spawnType==8,"landing effect exposes the OpenBOR dust-land spawn type");
    for(int i=0;i<7;++i)e.updateEntities();
    check(!e.entities_[1].visible&&!e.entities_[1].alive,"landing dust disappears when its animation finishes");
    check(e.pendingChildSpawns_.empty(),"ground contact does not repeatedly create landing dust");
    check(std::string(e.entities_[0].animation.animation()->name)=="fall","landing frames are not cut off after four ticks");
  }
};
int main(int argc,char** argv){try{if(argc!=2)return 2;RuntimeCompatibilityTest::run(argv[1]);std::cout<<"RUNTIME COMPATIBILITY PASS\n";return 0;}catch(const std::exception& error){std::cerr<<"FAIL: "<<error.what()<<"\n";return 1;}}
