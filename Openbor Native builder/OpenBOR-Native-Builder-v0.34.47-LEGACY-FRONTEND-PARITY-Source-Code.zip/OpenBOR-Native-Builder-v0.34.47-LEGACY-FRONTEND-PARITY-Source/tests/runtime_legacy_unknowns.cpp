#include "Engine.hpp"
#include <cmath>
#include <iostream>
#include <stdexcept>
#include <string>

struct RuntimeCompatibilityTest {
  static void check(bool ok,const char* message){if(!ok)throw std::runtime_error(message);std::cout<<"PASS: "<<message<<"\n";}
  static void run(const std::filesystem::path& root){
    Engine e;check(e.initialize(root),"generated runtime initializes");e.config_.autoPreviewMusic=false;
    check(e.stage_&&e.stage_->typeMp==1,"typemp is carried into native stage runtime");
    check(std::fabs(e.stage_->gravity+5.0f)<0.001f&&std::fabs(e.stage_->maxFallSpeed+20.0f)<0.001f&&std::fabs(e.stage_->maxTossSpeed-40.0f)<0.001f,"level gravity/max fall/max toss reach generated runtime data");
    check(std::fabs(e.stageGravity()-e.config_.gravity*0.5f)<0.001f&&std::fabs(e.stageMaxFallSpeed()-2.0f)<0.001f&&std::fabs(e.stageMaxTossSpeed()-4.0f)<0.001f,"legacy level physics convert to native vertical units");
    auto selectable=e.selectablePlayers();
    check(selectable.size()==1&&std::string(selectable[0]->name)=="Hero","allowselect filters native character selection");
    const auto* hero=e.findCharacter("Hero");const auto* enemy=e.findCharacter("Enemy");
    check(hero&&enemy,"legacy compatibility models are available");
    check(hero->mpRate==3,"mprate is preserved on generated player model");
    check(std::string(hero->playerArrow)=="sprites/p1.gif"&&hero->playerArrowX==2&&hero->playerArrowY==3,"parrow path and offsets are preserved");
    check(std::string(hero->playerArrow2)=="sprites/p2.gif"&&hero->playerArrow2X==4&&hero->playerArrow2Y==5,"parrow2 path and offsets are preserved");
    const auto* idle=e.findAnimation(hero,"idle");const auto* attack=e.findAnimation(hero,"attack1");const auto* stunAttack=e.findAnimation(hero,"attack2");
    check(idle&&idle->frameCount&&idle->frames[0].idleInterrupt,"idle frame interrupt flag reaches runtime data");
    check(idle->frames[0].frameShadow==3,"fshadow per-frame override reaches runtime data");
    check(attack&&attack->hasDive&&std::fabs(attack->diveVelocityX-1.5f)<0.001f&&std::fabs(attack->diveVelocityY-2.5f)<0.001f,"dive velocity reaches runtime animation data");
    check(attack&&attack->frameCount&&attack->frames[0].hasAttack&&attack->frames[0].attack.type==1003&&attack->frames[0].attack.freezeTime==17,"freeze attack and authored duration reach runtime frame data");
    check(attack->frames[0].attack.penetration==0&&attack->frames[0].attack.noFlash==1&&attack->frames[0].attack.pauseTime==3&&attack->frames[0].attack.zDepth==6,"freeze legacy arguments retain block/flash/pause/z semantics");
    check(stunAttack&&stunAttack->frameCount&&stunAttack->frames[0].attack.type==1&&stunAttack->frames[0].attack.freezeTime==11,"stun preserves normal attack type with authored duration");

    e.playerModel_=hero;e.beginGame();
    check(e.playerInvincibleTicks_==120,"makeinv activates native spawn invincibility used by parrow display window");
    e.playerMp_=0;e.playerMaxMp_=20;e.playerWorldX_=100;e.playerZ_=200;e.playerAltitude_=0;e.playerFacing_=1;e.player_.setAnimation(attack);e.playerAttackTicks_=20;e.playerAttackId_=77;
    RuntimeEntity victim;victim.model=enemy;victim.health=victim.maxHealth=100;victim.worldX=100;victim.z=200;victim.altitude=0;victim.facing=1;victim.animation.setAnimation(e.findAnimation(enemy,"idle"));e.entities_.clear();e.entities_.push_back(victim);
    auto atkBox=e.attackFor(e.player_.frame(),e.playerWorldX_,e.playerZ_+e.playerAltitude_,e.playerFacing_);auto bodyBox=e.bboxFor(e.entities_[0].animation.frame(),e.entities_[0].worldX,e.entities_[0].z+e.entities_[0].altitude,e.entities_[0].facing);check(e.overlaps(atkBox,bodyBox),"freeze attack box overlaps target body");
    e.resolveCombat();
    check(e.entities_[0].health==95,"freeze attack participates in native damage collision");
    check(e.entities_[0].freezeTicks==17&&e.entities_[0].paletteMap==1,"freeze applies authored duration and freeze palette map");
    check(e.playerMp_==3,"typemp 1 restores mprate MP on a successful hit");
    e.entities_[0].freezeTicks=0;e.entities_[0].preFreezePaletteMap=-1;e.entities_[0].paletteMap=0;e.entities_[0].hitStun=0;e.entities_[0].health=100;
    e.damageEnemy(e.entities_[0],4,1.0f,false,0,1,1,0,0,-1,0.0f,0,11);
    check(e.entities_[0].freezeTicks==11&&e.entities_[0].paletteMap==0&&e.entities_[0].preFreezePaletteMap==-1,"stun freezes victim without forcing freeze palette remap");
    check(std::fabs(e.clampStageVerticalVelocity(9.0f)-2.0f)<0.001f&&std::fabs(e.clampStageVerticalVelocity(-9.0f)+4.0f)<0.001f,"stage fall/toss caps clamp native vertical velocity");
    float beforeX=e.playerWorldX_;e.updatePlayer();check(e.playerWorldX_>beforeX,"dive animation applies native horizontal movement");
  }
};
int main(int argc,char** argv){try{if(argc!=2)return 2;RuntimeCompatibilityTest::run(argv[1]);std::cout<<"RUNTIME LEGACY UNKNOWNS PASS\n";return 0;}catch(const std::exception& error){std::cerr<<"FAIL: "<<error.what()<<"\n";return 1;}}
