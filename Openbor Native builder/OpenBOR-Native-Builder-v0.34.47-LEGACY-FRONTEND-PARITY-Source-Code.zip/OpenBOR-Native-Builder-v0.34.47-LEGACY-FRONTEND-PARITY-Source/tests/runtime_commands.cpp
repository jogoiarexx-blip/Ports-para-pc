#include "Engine.hpp"
#include <iostream>
#include <stdexcept>
#include <fstream>
struct RuntimeCompatibilityTest {
 static void check(bool v,const char* label){if(!v)throw std::runtime_error(label);std::cout<<"PASS: "<<label<<"\n";}
 static double number(const ScriptVM& vm,const char* key){auto it=vm.globals().find(key);if(it==vm.globals().end())return 0;if(auto p=std::get_if<double>(&it->second))return *p;if(auto p=std::get_if<bool>(&it->second))return *p?1:0;return 0;}
 static void run(const std::filesystem::path& root){
  Engine e;check(e.initialize(root),"command fixture initializes");e.config_.autoPreviewMusic=false;e.tickCounter_=1;
  e.loadCurrentPlayerSprite();
  const auto& globals=e.scriptVm_.globals();auto label=globals.find("label");
  check(label!=globals.end()&&std::get<std::string>(label->second)=="power # one","quoted spaces and # survive actual @cmd execution");
  auto actor=globals.find("actor");check(actor!=globals.end()&&std::get<std::uintptr_t>(actor->second)==1,"nested expression with spaces receives correct actor handle");
  check(number(e.scriptVm_,"scopeInner")==8&&number(e.scriptVm_,"scopeOuter")==7,"nested helper parameters and declarations do not corrupt caller locals");
  check(number(e.scriptVm_,"bad")==0,"false conditions and short-circuited calls have no effects");
  check(number(e.scriptVm_,"negativeBranch")==4,"unselected unary expressions are consumed without execution");
  check(number(e.scriptVm_,"macro")==4,"function macro and parenthesized object macro expand through nested mixed-case import");
  check(std::get<double>(e.playerScriptCtx_.local.at("persistent"))==77,"setlocalvar persists independently of automatic helper locals");
  check(!e.playerScriptCtx_.local.contains("x")&&!e.playerScriptCtx_.local.contains("label"),"automatic helper locals do not leak into frame context");
  check(number(e.scriptVm_,"order")==2,"multiple frame commands execute in source order");
  check(number(e.scriptVm_,"helperFrames")==1,"helper main runs once alongside frame commands");
  e.loadCurrentPlayerSprite();check(number(e.scriptVm_,"order")==2&&number(e.scriptVm_,"helperFrames")==1,"reloading same frame does not repeat commands");
  ScriptVM vm;vm.setRoot(root/"assets/openbor-data");ScriptContext ctx;ctx.local["self"]=std::uintptr_t(9);
  auto result=vm.runAnimationCommand("","setglobalvar(\"core\", getlocalvar(\"self\")); setglobalvar(\"zero\",NULL());",ctx);
  check(result.ok&&result.unsupported.empty()&&std::get<std::uintptr_t>(vm.globals().at("core"))==9,"verified direct core cmd subset executes with original handle");
  check(std::get<std::uintptr_t>(vm.globals().at("zero"))==0,"NULL cmd argument retains null-handle semantics");
  result=vm.runAnimationCommand("DATA/SCRIPTS/helper.C","stamp(-6);",ctx);check(result.ok&&result.unsupported.empty()&&number(vm,"stamp")==-6,"direct helper lookup is case-insensitive");
  result=vm.runAnimationCommand("","if(0){ setglobalvar(\"skip\",!~(-2)); } setglobalvar(\"after\",3);",ctx);
  check(result.ok&&number(vm,"after")==3&&number(vm,"skip")==0,"stacked unary operators in skipped block do not break later commands");
  result=vm.runAnimationCommand("","setglobalvar(\"and\",0 && unknown_skipped()); setglobalvar(\"or\",1 || unknown_skipped());",ctx);
  check(result.ok&&result.unsupported.empty()&&number(vm,"and")==0&&number(vm,"or")==1,"short circuit does not dispatch skipped unknown function");
  ScriptContext streamCtx;std::vector<std::string> streamUnsupported;auto stream=e.callScriptFunction("openfilestream",{std::string("scripts/stream_test.txt")},streamCtx,streamUnsupported);auto sh=std::get<std::uintptr_t>(stream);check(sh!=0&&streamUnsupported.empty(),"OpenBOR file stream opens a data asset natively");
  auto line0=e.callScriptFunction("getfilestreamline",{sh},streamCtx,streamUnsupported);check(std::get<std::string>(line0)=="alpha 12 3.5 \"hello world\"","getfilestreamline returns the current raw line");
  auto arg1=e.callScriptFunction("getfilestreamargument",{sh,1.0,std::string("int")},streamCtx,streamUnsupported);auto arg3=e.callScriptFunction("getfilestreamargument",{sh,3.0,std::string("string")},streamCtx,streamUnsupported);check(std::get<double>(arg1)==12.0&&std::get<std::string>(arg3)=="hello world","getfilestreamargument preserves numeric conversion and quoted tokens");
  auto pos0=e.callScriptFunction("getfilestreamposition",{sh},streamCtx,streamUnsupported);check(std::get<double>(pos0)==0.0,"new file stream starts at byte position zero");
  e.callScriptFunction("filestreamnextline",{sh},streamCtx,streamUnsupported);auto pos1=e.callScriptFunction("getfilestreamposition",{sh},streamCtx,streamUnsupported);check(std::get<double>(pos1)>0.0,"filestreamnextline advances the byte position");
  auto second=e.callScriptFunction("getfilestreamargument",{sh,1.0,std::string("int")},streamCtx,streamUnsupported);check(std::get<double>(second)==99.0,"file stream reads arguments from the advanced line");
  e.callScriptFunction("setfilestreamposition",{sh,0.0},streamCtx,streamUnsupported);check(std::get<std::string>(e.callScriptFunction("getfilestreamargument",{sh,0.0,std::string("string")},streamCtx,streamUnsupported))=="alpha","setfilestreamposition seeks back to an exact byte offset");
  check(std::get<bool>(e.callScriptFunction("closefilestream",{sh},streamCtx,streamUnsupported)),"closefilestream releases the native handle");
  auto created=e.callScriptFunction("createfilestream",{},streamCtx,streamUnsupported);auto ch=std::get<std::uintptr_t>(created);check(ch!=0,"createfilestream creates an in-memory OpenBOR stream");
  check(std::get<bool>(e.callScriptFunction("filestreamappend",{ch,std::string("score"),1.0},streamCtx,streamUnsupported)),"filestreamappend supports same-line append");
  check(std::get<bool>(e.callScriptFunction("filestreamappend",{ch,42.0,1.0},streamCtx,streamUnsupported)),"filestreamappend converts numeric values like OpenBOR");
  check(std::get<bool>(e.callScriptFunction("savefilestream",{ch,std::string("script-stream-test.txt")},streamCtx,streamUnsupported)),"savefilestream writes to the portable saves directory");
  auto saved=e.callScriptFunction("openfilestream",{std::string("script-stream-test.txt"),1.0},streamCtx,streamUnsupported);auto savedh=std::get<std::uintptr_t>(saved);check(savedh!=0,"openfilestream location=1 reopens a portable save stream");
  auto saved0=e.callScriptFunction("getfilestreamargument",{savedh,0.0,std::string("string")},streamCtx,streamUnsupported);auto saved1=e.callScriptFunction("getfilestreamargument",{savedh,1.0,std::string("int")},streamCtx,streamUnsupported);check(std::get<std::string>(saved0)=="score"&&std::get<double>(saved1)==42.0,"saved file stream round-trips appended script data");
  e.callScriptFunction("closefilestream",{savedh},streamCtx,streamUnsupported);e.callScriptFunction("closefilestream",{ch},streamCtx,streamUnsupported);std::error_code streamEc;std::filesystem::remove(root/"saves"/"script-stream-test.txt",streamEc);
  streamUnsupported.clear();auto screenValue=e.callScriptFunction("allocscreen",{8.0,8.0},streamCtx,streamUnsupported);auto screen=std::get<std::uintptr_t>(screenValue);check(screen!=0&&streamUnsupported.empty()&&e.scriptScreens_.contains(screen),"allocscreen creates a persistent native off-screen surface");
  check(std::get<double>(e.callScriptFunction("getgfxproperty",{screen,std::string("width")},streamCtx,streamUnsupported))==8.0&&std::get<double>(e.callScriptFunction("getgfxproperty",{screen,std::string("height")},streamCtx,streamUnsupported))==8.0,"subscreen dimensions are exposed through getgfxproperty");
  check(std::get<bool>(e.callScriptFunction("drawboxtoscreen",{screen,1.0,1.0,3.0,2.0,(double)0x112233},streamCtx,streamUnsupported)),"drawboxtoscreen writes into the selected off-screen surface");
  auto&surface=e.scriptScreens_.at(screen).image;auto pixel=[&](int x,int y){std::size_t i=((std::size_t)y*(std::size_t)surface.width+(std::size_t)x)*4u;return (unsigned(surface.bgra[i+2])<<16)|(unsigned(surface.bgra[i+1])<<8)|unsigned(surface.bgra[i]);};
  check(pixel(1,1)==0x112233u&&pixel(3,2)==0x112233u&&pixel(0,0)==0u,"subscreen box rasterization is clipped and does not leak into the main draw queue");
  check(std::get<bool>(e.callScriptFunction("drawlinetoscreen",{screen,0.0,0.0,7.0,0.0,(double)0xAA3300},streamCtx,streamUnsupported))&&pixel(6,0)==0xAA3300u,"drawlinetoscreen rasterizes OpenBOR line primitives natively");
  check(std::get<bool>(e.callScriptFunction("drawdottoscreen",{screen,7.0,7.0,(double)0x00CC55},streamCtx,streamUnsupported))&&pixel(7,7)==0x00CC55u,"drawdottoscreen rasterizes a single surface pixel");
  SpriteImage scriptSprite;scriptSprite.width=2;scriptSprite.height=2;scriptSprite.bgra.assign(16,0);for(std::size_t i=0;i<scriptSprite.bgra.size();i+=4){scriptSprite.bgra[i]=0xCC;scriptSprite.bgra[i+1]=0x44;scriptSprite.bgra[i+2]=0x22;scriptSprite.bgra[i+3]=0xFF;}std::uintptr_t spriteHandle=0x1000ABCDu;e.scriptSprites_[spriteHandle]=std::move(scriptSprite);
  streamUnsupported.clear();check(std::get<bool>(e.callScriptFunction("setdrawmethod",{std::uintptr_t(0),1.0,512.0,256.0,1.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},streamCtx,streamUnsupported))&&streamUnsupported.empty(),"setdrawmethod configures the global direct-draw method without a fake entity handle");
  check(e.scriptCommonDrawMethod_.enabled&&e.scriptCommonDrawMethod_.scaleX==2.0f&&e.scriptCommonDrawMethod_.scaleY==1.0f&&e.scriptCommonDrawMethod_.flipX,"legacy fixed-point scale and flip fields are converted into native drawmethod state");
  e.scriptDrawQueue_.clear();check(std::get<bool>(e.callScriptFunction("drawsprite",{spriteHandle,1.0,1.0,100.0,7.0},streamCtx,streamUnsupported)),"drawsprite queues a native sprite with the active common drawmethod");check(e.scriptDrawQueue_.size()==1&&e.scriptDrawQueue_.back().draw.scaleX==2.0f&&e.scriptDrawQueue_.back().sortId==7,"drawsprite snapshots drawmethod and sortid at submission time");
  check(std::get<bool>(e.callScriptFunction("changedrawmethod",{std::uintptr_t(0),std::string("scalex"),256.0},streamCtx,streamUnsupported))&&e.scriptCommonDrawMethod_.scaleX==1.0f&&e.scriptDrawQueue_.back().draw.scaleX==2.0f,"changedrawmethod updates future submissions without mutating queued entries");
  check(std::get<bool>(e.callScriptFunction("changedrawmethod",{std::uintptr_t(1),std::string("rotate"),90.0},streamCtx,streamUnsupported))&&e.scriptEntityDrawMethods_.at(1).rotate==90,"changedrawmethod stores entity-local render overrides used by actor rendering");
  e.callScriptFunction("clearscreen",{screen},streamCtx,streamUnsupported);e.callScriptFunction("changedrawmethod",{std::uintptr_t(0),std::string("scalex"),512.0},streamCtx,streamUnsupported);e.scriptDrawQueue_.clear();e.callScriptFunction("drawsprite",{spriteHandle,1.0,1.0,100.0,0.0},streamCtx,streamUnsupported);check(std::get<bool>(e.callScriptFunction("drawspriteq",{screen,0.0,100.0,100.0,1.0,0.0},streamCtx,streamUnsupported)),"drawspriteq renders a selected Z range into a retained subscreen");check(pixel(2,1)==0x2244CCu&&pixel(5,2)==0x2244CCu,"drawspriteq applies the snapshotted scale and requested queue offset to subscreen pixels");
  e.scriptDrawQueue_.clear();e.scriptFlushedDrawQueue_.clear();e.callScriptFunction("changedrawmethod",{std::uintptr_t(0),std::string("reset")},streamCtx,streamUnsupported);e.callScriptFunction("drawsprite",{spriteHandle,0.0,0.0,10.0,0.0},streamCtx,streamUnsupported);check(std::get<bool>(e.callScriptFunction("drawspriteq",{std::uintptr_t(0),0.0,0.0,20.0,3.0,4.0},streamCtx,streamUnsupported))&&e.scriptFlushedDrawQueue_.size()==1,"drawspriteq to vscreen captures an immediate queue replay instead of silently doing nothing");check(std::get<bool>(e.callScriptFunction("clearspriteq",{},streamCtx,streamUnsupported))&&e.scriptDrawQueue_.empty()&&e.scriptFlushedDrawQueue_.size()==1,"clearspriteq clears pending entries without erasing an already flushed vscreen replay");
  check(std::get<bool>(e.callScriptFunction("drawspritetoscreen",{spriteHandle,screen,4.0,4.0},streamCtx,streamUnsupported))&&pixel(4,4)==0x2244CCu,"drawspritetoscreen composites the sprite into its destination screen instead of the main frame");
  check(std::get<bool>(e.callScriptFunction("drawstringtoscreen",{screen,2.0,3.0,1.0,std::string("HUD")},streamCtx,streamUnsupported))&&e.scriptScreens_.at(screen).text.size()==1,"drawstringtoscreen keeps text attached to the off-screen surface");
  auto queueBefore=e.scriptDrawQueue_.size();check(std::get<bool>(e.callScriptFunction("drawscreen",{screen,10.0,20.0,300.0,4.0},streamCtx,streamUnsupported))&&e.scriptDrawQueue_.size()==queueBefore+1,"drawscreen queues the composed off-screen surface for presentation");auto&screenCmd=e.scriptDrawQueue_.back();check(screenCmd.kind==ScriptDrawCommand::Kind::Screen&&screenCmd.screen==screen&&screenCmd.x==10&&screenCmd.y==20&&screenCmd.z==300&&screenCmd.blend==4,"drawscreen preserves screen handle, position, layer and OpenBOR blend mode");
  check(std::get<bool>(e.callScriptFunction("clearscreen",{screen},streamCtx,streamUnsupported))&&e.scriptScreens_.at(screen).text.empty()&&std::all_of(surface.bgra.begin(),surface.bgra.end(),[](unsigned char v){return v==0;}),"clearscreen clears only the selected off-screen surface");
  check(std::get<bool>(e.callScriptFunction("free",{screen},streamCtx,streamUnsupported))&&!e.scriptScreens_.contains(screen),"free releases allocscreen handles without affecting sprite handles");
  // v0.34.32: direct drawing, gameplay, fglayer/frontpanel and HUD share one Z/sortid queue.
  e.scriptDrawQueue_.clear();e.scriptFlushedDrawQueue_.clear();int actorDepth=(int)std::lround(e.playerZ_);int actorSort=e.bindingSortId(1);
  e.callScriptFunction("drawsprite",{spriteHandle,0.0,0.0,(double)(actorDepth-1),(double)actorSort},streamCtx,streamUnsupported);
  e.callScriptFunction("drawsprite",{spriteHandle,0.0,0.0,(double)actorDepth,(double)(actorSort-1)},streamCtx,streamUnsupported);
  e.callScriptFunction("drawsprite",{spriteHandle,0.0,0.0,(double)actorDepth,(double)(actorSort+1)},streamCtx,streamUnsupported);
  e.callScriptFunction("drawsprite",{spriteHandle,0.0,0.0,(double)(actorDepth+1),(double)actorSort},streamCtx,streamUnsupported);
  e.drawStage();check(!e.lastSceneQueueTrace_.empty(),"drawStage records the unified native scene queue");
  for(std::size_t i=1;i<e.lastSceneQueueTrace_.size();++i){auto&a=e.lastSceneQueueTrace_[i-1];auto&b=e.lastSceneQueueTrace_[i];check(a.z<b.z||(a.z==b.z&&(a.sortId<b.sortId||(a.sortId==b.sortId&&a.sequence<=b.sequence))),"unified scene queue is ordered by Z, sortid, then submission sequence");}
  auto findTrace=[&](int kind,int z,int sortId){for(std::size_t i=0;i<e.lastSceneQueueTrace_.size();++i){auto&t=e.lastSceneQueueTrace_[i];if(t.kind==kind&&t.z==z&&t.sortId==sortId)return i;}return e.lastSceneQueueTrace_.size();};
  auto actorIndex=findTrace(4,actorDepth,actorSort),belowIndex=findTrace(6,actorDepth-1,actorSort),sameBefore=findTrace(6,actorDepth,actorSort-1),sameAfter=findTrace(6,actorDepth,actorSort+1),aboveIndex=findTrace(6,actorDepth+1,actorSort);
  check(actorIndex<e.lastSceneQueueTrace_.size()&&belowIndex<actorIndex&&sameBefore<actorIndex&&sameAfter>actorIndex&&aboveIndex>actorIndex,"script sprite Z/sortid can render behind, between and in front of the native player");
  int minz=e.stage_?e.stage_->zMin:160,maxz=e.stage_?e.stage_->zMax:232;check(findTrace(1,minz-50,0)<e.lastSceneQueueTrace_.size(),"normal panels enter the shared queue at OpenBOR PANEL_Z");check(findTrace(2,190,0)<e.lastSceneQueueTrace_.size(),"fglayer depth enters the same shared scene queue");check(findTrace(3,minz-47,actorSort)<e.lastSceneQueueTrace_.size(),"native shadows enter the shared queue at OpenBOR SHADOW_Z");check(findTrace(7,maxz+50,0)<e.lastSceneQueueTrace_.size(),"frontpanel enters the shared queue at OpenBOR FRONTPANEL_Z");check(findTrace(8,maxz+10050,0)<e.lastSceneQueueTrace_.size(),"HUD enters the shared queue above frontpanel using the OpenBOR HUD_Z offset");
  auto temp=std::filesystem::temp_directory_path()/"obor-prototype-0343";std::filesystem::create_directories(temp);
  std::ofstream(temp/"proto.c")<<"void missing(); void main(){setglobalvar(\"called\",getglobalvar(\"called\")+1);missing();}";vm.setRoot(temp);
  result=vm.runFile("proto.c",ctx);check(result.ok&&result.unsupported.size()==1&&result.unsupported[0]=="missing"&&number(vm,"called")==1,"prototype is not mistaken for following main function body");
  result=vm.runAnimationCommand("no-file.c","setglobalvar(\"independent\",42); missing_helper(); setglobalvar(\"afterMissing\",7);",ctx);
  check(!result.ok&&number(vm,"independent")==42&&number(vm,"afterMissing")==7&&result.unsupported.size()==1,"missing helper does not suppress independent frame commands and retains failure");
  RuntimeEntity screenBound;screenBound.model=e.playerModel_;screenBound.alive=true;screenBound.visible=true;screenBound.worldX=e.cameraX_-50.0f;e.entities_.push_back(std::move(screenBound));auto&bound=e.entities_.back();ScriptContext boundCtx;boundCtx.entity=&bound;std::vector<std::string> unsupported;
  e.callScriptFunction("changeentityproperty",{std::uintptr_t((std::uintptr_t)&bound),std::string("subject_to_screen"),1.0},boundCtx,unsupported);
  check(bound.subjectToScreen,"subject_to_screen script property is stored on runtime entities");
  auto subject=e.callScriptFunction("getentityproperty",{std::uintptr_t((std::uintptr_t)&bound),std::string("subject_to_screen")},boundCtx,unsupported);
  check(std::get<bool>(subject),"subject_to_screen script property is readable");
  auto* ownerThrow=e.findAnimation(e.playerModel_,"freespecial2");bool ownerFired=false;auto ownerBefore=e.projectiles_.size();check(ownerThrow&&ownerThrow->throwFrame==1,"model-level projectile fallback fixture has authored throwframe");e.maybeSpawnProjectile(e.playerModel_,ownerThrow,1,e.playerWorldX_,e.playerZ_,e.playerAltitude_,1,true,ownerFired,nullptr,nullptr);check(ownerFired&&e.projectiles_.size()==ownerBefore+1&&e.projectiles_.back().model&&std::string(e.projectiles_.back().model->name)=="Knife","throwframe falls back to owner knife model when animation custknife and equipped weapon are absent");
  auto beforeProjectile=e.projectiles_.size();ScriptContext projectileCtx;projectileCtx.player=true;projectileCtx.playerIndex=0;unsupported.clear();
  auto projectileResult=e.callScriptFunction("projectile",{std::string("Knife"),120.0,205.0,14.0,1.0,0.0,0.0,0.0},projectileCtx,unsupported);
  check(unsupported.empty()&&std::get<std::uintptr_t>(projectileResult)!=0&&e.projectiles_.size()==beforeProjectile+1,"legacy projectile() script API spawns a native runtime projectile");
  const auto& spawnedProjectile=e.projectiles_.back();check(spawnedProjectile.model&&std::string(spawnedProjectile.model->name)=="Knife"&&spawnedProjectile.worldX==120.0f&&spawnedProjectile.z==205.0f&&spawnedProjectile.altitude==-14.0f&&spawnedProjectile.facing==1&&!spawnedProjectile.bomb,"projectile() absolute coordinates, altitude and knife type are preserved");
  e.playerWorldX_=100;e.playerZ_=180;e.playerAltitude_=-10;e.playerFacing_=-1;e.playerPaletteMap_=3;auto beforeEntities=e.entities_.size();unsupported.clear();
  auto spawn01=e.callScriptFunction("spawn01",{std::string("Enemy"),20.0,5.0,3.0},projectileCtx,unsupported);
  check(unsupported.empty()&&std::get<std::uintptr_t>(spawn01)!=0&&e.entities_.size()==beforeEntities+1,"native spawn01 fallback spawns an entity when legacy helper include is missing");
  auto&spawned01=e.entities_.back();check(spawned01.worldX==80.0f&&spawned01.z==183.0f&&spawned01.altitude==-15.0f&&spawned01.facing==-1,"spawn01 mirrors X by caller direction and preserves OpenBOR X/Z/A offsets");
  auto spawnMap=e.callScriptFunction("spawn01map",{std::string("Enemy"),0.0,0.0,0.0},projectileCtx,unsupported);check(std::get<std::uintptr_t>(spawnMap)!=0&&e.entities_.back().paletteMap==3,"spawn01map copies caller palette map");
  result=vm.runAnimationCommand("../outside.c","stamp(1);",ctx);check(!result.ok,"unsafe animation helper path remains rejected");
  result=vm.runAnimationCommand("no-file.c","stamp(1);",ctx);check(!result.ok&&result.error.find("not found")!=std::string::npos,"missing animation helper is reported as failure");
 }
};
int main(int argc,char**argv){try{if(argc!=2)return 2;RuntimeCompatibilityTest::run(argv[1]);std::cout<<"RUNTIME COMMANDS PASS\n";return 0;}catch(const std::exception&e){std::cerr<<"FAIL: "<<e.what()<<"\n";return 1;}}
