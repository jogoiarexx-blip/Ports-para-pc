void main(){setglobalvar("helperFrames",getglobalvar("helperFrames")+1);}
void stamp(int value){setglobalvar("stamp",value);}
