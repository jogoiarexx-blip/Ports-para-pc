#define DOUBLE(x) ((x)*2)
#define NEG (-2)
int inner(int x){ int value=900; return x+1; }
