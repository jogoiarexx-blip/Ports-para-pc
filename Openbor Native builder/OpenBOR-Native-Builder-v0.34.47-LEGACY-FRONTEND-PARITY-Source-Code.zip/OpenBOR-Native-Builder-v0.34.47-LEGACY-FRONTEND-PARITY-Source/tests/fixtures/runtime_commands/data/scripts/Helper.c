#import "DATA/SCRIPTS/library/inner.H"
void stamp(int value){setglobalvar("stamp",value);}
void main(){setglobalvar("helperFrames",getglobalvar("helperFrames")+1);}
void collect(string label,void handle){
 int x=7;
 setglobalvar("scopeInner",inner(x));
 setglobalvar("scopeOuter",x);
 setglobalvar("label",label);
 setglobalvar("actor",handle);
 if(0){setglobalvar("bad",-3);}
 int a=0 && setglobalvar("bad",1);
 int b=1 || setglobalvar("bad",2);
 setglobalvar("negativeBranch",0 ? -7 : +4);
 setglobalvar("macro",DOUBLE(3)+NEG);
 int i;
 for(i=0;i<2;i++){ if(i<0){setglobalvar("bad",!(-1));} }
 setlocalvar("persistent",77);
}
void bump(){setglobalvar("order",getglobalvar("order")*10+2);}
