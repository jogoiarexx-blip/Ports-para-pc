#!/usr/bin/env python3
"""Validate real conversion and portable ZIP under Unicode paths on Linux.
Usage: python3 tests/test-unicode-inputs.py /path/to/builder output [--package]
"""
import argparse,json,struct,subprocess,zipfile,shutil
from pathlib import Path

def create_pak(out,encoding):
 entries={'data/models.txt':'load Hero data/chars/herói.txt\n','data/levels.txt':'set Test\nfile data/levels/ação.txt\n','data/chars/herói.txt':'name Hero\ntype player\nhealth 100\nanim idle\nloop 1\nframe none\n','data/levels/ação.txt':'direction right\n'}
 records=[]
 with out.open('wb') as f:
  f.write(b'PACK'+struct.pack('<I',0))
  for name,text in entries.items():
   data=text.encode(encoding);offset=f.tell();f.write(data);records.append((name.encode(encoding)+b'\0',offset,len(data)))
  index=f.tell()
  for name,offset,size in records:f.write(struct.pack('<III',12+len(name),offset,size)+name)
  f.write(struct.pack('<I',index))

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('builder',type=Path);p.add_argument('output',type=Path);p.add_argument('--package',action='store_true');a=p.parse_args()
 builder=a.builder.resolve();root=a.output.resolve()/'ação 日本語 🎮 %USERPROFILE% & jogos';root.mkdir(parents=True,exist_ok=True)
 def run(args,name):
  log=root/(name+'.log')
  with log.open('w') as f:r=subprocess.run([str(builder),*map(str,args)],stdout=f,stderr=subprocess.STDOUT)
  if r.returncode:raise RuntimeError(name+'\n'+log.read_text()[-4000:])
 fixture=Path(__file__).resolve().parent/'fixtures'/'side_scroll';folder=root/'pasta-ação';shutil.copytree(fixture,folder,dirs_exist_ok=True)
 utf8=root/'jogo-ação-UTF8.pak';legacy=root/'jogo-ação-1252.pak';create_pak(utf8,'utf-8');create_pak(legacy,'cp1252')
 archive=root/'arquivo-ação.zip'
 with zipfile.ZipFile(archive,'w') as z:
  for f in folder.rglob('*'):
   if f.is_file():z.write(f,'Bundle-ação/'+f.relative_to(folder).as_posix())
 nested=root/'engine-ação.zip'
 with zipfile.ZipFile(nested,'w') as z:z.write(legacy,'OpenBOR-ação/Paks/jogo-ação.pak')
 for name,source in [('folder',folder),('pak-utf8',utf8),('pak-1252',legacy),('zip',archive),('zip-pak',nested)]:
  out=root/('port-ação-'+name);run(['convert',source,out],name);data=json.loads((out/'reports'/'analysis.json').read_text(encoding='utf-8'))
  assert data['models']>0,name
  assert (out/'runtime'/'include'/'PathEncoding.hpp').exists(),name
  if name in ('pak-utf8','pak-1252','zip-pak'):
   assert data['models']==1 and data['stages']==1,name
   assert (out/'assets'/'openbor-data'/'chars'/'herói.txt').exists(),name
   assert (out/'assets'/'openbor-data'/'levels'/'ação.txt').exists(),name
  print('PASS CLI '+name,flush=True)
 run(['analyze',legacy],'default-analysis');assert (root/(legacy.stem+'-analysis')/'analysis.json').exists();print('PASS Unicode default analysis',flush=True)
 run(['convert',legacy],'default-port');port=root/(legacy.stem+'-Native-Port');assert (port/'runtime'/'CMakeLists.txt').exists();print('PASS Unicode default port',flush=True)
 if a.package:
  run(['package',port],'package');archive=root/(port.name+'-Portable-Host.zip')
  with zipfile.ZipFile(archive) as z:
   names=z.namelist();assert z.testzip() is None
   for suffix in ['/chars/herói.txt','/levels/ação.txt','/openbor-port']:assert any(n.endswith(suffix) for n in names),suffix
  print('PASS Unicode portable ZIP with compiled runtime',flush=True)
 print('ALL UNICODE INPUT TESTS PASS',flush=True)
if __name__=='__main__':main()
