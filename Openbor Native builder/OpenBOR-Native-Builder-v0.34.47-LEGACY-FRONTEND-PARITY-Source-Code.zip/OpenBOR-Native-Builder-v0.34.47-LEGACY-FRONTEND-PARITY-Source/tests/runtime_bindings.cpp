#include "Engine.hpp"
#include <iostream>
#include <stdexcept>
#include <algorithm>
struct RuntimeCompatibilityTest {
 static void check(bool v,const char*s){if(!v)throw std::runtime_error(s);std::cout<<"PASS: "<<s<<"\n";}
 static void run(const std::filesystem::path&root){
  Engine e;check(e.initialize(root),"binding fixture initializes");e.config_.autoPreviewMusic=false;e.tickCounter_=1;
  auto hero=e.findCharacter("Hero");RuntimeEntity child;child.model=hero;child.health=child.maxHealth=100;child.worldX=200;child.z=160;child.altitude=-3;child.animation.setAnimation(e.findAnimation(hero,"idle"));
  e.entities_.clear();e.entities_.push_back(child);auto h=std::uintptr_t((std::uintptr_t)&e.entities_[0]);auto&c=e.entities_[0];
  e.playerWorldX_=100;e.playerZ_=180;e.playerAltitude_=-20;e.playerFacing_=1;
  std::vector<std::string> u;
  auto bind=[&](std::vector<ScriptValue>a){u.clear();auto v=e.callScriptFunction("bindentity",a,e.playerScriptCtx_,u);check(std::holds_alternative<std::monostate>(v),"bindentity returns empty variant");};
  bind({h,std::uintptr_t(1),10.0,2.0,5.0,1.0,0.0});
  check(c.worldX==110&&c.z==182&&c.altitude==-25&&c.facing==1,"binding applies x z and OpenBOR altitude offsets immediately");
  check(u.empty()&&e.bindingSortId(h)==e.bindingSortId(1)-1,"default binding sort id draws child behind target at same depth");
  e.playerFacing_=-1;e.playerWorldX_=120;e.applyEntityBindings();check(c.worldX==110&&c.facing==-1,"target turn mirrors x offset and same direction");
  bind({h,std::uintptr_t(1),0.0,0.0,0.0,-1.0});check(c.facing==1,"opposite binding direction follows source enum");
  bind({h,std::uintptr_t(1),std::uintptr_t(0),std::uintptr_t(0),std::uintptr_t(0),-2.0});check(c.facing==-1,"forced left direction supported");
  auto x=c.worldX,z=c.z,alt=c.altitude;e.playerWorldX_=300;e.playerZ_=200;e.playerAltitude_=-60;e.applyEntityBindings();check(c.worldX==x&&c.z==z&&c.altitude==alt,"NULL offsets leave axes unbound");
  bind({h,std::uintptr_t(1),7.9});check(c.worldX==293&&c.z==z&&c.altitude==alt,"integer offset truncation and omitted axes match OpenBOR");
  bind({h,std::uintptr_t(0)});x=c.worldX;e.playerWorldX_=400;e.applyEntityBindings();check(c.worldX==x&&!e.entityBindings_.contains(h),"NULL target releases entity without binding to context actor");
  e.playerScriptCtx_.entity=&c;bind({std::uintptr_t(0),std::uintptr_t(1),1.0});check(!e.entityBindings_.contains(h),"NULL actor does not alias context self");
  bind({h,h});check(std::find(u.begin(),u.end(),"bindentity-cycle")!=u.end()&&!e.entityBindings_.contains(h),"self binding rejected with diagnostic");
  bind({h,std::uintptr_t(999999)});check(u.size()==1&&u[0]=="bindentity-invalid-target","invalid target rejected safely");
  e.entities_.push_back(child);auto h2=std::uintptr_t((std::uintptr_t)&e.entities_[1]);bind({h,std::uintptr_t(1),10.0,2.0,3.0,1.0});bind({h2,h,4.0,1.0,2.0,1.0});e.playerFacing_=1;e.playerWorldX_=500;e.applyEntityBindings();
  check(e.entities_[1].worldX==514&&e.entities_[1].z==203&&e.entities_[1].altitude==-65,"binding chain follows updated root target in dependency order");
  bind({h,h2,1.0});check(std::find(u.begin(),u.end(),"bindentity-cycle")!=u.end(),"indirect binding cycle rejected");
  RuntimeCoopPlayer cp;cp.model=hero;cp.health=cp.maxHealth=100;cp.worldX=600;cp.z=150;cp.altitude=-8;cp.facing=-1;cp.animation.setAnimation(e.findAnimation(hero,"idle"));e.coopPlayers_.push_back(cp);
  bind({h,std::uintptr_t(2),5.0,3.0,2.0,1.0});check(c.worldX==595&&c.z==153&&c.altitude==-10&&c.facing==-1,"entity follows cooperative actor");
  bind({std::uintptr_t(1),std::uintptr_t(2),8.0,4.0,1.0,1.0});check(e.playerWorldX_==592&&e.playerZ_==154&&e.playerAltitude_==-9,"player can be bound to cooperative actor");
  bind({std::uintptr_t(1),std::uintptr_t(0)});bind({h2,std::uintptr_t(0)});bind({std::uintptr_t(2),h2,1.0,1.0,1.0});check(e.entityBindings_.contains(2),"cooperative actor can be a binding child");bind({std::uintptr_t(2),std::uintptr_t(0)});
  e.playerFacing_=1;e.playerWorldX_=100;e.playerZ_=180;e.playerAltitude_=-10;
  bind({h,std::uintptr_t(1),10.0,2.0,3.0});c.scriptVelocityX=7;c.scriptVelocityZ=9;e.updateEntities();check(c.worldX==e.playerWorldX_+10&&c.z==e.playerZ_+2&&c.altitude==e.playerAltitude_-3,"real entity update restores bound axes after movement and gravity");
  bind({h,std::uintptr_t(0)});x=c.worldX;e.updateEntities();check(c.worldX==x+7,"unbinding releases normal entity movement");
  e.player_.setAnimation(e.findAnimation(hero,"attack1"));bind({h,std::uintptr_t(1),0.0,0.0,0.0,1.0,3.0});check(c.animation.animation()==e.player_.animation(),"animation-target flag copies matching animation");
  e.player_.setFrame(1);e.applyEntityBindings();check(c.animation.frameIndex()==1,"frame-target flag follows target frame");
  generated::Character onlyIdle=*hero;generated::Animation onlyAnim=*e.findAnimation(hero,"idle");onlyIdle.animations=&onlyAnim;onlyIdle.animationCount=1;c.model=&onlyIdle;c.visible=c.alive=true;
  bind({h,std::uintptr_t(1),0.0,0.0,0.0,0.0,5.0});check(!c.visible&&!c.alive&&!e.entityBindings_.contains(h),"animation remove flag removes child with missing target animation");
  c.model=&onlyIdle;c.visible=c.alive=true;c.animation.setAnimation(&onlyAnim);bind({h,std::uintptr_t(1),0.0,0.0,0.0,0.0,10.0});check(!c.visible&&!c.alive,"frame remove flag removes child without matching frame");
  c.model=hero;c.visible=c.alive=true;bind({h,std::uintptr_t(1),0.0,0.0,0.0,0.0,16.0});check(std::find(u.begin(),u.end(),"bindentity-config:16")!=u.end(),"defined animation config remains explicitly incomplete");
  bind({h,std::uintptr_t(1),0.0,0.0,0.0,0.0,0.0,3.0});check(e.bindingSortId(h)==e.bindingSortId(1)+3,"explicit binding sort offset supported");
  bind({h,std::uintptr_t(1),9.0,8.0,7.0});bind({h,std::uintptr_t(1),std::uintptr_t(0),std::uintptr_t(0),std::uintptr_t(0),2.0,1344.0});
  check(c.worldX==9&&c.z==8&&c.altitude==-7&&c.facing==1,"level-axis flags reuse retained offsets independently of target coordinates");
  e.playerAlive_=false;e.applyEntityBindings();check(!e.entityBindings_.contains(h),"binding clears when target is removed");
 }
};
int main(int argc,char**argv){try{if(argc!=2)return 2;RuntimeCompatibilityTest::run(argv[1]);std::cout<<"RUNTIME BINDINGS PASS\n";return 0;}catch(const std::exception&e){std::cerr<<"FAIL: "<<e.what()<<"\n";return 1;}}
