# Validação v0.34.46

## Performance

Same JLU 600-frame headless workload on the validation host:

- pre-cache runtime: 0.35 s wall / 0.32 s user CPU
- v0.34.46: 0.07 s wall / 0.06 s user CPU
- measured reduction: ~80% wall time and ~81% user CPU for this simulation workload

The improvement comes from caching preprocessed/tokenized ScriptVM programs. It is not presented as a direct Windows FPS multiplier because renderer/GPU costs differ.

## Authored screen flow

JLU generated `reports/frontend-flow.txt` reports:

- logo: yes
- intro: yes
- title/titleb: yes
- how-to: yes
- game-over: yes
- hiscore: yes
- complete: yes
- loading/loading2: yes
- campaign select entries: 54
- campaign scene files: 44 (1 pre-stage + 43 post-stage)
- generated cutscene animation steps: 184

## Regression

- Builder CTest: 100%
- runtime tests: 11/11 PASS
- JLU behavior suite: 54/54 PASS
- JLU smoke: 600 frames PASS
- Compatibility: 92,929 supported, 0 partial, 0 unsupported, 0 unknown

## Windows

Both binaries cross-compiled successfully as PE32+ x64. Visual D3D11 execution cannot be performed on the Linux validation host, so the Windows rendering result still requires the user's real-PC run.
