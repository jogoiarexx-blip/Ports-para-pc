# Validacao — OpenBOR Native Builder v0.34.31

## Builder
- Configuracao CMake Release: PASS.
- Compilacao do Builder e da regressao: PASS.
- `ctest --output-on-failure`: **1/1 PASS**.

## Runtime gerado
Executadas a partir de ports gerados novamente pelo Builder desta versao:

- runtime_effects: PASS
- runtime_contacts: PASS
- runtime_grabs: PASS
- runtime_bindings: PASS
- runtime_unicode: PASS
- runtime_terrain: PASS
- runtime_energy: PASS
- runtime_commands: PASS
- runtime_compatibility: PASS
- runtime_endlevel: PASS

**Resultado: 10/10 PASS.**

## Cobertura nova — Direct Drawing
- `setdrawmethod(NULL(),...)` configura drawmethod comum com escala fixa `256 = 100%`.
- `changedrawmethod` altera estado global ou por entidade/jogador e suporta reset e propriedades centrais.
- `drawsprite` preserva copia do drawmethod e `sortid` no momento da submissao.
- `drawspriteq` seleciona faixa Z, aplica offset e rasteriza para subscreen ou replay da superficie principal sem remover a origem.
- `clearspriteq` remove a fila pendente e preserva replay ja descarregado.
- Sprite/subscreen usa transformacao nativa de scale/flip/shift/fill/tint/rotate e alpha/blend.
- Override de drawmethod por entidade entra no frame nativo do ator.

## Limites mantidos visiveis
- O Direct Drawing de script ainda nao compartilha a mesma estrutura de fila com backgrounds, atores, sombras e HUD; ordenacao Z cruzada e parcial.
- Queue locking/`newonly` historico ainda nao esta completo.
- Clip/channel/center/repeat/span/water do drawmethod moderno continuam parciais.

## Windows
Um novo PE Windows x64 nao foi produzido neste ambiente. O pacote fonte deve ser recompilado com MinGW/MSVC ou CI Windows antes de publicar um Portable v0.34.31.
