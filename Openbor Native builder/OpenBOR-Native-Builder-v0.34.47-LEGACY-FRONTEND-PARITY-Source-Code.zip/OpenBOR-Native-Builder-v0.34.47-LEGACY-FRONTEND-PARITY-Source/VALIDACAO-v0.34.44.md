# Validação v0.34.44 — JLU Hero Behavior Matrix

Expected release gates:

- Builder Release compilation: PASS
- CTest regression: PASS
- full runtime test suite: PASS
- JLU compatibility: 92,929 SUPPORTED / 0 PARTIAL / 0 UNSUPPORTED / 0 UNKNOWN
- JLU `--behavior-suite=jlu`: 54 PASS / 0 FAIL
- continuous JLU smoke: 600 frames / RC=0
- Final Fight compatibility anchor: unchanged, 15,477 SUPPORTED / 0 PARTIAL / 0 UNSUPPORTED / 0 UNKNOWN

The release ships a real x64 PE build of the OpenBOR Native Builder produced with LLVM-MinGW. Generated runtime cross-compilation is also used as a C++20/Windows portability gate; the JLU Windows runtime is included when that gate passes.
