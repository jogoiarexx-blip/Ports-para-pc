# v0.34.47 - Legacy Frontend Parity

- Restores OpenBOR's legacy frontend state flow: PRESS START -> Start Game/Options/How To Play/Hall Of Fame/Quit -> Choose Mode -> New Game/Load Game/Back -> Game Mode.
- Uses title.gif before PRESS START and titleb.gif for post-start menus.
- Replaces fixed-cell bitmap text with OpenBOR-style clipped variable glyph widths; honors menu.txt fontmonospace and direct font 0/1/2 menu roles.
- Adds legacy centered/column menu positioning based on logical resolution and real font metrics.
- Keeps DirectWrite only as Unicode/missing-font fallback and preserves v0.34.46 profiling/performance work.

# v0.34.46 - Original bitmap fonts + Windows performance profiler

- Frontend, HUD and script text now prefer the original OpenBOR `font.gif`, `font2.gif`... sheets instead of DirectWrite when those assets exist.
- Font sheets are decoded once, split into their native 16x16 glyph grid and cached as sprite glyphs, so text participates in the existing GPU texture cache/atlas/batching path.
- `ofont.gif`, `ofont2.gif`... are preferred for selected/highlighted text when matching variants exist; DirectWrite remains a Unicode/missing-font fallback.
- Script `drawstring`, subscreen strings and persistent `settextobj` preserve the authored OpenBOR font index rather than converting it into a generic point size.
- Adds `--profile-game` and `--profile-frames=N`. The runtime runs an unlimited/V-Sync-off gameplay pass and writes `reports/performance-windows.txt` with average FPS, frame time, renderer time and Present time.
- Generated ports include `MEDIR-FPS-WINDOWS.cmd` so the Windows measurement can be run without command-line setup.
- Adds `reports/bitmap-font-audit.txt`; JLU v3.0 exposes 8 original font/outline sheets to the native runtime.
- Keeps the v0.34.45 frontend-flow and ScriptVM-token-cache work intact, with JLU at 92,929 SUPPORTED / 0 PARTIAL / 0 UNKNOWN, 54/54 behavior probes and 600-frame smoke PASS.
- Both Builder and JLU runtime cross-compile as real Windows x64 PE executables after the font/profiler changes.

# v0.34.45 - JLU frontend flow + ScriptVM performance

- Restores the authored OpenBOR startup flow when assets exist: `bgs/logo`, optional `scenes/logo.txt`, `scenes/intro.txt`, title/Press Start, then the native menu.
- Adds HOW TO PLAY from `scenes/howto.txt`, authored game-over background/scene, Hall-of-Fame background, completed `titleb`, stage-complete, and 1P/2P loading backgrounds.
- Keeps ordered campaign presentation metadata; JLU audit preserves all 54 authored `select` entries and all 44 `scene` entries (1 pre-stage + 43 post-stage files), producing 184 cutscene animation steps.
- Corrects legacy scene skip semantics: `skipone` skips the current animation while ordinary skip exits the scene file; `noskip` remains authoritative.
- Removes the artificial 250 ms delay from stage transitions. Loading art is presented while actual stage loading occurs.
- Adds a preprocessed/tokenized ScriptVM program cache for static scripts and authored animation commands; repeated update/think/key hooks no longer preprocess and lex the same source each invocation.
- JLU 600-frame headless simulation benchmark drops from 0.35 s wall / 0.32 s CPU to 0.07 s wall / 0.06 s CPU on the validation host (~80% lower measured simulation time on this workload). This is a CPU simulation benchmark, not a claim of 5x Windows FPS.
- Adds `reports/frontend-flow.txt` so generated ports report which authored system screens and campaign presentation entries are wired into the native runtime.
- Keeps JLU at 92,929 SUPPORTED / 0 PARTIAL / 0 UNKNOWN and 54/54 behavior probes.
- Both Native Builder and generated JLU runtime cross-compile successfully as real Windows x64 PE executables.

# v0.34.44 - JLU hero behavior matrix

- Expands generated `--behavior-suite=jlu` from 27 system probes to a 54-probe hero matrix while preserving deterministic headless execution.
- Adds authored power coverage for Superman heat vision, Shazam lightning, Wonder Woman BalaW bomb, Green Arrow explosive/standard arrows, Aquaman wave, Cyborg cannon, Green Lantern construct and Flash speed trail/binding.
- Executes the keyscript matrix for the core playable heroes and validates authored waiting/logo summons remain parent-bound.
- Preserves all v0.34.43 system probes (Batman/Batrang, Vixen helper arity, grab/throw, obstacle/basemap/script behavior) as the lower layer of the same suite.
- Adds Builder regression guards so future runtime-template changes cannot silently remove the hero matrix.
- Windows delivery now includes a real cross-compiled x64 PE Native Builder executable; the same cross-build pass is also used as a portability gate for generated runtimes.
- Replaces removed C++20 `shared_ptr::unique()` use with `use_count()!=1`, allowing generated runtimes to compile cleanly under LLVM-MinGW/libc++ as well as GCC/libstdc++.
- Fixes the Windows fallback compositor declaration order so `blendChannel` is visible to D3D11/CPU fallback code under real Windows compilation.
- Adds MinGW `-municode` for the generated Windows GUI runtime so the existing `wWinMain` entrypoint links correctly under LLVM-MinGW.
- Removes the remaining speculative Visual Studio 2026 CMake-path probe from the Builder executable; VS2022 remains the supported Windows build path.

# v0.34.43 - JLU behavioral regression suite

- Adds generated runtime `--behavior-suite[=jlu]` mode with deterministic, reportable behavior probes.
- JLU profile exercises real model registry/loadmodel, persistent text objects, branch state, Batman ironkey ScriptVM, summon/child binding, model-level Batrang projectile fallback, Vixen five-argument position helper, grab/throw, and FlechaPIA obstacle collision.
- Adds generic regression coverage for model-level `knife` + `throwframe` fallback.
- Writes `reports/behavior-suite-<profile>.txt` and returns non-zero on behavior regressions.
- Preserves v0.34.42 short-path Windows build flow and all previous compatibility behavior.
- Corrects OpenBOR legacy default `subject_to_gravity`: enabled by default for normal models while explicit `subject_to_gravity 0` still disables it; fractional `antigravity` now has permanent runtime regression coverage.
- Full native runtime suite expanded and revalidated after the gravity-default correction.

# v0.34.42 - Windows short-path build fix

- Windows portable builds now use a short `%TEMP%\OpenBOR-Native-Build\win64-<pid>` CMake/MSBuild directory, avoiding FileTracker FTK1011 failures caused by deeply nested port paths.
- Visual Studio 17 2022 + MSVC is now the primary generator/toolchain.
- Removed speculative Visual Studio 18 2026 probing.
- ClangCL is attempted only when actually installed (portable script) or explicitly requested with `OPENBOR_USE_CLANGCL=1` (Builder command path).
- Failed temporary build trees are preserved for diagnosis; successful ones are cleaned automatically.

# v0.34.41 — Justice League United compatibility crossfeed

- Uses JLU v3.0 as a large-module regression target: 447 models, 118 stages, 3,835 animations and more than 92k command occurrences.
- Reworked analyzer path resolution/indexing so `data/...` references do not trigger repeated recursive scans; JLU analysis falls from multi-minute/non-completing runs to roughly 12 seconds on the same workspace.
- ScriptVM custom helpers now resolve overloads by arity; JLU `keymove` calls are certified instead of producing 1,312 false partials.
- Adds runtime-backed JLU/OpenBOR semantics for model `layer`, typed `defense normalN`, `subject_to_obstacle`, static `basemap` + `subject_to_basemap`, `noreflect`, `nodieblink`, persistent text objects and registered-model `loadmodel`.
- Reproduces OpenBOR v3 `dying` with the exact stateful two-threshold cadence by replaying its 200 Hz legacy clock inside the native 60 Hz simulation.
- Analyzer now distinguishes authored custom-helper arity defects and reports the exact expected/provided count, matching OpenBOR's legacy `CHECKARG` rejection instead of mislabeling them as generic runtime gaps.
- JLU original reaches 92,928 SUPPORTED, 1 PARTIAL, 0 UNSUPPORTED, 0 UNKNOWN; the lone partial is the source-authored Vixen `position` call with one missing argument.
- AI-Repair now emits a high-confidence, auditable trailing-argument patch only when multiple valid sibling helper calls unanimously prove the missing value; it never mutates the original PAK/source. Applying the JLU Vixen suggestion produces 92,929 SUPPORTED, 0 PARTIAL, 0 UNSUPPORTED, 0 UNKNOWN.

# v0.34.40 — shader transforms + Texture2DArray atlas

- Moved entity flip and OpenBOR drawmethod scale/shear/rotation/fill/tint from CPU bitmap materialization to per-instance D3D11 shader parameters on the primary GPU path.
- Replaced per-sprite transformed GPU copies with the original sprite plus `SpriteInstance` data.
- Added `DrawInstanced` batching while keeping command order stable.
- Added shelf-packed 2D atlases stored as `Texture2DArray` layers for differently-sized sprites; oversized sprites use dedicated one-layer array textures.
- Added bounded settings: `gpu_shader_transforms`, `gpu_texture_atlas`, `gpu_atlas_size`, `gpu_atlas_layers`.
- Kept the old transform cache exclusively for CPU fallback frames and preserved exact legacy blend 3-6 fallback.
- Added low-VRAM residency safety so a batch never depends on a texture resource that can be evicted while the batch is being assembled.
- Final Fight X regression remains 15,477 supported occurrences with zero partial/unsupported/unknown.

# v0.34.39 — D3D11 persistent textures + sequence-preserving batching

- Renderer records draw commands in authored order and executes them as a GPU scene when safe.
- Sprite/transform cache IDs now back persistent immutable D3D11 textures instead of uploading the composed 1280x960 CPU frame every compatible frame.
- Consecutive instances of the same sprite are batched into one dynamic-vertex-buffer draw.
- HUD rectangles, lines, and DirectWrite text can render directly into the D3D11 scene target through Direct2D interop.
- Legacy blend modes 3-6 keep exact behavior by automatically falling back to the proven CPU compositor for that frame.
- Back-buffer RTV is retained instead of recreated every frame.
- New graphics settings: `gpu_sprite_batching` and `gpu_texture_cache_mb`.

# v0.34.38 — HD renderer performance + WebP crossfeed

- Direct framebuffer compositing replaces per-sprite GDI DC/DIB allocation and destruction.
- Decoded sprite cache shares pixel buffers instead of repeatedly decoding/copying HD sprites.
- Drawmethod transform cache reuses flip/scale/shear/tint/rotation results; identity draws bypass transform allocation entirely.
- Memory budgets: `sprite_cache_mb` and `transform_cache_mb`.
- HD resolver prefers `.webp` when `prefer_webp=true`, then safely falls back to PNG/GIF/BMP/PCX/original.
- Lossless WebP is recommended so remaster pixels and alpha remain exact.
- Logical 320x240 gameplay geometry remains isolated from physical 4x rendering.

# v0.34.37 — HD/HiDPI renderer crossfeed

- Added runtime HD override resolver for `assets/openbor-data-hd`.
- Added strict per-asset uniform-scale validation and original-asset fallback.
- Added renderer supersampling while preserving logical OpenBOR coordinates.
- Added HD-aware animation frame validation.
- Added regression coverage for generated HD renderer/config.

# v0.34.36 — Final Fight crossfeed

- Promoted verified Final Fight X combat semantics into the generic runtime (`defense all`, `attackone`, per-frame contacts).
- Removed false UNKNOWNs from mojibake readme files found in legacy PAKs.
- Added regression checks so future games inherit these fixes automatically.

# Changelog — v0.34.35

## v0.34.35
- Native per-stage gravity/maxfallspeed/maxtossspeed.
- Native legacy stun modifier without forced palette remap.
- Eliminated false UNKNOWNs from script-owned TXT/CFG data tables under data/scripts.
- Recognizes subject_to_basemap as explicit PARTIAL and accepts agression alias.

# Changelog — v0.34.34

## JLU UNKNOWN compatibility pass
- `parrow`/`parrow2` ganham modelo gerado, offsets e desenho durante a janela de `makeinv`.
- `mprate` e `typemp` passam a controlar recuperacao nativa de MP por tempo/acerto/desativada.
- `idle` por frame permite interrupcao por novo input.
- `fshadow` passa a sobrescrever a sombra do modelo por frame.
- `dive` aplica velocidade horizontal/vertical da animacao.
- `freeze` passa a ser um ataque nativo tipo freeze com duracao autorada, `fmap`, noflash, pausetime e z-depth.
- `allowselect` filtra a lista de personagens por stage/set.
- `parrow`, `parrow2`, `mprate`, `idle`, `fshadow`, `dive`, `freeze`, `allowselect` e `typemp` saem de UNKNOWN quando usados nas formas implementadas.

## Debug visual
- `show_bbox` e `show_attack_box` passam a `false` por padrao; hitboxes continuam disponiveis no menu de debug.

## Testes
- Regressao dedicada cobre parser, registry, analyzer e tabelas C++ geradas.
- Nova suite `runtime_legacy_unknowns` valida selecao, respawn, freeze, MP on-hit e dive em runtime.
- Bateria cumulativa: 11 suites de runtime.

---

# Changelog — v0.34.32

## Unified native scene queue
- Direct Drawing deixa de ser um passe separado depois dos atores: comandos de script entram na mesma fila Z/`sortid` de gameplay.
- Painel, sombras, `fglayer`, atores, projeteis, `frontpanel` e HUD recebem profundidades compativeis com os offsets historicos do OpenBOR.
- `drawsprite`/`drawscreen`/primitivas podem ficar atras, entre ou na frente de atores apenas pelo Z e `sortid`, sem hack de ordem fixa.
- Replays produzidos por `drawspriteq` tambem participam da fila compartilhada.
- `frontpanel` passa a usar xratio 1.5, evitando o scroll de background usado anteriormente por engano.
- Background e `bglayer` permanecem no passe de backdrop inferior, preservando a regra de serem as camadas de fundo.

## Testes
- CMake Release: PASS.
- Regression/ctest: 1/1 PASS.
- 10/10 suites de runtime: PASS.
- `runtime_commands` verifica Z abaixo/acima do jogador, desempate por `sortid`, e os offsets PANEL_Z/SHADOW_Z/FRONTPANEL_Z/HUD_Z.

---

# Changelog — v0.34.31

## Direct Drawing / ScriptVM
- `setdrawmethod` deixa de ser fallback/no-op e passa a manter drawmethod comum ou por entidade/jogador.
- `changedrawmethod` cobre reset, enabled/flag, scale X/Y, flip X/Y, shift X, alpha, remap/colourmap, fill color, rotate/fliprotate e tint mode/color.
- `drawsprite` captura uma copia imutavel do drawmethod no momento da submissao e preserva `sortid`.
- A fila de script ordena por Z, `sortid` e sequencia estavel.
- `drawspriteq` filtra min/max Z sem remover entradas, aplica dx/dy e rasteriza em subscreen; destino vazio cria replay para a superficie principal.
- `clearspriteq` limpa a porcao pendente sem invalidar replay ja descarregado.
- O transformador de imagem compartilhado aplica scale, flip, shift, fill, tint e rotate antes da composicao, incluindo subscreens.
- Drawmethod associado a ator e aplicado ao frame nativo da entidade durante o render.

## Compatibilidade honesta
- A fila de script ainda nao foi unificada fisicamente com a fila de backgrounds/atores/HUD; Z cruzado entre esses dois dominios continua parcial.
- Queue locking/`newonly` historico e propriedades avancadas de drawmethod (clip/channel/center/repeat/water) permanecem como trabalho de paridade, em vez de serem declarados completos.

## Testes
- CMake Release: PASS.
- Regression/ctest: 1/1 PASS.
- 10/10 suites de runtime: PASS.
- `runtime_commands` valida snapshot de drawmethod, escala fixa 256, `sortid`, override por entidade, `drawspriteq` em subscreen/vscreen e `clearspriteq`.

---

# Changelog — v0.34.30

## ScriptVM / native subscreens
- `allocscreen` deixa de retornar apenas um handle ficticio e passa a criar uma superficie BGRA independente com dimensoes reais e limites de seguranca.
- `clearscreen` limpa somente o subscreen selecionado; a fila principal de desenho deixa de ser apagada por engano.
- `drawboxtoscreen`, `drawlinetoscreen` e `drawdottoscreen` rasterizam diretamente no buffer off-screen, com blend opcional.
- `drawspritetoscreen` compoe o sprite no subscreen indicado em vez de vazar o desenho para o frame principal.
- `drawstringtoscreen` preserva texto associado ao subscreen e `drawscreen` apresenta a superficie com X/Y/Z/blend.
- `getgfxproperty` cobre width/height de sprites e subscreens; `free` libera ambos os tipos de handle.
- CompatibilityAnalyzer passa a reconhecer `drawlinetoscreen`/`drawdottoscreen` e identifica a cobertura como ScriptVM v0.34.30.

## Testes
- `runtime_commands` ganhou regressao para alocacao, raster off-screen, sprite, texto, drawscreen, clear e free.
- Fixture do analisador agora exercita a familia de subscreen APIs para impedir falso PARTIAL futuro.

---

# Changelog — v0.34.29

## Level-set lifecycle / ifcomplete
- `ifcomplete N` de `levels.txt` passa a fazer parte dos metadados gerados e do seletor nativo de campanhas.
- Contagem de conclusoes persistida em `saves/unlocks.ini`; level sets bloqueados exibem o requisito e recusam inicio antes do desbloqueio.
- `end`/`endlevel` em `levels.txt` marca o stage anterior como terminal da rota sequencial.
- Fases posteriores ao `end` continuam geradas e podem ser alcancadas por `branch`/`jumptobranch`.
- A progressao default agora respeita `setOrder`, impedindo cair automaticamente no set seguinte.
- `next` explicito ausente nao e tratado como conclusao valida e nao incrementa desbloqueios.

## Reconciliacao sem regressao
- Reintegrado o `TYPE_ENDLEVEL` da v0.34.26 entregue: `branch` em modelo, resolver case-insensitive, contato de jogador e `subtype both` para todos os jogadores ativos.
- A suite `runtime_endlevel` volta a fazer parte da validacao cumulativa, preservando simultaneamente file streams, StageInstruction/scroll e `nojoin/canjoin` das linhas posteriores.

## Testes
- CMake Release: PASS.
- Regression/ctest: 1/1 PASS.
- 10/10 suites de runtime: PASS.

---

# Changelog — v0.34.28

## StageInstruction / join gating
- O parser deixa de manter apenas um controle pendente por `at`: um mesmo ponto de fase pode carregar spawn, `wait`, `group`, `blockade` e `nojoin/canjoin` sem perder eventos.
- `at` passa a ser distribuido para todos os controles pendentes do mesmo bloco, preservando a ordem declarada e o `at` do spawn.
- `nojoin` e `canjoin` agora possuem estado executavel no runtime; `nojoin 1` e interpretado como booleano e pode ser aplicado imediatamente ou no `at` associado.
- `openborvariant("nojoin")`, `changeopenborvariant()` e `setopenborvariant()` compartilham o mesmo estado de join da fase.
- Entrada tardia nativa por gamepad foi adicionada para slots cooperativos contiguos e respeita o gate `nojoin/canjoin`.
- O novo jogador recebe spawn, contexto de script, palette/mapa, arma de fase e callbacks `joinN.c`/`joinall.c` quando disponiveis.
- O CompatibilityAnalyzer mantem `nojoin/canjoin` como PARTIAL por ocorrencia enquanto o frontend legado completo de selecao no momento do join ainda nao e reproduzido.

## Testes
- Regression/ctest cobre `spawn + nojoin + wait + group + blockade + at` no mesmo bloco e `canjoin` posterior.
- `runtime_compatibility` cobre gate fechado/aberto, entrada tardia de P2 e round-trip da variante `nojoin`.
- 1/1 teste CTest e 9/9 suites de runtime: PASS.

---

# Changelog — v0.34.27

## Stage scroll / StageInstruction fidelity
- `at` agora usa a posicao de scroll da fase, em vez da borda direita do viewport. Isso elimina disparos ate uma tela antes do ponto autorado.
- Em fases `direction left`, o progresso de `at` e convertido a partir da borda direita da fase, conforme a semantica original.
- O comprimento minimo da fase agora inclui todos os `at` de spawns e eventos, garantindo que gatilhos tardios sejam alcancaveis mesmo sem paineis/background largos.
- `coords X` de spawns passa a ser aplicado relativo a tela no instante real do spawn. Isso corrige entidades atrasadas por `group`, que antes usavam `at + coords` e podiam nascer fora da tela.
- `group min/max` usa a mesma normalizacao em todos os caminhos do runtime e continua persistente ate nova declaracao.
- A logica de alcance foi centralizada em `stageScrollPosition()`, `reachedStagePosition()` e `stageSpawnWorldX()`, removendo tres implementacoes divergentes.

## Testes
- Regression/ctest: 1/1 PASS.
- 9 suites de runtime: PASS.
- `runtime_compatibility` cobre trigger exato de `at`, alcance minimo de fase, spawn atrasado por `group` e coordenadas de `direction left`.

---

# Changelog — v0.34.26

## ScriptVM / file streams
- `ScriptFileStream` passa a preservar o buffer bruto e a posicao em bytes, aproximando a semantica do OpenBOR original.
- Implementados `getfilestreamline`, `getfilestreamposition`, `setfilestreamposition`, `filestreamappend`, `createfilestream` e `savefilestream`.
- `openfilestream(path, 1)` le da pasta portatil `saves`.
- `savefilestream` cria subpastas quando necessario e bloqueia caminhos absolutos ou com `..`.
- `getfilestreamargument` continua convertendo string/int/float e agora opera sobre a linha correspondente a posicao real do stream.
- CompatibilityAnalyzer atualizado para reconhecer as novas APIs sem falso PARTIAL.
- Parity Audit corrigido de `0.34.14` para `0.34.26`.

## Testes
- ctest/regression: 1/1 PASS.
- 9 suites de runtime: PASS.
- Novo runtime test cobre open/read line/read argument/next/seek/create/append/save/reopen/close.

---

# Changelog — v0.34.25

## Legacy water / stage motion
- `water` deixa de deslocar a imagem inteira e passa a usar deformacao horizontal por scanline em `rock 0`.
- `rock 1` usa perspectiva/parallax por linha, ampliando a superficie na direcao da area jogavel.
- `warp` e validado no intervalo legado 0-15 e controla a velocidade da animacao.
- `rock 0..3` passa a SUPPORTED por ocorrencia; modos 2/3 mantem o double-shake e rumble de cenario.
- O water overlay passa a ser ancorado diretamente no `BGHeight` da fase.

## Script include recovery
- Includes sao resolvidos case-insensitive.
- Se o caminho antigo nao existe, o Builder procura um unico arquivo com o mesmo basename dentro do data root.
- Includes ausentes redundantes deixam de gerar PARTIAL so por existirem.
- Se ainda houver chamada de funcao desconhecida, o relatorio mantem `api/function:<nome>` + `include-missing:<path>` de forma explicita.
- O ScriptVM aplica a mesma busca por basename unico em runtime antes de ignorar um include legado ausente.
- `spawn.h` continua usando os helpers nativos `spawn01`, `spawn01map` e `spawn000`.

## Validacao
- ctest/regression: 1/1 PASS.
- runtime_effects, contacts, grabs, bindings, unicode, terrain, energy, commands, compatibility: PASS.
- GoW: 2.783 SUPPORTED / 0 PARTIAL / 1 UNKNOWN; build + smoke 300 frames PASS.
- Evil Dead: 14.290 SUPPORTED / 0 PARTIAL / 0 UNKNOWN; build + smoke 300 frames PASS.

## v0.34.33 (local fix)
- Runtime generated ports now start with `show_bbox=false` and `show_attack_box=false` by default.
- Fixes visible green collision rectangles in gameplay unless the user explicitly enables debug overlays.
