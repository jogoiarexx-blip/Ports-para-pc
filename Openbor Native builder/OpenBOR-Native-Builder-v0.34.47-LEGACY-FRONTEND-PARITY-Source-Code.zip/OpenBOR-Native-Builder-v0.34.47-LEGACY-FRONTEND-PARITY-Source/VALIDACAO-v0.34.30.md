# Validacao — OpenBOR Native Builder v0.34.30

## Builder
- Configuracao CMake Release: PASS.
- Compilacao do Builder e da regressao: PASS.
- `ctest --output-on-failure`: **1/1 PASS**.

## Runtime gerado
Executadas a partir de ports gerados novamente pelo Builder desta versao:

- runtime_effects: PASS
- runtime_contacts: PASS
- runtime_grabs: PASS
- runtime_bindings: PASS
- runtime_unicode: PASS
- runtime_terrain: PASS
- runtime_energy: PASS
- runtime_commands: PASS
- runtime_compatibility: PASS
- runtime_endlevel: PASS

**Resultado: 10/10 PASS.**

## Cobertura nova — ScriptVM subscreens
- `allocscreen(w,h)` cria uma superficie nativa BGRA independente, com validacao de dimensoes e limite de memoria.
- `clearscreen(screen)` limpa somente a superficie alvo e o texto associado, sem apagar a fila principal de desenho.
- `drawboxtoscreen`, `drawlinetoscreen` e `drawdottoscreen` rasterizam no buffer off-screen, incluindo blend opcional.
- `drawspritetoscreen(sprite,screen,x,y)` compoe sprites carregados dentro da superficie alvo.
- `drawstringtoscreen` preserva texto ligado ao subscreen para ser apresentado com ele.
- `drawscreen(screen,x,y,z,lut)` agora enfileira e renderiza o subscreen, preservando posicao, profundidade e blend.
- `getgfxproperty` retorna width/height tanto para sprites quanto para subscreens.
- `free(handle)` libera sprites e subscreens criados pelo ScriptVM.
- CompatibilityAnalyzer reconhece `drawlinetoscreen` e `drawdottoscreen` sem falso aviso de API ausente.

## Windows
Um novo PE Windows x64 nao foi produzido neste ambiente. O pacote fonte deve ser recompilado com MinGW/MSVC ou CI Windows antes de publicar um Portable v0.34.30.
