# Validação — OpenBOR Native Builder v0.34.38

- Builder Release compile: PASS
- CTest regression: 100%, 0 failures
- Final Fight conversion: PASS
- Final Fight compatibility: 15,477 SUPPORTED / 0 PARTIAL / 0 UNSUPPORTED / 0 UNKNOWN
- Generated native runtime host build: PASS
- Gameplay smoke: 360 frames PASS
- HD conversion: 1,514 PNG -> lossless WebP, 0 RGBA mismatches
- HD byte reduction: 124,634,884 -> 67,391,136 bytes (-45.93%)
- Logical gameplay: 320x240
- HD render surface: 1280x960 (4x)
