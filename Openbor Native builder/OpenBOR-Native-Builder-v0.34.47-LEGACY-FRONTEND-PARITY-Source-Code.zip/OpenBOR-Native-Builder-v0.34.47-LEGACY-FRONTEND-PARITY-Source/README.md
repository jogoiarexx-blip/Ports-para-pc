# OpenBOR Native Builder v0.34.35

Versao focada em **compatibilidade real de mods OpenBOR**, com prioridade nos comandos UNKNOWN de maior frequencia encontrados no relatorio JLU.

## Melhorias principais

- `parrow` / `parrow2`: sprites e offsets de seta de respawn/invencibilidade sao preservados e exibidos durante `makeinv`.
- `mprate` + `typemp`: recuperacao de MP por tempo ou por acerto no runtime nativo.
- `idle`: frame pode ser interrompido por novo input, preservando a semantica de cancelamento legado.
- `fshadow`: override de sombra por frame, incluindo `none`/inherit e desligamento.
- `dive`: movimento horizontal/vertical autorado na animacao passa a ser executado.
- `freeze`: caixa de ataque, dano, duracao de congelamento, `fmap`, noflash, pausetime e z-depth sao transportados para o combate nativo.
- `allowselect`: cada fase/set pode restringir a lista nativa de personagens selecionaveis.
- Debug visual de bbox/attack box agora inicia desligado (`show_bbox=false`, `show_attack_box=false`).
- Preserva cumulativamente subscreens, drawmethod/sprite queue, fila grafica unificada, ifcomplete e TYPE_ENDLEVEL das versoes anteriores.

## Validacao real

- CMake Release + regression/CTest.
- Suite `runtime_legacy_unknowns` adicionada para os comandos acima.
- A bateria cumulativa passa a ter 11 suites de runtime.
- Windows x64 usa Visual Studio 2022/MSVC por padrao e compila em uma pasta curta de `%TEMP%` para evitar falhas do FileTracker em caminhos longos. ClangCL e apenas fallback opcional quando estiver instalado.

## Limites conhecidos

- `layer` encontrado em alguns modelos JLU permanece UNKNOWN ate a variante exata ser distinguida com seguranca; nao e reclassificado artificialmente.
- Entradas malformed/customizadas (`-`, tokens soltos, aliases de scripts ou comandos locais) continuam diagnosticadas individualmente.
- Algumas APIs de ScriptVM e propriedades historicas permanecem PARTIAL quando ainda nao existe comportamento nativo equivalente.
