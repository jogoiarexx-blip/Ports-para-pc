OpenBOR Native Builder v0.34.47 - Windows x64

Run OpenBOR-Native-Builder.exe with no arguments for the Windows file/folder picker,
or use it from cmd/PowerShell with analyze/convert/build/scan/audit/repair/package/test.
Source code is delivered separately in the Source-Code ZIP.
