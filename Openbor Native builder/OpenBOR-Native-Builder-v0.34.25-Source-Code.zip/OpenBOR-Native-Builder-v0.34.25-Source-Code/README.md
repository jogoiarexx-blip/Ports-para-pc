# OpenBOR Native Builder v0.34.25

Versao focada em fechar os ultimos PARTIAL encontrados nos testes reais de GoW e Evil Dead, sem hardcode de jogo.

## Melhorias principais

- `water {path} {warp}`: o overlay legado agora e renderizado no `BGHeight` com deformacao senoidal por scanline em `rock 0` e perspectiva/parallax em `rock 1`; `warp` 0-15 controla a velocidade. `rock 2/3` continuam movendo o cenario com double-shake/rumble nativos.
- `rock 0..3`: os quatro modos passam a ser certificados por ocorrencia como runtime-backed.
- Includes de script: recuperacao case-insensitive e por basename unico quando o helper foi movido para outra pasta.
- Include ausente redundante nao torna mais o arquivo inteiro PARTIAL. Se uma funcao realmente faltar, o analisador continua emitindo `api/function:<nome>` e o include ausente associado.
- `library/spawn.h` continua usando os shims nativos `spawn01`, `spawn01map` e `spawn000`.
- O runtime tambem tenta recuperar includes realocados antes de desistir; includes ausentes sao adiados e a falha e registrada somente se um simbolo realmente for chamado sem implementacao.
- Mantidas as melhorias anteriores: `noshare` P1-P4/Save V3, `completebg`, `map1`, `stealth`, `walkoffmove`, `skipselect`, RAR por assinatura, `gfxshadow`, `falldie`, `fmap`, `lifebarstatus`, `drawmethod`, `atchain`, smoke gameplay e fallback D3D11 -> GDI.

## Validacao real

- Regression/ctest: 1/1 PASS.
- 9 suites de runtime: PASS.
- GoW: 2.783 SUPPORTED, 0 PARTIAL, 0 UNSUPPORTED, 1 UNKNOWN (`heatlh`, typo presente no arquivo original); runtime compilado + smoke 300 frames PASS.
- Evil Dead v1.4.0: 14.290 SUPPORTED, 0 PARTIAL, 0 UNSUPPORTED, 0 UNKNOWN; runtime compilado + smoke 300 frames PASS.

## Limites conhecidos

- `heatlh` continua UNKNOWN no GoW porque e um typo da fonte e nao e reescrito silenciosamente para `health`.
- Includes ausentes que realmente fornecem uma funcao chamada continuam PARTIAL; o Builder nao inventa implementacoes desconhecidas.
- A transformacao `water` e reproduzida nativamente a partir do comportamento documentado do comando legado. Mods que dependam de timing de rasterizacao especifico de uma revisao antiga ainda devem ser comparados visualmente com o OpenBOR original.
