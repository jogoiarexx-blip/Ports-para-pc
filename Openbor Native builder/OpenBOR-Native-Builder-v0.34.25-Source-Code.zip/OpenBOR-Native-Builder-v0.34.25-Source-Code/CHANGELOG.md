# Changelog — v0.34.25

## Legacy water / stage motion
- `water` deixa de deslocar a imagem inteira e passa a usar deformacao horizontal por scanline em `rock 0`.
- `rock 1` usa perspectiva/parallax por linha, ampliando a superficie na direcao da area jogavel.
- `warp` e validado no intervalo legado 0-15 e controla a velocidade da animacao.
- `rock 0..3` passa a SUPPORTED por ocorrencia; modos 2/3 mantem o double-shake e rumble de cenario.
- O water overlay passa a ser ancorado diretamente no `BGHeight` da fase.

## Script include recovery
- Includes sao resolvidos case-insensitive.
- Se o caminho antigo nao existe, o Builder procura um unico arquivo com o mesmo basename dentro do data root.
- Includes ausentes redundantes deixam de gerar PARTIAL so por existirem.
- Se ainda houver chamada de funcao desconhecida, o relatorio mantem `api/function:<nome>` + `include-missing:<path>` de forma explicita.
- O ScriptVM aplica a mesma busca por basename unico em runtime antes de ignorar um include legado ausente.
- `spawn.h` continua usando os helpers nativos `spawn01`, `spawn01map` e `spawn000`.

## Validacao
- ctest/regression: 1/1 PASS.
- runtime_effects, contacts, grabs, bindings, unicode, terrain, energy, commands, compatibility: PASS.
- GoW: 2.783 SUPPORTED / 0 PARTIAL / 1 UNKNOWN; build + smoke 300 frames PASS.
- Evil Dead: 14.290 SUPPORTED / 0 PARTIAL / 0 UNKNOWN; build + smoke 300 frames PASS.
