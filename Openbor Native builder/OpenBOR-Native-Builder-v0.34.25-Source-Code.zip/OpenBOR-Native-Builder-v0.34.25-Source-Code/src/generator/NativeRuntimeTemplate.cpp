#include "PathEncodingTemplate.hpp"
#include "NativeRuntimeTemplate.hpp"
#include <fstream>
#include <filesystem>

void NativeRuntimeTemplate::generate(const std::filesystem::path& outDir) {
    auto runtime = outDir / "runtime";
    auto src = runtime / "src";
    auto include = runtime / "include";
    std::filesystem::create_directories(src);
    std::filesystem::create_directories(include);
    std::ofstream(include / "PathEncoding.hpp") << kPathEncodingHeader;

    std::ofstream cfg(outDir / "config" / "graphics.ini");
    cfg << "[video]\nrenderer=d3d11\ngpu_acceleration=true\nfullscreen=false\nwidth=1280\nheight=720\nvsync=true\nfps_limit=60\nrender_scale=1.0\ntexture_filter=nearest\n\n"
           "[graphics]\npreset=original\nupscale=original\npixel_perfect=true\nkeep_aspect_4_3=true\nfill_16_9=false\ninteger_scale=0\ncrt=false\nscanlines=false\ncrt_curvature=false\nbloom=false\ncontrast=1.0\nsaturation=1.0\nreduce_banding=false\nsharpen=0.0\n\n"
           "[gameplay]\nlogical_width=320\nlogical_height=240\ngravity=0.35\njump_default=4.0\nrun_multiplier=1.65\ndash_speed=6.0\ndash_ticks=12\nprojectile_lifetime=360\n\n[combat]\nenemy_ai=true\ncamera_lock_on_combat=true\nknockback=12\nenemy_attack_range=28\ncombo_window=24\nmax_combo=3\ngrab_range=30\nthrow_damage=24\nfall_ticks=28\nrecovery_ticks=18\n\n[audio]\nmaster_volume=1.0\nmusic_volume=0.80\neffects_volume=0.90\nopenbor_bor_adpcm=true\nauto_preview_music=true\npreferred_music_format=auto\n\n[input]\nmax_players=4\nactive_players=1\ngamepad=true\nplayer1_gamepad=0\nplayer2_gamepad=1\nplayer3_gamepad=2\nplayer4_gamepad=3\nkey_left=37\nkey_right=39\nkey_up=38\nkey_down=40\nkey_attack=74\nkey_jump=32\nkey_pickup=69\nkey_dash=76\nkey_grab=71\nkey_throw=72\nkey_run=16\npad_attack=4096\npad_jump=8192\npad_pickup=16384\npad_grab=32768\npad_dash=256\npad_throw=512\n\n[debug]\nshow_bbox=true\nshow_attack_box=true\n\n"
           "[compatibility]\nopenbor_palette_index0_transparency=true\npreserve_source_alpha=true\n\n[effects]\nparticles=high\nshadows=true\n";

    std::ofstream h(include / "RuntimeConfig.hpp");
    h << R"CPP(#pragma once
#include <filesystem>
#include <string>
struct RuntimeConfig {
  bool gpuAcceleration = true;
  bool fullscreen = false;
  bool vsync = true;
  bool showBBox = true;
  bool showAttackBox = true;
  bool openborPaletteIndex0Transparency = true;
  bool preserveSourceAlpha = true;
  bool openborBorAdpcm = true;
  bool autoPreviewMusic = true;
  bool enemyAI = true;
  bool cameraLockOnCombat = true;
  bool gamepad = true;
  bool pixelPerfect = true;
  bool keepAspect43 = true;
  bool fill169 = false;
  bool crt = false;
  bool scanlines = false;
  bool crtCurvature = false;
  bool bloom = false;
  bool reduceBanding = false;
  int maxPlayers = 4;
  int activePlayers = 1;
  int player1Gamepad = 0;
  int player2Gamepad = 1;
  int player3Gamepad = 2;
  int player4Gamepad = 3;
  int keyLeft = 37, keyRight = 39, keyUp = 38, keyDown = 40;
  int keyAttack = 74, keyJump = 32, keyPickup = 69, keyDash = 76, keyGrab = 71, keyThrow = 72, keyRun = 16;
  int padAttack = 4096, padJump = 8192, padPickup = 16384, padGrab = 32768, padDash = 256, padThrow = 512;
  int width = 1280;
  int height = 720;
  int fpsLimit = 60;
  int logicalWidth = 320;
  int logicalHeight = 240;
  int integerScale = 0;
  int dashTicks = 12;
  int projectileLifetime = 360;
  int knockback = 12;
  int enemyAttackRange = 28;
  int comboWindow = 24;
  int maxCombo = 3;
  int grabRange = 30;
  int throwDamage = 24;
  int fallTicks = 28;
  int recoveryTicks = 18;
  float renderScale = 1.0f;
  float gravity = 0.35f;
  float jumpDefault = 4.0f;
  float runMultiplier = 1.65f;
  float dashSpeed = 6.0f;
  float masterVolume = 1.0f;
  float musicVolume = 0.80f;
  float effectsVolume = 0.90f;
  float contrast = 1.0f;
  float saturation = 1.0f;
  float sharpen = 0.0f;
  std::string renderer = "d3d11";
  std::string textureFilter = "nearest";
  std::string graphicsPreset = "original";
  std::string upscaleMode = "original";
  std::string preferredMusicFormat = "auto";
};
RuntimeConfig loadRuntimeConfig(const std::filesystem::path& iniPath);
bool saveRuntimeConfig(const std::filesystem::path& iniPath, const RuntimeConfig& config);
void applyGraphicsPreset(RuntimeConfig& config, const std::string& preset);
)CPP";

    std::ofstream configCpp(src / "RuntimeConfig.cpp");
    configCpp << R"CPP(#include "PathEncoding.hpp"
#include "RuntimeConfig.hpp"
#include <random>
#include <algorithm>
#include <cctype>
#include <fstream>
#include <string>
namespace {
std::string trim(std::string s){
  auto ws=[](unsigned char c){ return std::isspace(c)!=0; };
  while(!s.empty() && ws((unsigned char)s.front())) s.erase(s.begin());
  while(!s.empty() && ws((unsigned char)s.back())) s.pop_back();
  return s;
}
std::string lower(std::string s){ for(auto& c:s)c=(char)std::tolower((unsigned char)c); return s; }
bool parseBool(const std::string& v,bool fallback){ auto x=lower(trim(v)); if(x=="true"||x=="1"||x=="yes"||x=="on")return true; if(x=="false"||x=="0"||x=="no"||x=="off")return false; return fallback; }
float parseFloat(const std::string& v,float fallback){ try{return std::stof(v);}catch(...){return fallback;} }
int parseInt(const std::string& v,int fallback){ try{return std::stoi(v);}catch(...){return fallback;} }
}
void applyGraphicsPreset(RuntimeConfig& c,const std::string& requested){
  auto p=lower(requested); c.graphicsPreset=p;
  if(p=="original"){
    c.upscaleMode="original";c.textureFilter="nearest";c.pixelPerfect=true;c.keepAspect43=true;c.fill169=false;c.crt=false;c.scanlines=false;c.crtCurvature=false;c.bloom=false;c.contrast=1.0f;c.saturation=1.0f;c.reduceBanding=false;c.sharpen=0.0f;
  }else if(p=="improved"||p=="melhorado"){
    c.graphicsPreset="improved";c.upscaleMode="sharp-bilinear";c.textureFilter="linear";c.pixelPerfect=false;c.keepAspect43=true;c.fill169=false;c.crt=false;c.scanlines=false;c.crtCurvature=false;c.bloom=false;c.contrast=1.05f;c.saturation=1.05f;c.reduceBanding=true;c.sharpen=0.28f;
  }else if(p=="crt"){
    c.upscaleMode="sharp-bilinear";c.textureFilter="linear";c.pixelPerfect=false;c.keepAspect43=true;c.fill169=false;c.crt=true;c.scanlines=true;c.crtCurvature=true;c.bloom=true;c.contrast=1.06f;c.saturation=1.04f;c.reduceBanding=true;c.sharpen=0.16f;
  }else if(p=="sharp"||p=="nitido"||p=="nítido"){
    c.graphicsPreset="sharp";c.upscaleMode="cas";c.textureFilter="linear";c.pixelPerfect=false;c.keepAspect43=true;c.fill169=false;c.crt=false;c.scanlines=false;c.crtCurvature=false;c.bloom=false;c.contrast=1.03f;c.saturation=1.02f;c.reduceBanding=true;c.sharpen=0.68f;
  }
}
RuntimeConfig loadRuntimeConfig(const std::filesystem::path& iniPath){
  RuntimeConfig c; std::ifstream f(iniPath); if(!f) return c;
  std::string section,line;
  while(std::getline(f,line)){
    line=trim(line); if(line.empty()||line[0]=='#'||line[0]==';') continue;
    if(line.front()=='['&&line.back()==']'){ section=lower(trim(line.substr(1,line.size()-2))); continue; }
    auto eq=line.find('='); if(eq==std::string::npos) continue;
    auto key=lower(trim(line.substr(0,eq))), val=trim(line.substr(eq+1));
    if(section=="video"){
      if(key=="renderer") c.renderer=lower(val); else if(key=="gpu_acceleration") c.gpuAcceleration=parseBool(val,c.gpuAcceleration);
      else if(key=="fullscreen") c.fullscreen=parseBool(val,c.fullscreen); else if(key=="width") c.width=parseInt(val,c.width);
      else if(key=="height") c.height=parseInt(val,c.height); else if(key=="vsync") c.vsync=parseBool(val,c.vsync);
      else if(key=="fps_limit") c.fpsLimit=std::max(0,parseInt(val,c.fpsLimit)); else if(key=="render_scale") c.renderScale=parseFloat(val,c.renderScale);
      else if(key=="texture_filter") c.textureFilter=lower(val);
    } else if(section=="graphics"){
      if(key=="preset") c.graphicsPreset=lower(val); else if(key=="upscale") c.upscaleMode=lower(val);
      else if(key=="pixel_perfect") c.pixelPerfect=parseBool(val,c.pixelPerfect); else if(key=="keep_aspect_4_3") c.keepAspect43=parseBool(val,c.keepAspect43);
      else if(key=="fill_16_9") c.fill169=parseBool(val,c.fill169); else if(key=="integer_scale") c.integerScale=std::clamp(parseInt(val,c.integerScale),0,4);
      else if(key=="crt") c.crt=parseBool(val,c.crt); else if(key=="scanlines") c.scanlines=parseBool(val,c.scanlines);
      else if(key=="crt_curvature") c.crtCurvature=parseBool(val,c.crtCurvature); else if(key=="bloom") c.bloom=parseBool(val,c.bloom);
      else if(key=="contrast") c.contrast=std::clamp(parseFloat(val,c.contrast),0.5f,2.0f); else if(key=="saturation") c.saturation=std::clamp(parseFloat(val,c.saturation),0.0f,2.0f);
      else if(key=="reduce_banding") c.reduceBanding=parseBool(val,c.reduceBanding); else if(key=="sharpen") c.sharpen=std::clamp(parseFloat(val,c.sharpen),0.0f,1.0f);
    } else if(section=="gameplay"){
      if(key=="logical_width") c.logicalWidth=parseInt(val,c.logicalWidth);
      else if(key=="logical_height") c.logicalHeight=parseInt(val,c.logicalHeight);
      else if(key=="gravity") c.gravity=std::max(0.01f,parseFloat(val,c.gravity));
      else if(key=="jump_default") c.jumpDefault=std::max(0.5f,parseFloat(val,c.jumpDefault));
      else if(key=="run_multiplier") c.runMultiplier=std::max(1.0f,parseFloat(val,c.runMultiplier));
      else if(key=="dash_speed") c.dashSpeed=std::max(1.0f,parseFloat(val,c.dashSpeed));
      else if(key=="dash_ticks") c.dashTicks=std::max(1,parseInt(val,c.dashTicks));
      else if(key=="projectile_lifetime") c.projectileLifetime=std::max(30,parseInt(val,c.projectileLifetime));
    } else if(section=="combat"){
      if(key=="enemy_ai") c.enemyAI=parseBool(val,c.enemyAI);
      else if(key=="camera_lock_on_combat") c.cameraLockOnCombat=parseBool(val,c.cameraLockOnCombat);
      else if(key=="knockback") c.knockback=parseInt(val,c.knockback);
      else if(key=="enemy_attack_range") c.enemyAttackRange=parseInt(val,c.enemyAttackRange);
      else if(key=="combo_window") c.comboWindow=parseInt(val,c.comboWindow);
      else if(key=="max_combo") c.maxCombo=std::max(1,parseInt(val,c.maxCombo));
      else if(key=="grab_range") c.grabRange=std::max(8,parseInt(val,c.grabRange));
      else if(key=="throw_damage") c.throwDamage=std::max(1,parseInt(val,c.throwDamage));
      else if(key=="fall_ticks") c.fallTicks=std::max(1,parseInt(val,c.fallTicks));
      else if(key=="recovery_ticks") c.recoveryTicks=std::max(1,parseInt(val,c.recoveryTicks));
    } else if(section=="input"){
      if(key=="max_players") c.maxPlayers=std::clamp(parseInt(val,c.maxPlayers),1,4);
      else if(key=="active_players") c.activePlayers=std::clamp(parseInt(val,c.activePlayers),1,4);
      else if(key=="gamepad") c.gamepad=parseBool(val,c.gamepad);
      else if(key=="player1_gamepad") c.player1Gamepad=std::clamp(parseInt(val,c.player1Gamepad),0,3);
      else if(key=="player2_gamepad") c.player2Gamepad=std::clamp(parseInt(val,c.player2Gamepad),0,3);
      else if(key=="player3_gamepad") c.player3Gamepad=std::clamp(parseInt(val,c.player3Gamepad),0,3);
      else if(key=="player4_gamepad") c.player4Gamepad=std::clamp(parseInt(val,c.player4Gamepad),0,3);
      else if(key=="key_left") c.keyLeft=std::clamp(parseInt(val,c.keyLeft),1,255);
      else if(key=="key_right") c.keyRight=std::clamp(parseInt(val,c.keyRight),1,255);
      else if(key=="key_up") c.keyUp=std::clamp(parseInt(val,c.keyUp),1,255);
      else if(key=="key_down") c.keyDown=std::clamp(parseInt(val,c.keyDown),1,255);
      else if(key=="key_attack") c.keyAttack=std::clamp(parseInt(val,c.keyAttack),1,255);
      else if(key=="key_jump") c.keyJump=std::clamp(parseInt(val,c.keyJump),1,255);
      else if(key=="key_pickup") c.keyPickup=std::clamp(parseInt(val,c.keyPickup),1,255);
      else if(key=="key_dash") c.keyDash=std::clamp(parseInt(val,c.keyDash),1,255);
      else if(key=="key_grab") c.keyGrab=std::clamp(parseInt(val,c.keyGrab),1,255);
      else if(key=="key_throw") c.keyThrow=std::clamp(parseInt(val,c.keyThrow),1,255);
      else if(key=="key_run") c.keyRun=std::clamp(parseInt(val,c.keyRun),1,255);
      else if(key=="pad_attack") c.padAttack=parseInt(val,c.padAttack);
      else if(key=="pad_jump") c.padJump=parseInt(val,c.padJump);
      else if(key=="pad_pickup") c.padPickup=parseInt(val,c.padPickup);
      else if(key=="pad_grab") c.padGrab=parseInt(val,c.padGrab);
      else if(key=="pad_dash") c.padDash=parseInt(val,c.padDash);
      else if(key=="pad_throw") c.padThrow=parseInt(val,c.padThrow);
    } else if(section=="audio"){
      if(key=="master_volume") c.masterVolume=std::clamp(parseFloat(val,c.masterVolume),0.0f,1.0f);
      else if(key=="music_volume") c.musicVolume=std::clamp(parseFloat(val,c.musicVolume),0.0f,1.0f);
      else if(key=="effects_volume") c.effectsVolume=std::clamp(parseFloat(val,c.effectsVolume),0.0f,1.0f);
      else if(key=="openbor_bor_adpcm") c.openborBorAdpcm=parseBool(val,c.openborBorAdpcm);
      else if(key=="auto_preview_music") c.autoPreviewMusic=parseBool(val,c.autoPreviewMusic);
      else if(key=="preferred_music_format") c.preferredMusicFormat=lower(val);
    } else if(section=="debug"){
      if(key=="show_bbox") c.showBBox=parseBool(val,c.showBBox); else if(key=="show_attack_box") c.showAttackBox=parseBool(val,c.showAttackBox);
    } else if(section=="compatibility"){
      if(key=="openbor_palette_index0_transparency") c.openborPaletteIndex0Transparency=parseBool(val,c.openborPaletteIndex0Transparency);
      else if(key=="preserve_source_alpha") c.preserveSourceAlpha=parseBool(val,c.preserveSourceAlpha);
    }
  }
  c.logicalWidth=std::max(160,c.logicalWidth);c.logicalHeight=std::max(120,c.logicalHeight);
  return c;
}
bool saveRuntimeConfig(const std::filesystem::path& iniPath,const RuntimeConfig& c){
  std::ofstream f(iniPath,std::ios::trunc); if(!f) return false;
  f<<"[video]\nrenderer="<<c.renderer<<"\ngpu_acceleration="<<(c.gpuAcceleration?"true":"false")
   <<"\nfullscreen="<<(c.fullscreen?"true":"false")<<"\nwidth="<<c.width<<"\nheight="<<c.height
   <<"\nvsync="<<(c.vsync?"true":"false")<<"\nfps_limit="<<c.fpsLimit<<"\nrender_scale="<<c.renderScale<<"\ntexture_filter="<<c.textureFilter<<"\n\n";
  f<<"[graphics]\npreset="<<c.graphicsPreset<<"\nupscale="<<c.upscaleMode<<"\npixel_perfect="<<(c.pixelPerfect?"true":"false")
   <<"\nkeep_aspect_4_3="<<(c.keepAspect43?"true":"false")<<"\nfill_16_9="<<(c.fill169?"true":"false")<<"\ninteger_scale="<<c.integerScale
   <<"\ncrt="<<(c.crt?"true":"false")<<"\nscanlines="<<(c.scanlines?"true":"false")<<"\ncrt_curvature="<<(c.crtCurvature?"true":"false")
   <<"\nbloom="<<(c.bloom?"true":"false")<<"\ncontrast="<<c.contrast<<"\nsaturation="<<c.saturation<<"\nreduce_banding="<<(c.reduceBanding?"true":"false")<<"\nsharpen="<<c.sharpen<<"\n\n";
  f<<"[gameplay]\nlogical_width="<<c.logicalWidth<<"\nlogical_height="<<c.logicalHeight
   <<"\ngravity="<<c.gravity<<"\njump_default="<<c.jumpDefault<<"\nrun_multiplier="<<c.runMultiplier
   <<"\ndash_speed="<<c.dashSpeed<<"\ndash_ticks="<<c.dashTicks<<"\nprojectile_lifetime="<<c.projectileLifetime<<"\n\n";
  f<<"[combat]\nenemy_ai="<<(c.enemyAI?"true":"false")<<"\ncamera_lock_on_combat="<<(c.cameraLockOnCombat?"true":"false")
   <<"\nknockback="<<c.knockback<<"\nenemy_attack_range="<<c.enemyAttackRange<<"\ncombo_window="<<c.comboWindow
   <<"\nmax_combo="<<c.maxCombo<<"\ngrab_range="<<c.grabRange<<"\nthrow_damage="<<c.throwDamage
   <<"\nfall_ticks="<<c.fallTicks<<"\nrecovery_ticks="<<c.recoveryTicks<<"\n\n";
  f<<"[input]\nmax_players="<<c.maxPlayers<<"\nactive_players="<<c.activePlayers<<"\ngamepad="<<(c.gamepad?"true":"false")
   <<"\nplayer1_gamepad="<<c.player1Gamepad<<"\nplayer2_gamepad="<<c.player2Gamepad<<"\nplayer3_gamepad="<<c.player3Gamepad<<"\nplayer4_gamepad="<<c.player4Gamepad
   <<"\nkey_left="<<c.keyLeft<<"\nkey_right="<<c.keyRight<<"\nkey_up="<<c.keyUp<<"\nkey_down="<<c.keyDown
   <<"\nkey_attack="<<c.keyAttack<<"\nkey_jump="<<c.keyJump<<"\nkey_pickup="<<c.keyPickup<<"\nkey_dash="<<c.keyDash
   <<"\nkey_grab="<<c.keyGrab<<"\nkey_throw="<<c.keyThrow<<"\nkey_run="<<c.keyRun
   <<"\npad_attack="<<c.padAttack<<"\npad_jump="<<c.padJump<<"\npad_pickup="<<c.padPickup<<"\npad_grab="<<c.padGrab<<"\npad_dash="<<c.padDash<<"\npad_throw="<<c.padThrow<<"\n\n";
  f<<"[audio]\nmaster_volume="<<c.masterVolume<<"\nmusic_volume="<<c.musicVolume<<"\neffects_volume="<<c.effectsVolume
   <<"\nopenbor_bor_adpcm="<<(c.openborBorAdpcm?"true":"false")<<"\nauto_preview_music="<<(c.autoPreviewMusic?"true":"false")
   <<"\npreferred_music_format="<<c.preferredMusicFormat<<"\n\n";
  f<<"[debug]\nshow_bbox="<<(c.showBBox?"true":"false")<<"\nshow_attack_box="<<(c.showAttackBox?"true":"false")<<"\n\n";
  f<<"[compatibility]\nopenbor_palette_index0_transparency="<<(c.openborPaletteIndex0Transparency?"true":"false")
   <<"\npreserve_source_alpha="<<(c.preserveSourceAlpha?"true":"false")<<"\n\n";
  f<<"[effects]\nparticles=high\nshadows=true\n";
  return (bool)f;
}
)CPP";

    std::ofstream renderer(include / "Renderer.hpp");
    renderer << R"CPP(#pragma once
#include "RuntimeConfig.hpp"
#include <random>
#include "../generated/GeneratedCharacters.hpp"
#include <filesystem>
#include <string>
#include <vector>
struct SpriteImage { int width=0; int height=0; std::vector<unsigned char> bgra; };
class Renderer {
public:
  Renderer() = default;
  ~Renderer();
  bool initialize(const RuntimeConfig&);
  void setConfig(const RuntimeConfig&);
  bool isRunning() const;
  bool pumpEvents();
  void beginFrame();
  void drawImage(const SpriteImage&, int x, int y);
  void drawImageBlend(const SpriteImage&, int x, int y, int mode);
  void drawSolidRect(int x, int y, int w, int h, unsigned char r, unsigned char g, unsigned char b);
  void drawDot(int x, int y, unsigned int rgb);
  void drawLine(int x1, int y1, int x2, int y2, unsigned int rgb);
  void drawText(const std::string& text, int x, int y, int size=12, bool selected=false);
  void drawFrame(const SpriteImage&, const generated::Frame&, int originX, int originY, const RuntimeConfig&, bool flipX=false, int modelAlphaMode=0);
  void endFrame();
  bool loadSprite(const std::filesystem::path&, SpriteImage&);
  bool loadPalette(const std::filesystem::path&, std::vector<unsigned>& colors);
  bool loadAnimationFrames(const std::filesystem::path&, std::vector<SpriteImage>& frames, std::vector<int>& delaysMs);
  const std::string& backend() const;
private:
  RuntimeConfig config_;
  std::string backend_ = "headless";
  bool running_ = true;
#ifdef _WIN32
  bool createLogicalCanvas();
  bool initializeD3D11();
  bool presentD3D11Frame();
  bool presentD3D11FrameUnsafe();
  void releaseD3D11Resources();
  void abandonD3D11Resources();
  void shutdownWindowsResources();
  void presentWithGdiFallback();
  void* hwnd_ = nullptr;
  void* frameDC_ = nullptr;
  void* frameBitmap_ = nullptr;
  void* frameOldBitmap_ = nullptr;
  void* frameBits_ = nullptr;
  int frameStride_ = 0;
  void* d3dDevice_ = nullptr;
  void* d3dContext_ = nullptr;
  void* swapChain_ = nullptr;
  void* sourceTexture_ = nullptr;
  void* sourceSRV_ = nullptr;
  void* samplerPoint_ = nullptr;
  void* samplerLinear_ = nullptr;
  void* vertexShader_ = nullptr;
  void* pixelShader_ = nullptr;
  void* constantBuffer_ = nullptr;
  void* d2dFactory_ = nullptr;
  void* d2dTarget_ = nullptr;
  void* dwriteFactory_ = nullptr;
#endif
};
)CPP";

    std::ofstream rendererCpp(src / "Renderer.cpp");
    rendererCpp << R"CPP(#include "PathEncoding.hpp"
#include "Renderer.hpp"
#include <iostream>
#include <algorithm>
#include <cstring>
#include <cmath>
#include <cstdint>
#include <utility>
#ifdef _WIN32
#define NOMINMAX
#include <windows.h>
#include <wincodec.h>
#include <d3d11.h>
#include <dxgi.h>
#include <d3dcompiler.h>
#include <d2d1.h>
#include <dwrite.h>
#pragma comment(lib, "windowscodecs.lib")
#pragma comment(lib, "ole32.lib")
#pragma comment(lib, "msimg32.lib")
#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "dxgi.lib")
#pragma comment(lib, "d3dcompiler.lib")
#pragma comment(lib, "d2d1.lib")
#pragma comment(lib, "dwrite.lib")

template<class T> static void safeRelease(T*& p){ if(p){ p->Release(); p=nullptr; } }
static LRESULT CALLBACK PortWndProc(HWND h, UINT m, WPARAM w, LPARAM l){
  if(m==WM_DESTROY){ PostQuitMessage(0); return 0; }
  return DefWindowProcW(h,m,w,l);
}
static std::wstring widenUtf8(const std::string& s){
  if(s.empty()) return {};
  int n=MultiByteToWideChar(CP_UTF8,0,s.c_str(),(int)s.size(),nullptr,0); if(n<=0) return std::wstring(s.begin(),s.end());
  std::wstring w((size_t)n,L' '); MultiByteToWideChar(CP_UTF8,0,s.c_str(),(int)s.size(),w.data(),n); return w;
}
struct ShaderParams {
  float texelX=1.0f/320.0f, texelY=1.0f/240.0f, sharpen=0.0f, contrast=1.0f;
  float saturation=1.0f, bloom=0.0f, scanline=0.0f, curvature=0.0f;
  float banding=0.0f, mode=0.0f, time=0.0f, unused=0.0f;
  float uvScaleX=1.0f, uvScaleY=1.0f, uvOffsetX=0.0f, uvOffsetY=0.0f;
};
static const char* kVs = R"HLSL(
struct VSOut { float4 pos:SV_POSITION; float2 uv:TEXCOORD0; };
VSOut main(uint id:SV_VertexID){
  VSOut o; float2 p = id==0?float2(-1,-1):(id==1?float2(-1,3):float2(3,-1));
  o.pos=float4(p,0,1); o.uv=float2((p.x+1)*0.5,1-(p.y+1)*0.5); return o;
}
)HLSL";
static const char* kPs = R"HLSL(
Texture2D Scene:register(t0); SamplerState Samp:register(s0);
cbuffer Params:register(b0){
  float2 texel; float sharpen; float contrast;
  float saturation; float bloom; float scanline; float curvature;
  float banding; float mode; float time; float unused;
  float2 uvScale; float2 uvOffset;
};
float hash12(float2 p){ float3 p3=frac(float3(p.xyx)*.1031); p3+=dot(p3,p3.yzx+33.33); return frac((p3.x+p3.y)*p3.z); }
float3 sampleScene(float2 uv){ return Scene.Sample(Samp,uv).rgb; }
float4 main(float4 pos:SV_POSITION,float2 baseUV:TEXCOORD0):SV_TARGET{
  float2 uv=baseUV;
  if(curvature>0.001){ float2 q=uv*2-1; q*=1+curvature*0.18*dot(q,q); uv=q*0.5+0.5; if(any(uv<0)||any(uv>1)) return float4(0,0,0,1); }
  uv=uv*uvScale+uvOffset;
  float3 c=sampleScene(uv);
  float3 l=sampleScene(uv-float2(texel.x,0)), r=sampleScene(uv+float2(texel.x,0));
  float3 u=sampleScene(uv-float2(0,texel.y)), d=sampleScene(uv+float2(0,texel.y));
  float3 avg=(l+r+u+d)*0.25;
  if(mode>0.5&&mode<1.5) c=saturate(c*1.18-avg*0.18);
  else if(mode>=1.5&&mode<2.5) c=saturate(c+(c-avg)*max(sharpen,0.22));
  else if(mode>=2.5){ float ex=dot(abs(l-r),float3(.333,.333,.333)); float ey=dot(abs(u-d),float3(.333,.333,.333)); float3 edge=ex<ey?(l+r)*.5:(u+d)*.5; c=lerp(c,edge,0.20); c=saturate(c+(c-avg)*sharpen*0.45); }
  if(bloom>0.001){ float3 glow=(sampleScene(uv+texel*2)+sampleScene(uv-texel*2)+sampleScene(uv+float2(texel.x*2,-texel.y*2))+sampleScene(uv+float2(-texel.x*2,texel.y*2)))*0.25; float lum=max(glow.r,max(glow.g,glow.b)); c+=glow*max(0,lum-.45)*bloom; }
  float lum=dot(c,float3(.299,.587,.114)); c=lerp(float3(lum,lum,lum),c,saturation); c=(c-.5)*contrast+.5;
  if(scanline>0.001){ float line=0.5+0.5*cos(3.14159265*(uv.y/max(texel.y,0.00001))); c*=1-scanline*(0.10+0.18*line); }
  if(banding>0.001){ float n=hash12(pos.xy+time)-.5; c+=n*(1.0/255.0)*banding; }
  if(unused>0.001){ float2 vp=baseUV*2-1; float vign=saturate(1.0-0.12*dot(vp,vp)); float mask=0.975+0.025*sin(pos.x*3.14159265); c*=vign*mask; }
  return float4(saturate(c),1);
}
)HLSL";
#endif
#ifdef _WIN32
static void drawOpenBORBlend(HDC dc,const SpriteImage& src,int x,int y,int mode);
#endif

Renderer::~Renderer(){
#ifdef _WIN32
  shutdownWindowsResources();
#endif
}
void Renderer::setConfig(const RuntimeConfig& c){ config_=c; }

#ifdef _WIN32
bool Renderer::createLogicalCanvas(){
  if(frameDC_){ HDC dc=(HDC)frameDC_; if(frameOldBitmap_) SelectObject(dc,(HGDIOBJ)frameOldBitmap_); if(frameBitmap_) DeleteObject((HBITMAP)frameBitmap_); DeleteDC(dc); frameDC_=frameBitmap_=frameOldBitmap_=frameBits_=nullptr; }
  BITMAPINFO bi{}; bi.bmiHeader.biSize=sizeof(BITMAPINFOHEADER); bi.bmiHeader.biWidth=config_.logicalWidth; bi.bmiHeader.biHeight=-config_.logicalHeight; bi.bmiHeader.biPlanes=1; bi.bmiHeader.biBitCount=32; bi.bmiHeader.biCompression=BI_RGB;
  HDC dc=CreateCompatibleDC(nullptr); void* bits=nullptr; HBITMAP bmp=CreateDIBSection(dc,&bi,DIB_RGB_COLORS,&bits,nullptr,0); if(!dc||!bmp||!bits){ if(bmp)DeleteObject(bmp); if(dc)DeleteDC(dc); return false; }
  HGDIOBJ old=SelectObject(dc,bmp); frameDC_=dc; frameBitmap_=bmp; frameOldBitmap_=old; frameBits_=bits; frameStride_=config_.logicalWidth*4;
  ID2D1Factory* factory=nullptr; if(SUCCEEDED(D2D1CreateFactory(D2D1_FACTORY_TYPE_SINGLE_THREADED,&factory))){
    d2dFactory_=factory; D2D1_RENDER_TARGET_PROPERTIES props=D2D1::RenderTargetProperties(D2D1_RENDER_TARGET_TYPE_SOFTWARE,D2D1::PixelFormat(DXGI_FORMAT_B8G8R8A8_UNORM,D2D1_ALPHA_MODE_PREMULTIPLIED)); ID2D1DCRenderTarget* rt=nullptr; if(SUCCEEDED(factory->CreateDCRenderTarget(&props,&rt))) d2dTarget_=rt;
  }
  IDWriteFactory* dw=nullptr; if(SUCCEEDED(DWriteCreateFactory(DWRITE_FACTORY_TYPE_SHARED,__uuidof(IDWriteFactory),(IUnknown**)&dw))) dwriteFactory_=dw;
  return true;
}
void Renderer::releaseD3D11Resources(){
  auto* ctx=(ID3D11DeviceContext*)d3dContext_; if(ctx)ctx->ClearState();
  if(constantBuffer_){((ID3D11Buffer*)constantBuffer_)->Release();constantBuffer_=nullptr;}
  if(pixelShader_){((ID3D11PixelShader*)pixelShader_)->Release();pixelShader_=nullptr;}
  if(vertexShader_){((ID3D11VertexShader*)vertexShader_)->Release();vertexShader_=nullptr;}
  if(samplerLinear_){((ID3D11SamplerState*)samplerLinear_)->Release();samplerLinear_=nullptr;}
  if(samplerPoint_){((ID3D11SamplerState*)samplerPoint_)->Release();samplerPoint_=nullptr;}
  if(sourceSRV_){((ID3D11ShaderResourceView*)sourceSRV_)->Release();sourceSRV_=nullptr;}
  if(sourceTexture_){((ID3D11Texture2D*)sourceTexture_)->Release();sourceTexture_=nullptr;}
  if(swapChain_){((IDXGISwapChain*)swapChain_)->Release();swapChain_=nullptr;}
  if(d3dContext_){((ID3D11DeviceContext*)d3dContext_)->Release();d3dContext_=nullptr;}
  if(d3dDevice_){((ID3D11Device*)d3dDevice_)->Release();d3dDevice_=nullptr;}
}
void Renderer::abandonD3D11Resources(){
  // A graphics-driver SEH means COM Release/ClearState may itself fault again.
  // Deliberately leak the small D3D object set until process exit and continue on GDI.
  constantBuffer_=pixelShader_=vertexShader_=samplerLinear_=samplerPoint_=sourceSRV_=sourceTexture_=swapChain_=d3dContext_=d3dDevice_=nullptr;
}
bool Renderer::initializeD3D11(){
  if(!hwnd_||!config_.gpuAcceleration||config_.renderer!="d3d11") return false;
  HWND h=(HWND)hwnd_; RECT rc{}; GetClientRect(h,&rc); UINT ww=(UINT)std::max<LONG>(1,rc.right-rc.left), wh=(UINT)std::max<LONG>(1,rc.bottom-rc.top);
  DXGI_SWAP_CHAIN_DESC sd{}; sd.BufferDesc.Width=ww; sd.BufferDesc.Height=wh; sd.BufferDesc.Format=DXGI_FORMAT_R8G8B8A8_UNORM; sd.SampleDesc.Count=1; sd.BufferUsage=DXGI_USAGE_RENDER_TARGET_OUTPUT; sd.BufferCount=2; sd.OutputWindow=h; sd.Windowed=TRUE; sd.SwapEffect=DXGI_SWAP_EFFECT_DISCARD;
  D3D_FEATURE_LEVEL levels[]={D3D_FEATURE_LEVEL_11_0,D3D_FEATURE_LEVEL_10_1,D3D_FEATURE_LEVEL_10_0}; D3D_FEATURE_LEVEL got{}; ID3D11Device* dev=nullptr;ID3D11DeviceContext* ctx=nullptr;IDXGISwapChain* sc=nullptr;
  HRESULT hr=D3D11CreateDeviceAndSwapChain(nullptr,D3D_DRIVER_TYPE_HARDWARE,nullptr,D3D11_CREATE_DEVICE_BGRA_SUPPORT,levels,3,D3D11_SDK_VERSION,&sd,&sc,&dev,&got,&ctx);
  if(FAILED(hr)) hr=D3D11CreateDeviceAndSwapChain(nullptr,D3D_DRIVER_TYPE_WARP,nullptr,D3D11_CREATE_DEVICE_BGRA_SUPPORT,levels,3,D3D11_SDK_VERSION,&sd,&sc,&dev,&got,&ctx);
  if(FAILED(hr)){safeRelease(sc);safeRelease(ctx);safeRelease(dev);return false;}
  d3dDevice_=dev;d3dContext_=ctx;swapChain_=sc;
  auto fail=[&](){ releaseD3D11Resources(); backend_="win32-gdi-fallback"; return false; };
  D3D11_TEXTURE2D_DESC td{}; td.Width=(UINT)config_.logicalWidth;td.Height=(UINT)config_.logicalHeight;td.MipLevels=1;td.ArraySize=1;td.Format=DXGI_FORMAT_B8G8R8A8_UNORM;td.SampleDesc.Count=1;td.Usage=D3D11_USAGE_DEFAULT;td.BindFlags=D3D11_BIND_SHADER_RESOURCE;
  ID3D11Texture2D* src=nullptr; if(FAILED(dev->CreateTexture2D(&td,nullptr,&src))||!src) return fail(); sourceTexture_=src;
  ID3D11ShaderResourceView* srv=nullptr;if(FAILED(dev->CreateShaderResourceView(src,nullptr,&srv))||!srv)return fail();sourceSRV_=srv;
  D3D11_SAMPLER_DESC sp{};sp.Filter=D3D11_FILTER_MIN_MAG_MIP_POINT;sp.AddressU=sp.AddressV=sp.AddressW=D3D11_TEXTURE_ADDRESS_CLAMP;sp.MaxLOD=D3D11_FLOAT32_MAX;ID3D11SamplerState* point=nullptr;if(FAILED(dev->CreateSamplerState(&sp,&point))||!point)return fail();samplerPoint_=point;sp.Filter=D3D11_FILTER_MIN_MAG_MIP_LINEAR;ID3D11SamplerState* linear=nullptr;if(FAILED(dev->CreateSamplerState(&sp,&linear))||!linear)return fail();samplerLinear_=linear;
  ID3DBlob* vb=nullptr,*pb=nullptr,*err=nullptr; if(FAILED(D3DCompile(kVs,std::strlen(kVs),nullptr,nullptr,nullptr,"main","vs_4_0",D3DCOMPILE_OPTIMIZATION_LEVEL3,0,&vb,&err))||!vb){if(err){std::cerr<<(const char*)err->GetBufferPointer()<<"\n";err->Release();}return fail();} if(err){err->Release();err=nullptr;}
  if(FAILED(D3DCompile(kPs,std::strlen(kPs),nullptr,nullptr,nullptr,"main","ps_4_0",D3DCOMPILE_OPTIMIZATION_LEVEL3,0,&pb,&err))||!pb){if(err){std::cerr<<(const char*)err->GetBufferPointer()<<"\n";err->Release();}vb->Release();return fail();} if(err)err->Release();
  ID3D11VertexShader* vs=nullptr;ID3D11PixelShader* ps=nullptr;HRESULT vhr=dev->CreateVertexShader(vb->GetBufferPointer(),vb->GetBufferSize(),nullptr,&vs);HRESULT phr=dev->CreatePixelShader(pb->GetBufferPointer(),pb->GetBufferSize(),nullptr,&ps);vb->Release();pb->Release();if(FAILED(vhr)||FAILED(phr)||!vs||!ps){safeRelease(vs);safeRelease(ps);return fail();}vertexShader_=vs;pixelShader_=ps;
  D3D11_BUFFER_DESC bd{};bd.ByteWidth=(UINT)((sizeof(ShaderParams)+15u)&~15u);bd.Usage=D3D11_USAGE_DYNAMIC;bd.BindFlags=D3D11_BIND_CONSTANT_BUFFER;bd.CPUAccessFlags=D3D11_CPU_ACCESS_WRITE;ID3D11Buffer* cb=nullptr;if(FAILED(dev->CreateBuffer(&bd,nullptr,&cb))||!cb)return fail();constantBuffer_=cb;
  backend_="d3d11-postprocess"; return true;
}
void Renderer::shutdownWindowsResources(){
  releaseD3D11Resources();
  if(d2dTarget_){((ID2D1DCRenderTarget*)d2dTarget_)->Release();d2dTarget_=nullptr;}if(d2dFactory_){((ID2D1Factory*)d2dFactory_)->Release();d2dFactory_=nullptr;}if(dwriteFactory_){((IDWriteFactory*)dwriteFactory_)->Release();dwriteFactory_=nullptr;}
  if(frameDC_){HDC dc=(HDC)frameDC_;if(frameOldBitmap_)SelectObject(dc,(HGDIOBJ)frameOldBitmap_);if(frameBitmap_)DeleteObject((HBITMAP)frameBitmap_);DeleteDC(dc);}frameDC_=frameBitmap_=frameOldBitmap_=frameBits_=nullptr;
  if(hwnd_){DestroyWindow((HWND)hwnd_);hwnd_=nullptr;} CoUninitialize();
}
#endif

bool Renderer::initialize(const RuntimeConfig& c){
  config_=c;
#ifdef _WIN32
  CoInitializeEx(nullptr, COINIT_MULTITHREADED); HINSTANCE inst=GetModuleHandleW(nullptr); WNDCLASSW wc{};wc.lpfnWndProc=PortWndProc;wc.hInstance=inst;wc.lpszClassName=L"OpenBORNativePort";wc.hCursor=LoadCursor(nullptr,IDC_ARROW);RegisterClassW(&wc);
  DWORD style=c.fullscreen?WS_POPUP:WS_OVERLAPPEDWINDOW;int x=c.fullscreen?0:CW_USEDEFAULT,y=c.fullscreen?0:CW_USEDEFAULT;HWND h=CreateWindowExW(0,wc.lpszClassName,L"OpenBOR Native Port",style|WS_VISIBLE,x,y,c.width,c.height,nullptr,nullptr,inst,nullptr);if(!h)return false;hwnd_=h;
  if(!createLogicalCanvas())return false; if(!initializeD3D11())backend_="win32-gdi-fallback";
#else
  backend_="headless-preview";
#endif
  return true;
}
bool Renderer::isRunning() const { return running_; }
bool Renderer::pumpEvents(){
#ifdef _WIN32
  MSG msg{};while(PeekMessageW(&msg,nullptr,0,0,PM_REMOVE)){if(msg.message==WM_QUIT){running_=false;return false;}TranslateMessage(&msg);DispatchMessageW(&msg);}
#endif
  return running_;
}
void Renderer::beginFrame(){
#ifdef _WIN32
  if(!frameBits_)return;auto* p=(unsigned char*)frameBits_;for(int y=0;y<config_.logicalHeight;++y)for(int x=0;x<config_.logicalWidth;++x){size_t i=((size_t)y*config_.logicalWidth+x)*4u;p[i]=30;p[i+1]=24;p[i+2]=24;p[i+3]=255;}
#endif
}
void Renderer::drawImage(const SpriteImage& img,int x,int y){
#ifdef _WIN32
  if(!frameDC_||img.width<=0||img.height<=0||img.bgra.empty())return;HDC dc=(HDC)frameDC_;BITMAPINFO bi{};bi.bmiHeader.biSize=sizeof(BITMAPINFOHEADER);bi.bmiHeader.biWidth=img.width;bi.bmiHeader.biHeight=-img.height;bi.bmiHeader.biPlanes=1;bi.bmiHeader.biBitCount=32;bi.bmiHeader.biCompression=BI_RGB;HDC mem=CreateCompatibleDC(dc);void* bits=nullptr;HBITMAP bmp=CreateDIBSection(dc,&bi,DIB_RGB_COLORS,&bits,nullptr,0);if(mem&&bmp&&bits){std::memcpy(bits,img.bgra.data(),img.bgra.size());HGDIOBJ old=SelectObject(mem,bmp);BLENDFUNCTION blend{AC_SRC_OVER,0,255,AC_SRC_ALPHA};AlphaBlend(dc,x,y,img.width,img.height,mem,0,0,img.width,img.height,blend);SelectObject(mem,old);}if(bmp)DeleteObject(bmp);if(mem)DeleteDC(mem);
#else
  (void)img;(void)x;(void)y;
#endif
}
void Renderer::drawImageBlend(const SpriteImage& img,int x,int y,int mode){
#ifdef _WIN32
  if(mode>=1&&mode<=6&&frameDC_)drawOpenBORBlend((HDC)frameDC_,img,x,y,mode);else drawImage(img,x,y);
#else
  (void)mode;drawImage(img,x,y);
#endif
}
void Renderer::drawSolidRect(int x,int y,int w,int h,unsigned char r,unsigned char g,unsigned char b){
#ifdef _WIN32
  if(!frameDC_||w<=0||h<=0)return;RECT rc{x,y,x+w,y+h};auto* rt=(ID2D1DCRenderTarget*)d2dTarget_;if(rt){RECT full{0,0,config_.logicalWidth,config_.logicalHeight};rt->BindDC((HDC)frameDC_,&full);rt->BeginDraw();ID2D1SolidColorBrush* brush=nullptr;rt->CreateSolidColorBrush(D2D1::ColorF(r/255.0f,g/255.0f,b/255.0f,1),&brush);if(brush){rt->FillRectangle(D2D1::RectF((FLOAT)x,(FLOAT)y,(FLOAT)(x+w),(FLOAT)(y+h)),brush);brush->Release();}rt->EndDraw();}else{HBRUSH brush=CreateSolidBrush(RGB(r,g,b));FillRect((HDC)frameDC_,&rc,brush);DeleteObject(brush);}
#else
  (void)x;(void)y;(void)w;(void)h;(void)r;(void)g;(void)b;
#endif
}
void Renderer::drawDot(int x,int y,unsigned int rgb){
  drawSolidRect(x,y,1,1,(unsigned char)((rgb>>16)&255),(unsigned char)((rgb>>8)&255),(unsigned char)(rgb&255));
}
void Renderer::drawLine(int x1,int y1,int x2,int y2,unsigned int rgb){
  int dx=std::abs(x2-x1),sx=x1<x2?1:-1,dy=-std::abs(y2-y1),sy=y1<y2?1:-1,err=dx+dy;
  for(;;){drawDot(x1,y1,rgb);if(x1==x2&&y1==y2)break;int e2=2*err;if(e2>=dy){err+=dy;x1+=sx;}if(e2<=dx){err+=dx;y1+=sy;}}
}
void Renderer::drawText(const std::string& text,int x,int y,int size,bool selected){
#ifdef _WIN32
  if(!frameDC_||text.empty())return;auto* rt=(ID2D1DCRenderTarget*)d2dTarget_;auto* dw=(IDWriteFactory*)dwriteFactory_;if(rt&&dw){RECT rc{0,0,config_.logicalWidth,config_.logicalHeight};rt->BindDC((HDC)frameDC_,&rc);IDWriteTextFormat* fmt=nullptr;dw->CreateTextFormat(L"Segoe UI",nullptr,selected?DWRITE_FONT_WEIGHT_BOLD:DWRITE_FONT_WEIGHT_NORMAL,DWRITE_FONT_STYLE_NORMAL,DWRITE_FONT_STRETCH_NORMAL,(FLOAT)std::max(6,size),L"pt-BR",&fmt);ID2D1SolidColorBrush* brush=nullptr;rt->CreateSolidColorBrush(selected?D2D1::ColorF(1.0f,.84f,.31f,1):D2D1::ColorF(.93f,.93f,.95f,1),&brush);auto w=widenUtf8(text);rt->BeginDraw();if(fmt&&brush)rt->DrawText(w.c_str(),(UINT32)w.size(),fmt,D2D1::RectF((FLOAT)x,(FLOAT)y,(FLOAT)config_.logicalWidth,(FLOAT)(y+size+8)),brush,D2D1_DRAW_TEXT_OPTIONS_CLIP);rt->EndDraw();if(brush)brush->Release();if(fmt)fmt->Release();}else{HDC dc=(HDC)frameDC_;SetBkMode(dc,TRANSPARENT);SetTextColor(dc,selected?RGB(255,215,80):RGB(238,238,242));HFONT font=CreateFontA(-std::max(8,size),0,0,0,selected?FW_BOLD:FW_NORMAL,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,ANTIALIASED_QUALITY,DEFAULT_PITCH|FF_DONTCARE,"Segoe UI");HGDIOBJ old=SelectObject(dc,font);TextOutA(dc,x,y,text.c_str(),(int)text.size());SelectObject(dc,old);DeleteObject(font);}
#else
  (void)text;(void)x;(void)y;(void)size;(void)selected;
#endif
}
static unsigned char clampByte(int v){return(unsigned char)std::clamp(v,0,255);}static unsigned char blendChannel(unsigned char src,unsigned char dst,int mode){const int s=(int)src,d=(int)dst;switch(mode){case 3:return clampByte(d<128?(2*s*d)/255:255-(2*(255-s)*(255-d))/255);case 4:return clampByte(s<128?(2*s*d)/255:255-(2*(255-s)*(255-d))/255);case 5:return clampByte(s>=255?255:std::min(255,(d*255)/std::max(1,255-s)));case 6:return(unsigned char)((s+d)/2);default:return src;}}
#ifdef _WIN32
static void drawOpenBORBlend(HDC dc,const SpriteImage& src,int x,int y,int mode){if(src.width<=0||src.height<=0||src.bgra.empty())return;RECT clip{0,0,32000,32000};int sx0=0,sy0=0,w=src.width,h=src.height;if(x<0){sx0=-x;w-=sx0;x=0;}if(y<0){sy0=-y;h-=sy0;y=0;}if(w<=0||h<=0)return;BITMAPINFO bi{};bi.bmiHeader.biSize=sizeof(BITMAPINFOHEADER);bi.bmiHeader.biWidth=w;bi.bmiHeader.biHeight=-h;bi.bmiHeader.biPlanes=1;bi.bmiHeader.biBitCount=32;bi.bmiHeader.biCompression=BI_RGB;HDC mem=CreateCompatibleDC(dc);void* bits=nullptr;HBITMAP bmp=CreateDIBSection(dc,&bi,DIB_RGB_COLORS,&bits,nullptr,0);if(!mem||!bmp||!bits){if(bmp)DeleteObject(bmp);if(mem)DeleteDC(mem);return;}HGDIOBJ old=SelectObject(mem,bmp);BitBlt(mem,0,0,w,h,dc,x,y,SRCCOPY);auto* dst=(unsigned char*)bits;for(int py=0;py<h;++py)for(int px=0;px<w;++px){size_t si=((size_t)(py+sy0)*src.width+(px+sx0))*4u,di=((size_t)py*w+px)*4u;unsigned a=src.bgra[si+3];if(!a)continue;unsigned char sb=(unsigned char)std::min(255u,(unsigned)src.bgra[si]*255u/a),sg=(unsigned char)std::min(255u,(unsigned)src.bgra[si+1]*255u/a),sr=(unsigned char)std::min(255u,(unsigned)src.bgra[si+2]*255u/a);unsigned char db=dst[di],dg=dst[di+1],dr=dst[di+2];unsigned weight=a;if(mode==1){unsigned lum=((unsigned)sr+(unsigned)sg+(unsigned)sb)/3u;weight=weight*lum/255u;}else if(mode==2){unsigned lum=((unsigned)sr+(unsigned)sg+(unsigned)sb)/3u;weight=weight*(255u-lum)/255u;}unsigned char rb=mode<=2?sb:blendChannel(sb,db,mode),rg=mode<=2?sg:blendChannel(sg,dg,mode),rr=mode<=2?sr:blendChannel(sr,dr,mode);dst[di]=(unsigned char)(((unsigned)rb*weight+(unsigned)db*(255u-weight))/255u);dst[di+1]=(unsigned char)(((unsigned)rg*weight+(unsigned)dg*(255u-weight))/255u);dst[di+2]=(unsigned char)(((unsigned)rr*weight+(unsigned)dr*(255u-weight))/255u);dst[di+3]=255;}BitBlt(dc,x,y,w,h,mem,0,0,SRCCOPY);SelectObject(mem,old);DeleteObject(bmp);DeleteDC(mem);}
#endif
static unsigned char blendTintChannel(int mode,int tint,int src){
  tint=std::clamp(tint,0,255);src=std::clamp(src,0,255);int v=src;
  switch(mode){
    case 1:v=255-((255-tint)*(255-src))/255;break;
    case 2:v=(tint*src)/255;break;
    case 3:v=src<128?(2*src*tint)/255:255-(2*(255-src)*(255-tint))/255;break;
    case 4:v=tint<128?(2*tint*src)/255:255-(2*(255-tint)*(255-src))/255;break;
    case 5:v=std::min(255,(src*256)/std::max(1,256-tint));break;
    case 6:v=(tint+src)/2;break;
    default:break;
  }
  return (unsigned char)std::clamp(v,0,255);
}
static SpriteImage transformOpenBORSprite(const SpriteImage& src,const generated::DrawMethod& d,bool entityFlip){if(src.width<=0||src.height<=0||src.bgra.empty())return src;float sx=d.enabled?d.scaleX:1.0f,sy=d.enabled?d.scaleY:1.0f;bool fx=entityFlip^(d.enabled&&d.flipX)^(sx<0.0f);bool fy=(d.enabled&&d.flipY)^(sy<0.0f);sx=std::max(0.01f,std::abs(sx));sy=std::max(0.01f,std::abs(sy));int sw=std::max(1,(int)std::lround(src.width*sx)),sh=std::max(1,(int)std::lround(src.height*sy));SpriteImage scaled;scaled.width=sw;scaled.height=sh;scaled.bgra.assign((size_t)sw*sh*4,0);const float shear=d.enabled?d.shiftX:0.0f;for(int y=0;y<sh;++y){float srcY=(float)y/sy;int iy=std::clamp((int)srcY,0,src.height-1);if(fy)iy=src.height-1-iy;float rowShift=shear*((float)y-(float)sh*0.5f);for(int x=0;x<sw;++x){float ux=(float)x-rowShift;if(ux<0||ux>=sw)continue;int ix=std::clamp((int)(ux/sx),0,src.width-1);if(fx)ix=src.width-1-ix;size_t si=((size_t)iy*src.width+ix)*4u,di=((size_t)y*sw+x)*4u;unsigned char b=src.bgra[si],g=src.bgra[si+1],r=src.bgra[si+2],a=src.bgra[si+3];if(d.enabled&&d.fillColor>255&&a){unsigned int col=(unsigned int)d.fillColor;r=(unsigned char)((col>>16)&255);g=(unsigned char)((col>>8)&255);b=(unsigned char)(col&255);b=(unsigned char)((unsigned)b*a/255u);g=(unsigned char)((unsigned)g*a/255u);r=(unsigned char)((unsigned)r*a/255u);}if(d.enabled&&d.tintMode>=1&&d.tintMode<=6&&a){unsigned int col=(unsigned int)d.tintColor;unsigned char tr=(unsigned char)((col>>16)&255),tg=(unsigned char)((col>>8)&255),tb=(unsigned char)(col&255);r=blendTintChannel(d.tintMode,tr,r);g=blendTintChannel(d.tintMode,tg,g);b=blendTintChannel(d.tintMode,tb,b);}scaled.bgra[di]=b;scaled.bgra[di+1]=g;scaled.bgra[di+2]=r;scaled.bgra[di+3]=a;}}int angle=d.enabled?d.rotate:0;if(d.enabled&&d.flipRotate&&entityFlip&&angle)angle=(360-angle)%360;if(angle==0)return scaled;const double rad=(double)angle*3.14159265358979323846/180.0,cs=std::cos(rad),sn=std::sin(rad);int rw=std::max(1,(int)std::ceil(std::abs(sw*cs)+std::abs(sh*sn))),rh=std::max(1,(int)std::ceil(std::abs(sw*sn)+std::abs(sh*cs)));SpriteImage rot;rot.width=rw;rot.height=rh;rot.bgra.assign((size_t)rw*rh*4,0);double cx=(sw-1)*0.5,cy=(sh-1)*0.5,dcx=(rw-1)*0.5,dcy=(rh-1)*0.5;for(int y=0;y<rh;++y)for(int x=0;x<rw;++x){double dx=x-dcx,dy=y-dcy;double ox=cs*dx+sn*dy+cx,oy=-sn*dx+cs*dy+cy;int ix=(int)std::lround(ox),iy=(int)std::lround(oy);if(ix<0||iy<0||ix>=sw||iy>=sh)continue;size_t si=((size_t)iy*sw+ix)*4u,di=((size_t)y*rw+x)*4u;std::memcpy(&rot.bgra[di],&scaled.bgra[si],4);}return rot;}
static std::pair<int,int> transformedOpenBORAnchor(const SpriteImage& src,const generated::Frame& f,bool entityFlip){
  const auto& d=f.draw;float rawSx=d.enabled?d.scaleX:1.0f,rawSy=d.enabled?d.scaleY:1.0f;bool fx=entityFlip^(d.enabled&&d.flipX)^(rawSx<0.0f);bool fy=(d.enabled&&d.flipY)^(rawSy<0.0f);float sx=std::max(0.01f,std::abs(rawSx)),sy=std::max(0.01f,std::abs(rawSy));int sw=std::max(1,(int)std::lround(src.width*sx)),sh=std::max(1,(int)std::lround(src.height*sy));double ax=(double)f.offsetX*sx,ay=(double)f.offsetY*sy;if(fx)ax=(double)sw-ax;if(fy)ay=(double)sh-ay;const double shear=d.enabled?(double)d.shiftX:0.0;ax+=shear*(ay-(double)sh*0.5);int angle=d.enabled?d.rotate:0;if(d.enabled&&d.flipRotate&&entityFlip&&angle)angle=(360-angle)%360;if(angle){const double rad=(double)angle*3.14159265358979323846/180.0,cs=std::cos(rad),sn=std::sin(rad);int rw=std::max(1,(int)std::ceil(std::abs(sw*cs)+std::abs(sh*sn))),rh=std::max(1,(int)std::ceil(std::abs(sw*sn)+std::abs(sh*cs)));const double cx=(sw-1)*0.5,cy=(sh-1)*0.5,dcx=(rw-1)*0.5,dcy=(rh-1)*0.5;const double dx=ax-cx,dy=ay-cy;ax=cs*dx-sn*dy+dcx;ay=sn*dx+cs*dy+dcy;}return {(int)std::lround(ax),(int)std::lround(ay)};
}
void Renderer::drawFrame(const SpriteImage& img,const generated::Frame& f,int originX,int originY,const RuntimeConfig& c,bool flipX,int modelAlphaMode){
#ifdef _WIN32
  if(!frameDC_)return;HDC dc=(HDC)frameDC_;auto rendered=transformOpenBORSprite(img,f.draw,flipX);auto anchor=transformedOpenBORAnchor(img,f,flipX);int x=originX-anchor.first,y=originY-anchor.second;if(rendered.width>0&&rendered.height>0&&!rendered.bgra.empty()){int alphaMode=(f.draw.alphaMode>=1&&f.draw.alphaMode<=6)?f.draw.alphaMode:modelAlphaMode;if(alphaMode>=1&&alphaMode<=6)drawOpenBORBlend(dc,rendered,x,y,alphaMode);else drawImage(rendered,x,y);}int baseX=flipX?originX-(img.width-f.offsetX):originX-f.offsetX,baseY=originY-f.offsetY;if(c.showBBox&&f.hasBBox){int bx=flipX?img.width-f.bbox.x-f.bbox.w:f.bbox.x;HPEN p=CreatePen(PS_SOLID,1,RGB(0,255,80));HGDIOBJ old=SelectObject(dc,p);SelectObject(dc,GetStockObject(NULL_BRUSH));Rectangle(dc,baseX+bx,baseY+f.bbox.y,baseX+bx+f.bbox.w,baseY+f.bbox.y+f.bbox.h);SelectObject(dc,old);DeleteObject(p);}if(c.showAttackBox&&f.hasAttack){int ax=flipX?img.width-f.attack.x-f.attack.w:f.attack.x;HPEN p=CreatePen(PS_SOLID,1,RGB(255,60,60));HGDIOBJ old=SelectObject(dc,p);SelectObject(dc,GetStockObject(NULL_BRUSH));Rectangle(dc,baseX+ax,baseY+f.attack.y,baseX+ax+f.attack.w,baseY+f.attack.y+f.attack.h);SelectObject(dc,old);DeleteObject(p);}
#else
  (void)img;(void)f;(void)originX;(void)originY;(void)c;(void)flipX;(void)modelAlphaMode;
#endif
}
#ifdef _WIN32
void Renderer::presentWithGdiFallback(){if(!hwnd_||!frameBits_)return;HWND h=(HWND)hwnd_;HDC dc=GetDC(h);RECT rc{};GetClientRect(h,&rc);int cw=std::max(1L,rc.right-rc.left),ch=std::max(1L,rc.bottom-rc.top);int dw=cw,dh=ch,dx=0,dy=0,sx=0,sy=0,sw=config_.logicalWidth,sh=config_.logicalHeight;float srcAspect=(float)config_.logicalWidth/(float)config_.logicalHeight,targetAspect=(float)cw/(float)ch;if(config_.fill169){if(targetAspect>srcAspect){sh=std::max(1,(int)std::lround(config_.logicalWidth/targetAspect));sy=(config_.logicalHeight-sh)/2;}else{sw=std::max(1,(int)std::lround(config_.logicalHeight*targetAspect));sx=(config_.logicalWidth-sw)/2;}}else if(config_.keepAspect43||config_.pixelPerfect||config_.integerScale>0){int scale=config_.integerScale>0?config_.integerScale:std::max(1,std::min(cw/config_.logicalWidth,ch/config_.logicalHeight));if(config_.pixelPerfect||config_.integerScale>0){dw=config_.logicalWidth*scale;dh=config_.logicalHeight*scale;}else if((float)cw/ch>srcAspect){dh=ch;dw=(int)(dh*srcAspect);}else{dw=cw;dh=(int)(dw/srcAspect);}dx=(cw-dw)/2;dy=(ch-dh)/2;}HBRUSH black=CreateSolidBrush(RGB(0,0,0));FillRect(dc,&rc,black);DeleteObject(black);SetStretchBltMode(dc,config_.textureFilter=="nearest"?COLORONCOLOR:HALFTONE);BITMAPINFO bi{};bi.bmiHeader.biSize=sizeof(BITMAPINFOHEADER);bi.bmiHeader.biWidth=config_.logicalWidth;bi.bmiHeader.biHeight=-config_.logicalHeight;bi.bmiHeader.biPlanes=1;bi.bmiHeader.biBitCount=32;bi.bmiHeader.biCompression=BI_RGB;StretchDIBits(dc,dx,dy,dw,dh,sx,sy,sw,sh,frameBits_,&bi,DIB_RGB_COLORS,SRCCOPY);ReleaseDC(h,dc);}
#endif
#ifdef _WIN32
bool Renderer::presentD3D11FrameUnsafe(){
  auto* dev=(ID3D11Device*)d3dDevice_;auto* ctx=(ID3D11DeviceContext*)d3dContext_;auto* sc=(IDXGISwapChain*)swapChain_;auto* src=(ID3D11Texture2D*)sourceTexture_;
  if(!dev||!ctx||!sc||!src||!sourceSRV_||!samplerPoint_||!samplerLinear_||!vertexShader_||!pixelShader_||!constantBuffer_||!frameBits_)return false;
  ctx->UpdateSubresource(src,0,nullptr,frameBits_,(UINT)frameStride_,0);
  ID3D11Texture2D* back=nullptr;HRESULT hr=sc->GetBuffer(0,__uuidof(ID3D11Texture2D),(void**)&back);if(FAILED(hr)||!back)return false;
  ID3D11RenderTargetView* rtv=nullptr;hr=dev->CreateRenderTargetView(back,nullptr,&rtv);back->Release();if(FAILED(hr)||!rtv)return false;
  float clear[4]={0,0,0,1};ctx->ClearRenderTargetView(rtv,clear);RECT rc{};GetClientRect((HWND)hwnd_,&rc);int cw=std::max(1L,rc.right-rc.left),ch=std::max(1L,rc.bottom-rc.top);float vw=(float)cw,vh=(float)ch,vx=0,vy=0;ShaderParams sp;sp.texelX=1.0f/config_.logicalWidth;sp.texelY=1.0f/config_.logicalHeight;sp.sharpen=config_.sharpen;sp.contrast=config_.contrast;sp.saturation=config_.saturation;sp.bloom=config_.bloom?0.28f:0.0f;sp.scanline=(config_.scanlines||config_.crt)?0.55f:0.0f;sp.curvature=config_.crtCurvature?1.0f:0.0f;sp.banding=config_.reduceBanding?1.0f:0.0f;sp.mode=config_.upscaleMode=="sharp-bilinear"?1.0f:(config_.upscaleMode=="cas"?2.0f:(config_.upscaleMode=="xbr"||config_.upscaleMode=="xbrz-like"?3.0f:0.0f));sp.time=(float)(GetTickCount64()%100000)/1000.0f;sp.unused=config_.crt?1.0f:0.0f;float srcAspect=(float)config_.logicalWidth/(float)config_.logicalHeight,targetAspect=(float)cw/(float)ch;if(config_.fill169){if(targetAspect>srcAspect){sp.uvScaleY=srcAspect/targetAspect;sp.uvOffsetY=(1.0f-sp.uvScaleY)*0.5f;}else{sp.uvScaleX=targetAspect/srcAspect;sp.uvOffsetX=(1.0f-sp.uvScaleX)*0.5f;}}else if(config_.keepAspect43||config_.pixelPerfect||config_.integerScale>0){if(config_.integerScale>0||config_.pixelPerfect){int scale=config_.integerScale>0?config_.integerScale:std::max(1,std::min(cw/config_.logicalWidth,ch/config_.logicalHeight));vw=(float)(config_.logicalWidth*scale);vh=(float)(config_.logicalHeight*scale);}else if(targetAspect>srcAspect){vh=(float)ch;vw=vh*srcAspect;}else{vw=(float)cw;vh=vw/srcAspect;}vx=(cw-vw)*0.5f;vy=(ch-vh)*0.5f;}
  D3D11_VIEWPORT vp{vx,vy,vw,vh,0,1};ctx->RSSetViewports(1,&vp);ctx->OMSetRenderTargets(1,&rtv,nullptr);ctx->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);ctx->IASetInputLayout(nullptr);ctx->VSSetShader((ID3D11VertexShader*)vertexShader_,nullptr,0);ctx->PSSetShader((ID3D11PixelShader*)pixelShader_,nullptr,0);ID3D11ShaderResourceView* srv=(ID3D11ShaderResourceView*)sourceSRV_;ctx->PSSetShaderResources(0,1,&srv);ID3D11SamplerState* samp=config_.textureFilter=="nearest"?(ID3D11SamplerState*)samplerPoint_:(ID3D11SamplerState*)samplerLinear_;ctx->PSSetSamplers(0,1,&samp);D3D11_MAPPED_SUBRESOURCE map{};hr=ctx->Map((ID3D11Buffer*)constantBuffer_,0,D3D11_MAP_WRITE_DISCARD,0,&map);if(FAILED(hr)||!map.pData){rtv->Release();return false;}std::memcpy(map.pData,&sp,sizeof(sp));ctx->Unmap((ID3D11Buffer*)constantBuffer_,0);ID3D11Buffer* cb=(ID3D11Buffer*)constantBuffer_;ctx->PSSetConstantBuffers(0,1,&cb);ctx->Draw(3,0);ID3D11ShaderResourceView* nullSrv=nullptr;ctx->PSSetShaderResources(0,1,&nullSrv);rtv->Release();hr=sc->Present(config_.vsync?1:0,0);if(FAILED(hr)){HRESULT removed=dev->GetDeviceRemovedReason();std::cerr<<"D3D11 Present failed hr=0x"<<std::hex<<(unsigned long)hr<<" removed=0x"<<(unsigned long)removed<<std::dec<<"\n";return false;}return true;
}
bool Renderer::presentD3D11Frame(){
#if defined(_MSC_VER)
  bool ok=false;
  __try { ok=presentD3D11FrameUnsafe(); }
  __except(EXCEPTION_EXECUTE_HANDLER) { ok=false; }
  return ok;
#else
  return presentD3D11FrameUnsafe();
#endif
}
#endif
void Renderer::endFrame(){
#ifdef _WIN32
  if(!d3dDevice_||!d3dContext_||!swapChain_){presentWithGdiFallback();return;}
  if(!presentD3D11Frame()){std::cerr<<"D3D11 runtime failure; switching permanently to Win32 GDI fallback.\n";abandonD3D11Resources();backend_="win32-gdi-recovered";presentWithGdiFallback();}
#endif
}
bool Renderer::loadPalette(const std::filesystem::path& path,std::vector<unsigned>& colors){
  colors.clear();
#ifdef _WIN32
  IWICImagingFactory* factory=nullptr;IWICBitmapDecoder* dec=nullptr;IWICBitmapFrameDecode* frame=nullptr;IWICPalette* palette=nullptr;
  if(FAILED(CoCreateInstance(CLSID_WICImagingFactory,nullptr,CLSCTX_INPROC_SERVER,IID_PPV_ARGS(&factory))))return false;
  std::wstring w=path.wstring();HRESULT hr=factory->CreateDecoderFromFilename(w.c_str(),nullptr,GENERIC_READ,WICDecodeMetadataCacheOnLoad,&dec);
  if(SUCCEEDED(hr))hr=dec->GetFrame(0,&frame);if(SUCCEEDED(hr))hr=factory->CreatePalette(&palette);if(SUCCEEDED(hr))hr=frame->CopyPalette(palette);
  UINT count=0;if(SUCCEEDED(hr))hr=palette->GetColorCount(&count);std::vector<WICColor> raw(count);UINT actual=0;if(SUCCEEDED(hr)&&count>0)hr=palette->GetColors(count,raw.data(),&actual);
  if(SUCCEEDED(hr)){colors.reserve(actual);for(UINT i=0;i<actual;++i){unsigned c=raw[i];unsigned b=c&255u,g=(c>>8)&255u,r=(c>>16)&255u;colors.push_back(b|(g<<8)|(r<<16));}}
  if(palette)palette->Release();if(frame)frame->Release();if(dec)dec->Release();if(factory)factory->Release();return SUCCEEDED(hr)&&!colors.empty();
#else
  (void)path;return false;
#endif
}
bool Renderer::loadSprite(const std::filesystem::path& path,SpriteImage& out){
#ifdef _WIN32
  IWICImagingFactory* factory=nullptr;IWICBitmapDecoder* dec=nullptr;IWICBitmapFrameDecode* frame=nullptr;IWICFormatConverter* conv=nullptr;if(FAILED(CoCreateInstance(CLSID_WICImagingFactory,nullptr,CLSCTX_INPROC_SERVER,IID_PPV_ARGS(&factory))))return false;std::wstring w=path.wstring();HRESULT hr=factory->CreateDecoderFromFilename(w.c_str(),nullptr,GENERIC_READ,WICDecodeMetadataCacheOnLoad,&dec);if(SUCCEEDED(hr))hr=dec->GetFrame(0,&frame);if(SUCCEEDED(hr))hr=factory->CreateFormatConverter(&conv);if(SUCCEEDED(hr))hr=conv->Initialize(frame,GUID_WICPixelFormat32bppBGRA,WICBitmapDitherTypeNone,nullptr,0.0,WICBitmapPaletteTypeCustom);UINT wi=0,he=0;if(SUCCEEDED(hr))hr=conv->GetSize(&wi,&he);if(SUCCEEDED(hr)){out.width=(int)wi;out.height=(int)he;out.bgra.resize((size_t)wi*he*4);hr=conv->CopyPixels(nullptr,wi*4,(UINT)out.bgra.size(),out.bgra.data());}if(SUCCEEDED(hr)&&frame&&!out.bgra.empty()){IWICPalette* palette=nullptr;bool paletted=false;if(SUCCEEDED(factory->CreatePalette(&palette))&&SUCCEEDED(frame->CopyPalette(palette))){UINT count=0;palette->GetColorCount(&count);if(count>0){WICColor color0=0;UINT actual=0;if(SUCCEEDED(palette->GetColors(1,&color0,&actual))&&actual==1){paletted=true;const unsigned char p0b=(unsigned char)(color0&0xFF),p0g=(unsigned char)((color0>>8)&0xFF),p0r=(unsigned char)((color0>>16)&0xFF);for(size_t i=0;i+3<out.bgra.size();i+=4){auto&b=out.bgra[i];auto&g=out.bgra[i+1];auto&r=out.bgra[i+2];auto&a=out.bgra[i+3];if(config_.openborPaletteIndex0Transparency&&r==p0r&&g==p0g&&b==p0b)a=0;b=(unsigned char)((unsigned)b*a/255u);g=(unsigned char)((unsigned)g*a/255u);r=(unsigned char)((unsigned)r*a/255u);}}}}if(!paletted){for(size_t i=0;i+3<out.bgra.size();i+=4){auto&b=out.bgra[i];auto&g=out.bgra[i+1];auto&r=out.bgra[i+2];auto&a=out.bgra[i+3];b=(unsigned char)((unsigned)b*a/255u);g=(unsigned char)((unsigned)g*a/255u);r=(unsigned char)((unsigned)r*a/255u);}}if(palette)palette->Release();}if(conv)conv->Release();if(frame)frame->Release();if(dec)dec->Release();if(factory)factory->Release();return SUCCEEDED(hr);
#else
  (void)path;out.width=64;out.height=64;out.bgra.assign(64*64*4,255);return std::filesystem::exists(path);
#endif
}
bool Renderer::loadAnimationFrames(const std::filesystem::path& path,std::vector<SpriteImage>& frames,std::vector<int>& delaysMs){
  frames.clear();delaysMs.clear();
#ifdef _WIN32
  IWICImagingFactory* factory=nullptr;IWICBitmapDecoder* dec=nullptr;if(FAILED(CoCreateInstance(CLSID_WICImagingFactory,nullptr,CLSCTX_INPROC_SERVER,IID_PPV_ARGS(&factory))))return false;std::wstring w=path.wstring();HRESULT hr=factory->CreateDecoderFromFilename(w.c_str(),nullptr,GENERIC_READ,WICDecodeMetadataCacheOnLoad,&dec);UINT count=0;if(SUCCEEDED(hr))hr=dec->GetFrameCount(&count);
  for(UINT i=0;SUCCEEDED(hr)&&i<count;++i){IWICBitmapFrameDecode* fr=nullptr;IWICFormatConverter* conv=nullptr;hr=dec->GetFrame(i,&fr);if(FAILED(hr)||!fr){if(fr)fr->Release();break;}hr=factory->CreateFormatConverter(&conv);if(SUCCEEDED(hr))hr=conv->Initialize(fr,GUID_WICPixelFormat32bppBGRA,WICBitmapDitherTypeNone,nullptr,0.0,WICBitmapPaletteTypeCustom);UINT wi=0,he=0;if(SUCCEEDED(hr))hr=conv->GetSize(&wi,&he);SpriteImage img;if(SUCCEEDED(hr)){img.width=(int)wi;img.height=(int)he;img.bgra.resize((size_t)wi*he*4);hr=conv->CopyPixels(nullptr,wi*4,(UINT)img.bgra.size(),img.bgra.data());for(size_t q=0;q+3<img.bgra.size();q+=4){auto&a=img.bgra[q+3];img.bgra[q]=(unsigned char)((unsigned)img.bgra[q]*a/255u);img.bgra[q+1]=(unsigned char)((unsigned)img.bgra[q+1]*a/255u);img.bgra[q+2]=(unsigned char)((unsigned)img.bgra[q+2]*a/255u);}}int delay=100;IWICMetadataQueryReader* qr=nullptr;if(SUCCEEDED(fr->GetMetadataQueryReader(&qr))&&qr){PROPVARIANT pv;PropVariantInit(&pv);if(SUCCEEDED(qr->GetMetadataByName(L"/grctlext/Delay",&pv))){if(pv.vt==VT_UI2)delay=std::max(10,(int)pv.uiVal*10);else if(pv.vt==VT_UI4)delay=std::max(10,(int)pv.ulVal*10);}PropVariantClear(&pv);qr->Release();}if(SUCCEEDED(hr)){frames.push_back(std::move(img));delaysMs.push_back(delay);}if(conv)conv->Release();fr->Release();}
  if(dec)dec->Release();if(factory)factory->Release();return !frames.empty();
#else
  SpriteImage img;if(!loadSprite(path,img))return false;frames.push_back(std::move(img));delaysMs.push_back(100);return true;
#endif
}
const std::string& Renderer::backend() const { return backend_; }
)CPP";

    std::ofstream audioDecoderH(include / "AudioDecoder.hpp");
    audioDecoderH << R"CPP(#pragma once
#include <cstdint>
#include <filesystem>
#include <string>
#include <vector>
struct DecodedAudio {
  int sampleRate = 22050;
  int channels = 1;
  std::vector<std::int16_t> pcm;
  std::uint32_t loopStartFrames = 0;
  std::uint32_t loopLengthFrames = 0;
  bool hasLoop = false;
  std::string format;
};
class AudioDecoder {
public:
  static bool decodeFile(const std::filesystem::path&, DecodedAudio&, std::string& error);
  // Legacy OpenBOR .bor music: 160-byte metadata header followed by Intel/IMA ADPCM.
  // Never pass .bor bytes directly to a PCM backend.
  static bool decodeOpenBorBor(const std::filesystem::path&, DecodedAudio&, std::string& error);
  static bool decodeWav(const std::filesystem::path&, DecodedAudio&, std::string& error);
#ifdef _WIN32
  static bool decodeMediaFoundation(const std::filesystem::path&, DecodedAudio&, std::string& error);
#endif
};
)CPP";

    std::ofstream audioDecoderCpp(src / "AudioDecoder.cpp");
    audioDecoderCpp << R"CPP(#include "PathEncoding.hpp"
#include "AudioDecoder.hpp"
#include <algorithm>
#include <array>
#include <cctype>
#include <cmath>
#include <cstring>
#include <fstream>
#include <iterator>
#ifdef _WIN32
#define NOMINMAX
#include <windows.h>
#include <mfapi.h>
#include <mfidl.h>
#include <mfreadwrite.h>
#endif

namespace {
constexpr std::array<int,16> kIndexTable={-1,-1,-1,-1,2,4,6,8,-1,-1,-1,-1,2,4,6,8};
constexpr std::array<int,89> kStepTable={
7,8,9,10,11,12,13,14,16,17,19,21,23,25,28,31,34,37,41,45,50,55,60,66,73,80,88,97,107,118,
130,143,157,173,190,209,230,253,279,307,337,371,408,449,494,544,598,658,724,796,876,963,1060,1166,
1282,1411,1552,1707,1878,2066,2272,2499,2749,3024,3327,3660,4026,4428,4871,5358,5894,6484,7132,7845,
8630,9493,10442,11487,12635,13899,15289,16818,18500,20350,22385,24623,27086,29794,32767};
struct State { int predicted=0; int index=0; };
std::int16_t decodeNibble(unsigned nibble, State& st){
  int step=kStepTable[(std::size_t)st.index], diff=step>>3;
  if(nibble&4) diff+=step; if(nibble&2) diff+=step>>1; if(nibble&1) diff+=step>>2;
  if(nibble&8) st.predicted-=diff; else st.predicted+=diff;
  st.predicted=std::clamp(st.predicted,-32768,32767);
  st.index=std::clamp(st.index+kIndexTable[nibble&0x0f],0,88);
  return (std::int16_t)st.predicted;
}
std::uint16_t u16(const unsigned char* p){ return (std::uint16_t)(p[0] | (p[1]<<8)); }
std::uint32_t u32(const unsigned char* p){ return (std::uint32_t)p[0] | ((std::uint32_t)p[1]<<8) | ((std::uint32_t)p[2]<<16) | ((std::uint32_t)p[3]<<24); }
std::string lowerExt(std::filesystem::path p){ auto s=PathEncoding::utf8(p.extension()); for(auto& c:s)c=(char)std::tolower((unsigned char)c); return s; }
}

bool AudioDecoder::decodeFile(const std::filesystem::path& path, DecodedAudio& out, std::string& error){
  auto ext=lowerExt(path);
  if(ext==".bor") return decodeOpenBorBor(path,out,error);
  if(ext==".wav" || ext==".wave") return decodeWav(path,out,error);
#ifdef _WIN32
  if(ext==".mp3" || ext==".flac" || ext==".ogg" || ext==".oga" || ext==".m4a" || ext==".aac") return decodeMediaFoundation(path,out,error);
#else
  if(ext==".mp3" || ext==".flac" || ext==".ogg" || ext==".oga" || ext==".m4a" || ext==".aac") { error="compressed audio requires the Windows Media Foundation backend in this generated runtime"; return false; }
#endif
  error="unsupported audio extension: "+ext; return false;
}

#ifdef _WIN32
bool AudioDecoder::decodeMediaFoundation(const std::filesystem::path& path, DecodedAudio& out, std::string& error){
  HRESULT hr=MFStartup(MF_VERSION,MFSTARTUP_LITE);if(FAILED(hr)){error="MFStartup failed for compressed audio";return false;}
  IMFSourceReader* reader=nullptr;IMFMediaType* requested=nullptr;IMFMediaType* actual=nullptr;bool ok=false;
  auto cleanup=[&](){if(actual)actual->Release();if(requested)requested->Release();if(reader)reader->Release();MFShutdown();};
  hr=MFCreateSourceReaderFromURL(path.wstring().c_str(),nullptr,&reader);if(FAILED(hr)){error="Media Foundation could not open compressed audio (codec may be unavailable)";cleanup();return false;}
  hr=MFCreateMediaType(&requested);if(SUCCEEDED(hr))hr=requested->SetGUID(MF_MT_MAJOR_TYPE,MFMediaType_Audio);if(SUCCEEDED(hr))hr=requested->SetGUID(MF_MT_SUBTYPE,MFAudioFormat_PCM);if(SUCCEEDED(hr))hr=requested->SetUINT32(MF_MT_AUDIO_BITS_PER_SAMPLE,16);if(SUCCEEDED(hr))hr=reader->SetCurrentMediaType(MF_SOURCE_READER_FIRST_AUDIO_STREAM,nullptr,requested);
  if(FAILED(hr)){error="Media Foundation could not negotiate PCM output";cleanup();return false;}
  hr=reader->GetCurrentMediaType(MF_SOURCE_READER_FIRST_AUDIO_STREAM,&actual);if(FAILED(hr)){error="Media Foundation did not expose decoded audio format";cleanup();return false;}
  UINT32 channels=MFGetAttributeUINT32(actual,MF_MT_AUDIO_NUM_CHANNELS,1),rate=MFGetAttributeUINT32(actual,MF_MT_AUDIO_SAMPLES_PER_SECOND,22050),bits=MFGetAttributeUINT32(actual,MF_MT_AUDIO_BITS_PER_SAMPLE,16);
  if(channels<1||channels>2||rate==0||bits!=16){error="Media Foundation PCM output is not supported (expected mono/stereo 16-bit)";cleanup();return false;}
  out=DecodedAudio{};out.channels=(int)channels;out.sampleRate=(int)rate;out.format="media-foundation-pcm16";std::vector<unsigned char> bytes;
  for(;;){DWORD stream=0,flags=0;LONGLONG ts=0;IMFSample* sample=nullptr;hr=reader->ReadSample(MF_SOURCE_READER_FIRST_AUDIO_STREAM,0,&stream,&flags,&ts,&sample);if(FAILED(hr)){if(sample)sample->Release();error="Media Foundation ReadSample failed";break;}if(flags&MF_SOURCE_READERF_ENDOFSTREAM){if(sample)sample->Release();ok=true;break;}if(flags&MF_SOURCE_READERF_CURRENTMEDIATYPECHANGED){if(actual){actual->Release();actual=nullptr;}reader->GetCurrentMediaType(MF_SOURCE_READER_FIRST_AUDIO_STREAM,&actual);if(actual){channels=MFGetAttributeUINT32(actual,MF_MT_AUDIO_NUM_CHANNELS,channels);rate=MFGetAttributeUINT32(actual,MF_MT_AUDIO_SAMPLES_PER_SECOND,rate);bits=MFGetAttributeUINT32(actual,MF_MT_AUDIO_BITS_PER_SAMPLE,bits);out.channels=(int)channels;out.sampleRate=(int)rate;if(bits!=16||channels<1||channels>2){if(sample)sample->Release();error="Media Foundation changed to unsupported PCM format";break;}}}
    if(sample){IMFMediaBuffer* buffer=nullptr;hr=sample->ConvertToContiguousBuffer(&buffer);if(SUCCEEDED(hr)&&buffer){BYTE* data=nullptr;DWORD maxLen=0,len=0;hr=buffer->Lock(&data,&maxLen,&len);if(SUCCEEDED(hr)&&data&&len){auto old=bytes.size();bytes.resize(old+len);std::memcpy(bytes.data()+old,data,len);buffer->Unlock();}buffer->Release();}sample->Release();if(FAILED(hr)){error="Media Foundation sample buffer conversion failed";break;}}
  }
  if(ok){if(bytes.size()<2){error="decoded compressed audio contained no PCM samples";ok=false;}else{out.pcm.resize(bytes.size()/2);std::memcpy(out.pcm.data(),bytes.data(),out.pcm.size()*2);}}
  cleanup();return ok;
}
#endif

bool AudioDecoder::decodeOpenBorBor(const std::filesystem::path& path, DecodedAudio& out, std::string& error){
  std::ifstream f(path,std::ios::binary); if(!f){ error="cannot open .bor music"; return false; }
  std::vector<unsigned char> bytes((std::istreambuf_iterator<char>(f)),{});
  constexpr std::size_t kHeader=160;
  if(bytes.size()<=kHeader){ error="invalid OpenBOR .bor: file is smaller than 160-byte header"; return false; }

  // Classic WAV2BOR input was normally 16-bit PCM, mono, 22050 Hz. Some later tools/ports
  // used variants, but there is no safe universal channel flag we can infer from arbitrary
  // legacy files. Until a verified header variant says otherwise, mono/22050 is deliberately
  // chosen over guessing stereo and corrupting playback.
  out=DecodedAudio{}; out.sampleRate=22050; out.channels=1; out.format="openbor-bor-ima-adpcm-mono";
  out.pcm.reserve((bytes.size()-kHeader)*2); State st{};
  for(std::size_t i=kHeader;i<bytes.size();++i){ const unsigned b=bytes[i]; out.pcm.push_back(decodeNibble((b>>4)&0x0f,st)); out.pcm.push_back(decodeNibble(b&0x0f,st)); }
  if(out.pcm.empty()){ error="OpenBOR .bor contains no ADPCM payload"; return false; }
  return true;
}

bool AudioDecoder::decodeWav(const std::filesystem::path& path, DecodedAudio& out, std::string& error){
  std::ifstream f(path,std::ios::binary); if(!f){ error="cannot open WAV"; return false; }
  std::vector<unsigned char> b((std::istreambuf_iterator<char>(f)),{});
  if(b.size()<44 || std::memcmp(b.data(),"RIFF",4)!=0 || std::memcmp(b.data()+8,"WAVE",4)!=0){ error="invalid RIFF/WAVE file"; return false; }
  std::uint16_t tag=0,channels=0,bits=0; std::uint32_t rate=0; const unsigned char* data=nullptr; std::size_t dataSize=0;
  std::uint32_t loopStart=0, loopEnd=0; bool haveLoop=false;
  for(std::size_t pos=12;pos+8<=b.size();){
    const char* id=(const char*)&b[pos]; std::uint32_t size=u32(&b[pos+4]); std::size_t body=pos+8; if(body+size>b.size()) break;
    if(std::memcmp(id,"fmt ",4)==0 && size>=16){ tag=u16(&b[body]); channels=u16(&b[body+2]); rate=u32(&b[body+4]); bits=u16(&b[body+14]); }
    else if(std::memcmp(id,"data",4)==0){ data=&b[body]; dataSize=size; }
    else if(std::memcmp(id,"smpl",4)==0 && size>=60){
      auto loops=u32(&b[body+28]); if(loops>0 && size>=60){ loopStart=u32(&b[body+44]); loopEnd=u32(&b[body+48]); haveLoop=loopEnd>=loopStart; }
    }
    pos=body+size+(size&1u);
  }
  if(!data||!dataSize||!channels||!rate){ error="WAV missing fmt/data chunk"; return false; }
  if(tag!=1 && tag!=3){ error="WAV codec is not PCM/IEEE-float"; return false; }
  if(tag==1 && bits!=8 && bits!=16 && bits!=24 && bits!=32){ error="WAV PCM bit depth must be 8/16/24/32"; return false; }
  if(tag==3 && bits!=32){ error="WAV IEEE-float must be 32-bit"; return false; }
  if(channels>2){ error="WAV channel count >2 is not supported by preview runtime"; return false; }
  out=DecodedAudio{}; out.sampleRate=(int)rate; out.channels=(int)channels; out.format=tag==3?"wav-float32":("wav-pcm"+std::to_string(bits));
  if(tag==3){
    out.pcm.reserve(dataSize/4);for(std::size_t i=0;i+3<dataSize;i+=4){float f32=0;std::memcpy(&f32,data+i,4);f32=std::clamp(f32,-1.0f,1.0f);out.pcm.push_back((std::int16_t)std::lround(f32*32767.0f));}
  } else if(bits==32){
    out.pcm.reserve(dataSize/4);for(std::size_t i=0;i+3<dataSize;i+=4){std::int32_t v=(std::int32_t)u32(data+i);out.pcm.push_back((std::int16_t)(v>>16));}
  } else if(bits==24){
    out.pcm.reserve(dataSize/3);for(std::size_t i=0;i+2<dataSize;i+=3){std::int32_t v=(std::int32_t)(data[i]|(data[i+1]<<8)|(data[i+2]<<16));if(v&0x800000)v|=~0xFFFFFF;out.pcm.push_back((std::int16_t)(v>>8));}
  } else if(bits==16){
    auto samples=dataSize/2; out.pcm.reserve(samples);
    for(std::size_t i=0;i+1<dataSize;i+=2) out.pcm.push_back((std::int16_t)u16(data+i));
  } else {
    out.pcm.reserve(dataSize); for(std::size_t i=0;i<dataSize;++i) out.pcm.push_back((std::int16_t)(((int)data[i]-128)<<8));
  }
  if(haveLoop){ out.hasLoop=true; out.loopStartFrames=loopStart; out.loopLengthFrames=loopEnd-loopStart+1; }
  if(out.pcm.empty()){ error="WAV contains no PCM samples"; return false; }
  return true;
}
)CPP";

    std::ofstream audioH(include / "AudioSystem.hpp");
    audioH << R"CPP(#pragma once
#include "RuntimeConfig.hpp"
#include <random>
#include "AudioDecoder.hpp"
#include <filesystem>
#include <memory>
#include <string>
#include <vector>
class AudioSystem {
public:
  ~AudioSystem();
  bool initialize(const RuntimeConfig&);
  bool playMusic(const std::filesystem::path&, bool loop=true, std::size_t loopOffsetBytes=0);
  bool playEffect(const std::filesystem::path&, float gain=1.0f, bool loop=false, float speed=1.0f);
  void stopMusic();
  void pauseMusic(bool paused);
  void setMasterVolume(float);
  void setMusicVolume(float);
  void setEffectsVolume(float);
  float masterVolume() const { return config_.masterVolume; }
  float musicVolume() const { return config_.musicVolume; }
  float effectsVolume() const { return config_.effectsVolume; }
  const std::string& lastError() const { return error_; }
private:
  void applyVolumes();
  void cleanupEffects();
  RuntimeConfig config_{};
  std::string error_;
#ifdef _WIN32
  struct ActiveEffect { void* voice=nullptr; std::shared_ptr<DecodedAudio> audio; float gain=1.0f; };
  void* xaudio_ = nullptr;
  void* mastering_ = nullptr;
  void* musicVoice_ = nullptr;
  std::vector<ActiveEffect> effectVoices_;
#endif
  bool musicPaused_ = false;
  DecodedAudio musicBuffer_{};
};
)CPP";

    std::ofstream audioCpp(src / "AudioSystem.cpp");
    audioCpp << R"CPP(#include "PathEncoding.hpp"
#include "AudioSystem.hpp"
#include <algorithm>
#include <cctype>
#include <iostream>
#ifdef _WIN32
#define NOMINMAX
#include <windows.h>
#include <xaudio2.h>
#endif

AudioSystem::~AudioSystem(){
#ifdef _WIN32
  for(auto& e:effectVoices_) if(e.voice) ((IXAudio2SourceVoice*)e.voice)->DestroyVoice();
  effectVoices_.clear();
  if(musicVoice_){ ((IXAudio2SourceVoice*)musicVoice_)->DestroyVoice(); musicVoice_=nullptr; }
  if(mastering_){ ((IXAudio2MasteringVoice*)mastering_)->DestroyVoice(); mastering_=nullptr; }
  if(xaudio_){ ((IXAudio2*)xaudio_)->Release(); xaudio_=nullptr; }
#endif
}
bool AudioSystem::initialize(const RuntimeConfig& c){
  config_=c;
#ifdef _WIN32
  IXAudio2* xa=nullptr; HRESULT hr=XAudio2Create(&xa,0,XAUDIO2_DEFAULT_PROCESSOR);
  if(FAILED(hr)){ error_="XAudio2Create failed"; return false; }
  IXAudio2MasteringVoice* mv=nullptr; hr=xa->CreateMasteringVoice(&mv);
  if(FAILED(hr)){ xa->Release(); error_="CreateMasteringVoice failed"; return false; }
  xaudio_=xa; mastering_=mv;
#endif
  return true;
}
static void fillFormat(const DecodedAudio& a,
#ifdef _WIN32
WAVEFORMATEX& fmt
#else
int& fmt
#endif
){
#ifdef _WIN32
  fmt={}; fmt.wFormatTag=WAVE_FORMAT_PCM; fmt.nChannels=(WORD)a.channels; fmt.nSamplesPerSec=a.sampleRate; fmt.wBitsPerSample=16;
  fmt.nBlockAlign=(WORD)(fmt.nChannels*2); fmt.nAvgBytesPerSec=fmt.nSamplesPerSec*fmt.nBlockAlign;
#else
  (void)a; (void)fmt;
#endif
}
bool AudioSystem::playMusic(const std::filesystem::path& path, bool loop, std::size_t loopOffsetBytes){
  error_.clear(); auto ext=PathEncoding::utf8(path.extension()); for(auto& c:ext)c=(char)std::tolower((unsigned char)c);
  if(ext==".bor" && !config_.openborBorAdpcm){ error_="OpenBOR .bor ADPCM decoder disabled"; return false; }
  if(!AudioDecoder::decodeFile(path,musicBuffer_,error_)) return false;
#ifdef _WIN32
  auto* xa=(IXAudio2*)xaudio_; if(!xa){ error_="audio system not initialized"; return false; }
  if(musicVoice_){ ((IXAudio2SourceVoice*)musicVoice_)->DestroyVoice(); musicVoice_=nullptr; }
  WAVEFORMATEX fmt{}; fillFormat(musicBuffer_,fmt); IXAudio2SourceVoice* voice=nullptr;
  HRESULT hr=xa->CreateSourceVoice(&voice,&fmt); if(FAILED(hr)){ error_="CreateSourceVoice(music) failed"; return false; }
  XAUDIO2_BUFFER buf{}; buf.AudioBytes=(UINT32)(musicBuffer_.pcm.size()*sizeof(std::int16_t)); buf.pAudioData=(const BYTE*)musicBuffer_.pcm.data(); buf.Flags=XAUDIO2_END_OF_STREAM;
  if(loop){
    const std::size_t totalFrames=musicBuffer_.pcm.size()/(std::size_t)std::max(1,musicBuffer_.channels);
    if(loopOffsetBytes>0 && totalFrames>1){std::error_code ec;auto sourceBytes=std::filesystem::file_size(path,ec);if(!ec&&sourceBytes>0){double ratio=std::clamp((double)loopOffsetBytes/(double)sourceBytes,0.0,0.999999);buf.LoopBegin=(UINT32)std::min<std::size_t>(totalFrames-1,(std::size_t)std::llround(ratio*(double)totalFrames));buf.LoopLength=(UINT32)(totalFrames-buf.LoopBegin);}}
    else if(musicBuffer_.hasLoop && musicBuffer_.loopLengthFrames>0){ buf.LoopBegin=musicBuffer_.loopStartFrames; buf.LoopLength=musicBuffer_.loopLengthFrames; }
    buf.LoopCount=XAUDIO2_LOOP_INFINITE;
  }
  hr=voice->SubmitSourceBuffer(&buf); if(FAILED(hr)){ voice->DestroyVoice(); error_="SubmitSourceBuffer(music) failed"; return false; }
  musicVoice_=voice; musicPaused_=false; applyVolumes(); hr=voice->Start(0); if(FAILED(hr)){ voice->DestroyVoice(); musicVoice_=nullptr; error_="XAudio2 music start failed"; return false; }
#else
  (void)loop;(void)loopOffsetBytes; std::cout<<"Decoded music: "<<musicBuffer_.format<<" "<<musicBuffer_.channels<<"ch "<<musicBuffer_.sampleRate<<"Hz frames="<<(musicBuffer_.pcm.size()/std::max(1,musicBuffer_.channels))<<"\n";
#endif
  return true;
}
void AudioSystem::cleanupEffects(){
#ifdef _WIN32
  for(auto it=effectVoices_.begin();it!=effectVoices_.end();){auto* v=(IXAudio2SourceVoice*)it->voice;XAUDIO2_VOICE_STATE state{};if(v)v->GetState(&state);if(!v||state.BuffersQueued==0){if(v)v->DestroyVoice();it=effectVoices_.erase(it);}else ++it;}
#endif
}
bool AudioSystem::playEffect(const std::filesystem::path& path,float gain,bool loop,float speed){
  error_.clear(); auto decoded=std::make_shared<DecodedAudio>(); if(!AudioDecoder::decodeFile(path,*decoded,error_)) return false;
#ifdef _WIN32
  auto* xa=(IXAudio2*)xaudio_; if(!xa){ error_="audio system not initialized"; return false; } cleanupEffects();
  WAVEFORMATEX fmt{}; fillFormat(*decoded,fmt); IXAudio2SourceVoice* voice=nullptr;
  HRESULT hr=xa->CreateSourceVoice(&voice,&fmt,0,2.0f); if(FAILED(hr)){ error_="CreateSourceVoice(effect) failed"; return false; }
  XAUDIO2_BUFFER buf{}; buf.AudioBytes=(UINT32)(decoded->pcm.size()*sizeof(std::int16_t)); buf.pAudioData=(const BYTE*)decoded->pcm.data(); buf.Flags=XAUDIO2_END_OF_STREAM; if(loop)buf.LoopCount=XAUDIO2_LOOP_INFINITE;
  hr=voice->SubmitSourceBuffer(&buf); if(FAILED(hr)){ voice->DestroyVoice(); error_="SubmitSourceBuffer(effect) failed"; return false; }
  voice->SetVolume(std::clamp(config_.masterVolume*config_.effectsVolume*gain,0.0f,2.0f)); voice->SetFrequencyRatio(std::clamp(speed,0.5f,2.0f));
  hr=voice->Start(0); if(FAILED(hr)){ voice->DestroyVoice(); error_="XAudio2 effect start failed"; return false; } effectVoices_.push_back({voice,decoded,gain});
#else
  (void)gain;(void)loop;(void)speed;std::cout<<"Decoded effect: "<<decoded->format<<" "<<decoded->channels<<"ch "<<decoded->sampleRate<<"Hz\n";
#endif
  return true;
}
void AudioSystem::stopMusic(){
#ifdef _WIN32
  if(musicVoice_) ((IXAudio2SourceVoice*)musicVoice_)->Stop(0);
#endif
  musicPaused_=false;
}
void AudioSystem::pauseMusic(bool paused){
#ifdef _WIN32
  if(musicVoice_){ if(paused)((IXAudio2SourceVoice*)musicVoice_)->Stop(0); else ((IXAudio2SourceVoice*)musicVoice_)->Start(0); }
#endif
  musicPaused_=paused;
}
void AudioSystem::applyVolumes(){
#ifdef _WIN32
  if(musicVoice_) ((IXAudio2SourceVoice*)musicVoice_)->SetVolume(std::clamp(config_.masterVolume*config_.musicVolume,0.0f,1.0f));
  cleanupEffects(); for(auto& e:effectVoices_) if(e.voice) ((IXAudio2SourceVoice*)e.voice)->SetVolume(std::clamp(config_.masterVolume*config_.effectsVolume*e.gain,0.0f,2.0f));
#endif
}
void AudioSystem::setMasterVolume(float v){ config_.masterVolume=std::clamp(v,0.0f,1.0f); applyVolumes(); }
void AudioSystem::setMusicVolume(float v){ config_.musicVolume=std::clamp(v,0.0f,1.0f); applyVolumes(); }
void AudioSystem::setEffectsVolume(float v){ config_.effectsVolume=std::clamp(v,0.0f,1.0f); applyVolumes(); }
)CPP";

    std::ofstream player(include / "AnimationPlayer.hpp");
    player << R"CPP(#pragma once
#include "../generated/GeneratedCharacters.hpp"
#include <cstddef>
class AnimationPlayer {
public:
  void setAnimation(const generated::Animation* animation);
  void update(int ticks=1);
  void setFrame(std::size_t frameIndex);
  const generated::Frame* frame() const;
  const generated::Animation* animation() const { return animation_; }
  std::size_t frameIndex() const { return frameIndex_; }
  bool finished() const { return finished_; }
private:
  const generated::Animation* animation_ = nullptr;
  std::size_t frameIndex_ = 0;
  int tick_ = 0;
  bool finished_ = false;
};
)CPP";
    std::ofstream playerCpp(src / "AnimationPlayer.cpp");
    playerCpp << R"CPP(#include "PathEncoding.hpp"
#include "AnimationPlayer.hpp"
#include <algorithm>
void AnimationPlayer::setAnimation(const generated::Animation* a){ animation_=a; frameIndex_=0; tick_=0; finished_=false; }
void AnimationPlayer::setFrame(std::size_t frameIndex){ if(!animation_||animation_->frameCount==0)return;frameIndex_=std::min(frameIndex,animation_->frameCount-1);tick_=0;finished_=false; }
void AnimationPlayer::update(int ticks){
  if(!animation_ || animation_->frameCount==0 || finished_) return;
  const auto frameDelay=[&](){ return animation_->frames[frameIndex_].delay; };
  if(frameDelay()<0) return; // OpenBOR infinite delay: hold current frame.
  tick_ += std::max(0,ticks);
  int delay=std::max(1,frameDelay());
  while(tick_>=delay && !finished_){
    tick_-=delay;
    const std::size_t last=animation_->frameCount-1;
    const std::size_t loopStart=(std::size_t)std::clamp(animation_->loopStart,0,(int)last);
    const std::size_t loopEnd=animation_->loopEnd<0?last:(std::size_t)std::clamp(animation_->loopEnd,0,(int)last);
    if(animation_->loop && frameIndex_>=loopEnd){ frameIndex_=std::min(loopStart,loopEnd); }
    else if(frameIndex_<last){ ++frameIndex_; }
    else if(animation_->loop){ frameIndex_=std::min(loopStart,last); }
    else { finished_=true; tick_=0; break; }
    if(animation_->frames[frameIndex_].delay<0){ tick_=0; break; }
    delay=std::max(1,animation_->frames[frameIndex_].delay);
  }
}
const generated::Frame* AnimationPlayer::frame() const { if(!animation_||animation_->frameCount==0) return nullptr; return &animation_->frames[frameIndex_]; }
)CPP";

    std::ofstream scriptVmH(include / "ScriptVM.hpp");
    scriptVmH << R"CPP(#pragma once
#include <cstdint>
#include <filesystem>
#include <memory>
#include <string>
#include <unordered_map>
#include <variant>
#include <vector>
struct ScriptArray;
using ScriptArrayPtr = std::shared_ptr<ScriptArray>;
using ScriptValue = std::variant<std::monostate,double,std::string,bool,std::uintptr_t,ScriptArrayPtr>;
struct ScriptArray {
  std::vector<ScriptValue> indexed;
  std::unordered_map<std::string,ScriptValue> named;
  std::vector<std::string> namedOrder;
  std::size_t cursor=0;
};
struct ScriptContext {
  std::unordered_map<std::string,ScriptValue> local;
  void* entity=nullptr;
  void* other=nullptr;
  bool player=false;
  int playerIndex=0;
};
struct ScriptRunResult { bool ok=true; std::string error; std::vector<std::string> unsupported; };
class ScriptHost {
public:
  virtual ~ScriptHost()=default;
  virtual ScriptValue callScriptFunction(const std::string&,const std::vector<ScriptValue>&,ScriptContext&,std::vector<std::string>& unsupported)=0;
};
class ScriptVM {
public:
  void setRoot(std::filesystem::path p){root_=std::move(p);}
  void setHost(ScriptHost* h){host_=h;}
  ScriptRunResult runFile(const std::string& path,ScriptContext& context,const std::string& function="main");
  ScriptRunResult runAnimationCommand(const std::string& helperPath,const std::string& command,ScriptContext& context);
  const std::unordered_map<std::string,ScriptValue>& globals() const { return globals_; }
private:
  std::filesystem::path root_;
  ScriptHost* host_=nullptr;
  std::unordered_map<std::string,std::string> sourceCache_;
  std::unordered_map<std::string,ScriptValue> globals_;
};
)CPP";

    std::ofstream scriptVmCpp(src / "ScriptVM.cpp");
    scriptVmCpp << R"CPP(#include "PathEncoding.hpp"
#include "ScriptVM.hpp"
#include <algorithm>
#include <cctype>
#include <cmath>
#include <fstream>
#include <random>
#include <sstream>
#include <stdexcept>
#include <unordered_set>

namespace {
enum class TK{End,Id,Num,Str,Sym};
struct Tok{TK k=TK::End;std::string s;};
static std::string lower(std::string s){for(auto&c:s)c=(char)std::tolower((unsigned char)c);return s;}
static bool truth(const ScriptValue&v){if(auto p=std::get_if<bool>(&v))return *p;if(auto p=std::get_if<double>(&v))return *p!=0;if(auto p=std::get_if<std::string>(&v))return !p->empty();if(auto p=std::get_if<std::uintptr_t>(&v))return *p!=0;if(auto p=std::get_if<ScriptArrayPtr>(&v))return p&&*p;return false;}
static double num(const ScriptValue&v){if(auto p=std::get_if<double>(&v))return *p;if(auto p=std::get_if<bool>(&v))return *p?1:0;if(auto p=std::get_if<std::uintptr_t>(&v))return (double)*p;if(auto p=std::get_if<std::string>(&v)){try{return std::stod(*p);}catch(...){}}return 0;}
static std::string str(const ScriptValue&v){if(auto p=std::get_if<std::string>(&v))return *p;if(auto p=std::get_if<double>(&v)){std::ostringstream o;o<<*p;return o.str();}if(auto p=std::get_if<bool>(&v))return *p?"1":"0";if(auto p=std::get_if<std::uintptr_t>(&v))return std::to_string(*p);if(auto p=std::get_if<ScriptArrayPtr>(&v))return (p&&*p)?"[array]":"";return {};}
static bool eq(const ScriptValue&a,const ScriptValue&b){if(a.index()==2||b.index()==2)return str(a)==str(b);if(a.index()==5||b.index()==5){auto ap=std::get_if<ScriptArrayPtr>(&a),bp=std::get_if<ScriptArrayPtr>(&b);return ap&&bp&&*ap==*bp;}return std::fabs(num(a)-num(b))<0.000001;}
static bool isTypeName(const std::string&s){auto q=lower(s);return q=="void"||q=="int"||q=="float"||q=="char"||q=="string"||q=="mixed"||q=="decimal"||q=="pointer";}
static std::vector<Tok> lex(const std::string&in){
  std::vector<Tok>o;size_t i=0;
  while(i<in.size()){
    unsigned char c=in[i];
    if(std::isspace(c)){++i;continue;}
    if(c=='#'){while(i<in.size()&&in[i]!='\n')++i;continue;}
    if(c=='/'&&i+1<in.size()&&in[i+1]=='/'){i+=2;while(i<in.size()&&in[i]!='\n')++i;continue;}
    if(c=='/'&&i+1<in.size()&&in[i+1]=='*'){i+=2;while(i+1<in.size()&&!(in[i]=='*'&&in[i+1]=='/'))++i;i=std::min(in.size(),i+2);continue;}
    if(std::isalpha(c)||c=='_'){size_t b=i++;while(i<in.size()&&(std::isalnum((unsigned char)in[i])||in[i]=='_'))++i;o.push_back({TK::Id,in.substr(b,i-b)});continue;}
    if(std::isdigit(c)||(c=='.'&&i+1<in.size()&&std::isdigit((unsigned char)in[i+1]))){
      size_t b=i++;
      if(c=='0'&&i<in.size()&&(in[i]=='x'||in[i]=='X')){++i;while(i<in.size()&&std::isxdigit((unsigned char)in[i]))++i;}
      else while(i<in.size()&&(std::isdigit((unsigned char)in[i])||in[i]=='.'||in[i]=='e'||in[i]=='E'||in[i]=='+'||in[i]=='-')){if((in[i]=='+'||in[i]=='-')&&i>b&&in[i-1]!='e'&&in[i-1]!='E')break;++i;}
      o.push_back({TK::Num,in.substr(b,i-b)});continue;
    }
    if(c=='"'||c=='\''){
      char quote=(char)c;++i;std::string v;
      while(i<in.size()&&in[i]!=quote){if(in[i]=='\\'&&i+1<in.size()){char n=in[++i];v+=n=='n'?'\n':n=='t'?'\t':n;}else v+=in[i];++i;}if(i<in.size())++i;o.push_back({TK::Str,v});continue;
    }
    std::string three=i+2<in.size()?in.substr(i,3):"";
    std::string two=i+1<in.size()?in.substr(i,2):"";
    if(three=="<<="||three==">>="){o.push_back({TK::Sym,three});i+=3;}
    else if(two=="=="||two=="!="||two=="<="||two==">="||two=="&&"||two=="||"||two=="+="||two=="-="||two=="*="||two=="/="||two=="%="||two=="&="||two=="|="||two=="^="||two=="++"||two=="--"||two=="<<"||two==">>"){o.push_back({TK::Sym,two});i+=2;}
    else{o.push_back({TK::Sym,std::string(1,(char)c)});++i;}
  }
  o.push_back({TK::End,{}});return o;
}
static std::filesystem::path scriptCasePath(const std::filesystem::path& p);
static bool safeScriptPath(const std::filesystem::path& root,const std::filesystem::path& current,const std::string& raw,std::filesystem::path& out){
  std::string q=raw;for(auto&c:q)if(c=='\\')c='/';while(lower(q).rfind("data/",0)==0)q.erase(0,5);auto rel=PathEncoding::path(q).lexically_normal();if(rel.empty()||rel.is_absolute()||rel.has_root_name()||rel.has_root_directory())return false;for(const auto&part:rel)if(part=="..")return false;
  auto candidate=scriptCasePath((root/rel).lexically_normal());if(!std::filesystem::exists(candidate)){auto local=scriptCasePath((current.parent_path()/rel).lexically_normal());std::error_code ec;auto rr=std::filesystem::weakly_canonical(root,ec);auto cc=std::filesystem::weakly_canonical(local,ec);if(!ec){auto r=cc.lexically_relative(rr);bool ok=!r.empty();for(const auto&part:r)if(part=="..")ok=false;if(ok)candidate=cc;}}out=candidate;return true;
}
static std::filesystem::path scriptCasePath(const std::filesystem::path& p){
  if(std::filesystem::exists(p))return p;
  std::filesystem::path out=p.root_path();
  for(const auto& part:p.relative_path()){
    auto next=out/part;if(!std::filesystem::exists(next)&&std::filesystem::is_directory(out)){
      for(const auto& e:std::filesystem::directory_iterator(out))if(lower(PathEncoding::utf8(e.path().filename()))==lower(PathEncoding::utf8(part))){next=e.path();break;}
    }out=next;
  }return out;
}
static std::filesystem::path scriptUniqueBasename(const std::filesystem::path& root,const std::filesystem::path& wanted){
  if(wanted.empty()||!wanted.has_filename())return {};
  std::filesystem::path unique;std::error_code ec;
  for(std::filesystem::recursive_directory_iterator it(root,std::filesystem::directory_options::skip_permission_denied,ec),end;it!=end;it.increment(ec)){
    if(ec){ec.clear();continue;}if(!it->is_regular_file(ec))continue;
    if(lower(PathEncoding::utf8(it->path().filename()))!=lower(PathEncoding::utf8(wanted.filename())))continue;
    if(!unique.empty())return {};unique=it->path();
  }
  return unique;
}
struct FunctionMacro { std::vector<std::string> params; std::string body; };
static std::string trimMacro(std::string x){while(!x.empty()&&std::isspace((unsigned char)x.front()))x.erase(x.begin());while(!x.empty()&&std::isspace((unsigned char)x.back()))x.pop_back();return x;}
static std::string replaceObjectMacros(const std::string& line,const std::unordered_map<std::string,std::string>& macros){
  std::string out;out.reserve(line.size());bool quoted=false;char quote=0;for(std::size_t i=0;i<line.size();){char c=line[i];if(quoted){out+=c;if(c=='\\'&&i+1<line.size()){out+=line[++i];++i;continue;}if(c==quote)quoted=false;++i;continue;}if(c=='"'||c=='\''){quoted=true;quote=c;out+=c;++i;continue;}if(std::isalpha((unsigned char)c)||c=='_'){std::size_t b=i++;while(i<line.size()&&(std::isalnum((unsigned char)line[i])||line[i]=='_'))++i;auto name=line.substr(b,i-b);auto it=macros.find(name);out+=it==macros.end()?name:it->second;continue;}out+=c;++i;}return out;
}
static std::string substituteMacroParams(const std::string& body,const FunctionMacro& fn,const std::vector<std::string>& args){
  std::unordered_map<std::string,std::string> repl;for(std::size_t i=0;i<fn.params.size()&&i<args.size();++i)repl[fn.params[i]]=args[i];return replaceObjectMacros(body,repl);
}
static std::string expandFunctionMacros(const std::string& line,const std::unordered_map<std::string,FunctionMacro>& funcs){
  std::string out;out.reserve(line.size());bool quoted=false;char quote=0;
  for(std::size_t i=0;i<line.size();){char c=line[i];if(quoted){out+=c;if(c=='\\'&&i+1<line.size()){out+=line[++i];++i;continue;}if(c==quote)quoted=false;++i;continue;}if(c=='"'||c=='\''){quoted=true;quote=c;out+=c;++i;continue;}
    if(std::isalpha((unsigned char)c)||c=='_'){std::size_t b=i++;while(i<line.size()&&(std::isalnum((unsigned char)line[i])||line[i]=='_'))++i;auto name=line.substr(b,i-b);auto fit=funcs.find(name);if(fit==funcs.end()){out+=name;continue;}std::size_t q=i;while(q<line.size()&&std::isspace((unsigned char)line[q]))++q;if(q>=line.size()||line[q]!='('){out+=name;continue;}
      std::vector<std::string> args;std::string cur;int depth=1;bool aq=false;char aqc=0;std::size_t j=q+1;for(;j<line.size()&&depth>0;++j){char ch=line[j];if(aq){cur+=ch;if(ch=='\\'&&j+1<line.size()){cur+=line[++j];continue;}if(ch==aqc)aq=false;continue;}if(ch=='"'||ch=='\''){aq=true;aqc=ch;cur+=ch;continue;}if(ch=='('){++depth;cur+=ch;continue;}if(ch==')'){--depth;if(depth==0){args.push_back(trimMacro(cur));break;}cur+=ch;continue;}if(ch==','&&depth==1){args.push_back(trimMacro(cur));cur.clear();continue;}cur+=ch;}
      if(depth!=0){out+=name;i=b+name.size();continue;}if(args.size()==1&&args[0].empty()&&fit->second.params.empty())args.clear();if(args.size()!=fit->second.params.size()){out+=line.substr(b,j-b);i=j;continue;}out+=substituteMacroParams(fit->second.body,fit->second,args);i=j+1;continue;}
    out+=c;++i;
  }return out;
}
static std::string expandMacros(std::string line,const std::unordered_map<std::string,std::string>& macros,const std::unordered_map<std::string,FunctionMacro>& funcs){
  for(int pass=0;pass<16;++pass){auto before=line;line=expandFunctionMacros(line,funcs);line=replaceObjectMacros(line,macros);if(line==before)break;}return line;
}
static std::string preprocessScript(const std::filesystem::path& root,const std::filesystem::path& file,const std::string& source,std::unordered_map<std::string,std::string>& macros,std::unordered_map<std::string,FunctionMacro>& funcMacros,std::unordered_set<std::string>& imported,std::vector<std::string>& unsupported,int depth){
  if(depth>24){unsupported.push_back("preprocessor-depth");return source;}std::istringstream in(source);std::ostringstream out;std::string line;std::vector<bool> active{true};
  while(std::getline(in,line)){auto t=trimMacro(line);if(!t.empty()&&t[0]=='#'){std::istringstream ds(t.substr(1));std::string cmd;ds>>cmd;cmd=lower(cmd);
      if(cmd=="define"){if(active.back()){std::string rest;std::getline(ds,rest);rest=trimMacro(rest);std::size_t n=0;while(n<rest.size()&&(std::isalnum((unsigned char)rest[n])||rest[n]=='_'))++n;auto name=rest.substr(0,n);std::size_t q=n;if(!name.empty()&&q<rest.size()&&rest[q]=='('){int depthp=1;std::size_t e=q+1;for(;e<rest.size()&&depthp>0;++e){if(rest[e]=='(')++depthp;else if(rest[e]==')')--depthp;}if(depthp==0){auto inside=rest.substr(q+1,(e-1)-(q+1));FunctionMacro fm;std::istringstream ps(inside);std::string param;while(std::getline(ps,param,',')){param=trimMacro(param);if(!param.empty())fm.params.push_back(param);}fm.body=trimMacro(rest.substr(e));funcMacros[name]=std::move(fm);}else unsupported.push_back("preprocessor-function-macro-malformed:"+name);}else if(!name.empty()){auto value=trimMacro(rest.substr(n));macros[name]=value.empty()?"1":value;}}continue;}
      if(cmd=="ifdef"||cmd=="ifndef"){std::string name;ds>>name;bool yes=macros.count(name)!=0||funcMacros.count(name)!=0;if(cmd=="ifndef")yes=!yes;active.push_back(active.back()&&yes);continue;}
      if(cmd=="else"){if(active.size()>1){bool parent=active[active.size()-2];active.back()=parent&&!active.back();}continue;}
      if(cmd=="endif"){if(active.size()>1)active.pop_back();continue;}
      if(cmd=="include"||cmd=="import"){if(!active.back())continue;std::string raw;std::getline(ds,raw);raw=trimMacro(raw);if(raw.size()>=2&&((raw.front()=='"'&&raw.back()=='"')||(raw.front()=='<'&&raw.back()=='>')))raw=raw.substr(1,raw.size()-2);std::filesystem::path inc;if(!safeScriptPath(root,file,raw,inc)){unsupported.push_back("unsafe-"+cmd+":"+raw);continue;}inc=scriptCasePath(inc);if(!std::filesystem::exists(inc)){auto unique=scriptUniqueBasename(root,PathEncoding::path(raw));if(!unique.empty())inc=unique;}auto key=PathEncoding::utf8(inc);if(cmd=="import"&&!imported.insert(key).second)continue;std::ifstream f(inc);if(!f){auto base=lower(PathEncoding::utf8(PathEncoding::path(raw).filename()));if(base=="spawn.h")continue;/* Missing legacy includes are deferred. If code actually calls a symbol that was supplied only by this include, Exec/ScriptHost logs that unresolved function at the call site instead of rejecting the whole compilation unit up front. */continue;}std::ostringstream ss;ss<<f.rdbuf();out<<preprocessScript(root,inc,ss.str(),macros,funcMacros,imported,unsupported,depth+1)<<"\n";continue;}
      if(active.back())unsupported.push_back("preprocessor:"+cmd);continue;}
    if(active.back())out<<expandMacros(line,macros,funcMacros)<<"\n";
  }return out.str();
}
struct ReturnSignal{ScriptValue v;};
struct BreakSignal{};struct ContinueSignal{};
struct FunctionInfo{bool found=false;size_t body=0;std::vector<std::string> params;};
class Exec{
 public:
  Exec(std::vector<Tok>t,ScriptVM*vm,ScriptHost*h,ScriptContext&c,std::unordered_map<std::string,ScriptValue>&g,std::vector<std::string>&u):t_(std::move(t)),vm_(vm),host_(h),ctx_(c),globals_(g),unsupported_(u){}
  bool runFunction(const std::string&name){ScriptValue ignored;return callUserFunction(name,{},ignored);}
 private:
  std::vector<Tok>t_;size_t pos_=0;ScriptVM*vm_;ScriptHost*host_;ScriptContext&ctx_;std::unordered_map<std::string,ScriptValue>&globals_;std::vector<std::string>&unsupported_;int callDepth_=0;std::vector<std::unordered_map<std::string,ScriptValue>> scopes_;
  bool is(const std::string&s)const{return t_[pos_].s==s;}Tok take(){return t_[pos_++];}bool eat(const std::string&s){if(is(s)){++pos_;return true;}return false;}void need(const std::string&s){if(!eat(s))throw std::runtime_error("expected "+s+" near '"+t_[pos_].s+"'");}
  FunctionInfo findFunction(const std::string&wanted){
    for(size_t i=0;i+3<t_.size();++i){if(t_[i].s=="{"){int d=1;while(d&&++i<t_.size()){if(t_[i].s=="{")++d;else if(t_[i].s=="}")--d;}continue;}if(t_[i].k!=TK::Id||!isTypeName(t_[i].s))continue;size_t n=i;if(isTypeName(t_[i].s))n=i+1;if(n>=t_.size()||t_[n].k!=TK::Id||lower(t_[n].s)!=lower(wanted)||n+1>=t_.size()||t_[n+1].s!="(")continue;
      FunctionInfo f;f.found=true;size_t j=n+2;std::vector<Tok> segment;int d=1;
      for(;j<t_.size()&&d;){if(t_[j].s=="("){++d;segment.push_back(t_[j++]);continue;}if(t_[j].s==")"){--d;if(d==0){if(!segment.empty()){for(auto it=segment.rbegin();it!=segment.rend();++it)if(it->k==TK::Id&&!isTypeName(it->s)){f.params.push_back(it->s);break;}}++j;break;}segment.push_back(t_[j++]);continue;}if(d==1&&t_[j].s==","){if(!segment.empty()){for(auto it=segment.rbegin();it!=segment.rend();++it)if(it->k==TK::Id&&!isTypeName(it->s)){f.params.push_back(it->s);break;}}segment.clear();++j;continue;}segment.push_back(t_[j++]);}
      if(j<t_.size()&&t_[j].s=="{"){f.body=j;return f;}
    }return {};
  }
  bool callUserFunction(const std::string&name,const std::vector<ScriptValue>&args,ScriptValue&out){
    auto f=findFunction(name);if(!f.found)return false;if(++callDepth_>64){--callDepth_;throw std::runtime_error("script recursion limit exceeded");}
    size_t savePos=pos_;scopes_.emplace_back();
    for(size_t i=0;i<f.params.size();++i)scopes_.back()[f.params[i]]=i<args.size()?args[i]:ScriptValue{};
    pos_=f.body;try{block(true);out=ScriptValue{};}catch(const ReturnSignal&r){out=r.v;}catch(...){pos_=savePos;scopes_.pop_back();--callDepth_;throw;}
    pos_=savePos;scopes_.pop_back();--callDepth_;return true;
  }
  void store(const std::string&n,ScriptValue v,bool declaration=false){
    if(!scopes_.empty()&&(declaration||scopes_.back().contains(n)))scopes_.back()[n]=std::move(v);else ctx_.local[n]=std::move(v);
  }
  void block(bool exec){need("{");while(!is("}")&&t_[pos_].k!=TK::End)statement(exec);need("}");}
  void simpleClause(bool exec,const std::string&terminator){
    if(eat(terminator))return;bool decl=false;if(t_[pos_].k==TK::Id&&isTypeName(t_[pos_].s)){decl=true;take();}
    if((decl||t_[pos_].k==TK::Id)&&t_[pos_].k==TK::Id){std::string n=t_[pos_].s;std::string next=pos_+1<t_.size()?t_[pos_+1].s:"";
      if(next=="++"||next=="--"){take();take();if(exec)store(n,num(get(n))+(next=="++"?1.0:-1.0));need(terminator);return;}
      if(next=="="||next=="+="||next=="-="||next=="*="||next=="/="||next=="%="||next=="&="||next=="|="||next=="^="||next=="<<="||next==">>="){take();std::string op=take().s;auto v=expr(exec);if(exec){auto cur=get(n);if(op=="+=")v=num(cur)+num(v);else if(op=="-=")v=num(cur)-num(v);else if(op=="*=")v=num(cur)*num(v);else if(op=="/=")v=num(v)==0?0.0:num(cur)/num(v);else if(op=="%=")v=(double)((long long)num(cur)%std::max(1LL,(long long)num(v)));else if(op=="&=")v=(double)((long long)num(cur)&(long long)num(v));else if(op=="|=")v=(double)((long long)num(cur)|(long long)num(v));else if(op=="^=")v=(double)((long long)num(cur)^(long long)num(v));else if(op=="<<=")v=(double)((long long)num(cur)<<(int)num(v));else if(op==">>=")v=(double)((long long)num(cur)>>(int)num(v));store(n,v,decl);}need(terminator);return;}
      if(decl){take();if(exec)store(n,0.0,true);need(terminator);return;}
    }
    (void)expr(exec);need(terminator);
  }
  void switchStatement(bool exec){
    take();need("(");auto key=expr(exec);need(")");need("{");const size_t bodyStart=pos_;size_t end=bodyStart;int depth=1;size_t target=(size_t)-1,def=(size_t)-1;
    for(size_t i=bodyStart;i<t_.size()&&depth>0;){if(t_[i].s=="{"){++depth;++i;continue;}if(t_[i].s=="}"){--depth;if(depth==0){end=i;break;}++i;continue;}if(depth==1&&t_[i].k==TK::Id&&lower(t_[i].s)=="case"){size_t save=pos_;pos_=i+1;ScriptValue cv{};try{cv=expr(exec);need(":");}catch(...){pos_=save;throw;}size_t after=pos_;pos_=save;if(exec&&target==(size_t)-1&&eq(key,cv))target=after;i=after;continue;}if(depth==1&&t_[i].k==TK::Id&&lower(t_[i].s)=="default"){size_t j=i+1;while(j<t_.size()&&t_[j].s!=":"&&t_[j].s!="}")++j;if(j<t_.size()&&t_[j].s==":")def=j+1;i=j+1;continue;}++i;}
    if(!exec){pos_=std::min(end+1,t_.size()-1);return;}if(target==(size_t)-1)target=def;if(target==(size_t)-1){pos_=std::min(end+1,t_.size()-1);return;}pos_=target;try{while(pos_<end){if(t_[pos_].k==TK::Id&&lower(t_[pos_].s)=="case"){take();(void)expr(false);need(":");continue;}if(t_[pos_].k==TK::Id&&lower(t_[pos_].s)=="default"){take();need(":");continue;}statement(true);}}catch(const BreakSignal&){}pos_=std::min(end+1,t_.size()-1);
  }
  void statement(bool exec){
    if(is("{")){block(exec);return;}
    if(t_[pos_].k==TK::Id&&lower(t_[pos_].s)=="switch"){switchStatement(exec);return;}
    if(t_[pos_].k==TK::Id&&lower(t_[pos_].s)=="do"){take();size_t bodyStart=pos_;statement(false);size_t afterBody=pos_;if(!(t_[pos_].k==TK::Id&&lower(t_[pos_].s)=="while"))throw std::runtime_error("expected while after do");take();need("(");size_t condStart=pos_;(void)expr(false);need(")");eat(";");size_t end=pos_;if(!exec){pos_=end;return;}for(int guard=0;guard<100000;++guard){pos_=bodyStart;bool br=false;try{statement(true);}catch(const ContinueSignal&){}catch(const BreakSignal&){br=true;}if(br)break;pos_=afterBody;take();need("(");pos_=condStart;auto c=expr(true);need(")");eat(";");if(!truth(c))break;}pos_=end;return;}
    if(t_[pos_].k==TK::Id&&lower(t_[pos_].s)=="if"){take();need("(");auto c=expr(exec);need(")");bool on=exec&&truth(c);statement(on);if(t_[pos_].k==TK::Id&&lower(t_[pos_].s)=="else"){take();statement(exec&&!truth(c));}return;}
    if(t_[pos_].k==TK::Id&&lower(t_[pos_].s)=="while"){
      take();need("(");size_t condStart=pos_;auto c=expr(exec);need(")");size_t bodyStart=pos_;pos_=bodyStart;statement(false);size_t bodyEnd=pos_;if(!exec||!truth(c)){pos_=bodyEnd;return;}
      for(int guard=0;guard<100000;++guard){pos_=bodyStart;bool br=false;try{statement(true);}catch(const ContinueSignal&){}catch(const BreakSignal&){br=true;}if(br)break;pos_=condStart;c=expr(true);need(")");if(!truth(c))break;}pos_=bodyEnd;return;
    }
    if(t_[pos_].k==TK::Id&&lower(t_[pos_].s)=="for"){
      take();need("(");simpleClause(exec,";");size_t condStart=pos_;bool hasCond=!is(";");auto initialCond=hasCond?expr(exec):ScriptValue(true);need(";");size_t incrStart=pos_;simpleClause(false,")");size_t bodyStart=pos_;pos_=bodyStart;statement(false);size_t bodyEnd=pos_;if(!exec||!truth(initialCond)){pos_=bodyEnd;return;}
      for(int guard=0;guard<100000;++guard){pos_=condStart;ScriptValue c=hasCond?expr(true):ScriptValue(true);need(";");if(!truth(c))break;pos_=bodyStart;bool br=false;try{statement(true);}catch(const ContinueSignal&){}catch(const BreakSignal&){br=true;}if(br)break;pos_=incrStart;simpleClause(true,")");}pos_=bodyEnd;return;
    }
    if(t_[pos_].k==TK::Id&&lower(t_[pos_].s)=="break"){take();eat(";");if(exec)throw BreakSignal{};return;}
    if(t_[pos_].k==TK::Id&&lower(t_[pos_].s)=="continue"){take();eat(";");if(exec)throw ContinueSignal{};return;}
    if(t_[pos_].k==TK::Id&&lower(t_[pos_].s)=="return"){take();ScriptValue v{};if(!is(";"))v=expr(exec);eat(";");if(exec)throw ReturnSignal{v};return;}
    bool decl=false;if(t_[pos_].k==TK::Id&&isTypeName(t_[pos_].s)){decl=true;take();}
    if((decl||t_[pos_].k==TK::Id)&&t_[pos_].k==TK::Id&&pos_+1<t_.size()&&(t_[pos_+1].s=="="||t_[pos_+1].s=="+="||t_[pos_+1].s=="-="||t_[pos_+1].s=="*="||t_[pos_+1].s=="/="||t_[pos_+1].s=="%="||t_[pos_+1].s=="&="||t_[pos_+1].s=="|="||t_[pos_+1].s=="^="||t_[pos_+1].s=="<<="||t_[pos_+1].s==">>=")){std::string n=take().s;std::string op=take().s;auto v=expr(exec);eat(";");if(exec){auto cur=get(n);if(op=="+=")v=num(cur)+num(v);else if(op=="-=")v=num(cur)-num(v);else if(op=="*=")v=num(cur)*num(v);else if(op=="/=")v=num(v)==0?0.0:num(cur)/num(v);else if(op=="%=")v=(double)((long long)num(cur)%std::max(1LL,(long long)num(v)));else if(op=="&=")v=(double)((long long)num(cur)&(long long)num(v));else if(op=="|=")v=(double)((long long)num(cur)|(long long)num(v));else if(op=="^=")v=(double)((long long)num(cur)^(long long)num(v));else if(op=="<<=")v=(double)((long long)num(cur)<<(int)num(v));else if(op==">>=")v=(double)((long long)num(cur)>>(int)num(v));store(n,v,decl);}return;}
    if((decl||t_[pos_].k==TK::Id)&&t_[pos_].k==TK::Id&&pos_+1<t_.size()&&(t_[pos_+1].s=="++"||t_[pos_+1].s=="--")){std::string n=take().s;std::string op=take().s;eat(";");if(exec)store(n,num(get(n))+(op=="++"?1.0:-1.0));return;}
    if(decl&&t_[pos_].k==TK::Id){std::string n=take().s;ScriptValue v=0.0;if(eat("="))v=expr(exec);eat(";");if(exec)store(n,v,decl);return;}
    (void)expr(exec);eat(";");
  }
  ScriptValue get(const std::string&n){if(!scopes_.empty()){auto v=scopes_.back().find(n);if(v!=scopes_.back().end())return v->second;}auto it=ctx_.local.find(n);if(it!=ctx_.local.end())return it->second;auto g=globals_.find(n);if(g!=globals_.end())return g->second;if(lower(n)=="null")return std::uintptr_t(0);return 0.0;}
  ScriptValue expr(bool exec,int minp=0){auto l=unary(exec);for(;;){std::string op=t_[pos_].s;int p=prec(op);if(p<minp)break;take();bool rhs=exec&&!(op=="&&"&&!truth(l))&&!(op=="||"&&truth(l));auto r=expr(rhs,p+1);if(!exec){l=0.0;continue;}if(op=="+"){if(l.index()==2||r.index()==2)l=str(l)+str(r);else l=num(l)+num(r);}else if(op=="-")l=num(l)-num(r);else if(op=="*")l=num(l)*num(r);else if(op=="/")l=num(r)==0?0.0:num(l)/num(r);else if(op=="%")l=(double)((long long)num(l)%std::max(1LL,(long long)num(r)));else if(op=="<<")l=(double)((long long)num(l)<<(int)num(r));else if(op==">>")l=(double)((long long)num(l)>>(int)num(r));else if(op=="&")l=(double)((long long)num(l)&(long long)num(r));else if(op=="^")l=(double)((long long)num(l)^(long long)num(r));else if(op=="|")l=(double)((long long)num(l)|(long long)num(r));else if(op=="==")l=eq(l,r);else if(op=="!=")l=!eq(l,r);else if(op=="<")l=num(l)<num(r);else if(op==">")l=num(l)>num(r);else if(op=="<=")l=num(l)<=num(r);else if(op==">=")l=num(l)>=num(r);else if(op=="&&")l=truth(l)&&truth(r);else if(op=="||")l=truth(l)||truth(r);}if(minp==0&&eat("?")){bool choose=exec&&truth(l);auto yes=expr(choose);need(":");auto no=expr(exec&&!choose);if(exec)l=choose?yes:no;else l=0.0;}return l;}
  int prec(const std::string&o){if(o=="||")return 1;if(o=="&&")return 2;if(o=="|")return 3;if(o=="^")return 4;if(o=="&")return 5;if(o=="=="||o=="!=")return 6;if(o=="<"||o==">"||o=="<="||o==">=")return 7;if(o=="<<"||o==">>")return 8;if(o=="+"||o=="-")return 9;if(o=="*"||o=="/"||o=="%")return 10;return -1;}
  ScriptValue unary(bool exec){if(is("!")||is("~")||is("-")||is("+")){auto op=take().s;auto v=unary(exec);if(!exec)return 0.0;if(op=="!")return !truth(v);if(op=="~")return (double)~(long long)num(v);if(op=="-")return -num(v);return v;}return primary(exec);}
  ScriptValue primary(bool exec){
    if(eat("(")){auto v=expr(exec);need(")");return v;}
    if(t_[pos_].k==TK::Num){auto raw=take().s;double v=0;try{v=(raw.size()>2&&raw[0]=='0'&&(raw[1]=='x'||raw[1]=='X'))?(double)std::stoll(raw,nullptr,16):std::stod(raw);}catch(...){v=0;}return exec?ScriptValue(v):ScriptValue(0.0);}
    if(t_[pos_].k==TK::Str){auto v=take().s;return exec?ScriptValue(v):ScriptValue(std::string{});}
    if(t_[pos_].k==TK::Id){
      std::string n=take().s;
      if(eat("(")){
        std::vector<ScriptValue>a;if(!is(")")){do{a.push_back(expr(exec));}while(eat(","));}need(")");if(!exec)return 0.0;auto ln=lower(n);
        if(ln=="getglobalvar"&&a.size()){auto it=globals_.find(str(a[0]));return it==globals_.end()?ScriptValue{}:it->second;}
        if(ln=="setglobalvar"&&a.size()>1){globals_[str(a[0])]=a[1];return a[1];}
        if(ln=="clearglobalvar"){globals_.clear();return 1.0;}
        if(ln=="getlocalvar"&&a.size()){auto it=ctx_.local.find(str(a[0]));return it==ctx_.local.end()?ScriptValue{}:it->second;}
        if(ln=="setlocalvar"&&a.size()>1){ctx_.local[str(a[0])]=a[1];return a[1];}
        if(ln=="clearlocalvar"){ctx_.local.clear();return 1.0;}
        if(ln=="maxglobalvarindex")return globals_.empty()?-1.0:(double)globals_.size()-1.0;
        if(ln=="getindexedvar"&&a.size()){auto k="#"+std::to_string((long long)num(a[0]));auto it=globals_.find(k);return it==globals_.end()?ScriptValue{}:it->second;}
        if(ln=="setindexedvar"&&a.size()>1){auto k="#"+std::to_string((long long)num(a[0]));globals_[k]=a[1];return a[1];}
        if(ln=="clearindexedvar"){for(auto it=globals_.begin();it!=globals_.end();){if(!it->first.empty()&&it->first[0]=='#')it=globals_.erase(it);else ++it;}return 1.0;}
        if(ln=="isempty")return a.empty()||std::holds_alternative<std::monostate>(a[0]);
        if(ln=="rand"){static std::mt19937 r{0x0B0B0B};return (double)static_cast<std::int32_t>(r());}
        if(ln=="null")return std::uintptr_t(0);
        if(ln=="array"){auto ar=std::make_shared<ScriptArray>();if(!a.empty()&&num(a[0])>0)ar->indexed.resize((std::size_t)num(a[0]));return ar;}
        if(ln=="size"&&a.size()){if(auto p=std::get_if<ScriptArrayPtr>(&a[0]);p&&*p)return (double)((*p)->indexed.size()+(*p)->named.size());return 0.0;}
        if((ln=="get"||ln=="set"||ln=="add"||ln=="delete")&&a.size()>=2){auto p=std::get_if<ScriptArrayPtr>(&a[0]);if(!p||!*p)return {};auto ar=*p;bool numeric=a[1].index()!=2;
          if(ln=="get"){if(numeric){long long i=(long long)num(a[1]);return i>=0&&(std::size_t)i<ar->indexed.size()?ar->indexed[(std::size_t)i]:ScriptValue{};}auto it=ar->named.find(str(a[1]));return it==ar->named.end()?ScriptValue{}:it->second;}
          if(ln=="set"&&a.size()>=3){if(numeric){long long i=(long long)num(a[1]);if(i<0)return 0.0;if((std::size_t)i>=ar->indexed.size())ar->indexed.resize((std::size_t)i+1);ar->indexed[(std::size_t)i]=a[2];}else{auto k=str(a[1]);if(!ar->named.count(k))ar->namedOrder.push_back(k);ar->named[k]=a[2];}return a[2];}
          if(ln=="add"&&a.size()>=3){long long i=(long long)num(a[1]);if(i<0||i>(long long)ar->indexed.size())return 0.0;ar->indexed.insert(ar->indexed.begin()+i,a[2]);return 1.0;}
          if(ln=="delete"){if(numeric){long long i=(long long)num(a[1]);if(i<0||(std::size_t)i>=ar->indexed.size())return 0.0;ar->indexed.erase(ar->indexed.begin()+i);return 1.0;}auto k=str(a[1]);auto erased=ar->named.erase(k);ar->namedOrder.erase(std::remove(ar->namedOrder.begin(),ar->namedOrder.end(),k),ar->namedOrder.end());if(ar->cursor>=ar->namedOrder.size()&&ar->cursor)ar->cursor=ar->namedOrder.size()-1;return erased?1.0:0.0;}
        }
        if((ln=="next"||ln=="previous"||ln=="reset"||ln=="value"||ln=="key"||ln=="free")&&a.size()){auto p=std::get_if<ScriptArrayPtr>(&a[0]);if((!p||!*p)&&ln=="free"){}else if(!p||!*p)return {};else {auto ar=*p;if(ln=="next"){if(ar->cursor+1<ar->namedOrder.size())++ar->cursor;return 1.0;}if(ln=="previous"){if(ar->cursor>0)--ar->cursor;return 1.0;}if(ln=="reset"){ar->cursor=0;return 1.0;}if(ln=="key"){return ar->cursor<ar->namedOrder.size()?ScriptValue(ar->namedOrder[ar->cursor]):ScriptValue{};}if(ln=="value"){if(ar->cursor<ar->namedOrder.size()){auto it=ar->named.find(ar->namedOrder[ar->cursor]);if(it!=ar->named.end())return it->second;}return ScriptValue{};}if(ln=="free"){p->reset();return 1.0;}}}
        ScriptValue userRet{};if(callUserFunction(n,a,userRet))return userRet;
        if(host_)return host_->callScriptFunction(n,a,ctx_,unsupported_);if(std::find(unsupported_.begin(),unsupported_.end(),n)==unsupported_.end())unsupported_.push_back(n);return {};
      }
      auto q=lower(n);if(q=="true")return true;if(q=="false")return false;return exec?get(n):ScriptValue(0.0);
    }
    throw std::runtime_error("unexpected token "+t_[pos_].s);
  }
};
}
ScriptRunResult ScriptVM::runFile(const std::string& raw,ScriptContext& context,const std::string& function){
  ScriptRunResult r;if(raw.empty())return r;
  try{
    std::string key=raw;for(auto&c:key)if(c=='\\')c='/';while(lower(key).rfind("data/",0)==0)key.erase(0,5);auto rel=PathEncoding::path(key).lexically_normal();for(const auto&part:rel)if(part=="..")return {false,"unsafe script path",{}};if(rel.is_absolute()||rel.has_root_name()||rel.has_root_directory())return {false,"unsafe script path",{}};auto path=scriptCasePath(root_/rel);if(!std::filesystem::exists(path)){auto unique=scriptUniqueBasename(root_,rel);if(!unique.empty())path=unique;}std::string source;
    auto it=sourceCache_.find(PathEncoding::utf8(path));if(it==sourceCache_.end()){std::ifstream in(path);if(!in){r.ok=false;r.error="script not found: "+PathEncoding::utf8(path);return r;}std::ostringstream ss;ss<<in.rdbuf();source=ss.str();sourceCache_[PathEncoding::utf8(path)]=source;}else source=it->second;
    std::unordered_map<std::string,std::string> macros;std::unordered_map<std::string,FunctionMacro> funcMacros;std::unordered_set<std::string> imported;imported.insert(PathEncoding::utf8(path));source=preprocessScript(root_,path,source,macros,funcMacros,imported,r.unsupported,0);auto tokens=lex(source);Exec e(std::move(tokens),this,host_,context,globals_,r.unsupported);bool ran=e.runFunction(function);if(!ran&&function!="main")ran=e.runFunction("main");if(!ran){r.ok=false;r.error="requested function/main() not found";}
  }catch(const std::exception&e){r.ok=false;r.error=e.what();}
  return r;
}
ScriptRunResult ScriptVM::runAnimationCommand(const std::string& rawHelper,const std::string& command,ScriptContext& context){
  ScriptRunResult r;if(command.empty()&&rawHelper.empty())return r;
  try{
    std::filesystem::path path=root_/"__generated_animation_command.c";std::string source;
    if(!rawHelper.empty()){
      std::string key=rawHelper;for(auto&c:key)if(c=='\\')c='/';while(lower(key).rfind("data/",0)==0)key.erase(0,5);auto rel=PathEncoding::path(key).lexically_normal();for(const auto&part:rel)if(part=="..")return {false,"unsafe animation script path",{}};if(rel.is_absolute()||rel.has_root_name()||rel.has_root_directory())return {false,"unsafe animation script path",{}};path=scriptCasePath(root_/rel);if(!std::filesystem::exists(path)){auto unique=scriptUniqueBasename(root_,rel);if(!unique.empty())path=unique;}
      auto it=sourceCache_.find(PathEncoding::utf8(path));if(it==sourceCache_.end()){std::ifstream in(path);if(!in){r.ok=false;r.error="animation helper not found: "+PathEncoding::utf8(path);}else{std::ostringstream ss;ss<<in.rdbuf();source=ss.str();sourceCache_[PathEncoding::utf8(path)]=source;}}else source=it->second;
    }
    source+="\nvoid __obnb_animation_frame(){\n"+command+"\n}\n";
    std::unordered_map<std::string,std::string> macros;std::unordered_map<std::string,FunctionMacro> funcMacros;std::unordered_set<std::string> imported;imported.insert(PathEncoding::utf8(path));source=preprocessScript(root_,path,source,macros,funcMacros,imported,r.unsupported,0);auto tokens=lex(source);Exec e(std::move(tokens),this,host_,context,globals_,r.unsupported);if(!rawHelper.empty()&&r.ok)e.runFunction("main");if(!e.runFunction("__obnb_animation_frame")){r.ok=false;r.error="generated animation function not found";}
  }catch(const std::exception&e){r.ok=false;r.error=e.what();}
  return r;
}
)CPP";

    std::ofstream engine(include / "Engine.hpp");
    engine << R"CPP(#pragma once
#include "Renderer.hpp"
#include "AnimationPlayer.hpp"
#include "AudioSystem.hpp"
#include "ScriptVM.hpp"
#include "../generated/GeneratedStages.hpp"
#include <filesystem>
#include <deque>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>
struct PendingEnergyCost { const generated::Animation* animation=nullptr; int cost=0,mode=0; bool hit=false; };
struct RuntimeEntity {
  PendingEnergyCost energyPending;
  bool animationEffect = false;
  int effectSpawnType = 8;
  const generated::Spawn* spawn = nullptr;
  const generated::Character* model = nullptr;
  AnimationPlayer animation;
  float worldX = 0;
  float z = 200;
  int health = 100;
  int maxHealth = 100;
  int mp = 0;
  int maxMp = 0;
  float knockdownMeter = 0.0f;
  int hitStun = 0;
  int attackTicks = 0;
  int attackCooldown = 0;
  int attackHits = 0;
  bool attackHasHit = false;
  bool projectileFired = false;
  int facing = -1;
  int fallTicks = 0;
  int landingDamage = 0;
  int landingMode = 0;
  int landingType = -1;
  int recoveryTicks = 0;
  int invincibleTicks = 0;
  int juggleRemaining = 4;
  float altitude = 0.0f;
  float verticalVelocity = 0.0f;
  int bouncesRemaining = 0;
  bool grabbed = false;
  bool alive = true;
  bool visible = true;
  bool subjectToScreen = false;
  int deathTicks = 0;
  bool deathFollowDeath = false;
  int freezeTicks = 0;
  int preFreezePaletteMap = -1;
  int lifeTicks = -1;
  int paletteMap = 0;
  long long score = 0;
  int reactionType = 0;
  int guardPoints = 0;
  int blockState = 0;
  bool blocking = false;
  float scriptVelocityX = 0.0f;
  float scriptVelocityZ = 0.0f;
  const generated::Character* equippedWeapon = nullptr;
  int weaponUses = 0;
  const generated::Character* weaponItemModel = nullptr;
  int weaponDropsRemaining = -1;
  std::uintptr_t parentHandle = 0;
  bool summonedChild = false;
  std::unordered_map<std::string,ScriptValue> scriptVars;
  unsigned lastPlayerAttackId = 0;
  std::unordered_set<std::uintptr_t> landingHitTargets;
  std::size_t lastFrame = (std::size_t)-1;
  SpriteImage sprite;
  ScriptContext scriptCtx;
};
struct RuntimeCoopPlayer {
  PendingEnergyCost energyPending;
  const generated::Character* model = nullptr;
  AnimationPlayer animation;
  float worldX = 80.0f, z = 200.0f, altitude = 0.0f, verticalVelocity = 0.0f;
  int health = 100, maxHealth = 100, mp = 0, maxMp = 0, hitStun = 0, attackTicks = 0, attackCooldown = 0, facing = 1;
  int playerSlot = 1; // zero-based OpenBOR player slot (P2 => 1), preserved even with sparse joins
  int livesRemaining = 0, creditsRemaining = 0;
  int paletteMap = 0;
  int freezeTicks = 0;
  int preFreezePaletteMap = -1;
  int deathTicks = 0;
  bool deathFollowDeath = false;
  long long score = 0;
  int reactionType = 0;
  int landingDamage = 0, landingMode = 0, landingType = -1;
  int guardPoints = 0;
  int blockState = 0;
  bool blocking = false;
  float knockdownMeter = 0.0f;
  float scriptVelocityX = 0.0f, scriptVelocityZ = 0.0f;
  bool alive = true, jumping = false, knockdownAir = false, runningJump = false, attackHasHit = false, projectileFired = false;
  int invincibleTicks = 0;
  int attackHits = 0;
  int comboStep = 0, comboBranch = -1, comboWindow = 0;
  const generated::Character* equippedWeapon = nullptr;
  int weaponUses = 0;
  const generated::Character* weaponItemModel = nullptr;
  int weaponDropsRemaining = -1;
  unsigned attackId = 0;
  int gamepadId = 0;
  std::unordered_set<std::uintptr_t> landingHitTargets;
  std::size_t lastFrame = (std::size_t)-1;
  SpriteImage sprite;
  ScriptContext scriptCtx;
};
struct RuntimeStageLayer {
  SpriteImage image;
  std::string kind;
  float xRatio=0.5f, zRatio=0.5f;
  int xOffset=0, zOffset=0, xSpacing=0, zSpacing=0, xRepeat=0, zRepeat=0, zOrder=0;
  int transparency=0, alpha=0, waterMode=0, amplitude=0, wavelength=0;
  float waveSpeed=0.0f, bgSpeedRatio=0.0f;
};
struct ScriptSpawnEntry {
  std::string model;
  std::string alias;
  std::string item;
  std::string map;
  float x=0.0f,z=200.0f,a=0.0f;
  int health=-1;
  bool boss=false;
};
struct PendingChildSpawn {
  bool animationEffect = false;
  int effectSpawnType = 8;
  const generated::Character* model = nullptr;
  float worldX=0,z=200,altitude=0;
  int facing=1;
  std::uintptr_t parent=0;
  bool summon=false;
};
struct PendingWeaponDrop {
  const generated::Character* itemModel = nullptr;
  float worldX=0,z=200,altitude=0;
  int facing=1;
  int remainingDrops=-1;
};
struct InputHistoryEntry { unsigned held=0,newKeys=0,released=0; };
struct RuntimeProjectile {
  const generated::Character* model = nullptr;
  const generated::Character* ownerModel = nullptr; // preserves player/enemy combat role for type none/projectile weapon models
  AnimationPlayer animation;
  float worldX=0,z=200,altitude=0;
  float vx=0,vy=0,vz=0;
  int facing=1;
  int life=0;
  bool bomb=false;
  bool exploded=false;
  bool attackSpent=false; // attackone: first collision consumes this attack box.
  std::unordered_set<std::uintptr_t> hitTargets;
  bool fromPlayer=true;
  bool alive=true;
  bool subjectToGravity=false;
  int bouncesLeft=0;
  float bounceFactor=0.5f;
  int hitMask=0;
  unsigned hitId=0;
  std::size_t lastFrame=(std::size_t)-1;
  SpriteImage sprite;
};
struct ScriptDrawCommand {
  enum class Kind { Text, Box, Line, Dot, Sprite } kind = Kind::Dot;
  int x=0,y=0,x2=0,y2=0,w=0,h=0,z=0,font=0;
  unsigned int color=0xFFFFFFu;
  std::string text;
  std::uintptr_t sprite=0;
};
struct ScriptFileStream {
  std::vector<std::vector<std::string>> lines;
  std::size_t line=0;
};
class Engine : public ScriptHost {
public: bool initialize(const std::filesystem::path& portRoot); int run(); int runSmokeGame(int frames=600);
  ScriptValue callScriptFunction(const std::string&,const std::vector<ScriptValue>&,ScriptContext&,std::vector<std::string>&) override;
private:
  enum class FrontendState { MainMenu, LevelSetSelect, CharacterSelect, Loading, Options, GraphicsOptions, Controls, Playing, Paused, GameOver, Quit };
  friend struct RuntimeCompatibilityTest;
  struct RectF { float x=0,y=0,w=0,h=0; };
  void previewMusic();
  void pollAudioHotkeys();
  void smokeTrace(const char* msg);
  void beginGame();
  void startCampaign(std::size_t campaignIndex);
  void loadLegacyMenuConfig();
  std::string legacyControlLabel(const std::string& key,const std::string& fallback) const;
  void drawSelectCharacterPreview(const generated::Character* model,int slot,int total);
  bool loadStage(std::size_t index, bool keepHealth=false);
  void playStageCutscene(bool post=false);
  void playStageCompleteScreen();
  void advanceStage();
  void saveProgress();
  bool loadProgress();
  void applyStageGeometry(float oldX,float oldZ);
  bool applyActorTerrain(const generated::Character*,ScriptContext&,float& x,float& z,float altitude,float oldX,float oldZ);
  float dynamicPlatformHeight(float x,float z,const RuntimeEntity* ignore=nullptr,const generated::Character* subject=nullptr) const;
  void updateFrontend();
  void drawFrontend();
  void runModelScript(const char* path, ScriptContext& ctx, const char* event);
  void runAnimationCommand(const generated::Character* model,const generated::Frame* frame,ScriptContext& ctx,const char* event,const generated::Animation* animation);
  void saveSettings();
  bool frontendKeyPressed(int vk);
  bool gamepadButtonPressed(unsigned short button);
  bool gamepadButtonPressedFor(int pad, unsigned short button);
  int captureAnyKey();
  unsigned short captureAnyGamepadButton(int pad);
  void updatePlayer();
  void updateCoopPlayers();
  void updateEntities();
  void updateProjectiles();
  void resolveCombat();
  void updateCombatLock();
  void updateCamera();
  void triggerSpawns();
  void updateStageEvents();
  void processStageInstructions();
  float scrollMin() const;
  float scrollMax() const;
  void drawStage();
  void drawHud();
  bool consumeRespawnResource(int playerSlot);
  void respawnPlayerSlot(int playerSlot);
  void startPlayerAttack();
  void startPlayerJump(bool running=false);
  void startPlayerDash();
  void startEnemyAttack(RuntimeEntity&, float targetDistance=0.0f, std::uintptr_t targetHandle=0);
  void maybeSpawnProjectile(const generated::Character*, const generated::Animation*, std::size_t frameIndex, float x, float z, float altitude, int facing, bool fromPlayer, bool& firedFlag, const generated::Character* equippedOverride=nullptr, int* weaponUses=nullptr);
  void spawnProjectile(const generated::Character*, float x, float z, float altitude, int facing, float vx, float vy, float vz, bool bomb, bool fromPlayer, const generated::Character* ownerModel=nullptr);
  bool detonateProjectile(RuntimeProjectile&,bool contact);
  bool projectileContact(RuntimeProjectile&);
  void tryPickupWeapon();
  void tryPickupWeapon(RuntimeCoopPlayer&);
  void setPlayerWeaponIndex(int index);
  void setCoopWeaponIndex(RuntimeCoopPlayer&, int index);
  void setEntityWeaponIndex(RuntimeEntity&, int index);
  void queueChildSpawn(const generated::Character* owner,const generated::Animation*,std::size_t frameIndex,float x,float z,float altitude,int facing,std::uintptr_t parent);
  void unsummonChildren(std::uintptr_t parent,bool allChildren=false);
  void flushChildSpawns();
  void updateChildFollowing(RuntimeEntity&);
  void queueWeaponDrop(const generated::Character* item,float x,float z,float altitude,int facing,int remaining);
  void flushWeaponDrops();
  void dropPlayerWeapon(bool stageLoss=false);
  void dropCoopWeapon(RuntimeCoopPlayer&,bool stageLoss=false);
  void dropEntityWeapon(RuntimeEntity&,bool stageLoss=false);
  void recordInputHistory(int slot);
  const generated::Animation* commandTarget(const generated::Character*,int slot,int facing) const;
  const generated::Animation* cancelTarget(const generated::Character*,const generated::Animation*,std::size_t frame,int hits,int slot,int facing) const;
  bool tryEntityPickupWeapon(RuntimeEntity&);
  void tryGrabNearest();
  void throwGrabbed();
  void playFrameSound(const generated::Frame*);
  void playHitFx(const generated::Animation*);
  void triggerQuake(const generated::Character*,const generated::Animation*,std::size_t);
  void playDieSound(const generated::Character*);
  const generated::Defense* defenseFor(const generated::Character*,int attackType) const;
  int effectiveDamage(const generated::Character*,int raw,int attackType) const;
  bool defenseAllowsPain(const generated::Character*,int raw,int attackType) const;
  bool defenseAllowsKnockdown(const generated::Character*,int attackType) const;
  bool resolveKnockdown(const generated::Character*,float& meter,bool requested,int attackType,int power) const;
  void applyLandFrame(AnimationPlayer&,float x=0,float z=0,int facing=1,std::uintptr_t parent=0);
  void queueModelDust(const char* modelName,float x,float z,int facing,std::uintptr_t parent);
  void drawShadow(const generated::Character*,float worldX,float z,float altitude);
  void damageEnemy(RuntimeEntity&, int damage, float knockDirection, bool knockdown=false, int dropVy=-3, int attackType=0, std::uintptr_t attacker=0, int landingDamage=0, int landingMode=0, int landingType=-1, float dropVx=0.0f, int forceDirection=0);
  void damagePlayer(int damage, float knockDirection, bool knockdown=false, int dropVy=-3, int attackType=0, std::uintptr_t attacker=0, int landingDamage=0, int landingMode=0, int landingType=-1, float dropVx=0.0f, int forceDirection=0);
  void damageCoopPlayer(RuntimeCoopPlayer&, int damage, float knockDirection, bool knockdown=false, int dropVy=-3, int attackType=0, std::uintptr_t attacker=0, int landingDamage=0, int landingMode=0, int landingType=-1, float dropVx=0.0f, int forceDirection=0);
  bool tryBlockEntity(RuntimeEntity&, const generated::Frame&, std::uintptr_t attacker);
  bool tryBlockPlayer(int slot, const generated::Frame&, std::uintptr_t attacker);
  void renderScriptDrawQueue();
  RectF bboxFor(const generated::Frame*, float worldX, float worldY, int facing=1) const;
  RectF attackFor(const generated::Frame*, float worldX, float worldY, int facing=1) const;
  static bool overlaps(const RectF&, const RectF&);
  void queueAttackFlash(const generated::Frame*,const generated::Character*,bool,const RectF&,const RectF&,float,float,int);
  const generated::Character* findCharacter(const char* name) const;
  const generated::Animation* findAnimation(const generated::Character*, const char* preferred) const;
  const generated::Animation* findActionAnimation(const generated::Character* base,const generated::Character* weapon,const char* preferred) const;
  void setEntityAnimation(RuntimeEntity&, const generated::Animation*);
  void loadCurrentPlayerSprite();
  void loadEntitySprite(RuntimeEntity&);
  RuntimeConfig config_; Renderer renderer_; AnimationPlayer player_; AudioSystem audio_; ScriptVM scriptVm_; ScriptContext playerScriptCtx_; ScriptContext stageScriptCtx_; std::filesystem::path root_;
  const generated::Stage* stage_ = nullptr;
  const generated::Character* playerModel_ = nullptr;
  float playerWorldX_ = 80.0f, playerZ_ = 200.0f, cameraX_ = 0.0f, cameraMaxX_ = 0.0f, stageLength_ = 320.0f;
  float verticalStageScroll_ = 0.0f;
  bool verticalScroll_ = false;
  int verticalScrollSign_ = 1;
  PendingEnergyCost playerEnergyPending_;
  int playerHealth_ = 100, playerMaxHealth_ = 100, playerMp_ = 0, playerMaxMp_ = 0, playerHitStun_ = 0, playerAttackTicks_ = 0, playerAttackCooldown_ = 0;
  int playerPaletteMap_ = 0; int playerFreezeTicks_ = 0, playerPreFreezePaletteMap_ = -1, playerDeathTicks_ = 0; bool playerDeathFollowDeath_ = false; long long playerScore_ = 0;
  int playerFacing_ = 1, playerComboStep_ = 0, playerComboBranch_ = -1, playerComboWindow_ = 0, playerFallTicks_ = 0, playerRecoveryTicks_ = 0, playerInvincibleTicks_ = 0, playerDashTicks_ = 0, playerReactionType_ = 0, playerLandingDamage_ = 0, playerLandingMode_ = 0, playerLandingType_ = -1;
  int playerGuardPoints_ = 0, playerBlockState_ = 0; bool playerBlocking_ = false; float playerKnockdownMeter_ = 0.0f;
  int livesRemaining_ = 0, creditsRemaining_ = 0;
  bool playerAlive_ = true, playerQueuedAttack_ = false, playerProjectileFired_ = false, playerJumping_ = false, playerRunningJump_ = false, playerAnimJumpTriggered_ = false, playerAttackHasHit_ = false;
  int playerAttackHits_ = 0;
  int grabbedEntity_ = -1, grabHoldTicks_ = 0;
  float playerAltitude_ = 0.0f, playerVerticalVelocity_ = 0.0f, playerJumpVelocityX_ = 0.0f, playerJumpVelocityZ_ = 0.0f;
  unsigned playerAttackId_ = 0;
  std::unordered_set<std::uintptr_t> playerLandingHitTargets_;
  bool combatLocked_ = false;
  float combatLockX_ = 0.0f;
  std::size_t nextSpawn_ = 0;
  std::size_t nextInstruction_ = 0;
  std::vector<unsigned char> spawnState_;
  std::vector<unsigned char> eventState_;
  int scrollDir_ = 1;
  bool cameraFixed_ = false;
  bool allowBacktrack_ = false;
  bool scrollBlocked_ = false;
  int groupMin_ = 0, groupMax_ = 0;
  bool groupRefillActive_ = false;
  float backtrackFloor_ = 0.0f;
  std::size_t lastFrame_=(std::size_t)-1; SpriteImage sprite_; SpriteImage background_; SpriteImage titleBackground_; SpriteImage selectBackground_; SpriteImage water_;
  bool bossMusicStarted_=false;
  std::unordered_map<int,SpriteImage> shadowCache_;
  std::unordered_map<std::string,SpriteImage> hudIconCache_;
  std::unordered_map<std::string,SpriteImage> hudDeadIconCache_;
  int quakeTicks_=0,quakeIntensity_=0;
  int hudBarWidth_=70,hudBarHeight_=7;
  float backgroundRatioX_=0.5f; int backgroundOffsetX_=0, backgroundOffsetY_=0;
  std::vector<SpriteImage> panels_;
  std::vector<RuntimeStageLayer> backgroundLayers_;
  std::vector<RuntimeStageLayer> foregroundLayers_;
  std::deque<RuntimeEntity> entities_;
  std::vector<RuntimeProjectile> projectiles_;
  std::vector<PendingChildSpawn> pendingChildSpawns_;
  std::vector<PendingWeaponDrop> pendingWeaponDrops_;
  std::vector<RuntimeCoopPlayer> coopPlayers_;
  const generated::Character* equippedWeapon_ = nullptr;
  int weaponUses_ = 0;
  const generated::Character* weaponItemModel_ = nullptr;
  int weaponDropsRemaining_ = -1;
  std::vector<std::filesystem::path> scriptSamples_;
  std::unordered_map<std::uintptr_t,float> scriptAntigravity_;
  struct EntityBinding {std::uintptr_t target=0;int x=0,z=0,a=0,direction=0,config=0,sort=-1;};
  struct BindActor {float*x=nullptr,*z=nullptr,*alt=nullptr;int*face=nullptr;AnimationPlayer*animation=nullptr;std::size_t*lastFrame=nullptr;const generated::Character*model=nullptr;};
  std::unordered_map<std::uintptr_t,EntityBinding> entityBindings_;
  BindActor bindActor(std::uintptr_t h);
  void applyEntityBindings();
  int bindingSortId(std::uintptr_t h)const;

  float actorAntigravity(std::uintptr_t h,const generated::Character* m)const{auto i=scriptAntigravity_.find(h);return i==scriptAntigravity_.end()?(m?m->antigravity:0.0f):i->second;}
  std::unordered_map<std::uintptr_t,SpriteImage> scriptSprites_;
  std::uintptr_t nextScriptSpriteHandle_ = 0x10000000u;
  std::uintptr_t nextScriptScreenHandle_ = 0x18000000u;
  std::uintptr_t nextScriptFileHandle_ = 0x1C000000u;
  std::unordered_map<std::uintptr_t,ScriptFileStream> scriptFiles_;
  std::vector<ScriptDrawCommand> scriptDrawQueue_;
  ScriptSpawnEntry scriptSpawnEntry_;
  std::unordered_map<std::string,ScriptValue> playerScriptVars_[4];
  unsigned playerKeys_[4]{0,0,0,0};
  unsigned playerNewKeys_[4]{0,0,0,0};
  unsigned playerReleasedKeys_[4]{0,0,0,0};
  unsigned playerPlayKeys_[4]{0,0,0,0};
  unsigned playerDisabledKeys_[4]{0,0,0,0};
  std::deque<InputHistoryEntry> playerInputHistory_[4];
  float playerScriptVelocityX_=0.0f, playerScriptVelocityZ_=0.0f;
  unsigned long long tickCounter_ = 0;
  FrontendState frontendState_ = FrontendState::MainMenu;
  int menuIndex_ = 0;
  int campaignIndex_ = 0;
  std::vector<std::size_t> campaignFirstStages_;
  std::vector<std::string> campaignNames_;
  std::unordered_map<std::string,std::string> legacyKeyLabels_;
  std::unordered_set<std::string> legacyDisabledKeys_;
  std::unordered_map<std::string,SpriteImage> frontendSpriteCache_;
  unsigned long long frontendTick_ = 0;
  int optionIndex_ = 0;
  int graphicsOptionIndex_ = 0;
  int pauseIndex_ = 0;
  bool optionsFromPause_ = false;
  std::size_t stageIndex_ = 0;
  std::size_t pendingBranchTarget_ = (std::size_t)-1;
  bool pendingBranchImmediate_ = false;
  int selectIndex_ = 0;
  int selectedPlayerIndex_ = -1;
  int selectIndexes_[4]{0,0,0,0};
  bool joinedPlayers_[4]{true,false,false,false};
  int controlsIndex_ = 0;
  bool waitingForKey_ = false;
  bool waitingForPad_ = false;
  int controlCaptureDelay_ = 0;
  bool stageComplete_ = false;
  bool smokeMode_ = false;
  int smokeFrameLimit_ = 0;
  int smokeFramesRun_ = 0;
  bool suspendSave_ = false;
};
)CPP";
    std::ofstream engineCpp(src / "Engine.cpp");
    engineCpp << R"CPP(#include "PathEncoding.hpp"
#include "Engine.hpp"
#include "RuntimeConfig.hpp"
#include <random>
#include "../generated/GeneratedCharacters.hpp"
#include "../generated/GeneratedStages.hpp"
#include <algorithm>
#include <cctype>
#include <cmath>
#include <cstring>
#include <iostream>
#include <fstream>
#include <sstream>
#include <unordered_map>
#include <thread>
#include <chrono>
#ifdef _WIN32
#define NOMINMAX
#include <windows.h>
#include <xinput.h>
#pragma comment(lib, "xinput.lib")
#endif

static std::filesystem::path normalizeDataPath(std::string s){
  for(auto& c:s) if(c=='\\') c='/';
  while(s.rfind("./",0)==0) s.erase(0,2);
  std::string low=s; for(auto& c:low)c=(char)std::tolower((unsigned char)c);
  if(low.rfind("data/",0)==0) s.erase(0,5);
  auto p=PathEncoding::path(s).lexically_normal();
  if(p.empty() || p.is_absolute() || p.has_root_name() || p.has_root_directory()) return {};
  for(const auto& part:p) if(part=="..") return {};
  return p;
}
static std::string lowerString(std::string s){ for(auto& c:s)c=(char)std::tolower((unsigned char)c); return s; }
static int modelFacingValue(const generated::Character* model,int current,int scrollDir){
  if(!model)return current;
  if(model->facingAdjust==1)return 1;
  if(model->facingAdjust==2)return -1;
  if(model->facingAdjust==3)return scrollDir<0?-1:1;
  return current;
}
struct StagePlayerSpawn { float x=20.0f,z=0.0f,altitude=0.0f; int facing=1; bool adjusted=false; };
static bool spawnGeometryContains(const generated::Geometry& g,float x,float z){
  if(!g.openborShape)return x>=g.x&&x<=g.x+g.w&&z>=g.z&&z<=g.z+g.h;
  const auto*p=g.shape;float depth=p[6];if(depth<=0||z>p[1]||z<p[1]-depth)return false;
  float left=p[0]+p[3]+(p[1]-z)*((p[2]-p[3])/depth),right=p[0]+p[5]+(p[1]-z)*((p[4]-p[5])/depth);return x>=std::min(left,right)&&x<=std::max(left,right);
}
static bool spawnPointBlocked(const generated::Stage* stage,float x,float z){
  if(!stage)return false;bool hole=false,cover=false;
  for(std::size_t i=0;i<stage->geometryCount;++i){const auto&g=stage->geometry[i];auto kind=lowerString(g.kind?g.kind:"");if(!spawnGeometryContains(g,x,z))continue;float h=g.openborShape?g.shape[7]:(float)g.altitude;
    if(kind=="wall"&&h>0.0f)cover=true;else if(kind=="hole")hole=true;
  }
  return cover||hole;
}
static StagePlayerSpawn findSafePlayerSpawnPoint(const generated::Stage* stage,StagePlayerSpawn raw,int logicalWidth,int scrollDir){
  if(!stage)return raw;raw.z=std::clamp(raw.z,(float)std::min(stage->zMin,stage->zMax),(float)std::max(stage->zMin,stage->zMax));raw.x=std::max(0.0f,raw.x);
  if(!spawnPointBlocked(stage,raw.x,raw.z))return raw;
  const float zStep=8.0f,xStep=16.0f;const int dir=scrollDir<0?-1:1;
  for(int radius=1;radius<=12;++radius){
    for(int zi=-radius;zi<=radius;++zi){
      const int xi=radius-std::abs(zi);for(int sign: {1,-1}){float cx=std::max(0.0f,raw.x+(float)(xi*sign*dir)*xStep);float cz=std::clamp(raw.z+(float)zi*zStep,(float)std::min(stage->zMin,stage->zMax),(float)std::max(stage->zMin,stage->zMax));if(!spawnPointBlocked(stage,cx,cz)){raw.x=cx;raw.z=cz;raw.adjusted=true;return raw;}}
    }
  }
  // Last-resort safe band inside the walkable Z range. Keeping the player visible
  // is preferable to spawning directly inside authored hole/wall geometry.
  raw.z=(float)(stage->zMin+std::max(0,(stage->zMax-stage->zMin)/2));raw.x=std::max(0.0f,raw.x+(float)dir*std::max(16,logicalWidth/10));raw.adjusted=true;return raw;
}
static StagePlayerSpawn stagePlayerSpawn(const generated::Stage* stage,int slot,float cameraX,int logicalWidth,int scrollDir){
  StagePlayerSpawn out;if(!stage)return out;slot=std::clamp(slot,0,3);
  bool defined=false;int x=0,z=stage->zMin+5,a=0;
  if(slot==0){defined=stage->player1SpawnDefined;x=stage->playerStartX;z=stage->playerStartZ;a=stage->playerStartA;}
  else if(slot==1){defined=stage->player2SpawnDefined;x=stage->player2StartX;z=stage->player2StartZ;a=stage->player2StartA;}
  else if(slot==2){defined=stage->player3SpawnDefined;x=stage->player3StartX;z=stage->player3StartZ;a=stage->player3StartA;}
  else {defined=stage->player4SpawnDefined;x=stage->player4StartX;z=stage->player4StartZ;a=stage->player4StartA;}
  out.facing=scrollDir<0?-1:1;
  if(defined){out.x=(float)x;out.z=(float)z;out.altitude=-(float)std::max(0,a);return findSafePlayerSpawnPoint(stage,out,logicalWidth,scrollDir);}
  float wide=std::max(0.0f,((float)std::max(160,logicalWidth)-320.0f)*0.5f);
  float screenX=scrollDir<0?(300.0f-30.0f*(float)slot):(20.0f+30.0f*(float)slot);
  out.x=cameraX+wide+screenX;out.z=(stage->zMax-stage->zMin>5)?(float)(stage->zMin+5):(float)stage->zMin;out.altitude=0.0f;return findSafePlayerSpawnPoint(stage,out,logicalWidth,scrollDir);
}
static std::string lowerExt(const std::filesystem::path& p){ return lowerString(PathEncoding::utf8(p.extension())); }
// OpenBOR entity type bit values used by candamage/hostile/projectilehit.
static int openborTypeBit(const generated::Character* m){
  if(!m)return 0;auto t=lowerString(m->type?m->type:"");
  if(t=="none")return 1<<0;if(t=="player")return 1<<2;if(t=="enemy")return 1<<3;if(t=="item")return 1<<4;if(t=="obstacle")return 1<<5;if(t=="projectile")return 1<<6;if(t=="steamer")return 1<<7;if(t=="shot")return 1<<8;if(t=="trap")return 1<<9;if(t=="textbox")return 1<<10;if(t=="endlevel")return 1<<11;if(t=="npc")return 1<<12;if(t=="panel")return 1<<13;return 0;
}
static bool auxiliaryCombatType(const generated::Character* m){
  if(!m)return true;auto t=lowerString(m->type?m->type:"");return t.empty()||t=="none"||t=="projectile"||t=="shot";
}
static const generated::Character* effectiveCombatType(const generated::Character* model,const generated::Character* owner){
  return owner&&auxiliaryCombatType(model)?owner:model;
}
static bool maskAllowsTarget(int mask,const generated::Character* target){int bit=openborTypeBit(target);return mask!=0&&bit!=0&&(mask&bit)!=0;}
static bool modelCanPerceive(const generated::Character* observer,const generated::Character* target,const generated::Character* owner=nullptr){
  if(!target)return false;const auto*effective=effectiveCombatType(observer,owner);int perception=effective?std::max(0,effective->perception):0;return perception>=std::max(0,target->stealth);
}
static bool modelIsHostileTo(const generated::Character* attacker,const generated::Character* target,bool legacyDefault,const generated::Character* owner=nullptr){
  if(!target)return legacyDefault;
  if(attacker&&attacker->hostileMask!=0)return maskAllowsTarget(attacker->hostileMask,target);
  const auto*effective=effectiveCombatType(attacker,owner);if(effective&&effective!=attacker&&effective->hostileMask!=0)return maskAllowsTarget(effective->hostileMask,target);
  return legacyDefault;
}
static bool modelCanDamage(const generated::Character* attacker,const generated::Character* target,bool legacyDefault,const generated::Character* owner=nullptr){
  if(!target)return legacyDefault;
  if(attacker&&attacker->canDamageMask!=0)return maskAllowsTarget(attacker->canDamageMask,target);
  const auto*effective=effectiveCombatType(attacker,owner);if(effective&&effective!=attacker&&effective->canDamageMask!=0)return maskAllowsTarget(effective->canDamageMask,target);
  // Weapon/projectile models commonly use `type none`. When their own masks are
  // absent, OpenBOR keeps the owner's combat faction instead of turning neutral.
  return legacyDefault;
}
static int highestAttackIndex(const generated::Character* m){
  if(!m)return 1;int hi=1;for(std::size_t i=0;i<m->animationCount;++i){std::string n=lowerString(m->animations[i].name?m->animations[i].name:"");if(n=="attack")hi=std::max(hi,1);else if(n.rfind("attack",0)==0&&n.size()>6){try{hi=std::max(hi,std::stoi(n.substr(6)));}catch(...){}}}return hi;
}
static int comboWindowFor(const generated::Character* m,int fallback){
  if(!m||m->comboDelay<=0)return fallback;return std::max(6,(int)std::lround((double)m->comboDelay*0.30));
}
static std::vector<std::vector<int>> comboBranches(const generated::Character* m){
  std::vector<std::vector<int>> out;if(!m||!m->attackChain||m->attackChainCount==0)return out;out.push_back({});for(std::size_t i=0;i<m->attackChainCount;++i){int v=m->attackChain[i];if(v<=0){if(!out.back().empty())out.push_back({});continue;}out.back().push_back(v);}if(!out.empty()&&out.back().empty())out.pop_back();return out;
}
static int chainAttackNumber(const generated::Character* m,int step){
  if(!m)return std::max(1,step+1);if(!m->attackChain||m->attackChainCount==0)return ((std::max(0,step))%std::max(1,highestAttackIndex(m)))+1;
  auto branches=comboBranches(m);if(branches.empty())return 1;const auto&chain=branches.front();if(chain.empty())return 1;return chain[(std::size_t)(std::max(0,step)%((int)chain.size()))];
}
static bool attackRangePass(const generated::Character* m,int attack,float dx,float dz,float da){
  if(!m)return false;const generated::Animation* a=nullptr;std::string name="attack"+std::to_string(std::max(1,attack));for(std::size_t i=0;i<m->animationCount;++i)if(lowerString(m->animations[i].name?m->animations[i].name:"")==name){a=&m->animations[i];break;}if(!a)return false;float ax=std::fabs(dx),az=std::fabs(dz);float xmin=a->hasRangeX?a->rangeXMin:0.0f,xmax=a->hasRangeX?a->rangeXMax:75.0f;float zmin=a->hasRangeZ?std::min(std::fabs(a->rangeZMin),std::fabs(a->rangeZMax)):0.0f,zmax=a->hasRangeZ?std::max(std::fabs(a->rangeZMin),std::fabs(a->rangeZMax)):std::max(1.0f,(float)m->grabDistance/3.0f);float amin=a->hasRangeA?a->rangeAMin:-1000.0f,amax=a->hasRangeA?a->rangeAMax:1000.0f;return ax>=std::min(xmin,xmax)&&ax<=std::max(xmin,xmax)&&az>=zmin&&az<=zmax&&da>=amin&&da<=amax;
}
static int dynamicChainAttackNumber(const generated::Character* m,int step,int& branch,float dx,float dz,float da){
  if(!m||m->comboStyle!=1)return chainAttackNumber(m,step);auto b=comboBranches(m);if(b.empty())return chainAttackNumber(m,step);if(step<=0){branch=-1;return b[0].empty()?1:b[0][0];}
  if(branch<0){for(std::size_t bi=0;bi<b.size();++bi){std::size_t idx=(bi==0?(std::size_t)step:(std::size_t)step-1);if(idx<b[bi].size()&&attackRangePass(m,b[bi][idx],dx,dz,da)){branch=(int)bi;break;}}if(branch<0)branch=0;}
  std::size_t idx=(branch==0?(std::size_t)step:(std::size_t)step-1);if(branch<0||(std::size_t)branch>=b.size()||idx>=b[(std::size_t)branch].size()){branch=-1;return b[0].empty()?1:b[0][0];}return b[(std::size_t)branch][idx];
}
static bool followConditionPass(int cond,bool blocked,bool hostile,bool lethal,bool targetNoGrab){
  switch(cond){case 1:return true;case 2:return hostile;case 3:return hostile&&!lethal&&!blocked;case 4:return hostile&&!lethal&&!blocked&&!targetNoGrab;case 5:return hostile&&!lethal&&!blocked;default:return false;}
}
static bool animationHasProjectile(const generated::Animation* a){return a&&(a->throwFrame>=0||a->tossFrame>=0);}
static std::filesystem::path runtimeCasePath(const std::filesystem::path& p){
  if(std::filesystem::exists(p))return p;auto out=p.root_path();
  for(const auto&part:p.relative_path()){auto next=out/part;std::error_code ec;if(!std::filesystem::exists(next,ec)&&std::filesystem::is_directory(out,ec)){std::filesystem::path match;for(std::filesystem::directory_iterator it(out,ec),end;!ec&&it!=end;it.increment(ec))if(lowerString(PathEncoding::utf8(it->path().filename()))==lowerString(PathEncoding::utf8(part))){if(!match.empty())return p;match=it->path();}if(!match.empty())next=match;}out=next;}return out;
}
static std::filesystem::path resolveSpriteAsset(const std::filesystem::path& dataRoot,const char* raw){
  if(!raw||!*raw)return {};
  auto rel=normalizeDataPath(raw);
  auto exact=runtimeCasePath(dataRoot/rel);
  if(std::filesystem::exists(exact))return exact;
  // OpenBOR packs sometimes ship a palette source under a different raster extension
  // than the legacy reference. Recover only an unambiguous same-stem sibling.
  static const char* exts[]={".gif",".bmp",".pcx",".png"};
  if(rel.has_extension()){auto stem=exact;stem.replace_extension();std::filesystem::path found;for(auto* ext:exts){auto p=stem;p+=ext;p=runtimeCasePath(p);if(!std::filesystem::exists(p))continue;if(!found.empty()&&runtimeCasePath(found)!=p)return exact;found=p;}if(!found.empty())return found;return exact;}
  // OpenBOR legacy extension fallback order.
  for(auto* ext:exts){auto p=exact;p+=ext;p=runtimeCasePath(p);if(std::filesystem::exists(p))return p;}
  return exact;
}
static std::filesystem::path resolveAudioAsset(const std::filesystem::path& dataRoot,const std::string& raw){
  if(raw.empty())return {};auto rel=normalizeDataPath(raw);if(rel.empty())return {};auto exact=runtimeCasePath(dataRoot/rel);if(std::filesystem::exists(exact))return exact;if(rel.has_extension())return exact;
  // OpenBOR-compatible extension probing: exact path first, then streamed/native formats.
  static const char* exts[]={".ogg",".oga",".wav",".bor",".mp3",".flac"};for(auto* ext:exts){auto p=exact;p+=ext;p=runtimeCasePath(p);if(std::filesystem::exists(p))return p;}return exact;
}
static int paletteIndexFromText(const char* raw){if(!raw||!*raw)return 0;try{return std::max(0,std::stoi(raw));}catch(...){return 0;}}
static unsigned char unpremul(unsigned char c,unsigned char a){if(a==0)return 0;return (unsigned char)std::min(255u,((unsigned)c*255u+(unsigned)a/2u)/(unsigned)a);}
static bool loadPaletteColors(Renderer& renderer,const std::filesystem::path& path,std::vector<unsigned>& colors){
  colors.clear();
  if(lowerExt(path)==".act"){
    std::ifstream f(path,std::ios::binary);if(!f)return false;std::vector<unsigned char> bytes((std::istreambuf_iterator<char>(f)),{});std::size_t count=std::min<std::size_t>(256,bytes.size()/3);if(count==0)return false;colors.reserve(count);for(std::size_t i=0;i<count;++i){unsigned r=bytes[i*3],g=bytes[i*3+1],b=bytes[i*3+2];colors.push_back(b|(g<<8)|(r<<16));}return true;
  }
  // Preserve the indexed palette table itself whenever the decoder exposes it.
  // This makes legacy GIF remaps index-stable instead of deriving a LUT from
  // the image's pixel order. The fallback remains for non-indexed assets.
  if(renderer.loadPalette(path,colors))return true;
  SpriteImage img;if(!renderer.loadSprite(path,img))return false;colors.reserve(img.bgra.size()/4);for(std::size_t o=0;o+3<img.bgra.size();o+=4){auto a=img.bgra[o+3];if(a==0){colors.push_back(0);continue;}unsigned b=unpremul(img.bgra[o],a),g=unpremul(img.bgra[o+1],a),r=unpremul(img.bgra[o+2],a);colors.push_back(b|(g<<8)|(r<<16));}return !colors.empty();
}
static void applyCharacterPalette(Renderer& renderer,const std::filesystem::path& dataRoot,const generated::Character* model,int mapIndex,SpriteImage& sprite){
  if(!model||mapIndex<=0||sprite.bgra.empty())return;
  const char* source=nullptr;const char* target=nullptr;
  if(model->paletteRemapCount>0 && model->paletteRemaps && (std::size_t)mapIndex<=model->paletteRemapCount){source=model->paletteRemaps[mapIndex-1].source;target=model->paletteRemaps[mapIndex-1].target;}
  else if(model->palettePath&&*model->palettePath&&model->alternatePalettes&&(std::size_t)mapIndex<=model->alternatePaletteCount){source=model->palettePath;target=model->alternatePalettes[mapIndex-1];}
  if(!source||!target||!*source||!*target)return;
  auto sourcePath=resolveSpriteAsset(dataRoot,source),targetPath=resolveSpriteAsset(dataRoot,target);std::vector<unsigned> srcColors,tgtColors;if(!loadPaletteColors(renderer,sourcePath,srcColors)||!loadPaletteColors(renderer,targetPath,tgtColors))return;
  const std::size_t count=std::min(srcColors.size(),tgtColors.size());if(count==0)return;std::unordered_map<unsigned,unsigned> lut;lut.reserve(count);for(std::size_t i=0;i<count;++i)lut[srcColors[i]]=tgtColors[i];
  for(std::size_t o=0;o+3<sprite.bgra.size();o+=4){auto a=sprite.bgra[o+3];if(a==0)continue;unsigned b=unpremul(sprite.bgra[o],a),g=unpremul(sprite.bgra[o+1],a),r=unpremul(sprite.bgra[o+2],a);auto it=lut.find(b|(g<<8)|(r<<16));if(it==lut.end())continue;unsigned v=it->second;unsigned nb=v&255u,ng=(v>>8)&255u,nr=(v>>16)&255u;sprite.bgra[o]=(unsigned char)(nb*a/255u);sprite.bgra[o+1]=(unsigned char)(ng*a/255u);sprite.bgra[o+2]=(unsigned char)(nr*a/255u);}
}

const generated::Character* Engine::findCharacter(const char* name) const{
  if(!name) return nullptr; auto wanted=lowerString(name);
  for(std::size_t i=0;i<generated::kCharacterCount;++i){
    const auto& c=generated::kCharacters[i];
    if((c.modelName && lowerString(c.modelName)==wanted) || (c.name && lowerString(c.name)==wanted)) return &c;
  }
  return nullptr;
}
const generated::Animation* Engine::findAnimation(const generated::Character* c,const char* preferred) const{
  if(!c || c->animationCount==0) return nullptr; auto wanted=lowerString(preferred?preferred:"");
  for(std::size_t i=0;i<c->animationCount;++i){ auto n=lowerString(c->animations[i].name); if(n==wanted || (!wanted.empty() && n.find(wanted)!=std::string::npos)) return &c->animations[i]; }
  return &c->animations[0];
}
static const generated::Animation* exactAnimation(const generated::Character* c,const std::string& wanted){if(!c)return nullptr;auto low=lowerString(wanted);for(std::size_t i=0;i<c->animationCount;++i)if(lowerString(c->animations[i].name)==low)return &c->animations[i];return nullptr;}
const generated::Animation* Engine::findActionAnimation(const generated::Character* base,const generated::Character* weapon,const char* preferred) const{
  if(weapon){if(auto* a=exactAnimation(weapon,preferred?preferred:""))return a;if((weapon->modelCopyFlags&1)!=0)return nullptr;}
  return findAnimation(base,preferred);
}
static const generated::Animation* followAnimationFor(const generated::Character* model,const generated::Animation* source){
  if(!model||!source||source->followAnim<=0)return nullptr;return exactAnimation(model,"follow"+std::to_string(source->followAnim));
}
struct CounterResult{const generated::Animation* animation=nullptr;bool takesDamage=true;bool rage=false;};
static CounterResult counterFor(const generated::Character* model,const generated::Animation* current,std::size_t frame,bool hostile,bool unblockable,bool fromFront,int currentHealth,int damage){
  CounterResult out;if(!model||!current||current->counterStart<0||current->counterEnd<current->counterStart||(int)frame<current->counterStart||(int)frame>current->counterEnd)return out;
  bool ok=false;switch(current->counterCond){case 1:ok=true;break;case 2:ok=hostile;break;case 3:ok=hostile&&!unblockable&&fromFront;break;case 4:ok=true;out.rage=true;break;default:break;}if(!ok)return out;
  out.animation=followAnimationFor(model,current);out.takesDamage=current->counterTakesDamage;if(out.rage&&currentHealth-damage<=0)out.takesDamage=false;return out;
}
static const generated::Animation* reactionAnimation(const generated::Character* c,const char* base,int attackType){if(!c)return nullptr;if(attackType==1004){std::string b=base?base:"";if(b=="pain"){if(auto a=exactAnimation(c,"spain"))return a;}if(b=="fall"){if(auto a=exactAnimation(c,"shock"))return a;}}if(attackType==1002){std::string b=base?base:"";if(b=="pain"){if(auto a=exactAnimation(c,"bpain"))return a;if(auto a=exactAnimation(c,"burn"))return a;}if(b=="fall"){if(auto a=exactAnimation(c,"burn"))return a;if(auto a=exactAnimation(c,"bfell"))return a;}}if(attackType>1&&attackType<1000){if(auto a=exactAnimation(c,std::string(base)+std::to_string(attackType)))return a;}if(auto a=exactAnimation(c,base))return a;return nullptr;}
void Engine::setEntityAnimation(RuntimeEntity& e,const generated::Animation* a){ if(a && e.animation.animation()!=a){ e.animation.setAnimation(a); e.lastFrame=(std::size_t)-1; } }

static std::string scriptString(const ScriptValue& v){if(auto p=std::get_if<std::string>(&v))return *p;if(auto p=std::get_if<double>(&v))return std::to_string(*p);if(auto p=std::get_if<bool>(&v))return *p?"1":"0";return {};}
static double scriptNumber(const ScriptValue& v){if(auto p=std::get_if<double>(&v))return *p;if(auto p=std::get_if<bool>(&v))return *p?1.0:0.0;if(auto p=std::get_if<std::uintptr_t>(&v))return (double)*p;if(auto p=std::get_if<std::string>(&v)){try{return std::stod(*p);}catch(...){}}return 0.0;}
static std::uintptr_t scriptPointer(const ScriptValue& v){if(auto p=std::get_if<std::uintptr_t>(&v))return *p;return (std::uintptr_t)scriptNumber(v);}
static int animationDuration(const generated::Animation*,std::size_t first=0);
static void applyDropFrameOnApex(AnimationPlayer& player,float before,float after);
static bool costDisabled(const generated::Character* model,int disable){
  auto t=lowerString(model&&model->type?model->type:"");bool player=t=="player",enemy=t=="enemy",npc=t=="npc";
  if(disable==1||disable==-1)return true;
  if(disable==2||disable==-2)return enemy||npc;
  if(disable==3||disable==-3)return player||npc;
  if(disable==4||disable==-4)return player||enemy;
  return disable!=0&&disable==openborTypeBit(model);
}
static bool hasAnimationEnergy(const generated::Animation* a,const generated::Character* m,int hp,int mp){
  if(!a||costDisabled(m,a->energyDisable))return false;int cost=std::max(0,a->energyCost);
  return (a->energyMode!=2&&mp>=cost)||(a->energyMode!=1&&hp>cost);
}
static void debitAnimationEnergy(int cost,int mode,int&hp,int&mp){
  if(cost<=0)return;if(mode!=2&&mp>=cost)mp-=cost;else if(mode!=1)hp=std::max(1,hp-cost);
}
static void finishAnimationEnergy(PendingEnergyCost& pending,int&hp,int&mp){
  if(pending.animation&&pending.hit)debitAnimationEnergy(pending.cost,pending.mode,hp,mp);pending={};
}
static bool beginEnergyAnimation(AnimationPlayer& player,const generated::Animation* animation,const generated::Character* model,int&hp,int&mp,PendingEnergyCost&pending){
  if(!hasAnimationEnergy(animation,model,hp,mp))return false;
  finishAnimationEnergy(pending,hp,mp);
  if(!hasAnimationEnergy(animation,model,hp,mp))return false;
  if(model&&model->globalNoCost&&animation->energyCost>0)pending={animation,animation->energyCost,animation->energyMode,false};
  else debitAnimationEnergy(animation->energyCost,animation->energyMode,hp,mp);
  player.setAnimation(animation);return true;
}
static void settleAnimationEnergy(PendingEnergyCost& pending,const AnimationPlayer& player,int&hp,int&mp){
  if(pending.animation&&(player.animation()!=pending.animation||player.finished()))finishAnimationEnergy(pending,hp,mp);
}

void Engine::runModelScript(const char* path, ScriptContext& ctx, const char* event){
  if(!path||!*path)return;auto result=scriptVm_.runFile(path,ctx,"main");if(!result.ok)std::cerr<<"Script VM "<<(event?event:"hook")<<" error ["<<path<<"]: "<<result.error<<"\n";
  if(!result.unsupported.empty()){std::filesystem::create_directories(root_/"logs");std::ofstream log(root_/"logs"/"script-vm.log",std::ios::app);for(const auto&f:result.unsupported){log<<(event?event:"hook")<<"\t"<<path<<"\tunsupported="<<f<<"\n";}}
}
void Engine::runAnimationCommand(const generated::Character* model,const generated::Frame* frame,ScriptContext& ctx,const char* event,const generated::Animation* animation){
  if(!model||!frame)return;
  std::string command=animation&&animation->inlineScript?animation->inlineScript:"";
  if(frame->animationCommand&&*frame->animationCommand){command+='\n';command+=frame->animationCommand;}
  ctx.local["animhandle"]=std::string(animation&&animation->name?animation->name:"");
  if(command.empty()&&(!model->animationScript||!*model->animationScript))return;
  auto result=scriptVm_.runAnimationCommand(model->animationScript?model->animationScript:"",command,ctx);
  if(!result.ok)std::cerr<<"Animation ScriptVM "<<(event?event:"animation")<<" model="<<(model->name?model->name:"?")<<" anim="<<(animation&&animation->name?animation->name:"?")<<" frame="<<(std::get_if<double>(&ctx.local["frame"])?std::get<double>(ctx.local["frame"]):-1)<<" frameSprite="<<(frame?frame->sprite:"")<<" helper="<<(model->animationScript?model->animationScript:"")<<" call="<<command<<" error: "<<result.error<<"\n";
  if(!result.unsupported.empty()){std::filesystem::create_directories(root_/"logs");std::ofstream log(root_/"logs"/"script-vm.log",std::ios::app);for(const auto&f:result.unsupported){log<<(event?event:"animation")<<"\tmodel="<<(model->name?model->name:"?")<<"\thelper="<<(model->animationScript?model->animationScript:"")<<"\tcall="<<command<<"\tunsupported="<<f<<"\n";}}
}
enum ScriptKeyBits : unsigned {
  SK_LEFT=1u<<0, SK_RIGHT=1u<<1, SK_UP=1u<<2, SK_DOWN=1u<<3,
  SK_ATTACK=1u<<4, SK_JUMP=1u<<5, SK_SPECIAL=1u<<6, SK_START=1u<<7,
  SK_ESC=1u<<8, SK_ATTACK2=1u<<9, SK_ATTACK3=1u<<10, SK_ATTACK4=1u<<11
};
static unsigned scriptKeyBit(const std::string& raw){
  auto k=lowerString(raw);if(k=="moveleft"||k=="left")return SK_LEFT;if(k=="moveright"||k=="right")return SK_RIGHT;if(k=="moveup"||k=="up")return SK_UP;if(k=="movedown"||k=="down")return SK_DOWN;
  if(k=="attack"||k=="attack1")return SK_ATTACK;if(k=="attack2")return SK_ATTACK2;if(k=="attack3")return SK_ATTACK3;if(k=="attack4")return SK_ATTACK4;if(k=="jump")return SK_JUMP;if(k=="special")return SK_SPECIAL;if(k=="start")return SK_START;if(k=="esc"||k=="escape")return SK_ESC;
  if(k=="anybutton")return SK_ATTACK|SK_ATTACK2|SK_ATTACK3|SK_ATTACK4|SK_JUMP|SK_SPECIAL;return 0;
}
struct ParsedCommandStep{unsigned press=0,hold=0,holdTrigger=0,release=0;int holdMin=0,holdMax=0,chordTime=0;};
struct ParsedCommand{std::vector<ParsedCommandStep> steps;int sequenceGrace=50;int specificity=0;};
static unsigned commandBit(std::string tok,int facing){tok=lowerString(tok);if(tok=="a")return SK_ATTACK;if(tok=="a2")return SK_ATTACK2;if(tok=="a3")return SK_ATTACK3;if(tok=="a4")return SK_ATTACK4;if(tok=="j")return SK_JUMP;if(tok=="s"||tok=="k")return SK_SPECIAL;if(tok=="u")return SK_UP;if(tok=="d")return SK_DOWN;if(tok=="l")return SK_LEFT;if(tok=="r")return SK_RIGHT;if(tok=="f")return facing>=0?SK_RIGHT:SK_LEFT;if(tok=="b")return facing>=0?SK_LEFT:SK_RIGHT;return scriptKeyBit(tok);}
static int bracketNumber(const std::string&s,std::size_t from,int fallback=0){auto a=s.find('[',from),b=a==std::string::npos?std::string::npos:s.find(']',a+1);if(a==std::string::npos||b==std::string::npos)return fallback;try{return std::max(0,std::stoi(s.substr(a+1,b-a-1)));}catch(...){return fallback;}}
static ParsedCommand parseOpenBorCommand(std::string raw,int facing){
  ParsedCommand out;for(std::size_t p=0;(p=raw.find(":[",p))!=std::string::npos;){auto e=raw.find(']',p+2);if(e==std::string::npos)break;try{out.sequenceGrace=std::max(1,std::stoi(raw.substr(p+2,e-p-2)));}catch(...){}raw.replace(p,e-p+1," ");}
  for(std::size_t p=0;(p=raw.find("->",p))!=std::string::npos;){raw.replace(p,2," | ");p+=3;}for(char&c:raw)if(c==',')c=' ';
  std::istringstream ss(raw);std::string tok;ParsedCommandStep cur{};bool join=false;auto flush=[&](){if(cur.press||cur.hold||cur.holdTrigger||cur.release){out.steps.push_back(cur);cur={};}};
  while(ss>>tok){if(tok=="|"){flush();join=false;continue;}if(tok=="+"){join=true;continue;}if(tok.rfind("+[",0)==0){cur.chordTime=bracketNumber(tok,1,0);join=true;continue;}if((cur.press||cur.hold||cur.holdTrigger||cur.release)&&!join)flush();
    bool release=!tok.empty()&&tok[0]=='~';if(release)tok.erase(tok.begin());bool trigger=tok.find('*')!=std::string::npos;if(trigger)tok.erase(tok.find('*'),1);auto bp=tok.find('[');std::string key=bp==std::string::npos?tok:tok.substr(0,bp);unsigned bit=commandBit(key,facing);if(!bit){join=false;continue;}int minHold=bp==std::string::npos?0:bracketNumber(tok,bp,0);int maxHold=0;if(bp!=std::string::npos){auto close=tok.find(']',bp+1);if(close!=std::string::npos)maxHold=bracketNumber(tok,close+1,0);}if(release)cur.release|=bit;else if(trigger)cur.holdTrigger|=bit;else if(bp!=std::string::npos)cur.hold|=bit;else cur.press|=bit;if(bp!=std::string::npos){cur.holdMin=std::max(cur.holdMin,minHold);if(maxHold>0)cur.holdMax=cur.holdMax==0?maxHold:std::min(cur.holdMax,maxHold);}out.specificity+=1+(bp!=std::string::npos)+(release||trigger);join=false;
  }flush();return out;
}
static int heldDuration(const std::deque<InputHistoryEntry>&h,std::ptrdiff_t pos,unsigned bit){if(pos<0)return 0;std::ptrdiff_t p=pos;if((h[(std::size_t)p].held&bit)==0){if((h[(std::size_t)p].released&bit)==0)return 0;--p;}int n=0;for(;p>=0&&((h[(std::size_t)p].held&bit)!=0);--p)++n;return n;}
static bool commandStepMatches(const std::deque<InputHistoryEntry>&h,std::ptrdiff_t pos,const ParsedCommandStep&st){if(pos<0)return false;const auto&e=h[(std::size_t)pos];
  if(st.release&&((e.released&st.release)!=st.release))return false;if(st.holdTrigger){if((e.held&st.holdTrigger)!=st.holdTrigger)return false;for(unsigned b=1;b;b<<=1)if(st.holdTrigger&b){int d=heldDuration(h,pos,b);if(d!=std::max(1,st.holdMin))return false;}}
  if(st.press){if(st.chordTime<=0){if((e.newKeys&st.press)!=st.press)return false;}else{if((e.held&st.press)!=st.press)return false;for(unsigned b=1;b;b<<=1)if(st.press&b){bool edge=false;for(std::ptrdiff_t j=pos;j>=0&&pos-j<=st.chordTime;--j)if(h[(std::size_t)j].newKeys&b){edge=true;break;}if(!edge)return false;}}}
  unsigned holdMask=st.hold;if(st.release)holdMask|=st.release;for(unsigned b=1;b;b<<=1)if(holdMask&b){int d=heldDuration(h,pos,b);if(d<st.holdMin)return false;if(st.holdMax>0&&d>st.holdMax)return false;}return st.press||st.release||st.holdTrigger;
}
static bool matchOpenBorCommand(const std::deque<InputHistoryEntry>&h,const std::string&raw,int facing,int* score=nullptr){if(h.empty())return false;auto parsed=parseOpenBorCommand(raw,facing);if(parsed.steps.empty())return false;std::ptrdiff_t pos=(std::ptrdiff_t)h.size()-1,newest=-1,previous=-1;for(std::ptrdiff_t si=(std::ptrdiff_t)parsed.steps.size()-1;si>=0;--si){bool found=false;for(;pos>=0;--pos){if(previous>=0&&previous-pos>parsed.sequenceGrace)break;if(commandStepMatches(h,pos,parsed.steps[(std::size_t)si])){if(newest<0)newest=pos;previous=pos;found=true;--pos;break;}}if(!found)return false;}if(newest!=(std::ptrdiff_t)h.size()-1)return false;if(score)*score=(int)parsed.steps.size()*100+parsed.specificity;return true;}
const generated::Animation* Engine::cancelTarget(const generated::Character* model,const generated::Animation* anim,std::size_t frame,int hits,int slot,int facing) const{
  if(!model||!anim||!anim->cancels||anim->cancelCount==0||slot<0||slot>=4)return nullptr;const auto&hist=playerInputHistory_[slot];for(std::size_t i=0;i<anim->cancelCount;++i){const auto&c=anim->cancels[i];if((int)frame<c.startFrame||(int)frame>c.endFrame||hits<c.hits)continue;if(!matchOpenBorCommand(hist,c.command?c.command:"",facing))continue;std::string target=c.targetAnimation?c.targetAnimation:"";if(target.empty())continue;if(std::all_of(target.begin(),target.end(),[](unsigned char ch){return std::isdigit(ch)!=0;}))target="freespecial"+target;if(auto*a=exactAnimation(model,target))return a;if(auto*a=findAnimation(model,target.c_str()))return a;}return nullptr;
}
void Engine::recordInputHistory(int slot){if(slot<0||slot>=4)return;InputHistoryEntry e{playerPlayKeys_[slot],playerNewKeys_[slot],playerReleasedKeys_[slot]};auto&h=playerInputHistory_[slot];h.push_back(e);while(h.size()>128)h.pop_front();}
const generated::Animation* Engine::commandTarget(const generated::Character* model,int slot,int facing) const{
  if(!model||!model->commands||model->commandCount==0||slot<0||slot>=4)return nullptr;const auto&hist=playerInputHistory_[slot];const generated::Animation*best=nullptr;int bestScore=-1;for(std::size_t ci=0;ci<model->commandCount;++ci){const auto&cmd=model->commands[ci];int score=0;if(!matchOpenBorCommand(hist,cmd.sequence?cmd.sequence:"",facing,&score))continue;std::string target=cmd.targetAnimation?cmd.targetAnimation:"";if(target.empty())continue;if(std::all_of(target.begin(),target.end(),[](unsigned char ch){return std::isdigit(ch)!=0;}))target="freespecial"+target;const generated::Animation*a=exactAnimation(model,target);if(!a)a=findAnimation(model,target.c_str());if(a&&score>=bestScore){best=a;bestScore=score;}}return best;
}
static ScriptValue openborConstantValue(const std::string& raw){
  auto k=lowerString(raw);
  if(k.rfind("ani_",0)==0)return k.substr(4);
  if(k.rfind("type_",0)==0)return k.substr(5);
  if(k=="flag_moveleft")return (double)SK_LEFT;if(k=="flag_moveright")return (double)SK_RIGHT;if(k=="flag_moveup")return (double)SK_UP;if(k=="flag_movedown")return (double)SK_DOWN;
  if(k=="flag_attack"||k=="flag_attack1")return (double)SK_ATTACK;if(k=="flag_attack2")return (double)SK_ATTACK2;if(k=="flag_attack3")return (double)SK_ATTACK3;if(k=="flag_attack4")return (double)SK_ATTACK4;
  if(k=="flag_jump")return (double)SK_JUMP;if(k=="flag_special")return (double)SK_SPECIAL;if(k=="flag_start")return (double)SK_START;if(k=="flag_esc")return (double)SK_ESC;
  if(k=="direction_left")return 0.0;if(k=="direction_right")return 1.0;
  if(k=="type_none")return (double)(1<<0);if(k=="type_player")return (double)(1<<2);if(k=="type_enemy")return (double)(1<<3);if(k=="type_item")return (double)(1<<4);if(k=="type_obstacle")return (double)(1<<5);if(k=="type_projectile")return (double)(1<<6);if(k=="type_shot")return (double)(1<<8);if(k=="type_trap")return (double)(1<<9);if(k=="type_npc")return (double)(1<<12);
  if(k=="aiattack1_normal")return 0.0;if(k=="aiattack1_long")return 1.0;if(k=="aiattack1_melee")return 2.0;if(k=="aiattack1_noattack")return 4.0;if(k=="aiattack1_always")return 8.0;if(k=="aiattack2_dodge")return 65536.0;if(k=="aiattack2_dodgemove")return 131072.0;
  if(k=="aimove1_none")return 0.0;if(k=="aimove1_normal")return 1.0;if(k=="aimove1_chase")return 2.0;if(k=="aimove1_chasez")return 4.0;if(k=="aimove1_chasex")return 8.0;if(k=="aimove1_avoid")return 16.0;if(k=="aimove1_avoidz")return 32.0;if(k=="aimove1_avoidx")return 64.0;if(k=="aimove1_wander")return 128.0;if(k=="aimove1_biker")return 256.0;if(k=="aimove1_arrow")return 512.0;if(k=="aimove1_star")return 1024.0;if(k=="aimove1_bomb")return 2048.0;if(k=="aimove1_nomove")return 4096.0;if(k=="aimove2_ignoreholes")return 65536.0;if(k=="aimove2_notargetidle")return 131072.0;
  if(k=="block_state_active")return 1.0;if(k=="block_state_native")return 2.0;if(k=="block_state_ignore_chance")return 4.0;if(k=="block_state_ignore_guard_points")return 8.0;if(k=="block_state_ignore_direction")return 16.0;if(k=="block_state_ignore_attack_eligibility")return 32.0;if(k=="block_state_ignore_blockpain")return 64.0;
  static const std::unordered_map<std::string,std::string> props={
    {"entity_property_hp","health"},{"entity_property_health","health"},{"entity_property_hp_max","maxhealth"},{"entity_property_max_health","maxhealth"},
    {"entity_property_position_x","x"},{"entity_property_position_z","z"},{"entity_property_position_y","altitude"},{"entity_property_altitude","altitude"},
    {"entity_property_direction","direction"},{"entity_property_animation","animation"},{"entity_property_animation_frame","animpos"},
    {"entity_property_velocity_x","xdir"},{"entity_property_velocity_z","zdir"},{"entity_property_velocity_y","tossv"},
    {"entity_property_color_map","colourmap"},{"entity_property_colourmap","colourmap"},{"entity_property_modeldata","modelptr"},{"entity_property_model","modelptr"},
    {"entity_property_block_state","blockstate"},{"entity_property_guard_points","guardpoints"},{"entity_property_exists","exists"},{"entity_property_dead","dead"},
    {"model_property_name","name"},{"model_property_type","type"},{"model_property_subtype","subtype"},{"model_property_hp","health"},{"model_property_health","health"},
    {"model_property_speed","speed"},{"model_property_run_speed","runspeed"},{"model_property_grab_distance","grabdistance"},{"model_property_juggle_points","jugglepoints"},
    {"model_property_block_odds","blockodds"},{"model_property_block_pain","blockpain"},{"model_property_block_threshold","blockthreshold"},{"model_property_guard_points","guardpoints"},{"model_property_guard_rate","guardrate"},
    {"model_property_aggression","aggression"},{"model_property_ai_attack","aiattack"},{"model_property_ai_move","aimove"},{"model_property_candamage","candamage"},{"model_property_hostile","hostile"},{"model_property_projectilehit","projectilehit"},
    {"model_property_nograb","nograb"},{"model_property_grab_force","grabforce"},{"model_property_grab_resistance","grabresistance"},{"model_property_throw_damage","throwdamage"},{"model_property_bounce","bounce"},{"model_property_subject_to_gravity","subject_to_gravity"},
    {"level_property_name","name"},{"level_property_width","width"},{"level_property_height","height"},{"level_property_z_min","zmin"},{"level_property_z_max","zmax"},
    {"level_property_camera_x","camerax"},{"level_property_scroll_speed","scrollspeed"},{"level_property_direction","direction"},{"level_property_branch","branch"}
  };
  auto it=props.find(k);if(it!=props.end())return it->second;
  if(k=="plane_x")return 0.0;if(k=="plane_y")return 1.0;if(k=="plane_z")return 2.0;
  if(k=="blend_none")return 0.0;if(k=="blend_alpha")return 1.0;if(k=="blend_add")return 2.0;if(k=="blend_multiply")return 3.0;
  return 0.0;
}
static bool terrainContains(const generated::Geometry& g,float x,float z){
  if(!g.openborShape)return x>=g.x&&x<=g.x+g.w&&z>=g.z&&z<=g.z+g.h;
  const auto*p=g.shape;float depth=p[6];if(depth<=0||z>p[1]||z<p[1]-depth)return false;
  float left=p[0]+p[3]+(p[1]-z)*((p[2]-p[3])/depth),right=p[0]+p[5]+(p[1]-z)*((p[4]-p[5])/depth);return x>=left&&x<=right;
}
Engine::BindActor Engine::bindActor(std::uintptr_t h){
  if(h==1&&playerAlive_&&playerModel_)return {&playerWorldX_,&playerZ_,&playerAltitude_,&playerFacing_,&player_,&lastFrame_,playerModel_};
  if(h>=2&&h<=4){auto i=(std::size_t)(h-2);if(i<coopPlayers_.size()){auto&c=coopPlayers_[i];if(c.alive&&c.model)return {&c.worldX,&c.z,&c.altitude,&c.facing,&c.animation,&c.lastFrame,c.model};}return {};}
  for(auto&e:entities_)if((std::uintptr_t)&e==h&&e.visible&&e.model)return {&e.worldX,&e.z,&e.altitude,&e.facing,&e.animation,&e.lastFrame,e.model};return {};
}
int Engine::bindingSortId(std::uintptr_t h)const{
  auto i=entityBindings_.find(h);if(i!=entityBindings_.end())return bindingSortId(i->second.target)+i->second.sort;
  if(h>=1&&h<=4)return(int)h*100;int id=500;for(const auto&e:entities_){if((std::uintptr_t)&e==h)return id;id+=100;}return 0;
}
void Engine::applyEntityBindings(){
  std::unordered_map<std::uintptr_t,int> state;
  auto apply=[&](auto&&again,std::uintptr_t h)->void{
    if(state[h]==2)return;if(state[h]==1){entityBindings_.erase(h);return;}state[h]=1;
    auto i=entityBindings_.find(h);if(i==entityBindings_.end()){state[h]=2;return;}auto b=i->second;
    if(entityBindings_.contains(b.target))again(again,b.target);
    if(!entityBindings_.contains(h)){state[h]=2;return;}
    auto actor=bindActor(h),target=bindActor(b.target);
    if(!actor.x||!target.x){entityBindings_.erase(h);state[h]=2;return;}
    auto ta=target.animation->animation();
    if(b.config&1){auto animation=ta?exactAnimation(actor.model,ta->name):nullptr;
      if(!animation){if(b.config&4){std::vector<std::string> u;ScriptContext c;callScriptFunction("killentity",{h},c,u);}entityBindings_.erase(h);state[h]=2;return;}
      if(animation!=actor.animation->animation()){actor.animation->setAnimation(animation);*actor.lastFrame=(std::size_t)-1;}
    }
    if(b.config&2){auto frame=target.animation->frameIndex();auto animation=actor.animation->animation();
      if(!animation||frame>=animation->frameCount){if(b.config&8){std::vector<std::string> u;ScriptContext c;callScriptFunction("killentity",{h},c,u);entityBindings_.erase(h);state[h]=2;return;}}
      else if(frame!=actor.animation->frameIndex()){actor.animation->setFrame(frame);*actor.lastFrame=(std::size_t)-1;}
    }
    int direction=*actor.face;
    if(b.direction==1)direction=*target.face;else if(b.direction==-1)direction=-*target.face;else if(b.direction==2)direction=1;else if(b.direction==-2)direction=-1;
    else if((b.direction==3||b.direction==4)&&*actor.x!=*target.x){direction=*actor.x<*target.x?1:-1;if(b.direction==4)direction=-direction;}
    *actor.face=direction;
    if(b.config&128)*actor.x=*target.x+(float)b.x*(float)*target.face;else if(b.config&64)*actor.x=(float)b.x;
    if(b.config&512)*actor.alt=*target.alt-(float)b.a;else if(b.config&256)*actor.alt=-(float)b.a;
    if(b.config&2048)*actor.z=*target.z+(float)b.z;else if(b.config&1024)*actor.z=(float)b.z;
    state[h]=2;
  };
  std::vector<std::uintptr_t> handles;for(const auto&[h,b]:entityBindings_)handles.push_back(h);for(auto h:handles)apply(apply,h);
}
ScriptValue Engine::callScriptFunction(const std::string& raw,const std::vector<ScriptValue>& a,ScriptContext& ctx,std::vector<std::string>& unsupported){
  auto name=lowerString(raw);
  // Common OpenBORScript math helpers. Legacy scripts commonly pass angles in
  // radians, matching the C math functions used by OpenBOR helper libraries.
  if(name=="sin") return a.empty()?0.0:std::sin(scriptNumber(a[0]));
  if(name=="cos") return a.empty()?0.0:std::cos(scriptNumber(a[0]));
  if(name=="sqrt") return a.empty()?0.0:std::sqrt(std::max(0.0,scriptNumber(a[0])));
  if(name=="atan") return a.empty()?0.0:std::atan(scriptNumber(a[0]));
  if(name=="atan2") return a.size()<2?0.0:std::atan2(scriptNumber(a[0]),scriptNumber(a[1]));
  if(name=="pow") return a.size()<2?0.0:std::pow(scriptNumber(a[0]),scriptNumber(a[1]));
  if(name=="abs") return a.empty()?0.0:std::fabs(scriptNumber(a[0]));
  if(name=="floor") return a.empty()?0.0:std::floor(scriptNumber(a[0]));
  if(name=="ceil") return a.empty()?0.0:std::ceil(scriptNumber(a[0]));
  if(name=="checkhole"||name=="checkholeindex"||name=="checkwall"||name=="checkwallindex"){
    const bool hole=name=="checkhole"||name=="checkholeindex",index=name=="checkholeindex"||name=="checkwallindex";
    if(a.size()<2){unsupported.push_back(name+"-arguments");return index?-1.0:0.0;}
    if(!stage_)return index?-1.0:0.0;
    float x=(float)scriptNumber(a[0]),z=(float)scriptNumber(a[1]),alt=a.size()>2?(float)scriptNumber(a[2]):9999999.0f;
    int wi=0,hi=0,wall=-1,holeId=-1;float wallHeight=0,holeHeight=-1;bool covers=false;
    for(std::size_t i=0;i<stage_->geometryCount;++i){const auto&g=stage_->geometry[i];auto kind=lowerString(g.kind?g.kind:"");if(kind!="wall"&&kind!="hole")continue;
      int ownIndex=kind=="wall"?wi++:hi++;if(!terrainContains(g,x,z))continue;
      if(!g.openborShape&&std::find(unsupported.begin(),unsupported.end(),"terrain-legacy-rectangle")==unsupported.end())unsupported.push_back("terrain-legacy-rectangle");
      float height=g.openborShape?g.shape[7]:(float)g.altitude;
      if(kind=="wall"){covers=true;if(height<=alt&&height>wallHeight){wall=ownIndex;wallHeight=height;}}
      else if(a.size()<3){if(holeId<0)holeId=ownIndex;}
      else if(height+2.0f>=alt&&height>holeHeight){holeId=ownIndex;holeHeight=height;}
    }
    if(hole)return covers?(index?-1.0:0.0):(index?(double)holeId:(holeId>=0?1.0:0.0));
    return index?(double)wall:(double)wallHeight;
  }

  if(name=="bindentity"){
    if(a.size()<2){unsupported.push_back("bindentity-arguments");return {};}
    auto actor=scriptPointer(a[0]),target=scriptPointer(a[1]);if(!actor)return {};
    if(!bindActor(actor).x){unsupported.push_back("bindentity-invalid-actor");return {};}
    auto old=entityBindings_.find(actor);EntityBinding b=old==entityBindings_.end()?EntityBinding{}:old->second;
    entityBindings_.erase(actor);if(!target)return {};
    if(!bindActor(target).x){unsupported.push_back("bindentity-invalid-target");return {};}
    auto next=target;std::unordered_map<std::uintptr_t,bool> seen;
    while(next){if(next==actor||seen.contains(next)){unsupported.push_back("bindentity-cycle");return {};}seen[next]=true;auto i=entityBindings_.find(next);if(i==entityBindings_.end())break;next=i->second.target;}
    b.target=target;b.config=0;b.sort=-1;
    auto numeric=[&](std::size_t i){return i<a.size()&&(std::holds_alternative<double>(a[i])||std::holds_alternative<bool>(a[i]));};
    if(numeric(2)){b.x=(int)scriptNumber(a[2]);b.config|=128;}if(numeric(3)){b.z=(int)scriptNumber(a[3]);b.config|=2048;}if(numeric(4)){b.a=(int)scriptNumber(a[4]);b.config|=512;}
    if(numeric(5))b.direction=(int)scriptNumber(a[5]);if(numeric(6))b.config+=(int)scriptNumber(a[6]);if(numeric(7))b.sort=(int)scriptNumber(a[7]);
    constexpr int supported=15|64|128|256|512|1024|2048;
    if((b.config&~supported)!=0)unsupported.push_back("bindentity-config:"+std::to_string(b.config&~supported));
    entityBindings_[actor]=b;applyEntityBindings();return {};
  }
  auto normalizeHandle=[&](std::uintptr_t p)->std::uintptr_t{if(p==0&&ctx.entity)return (std::uintptr_t)ctx.entity;if(p==0&&ctx.player)return (std::uintptr_t)(ctx.playerIndex+1);return p;};
  auto entityFromHandle=[&](std::uintptr_t p)->RuntimeEntity*{p=normalizeHandle(p);if(p<=4)return nullptr;for(auto& e:entities_)if((std::uintptr_t)&e==p)return &e;return nullptr;};
  auto playerSlot=[&](std::uintptr_t p)->int{p=normalizeHandle(p);return p>=1&&p<=4?(int)p-1:-1;};
  auto modelForPlayer=[&](int slot)->const generated::Character*{if(slot==0)return playerModel_;std::size_t i=(std::size_t)(slot-1);return i<coopPlayers_.size()?coopPlayers_[i].model:nullptr;};
  auto playerAliveFor=[&](int slot)->bool{if(slot==0)return playerAlive_;std::size_t i=(std::size_t)(slot-1);return i<coopPlayers_.size()&&coopPlayers_[i].alive;};
  auto playerX=[&](int slot)->float{if(slot==0)return playerWorldX_;std::size_t i=(std::size_t)(slot-1);return i<coopPlayers_.size()?coopPlayers_[i].worldX:0.0f;};
  auto playerZ=[&](int slot)->float{if(slot==0)return playerZ_;std::size_t i=(std::size_t)(slot-1);return i<coopPlayers_.size()?coopPlayers_[i].z:0.0f;};
  auto playerAlt=[&](int slot)->float{if(slot==0)return -playerAltitude_;std::size_t i=(std::size_t)(slot-1);return i<coopPlayers_.size()?-coopPlayers_[i].altitude:0.0f;};
  auto playerFace=[&](int slot)->int{if(slot==0)return playerFacing_;std::size_t i=(std::size_t)(slot-1);return i<coopPlayers_.size()?coopPlayers_[i].facing:1;};
  auto getAnimName=[&](std::uintptr_t p)->std::string{int slot=playerSlot(p);if(slot==0)return player_.animation()&&player_.animation()->name?player_.animation()->name:"";if(slot>0){std::size_t i=(std::size_t)(slot-1);return i<coopPlayers_.size()&&coopPlayers_[i].animation.animation()&&coopPlayers_[i].animation.animation()->name?coopPlayers_[i].animation.animation()->name:"";}auto*e=entityFromHandle(p);return e&&e->animation.animation()&&e->animation.animation()->name?e->animation.animation()->name:"";};
  auto setAnim=[&](std::uintptr_t p,const std::string& an)->bool{int slot=playerSlot(p);if(slot==0){auto q=findAnimation(playerModel_,an.c_str());if(!q)return false;player_.setAnimation(q);lastFrame_=(std::size_t)-1;return true;}if(slot>0){std::size_t i=(std::size_t)(slot-1);if(i>=coopPlayers_.size())return false;auto q=findAnimation(coopPlayers_[i].model,an.c_str());if(!q)return false;coopPlayers_[i].animation.setAnimation(q);coopPlayers_[i].lastFrame=(std::size_t)-1;return true;}auto*e=entityFromHandle(p);if(!e)return false;auto q=findAnimation(e->model,an.c_str());if(!q)return false;setEntityAnimation(*e,q);return true;};
  auto entityVarMap=[&](std::uintptr_t p)->std::unordered_map<std::string,ScriptValue>*{int slot=playerSlot(p);if(slot>=0&&slot<4)return &playerScriptVars_[slot];auto*e=entityFromHandle(p);return e?&e->scriptVars:nullptr;};
  auto modelFromValue=[&](const ScriptValue& v)->const generated::Character*{
    if(auto sp=std::get_if<std::string>(&v))return findCharacter(sp->c_str());
    auto p=scriptPointer(v);for(std::size_t i=0;i<generated::kCharacterCount;++i)if((std::uintptr_t)&generated::kCharacters[i]==p)return &generated::kCharacters[i];
    int slot=playerSlot(p);if(slot>=0)return modelForPlayer(slot);if(auto*e=entityFromHandle(p))return e->model;return nullptr;
  };

  if(name=="strlength"){return a.empty()?0.0:(double)scriptString(a[0]).size();}
  if(name=="getscriptvar"){
    if(a.empty())return {};auto key=std::string("__scriptvar_")+std::to_string((long long)scriptNumber(a[0]));auto it=ctx.local.find(key);return it==ctx.local.end()?ScriptValue{}:it->second;
  }
  if(name=="setscriptvar"){
    if(a.size()<2)return false;auto key=std::string("__scriptvar_")+std::to_string((long long)scriptNumber(a[0]));ctx.local[key]=a[1];return true;
  }
  if(name=="openfilestream"){
    if(a.empty())return std::uintptr_t(0);auto rel=normalizeDataPath(scriptString(a[0]));auto path=(root_/"assets"/"openbor-data"/rel).lexically_normal();auto dataRoot=(root_/"assets"/"openbor-data").lexically_normal();auto ps=PathEncoding::utf8(path),ds=PathEncoding::utf8(dataRoot);if(ps.rfind(ds,0)!=0)return std::uintptr_t(0);std::ifstream in(path);if(!in)return std::uintptr_t(0);ScriptFileStream fs;std::string line;
    while(std::getline(in,line)){std::vector<std::string> tok;std::string cur;char quote=0;for(std::size_t i=0;i<line.size();++i){char c=line[i];if(quote){if(c=='\\'&&i+1<line.size()){cur+=line[++i];continue;}if(c==quote){quote=0;continue;}cur+=c;continue;}if(c=='"'||c=='\''){quote=c;continue;}if(std::isspace((unsigned char)c)){if(!cur.empty()){tok.push_back(cur);cur.clear();}}else cur+=c;}if(!cur.empty())tok.push_back(cur);fs.lines.push_back(std::move(tok));}
    auto h=nextScriptFileHandle_++;scriptFiles_[h]=std::move(fs);return std::uintptr_t(h);
  }
  if(name=="getfilestreamargument"){
    if(a.size()<2)return {};auto h=scriptPointer(a[0]);auto it=scriptFiles_.find(h);if(it==scriptFiles_.end()||it->second.line>=it->second.lines.size())return {};auto idx=(std::size_t)std::max(0.0,scriptNumber(a[1]));auto& line=it->second.lines[it->second.line];if(idx>=line.size())return {};auto value=line[idx];auto type=a.size()>2?lowerString(scriptString(a[2])):std::string("string");if(type=="int"||type=="integer"){try{return(double)std::stoll(value,nullptr,0);}catch(...){return 0.0;}}if(type=="float"||type=="decimal"){try{return std::stod(value);}catch(...){return 0.0;}}return value;
  }
  if(name=="filestreamnextline"){
    if(a.empty())return false;auto h=scriptPointer(a[0]);auto it=scriptFiles_.find(h);if(it==scriptFiles_.end())return false;if(it->second.line<it->second.lines.size())++it->second.line;return it->second.line<it->second.lines.size();
  }
  if(name=="closefilestream"){
    if(a.empty())return false;return scriptFiles_.erase(scriptPointer(a[0]))>0;
  }
  if(name=="allocscreen") return std::uintptr_t(nextScriptScreenHandle_++);
  if(name=="clearscreen"){scriptDrawQueue_.clear();return true;}
  if(name=="drawspritetoscreen"&&a.size()>=4){ScriptDrawCommand c;c.kind=ScriptDrawCommand::Kind::Sprite;c.sprite=scriptPointer(a[0]);c.x=(int)scriptNumber(a[2]);c.y=(int)scriptNumber(a[3]);c.z=a.size()>4?(int)scriptNumber(a[4]):999999;scriptDrawQueue_.push_back(std::move(c));return true;}
  if(name=="drawboxtoscreen"&&a.size()>=6){ScriptDrawCommand c;c.kind=ScriptDrawCommand::Kind::Box;c.x=(int)scriptNumber(a[1]);c.y=(int)scriptNumber(a[2]);c.w=(int)scriptNumber(a[3]);c.h=(int)scriptNumber(a[4]);c.color=(unsigned int)scriptNumber(a[5]);c.z=a.size()>6?(int)scriptNumber(a[6]):999999;scriptDrawQueue_.push_back(std::move(c));return true;}
  if(name=="drawstringtoscreen"&&a.size()>=5){ScriptDrawCommand c;c.kind=ScriptDrawCommand::Kind::Text;c.x=(int)scriptNumber(a[1]);c.y=(int)scriptNumber(a[2]);c.font=(int)scriptNumber(a[3]);c.text=scriptString(a[4]);c.z=a.size()>5?(int)scriptNumber(a[5]):999999;scriptDrawQueue_.push_back(std::move(c));return true;}
  if(name=="drawscreen") return true;
  if(name=="drawspriteq"||name=="clearspriteq"||name=="changedrawmethod") return true;
  if(name=="aichecklie"||name=="aicheckgrabbed"||name=="aicheckgrab"||name=="aicheckescape"||name=="aicheckbusy"||name=="aicheckattack"||name=="aicheckmove") return 0.0;
  if(name=="fademusic"){audio_.stopMusic();return true;}
  if(name=="playsound"){
    if(a.empty())return false;if(auto p=std::get_if<std::string>(&a[0])){auto path=resolveAudioAsset(root_/"assets"/"openbor-data",*p);return std::filesystem::exists(path)&&audio_.playEffect(path);}auto id=(long long)scriptNumber(a[0]);if(id>=0&&(std::size_t)id<scriptSamples_.size()&&!scriptSamples_[(std::size_t)id].empty())return audio_.playEffect(scriptSamples_[(std::size_t)id]);return false;
  }

  if(name=="projectile"){
    // Legacy projectile([relative], model, x, z, a, direction, pytype, type, map).
    // Final Fight X uses the absolute 8-argument form from shoot()/toss().
    std::size_t base=0;bool relative=false;if(a.size()==9){relative=scriptNumber(a[0])!=0;base=1;}else if(a.size()!=8){unsupported.push_back("projectile-arguments");return std::uintptr_t(0);}
    auto* model=modelFromValue(a[base]);if(!model){unsupported.push_back("projectile-model");return std::uintptr_t(0);}
    float x=(float)scriptNumber(a[base+1]),z=(float)scriptNumber(a[base+2]),openborA=(float)scriptNumber(a[base+3]);int direction=(int)scriptNumber(a[base+4]);int pytype=(int)scriptNumber(a[base+5]);int type=(int)scriptNumber(a[base+6]);
    int facing=direction==0?-1:1;bool fromPlayer=ctx.player;const generated::Character* ownerModel=nullptr;float ox=0.0f,oz=0.0f,oa=0.0f;if(ctx.player){int slot=std::clamp(ctx.playerIndex,0,3);ox=playerX(slot);oz=playerZ(slot);oa=playerAlt(slot);ownerModel=modelForPlayer(slot);fromPlayer=true;}else if(ctx.entity){auto* self=(RuntimeEntity*)ctx.entity;ox=self->worldX;oz=self->z;oa=-self->altitude;ownerModel=self->model;auto st=lowerString(self->model&&self->model->type?self->model->type:"");fromPlayer=st=="player"||st=="npc";}
    if(relative){x=ox+x*(float)facing;z=oz+z;openborA=oa+openborA;}
    bool bomb=type==1;float vx=pytype?0.0f:std::max(0.0f,model->speed);if(!bomb&&vx<0.01f)vx=2.0f;float vy=(bomb&&!pytype)?(float)std::max(1,model->jumpHeight):0.0f;
    spawnProjectile(model,x,z,-openborA,facing,vx,vy,0.0f,bomb,fromPlayer,ownerModel);return std::uintptr_t(1);
  }

  if(name=="openborconstant") return a.empty()?ScriptValue(0.0):openborConstantValue(scriptString(a[0]));
  if(name=="openborvariant") {
    auto k=a.empty()?std::string{}:lowerString(scriptString(a[0]));
    if(k=="xpos"||k=="levelpos")return (double)cameraX_;if(k=="elapsed_time"||k=="elapsedtime")return (double)tickCounter_;
    if(k=="count_players")return (double)(1+coopPlayers_.size());if(k=="maxplayers"||k=="max_players")return (double)config_.maxPlayers;
    if(k=="count_entities"||k=="ent_count"){int n=0;for(const auto&e:entities_)if(e.visible)++n;return(double)n;}if(k=="count_enemies"){int n=0;for(const auto&e:entities_)if(e.alive&&e.model&&lowerString(e.model->type)=="enemy")++n;return(double)n;}
    if(k=="current_player")return (double)ctx.playerIndex;if(k=="current_level"||k=="currentlevel")return (double)stageIndex_;if(k=="current_branch"||k=="currentbranch")return stage_&&stage_->branchName?std::string(stage_->branchName):std::string{};
    if(k=="hresolution")return (double)config_.logicalWidth;if(k=="vresolution")return (double)config_.logicalHeight;if(k=="levelwidth")return(double)stageLength_;if(k=="levelheight")return stage_?(double)(stage_->zMax-stage_->zMin):0.0;
    if(k=="effectvol")return 100.0; // User effect gain is applied once by AudioSystem.
    if(k=="in_level"||k=="inlevel")return stage_!=nullptr&&frontendState_==FrontendState::Playing;if(k=="game_speed"||k=="gamespeed")return 60.0;
    return 0.0;
  }
  if(name=="changeopenborvariant"||name=="setopenborvariant") {if(a.size()>1){auto k=lowerString(scriptString(a[0]));if(k=="xpos"||k=="levelpos")cameraX_=std::clamp((float)scriptNumber(a[1]),0.0f,std::max(0.0f,stageLength_-(float)config_.logicalWidth));}return a.size()>1?a[1]:ScriptValue{};}
  if(name=="jumptobranch"){if(a.empty())return false;auto wanted=lowerString(scriptString(a[0]));std::size_t targetIndex=(std::size_t)-1;for(std::size_t i=0;i<generated::kStageCount;++i){auto label=generated::kStages[i].branchName?lowerString(generated::kStages[i].branchName):std::string{};if(!label.empty()&&label==wanted){targetIndex=i;break;}}if(targetIndex==(std::size_t)-1){if(std::find(unsupported.begin(),unsupported.end(),"jumptobranch-missing:"+wanted)==unsupported.end())unsupported.push_back("jumptobranch-missing:"+wanted);return false;}pendingBranchTarget_=targetIndex;pendingBranchImmediate_=a.size()>1&&scriptNumber(a[1])!=0;if(pendingBranchImmediate_){stageComplete_=true;}return true;}

  if(name=="getentity"||name=="get_entity"){if(a.empty())return std::uintptr_t(0);long long idx=(long long)scriptNumber(a[0]);if(idx<0||(std::size_t)idx>=entities_.size())return std::uintptr_t(0);auto it=entities_.begin();std::advance(it,idx);return std::uintptr_t((std::uintptr_t)&*it);}
  if(name=="findtarget"||name=="find_target"){
    std::uintptr_t self=a.empty()?normalizeHandle(0):normalizeHandle(scriptPointer(a[0]));int slot=playerSlot(self);float sx=0,sz=0;const generated::Character* selfModel=nullptr;if(slot>=0){sx=playerX(slot);sz=playerZ(slot);selfModel=modelForPlayer(slot);RuntimeEntity*best=nullptr;float bd=1e30f;for(auto&e:entities_){if(!e.alive||!e.visible||!e.model)continue;auto t=lowerString(e.model->type?e.model->type:"");bool legacy=(t=="enemy"||t=="obstacle");if(!modelIsHostileTo(selfModel,e.model,legacy)||!modelCanPerceive(selfModel,e.model))continue;float d=std::fabs(e.worldX-sx)+std::fabs(e.z-sz);if(d<bd){bd=d;best=&e;}}return best?ScriptValue(std::uintptr_t((std::uintptr_t)best)):ScriptValue(std::uintptr_t(0));}
    auto* selfEnt=entityFromHandle(self);if(!selfEnt||!selfEnt->model)return std::uintptr_t(0);selfModel=selfEnt->model;sx=selfEnt->worldX;sz=selfEnt->z;std::uintptr_t bestHandle=0;float bd=1e30f;for(int ps=0;ps<4;++ps){if(!playerAliveFor(ps))continue;auto*pm=modelForPlayer(ps);if(!modelIsHostileTo(selfModel,pm,true)||!modelCanPerceive(selfModel,pm))continue;float d=std::fabs(playerX(ps)-sx)+std::fabs(playerZ(ps)-sz);if(d<bd){bd=d;bestHandle=std::uintptr_t(ps+1);}}for(auto&other:entities_){if(&other==selfEnt||!other.alive||!other.visible||!other.model)continue;if(!modelIsHostileTo(selfModel,other.model,false)||!modelCanPerceive(selfModel,other.model))continue;float d=std::fabs(other.worldX-sx)+std::fabs(other.z-sz);if(d<bd){bd=d;bestHandle=std::uintptr_t((std::uintptr_t)&other);}}return bestHandle?ScriptValue(bestHandle):ScriptValue(std::uintptr_t(0));
  }
  if(name=="checkrange"||name=="check_range"){
    if(a.size()<2)return false;auto p1=normalizeHandle(scriptPointer(a[0])),p2=normalizeHandle(scriptPointer(a[1]));auto pos=[&](std::uintptr_t p,float&x,float&z)->bool{int sl=playerSlot(p);if(sl>=0){if(!playerAliveFor(sl))return false;x=playerX(sl);z=playerZ(sl);return true;}auto*e=entityFromHandle(p);if(!e||!e->alive)return false;x=e->worldX;z=e->z;return true;};float x1,z1,x2,z2;if(!pos(p1,x1,z1)||!pos(p2,x2,z2))return false;float range=(float)config_.enemyAttackRange;if(auto*e=entityFromHandle(p1);e&&e->model)range=(float)std::max(e->model->grabDistance,config_.enemyAttackRange);return std::fabs(x1-x2)<=range&&std::fabs(z1-z2)<=24.0f;
  }

  if(name=="getentityproperty"||name=="get_entity_property") {
    if(a.size()<2)return {};auto p=normalizeHandle(scriptPointer(a[0]));auto k=lowerString(scriptString(a[1]));int slot=playerSlot(p);
    if(slot>=0){auto*m=modelForPlayer(slot);if(!m)return {};if(k=="grabforce")return(double)m->grabForce;if(k=="grabresistance")return(double)m->grabResistance;if(k=="antigravity")return(double)actorAntigravity(p,m);if(k=="x")return(double)playerX(slot);if(k=="z")return(double)playerZ(slot);if(k=="a"||k=="altitude")return(double)playerAlt(slot);if(k=="health")return slot==0?(double)playerHealth_:(double)coopPlayers_[(std::size_t)(slot-1)].health;if(k=="maxhealth")return slot==0?(double)playerMaxHealth_:(double)coopPlayers_[(std::size_t)(slot-1)].maxHealth;if(k=="direction")return(double)(playerFace(slot)<0?0:1);if(k=="name"||k=="model")return std::string(m->name);if(k=="modelptr")return std::uintptr_t((std::uintptr_t)m);if(k=="blockstate")return slot==0?(double)playerBlockState_:(double)coopPlayers_[(std::size_t)(slot-1)].blockState;if(k=="guardpoints")return slot==0?(double)playerGuardPoints_:(double)coopPlayers_[(std::size_t)(slot-1)].guardPoints;if(k=="type")return std::string(m->type);if(k=="subtype")return std::string(m->subtype);if(k=="aggression")return(double)m->aggression;if(k=="stealth")return(double)m->stealth;if(k=="perception")return(double)m->perception;if(k=="aiattack")return(double)m->aiAttack;if(k=="aimove")return(double)m->aiMove;if(k=="candamage")return(double)m->canDamageMask;if(k=="hostile")return(double)m->hostileMask;if(k=="projectilehit")return(double)m->projectileHitMask;if(k=="playerindex")return(double)slot;if(k=="speed")return(double)m->speed;if(k=="animpos"||k=="animationposition")return slot==0?(double)player_.frameIndex():(double)coopPlayers_[(std::size_t)(slot-1)].animation.frameIndex();if(k=="animating")return slot==0?(player_.finished()?0.0:1.0):(coopPlayers_[(std::size_t)(slot-1)].animation.finished()?0.0:1.0);if(k=="xdir")return slot==0?(double)playerScriptVelocityX_:(double)coopPlayers_[(std::size_t)(slot-1)].scriptVelocityX;if(k=="zdir")return slot==0?(double)playerScriptVelocityZ_:(double)coopPlayers_[(std::size_t)(slot-1)].scriptVelocityZ;if(k=="tossv"||k=="velocityy")return slot==0?-(double)playerVerticalVelocity_:-(double)coopPlayers_[(std::size_t)(slot-1)].verticalVelocity;if(k=="attacking")return slot==0?playerAttackTicks_>0:coopPlayers_[(std::size_t)(slot-1)].attackTicks>0;if(k=="animationid"||k=="animation")return getAnimName(p);if(k=="exists")return playerAliveFor(slot);if(k=="dead")return !playerAliveFor(slot);if(k=="colourmap"||k=="colormap"||k=="map")return slot==0?(double)playerPaletteMap_:(double)coopPlayers_[(std::size_t)(slot-1)].paletteMap;if(k=="aiflag"&&a.size()>2){auto f=lowerString(scriptString(a[2]));if(f=="drop"||f=="falling")return slot==0?(playerFallTicks_>0||playerAltitude_<0):(coopPlayers_[(std::size_t)(slot-1)].altitude<0);return false;}return {};}
    auto*e=entityFromHandle(p);if(!e)return {};if(k=="grabforce")return e->model?(double)e->model->grabForce:0.0;if(k=="grabresistance")return e->model?(double)e->model->grabResistance:0.0;if(k=="antigravity")return(double)actorAntigravity(p,e->model);if(k=="x")return(double)e->worldX;if(k=="z")return(double)e->z;if(k=="a"||k=="altitude")return(double)(-e->altitude);if(k=="health")return(double)e->health;if(k=="maxhealth")return(double)e->maxHealth;if(k=="direction")return(double)(e->facing<0?0:1);if(k=="name"||k=="model")return e->model?std::string(e->model->name):std::string{};if(k=="modelptr")return e->model?ScriptValue(std::uintptr_t((std::uintptr_t)e->model)):ScriptValue(std::uintptr_t(0));if(k=="blockstate")return(double)e->blockState;if(k=="guardpoints")return(double)e->guardPoints;if(k=="type")return e->model?std::string(e->model->type):std::string{};if(k=="subtype")return e->model?std::string(e->model->subtype):std::string{};if(k=="aggression")return e->model?(double)e->model->aggression:0.0;if(k=="stealth")return e->model?(double)e->model->stealth:0.0;if(k=="perception")return e->model?(double)e->model->perception:0.0;if(k=="aiattack")return e->model?(double)e->model->aiAttack:0.0;if(k=="aimove")return e->model?(double)e->model->aiMove:0.0;if(k=="candamage")return e->model?(double)e->model->canDamageMask:0.0;if(k=="hostile")return e->model?(double)e->model->hostileMask:0.0;if(k=="projectilehit")return e->model?(double)e->model->projectileHitMask:0.0;if(k=="speed")return e->model?(double)e->model->speed:0.0;if(k=="animpos"||k=="animationposition")return(double)e->animation.frameIndex();if(k=="animating")return e->animation.finished()?0.0:1.0;if(k=="xdir")return(double)e->scriptVelocityX;if(k=="zdir")return(double)e->scriptVelocityZ;if(k=="tossv"||k=="velocityy")return-(double)e->verticalVelocity;if(k=="attacking")return e->attackTicks>0;if(k=="animationid"||k=="animation")return getAnimName(p);if(k=="exists")return e->visible;if(k=="dead")return !e->alive;if(k=="colourmap"||k=="colormap"||k=="map")return(double)e->paletteMap;if(k=="subject_to_screen")return e->subjectToScreen;if(k=="aiflag"&&a.size()>2){auto f=lowerString(scriptString(a[2]));if(f=="drop")return e->fallTicks>0||e->altitude<0;if(f=="falling")return e->altitude<0&&e->verticalVelocity>0;if(f=="attacking")return e->attackTicks>0;return false;}return {};
  }
  if(name=="changeentityproperty"||name=="change_entity_property"||name=="setentityproperty") {
    if(a.size()<3)return {};auto p=normalizeHandle(scriptPointer(a[0]));auto k=lowerString(scriptString(a[1]));int slot=playerSlot(p);double v=scriptNumber(a[2]);
    if(k=="antigravity"){if(!scriptPointer(a[0])||(slot>=0?!modelForPlayer(slot):!entityFromHandle(p)))return {};if(std::holds_alternative<double>(a[2])||std::holds_alternative<bool>(a[2]))scriptAntigravity_[p]=(float)v;return a[2];}
    if(k=="animation"||k=="animationid")return setAnim(p,scriptString(a[2]));
    if(k=="position"){auto numeric=[&](std::size_t i){return i<a.size()&&(std::holds_alternative<double>(a[i])||std::holds_alternative<bool>(a[i]));};if(slot>=0){if(slot==0){if(numeric(2))playerWorldX_=(float)v;if(numeric(3))playerZ_=(float)scriptNumber(a[3]);if(numeric(4))playerAltitude_=-(float)scriptNumber(a[4]);}else{if((std::size_t)(slot-1)>=coopPlayers_.size())return false;auto&cp=coopPlayers_[(std::size_t)(slot-1)];if(numeric(2))cp.worldX=(float)v;if(numeric(3))cp.z=(float)scriptNumber(a[3]);if(numeric(4))cp.altitude=-(float)scriptNumber(a[4]);}return true;}if(auto*pe=entityFromHandle(p)){if(numeric(2))pe->worldX=(float)v;if(numeric(3))pe->z=(float)scriptNumber(a[3]);if(numeric(4))pe->altitude=-(float)scriptNumber(a[4]);return true;}return false;}
    if(slot>=0){if(k=="x"){if(slot==0)playerWorldX_=(float)v;else coopPlayers_[(std::size_t)(slot-1)].worldX=(float)v;}else if(k=="z"){if(slot==0)playerZ_=(float)v;else coopPlayers_[(std::size_t)(slot-1)].z=(float)v;}else if(k=="a"||k=="altitude"){if(slot==0)playerAltitude_=-(float)v;else coopPlayers_[(std::size_t)(slot-1)].altitude=-(float)v;}else if(k=="health"){if(slot==0)playerHealth_=std::clamp((int)v,0,playerMaxHealth_);else{auto&cp=coopPlayers_[(std::size_t)(slot-1)];cp.health=std::clamp((int)v,0,cp.maxHealth);}}else if(k=="maxhealth"){if(slot==0){playerMaxHealth_=std::max(1,(int)v);playerHealth_=std::min(playerHealth_,playerMaxHealth_);}else{auto&cp=coopPlayers_[(std::size_t)(slot-1)];cp.maxHealth=std::max(1,(int)v);cp.health=std::min(cp.health,cp.maxHealth);}}else if(k=="direction"){int f=v==0?-1:1;if(slot==0)playerFacing_=f;else coopPlayers_[(std::size_t)(slot-1)].facing=f;}else if(k=="colourmap"||k=="colormap"||k=="map"){if(slot==0)playerPaletteMap_=(int)v;else coopPlayers_[(std::size_t)(slot-1)].paletteMap=(int)v;}else if(k=="blockstate"){if(slot==0)playerBlockState_=(int)v;else coopPlayers_[(std::size_t)(slot-1)].blockState=(int)v;}else if(k=="guardpoints"){if(slot==0)playerGuardPoints_=(int)v;else coopPlayers_[(std::size_t)(slot-1)].guardPoints=(int)v;}else if(k=="velocity"){auto numeric=[&](std::size_t i){return i<a.size()&&(std::holds_alternative<double>(a[i])||std::holds_alternative<bool>(a[i]));};if(slot==0){if(numeric(2))playerScriptVelocityX_=(float)v;if(numeric(3))playerScriptVelocityZ_=(float)scriptNumber(a[3]);if(numeric(4))playerVerticalVelocity_=-(float)scriptNumber(a[4]);}else{std::size_t ci=(std::size_t)(slot-1);if(ci>=coopPlayers_.size())return false;auto&cp=coopPlayers_[ci];if(numeric(2))cp.scriptVelocityX=(float)v;if(numeric(3))cp.scriptVelocityZ=(float)scriptNumber(a[3]);if(numeric(4))cp.verticalVelocity=-(float)scriptNumber(a[4]);}}return a[2];}
    auto*e=entityFromHandle(p);if(!e)return {};if(k=="x")e->worldX=(float)v;else if(k=="z")e->z=(float)v;else if(k=="a"||k=="altitude")e->altitude=-(float)v;else if(k=="health")e->health=std::clamp((int)v,0,e->maxHealth);else if(k=="maxhealth"){e->maxHealth=std::max(1,(int)v);e->health=std::min(e->health,e->maxHealth);}else if(k=="direction")e->facing=v==0?-1:1;else if(k=="colourmap"||k=="colormap"||k=="map")e->paletteMap=(int)v;else if(k=="subject_to_screen")e->subjectToScreen=v!=0.0;else if(k=="blockstate")e->blockState=(int)v;else if(k=="guardpoints")e->guardPoints=(int)v;else if(k=="velocity"){auto numeric=[&](std::size_t i){return i<a.size()&&(std::holds_alternative<double>(a[i])||std::holds_alternative<bool>(a[i]));};if(numeric(2))e->scriptVelocityX=(float)v;if(numeric(3))e->scriptVelocityZ=(float)scriptNumber(a[3]);if(numeric(4))e->verticalVelocity=-(float)scriptNumber(a[4]);}return a[2];
  }
  if(name=="getmodelproperty"||name=="get_model_property"){
    if(a.size()<2)return {};auto*m=modelFromValue(a[0]);if(!m)return {};auto k=lowerString(scriptString(a[1]));
    if(k=="name")return std::string(m->name);if(k=="type")return std::string(m->type);if(k=="subtype")return std::string(m->subtype);if(k=="health"||k=="hp")return(double)m->health;if(k=="speed")return(double)m->speed;if(k=="runspeed")return(double)m->runSpeed;if(k=="grabdistance")return(double)m->grabDistance;if(k=="jugglepoints")return(double)m->jugglePoints;if(k=="blockodds")return(double)m->blockOdds;if(k=="blockpain")return(double)m->blockPain;if(k=="blockthreshold")return(double)m->blockThreshold;if(k=="guardpoints")return(double)m->guardPoints;if(k=="guardrate")return(double)m->guardRate;if(k=="aggression")return(double)m->aggression;if(k=="stealth")return(double)m->stealth;if(k=="perception")return(double)m->perception;if(k=="aiattack")return(double)m->aiAttack;if(k=="aimove")return(double)m->aiMove;if(k=="candamage")return(double)m->canDamageMask;if(k=="hostile")return(double)m->hostileMask;if(k=="projectilehit")return(double)m->projectileHitMask;if(k=="nograb")return m->noGrab;if(k=="grabforce")return(double)m->grabForce;if(k=="grabresistance")return(double)m->grabResistance;if(k=="throwdamage")return(double)m->throwDamage;if(k=="throwdist")return(double)m->throwDistance;if(k=="throwheight")return(double)m->throwHeight;if(k=="bounce")return(double)m->bounce;if(k=="bouncefactor")return(double)m->bounceFactor;if(k=="subject_to_gravity")return m->subjectToGravity;return {};
  }
  if(name=="getlevelproperty"||name=="get_level_property"){
    if(a.empty()||!stage_)return {};auto k=lowerString(scriptString(a.size()>1?a[1]:a[0]));if(k=="name"||k=="source")return std::string(stage_->sourceFile?stage_->sourceFile:"");if(k=="width")return(double)stageLength_;if(k=="height")return(double)(stage_->zMax-stage_->zMin);if(k=="zmin")return(double)stage_->zMin;if(k=="zmax")return(double)stage_->zMax;if(k=="camerax")return(double)cameraX_;if(k=="scrollspeed")return(double)stage_->scrollSpeed;if(k=="direction")return std::string(stage_->direction?stage_->direction:"");if(k=="branch")return std::string(stage_->branchName?stage_->branchName:"");return {};
  }
  if(name=="changelevelproperty"||name=="set_level_property"||name=="setlevelproperty"){
    if(a.size()<2||!stage_)return false;auto k=lowerString(scriptString(a.size()>2?a[1]:a[0]));const auto&v=a.size()>2?a[2]:a[1];if(k=="camerax"){cameraX_=std::clamp((float)scriptNumber(v),0.0f,std::max(0.0f,stageLength_-(float)config_.logicalWidth));return v;}return false;
  }

  if(name=="getentityvar"||name=="get_entity_var"){if(a.size()<2)return {};auto*m=entityVarMap(normalizeHandle(scriptPointer(a[0])));if(!m)return {};auto it=m->find(scriptString(a[1]));return it==m->end()?ScriptValue{}:it->second;}
  if(name=="setentityvar"||name=="set_entity_var"){if(a.size()<3)return {};auto*m=entityVarMap(normalizeHandle(scriptPointer(a[0])));if(!m)return {};(*m)[scriptString(a[1])]=a[2];return a[2];}
  if(name=="clearentityvar"||name=="clear_entity_var"){if(a.empty())return false;auto*m=entityVarMap(normalizeHandle(scriptPointer(a[0])));if(!m)return false;if(a.size()>1)m->erase(scriptString(a[1]));else m->clear();return true;}

  if(name=="tossentity"){
    if(a.empty()||scriptPointer(a[0])==0)return false;auto p=normalizeHandle(scriptPointer(a[0]));float lift=a.size()>1?(float)scriptNumber(a[1]):0.0f,vx=a.size()>2?(float)scriptNumber(a[2]):0.0f,vz=a.size()>3?(float)scriptNumber(a[3]):0.0f;int slot=playerSlot(p);
    if(slot==0){if(playerJumping_){playerJumpVelocityX_=vx;playerJumpVelocityZ_=vz;}else{playerScriptVelocityX_=vx;playerScriptVelocityZ_=vz;}if(lift!=0){playerAltitude_-=0.5f;playerVerticalVelocity_=-lift;playerJumping_=true;playerJumpVelocityX_=vx;playerJumpVelocityZ_=vz;playerScriptVelocityX_=playerScriptVelocityZ_=0;}return true;}
    if(slot>0){auto&cp=coopPlayers_[(std::size_t)(slot-1)];cp.scriptVelocityX=vx;cp.scriptVelocityZ=vz;if(lift!=0){cp.altitude-=0.5f;cp.verticalVelocity=-lift;cp.jumping=true;}return true;}
    auto*e=entityFromHandle(p);if(!e)return false;e->scriptVelocityX=vx;e->scriptVelocityZ=vz;if(lift!=0){e->altitude-=0.5f;e->verticalVelocity=-lift;}return true;
  }
  if(name=="setanimation"||name=="changeanimation") {std::uintptr_t p=a.empty()?normalizeHandle(0):normalizeHandle(scriptPointer(a[0]));std::string an=a.size()>1?scriptString(a[1]):"idle";return setAnim(p,an);}
  if(name=="performattack"||name=="perform_attack") {
    std::uintptr_t p=a.empty()?normalizeHandle(0):normalizeHandle(scriptPointer(a[0]));std::string an=a.size()>1?scriptString(a[1]):"attack1";int slot=playerSlot(p);
    if(slot==0){auto*aa=findActionAnimation(playerModel_,equippedWeapon_,an.c_str());if(!beginEnergyAnimation(player_,aa,playerModel_,playerHealth_,playerMp_,playerEnergyPending_))return false;lastFrame_=(std::size_t)-1;}
    else if(slot>0){auto&cp=coopPlayers_[(std::size_t)(slot-1)];auto*aa=findActionAnimation(cp.model,cp.equippedWeapon,an.c_str());if(!beginEnergyAnimation(cp.animation,aa,cp.model,cp.health,cp.mp,cp.energyPending))return false;cp.lastFrame=(std::size_t)-1;}
    else {auto*e=entityFromHandle(p);if(!e)return false;auto*aa=findActionAnimation(e->model,e->equippedWeapon,an.c_str());if(!beginEnergyAnimation(e->animation,aa,e->model,e->health,e->mp,e->energyPending))return false;e->lastFrame=(std::size_t)-1;}
    if(slot==0){auto aa=player_.animation();playerAttackTicks_=animationDuration(aa);playerAttackCooldown_=std::max(2,playerAttackTicks_/3);playerProjectileFired_=false;++playerAttackId_;if(playerModel_&&playerModel_->onDoAttackScript&&*playerModel_->onDoAttackScript){playerScriptCtx_.local["attack"]=an;runModelScript(playerModel_->onDoAttackScript,playerScriptCtx_,"script-player-performattack");}}
    else if(slot>0){auto&cp=coopPlayers_[(std::size_t)(slot-1)];auto aa=cp.animation.animation();cp.attackTicks=animationDuration(aa);cp.attackCooldown=std::max(2,cp.attackTicks/3);cp.attackHasHit=false;++cp.attackId;if(cp.model&&cp.model->onDoAttackScript&&*cp.model->onDoAttackScript){cp.scriptCtx.local["attack"]=an;runModelScript(cp.model->onDoAttackScript,cp.scriptCtx,"script-coop-performattack");}}
    else if(auto*e=entityFromHandle(p)){auto aa=e->animation.animation();e->attackTicks=animationDuration(aa);e->attackCooldown=std::max(2,e->attackTicks/3);e->attackHasHit=false;e->projectileFired=false;if(e->model&&e->model->onDoAttackScript&&*e->model->onDoAttackScript){e->scriptCtx.local["attack"]=an;runModelScript(e->model->onDoAttackScript,e->scriptCtx,"script-entity-performattack");}}
    return true;
  }
  if(name=="setidle") {std::uintptr_t p=a.empty()?normalizeHandle(0):normalizeHandle(scriptPointer(a[0]));std::string an=a.size()>1?scriptString(a[1]):"idle";return setAnim(p,an);}
  if(name=="updateframe") {if(a.size()<2)return false;auto p=normalizeHandle(scriptPointer(a[0]));std::size_t f=(std::size_t)std::max(0.0,scriptNumber(a[1]));int slot=playerSlot(p);if(slot==0){player_.setFrame(f);lastFrame_=(std::size_t)-1;return true;}if(slot>0){auto&cp=coopPlayers_[(std::size_t)(slot-1)];cp.animation.setFrame(f);cp.lastFrame=(std::size_t)-1;return true;}if(auto*e=entityFromHandle(p)){e->animation.setFrame(f);e->lastFrame=(std::size_t)-1;return true;}return false;}

  if(name=="damageentity"||name=="damage_entity") {if(a.empty())return {};auto p=normalizeHandle(scriptPointer(a[0]));int dmg=a.size()>2?(int)scriptNumber(a[2]):(a.size()>1?(int)scriptNumber(a[1]):1);int slot=playerSlot(p);if(slot==0)damagePlayer(dmg,-1,false,-3,0,normalizeHandle(0));else if(slot>0){std::size_t ci=(std::size_t)(slot-1);if(ci>=coopPlayers_.size())return false;damageCoopPlayer(coopPlayers_[ci],dmg,-1,false,-3,0,normalizeHandle(0));}else if(auto*e=entityFromHandle(p))damageEnemy(*e,dmg,-1,false,-3,0,normalizeHandle(0));return true;}
  if(name=="killentity"||name=="kill_entity") {if(a.empty())return {};auto p=scriptPointer(a[0]);if(!p)return 0.0;if(a.size()>1)unsupported.push_back("killentity-trigger");int slot=playerSlot(p);if(slot==0){playerHealth_=0;playerAlive_=false;}else if(slot>0){std::size_t ci=(std::size_t)(slot-1);if(ci>=coopPlayers_.size())return 0.0;auto&cp=coopPlayers_[ci];cp.health=0;cp.alive=false;}else if(auto*e=entityFromHandle(p)){e->health=0;e->alive=false;e->visible=false;}else return 0.0;return 1.0;}
  if(name=="getplayerproperty"||name=="get_player_property") {if(a.size()<2)return {};int slot=std::clamp((int)scriptNumber(a[0]),0,3);auto k=lowerString(scriptString(a[1]));if(k=="entity")return playerAliveFor(slot)?ScriptValue(std::uintptr_t((std::uintptr_t)(slot+1))):ScriptValue(std::uintptr_t(0));if(k=="health")return slot==0?(double)playerHealth_:((std::size_t)(slot-1)<coopPlayers_.size()?(double)coopPlayers_[(std::size_t)(slot-1)].health:0.0);if(k=="maxhealth")return slot==0?(double)playerMaxHealth_:((std::size_t)(slot-1)<coopPlayers_.size()?(double)coopPlayers_[(std::size_t)(slot-1)].maxHealth:0.0);if(k=="name"){auto*m=modelForPlayer(slot);return m?ScriptValue(std::string(m->name)):ScriptValue(std::string{});}if(k=="keys")return(double)playerKeys_[slot];if(k=="newkeys")return(double)playerNewKeys_[slot];if(k=="releasekeys"||k=="releasedkeys")return(double)playerReleasedKeys_[slot];if(k=="playkeys")return(double)playerPlayKeys_[slot];if(k=="disablekeys")return(double)playerDisabledKeys_[slot];return 0.0;}
  if(name=="changeplayerproperty"||name=="change_player_property") {if(a.size()<3)return false;int slot=std::clamp((int)scriptNumber(a[0]),0,3);auto k=lowerString(scriptString(a[1]));if(k=="health"){if(slot==0)playerHealth_=std::clamp((int)scriptNumber(a[2]),0,playerMaxHealth_);else if((std::size_t)(slot-1)<coopPlayers_.size()){auto&cp=coopPlayers_[(std::size_t)(slot-1)];cp.health=std::clamp((int)scriptNumber(a[2]),0,cp.maxHealth);}}else if(k=="playkeys")playerPlayKeys_[slot]=(unsigned)scriptNumber(a[2]);else if(k=="disablekeys")playerDisabledKeys_[slot]=(unsigned)scriptNumber(a[2]);return true;}
  if(name=="playerkeys"||name=="key") {if(a.size()<3)return false;int slot=std::clamp((int)scriptNumber(a[0]),0,3);int state=(int)scriptNumber(a[1]);unsigned mask=state==1?playerNewKeys_[slot]:(state==2?playerReleasedKeys_[slot]:playerKeys_[slot]);for(std::size_t i=2;i<a.size();++i){unsigned bit=scriptKeyBit(scriptString(a[i]));if(bit==0)return false;if(lowerString(scriptString(a[i]))=="anybutton"){if((mask&bit)==0)return false;}else if((mask&bit)!=bit)return false;}return true;}

  if(name=="spawn01"||name=="spawn01map"||name=="spawn000"){
    if(a.size()<4)return std::uintptr_t(0);auto modelName=scriptString(a[0]);if(modelName.empty())return std::uintptr_t(0);
    auto self=normalizeHandle(0);int slot=playerSlot(self);float sx=0.0f,sz=200.0f,sa=0.0f;int face=1;int palette=0;
    if(slot>=0){sx=playerX(slot);sz=playerZ(slot);sa=playerAlt(slot);face=playerFace(slot);palette=slot==0?playerPaletteMap_:0;if(slot>0)for(const auto&cp:coopPlayers_)if(cp.playerSlot==slot){palette=cp.paletteMap;break;}}
    else if(auto*e=entityFromHandle(self)){sx=e->worldX;sz=e->z;sa=-e->altitude;face=e->facing;palette=e->paletteMap;}
    float dx=(float)scriptNumber(a[1]),da=(float)scriptNumber(a[2]),dz=(float)scriptNumber(a[3]);if(name!="spawn000")dx*=face;
    scriptSpawnEntry_=ScriptSpawnEntry{};scriptSpawnEntry_.model=modelName;scriptSpawnEntry_.x=sx+dx;scriptSpawnEntry_.z=sz+dz;scriptSpawnEntry_.a=sa+da;if(name=="spawn01map")scriptSpawnEntry_.map=std::to_string(std::max(0,palette));
    auto h=callScriptFunction("spawn",{},ctx,unsupported);auto ptr=scriptPointer(h);if(auto*spawned=entityFromHandle(ptr)){if(name!="spawn000")spawned->facing=face;}return h;
  }

  if(name=="clearspawnentry"||name=="clear_spawn_entry"){scriptSpawnEntry_=ScriptSpawnEntry{};return true;}
  if(name=="setspawnentry"||name=="set_spawn_entry"){
    if(a.size()<2)return false;auto k=lowerString(scriptString(a[0]));if(k=="name"||k=="model")scriptSpawnEntry_.model=scriptString(a[1]);else if(k=="alias")scriptSpawnEntry_.alias=scriptString(a[1]);else if(k=="item")scriptSpawnEntry_.item=scriptString(a[1]);else if(k=="map"||k=="colourmap"||k=="colormap")scriptSpawnEntry_.map=scriptString(a[1]);else if(k=="health")scriptSpawnEntry_.health=(int)scriptNumber(a[1]);else if(k=="boss")scriptSpawnEntry_.boss=scriptNumber(a[1])!=0;else if(k=="x")scriptSpawnEntry_.x=(float)scriptNumber(a[1]);else if(k=="z")scriptSpawnEntry_.z=(float)scriptNumber(a[1]);else if(k=="a"||k=="altitude")scriptSpawnEntry_.a=(float)scriptNumber(a[1]);else if(k=="coords"){scriptSpawnEntry_.x=(float)scriptNumber(a[1]);if(a.size()>2)scriptSpawnEntry_.z=(float)scriptNumber(a[2]);if(a.size()>3)scriptSpawnEntry_.a=(float)scriptNumber(a[3]);}return true;
  }
  if(name=="spawn"||name=="spawnentity"||name=="spawn_entity"){
    if(scriptSpawnEntry_.model.empty())return std::uintptr_t(0);auto*m=findCharacter(scriptSpawnEntry_.model.c_str());if(!m)return std::uintptr_t(0);RuntimeEntity e;e.model=m;e.subjectToScreen=m->subjectToScreen;e.weaponDropsRemaining=std::max(0,m->weaponDropCounter);e.worldX=scriptSpawnEntry_.x==0.0f?cameraX_+(float)config_.logicalWidth*0.5f:scriptSpawnEntry_.x;e.z=scriptSpawnEntry_.z;e.altitude=-std::max(0.0f,scriptSpawnEntry_.a);e.paletteMap=paletteIndexFromText(scriptSpawnEntry_.map.c_str());e.maxHealth=e.health=std::max(1,scriptSpawnEntry_.health>0?scriptSpawnEntry_.health:m->health);e.maxMp=e.mp=std::max(0,m->mp);e.lifeTicks=m->lifespanSeconds>0.0f?std::max(1,(int)std::lround(m->lifespanSeconds*60.0f)):-1;e.guardPoints=std::max(0,m->guardPoints);e.juggleRemaining=std::max(1,m->jugglePoints);auto idle=findAnimation(m,"idle");if(!idle)idle=findAnimation(m,"walk");e.animation.setAnimation(idle);entities_.push_back(std::move(e));auto&spawned=entities_.back();spawned.scriptCtx.entity=&spawned;spawned.scriptCtx.local["self"]=std::uintptr_t((std::uintptr_t)&spawned);runModelScript(m->onSpawnScript,spawned.scriptCtx,"script-spawn-onspawn");return std::uintptr_t((std::uintptr_t)&spawned);
  }

  if(name=="rgbcolor"||name=="rgbcolour"){if(a.size()<3)return 0.0;unsigned r=(unsigned)std::clamp((int)scriptNumber(a[0]),0,255),g=(unsigned)std::clamp((int)scriptNumber(a[1]),0,255),b=(unsigned)std::clamp((int)scriptNumber(a[2]),0,255);return(double)((r<<16)|(g<<8)|b);}
  if(name=="loadsprite"){if(a.empty())return std::uintptr_t(0);SpriteImage img;auto path=resolveSpriteAsset(root_/"assets"/"openbor-data",scriptString(a[0]).c_str());if(!renderer_.loadSprite(path,img)||img.width<=0)return std::uintptr_t(0);auto h=nextScriptSpriteHandle_++;scriptSprites_[h]=std::move(img);return std::uintptr_t(h);}
  if(name=="freesprite"||name=="free"){if(a.empty())return false;auto h=scriptPointer(a[0]);return scriptSprites_.erase(h)>0;}
  if(name=="getgfxproperty"||name=="get_gfx_property"){if(a.size()<2)return {};auto h=scriptPointer(a[0]);auto it=scriptSprites_.find(h);if(it==scriptSprites_.end())return {};auto k=lowerString(scriptString(a[1]));if(k=="width")return(double)it->second.width;if(k=="height")return(double)it->second.height;return {};}
  if(name=="drawdot"&&a.size()>=4){ScriptDrawCommand c;c.kind=ScriptDrawCommand::Kind::Dot;c.x=(int)scriptNumber(a[0]);c.y=(int)scriptNumber(a[1]);c.z=(int)scriptNumber(a[2]);c.color=(unsigned int)scriptNumber(a[3]);scriptDrawQueue_.push_back(std::move(c));return true;}
  if(name=="drawline"&&a.size()>=6){ScriptDrawCommand c;c.kind=ScriptDrawCommand::Kind::Line;c.x=(int)scriptNumber(a[0]);c.y=(int)scriptNumber(a[1]);c.x2=(int)scriptNumber(a[2]);c.y2=(int)scriptNumber(a[3]);c.z=(int)scriptNumber(a[4]);c.color=(unsigned int)scriptNumber(a[5]);scriptDrawQueue_.push_back(std::move(c));return true;}
  if(name=="drawbox"&&a.size()>=6){ScriptDrawCommand c;c.kind=ScriptDrawCommand::Kind::Box;c.x=(int)scriptNumber(a[0]);c.y=(int)scriptNumber(a[1]);c.w=(int)scriptNumber(a[2]);c.h=(int)scriptNumber(a[3]);c.z=(int)scriptNumber(a[4]);c.color=(unsigned int)scriptNumber(a[5]);scriptDrawQueue_.push_back(std::move(c));return true;}
  if(name=="drawstring"&&a.size()>=4){ScriptDrawCommand c;c.kind=ScriptDrawCommand::Kind::Text;c.x=(int)scriptNumber(a[0]);c.y=(int)scriptNumber(a[1]);c.font=(int)scriptNumber(a[2]);c.text=scriptString(a[3]);c.z=a.size()>4?(int)scriptNumber(a[4]):0;scriptDrawQueue_.push_back(std::move(c));return true;}
  if(name=="drawsprite"&&a.size()>=3){ScriptDrawCommand c;c.kind=ScriptDrawCommand::Kind::Sprite;c.sprite=scriptPointer(a[0]);c.x=(int)scriptNumber(a[1]);c.y=(int)scriptNumber(a[2]);c.z=a.size()>3?(int)scriptNumber(a[3]):0;scriptDrawQueue_.push_back(std::move(c));return true;}

  if(name=="playmusic"){if(a.empty())return false;auto path=resolveAudioAsset(root_/"assets"/"openbor-data",scriptString(a[0]));bool loop=a.size()>1?scriptNumber(a[1])!=0:true;std::size_t off=a.size()>2?(std::size_t)std::max(0.0,scriptNumber(a[2])):0;return std::filesystem::exists(path)&&audio_.playMusic(path,loop,off);}
  if(name=="pausemusic"){audio_.pauseMusic(!a.empty()&&scriptNumber(a[0])!=0);return true;}
  if(name=="loadsample"){if(a.empty())return -1.0;auto path=resolveAudioAsset(root_/"assets"/"openbor-data",scriptString(a[0]));if(!std::filesystem::exists(path))return -1.0;for(std::size_t i=0;i<scriptSamples_.size();++i)if(scriptSamples_[i]==path)return (double)i;scriptSamples_.push_back(path);return (double)(scriptSamples_.size()-1);}
  if(name=="unloadsample"){if(a.empty())return false;auto id=(long long)scriptNumber(a[0]);if(id<0||(std::size_t)id>=scriptSamples_.size())return false;scriptSamples_[(std::size_t)id].clear();return true;}
  if(name=="playsample"){if(a.empty())return -1.0;auto id=(long long)scriptNumber(a[0]);if(id<0||(std::size_t)id>=scriptSamples_.size()||scriptSamples_[(std::size_t)id].empty())return -1.0;float lv=a.size()>2?(float)scriptNumber(a[2]):100.0f,rv=a.size()>3?(float)scriptNumber(a[3]):lv;float gain=std::clamp((lv+rv)/200.0f,0.0f,8.0f);float speed=a.size()>4?(float)scriptNumber(a[4])/100.0f:1.0f;bool loop=a.size()>5&&scriptNumber(a[5])!=0;return audio_.playEffect(scriptSamples_[(std::size_t)id],gain,loop,speed)?1.0:-1.0;}
  if(name=="log"||name=="printf"||name=="debug") {if(!a.empty())std::cout<<"[OpenBOR script] "<<scriptString(a[0])<<"\n";return true;}
  if(std::find(unsupported.begin(),unsupported.end(),raw)==unsupported.end())unsupported.push_back(raw);return {};
}
void Engine::playStageCutscene(bool post){
  if(!stage_)return;
  const generated::CutsceneAnimation* steps=post?stage_->postSceneAnimations:stage_->sceneAnimations;
  std::size_t count=post?stage_->postSceneAnimationCount:stage_->sceneAnimationCount;
  if(!steps||count==0)return;
  auto data=root_/"assets"/"openbor-data";
  for(std::size_t si=0;si<count&&renderer_.isRunning();++si){
    const auto&step=steps[si];if(!step.path||!*step.path)continue;
    if(step.silenceBefore)audio_.stopMusic();
    if(step.musicBefore&&*step.musicBefore){auto m=resolveAudioAsset(data,step.musicBefore);audio_.playMusic(m,step.musicLoop);}
    std::vector<SpriteImage> frames;std::vector<int> delays;auto path=resolveSpriteAsset(data,step.path);if(!renderer_.loadAnimationFrames(path,frames,delays)||frames.empty())continue;
    int elapsed=0,limit=step.durationTicks>0?std::max(1,step.durationTicks)*16:0;for(std::size_t di=0;di<frames.size();++di)if(step.durationTicks<=0)limit+=di<delays.size()?std::max(16,delays[di]):100;limit=std::max(16,limit);std::size_t fi=0;int frameElapsed=0;bool closeScene=false;
    while(elapsed<limit&&renderer_.isRunning()&&renderer_.pumpEvents()){
      bool skipPressed=false;
#ifdef _WIN32
      if(!step.noSkip)skipPressed=frontendKeyPressed(config_.keyAttack)||frontendKeyPressed(config_.keyJump)||frontendKeyPressed(config_.keyPickup)||frontendKeyPressed(config_.keyDash)||frontendKeyPressed(config_.keyGrab)||frontendKeyPressed(config_.keyThrow)||frontendKeyPressed(VK_RETURN)||frontendKeyPressed(VK_ESCAPE);
#endif
      if(skipPressed){if(step.skip)break;closeScene=true;break;}
      renderer_.beginFrame();renderer_.drawImage(frames[fi],step.x,step.y);renderer_.endFrame();std::this_thread::sleep_for(std::chrono::milliseconds(16));elapsed+=16;frameElapsed+=16;int d=fi<delays.size()?std::max(16,delays[fi]):100;if(frameElapsed>=d){frameElapsed=0;fi=(fi+1)%frames.size();}
    }
    if(closeScene){int scene=step.sceneIndex;while(si+1<count&&steps[si+1].sceneIndex==scene)++si;}
  }
  audio_.stopMusic();
}
void Engine::playStageCompleteScreen(){
  if(!stage_||stage_->completeBg==0||!renderer_.isRunning())return;
  auto data=root_/"assets"/"openbor-data";SpriteImage complete;
  bool haveImage=renderer_.loadSprite(resolveSpriteAsset(data,"bgs/complete"),complete)&&complete.width>0&&complete.height>0;
  const int frames=smokeMode_?1:90;
  for(int i=0;i<frames&&renderer_.isRunning()&&renderer_.pumpEvents();++i){
    bool skip=false;
#ifdef _WIN32
    if(!smokeMode_)skip=frontendKeyPressed(config_.keyAttack)||frontendKeyPressed(config_.keyJump)||frontendKeyPressed(VK_RETURN)||frontendKeyPressed(VK_ESCAPE);
#endif
    renderer_.beginFrame();
    if(haveImage){int x=std::max(0,(config_.logicalWidth-complete.width)/2),y=std::max(0,(config_.logicalHeight-complete.height)/2);renderer_.drawImage(complete,x,y);}
    else renderer_.drawText("STAGE COMPLETE",std::max(8,config_.logicalWidth/2-70),std::max(24,config_.logicalHeight/2-8),14,true);
    renderer_.endFrame();
    if(skip)break;
    if(!smokeMode_)std::this_thread::sleep_for(std::chrono::milliseconds(16));
  }
}
bool Engine::loadStage(std::size_t index,bool keepHealth){
  smokeTrace("loadStage enter");
  if(generated::kStageCount==0||index>=generated::kStageCount){smokeTrace("loadStage invalid index");return false;}
  stageIndex_=index;stage_=&generated::kStages[index];
  smokeTrace("loadStage stage assigned");entities_.clear();scriptAntigravity_.clear();entityBindings_.clear();projectiles_.clear();panels_.clear();backgroundLayers_.clear();foregroundLayers_.clear();background_=SpriteImage{};water_=SpriteImage{};bossMusicStarted_=false;shadowCache_.clear();hudIconCache_.clear();hudDeadIconCache_.clear();backgroundRatioX_=0.5f;backgroundOffsetX_=backgroundOffsetY_=0;nextSpawn_=0;nextInstruction_=0;cameraX_=0;cameraMaxX_=0;verticalStageScroll_=0.0f;verticalScroll_=false;verticalScrollSign_=1;combatLocked_=false;stageComplete_=false;scrollBlocked_=false;groupMin_=groupMax_=100;groupRefillActive_=false;backtrackFloor_=0.0f;cameraFixed_=stage_&&stage_->cameraType!=0;scrollDir_=1;allowBacktrack_=false;if(stage_&&stage_->direction){std::string d=lowerString(stage_->direction);if(d=="left"||d=="in"||d=="bothleft")scrollDir_=-1;if(d=="both")allowBacktrack_=true;if(d=="up"||d=="down"){verticalScroll_=true;verticalScrollSign_=d=="down"?-1:1;cameraFixed_=true;}}spawnState_.assign(stage_->spawnCount,0);eventState_.assign(stage_->eventCount,0);
  smokeTrace("loadStage state reset");
  auto data=root_/"assets"/"openbor-data";if(stage_->sceneAnimationCount>0)playStageCutscene(false);
  smokeTrace("loadStage cutscene/assets begin");if(stage_->background&&*stage_->background)renderer_.loadSprite(data/normalizeDataPath(stage_->background),background_);if(stage_->waterPath&&*stage_->waterPath)renderer_.loadSprite(data/normalizeDataPath(stage_->waterPath),water_);
  for(std::size_t i=0;i<stage_->panelCount;++i){SpriteImage img;renderer_.loadSprite(data/normalizeDataPath(stage_->panels[i]),img);panels_.push_back(std::move(img));}
  for(std::size_t i=0;i<stage_->layerCount;++i){const auto&gl=stage_->layers[i];std::string kind=lowerString(gl.kind?gl.kind:"");if(kind=="background"){backgroundRatioX_=gl.xRatio;backgroundOffsetX_=gl.xOffset;backgroundOffsetY_=gl.zOffset;continue;}if(kind!="bglayer"&&kind!="fglayer"&&kind!="frontpanel")continue;RuntimeStageLayer rl;rl.kind=kind;rl.xRatio=gl.xRatio;rl.zRatio=gl.zRatio;rl.xOffset=gl.xOffset;rl.zOffset=gl.zOffset;rl.xSpacing=gl.xSpacing;rl.zSpacing=gl.zSpacing;rl.xRepeat=gl.xRepeat;rl.zRepeat=gl.zRepeat;rl.zOrder=gl.zOrder;rl.transparency=gl.transparency;rl.alpha=gl.alpha;rl.waterMode=gl.waterMode;rl.amplitude=gl.amplitude;rl.wavelength=gl.wavelength;rl.waveSpeed=gl.waveSpeed;rl.bgSpeedRatio=gl.bgSpeedRatio;if(!renderer_.loadSprite(data/normalizeDataPath(gl.path?gl.path:""),rl.image)||rl.image.width<=0)continue;if(kind=="bglayer"||(kind=="fglayer"&&rl.zOrder<0))backgroundLayers_.push_back(std::move(rl));else foregroundLayers_.push_back(std::move(rl));}
  smokeTrace("loadStage layers loaded");
  auto layerSort=[](const RuntimeStageLayer&a,const RuntimeStageLayer&b){return a.zOrder<b.zOrder;};std::stable_sort(backgroundLayers_.begin(),backgroundLayers_.end(),layerSort);std::stable_sort(foregroundLayers_.begin(),foregroundLayers_.end(),layerSort);
  float panelWidth=0;for(const auto&p:panels_)panelWidth+=(float)p.width;stageLength_=std::max(320.0f,panelWidth);stageLength_=std::max(stageLength_,(float)background_.width);for(const auto&l:backgroundLayers_)stageLength_=std::max(stageLength_,(float)l.image.width+std::max(0,l.xOffset));float farthest=stageLength_;for(std::size_t i=0;i<stage_->spawnCount;++i)farthest=std::max(farthest,(float)stage_->spawns[i].at+(float)std::max(0,stage_->spawns[i].x)+64.0f);stageLength_=std::max(stageLength_,farthest);
  smokeTrace("loadStage length calculated");
  if(scrollDir_<0&&!verticalScroll_)cameraX_=std::max(0.0f,stageLength_-(float)std::max(160,config_.logicalWidth));
  smokeTrace("loadStage before safe spawn");
  auto p1spawn=stagePlayerSpawn(stage_,0,cameraX_,config_.logicalWidth,scrollDir_);
  smokeTrace("loadStage after safe spawn");playerWorldX_=p1spawn.x;playerZ_=p1spawn.z;playerAltitude_=p1spawn.altitude;playerFacing_=p1spawn.facing;
  if(!keepHealth&&playerModel_){playerHealth_=playerMaxHealth_=std::max(1,playerModel_->health);playerMp_=playerMaxMp_=std::max(0,playerModel_->mp);playerGuardPoints_=std::max(0,playerModel_->guardPoints);}else playerHealth_=std::clamp(playerHealth_,1,std::max(1,playerMaxHealth_));
  stageScriptCtx_.local.clear();stageScriptCtx_.entity=nullptr;stageScriptCtx_.other=nullptr;stageScriptCtx_.player=false;stageScriptCtx_.playerIndex=0;if(stage_->levelScript&&*stage_->levelScript)runModelScript(stage_->levelScript,stageScriptCtx_,"levelscript");
  smokeTrace("loadStage after level script");
  smokeTrace("loadStage before audio stop");
  audio_.stopMusic();
  smokeTrace("loadStage after audio stop");if(stage_->music&&*stage_->music){auto music=resolveAudioAsset(data,stage_->music);if(!audio_.playMusic(music,stage_->musicLoop))std::cerr<<"Stage music diagnostic: "<<audio_.lastError()<<"\n";}else if(config_.autoPreviewMusic)previewMusic();
  smokeTrace("loadStage complete");
  std::cout<<"Stage "<<(index+1)<<"/"<<generated::kStageCount<<": "<<stage_->sourceFile<<" geometry="<<stage_->geometryCount<<" length="<<stageLength_<<"\n";return true;
}
void Engine::saveProgress(){
  if(smokeMode_||suspendSave_||!stage_||stage_->canSave<=0)return;
  std::filesystem::create_directories(root_/"saves");std::ofstream f(root_/"saves"/"slot1.sav",std::ios::trunc);if(!f)return;
  auto modelName=[](const generated::Character* m)->std::string{return m&&m->name?std::string(m->name):std::string{};};
  int joinedMask=1;for(const auto&cp:coopPlayers_)if(cp.playerSlot>=1&&cp.playerSlot<4)joinedMask|=(1<<cp.playerSlot);
  f<<"save_version=3\n"<<"stage="<<stageIndex_<<"\nchapter="<<stage_->chapter<<"\nactive_players="<<(1+(int)coopPlayers_.size())<<"\njoined_mask="<<joinedMask<<"\nlives="<<livesRemaining_<<"\ncredits="<<creditsRemaining_<<"\n";
  f<<"player1="<<modelName(playerModel_)<<"\nalive1="<<(playerAlive_?1:0)<<"\nhealth1="<<playerHealth_<<"\nmp1="<<playerMp_<<"\npalette1="<<playerPaletteMap_<<"\nscore1="<<playerScore_<<"\nlives1="<<livesRemaining_<<"\ncredits1="<<creditsRemaining_<<"\nweapon1="<<modelName(equippedWeapon_)<<"\nweapon_uses1="<<weaponUses_<<"\nweapon_item1="<<modelName(weaponItemModel_)<<"\nweapon_drops1="<<weaponDropsRemaining_<<"\n";
  for(std::size_t i=0;i<coopPlayers_.size()&&i<3;++i){const auto&cp=coopPlayers_[i];int slot=std::clamp(cp.playerSlot+1,2,4);f<<"player"<<slot<<"="<<modelName(cp.model)<<"\nalive"<<slot<<"="<<(cp.alive?1:0)<<"\nhealth"<<slot<<"="<<cp.health<<"\nmp"<<slot<<"="<<cp.mp<<"\npalette"<<slot<<"="<<cp.paletteMap<<"\nscore"<<slot<<"="<<cp.score<<"\nlives"<<slot<<"="<<cp.livesRemaining<<"\ncredits"<<slot<<"="<<cp.creditsRemaining<<"\nweapon"<<slot<<"="<<modelName(cp.equippedWeapon)<<"\nweapon_uses"<<slot<<"="<<cp.weaponUses<<"\nweapon_item"<<slot<<"="<<modelName(cp.weaponItemModel)<<"\nweapon_drops"<<slot<<"="<<cp.weaponDropsRemaining<<"\n";}
}
bool Engine::loadProgress(){
  std::ifstream f(root_/"saves"/"slot1.sav");if(!f)return false;std::string line;std::size_t st=0;int active=1,joinedMask=-1,savedLives=-1,savedCredits=-1;std::string names[4],weapon[4],weaponItem[4];int aliveState[4]{-1,-1,-1,-1},hp[4]{0,0,0,0},mp[4]{-1,-1,-1,-1},palette[4]{0,0,0,0},slotLives[4]{-1,-1,-1,-1},slotCredits[4]{-1,-1,-1,-1},weaponUses[4]{0,0,0,0},weaponDrops[4]{-1,-1,-1,-1};long long score[4]{0,0,0,0};
  while(std::getline(f,line)){auto p=line.find('=');if(p==std::string::npos)continue;auto k=line.substr(0,p),v=line.substr(p+1);try{
    if(k=="stage")st=(std::size_t)std::stoul(v);else if(k=="active_players")active=std::clamp(std::stoi(v),1,4);else if(k=="joined_mask")joinedMask=std::clamp(std::stoi(v),1,15);else if(k=="lives")savedLives=std::max(0,std::stoi(v));else if(k=="credits")savedCredits=std::max(0,std::stoi(v));else for(int i=0;i<4;++i){auto n=std::to_string(i+1);if(k=="player"+n)names[i]=v;else if(k=="alive"+n)aliveState[i]=std::stoi(v)!=0?1:0;else if(k=="health"+n)hp[i]=std::stoi(v);else if(k=="mp"+n)mp[i]=std::stoi(v);else if(k=="palette"+n)palette[i]=std::stoi(v);else if(k=="score"+n)score[i]=std::stoll(v);else if(k=="lives"+n)slotLives[i]=std::max(0,std::stoi(v));else if(k=="credits"+n)slotCredits[i]=std::max(0,std::stoi(v));else if(k=="weapon"+n)weapon[i]=v;else if(k=="weapon_uses"+n)weaponUses[i]=std::stoi(v);else if(k=="weapon_item"+n)weaponItem[i]=v;else if(k=="weapon_drops"+n)weaponDrops[i]=std::stoi(v);}
  }catch(...){} }
  std::vector<const generated::Character*> selectable;for(std::size_t i=0;i<generated::kCharacterCount;++i)if(lowerString(generated::kCharacters[i].type)=="player")selectable.push_back(&generated::kCharacters[i]);if(selectable.empty()&&generated::kCharacterCount)selectable.push_back(&generated::kCharacters[0]);if(selectable.empty()||generated::kStageCount==0)return false;
  if(joinedMask<0)joinedMask=(1<<active)-1;joinedMask|=1;active=0;for(int slot=0;slot<4;++slot){joinedPlayers_[slot]=(joinedMask&(1<<slot))!=0;if(joinedPlayers_[slot])++active;selectIndexes_[slot]=0;if(!names[slot].empty())for(std::size_t j=0;j<selectable.size();++j)if(lowerString(selectable[j]->name)==lowerString(names[slot])){selectIndexes_[slot]=(int)j;break;}}
  config_.activePlayers=std::max(1,active);playerModel_=selectable[(std::size_t)selectIndexes_[0]];selectedPlayerIndex_=selectIndexes_[0];stageIndex_=std::min(st,generated::kStageCount-1);
  suspendSave_=true;beginGame();suspendSave_=false;
  if(aliveState[0]==0){playerAlive_=false;playerHealth_=0;}else if(hp[0]>0){playerAlive_=true;playerHealth_=std::clamp(hp[0],1,playerMaxHealth_);}if(mp[0]>=0)playerMp_=std::clamp(mp[0],0,playerMaxMp_);playerPaletteMap_=std::max(0,palette[0]);playerScore_=std::max(0LL,score[0]);if(slotLives[0]>=0)livesRemaining_=slotLives[0];else if(savedLives>=0)livesRemaining_=savedLives;if(slotCredits[0]>=0)creditsRemaining_=slotCredits[0];else if(savedCredits>=0)creditsRemaining_=savedCredits;
  if(!weapon[0].empty())equippedWeapon_=findCharacter(weapon[0].c_str());weaponUses_=std::max(0,weaponUses[0]);if(!weaponItem[0].empty())weaponItemModel_=findCharacter(weaponItem[0].c_str());weaponDropsRemaining_=weaponDrops[0];
  for(std::size_t i=0;i<coopPlayers_.size()&&i<3;++i){auto&cp=coopPlayers_[i];int slot=std::clamp(cp.playerSlot,1,3);if(aliveState[slot]==0){cp.alive=false;cp.health=0;}else if(hp[slot]>0){cp.alive=true;cp.health=std::clamp(hp[slot],1,cp.maxHealth);}if(mp[slot]>=0)cp.mp=std::clamp(mp[slot],0,cp.maxMp);cp.paletteMap=std::max(0,palette[slot]);cp.score=std::max(0LL,score[slot]);if(slotLives[slot]>=0)cp.livesRemaining=slotLives[slot];else if(savedLives>=0)cp.livesRemaining=savedLives;if(slotCredits[slot]>=0)cp.creditsRemaining=slotCredits[slot];else if(savedCredits>=0)cp.creditsRemaining=savedCredits;if(!weapon[slot].empty())cp.equippedWeapon=findCharacter(weapon[slot].c_str());cp.weaponUses=std::max(0,weaponUses[slot]);if(!weaponItem[slot].empty())cp.weaponItemModel=findCharacter(weaponItem[slot].c_str());cp.weaponDropsRemaining=weaponDrops[slot];}
  return true;
}
void Engine::advanceStage(){
  dropPlayerWeapon(true);for(auto&cp:coopPlayers_)dropCoopWeapon(cp,true);for(auto&e:entities_)dropEntityWeapon(e,true);flushWeaponDrops();
  playStageCompleteScreen();
  int oldChapter=stage_?stage_->chapter:0;if(stage_&&stage_->postSceneAnimationCount>0)playStageCutscene(true);
  std::size_t target=stageIndex_+1;if(pendingBranchTarget_!=(std::size_t)-1){target=pendingBranchTarget_;pendingBranchTarget_=(std::size_t)-1;pendingBranchImmediate_=false;}else if(stage_&&stage_->nextStage&&*stage_->nextStage){auto want=PathEncoding::utf8(normalizeDataPath(stage_->nextStage));for(std::size_t i=0;i<generated::kStageCount;++i){auto src=PathEncoding::utf8(normalizeDataPath(generated::kStages[i].sourceFile));if(src==want||src.ends_with(want)){target=i;break;}}}
  if(target<generated::kStageCount){int hp1=playerHealth_;bool p1Alive=playerAlive_;std::vector<int> coopHp;std::vector<bool> coopAlive;for(const auto&cp:coopPlayers_){coopHp.push_back(cp.health);coopAlive.push_back(cp.alive);}bool sameChapter=generated::kStages[target].chapter==oldChapter;frontendState_=FrontendState::Loading;renderer_.beginFrame();SpriteImage loading;auto lp=resolveSpriteAsset(root_/"assets"/"openbor-data","bgs/loading");if(renderer_.loadSprite(lp,loading)&&loading.width>0)renderer_.drawImage(loading,0,0);else renderer_.drawText("LOADING...",92,105,18,true);renderer_.endFrame();std::this_thread::sleep_for(std::chrono::milliseconds(250));loadStage(target,true);playerAlive_=p1Alive;if(p1Alive)playerHealth_=sameChapter?std::min(std::max(1,playerMaxHealth_),std::max(1,hp1)+5):std::max(1,playerMaxHealth_);else playerHealth_=0;for(std::size_t i=0;i<coopPlayers_.size();++i){int slot=coopPlayers_[i].playerSlot;auto sp=stagePlayerSpawn(stage_,slot,cameraX_,config_.logicalWidth,scrollDir_);coopPlayers_[i].worldX=sp.x;coopPlayers_[i].z=sp.z;coopPlayers_[i].altitude=sp.altitude;coopPlayers_[i].facing=sp.facing;bool wasAlive=i<coopAlive.size()?coopAlive[i]:true;coopPlayers_[i].alive=wasAlive;if(wasAlive){if(i<coopHp.size())coopPlayers_[i].health=sameChapter?std::min(coopPlayers_[i].maxHealth,std::max(1,coopHp[i])+5):coopPlayers_[i].maxHealth;else coopPlayers_[i].health=coopPlayers_[i].maxHealth;}else coopPlayers_[i].health=0;coopPlayers_[i].animation.setAnimation(findAnimation(coopPlayers_[i].model,"idle"));coopPlayers_[i].lastFrame=(std::size_t)-1;}nextSpawn_=0;nextInstruction_=0;frontendState_=FrontendState::Playing;saveProgress();}
  else{std::error_code ec;std::filesystem::remove(root_/"saves"/"slot1.sav",ec);frontendState_=FrontendState::MainMenu;audio_.stopMusic();}
}
float Engine::dynamicPlatformHeight(float x,float z,const RuntimeEntity* ignore,const generated::Character* subject) const{
  if(subject&&!subject->subjectToPlatform)return 0.0f;
  float best=0.0f;
  for(const auto& pe:entities_){if(&pe==ignore||!pe.alive||!pe.visible||!pe.model)continue;auto*pf=pe.animation.frame();if(!pf||!pf->hasPlatform)continue;const auto&p=pf->platform;if(p.depth<=0.0f||p.altitude<=0.0f)continue;float anchorX=pe.worldX+(p.x-(float)pf->offsetX)*(float)pe.facing;float anchorZ=pe.z+(p.z-(float)pf->offsetY);float dz=anchorZ-z;if(dz<0.0f||dz>p.depth)continue;float t=std::clamp(dz/p.depth,0.0f,1.0f);float l=p.lowerLeft+(p.upperLeft-p.lowerLeft)*t;float r=p.lowerRight+(p.upperRight-p.lowerRight)*t;float wx1=anchorX+l*(float)pe.facing,wx2=anchorX+r*(float)pe.facing;float left=std::min(wx1,wx2),right=std::max(wx1,wx2);if(x>=left&&x<=right)best=std::max(best,p.altitude);}
  return best;
}
bool Engine::applyActorTerrain(const generated::Character* model,ScriptContext& ctx,float& x,float& z,float altitude,float oldX,float oldZ){
  if(!stage_)return false;
  // Runtime screen altitude is the negative of OpenBOR's world Y.
  float worldY=-altitude;int wallIndex=-1,wallCounter=0;const generated::Geometry* wall=nullptr;
  bool coversHole=false,hole=false;
  // Entity `platform` boxes are animation-frame geometry. Their trapezoid footprint
  // blocks side entry below the top, while dynamicPlatformHeight() supplies the top
  // landing/base height used by player, coop, and entity vertical physics.
  if((!model||model->subjectToPlatform)&&(x!=oldX||z!=oldZ)){for(auto& pe:entities_){if(!pe.alive||!pe.visible||!pe.model)continue;auto*pf=pe.animation.frame();if(!pf||!pf->hasPlatform)continue;const auto&p=pf->platform;if(p.depth<=0.0f||p.altitude<=worldY)continue;float anchorX=pe.worldX+(p.x-(float)pf->offsetX)*(float)pe.facing;float anchorZ=pe.z+(p.z-(float)pf->offsetY);float dz=anchorZ-z;if(dz<0.0f||dz>p.depth)continue;float t=std::clamp(dz/p.depth,0.0f,1.0f);float l=p.lowerLeft+(p.upperLeft-p.lowerLeft)*t;float r=p.lowerRight+(p.upperRight-p.lowerRight)*t;float wx1=anchorX+l*(float)pe.facing,wx2=anchorX+r*(float)pe.facing;float left=std::min(wx1,wx2),right=std::max(wx1,wx2);if(x>=left&&x<=right){x=oldX;z=oldZ;break;}}}
  for(std::size_t i=0;i<stage_->geometryCount;++i){const auto& g=stage_->geometry[i];auto kind=lowerString(g.kind?g.kind:"");
    int index=kind=="wall"?wallCounter++:-1;if(!terrainContains(g,x,z))continue;
    float height=g.openborShape?g.shape[7]:(float)g.altitude;
    if(kind=="wall"){coversHole=true;if(height>worldY&&height>0&&(!wall||height>(wall->openborShape?wall->shape[7]:(float)wall->altitude))){wall=&g;wallIndex=index;}}
    else if(kind=="hole"&&height+2.0f>=worldY)hole=true;
  }
  if(wall&&(!model||model->subjectToWall)&& (x!=oldX||z!=oldZ)){
    float dx=x-oldX,dz=z-oldZ;x=oldX;z=oldZ;
    if(model){ctx.local["plane"]=(double)(std::fabs(dx)>=std::fabs(dz)?0:2);ctx.local["index"]=(double)wallIndex;
      ctx.local["height"]=(double)(wall->openborShape?wall->shape[7]:wall->altitude);
      ctx.local["depth"]=(double)(wall->openborShape?wall->shape[6]:wall->h);
      ctx.local["type"]=(double)(wall->openborShape?wall->shape[8]:0);
      runModelScript(model->onBlockWScript,ctx,"actor-onblockw");
      for(const auto*key:{"plane","index","height","depth","type"})ctx.local.erase(key);
    }
    return false;
  }
  return hole&&!coversHole&&(!model||model->subjectToHole);
}
void Engine::applyStageGeometry(float oldX,float oldZ){
  if(applyActorTerrain(playerModel_,playerScriptCtx_,playerWorldX_,playerZ_,playerAltitude_,oldX,oldZ)){
    playerHealth_=std::max(1,playerHealth_-10);playerWorldX_=(float)stage_->playerStartX;playerZ_=(float)stage_->playerStartZ;
    std::cout<<"Hole reset, hp="<<playerHealth_<<"\n";
  }
}
bool Engine::initialize(const std::filesystem::path& portRoot){
  root_=portRoot; config_=loadRuntimeConfig(root_/"config"/"graphics.ini");{std::ifstream hf(root_/"assets"/"openbor-data"/"lifebar.txt");std::string line;while(std::getline(hf,line)){auto hash=line.find('#');if(hash!=std::string::npos)line.resize(hash);std::istringstream ss(line);std::string k;ss>>k;k=lowerString(k);if(k=="lbarsize"||k=="lifebarsize"){int w=0,h=0;if(ss>>w>>h){hudBarWidth_=std::max(8,w);hudBarHeight_=std::max(2,h);}}}} {std::ifstream vf(root_/"config"/"openbor-video.ini");std::string line;while(std::getline(vf,line)){auto eq=line.find('=');if(eq==std::string::npos)continue;auto k=line.substr(0,eq),v=line.substr(eq+1);try{if(k=="logical_width")config_.logicalWidth=std::max(160,std::stoi(v));else if(k=="logical_height")config_.logicalHeight=std::max(120,std::stoi(v));}catch(...){}}} scriptVm_.setRoot(root_/"assets"/"openbor-data"); scriptVm_.setHost(this); playerScriptCtx_.player=true; playerScriptCtx_.playerIndex=0; playerScriptCtx_.local["self"]=std::uintptr_t(1);
  if(!renderer_.initialize(config_)) return false;
  if(!audio_.initialize(config_)) std::cerr<<"Audio warning: "<<audio_.lastError()<<"\n";
  std::cout << "Renderer: " << renderer_.backend() << "\nCharacters: " << generated::kCharacterCount << " Stages: " << generated::kStageCount << "\n";
  std::cout << "Graphics: preset="<<config_.graphicsPreset<<" upscale="<<config_.upscaleMode<<" filter="<<config_.textureFilter<<" vsync="<<(config_.vsync?"on":"off")<<" fps="<<(config_.fpsLimit==0?std::string("unlimited"):std::to_string(config_.fpsLimit))<<"\n";
  std::cout << "Audio volumes master="<<audio_.masterVolume()<<" music="<<audio_.musicVolume()<<" effects="<<audio_.effectsVolume()<<"\n";

  if(generated::kStageCount>0) stage_=&generated::kStages[0];

  renderer_.loadSprite(resolveSpriteAsset(root_/"assets"/"openbor-data","bgs/title"),titleBackground_);
  renderer_.loadSprite(resolveSpriteAsset(root_/"assets"/"openbor-data","bgs/select"),selectBackground_);
  loadLegacyMenuConfig();
  campaignFirstStages_.clear(); campaignNames_.clear();
  for(std::size_t i=0;i<generated::kStageCount;++i){
    std::string set=(generated::kStages[i].setName&&*generated::kStages[i].setName)?generated::kStages[i].setName:"NEW GAME";
    bool seen=false;for(const auto&n:campaignNames_)if(lowerString(n)==lowerString(set)){seen=true;break;}
    if(!seen){campaignFirstStages_.push_back(i);campaignNames_.push_back(set);}
  }
  if(campaignFirstStages_.empty()&&generated::kStageCount){campaignFirstStages_.push_back(0);campaignNames_.push_back("NEW GAME");}
  for(std::size_t i=0;i<generated::kCharacterCount;++i){ if(lowerString(generated::kCharacters[i].type)=="player"){ playerModel_=&generated::kCharacters[i]; break; } }
  if(!playerModel_ && generated::kCharacterCount) playerModel_=&generated::kCharacters[0];
  if(playerModel_){
    playerMaxHealth_=playerHealth_=std::max(1,playerModel_->health);
    player_.setAnimation(findAnimation(playerModel_,"idle")); if(!player_.frame()) player_.setAnimation(findAnimation(playerModel_,"walk"));
    std::cout<<"Combat ready: player="<<playerModel_->name<<" hp="<<playerHealth_<<" enemyAI="<<(config_.enemyAI?"on":"off")<<" cameraLock="<<(config_.cameraLockOnCombat?"on":"off")<<"\n";
  }
#ifdef _WIN32
  frontendState_=FrontendState::MainMenu;
  audio_.stopMusic();
#else
  frontendState_=FrontendState::Playing;for(int i=0;i<4;++i)joinedPlayers_[i]=(i<config_.activePlayers);beginGame();
#endif
  return true;
}
bool Engine::frontendKeyPressed(int vk){
#ifdef _WIN32
  static SHORT prev[256]{}; if(vk<0||vk>255) return false; SHORT now=GetAsyncKeyState(vk); bool down=(now&0x8000)!=0, was=(prev[vk]&0x8000)!=0; prev[vk]=now; return down&&!was;
#else
  (void)vk; return false;
#endif
}
bool Engine::gamepadButtonPressedFor(int pad,unsigned short button){
#ifdef _WIN32
  if(!config_.gamepad)return false;static WORD prev[4]{},cur[4]{};static ULONGLONG stamp[4]{};DWORD id=(DWORD)std::clamp(pad,0,3);ULONGLONG nowTick=GetTickCount64();if(nowTick!=stamp[id]){prev[id]=cur[id];XINPUT_STATE state{};cur[id]=(XInputGetState(id,&state)==ERROR_SUCCESS)?state.Gamepad.wButtons:0;stamp[id]=nowTick;}return (cur[id]&button)&&!(prev[id]&button);
#else
  (void)pad;(void)button;return false;
#endif
}
bool Engine::gamepadButtonPressed(unsigned short button){ return gamepadButtonPressedFor(config_.player1Gamepad,button); }
int Engine::captureAnyKey(){
#ifdef _WIN32
  static unsigned char prev[256]{};for(int vk=8;vk<255;++vk){bool down=(GetAsyncKeyState(vk)&0x8000)!=0;bool fire=down&&!prev[vk];prev[vk]=(unsigned char)(down?1:0);if(fire)return vk;}return 0;
#else
  return 0;
#endif
}
unsigned short Engine::captureAnyGamepadButton(int pad){
#ifdef _WIN32
  static WORD prev[4]{};XINPUT_STATE xs{};DWORD id=(DWORD)std::clamp(pad,0,3);WORD cur=(XInputGetState(id,&xs)==ERROR_SUCCESS)?xs.Gamepad.wButtons:0;WORD pressed=(WORD)(cur&~prev[id]);prev[id]=cur;static const WORD buttons[]={XINPUT_GAMEPAD_A,XINPUT_GAMEPAD_B,XINPUT_GAMEPAD_X,XINPUT_GAMEPAD_Y,XINPUT_GAMEPAD_LEFT_SHOULDER,XINPUT_GAMEPAD_RIGHT_SHOULDER,XINPUT_GAMEPAD_BACK,XINPUT_GAMEPAD_START,XINPUT_GAMEPAD_LEFT_THUMB,XINPUT_GAMEPAD_RIGHT_THUMB};for(WORD b:buttons)if(pressed&b)return b;return 0;
#else
  (void)pad;return 0;
#endif
}
void Engine::saveSettings(){
  config_.masterVolume=audio_.masterVolume(); config_.musicVolume=audio_.musicVolume(); config_.effectsVolume=audio_.effectsVolume();
  renderer_.setConfig(config_);
  if(!saveRuntimeConfig(root_/"config"/"graphics.ini",config_)) std::cerr<<"Could not save graphics.ini\n";
}
void Engine::smokeTrace(const char* msg){
  if(!smokeMode_||!msg)return;
  std::ofstream out(root_/"runtime-startup.log",std::ios::app);
  if(out){out<<"SMOKE TRACE "<<msg<<"\n";out.flush();}
}
void Engine::loadLegacyMenuConfig(){
  legacyKeyLabels_.clear(); legacyDisabledKeys_.clear();
  auto path=root_/"assets"/"openbor-data"/"menu.txt";std::ifstream in(path);if(!in)return;
  std::string line;while(std::getline(in,line)){
    auto hash=line.find('#');if(hash!=std::string::npos)line.resize(hash);std::istringstream ss(line);std::string cmd,key;if(!(ss>>cmd>>key))continue;cmd=lowerString(cmd);key=lowerString(key);
    if(cmd=="renamekey"){std::string label;std::getline(ss,label);auto first=label.find_first_not_of(" \t\r\n");if(first!=std::string::npos){label=label.substr(first);legacyKeyLabels_[key]=label;}}
    else if(cmd=="disablekey")legacyDisabledKeys_.insert(key);
  }
}
std::string Engine::legacyControlLabel(const std::string& key,const std::string& fallback) const{
  auto it=legacyKeyLabels_.find(lowerString(key));return it==legacyKeyLabels_.end()?fallback:it->second;
}
void Engine::startCampaign(std::size_t campaignIndex){
  if(generated::kStageCount==0)return;if(campaignFirstStages_.empty()){campaignFirstStages_.push_back(0);campaignNames_.push_back("NEW GAME");}
  campaignIndex_=std::clamp((int)campaignIndex,0,(int)campaignFirstStages_.size()-1);stageIndex_=campaignFirstStages_[(std::size_t)campaignIndex_];
  selectIndex_=0;for(int i=0;i<4;++i){selectIndexes_[i]=0;joinedPlayers_[i]=(i==0);}std::vector<const generated::Character*> players;
  for(std::size_t i=0;i<generated::kCharacterCount;++i)if(lowerString(generated::kCharacters[i].type)=="player")players.push_back(&generated::kCharacters[i]);if(players.empty()&&generated::kCharacterCount)players.push_back(&generated::kCharacters[0]);
  const bool skip=(stageIndex_<generated::kStageCount&&generated::kStages[stageIndex_].skipSelect!=0);
  if(skip&&!players.empty()){playerModel_=players[0];selectedPlayerIndex_=0;config_.activePlayers=1;saveSettings();beginGame();}else frontendState_=FrontendState::CharacterSelect;
}
void Engine::drawSelectCharacterPreview(const generated::Character* model,int slot,int total){
  if(!model)return;const generated::Animation* a=findAnimation(model,"select");if(!a)a=findAnimation(model,"idle");if(!a)a=findAnimation(model,"walk");if(!a||!a->frameCount)return;
  unsigned long long cycle=0;for(std::size_t i=0;i<a->frameCount;++i)cycle+=(unsigned long long)std::max(1,a->frames[i].delay);if(cycle==0)cycle=1;unsigned long long t=frontendTick_%cycle;std::size_t fi=0;for(;fi+1<a->frameCount;++fi){auto d=(unsigned long long)std::max(1,a->frames[fi].delay);if(t<d)break;t-=d;}
  const auto&f=a->frames[fi];if(!f.sprite||!*f.sprite)return;std::string key=f.sprite;auto it=frontendSpriteCache_.find(key);if(it==frontendSpriteCache_.end()){SpriteImage img;renderer_.loadSprite(resolveSpriteAsset(root_/"assets"/"openbor-data",key.c_str()),img);it=frontendSpriteCache_.emplace(key,std::move(img)).first;}if(it->second.width<=0)return;
  int count=std::max(1,total),anchorX=(config_.logicalWidth*(slot+1))/(count+1),anchorY=std::max(80,config_.logicalHeight-44);renderer_.drawImage(it->second,anchorX-f.offsetX,anchorY-f.offsetY);
}
void Engine::beginGame(){
  smokeTrace("beginGame enter");
  if(!playerModel_){smokeTrace("beginGame no-player-model");return;}
  smokeTrace("beginGame before loadStage");
  if(!loadStage(stageIndex_,false)){smokeTrace("beginGame loadStage failed");return;}
  smokeTrace("beginGame after loadStage");
  smokeTrace("beginGame configure lives");
  const int initialLives=std::max(1,stage_&&stage_->lives>0?stage_->lives:1);
  const int initialCredits=std::max(0,stage_?stage_->credits:0);
  livesRemaining_=initialLives;creditsRemaining_=initialCredits;
  entities_.clear();scriptAntigravity_.clear();entityBindings_.clear(); projectiles_.clear(); equippedWeapon_=nullptr; grabbedEntity_=-1; grabHoldTicks_=0;
  nextSpawn_=0; combatLocked_=false; combatLockX_=0.0f; tickCounter_=0;
  smokeTrace("beginGame before player spawn");
  auto p1spawn=stagePlayerSpawn(stage_,0,cameraX_,config_.logicalWidth,scrollDir_);smokeTrace("beginGame after player spawn");playerWorldX_=p1spawn.x;playerZ_=p1spawn.z;playerAltitude_=p1spawn.altitude;playerFacing_=p1spawn.facing; playerVerticalVelocity_=0; playerJumpVelocityX_=playerJumpVelocityZ_=0;
  playerEnergyPending_={};playerAlive_=true; playerMaxHealth_=playerHealth_=std::max(1,playerModel_->health); playerMaxMp_=playerMp_=std::max(0,playerModel_->mp); playerGuardPoints_=std::max(0,playerModel_->guardPoints);if(!suspendSave_){playerPaletteMap_=0;playerScore_=0;} playerBlockState_=0; playerBlocking_=false; playerHitStun_=playerAttackTicks_=playerAttackCooldown_=0;
  playerComboStep_=playerComboWindow_=playerFallTicks_=playerRecoveryTicks_=playerDashTicks_=0;playerLandingDamage_=0;playerLandingMode_=0;playerLandingType_=-1; playerComboBranch_=-1; playerQueuedAttack_=playerProjectileFired_=playerJumping_=playerAnimJumpTriggered_=false;
  playerAttackId_=0; lastFrame_=(std::size_t)-1; smokeTrace("beginGame before animation");player_.setAnimation(findAnimation(playerModel_,"idle")); if(!player_.frame()) player_.setAnimation(findAnimation(playerModel_,"walk"));smokeTrace("beginGame after animation");
  coopPlayers_.clear();smokeTrace("beginGame coop clear");
  std::vector<const generated::Character*> selectable;for(std::size_t i=0;i<generated::kCharacterCount;++i)if(lowerString(generated::kCharacters[i].type)=="player")selectable.push_back(&generated::kCharacters[i]);if(selectable.empty()&&generated::kCharacterCount)selectable.push_back(&generated::kCharacters[0]);
  int pads[4]={config_.player1Gamepad,config_.player2Gamepad,config_.player3Gamepad,config_.player4Gamepad};
  for(int slot=1;slot<std::min(4,config_.maxPlayers);++slot){if(!joinedPlayers_[slot]||selectable.empty())continue;RuntimeCoopPlayer cp;cp.playerSlot=slot;cp.model=selectable[(std::size_t)(selectIndexes_[slot]%(int)selectable.size())];cp.maxHealth=cp.health=std::max(1,cp.model->health);cp.maxMp=cp.mp=std::max(0,cp.model->mp);cp.guardPoints=std::max(0,cp.model->guardPoints);cp.livesRemaining=initialLives;cp.creditsRemaining=initialCredits;if(stage_){auto sp=stagePlayerSpawn(stage_,slot,cameraX_,config_.logicalWidth,scrollDir_);cp.worldX=sp.x;cp.z=sp.z;cp.altitude=sp.altitude;cp.facing=sp.facing;}else{cp.worldX=playerWorldX_+18.0f*(float)slot;cp.z=playerZ_+7.0f*(float)slot;}cp.gamepadId=pads[slot];cp.paletteMap=slot;cp.animation.setAnimation(findAnimation(cp.model,"idle"));if(!cp.animation.frame())cp.animation.setAnimation(findAnimation(cp.model,"walk"));cp.scriptCtx.player=true;cp.scriptCtx.playerIndex=slot;cp.scriptCtx.local["self"]=std::uintptr_t(slot+1);cp.scriptCtx.local["player"]=(double)slot;coopPlayers_.push_back(std::move(cp));}
  smokeTrace("beginGame coop ready");
  if(stage_&&stage_->setWeapon>0){setPlayerWeaponIndex(stage_->setWeapon);for(auto&cp:coopPlayers_)setCoopWeaponIndex(cp,stage_->setWeapon);}
  smokeTrace("beginGame before audio stop");
  audio_.stopMusic();
  smokeTrace("beginGame after audio stop");
  if(stage_ && stage_->music && *stage_->music){ auto music=root_/"assets"/"openbor-data"/normalizeDataPath(stage_->music); if(!audio_.playMusic(music,stage_->musicLoop)) std::cerr<<"Stage music diagnostic: "<<audio_.lastError()<<"\n"; }
  else if(config_.autoPreviewMusic) previewMusic();
  smokeTrace("beginGame after music");
  frontendState_=FrontendState::Playing;saveProgress();smokeTrace("beginGame after saveProgress");
  playerScriptCtx_.player=true;playerScriptCtx_.playerIndex=0;playerScriptCtx_.local["self"]=std::uintptr_t(1);playerScriptCtx_.local["player"]=0.0;runModelScript(playerModel_->onSpawnScript,playerScriptCtx_,"player-onspawn");
  for(auto&cp:coopPlayers_)runModelScript(cp.model?cp.model->onSpawnScript:"",cp.scriptCtx,"coop-onspawn");
  smokeTrace("beginGame scripts complete");
  std::cout<<"New game started local_players="<<(1+coopPlayers_.size())<<"\n";
}
void Engine::updateFrontend(){
#ifdef _WIN32
  auto up=frontendKeyPressed(VK_UP)||frontendKeyPressed('W');
  auto down=frontendKeyPressed(VK_DOWN)||frontendKeyPressed('S');
  auto left=frontendKeyPressed(VK_LEFT)||frontendKeyPressed('A');
  auto right=frontendKeyPressed(VK_RIGHT)||frontendKeyPressed('D');
  auto accept=frontendKeyPressed(VK_RETURN)||frontendKeyPressed('J')||frontendKeyPressed('X')||gamepadButtonPressed((unsigned short)config_.padAttack);
  auto back=frontendKeyPressed(VK_ESCAPE)||frontendKeyPressed(VK_BACK)||gamepadButtonPressed((unsigned short)config_.padJump);
  up=up||gamepadButtonPressed(XINPUT_GAMEPAD_DPAD_UP);down=down||gamepadButtonPressed(XINPUT_GAMEPAD_DPAD_DOWN);left=left||gamepadButtonPressed(XINPUT_GAMEPAD_DPAD_LEFT);right=right||gamepadButtonPressed(XINPUT_GAMEPAD_DPAD_RIGHT);
  if(frontendState_==FrontendState::MainMenu){
    constexpr int count=5;if(up)menuIndex_=(menuIndex_+count-1)%count;if(down)menuIndex_=(menuIndex_+1)%count;
    if(accept){if(menuIndex_==0){
      campaignIndex_=0;if(campaignFirstStages_.size()>1)frontendState_=FrontendState::LevelSetSelect;else startCampaign(0);
    }else if(menuIndex_==1){if(loadProgress())frontendState_=FrontendState::Playing;}else if(menuIndex_==2){optionsFromPause_=false;optionIndex_=0;frontendState_=FrontendState::Options;}else if(menuIndex_==3)frontendState_=FrontendState::Controls;else frontendState_=FrontendState::Quit;}
  }else if(frontendState_==FrontendState::LevelSetSelect){
    int count=(int)campaignFirstStages_.size();if(count<=0){frontendState_=FrontendState::MainMenu;return;}if(up)campaignIndex_=(campaignIndex_+count-1)%count;if(down)campaignIndex_=(campaignIndex_+1)%count;if(back)frontendState_=FrontendState::MainMenu;else if(accept)startCampaign((std::size_t)campaignIndex_);
  }else if(frontendState_==FrontendState::CharacterSelect){
    std::vector<const generated::Character*> players;for(std::size_t i=0;i<generated::kCharacterCount;++i)if(lowerString(generated::kCharacters[i].type)=="player")players.push_back(&generated::kCharacters[i]);if(players.empty()&&generated::kCharacterCount)players.push_back(&generated::kCharacters[0]);
    if(!players.empty()){
      if(left)selectIndexes_[0]=(selectIndexes_[0]+(int)players.size()-1)%(int)players.size();if(right)selectIndexes_[0]=(selectIndexes_[0]+1)%(int)players.size();
      int pads[4]={config_.player1Gamepad,config_.player2Gamepad,config_.player3Gamepad,config_.player4Gamepad};
      for(int slot=0;slot<std::min(4,config_.maxPlayers);++slot){int pad=pads[slot];if(gamepadButtonPressedFor(pad,XINPUT_GAMEPAD_A)||gamepadButtonPressedFor(pad,XINPUT_GAMEPAD_START))joinedPlayers_[slot]=true;if(slot>0&&gamepadButtonPressedFor(pad,XINPUT_GAMEPAD_B))joinedPlayers_[slot]=false;if(joinedPlayers_[slot]){if(gamepadButtonPressedFor(pad,XINPUT_GAMEPAD_DPAD_LEFT))selectIndexes_[slot]=(selectIndexes_[slot]+(int)players.size()-1)%(int)players.size();if(gamepadButtonPressedFor(pad,XINPUT_GAMEPAD_DPAD_RIGHT))selectIndexes_[slot]=(selectIndexes_[slot]+1)%(int)players.size();}}
      if(back)frontendState_=FrontendState::MainMenu;else if(accept||gamepadButtonPressedFor(config_.player1Gamepad,XINPUT_GAMEPAD_START)){playerModel_=players[(std::size_t)selectIndexes_[0]];selectedPlayerIndex_=selectIndexes_[0];config_.activePlayers=0;for(int i=0;i<std::min(4,config_.maxPlayers);++i)if(joinedPlayers_[i])++config_.activePlayers;config_.activePlayers=std::max(1,config_.activePlayers);saveSettings();beginGame();}
    }
  }else if(frontendState_==FrontendState::Paused){
    constexpr int count=5;if(up)pauseIndex_=(pauseIndex_+count-1)%count;if(down)pauseIndex_=(pauseIndex_+1)%count;if(back){frontendState_=FrontendState::Playing;return;}if(accept){if(pauseIndex_==0)frontendState_=FrontendState::Playing;else if(pauseIndex_==1){optionsFromPause_=true;optionIndex_=0;frontendState_=FrontendState::Options;}else if(pauseIndex_==2)beginGame();else if(pauseIndex_==3){audio_.stopMusic();frontendState_=FrontendState::MainMenu;menuIndex_=0;}else frontendState_=FrontendState::Quit;}
  }else if(frontendState_==FrontendState::GameOver){if(accept){if(loadProgress())frontendState_=FrontendState::Playing;else frontendState_=FrontendState::MainMenu;}if(back)frontendState_=FrontendState::MainMenu;
  }else if(frontendState_==FrontendState::Controls){
    constexpr int count=22;
    if(waitingForKey_){if(controlCaptureDelay_>0)--controlCaptureDelay_;else{int k=captureAnyKey();if(k){int* binds[]={&config_.keyLeft,&config_.keyRight,&config_.keyUp,&config_.keyDown,&config_.keyAttack,&config_.keyJump,&config_.keyPickup,&config_.keyDash,&config_.keyGrab,&config_.keyThrow,&config_.keyRun};if(controlsIndex_>=0&&controlsIndex_<11)*binds[controlsIndex_]=k;waitingForKey_=false;saveSettings();}}}
    else if(waitingForPad_){if(controlCaptureDelay_>0)--controlCaptureDelay_;else{auto b=captureAnyGamepadButton(config_.player1Gamepad);if(b){int* binds[]={&config_.padAttack,&config_.padJump,&config_.padPickup,&config_.padDash,&config_.padGrab,&config_.padThrow};if(controlsIndex_>=11&&controlsIndex_<17)*binds[controlsIndex_-11]=(int)b;waitingForPad_=false;saveSettings();}}}
    else{if(up)controlsIndex_=(controlsIndex_+count-1)%count;if(down)controlsIndex_=(controlsIndex_+1)%count;int dir=right?1:(left?-1:0);if(controlsIndex_>=17&&controlsIndex_<=20&&dir!=0){int* pads[]={&config_.player1Gamepad,&config_.player2Gamepad,&config_.player3Gamepad,&config_.player4Gamepad};int idx=controlsIndex_-17;*pads[idx]=(*pads[idx]+(dir<0?3:1))%4;saveSettings();}else if(accept&&controlsIndex_<11){waitingForKey_=true;controlCaptureDelay_=8;}else if(accept&&controlsIndex_>=11&&controlsIndex_<17){waitingForPad_=true;controlCaptureDelay_=8;}else if((accept&&controlsIndex_==21)||back){waitingForKey_=waitingForPad_=false;frontendState_=FrontendState::MainMenu;saveSettings();}}
  }else if(frontendState_==FrontendState::Options){
    constexpr int count=11;if(up)optionIndex_=(optionIndex_+count-1)%count;if(down)optionIndex_=(optionIndex_+1)%count;int dir=right?1:(left?-1:0);
    if((accept||dir!=0)&&optionIndex_==0)config_.fullscreen=!config_.fullscreen;
    else if((accept||dir!=0)&&optionIndex_==1){static const int rw[]={640,960,1280,1920,2560};static const int rh[]={480,720,720,1080,1440};int cur=2;for(int i=0;i<5;++i)if(config_.width==rw[i]&&config_.height==rh[i])cur=i;cur=(cur+(dir<0?4:1))%5;config_.width=rw[cur];config_.height=rh[cur];}
    else if((accept||dir!=0)&&optionIndex_==2){static const int fps[]={60,120,144,0};int cur=0;for(int i=0;i<4;++i)if(config_.fpsLimit==fps[i])cur=i;cur=(cur+(dir<0?3:1))%4;config_.fpsLimit=fps[cur];}
    else if((accept||dir!=0)&&optionIndex_==3)config_.vsync=!config_.vsync;
    else if(accept&&optionIndex_==4){graphicsOptionIndex_=0;frontendState_=FrontendState::GraphicsOptions;}
    else if(dir!=0&&optionIndex_==5)audio_.setMasterVolume(audio_.masterVolume()+0.05f*(float)dir);
    else if(dir!=0&&optionIndex_==6)audio_.setMusicVolume(audio_.musicVolume()+0.05f*(float)dir);
    else if(dir!=0&&optionIndex_==7)audio_.setEffectsVolume(audio_.effectsVolume()+0.05f*(float)dir);
    else if((accept||dir!=0)&&optionIndex_==8)config_.showBBox=!config_.showBBox;
    else if((accept||dir!=0)&&optionIndex_==9)config_.showAttackBox=!config_.showAttackBox;
    else if((accept||back)&&optionIndex_==10){saveSettings();frontendState_=optionsFromPause_?FrontendState::Paused:FrontendState::MainMenu;}
    if(back&&optionIndex_!=10){saveSettings();frontendState_=optionsFromPause_?FrontendState::Paused:FrontendState::MainMenu;}if(accept||dir!=0)saveSettings();
  }else if(frontendState_==FrontendState::GraphicsOptions){
    constexpr int count=15;if(up)graphicsOptionIndex_=(graphicsOptionIndex_+count-1)%count;if(down)graphicsOptionIndex_=(graphicsOptionIndex_+1)%count;int dir=right?1:(left?-1:0);
    if((accept||dir!=0)&&graphicsOptionIndex_==0){static const char* p[]={"original","improved","crt","sharp"};int cur=0;for(int i=0;i<4;++i)if(config_.graphicsPreset==p[i])cur=i;cur=(cur+(dir<0?3:1))%4;applyGraphicsPreset(config_,p[cur]);}
    else if((accept||dir!=0)&&graphicsOptionIndex_==1){static const char* u[]={"original","sharp-bilinear","cas","xbrz-like"};int cur=0;for(int i=0;i<4;++i)if(config_.upscaleMode==u[i])cur=i;cur=(cur+(dir<0?3:1))%4;config_.upscaleMode=u[cur];config_.graphicsPreset="custom";}
    else if((accept||dir!=0)&&graphicsOptionIndex_==2){config_.pixelPerfect=!config_.pixelPerfect;config_.graphicsPreset="custom";}
    else if((accept||dir!=0)&&graphicsOptionIndex_==3){config_.keepAspect43=!config_.keepAspect43;if(config_.keepAspect43)config_.fill169=false;config_.graphicsPreset="custom";}
    else if((accept||dir!=0)&&graphicsOptionIndex_==4){config_.fill169=!config_.fill169;if(config_.fill169){config_.keepAspect43=false;config_.pixelPerfect=false;}config_.graphicsPreset="custom";}
    else if((accept||dir!=0)&&graphicsOptionIndex_==5){static const int sc[]={0,2,3,4};int cur=0;for(int i=0;i<4;++i)if(config_.integerScale==sc[i])cur=i;cur=(cur+(dir<0?3:1))%4;config_.integerScale=sc[cur];config_.graphicsPreset="custom";}
    else if((accept||dir!=0)&&graphicsOptionIndex_==6){config_.textureFilter=config_.textureFilter=="nearest"?"linear":"nearest";config_.graphicsPreset="custom";}
    else if((accept||dir!=0)&&graphicsOptionIndex_==7){config_.crt=!config_.crt;config_.graphicsPreset="custom";}
    else if((accept||dir!=0)&&graphicsOptionIndex_==8){config_.scanlines=!config_.scanlines;config_.graphicsPreset="custom";}
    else if((accept||dir!=0)&&graphicsOptionIndex_==9){config_.crtCurvature=!config_.crtCurvature;config_.graphicsPreset="custom";}
    else if((accept||dir!=0)&&graphicsOptionIndex_==10){config_.bloom=!config_.bloom;config_.graphicsPreset="custom";}
    else if(dir!=0&&graphicsOptionIndex_==11){config_.contrast=std::clamp(config_.contrast+0.05f*dir,0.5f,2.0f);config_.graphicsPreset="custom";}
    else if(dir!=0&&graphicsOptionIndex_==12){config_.saturation=std::clamp(config_.saturation+0.05f*dir,0.0f,2.0f);config_.graphicsPreset="custom";}
    else if((accept||dir!=0)&&graphicsOptionIndex_==13){config_.reduceBanding=!config_.reduceBanding;config_.graphicsPreset="custom";}
    else if(dir!=0&&graphicsOptionIndex_==14){config_.sharpen=std::clamp(config_.sharpen+0.05f*dir,0.0f,1.0f);config_.graphicsPreset="custom";}
    if(back){saveSettings();frontendState_=FrontendState::Options;}else if(accept||dir!=0)saveSettings();
  }
#else
  frontendState_=FrontendState::Playing;
#endif
}
void Engine::drawFrontend(){
  ++frontendTick_;const bool overGameplay=(frontendState_==FrontendState::Paused)||(frontendState_==FrontendState::Options&&optionsFromPause_)||(frontendState_==FrontendState::GraphicsOptions&&optionsFromPause_);
  const bool selectScreen=frontendState_==FrontendState::CharacterSelect;const SpriteImage* frontBg=selectScreen&&selectBackground_.width>0?&selectBackground_:&titleBackground_;
  if(overGameplay){drawStage();renderer_.drawSolidRect(8,22,304,210,18,18,24);}else{renderer_.beginFrame();if(frontBg->width>0)renderer_.drawImage(*frontBg,0,0);}
  const bool originalFrontend=!overGameplay&&frontBg->width>0;if(!originalFrontend){renderer_.drawText("OPENBOR NATIVE PORT",10,6,15,true);renderer_.drawText("OpenBOR Native Builder",11,25,8,false);}
  if(frontendState_==FrontendState::MainMenu){const char* items[]={"NEW GAME","CONTINUE","OPTIONS","CONTROLS","QUIT"};for(int i=0;i<5;++i)renderer_.drawText(items[i],28,62+i*29,13,i==menuIndex_);renderer_.drawText("ENTER/J select  UP/DOWN navigate",18,216,8,false);
  }else if(frontendState_==FrontendState::LevelSetSelect){renderer_.drawText("SELECT GAME",20,42,14,true);int count=(int)campaignNames_.size();int first=std::clamp(campaignIndex_-4,0,std::max(0,count-8));for(int row=0;row<8&&first+row<count;++row){int idx=first+row;renderer_.drawText(campaignNames_[(std::size_t)idx],28,68+row*20,10,idx==campaignIndex_);}renderer_.drawText("ENTER select   ESC back",20,220,7,false);
  }else if(frontendState_==FrontendState::CharacterSelect){if(selectBackground_.width<=0)renderer_.drawText("SELECT CHARACTERS",20,46,14,true);std::vector<const generated::Character*>players;for(std::size_t i=0;i<generated::kCharacterCount;++i)if(lowerString(generated::kCharacters[i].type)=="player")players.push_back(&generated::kCharacters[i]);if(players.empty()&&generated::kCharacterCount)players.push_back(&generated::kCharacters[0]);int activeSlots=0;for(int slot=0;slot<std::min(4,config_.maxPlayers);++slot)if(joinedPlayers_[slot])++activeSlots;if(!players.empty()){int drawSlot=0;for(int slot=0;slot<std::min(4,config_.maxPlayers);++slot){if(joinedPlayers_[slot]){auto*m=players[(std::size_t)std::clamp(selectIndexes_[slot],0,(int)players.size()-1)];drawSelectCharacterPreview(m,drawSlot++,std::max(1,activeSlots));}std::string line="P"+std::to_string(slot+1)+"  ";if(joinedPlayers_[slot])line+="< "+std::string(players[(std::size_t)std::clamp(selectIndexes_[slot],0,(int)players.size()-1)]->name)+" >";else line+="PRESS A/START TO JOIN";renderer_.drawText(line,22,60+slot*18,8,slot==0);}}renderer_.drawText("P1 arrows choose | pads D-PAD choose",14,std::max(150,config_.logicalHeight-30),7,false);renderer_.drawText("ENTER / P1 START begin   B leaves",14,std::max(166,config_.logicalHeight-14),7,false);
  }else if(frontendState_==FrontendState::Paused){renderer_.drawText("PAUSED",24,49,15,true);const char* items[]={"CONTINUE","OPTIONS","RESTART STAGE","MAIN MENU","QUIT"};for(int i=0;i<5;++i)renderer_.drawText(items[i],30,78+i*25,11,i==pauseIndex_);
  }else if(frontendState_==FrontendState::GameOver){renderer_.drawText("GAME OVER",78,92,24,true);renderer_.drawText("ENTER CONTINUE   ESC MAIN MENU",35,138,9,false);
  }else if(frontendState_==FrontendState::Controls){renderer_.drawText("CONTROLS / REMAP",18,43,13,true);std::vector<std::string>rows={"LEFT KEY: "+std::to_string(config_.keyLeft),"RIGHT KEY: "+std::to_string(config_.keyRight),"UP KEY: "+std::to_string(config_.keyUp),"DOWN KEY: "+std::to_string(config_.keyDown),legacyControlLabel("attack1","ATTACK")+" KEY: "+std::to_string(config_.keyAttack),"JUMP KEY: "+std::to_string(config_.keyJump),"PICKUP KEY: "+std::to_string(config_.keyPickup),"DASH KEY: "+std::to_string(config_.keyDash),"GRAB KEY: "+std::to_string(config_.keyGrab),"THROW KEY: "+std::to_string(config_.keyThrow),"RUN KEY: "+std::to_string(config_.keyRun),"PAD "+legacyControlLabel("attack1","ATTACK")+": "+std::to_string(config_.padAttack),"PAD JUMP: "+std::to_string(config_.padJump),"PAD PICKUP: "+std::to_string(config_.padPickup),"PAD DASH: "+std::to_string(config_.padDash),"PAD GRAB: "+std::to_string(config_.padGrab),"PAD THROW: "+std::to_string(config_.padThrow),"P1 GAMEPAD: "+std::to_string(config_.player1Gamepad+1),"P2 GAMEPAD: "+std::to_string(config_.player2Gamepad+1),"P3 GAMEPAD: "+std::to_string(config_.player3Gamepad+1),"P4 GAMEPAD: "+std::to_string(config_.player4Gamepad+1),"BACK"};int first=std::clamp(controlsIndex_-5,0,std::max(0,(int)rows.size()-10));for(int r=0;r<10&&first+r<(int)rows.size();++r){int idx=first+r;renderer_.drawText(rows[(std::size_t)idx],18,62+r*15,8,idx==controlsIndex_);}std::string help=waitingForKey_?"PRESS A NEW KEY...":(waitingForPad_?"PRESS A GAMEPAD BUTTON...":"ENTER remap | LEFT/RIGHT pad slot");renderer_.drawText(help,14,218,7,waitingForKey_||waitingForPad_);
  }else if(frontendState_==FrontendState::Options){renderer_.drawText("OPTIONS",18,44,14,true);std::vector<std::string>rows={std::string("FULLSCREEN: ")+(config_.fullscreen?"ON":"OFF"),"RESOLUTION: "+std::to_string(config_.width)+"x"+std::to_string(config_.height),"FPS: "+(config_.fpsLimit==0?std::string("UNLIMITED"):std::to_string(config_.fpsLimit)),std::string("V-SYNC: ")+(config_.vsync?"ON":"OFF"),"GRAPHICS...","MASTER: "+std::to_string((int)(audio_.masterVolume()*100))+"%","MUSIC: "+std::to_string((int)(audio_.musicVolume()*100))+"%","SFX: "+std::to_string((int)(audio_.effectsVolume()*100))+"%",std::string("SHOW BBOX: ")+(config_.showBBox?"ON":"OFF"),std::string("ATTACK BOX: ")+(config_.showAttackBox?"ON":"OFF"),"BACK"};for(int i=0;i<(int)rows.size();++i)renderer_.drawText(rows[(std::size_t)i],22,59+i*14,8,i==optionIndex_);renderer_.drawText("LEFT/RIGHT change",20,222,7,false);
  }else if(frontendState_==FrontendState::GraphicsOptions){renderer_.drawText("OPTIONS > GRAPHICS",12,42,13,true);auto on=[](bool v){return v?"ON":"OFF";};std::string scale=config_.integerScale==0?"AUTO":std::to_string(config_.integerScale)+"x";std::vector<std::string>rows={"PRESET: "+config_.graphicsPreset,"UPSCALE: "+config_.upscaleMode,std::string("PIXEL PERFECT: ")+on(config_.pixelPerfect),std::string("KEEP 4:3: ")+on(config_.keepAspect43),std::string("FILL 16:9: ")+on(config_.fill169),"INTEGER SCALE: "+scale,"TEXTURE: "+config_.textureFilter,std::string("CRT: ")+on(config_.crt),std::string("SCANLINES: ")+on(config_.scanlines),std::string("CURVATURE: ")+on(config_.crtCurvature),std::string("BLOOM: ")+on(config_.bloom),"CONTRAST: "+std::to_string((int)(config_.contrast*100))+"%","SATURATION: "+std::to_string((int)(config_.saturation*100))+"%",std::string("REDUCE BANDING: ")+on(config_.reduceBanding),"SHARPEN: "+std::to_string((int)(config_.sharpen*100))+"%"};int first=std::clamp(graphicsOptionIndex_-4,0,std::max(0,(int)rows.size()-9));for(int row=0;row<9&&first+row<(int)rows.size();++row){int idx=first+row;renderer_.drawText(rows[(std::size_t)idx],14,65+row*16,8,idx==graphicsOptionIndex_);}renderer_.drawText("ESC back  LEFT/RIGHT change",14,220,7,false);
  }
  renderer_.endFrame();
}
void Engine::previewMusic(){
  auto data=root_/"assets"/"openbor-data"; if(!std::filesystem::exists(data)) return; std::filesystem::path best; int bestScore=-1;
  for(const auto& e:std::filesystem::recursive_directory_iterator(data)){
    if(!e.is_regular_file()) continue; auto ext=lowerExt(e.path()); if(ext!=".bor"&&ext!=".wav"&&ext!=".ogg"&&ext!=".oga"&&ext!=".mp3"&&ext!=".flac") continue;
    auto generic=PathEncoding::utf8(e.path()); std::string low=lowerString(generic); int score=(ext==".bor"?30:ext==".wav"?20:10)+(low.find("music")!=std::string::npos?20:0);
    if(config_.preferredMusicFormat!="auto" && ext=="."+config_.preferredMusicFormat) score+=40; if(score>bestScore){bestScore=score;best=e.path();}
  }
  if(!best.empty()){ if(audio_.playMusic(best,true)) std::cout<<"Preview music: "<<PathEncoding::utf8(best)<<"\n"; else std::cerr<<"Music diagnostic: "<<PathEncoding::utf8(best)<<" -> "<<audio_.lastError()<<"\n"; }
}
void Engine::pollAudioHotkeys(){
#ifdef _WIN32
  static SHORT p2=0,p3=0,p4=0,p5=0,p6=0,p7=0; auto press=[](int vk,SHORT& prev){SHORT now=GetAsyncKeyState(vk);bool down=(now&0x8000)!=0,was=(prev&0x8000)!=0;prev=now;return down&&!was;}; bool changed=false;
  if(press(VK_F2,p2)){audio_.setMusicVolume(audio_.musicVolume()-0.05f);changed=true;} if(press(VK_F3,p3)){audio_.setMusicVolume(audio_.musicVolume()+0.05f);changed=true;}
  if(press(VK_F4,p4)){audio_.setEffectsVolume(audio_.effectsVolume()-0.05f);changed=true;} if(press(VK_F5,p5)){audio_.setEffectsVolume(audio_.effectsVolume()+0.05f);changed=true;}
  if(press(VK_F6,p6)){audio_.setMasterVolume(audio_.masterVolume()-0.05f);changed=true;} if(press(VK_F7,p7)){audio_.setMasterVolume(audio_.masterVolume()+0.05f);changed=true;}
  if(changed) std::cout<<"Audio settings: master="<<audio_.masterVolume()<<" music="<<audio_.musicVolume()<<" effects="<<audio_.effectsVolume()<<"\n";
#endif
}
void Engine::startPlayerAttack(){
  if(!playerAlive_ || !playerModel_ || playerHitStun_>0 || playerFallTicks_>0 || playerRecoveryTicks_>0 || grabbedEntity_>=0) return;
  if(playerAttackTicks_>0){ if(playerComboWindow_>0 && !playerJumping_) playerQueuedAttack_=true; return; }
  if(playerAttackCooldown_>0 && playerComboWindow_<=0 && !playerJumping_) return;
  const generated::Animation* attack=nullptr; int attackNumber=1;
  if(playerJumping_ || playerAltitude_<-0.1f){
    attack=findActionAnimation(playerModel_,equippedWeapon_,"jumpattack");
    if(!attack) attack=findActionAnimation(playerModel_,equippedWeapon_,"jumpforward");
  } else {
    if(playerComboWindow_<=0){playerComboStep_=0;playerComboBranch_=-1;}
    else if(playerAttackHasHit_ || playerModel_->comboStyle==2) ++playerComboStep_;
    else {playerComboStep_=0;playerComboBranch_=-1;}
    float cdx=99999.0f,cdz=99999.0f,cda=0.0f,best=1.0e30f;for(const auto&e:entities_)if(e.alive&&e.visible&&e.model&&modelCanDamage(playerModel_,e.model,true)){float dx=e.worldX-playerWorldX_,dz=e.z-playerZ_,d=std::fabs(dx)+std::fabs(dz);if(d<best){best=d;cdx=dx;cdz=dz;cda=e.altitude-playerAltitude_;}}
    attackNumber=dynamicChainAttackNumber(playerModel_,playerComboStep_,playerComboBranch_,cdx,cdz,cda);
    std::string wanted="attack"+std::to_string(attackNumber);
    attack=findActionAnimation(playerModel_,equippedWeapon_,wanted.c_str());
    if(!attack) attack=findActionAnimation(playerModel_,equippedWeapon_,"attack");
  }
  if(!attack) return;
  if(!beginEnergyAnimation(player_,attack,playerModel_,playerHealth_,playerMp_,playerEnergyPending_))return; lastFrame_=(std::size_t)-1; playerAttackTicks_=animationDuration(attack); playerAttackCooldown_=std::max(2,playerAttackTicks_/3);
  playerComboWindow_=playerJumping_?0:comboWindowFor(playerModel_,config_.comboWindow); playerQueuedAttack_=false; playerProjectileFired_=false; playerAnimJumpTriggered_=false; ++playerAttackId_;
  playerAttackHasHit_=false;playerAttackHits_=0;
  if(playerModel_->onDoAttackScript&&*playerModel_->onDoAttackScript){playerScriptCtx_.local["attack"]=(double)attackNumber;playerScriptCtx_.local["target"]=std::uintptr_t(0);runModelScript(playerModel_->onDoAttackScript,playerScriptCtx_,"player-ondoattack");}
  std::cout<<(playerJumping_?"Player air attack ":"Player combo attack ")<<attackNumber<<" chain="<<playerComboStep_<<" #"<<playerAttackId_<<" facing="<<(playerFacing_>0?"right":"left")<<"\n";
}
void Engine::startPlayerJump(bool running){
  if(!playerAlive_ || !playerModel_ || playerJumping_ || playerFallTicks_>0 || playerRecoveryTicks_>0 || playerHitStun_>0 || grabbedEntity_>=0) return;
  const bool runJump=running&&playerModel_->runSpeed>0.0f;
  float h=runJump&&playerModel_->runJumpHeight>0.0f?playerModel_->runJumpHeight:(float)std::max(1,playerModel_->jumpHeight); if(h<=0.0f) h=config_.jumpDefault;
  playerJumping_=true; playerRunningJump_=runJump; playerAltitude_=-dynamicPlatformHeight(playerWorldX_,playerZ_,nullptr,playerModel_)-0.1f; playerVerticalVelocity_=-std::fabs(h);
  float baseJumpSpeed=playerModel_->jumpSpeed>0.0f?playerModel_->jumpSpeed:std::max(0.0f,playerModel_->speed);
  float js=runJump?std::max(0.0f,playerModel_->runSpeed):baseJumpSpeed;
  if(runJump&&playerModel_->runJumpLength>0.0f)js*=playerModel_->runJumpLength;
  playerJumpVelocityX_=(float)playerFacing_*js; playerJumpVelocityZ_=0.0f;
  if(playerModel_->dustJumpModel&&*playerModel_->dustJumpModel)queueModelDust(playerModel_->dustJumpModel,playerWorldX_,playerZ_,playerFacing_,1);
  auto a=findActionAnimation(playerModel_,equippedWeapon_,"jump"); if(!a) a=findActionAnimation(playerModel_,equippedWeapon_,"jumpforward"); if(a){player_.setAnimation(a);lastFrame_=(std::size_t)-1;}
  std::cout<<"Player jump height="<<h<<" vx="<<playerJumpVelocityX_<<(runJump?" run":"")<<"\n";
}
void Engine::startPlayerDash(){
  if(!playerAlive_||!playerModel_||playerJumping_||playerFallTicks_>0||playerRecoveryTicks_>0||playerHitStun_>0||grabbedEntity_>=0)return;
  playerDashTicks_=config_.dashTicks; auto a=findActionAnimation(playerModel_,equippedWeapon_,"run"); if(a){player_.setAnimation(a);lastFrame_=(std::size_t)-1;}
  std::cout<<"Player dash facing="<<(playerFacing_>0?"right":"left")<<" ticks="<<playerDashTicks_<<"\n";
}
void Engine::setPlayerWeaponIndex(int index){
  if(index<=0){equippedWeapon_=nullptr;weaponUses_=0;return;}if(!playerModel_||!playerModel_->weapons||(std::size_t)index>playerModel_->weaponCount)return;const char* name=playerModel_->weapons[index-1];if(!name||!*name||lowerString(name)=="none")return;auto* w=findCharacter(name);if(!w)return;equippedWeapon_=w;weaponUses_=w->shootNum>0?w->shootNum:0;playerScriptCtx_.local["weapon"]=(double)index;runModelScript(w->onModelCopyScript,playerScriptCtx_,"player-onmodelcopy");std::cout<<"Player weapon index="<<index<<" model="<<w->name<<" uses="<<weaponUses_<<"\n";
}
void Engine::setCoopWeaponIndex(RuntimeCoopPlayer& cp,int index){
  if(index<=0){cp.equippedWeapon=nullptr;cp.weaponUses=0;return;}if(!cp.model||!cp.model->weapons||(std::size_t)index>cp.model->weaponCount)return;const char* name=cp.model->weapons[index-1];if(!name||!*name||lowerString(name)=="none")return;auto*w=findCharacter(name);if(!w)return;cp.equippedWeapon=w;cp.weaponUses=w->shootNum>0?w->shootNum:0;cp.scriptCtx.local["weapon"]=(double)index;runModelScript(w->onModelCopyScript,cp.scriptCtx,"coop-onmodelcopy");
}
void Engine::setEntityWeaponIndex(RuntimeEntity& e,int index){
  if(index<=0){e.equippedWeapon=nullptr;e.weaponUses=0;return;}if(!e.model||!e.model->weapons||(std::size_t)index>e.model->weaponCount)return;const char*name=e.model->weapons[index-1];if(!name||!*name||lowerString(name)=="none")return;auto*w=findCharacter(name);if(!w)return;e.equippedWeapon=w;e.weaponUses=w->shootNum>0?w->shootNum:0;e.scriptCtx.local["weapon"]=(double)index;runModelScript(w->onModelCopyScript,e.scriptCtx,"entity-onmodelcopy");
}
void Engine::tryPickupWeapon(){
  for(auto& e:entities_){
    if(!e.alive||!e.model) continue; auto t=lowerString(e.model->type),st=lowerString(e.model->subtype);bool weapon=(t=="item")&&(st.find("weapon")!=std::string::npos||st.find("project")!=std::string::npos||e.model->weaponNumber>0||e.model->reloadAmount>0||(e.model->projectModel&&*e.model->projectModel));if(!weapon)continue;
    if(std::fabs(e.worldX-playerWorldX_)>24.0f||std::fabs(e.z-playerZ_)>18.0f)continue;
    if(e.model->reloadAmount>0&&equippedWeapon_&&equippedWeapon_->shootNum>0){weaponUses_+=e.model->reloadAmount;e.alive=false;e.visible=false;std::cout<<"Ammo reload +"<<e.model->reloadAmount<<" uses="<<weaponUses_<<"\n";return;}
    if(e.model->weaponNumber>0){auto before=equippedWeapon_;setPlayerWeaponIndex(e.model->weaponNumber);if(equippedWeapon_!=before||equippedWeapon_){weaponItemModel_=e.model;weaponDropsRemaining_=e.weaponDropsRemaining>=0?e.weaponDropsRemaining:std::max(0,e.model->weaponDropCounter);e.alive=false;e.visible=false;return;}}
    if(st.find("project")!=std::string::npos||(e.model->projectModel&&*e.model->projectModel)){equippedWeapon_=e.model;weaponUses_=e.model->shootNum>0?e.model->shootNum:0;e.alive=false;e.visible=false;return;}
  }
}
void Engine::tryPickupWeapon(RuntimeCoopPlayer& cp){
  for(auto& e:entities_){if(!e.alive||!e.model)continue;auto t=lowerString(e.model->type),st=lowerString(e.model->subtype);bool weapon=(t=="item")&&(st.find("weapon")!=std::string::npos||st.find("project")!=std::string::npos||e.model->weaponNumber>0||e.model->reloadAmount>0||(e.model->projectModel&&*e.model->projectModel));if(!weapon)continue;if(std::fabs(e.worldX-cp.worldX)>24.0f||std::fabs(e.z-cp.z)>18.0f)continue;if(e.model->reloadAmount>0&&cp.equippedWeapon&&cp.equippedWeapon->shootNum>0){cp.weaponUses+=e.model->reloadAmount;e.alive=false;e.visible=false;return;}if(e.model->weaponNumber>0){auto before=cp.equippedWeapon;setCoopWeaponIndex(cp,e.model->weaponNumber);if(cp.equippedWeapon!=before||cp.equippedWeapon){cp.weaponItemModel=e.model;cp.weaponDropsRemaining=e.weaponDropsRemaining>=0?e.weaponDropsRemaining:std::max(0,e.model->weaponDropCounter);e.alive=false;e.visible=false;return;}}if(st.find("project")!=std::string::npos||(e.model->projectModel&&*e.model->projectModel)){cp.equippedWeapon=e.model;cp.weaponUses=e.model->shootNum>0?e.model->shootNum:0;e.alive=false;e.visible=false;return;}}
}
void Engine::spawnProjectile(const generated::Character* model,float x,float z,float altitude,int facing,float vx,float vy,float vz,bool bomb,bool fromPlayer,const generated::Character* ownerModel){
  if(!model) return; RuntimeProjectile p; p.model=model;p.ownerModel=ownerModel;p.worldX=x;p.z=z;p.altitude=altitude;p.facing=facing;p.vx=vx*(float)facing;p.vy=-vy;p.vz=vz;p.bomb=bomb;p.fromPlayer=fromPlayer;p.life=config_.projectileLifetime;
  p.subjectToGravity=bomb||model->subjectToGravity;p.bouncesLeft=std::max(0,model->bounce);p.bounceFactor=model->bounceFactor>0.0f?model->bounceFactor:0.5f;p.hitMask=model->projectileHitMask;
  p.animation.setAnimation(findAnimation(model,"idle")); if(!p.animation.frame()) p.animation.setAnimation(findAnimation(model,"attack1")); projectiles_.push_back(std::move(p));
  std::cout<<"Projectile spawned: "<<model->name<<" kind="<<(bomb?"bomb":"knife")<<" vx="<<vx*(float)facing<<" vy="<<-vy<<"\n";
}
void Engine::queueModelDust(const char* modelName,float x,float z,int facing,std::uintptr_t parent){
  if(!modelName||!*modelName)return;auto* model=findCharacter(modelName);if(!model)return;PendingChildSpawn q;q.animationEffect=true;q.effectSpawnType=10;q.model=model;q.worldX=x;q.z=z;q.altitude=0.0f;q.facing=facing;q.parent=parent;pendingChildSpawns_.push_back(q);
}
void Engine::queueChildSpawn(const generated::Character* owner,const generated::Animation* a,std::size_t frameIndex,float x,float z,float altitude,int facing,std::uintptr_t parent){
  if(!owner||!a||a->spawnFrame<0||(int)frameIndex!=a->spawnFrame)return;if(a->summonFrame){for(const auto&e:entities_)if(e.alive&&e.summonedChild&&e.parentHandle==parent)return;for(const auto&q:pendingChildSpawns_)if(q.summon&&q.parent==parent)return;}std::string name=(a->custEntity&&*a->custEntity)?a->custEntity:(owner->subEntityModel?owner->subEntityModel:"");if(name.empty())return;auto* model=findCharacter(name.c_str());if(!model){std::cerr<<"Child model missing: "<<name<<"\n";return;}PendingChildSpawn q;q.model=model;q.facing=facing;q.parent=parent;q.summon=a->summonFrame;q.worldX=a->spawnScreenRelative?cameraX_+a->spawnOffsetX:x+a->spawnOffsetX*(float)facing;q.z=z+a->spawnOffsetZ;q.altitude=altitude-a->spawnOffsetA;pendingChildSpawns_.push_back(q);
}
void Engine::flushChildSpawns(){
  if(pendingChildSpawns_.empty())return;auto pending=std::move(pendingChildSpawns_);pendingChildSpawns_.clear();for(const auto&q:pending){if(!q.model)continue;RuntimeEntity e;e.animationEffect=q.animationEffect;e.effectSpawnType=q.effectSpawnType;e.model=q.model;e.subjectToScreen=q.model->subjectToScreen;e.weaponDropsRemaining=std::max(0,q.model->weaponDropCounter);e.worldX=q.worldX;e.z=q.z;e.altitude=q.altitude;e.facing=q.facing;e.parentHandle=q.parent;e.summonedChild=q.summon;e.maxHealth=e.health=std::max(1,q.model->health);e.maxMp=e.mp=std::max(0,q.model->mp);e.lifeTicks=q.model->lifespanSeconds>0.0f?std::max(1,(int)std::lround(q.model->lifespanSeconds*60.0f)):-1;e.juggleRemaining=std::max(1,q.model->jugglePoints);e.guardPoints=q.model->guardPoints;auto a=findAnimation(q.model,"spawn");if(!a)a=findAnimation(q.model,"idle");if(!a)a=findAnimation(q.model,"walk");e.animation.setAnimation(a);entities_.push_back(std::move(e));auto& spawned=entities_.back();spawned.scriptCtx.entity=&spawned;spawned.scriptCtx.local["self"]=std::uintptr_t((std::uintptr_t)&spawned);spawned.scriptCtx.local["parent"]=q.parent;spawned.scriptCtx.local["spawn_type"]=q.animationEffect?(double)q.effectSpawnType:(q.summon?3.0:2.0);runModelScript(spawned.model->onSpawnScript,spawned.scriptCtx,"child-onspawn");std::cout<<"Child spawn model="<<spawned.model->name<<" parent="<<q.parent<<" summon="<<(q.summon?"yes":"no")<<"\n";}
}
void Engine::unsummonChildren(std::uintptr_t parent,bool allChildren){
  for(auto& e:entities_){if(!e.alive||e.parentHandle!=parent)continue;if(!allChildren&&!e.summonedChild)continue;e.alive=false;e.deathTicks=0;e.scriptCtx.local["trigger"]=1.0;runModelScript(e.model?e.model->onKillScript:"",e.scriptCtx,"child-unsummon");e.visible=false;}
}
void Engine::updateChildFollowing(RuntimeEntity& e){
  if(!e.alive||!e.model||e.parentHandle==0||e.model->noMove)return;std::string st=lowerString(e.model->subtype?e.model->subtype:"");if(st.find("follow")==std::string::npos&&e.model->childFollowRange<=0.0f)return;float px=0,pz=0,pa=0;int pf=1;bool found=false;if(e.parentHandle==1){if(playerAlive_){px=playerWorldX_;pz=playerZ_;pa=playerAltitude_;pf=playerFacing_;found=true;}}else if(e.parentHandle>=2&&e.parentHandle<=4){std::size_t i=(std::size_t)e.parentHandle-2;if(i<coopPlayers_.size()&&coopPlayers_[i].alive){auto&cp=coopPlayers_[i];px=cp.worldX;pz=cp.z;pa=cp.altitude;pf=cp.facing;found=true;}}else{for(auto&p:entities_)if((std::uintptr_t)&p==e.parentHandle&&p.alive){px=p.worldX;pz=p.z;pa=p.altitude;pf=p.facing;found=true;break;}}if(!found)return;
  float tx=px+e.model->childFollowOffsetX*(float)pf,tz=pz+e.model->childFollowOffsetZ,ta=pa-e.model->childFollowOffsetY;float dx=tx-e.worldX,dz=tz-e.z,da=ta-e.altitude;
  auto outside=[](float v,float mn,float mx){return v<mn||v>mx;};bool recall=outside(dx,e.model->childRecallRangeXMin,e.model->childRecallRangeXMax)||outside(dz,e.model->childRecallRangeZMin,e.model->childRecallRangeZMax)||outside(da,e.model->childRecallRangeYMin,e.model->childRecallRangeYMax);bool follow=outside(dx,e.model->childFollowRangeXMin,e.model->childFollowRangeXMax)||outside(dz,e.model->childFollowRangeZMin,e.model->childFollowRangeZMax)||outside(da,e.model->childFollowRangeYMin,e.model->childFollowRangeYMax);
  if(recall){e.worldX=px+(e.model->childRecallOffsetX+e.model->childFollowOffsetX)*(float)pf;e.z=pz+e.model->childRecallOffsetZ+e.model->childFollowOffsetZ;e.altitude=pa-e.model->childRecallOffsetY-e.model->childFollowOffsetY;e.facing=pf;auto*a=findAnimation(e.model,(e.model->childRecallAnimation&&*e.model->childRecallAnimation)?e.model->childRecallAnimation:"respawn");if(!a)a=findAnimation(e.model,"spawn");if(a)setEntityAnimation(e,a);return;}
  switch(e.model->childDirectionAdjust){case 1:e.facing=pf;break;case 2:e.facing=-pf;break;case 3:e.facing=-1;break;case 4:e.facing=1;break;case 5:e.facing=dx<0?1:-1;break;case 6:e.facing=dx<0?-1:1;break;default:if(std::fabs(dx)>1)e.facing=dx<0?-1:1;break;}
  if(follow){float dist=std::sqrt(dx*dx+dz*dz+da*da),speed=std::max(0.0f,e.model->runSpeed>0?e.model->runSpeed:e.model->speed);if(dist>0.001f&&speed>0.0f){e.worldX+=dx/dist*speed;e.z+=dz/dist*speed;e.altitude+=da/dist*std::min(speed,1.5f);}auto*w=findAnimation(e.model,e.model->runSpeed>0?"run":"walk");if(w&&e.animation.animation()!=w)setEntityAnimation(e,w);}else if(e.attackTicks<=0&&e.hitStun<=0&&e.fallTicks<=0){auto*i=findAnimation(e.model,"idle");if(i&&e.animation.animation()!=i)setEntityAnimation(e,i);}
}
void Engine::queueWeaponDrop(const generated::Character* item,float x,float z,float altitude,int facing,int remaining){if(!item||remaining<=0)return;PendingWeaponDrop q;q.itemModel=item;q.worldX=x;q.z=z;q.altitude=altitude;q.facing=facing;q.remainingDrops=remaining;pendingWeaponDrops_.push_back(q);}
void Engine::flushWeaponDrops(){
  if(pendingWeaponDrops_.empty())return;auto q=std::move(pendingWeaponDrops_);pendingWeaponDrops_.clear();for(const auto&d:q){if(!d.itemModel||d.remainingDrops<=0)continue;RuntimeEntity e;e.model=d.itemModel;e.subjectToScreen=d.itemModel->subjectToScreen;e.worldX=d.worldX+12.0f*(float)d.facing;e.z=d.z;e.altitude=d.altitude;e.facing=d.facing;e.weaponDropsRemaining=d.remainingDrops;e.maxHealth=e.health=std::max(1,d.itemModel->health);auto*a=findAnimation(d.itemModel,"respawn");if(!a)a=findAnimation(d.itemModel,"spawn");if(!a)a=findAnimation(d.itemModel,"idle");e.animation.setAnimation(a);entities_.push_back(std::move(e));auto&drop=entities_.back();drop.scriptCtx.entity=&drop;drop.scriptCtx.local["self"]=std::uintptr_t((std::uintptr_t)&drop);runModelScript(drop.model->onSpawnScript,drop.scriptCtx,"weapon-drop");}
}
void Engine::dropPlayerWeapon(bool stageLoss){if(!equippedWeapon_)return;const auto*spec=equippedWeapon_->weaponLossDefined?equippedWeapon_:playerModel_;int remaining=weaponDropsRemaining_;if(remaining<0&&weaponItemModel_)remaining=std::max(0,weaponItemModel_->weaponDropCounter);if(!stageLoss&&weaponItemModel_&&remaining>1)queueWeaponDrop(weaponItemModel_,playerWorldX_,playerZ_,playerAltitude_,playerFacing_,remaining-1);int loss=spec?std::max(0,spec->weaponLossIndex):0;setPlayerWeaponIndex(loss);weaponItemModel_=nullptr;weaponDropsRemaining_=-1;}
void Engine::dropCoopWeapon(RuntimeCoopPlayer&cp,bool stageLoss){if(!cp.equippedWeapon)return;const auto*spec=cp.equippedWeapon->weaponLossDefined?cp.equippedWeapon:cp.model;int remaining=cp.weaponDropsRemaining;if(remaining<0&&cp.weaponItemModel)remaining=std::max(0,cp.weaponItemModel->weaponDropCounter);if(!stageLoss&&cp.weaponItemModel&&remaining>1)queueWeaponDrop(cp.weaponItemModel,cp.worldX,cp.z,cp.altitude,cp.facing,remaining-1);int loss=spec?std::max(0,spec->weaponLossIndex):0;setCoopWeaponIndex(cp,loss);cp.weaponItemModel=nullptr;cp.weaponDropsRemaining=-1;}
void Engine::dropEntityWeapon(RuntimeEntity&e,bool stageLoss){if(!e.equippedWeapon)return;const auto*spec=e.equippedWeapon->weaponLossDefined?e.equippedWeapon:e.model;int remaining=e.weaponDropsRemaining;if(remaining<0&&e.weaponItemModel)remaining=std::max(0,e.weaponItemModel->weaponDropCounter);if(!stageLoss&&e.weaponItemModel&&remaining>1)queueWeaponDrop(e.weaponItemModel,e.worldX,e.z,e.altitude,e.facing,remaining-1);int loss=spec?std::max(0,spec->weaponLossIndex):0;setEntityWeaponIndex(e,loss);e.weaponItemModel=nullptr;e.weaponDropsRemaining=-1;}
void Engine::maybeSpawnProjectile(const generated::Character* owner,const generated::Animation* a,std::size_t frameIndex,float x,float z,float altitude,int facing,bool fromPlayer,bool& firedFlag,const generated::Character* equippedOverride,int* weaponUses){
  if(!owner||!a||firedFlag)return; bool bomb=false;int trigger=a->throwFrame;std::string modelName=a->custKnife?a->custKnife:"";
  if(trigger<0 && a->tossFrame>=0){trigger=a->tossFrame;bomb=true;modelName=a->custBomb?a->custBomb:"";}
  if(trigger<0)return; if((int)frameIndex<trigger)return;
  const generated::Character* equipped=equippedOverride?equippedOverride:(fromPlayer?equippedWeapon_:nullptr);
  if(modelName.empty() && equipped){ if(bomb&&equipped->bombModel&&*equipped->bombModel)modelName=equipped->bombModel; else if(equipped->projectModel&&*equipped->projectModel)modelName=equipped->projectModel; else if(equipped->knifeModel&&*equipped->knifeModel)modelName=equipped->knifeModel; }
  if(modelName.empty()){ if(bomb && owner->bombModel)modelName=owner->bombModel; else if(owner->projectModel&&*owner->projectModel)modelName=owner->projectModel; else if(owner->knifeModel)modelName=owner->knifeModel; }
  auto model=findCharacter(modelName.c_str()); if(!model){ if(!modelName.empty())std::cerr<<"Projectile model missing: "<<modelName<<"\n"; firedFlag=true;return; }
  float vy=a->projectileVelocityY; if(bomb && std::fabs(vy)<0.001f)vy=(float)std::max(1,model->jumpHeight);
  spawnProjectile(model,x,z,altitude-(float)a->projectileOffsetY,facing,a->projectileVelocityX,vy,a->projectileVelocityZ,bomb,fromPlayer,owner); firedFlag=true;if(equipped&&equipped->shootNum>0&&weaponUses&&*weaponUses>0){--*weaponUses;}
}
void Engine::updatePlayer(){
  settleAnimationEnergy(playerEnergyPending_,player_,playerHealth_,playerMp_);
  if(playerInvincibleTicks_>0)--playerInvincibleTicks_;
  if(!playerModel_ || !playerAlive_) return; float dx=0,dz=0; bool attackPressed=false,grabPressed=false,throwPressed=false,jumpPressed=false,dashPressed=false,pickupPressed=false,running=false;
  bool leftHeld=false,rightHeld=false,upHeld=false,downHeld=false,attackHeld=false,grabHeld=false,throwHeld=false,jumpHeld=false,dashHeld=false,pickupHeld=false,startHeld=false,escHeld=false;
#ifdef _WIN32
  static bool attackWasDown=false,grabWasDown=false,throwWasDown=false,jumpWasDown=false,dashWasDown=false,pickupWasDown=false;
  bool attackDown=(GetAsyncKeyState(config_.keyAttack)&0x8000)!=0;
  bool grabDown=(GetAsyncKeyState(config_.keyGrab)&0x8000)!=0, throwDown=(GetAsyncKeyState(config_.keyThrow)&0x8000)!=0;
  bool jumpDown=(GetAsyncKeyState(config_.keyJump)&0x8000)!=0, dashDown=(GetAsyncKeyState(config_.keyDash)&0x8000)!=0, pickupDown=(GetAsyncKeyState(config_.keyPickup)&0x8000)!=0;
  leftHeld=(GetAsyncKeyState(config_.keyLeft)&0x8000)!=0;rightHeld=(GetAsyncKeyState(config_.keyRight)&0x8000)!=0;upHeld=(GetAsyncKeyState(config_.keyUp)&0x8000)!=0;downHeld=(GetAsyncKeyState(config_.keyDown)&0x8000)!=0;
  attackHeld=attackDown;grabHeld=grabDown;throwHeld=throwDown;jumpHeld=jumpDown;dashHeld=dashDown;pickupHeld=pickupDown;startHeld=(GetAsyncKeyState(VK_RETURN)&0x8000)!=0;escHeld=(GetAsyncKeyState(VK_ESCAPE)&0x8000)!=0;
  attackPressed=attackDown&&!attackWasDown; grabPressed=grabDown&&!grabWasDown; throwPressed=throwDown&&!throwWasDown; jumpPressed=jumpDown&&!jumpWasDown;dashPressed=dashDown&&!dashWasDown;pickupPressed=pickupDown&&!pickupWasDown;
  attackWasDown=attackDown; grabWasDown=grabDown; throwWasDown=throwDown;jumpWasDown=jumpDown;dashWasDown=dashDown;pickupWasDown=pickupDown;
  running=(GetAsyncKeyState(config_.keyRun)&0x8000)!=0;
  if(config_.gamepad){XINPUT_STATE xs{};if(XInputGetState((DWORD)std::clamp(config_.player1Gamepad,0,3),&xs)==ERROR_SUCCESS){auto&g=xs.Gamepad;const int dead=7849;float gx=std::abs((int)g.sThumbLX)>dead?(float)g.sThumbLX/32767.0f:0.0f;float gy=std::abs((int)g.sThumbLY)>dead?-(float)g.sThumbLY/32767.0f:0.0f;if(std::fabs(gx)>std::fabs(dx))dx=gx;if(std::fabs(gy)>std::fabs(dz))dz=gy;leftHeld=leftHeld||gx<-0.25f||(g.wButtons&XINPUT_GAMEPAD_DPAD_LEFT);rightHeld=rightHeld||gx>0.25f||(g.wButtons&XINPUT_GAMEPAD_DPAD_RIGHT);upHeld=upHeld||gy<-0.25f||(g.wButtons&XINPUT_GAMEPAD_DPAD_UP);downHeld=downHeld||gy>0.25f||(g.wButtons&XINPUT_GAMEPAD_DPAD_DOWN);attackHeld=attackHeld||(g.wButtons&(unsigned short)config_.padAttack);jumpHeld=jumpHeld||(g.wButtons&(unsigned short)config_.padJump);pickupHeld=pickupHeld||(g.wButtons&(unsigned short)config_.padPickup);grabHeld=grabHeld||(g.wButtons&(unsigned short)config_.padGrab);dashHeld=dashHeld||(g.wButtons&(unsigned short)config_.padDash);throwHeld=throwHeld||(g.wButtons&(unsigned short)config_.padThrow);startHeld=startHeld||(g.wButtons&XINPUT_GAMEPAD_START);attackPressed=attackPressed||gamepadButtonPressed((unsigned short)config_.padAttack);jumpPressed=jumpPressed||gamepadButtonPressed((unsigned short)config_.padJump);pickupPressed=pickupPressed||gamepadButtonPressed((unsigned short)config_.padPickup);grabPressed=grabPressed||gamepadButtonPressed((unsigned short)config_.padGrab);dashPressed=dashPressed||gamepadButtonPressed((unsigned short)config_.padDash);throwPressed=throwPressed||gamepadButtonPressed((unsigned short)config_.padThrow);running=running||(g.bRightTrigger>80);}}
  if(smokeMode_){
    leftHeld=rightHeld=upHeld=downHeld=attackHeld=grabHeld=throwHeld=jumpHeld=dashHeld=pickupHeld=startHeld=escHeld=false;
    dx=scrollDir_<0?-1.0f:1.0f; dz=((tickCounter_/90)%2==0)?0.18f:-0.18f; running=true;
    leftHeld=dx<0; rightHeld=dx>0; upHeld=dz<0; downHeld=dz>0;
    attackPressed=(tickCounter_%45u)==10u; attackHeld=attackPressed;
    jumpPressed=(tickCounter_%180u)==70u; jumpHeld=jumpPressed;
    dashPressed=(tickCounter_%240u)==120u; dashHeld=dashPressed;
    pickupPressed=tickCounter_==2u; pickupHeld=pickupPressed;
  }
  if(playerHitStun_<=0 && playerFallTicks_<=0 && playerRecoveryTicks_<=0 && grabbedEntity_<0){
    if(GetAsyncKeyState(config_.keyLeft)&0x8000) dx-=1; if(GetAsyncKeyState(config_.keyRight)&0x8000) dx+=1;
    if(GetAsyncKeyState(config_.keyUp)&0x8000) dz-=1; if(GetAsyncKeyState(config_.keyDown)&0x8000) dz+=1;
  }
#else
  float nearest=99999.0f; for(const auto& e:entities_) if(e.alive && !e.grabbed && e.model && lowerString(e.model->type)=="enemy") nearest=std::min(nearest,std::fabs(e.worldX-playerWorldX_));
  if(tickCounter_==2){pickupPressed=true;pickupHeld=true;}
  if(playerHitStun_<=0 && playerFallTicks_<=0 && playerRecoveryTicks_<=0 && !playerJumping_ && grabbedEntity_<0){ dx = scrollDir_<0 ? -1.0f : 1.0f;leftHeld=dx<0;rightHeld=dx>0; }
  attackHeld=attackPressed;jumpHeld=jumpPressed;grabHeld=grabPressed;throwHeld=throwPressed;dashHeld=dashPressed;
#endif
  unsigned rawKeys=(leftHeld?SK_LEFT:0u)|(rightHeld?SK_RIGHT:0u)|(upHeld?SK_UP:0u)|(downHeld?SK_DOWN:0u)|(attackHeld?SK_ATTACK:0u)|(jumpHeld?SK_JUMP:0u)|(dashHeld?SK_SPECIAL:0u)|(startHeld?SK_START:0u)|(escHeld?SK_ESC:0u)|(grabHeld?SK_ATTACK2:0u)|(throwHeld?SK_ATTACK3:0u)|(pickupHeld?SK_ATTACK4:0u);
  rawKeys&=~playerDisabledKeys_[0];playerNewKeys_[0]=rawKeys&~playerKeys_[0];playerReleasedKeys_[0]=playerKeys_[0]&~rawKeys;playerKeys_[0]=rawKeys;playerPlayKeys_[0]=rawKeys;
  playerScriptCtx_.player=true;playerScriptCtx_.playerIndex=0;playerScriptCtx_.local["self"]=std::uintptr_t(1);playerScriptCtx_.local["player"]=0.0;
  if(playerNewKeys_[0]||playerReleasedKeys_[0]){
    if(playerModel_->keyScript&&*playerModel_->keyScript)runModelScript(playerModel_->keyScript,playerScriptCtx_,"player-key");
    const auto keySpecific=std::string("scripts/key")+std::to_string(playerScriptCtx_.playerIndex+1)+".c";
    if(std::filesystem::exists(root_/"assets"/"openbor-data"/keySpecific))runModelScript(keySpecific.c_str(),playerScriptCtx_,"global-key-player");
    if(std::filesystem::exists(root_/"assets"/"openbor-data"/"scripts"/"keyall.c"))runModelScript("scripts/keyall.c",playerScriptCtx_,"global-key-all");
  }
  runModelScript(playerModel_->thinkScript,playerScriptCtx_,"player-think");runModelScript(playerModel_->updateScript,playerScriptCtx_,"player-update");
  unsigned play=playerPlayKeys_[0];if(!(play&SK_ATTACK))attackPressed=false;if(!(play&SK_ATTACK2))grabPressed=false;if(!(play&SK_ATTACK3))throwPressed=false;if(!(play&SK_ATTACK4))pickupPressed=false;if(!(play&SK_JUMP))jumpPressed=false;if(!(play&SK_SPECIAL))dashPressed=false;if(dx<0&&!(play&SK_LEFT))dx=0;if(dx>0&&!(play&SK_RIGHT))dx=0;if(dz<0&&!(play&SK_UP))dz=0;if(dz>0&&!(play&SK_DOWN))dz=0;
  if(playerModel_->noMove)dx=dz=0; if(!playerModel_->noFlip&&playerModel_->facingAdjust==0){if(dx<0) playerFacing_=-1; else if(dx>0) playerFacing_=1;} playerFacing_=modelFacingValue(playerModel_,playerFacing_,scrollDir_);
  recordInputHistory(0);
  // holdblock 1 keeps the native block animation/state active while Special is held.
  // Releasing Special clears the forced state; blockpain can temporarily interrupt
  // the animation and the held input resumes blocking on the following tick.
  if(playerModel_->holdBlock&&findAnimation(playerModel_,"block")&&playerHitStun_<=0&&playerFallTicks_<=0&&playerRecoveryTicks_<=0&&grabbedEntity_<0){constexpr int BS_ACTIVE=1;bool held=(playerPlayKeys_[0]&SK_SPECIAL)!=0;if(held){playerBlockState_|=BS_ACTIVE;dashPressed=false;if(playerAttackTicks_<=0){auto*b=findAnimation(playerModel_,"block");if(b&&player_.animation()!=b){player_.setAnimation(b);lastFrame_=(std::size_t)-1;}}}else if((playerBlockState_&BS_ACTIVE)!=0){playerBlockState_&=~BS_ACTIVE;auto n=player_.animation()?lowerString(player_.animation()->name?player_.animation()->name:""):std::string{};if(n.rfind("block",0)==0){player_.setAnimation(findActionAnimation(playerModel_,equippedWeapon_,"idle"));lastFrame_=(std::size_t)-1;}}}
  const generated::Character* commandModel=equippedWeapon_?equippedWeapon_:playerModel_;
  bool commandActivated=false;
  const generated::Animation* chargeAnim=findActionAnimation(playerModel_,equippedWeapon_,"chargeattack");
  const bool deferChargePress=chargeAnim&&chargeAnim->chargeTime>0&&((playerNewKeys_[0]&SK_ATTACK)!=0);
  const bool chargeReleased=chargeAnim&&chargeAnim->chargeTime>0&&((playerReleasedKeys_[0]&SK_ATTACK)!=0);
  if(deferChargePress)attackPressed=false;
  if(playerAttackTicks_<=0&&playerHitStun_<=0&&playerFallTicks_<=0&&playerRecoveryTicks_<=0&&grabbedEntity_<0){if(auto* special=commandTarget(commandModel,0,playerFacing_);special&&beginEnergyAnimation(player_,special,playerModel_,playerHealth_,playerMp_,playerEnergyPending_)){lastFrame_=(std::size_t)-1;playerAttackTicks_=animationDuration(special);playerAttackCooldown_=std::max(2,playerAttackTicks_/3);playerComboWindow_=0;playerQueuedAttack_=false;playerProjectileFired_=false;playerAttackHasHit_=false;playerAttackHits_=0;++playerAttackId_;commandActivated=true;attackPressed=jumpPressed=dashPressed=grabPressed=throwPressed=pickupPressed=false;if(commandModel&&commandModel->onDoAttackScript&&*commandModel->onDoAttackScript){playerScriptCtx_.local["attack"]=std::string(special->name?special->name:"freespecial");playerScriptCtx_.local["target"]=std::uintptr_t(0);runModelScript(commandModel->onDoAttackScript,playerScriptCtx_,"player-com");}}}
  if(playerAttackTicks_>0&&!commandActivated){if(auto* ca=cancelTarget(commandModel,player_.animation(),player_.frameIndex(),playerAttackHits_,0,playerFacing_);ca&&beginEnergyAnimation(player_,ca,playerModel_,playerHealth_,playerMp_,playerEnergyPending_)){lastFrame_=(std::size_t)-1;playerAttackTicks_=animationDuration(ca);playerAttackCooldown_=std::max(2,playerAttackTicks_/3);playerAttackHasHit_=false;playerAttackHits_=0;playerProjectileFired_=false;++playerAttackId_;attackPressed=false;jumpPressed=false;}}
  if(!commandActivated&&chargeReleased&&playerAttackTicks_<=0&&playerHitStun_<=0&&playerFallTicks_<=0&&playerRecoveryTicks_<=0&&grabbedEntity_<0){
    int held=heldDuration(playerInputHistory_[0],(std::ptrdiff_t)playerInputHistory_[0].size()-1,SK_ATTACK);int threshold=std::max(1,(int)std::lround(chargeAnim->chargeTime*0.6f));
    if(held>=threshold&&beginEnergyAnimation(player_,chargeAnim,playerModel_,playerHealth_,playerMp_,playerEnergyPending_)){lastFrame_=(std::size_t)-1;playerAttackTicks_=animationDuration(chargeAnim);playerAttackCooldown_=std::max(2,playerAttackTicks_/3);playerComboWindow_=0;playerQueuedAttack_=false;playerProjectileFired_=false;playerAttackHasHit_=false;playerAttackHits_=0;++playerAttackId_;commandActivated=true;}
    else attackPressed=true;
  }
  if(!commandActivated){if(pickupPressed) tryPickupWeapon(); if(jumpPressed) startPlayerJump(running); if(dashPressed) startPlayerDash(); if(grabPressed) tryGrabNearest(); if(throwPressed) throwGrabbed(); if(attackPressed) startPlayerAttack();}
  if(playerAttackCooldown_>0) --playerAttackCooldown_; if(playerComboWindow_>0) --playerComboWindow_; else if(playerAttackTicks_<=0) playerComboStep_=0;
  float playerGround=-dynamicPlatformHeight(playerWorldX_,playerZ_,nullptr,playerModel_);
  if((playerFallTicks_>0||playerAltitude_<playerGround-0.1f) && !playerJumping_){
    // walkoffmove mirrors jumpmove's air-control intent when an actor simply walks
    // off a raised platform. Knockdown/fall reactions intentionally do not get it.
    if(playerFallTicks_<=0){float airSpeed=std::max(0.0f,playerModel_->speed)*0.7f;if(playerModel_->walkoffMoveX>=2)playerWorldX_+=dx*airSpeed;if(playerModel_->walkoffMoveZ!=0)playerZ_+=dz*airSpeed;playerWorldX_=std::clamp(playerWorldX_,0.0f,std::max(0.0f,stageLength_-1.0f));if(stage_){if(playerModel_->subjectToMinZ)playerZ_=std::max(playerZ_,(float)stage_->zMin);if(playerModel_->subjectToMaxZ)playerZ_=std::min(playerZ_,(float)stage_->zMax);}}
    if(playerFallTicks_>0)--playerFallTicks_; float beforeVy=playerVerticalVelocity_; playerAltitude_+=playerVerticalVelocity_; playerVerticalVelocity_+=config_.gravity*(1.0f-actorAntigravity(1,playerModel_)); applyDropFrameOnApex(player_,beforeVy,playerVerticalVelocity_);
    if(playerAltitude_>=playerGround){
      if(playerLandingDamage_>0&&playerAlive_){
        playerHealth_=std::max(0,playerHealth_-effectiveDamage(playerModel_,playerLandingDamage_,playerLandingType_));
        if(playerHealth_==0){playerAlive_=false;runModelScript(playerModel_?playerModel_->onDeathScript:"",playerScriptCtx_,"player-ondeath");playDieSound(playerModel_);auto*d=findAnimation(playerModel_,"death");if(!d)d=findAnimation(playerModel_,"fall");player_.setAnimation(d);lastFrame_=(std::size_t)-1;std::cout<<"GAME OVER\n";}
      }
      playerLandingDamage_=0;playerLandingMode_=0;playerLandingType_=-1;playerAltitude_=playerGround;playerVerticalVelocity_=0;playerFallTicks_=0;
      if(!playerAlive_){playerFallTicks_=0;playerRecoveryTicks_=0;return;}
      if(playerModel_->dustFallModel&&*playerModel_->dustFallModel)queueModelDust(playerModel_->dustFallModel,playerWorldX_,playerZ_,playerFacing_,1);auto*landAnim=player_.animation();bool hasLandFrame=landAnim&&landAnim->landFrame>=0;applyLandFrame(player_,playerWorldX_,playerZ_,playerFacing_,1);lastFrame_=(std::size_t)-1;
      if(playerFallTicks_<=0){playerRecoveryTicks_=hasLandFrame?animationDuration(landAnim,player_.frameIndex()):config_.recoveryTicks;if(!hasLandFrame){auto r=reactionAnimation(playerModel_,"rise",playerReactionType_);if(!r)r=findAnimation(playerModel_,"rise");if(r)player_.setAnimation(r);}}
    }
    player_.update(1);return;
  }
  if(playerJumping_){
    float oldAirX=playerWorldX_,oldAirZ=playerZ_;
    float airAdjust=(playerModel_->jumpMoveX>=2?0.10f:0.0f);playerJumpVelocityX_+=dx*airAdjust*(float)playerFacing_;bool airZ=playerRunningJump_?playerModel_->runMoveZ:playerModel_->jumpMoveZ;playerJumpVelocityZ_+=dz*(airZ?0.08f:0.0f);
    playerWorldX_+=playerJumpVelocityX_;playerZ_+=playerJumpVelocityZ_;float beforeVy=playerVerticalVelocity_;playerAltitude_+=playerVerticalVelocity_;playerVerticalVelocity_+=config_.gravity*(1.0f-actorAntigravity(1,playerModel_));applyDropFrameOnApex(player_,beforeVy,playerVerticalVelocity_);
    if(playerAttackTicks_>0){maybeSpawnProjectile(playerModel_,player_.animation(),player_.frameIndex(),playerWorldX_,playerZ_,playerAltitude_,playerFacing_,true,playerProjectileFired_,equippedWeapon_,&weaponUses_);if(equippedWeapon_&&equippedWeapon_->shootNum>0&&weaponUses_<=0){if(equippedWeapon_->typeShot&&weaponItemModel_)dropPlayerWeapon();else setPlayerWeaponIndex(0);}--playerAttackTicks_;player_.update(1);}
    else player_.update(1);
    float jumpGround=-dynamicPlatformHeight(playerWorldX_,playerZ_,nullptr,playerModel_);if(playerAltitude_>=jumpGround){playerAltitude_=jumpGround;playerVerticalVelocity_=0;playerJumpVelocityX_=playerJumpVelocityZ_=0;playerJumping_=false;playerAttackTicks_=0;playerProjectileFired_=false;if(playerModel_->dustLandModel&&*playerModel_->dustLandModel)queueModelDust(playerModel_->dustLandModel,playerWorldX_,playerZ_,playerFacing_,1);auto*landAnim=player_.animation();if(landAnim&&landAnim->landFrame>=0){applyLandFrame(player_,playerWorldX_,playerZ_,playerFacing_,1);playerRecoveryTicks_=animationDuration(landAnim,player_.frameIndex());}else{auto land=findAnimation(playerModel_,"land");player_.setAnimation(land?land:findActionAnimation(playerModel_,equippedWeapon_,"idle"));}if(playerRunningJump_&&playerModel_->runLand&&(playerKeys_[0]&(playerFacing_>0?SK_RIGHT:SK_LEFT))){playerDashTicks_=std::max(playerDashTicks_,2);}playerRunningJump_=false;lastFrame_=(std::size_t)-1;std::cout<<"Player landed\n";}
    playerWorldX_=std::clamp(playerWorldX_,0.0f,std::max(0.0f,stageLength_-1.0f));if(stage_){if(playerModel_->subjectToMinZ)playerZ_=std::max(playerZ_,(float)stage_->zMin);if(playerModel_->subjectToMaxZ)playerZ_=std::min(playerZ_,(float)stage_->zMax);}applyStageGeometry(oldAirX,oldAirZ);return;
  }
  if(playerRecoveryTicks_>0){--playerRecoveryTicks_;player_.update(1);if(playerRecoveryTicks_==0){if(playerModel_->riseInv>0)playerInvincibleTicks_=std::max(playerInvincibleTicks_,playerModel_->riseInv*60);player_.setAnimation(findActionAnimation(playerModel_,equippedWeapon_,"idle"));lastFrame_=(std::size_t)-1;}return;}
  if(playerHitStun_>0){--playerHitStun_;player_.update(1);if(playerHitStun_==0){player_.setAnimation(findActionAnimation(playerModel_,equippedWeapon_,"idle"));lastFrame_=(std::size_t)-1;}return;}
  if(playerAttackTicks_>0){
    auto active=player_.animation();
    maybeSpawnProjectile(playerModel_,active,player_.frameIndex(),playerWorldX_,playerZ_,playerAltitude_,playerFacing_,true,playerProjectileFired_,equippedWeapon_,&weaponUses_);if(equippedWeapon_&&equippedWeapon_->shootNum>0&&weaponUses_<=0){if(equippedWeapon_->typeShot&&weaponItemModel_)dropPlayerWeapon();else setPlayerWeaponIndex(0);}
    if(active && active->jumpFrame>=0 && !playerAnimJumpTriggered_ && (int)player_.frameIndex()>=active->jumpFrame){
      playerAnimJumpTriggered_=true;playerJumping_=true;playerAltitude_=-dynamicPlatformHeight(playerWorldX_,playerZ_,nullptr,playerModel_)-0.1f;float jy=std::fabs(active->jumpVelocityY)>0.001f?active->jumpVelocityY:(float)std::max(1,playerModel_->jumpHeight);playerVerticalVelocity_=-std::fabs(jy);playerJumpVelocityX_=active->jumpVelocityX*(float)playerFacing_;playerJumpVelocityZ_=active->jumpVelocityZ;std::cout<<"jumpframe triggered y="<<jy<<" x="<<playerJumpVelocityX_<<" z="<<playerJumpVelocityZ_<<"\n";
    }
    --playerAttackTicks_;player_.update(1);if(playerAttackTicks_==0&&!playerJumping_){if(playerQueuedAttack_){playerAttackCooldown_=0;startPlayerAttack();}else{player_.setAnimation(findActionAnimation(playerModel_,equippedWeapon_,"idle"));lastFrame_=(std::size_t)-1;}}return;}
  if(grabbedEntity_>=0){if((std::size_t)grabbedEntity_<entities_.size()){auto& e=entities_[(std::size_t)grabbedEntity_];e.worldX=playerWorldX_+(float)(playerFacing_*14);e.z=playerZ_;}player_.update(1);return;}
  float walk=std::max(0.0f,playerModel_->speed),run=playerModel_->runSpeed>0?playerModel_->runSpeed:walk*config_.runMultiplier;float speed=running?run:walk;
  if(playerDashTicks_>0){--playerDashTicks_;dx=(float)playerFacing_;speed=std::max(config_.dashSpeed,run);}
  float oldX=playerWorldX_,oldZ=playerZ_;playerWorldX_+=dx*speed+playerScriptVelocityX_;playerZ_+=dz*speed+playerScriptVelocityZ_;float unclampedX=playerWorldX_,unclampedZ=playerZ_;playerWorldX_=std::clamp(playerWorldX_,0.0f,std::max(0.0f,stageLength_-1.0f));if(playerWorldX_!=unclampedX&&playerModel_->onBlockSScript&&*playerModel_->onBlockSScript){playerScriptCtx_.local["plane"]=0.0;runModelScript(playerModel_->onBlockSScript,playerScriptCtx_,"player-onblocks");}if(stage_){if(playerModel_->subjectToMinZ)playerZ_=std::max(playerZ_,(float)stage_->zMin);if(playerModel_->subjectToMaxZ)playerZ_=std::min(playerZ_,(float)stage_->zMax);if(playerZ_!=unclampedZ&&playerModel_->onBlockZScript&&*playerModel_->onBlockZScript){playerScriptCtx_.local["plane"]=1.0;runModelScript(playerModel_->onBlockZScript,playerScriptCtx_,"player-onblockz");}}applyStageGeometry(oldX,oldZ);
  if(std::fabs(playerWorldX_-oldX)>0.001f&&playerModel_->onMoveXScript&&*playerModel_->onMoveXScript){playerScriptCtx_.local["movex"]=double(playerWorldX_-oldX);runModelScript(playerModel_->onMoveXScript,playerScriptCtx_,"player-onmovex");}
  if(std::fabs(playerZ_-oldZ)>0.001f&&playerModel_->onMoveZScript&&*playerModel_->onMoveZScript){playerScriptCtx_.local["movez"]=double(playerZ_-oldZ);runModelScript(playerModel_->onMoveZScript,playerScriptCtx_,"player-onmovez");}
  const char* anim=(dx!=0||dz!=0)?((running||playerDashTicks_>0)?"run":"walk"):"idle";const generated::Animation* wanted=findActionAnimation(playerModel_,equippedWeapon_,anim);if(wanted&&wanted!=player_.animation()){player_.setAnimation(wanted);lastFrame_=(std::size_t)-1;}player_.update(1);
}
void Engine::updateCoopPlayers(){
  for(std::size_t ci=0;ci<coopPlayers_.size();++ci){auto& cp=coopPlayers_[ci];settleAnimationEnergy(cp.energyPending,cp.animation,cp.health,cp.mp);if(cp.invincibleTicks>0)--cp.invincibleTicks;int slot=(int)ci+1;
    if(!cp.model)continue;if(!cp.alive){cp.animation.update(1);continue;}
    float dx=0.0f,dz=0.0f;bool attackPressed=false,jumpPressed=false,pickupPressed=false,running=false;unsigned rawKeys=0;
#ifdef _WIN32
    XINPUT_STATE xs{};if(config_.gamepad&&XInputGetState((DWORD)std::clamp(cp.gamepadId,0,3),&xs)==ERROR_SUCCESS){auto&g=xs.Gamepad;const int dead=7849;float gx=std::abs((int)g.sThumbLX)>dead?(float)g.sThumbLX/32767.0f:0.0f;float gy=std::abs((int)g.sThumbLY)>dead?-(float)g.sThumbLY/32767.0f:0.0f;dx=gx;dz=gy;if(g.wButtons&XINPUT_GAMEPAD_DPAD_LEFT)dx=-1;if(g.wButtons&XINPUT_GAMEPAD_DPAD_RIGHT)dx=1;if(g.wButtons&XINPUT_GAMEPAD_DPAD_UP)dz=-1;if(g.wButtons&XINPUT_GAMEPAD_DPAD_DOWN)dz=1;if(dx<-.25f)rawKeys|=SK_LEFT;if(dx>.25f)rawKeys|=SK_RIGHT;if(dz<-.25f)rawKeys|=SK_UP;if(dz>.25f)rawKeys|=SK_DOWN;if(g.wButtons&(unsigned short)config_.padAttack)rawKeys|=SK_ATTACK;if(g.wButtons&(unsigned short)config_.padJump)rawKeys|=SK_JUMP;if(g.wButtons&(unsigned short)config_.padGrab)rawKeys|=SK_ATTACK2;if(g.wButtons&(unsigned short)config_.padThrow)rawKeys|=SK_ATTACK3;if(g.wButtons&(unsigned short)config_.padPickup)rawKeys|=SK_ATTACK4;if(g.wButtons&(unsigned short)config_.padDash)rawKeys|=SK_SPECIAL;if(g.wButtons&XINPUT_GAMEPAD_START)rawKeys|=SK_START;attackPressed=gamepadButtonPressedFor(cp.gamepadId,(unsigned short)config_.padAttack);jumpPressed=gamepadButtonPressedFor(cp.gamepadId,(unsigned short)config_.padJump);pickupPressed=gamepadButtonPressedFor(cp.gamepadId,(unsigned short)config_.padPickup);running=g.bRightTrigger>80;}
#else
    if(tickCounter_%120<60){dx=0.35f;rawKeys|=SK_RIGHT;} if(tickCounter_%90==10){attackPressed=true;rawKeys|=SK_ATTACK;}
#endif
    rawKeys&=~playerDisabledKeys_[slot];playerNewKeys_[slot]=rawKeys&~playerKeys_[slot];playerReleasedKeys_[slot]=playerKeys_[slot]&~rawKeys;playerKeys_[slot]=rawKeys;playerPlayKeys_[slot]=rawKeys;
    cp.scriptCtx.player=true;cp.scriptCtx.playerIndex=slot;cp.scriptCtx.local["self"]=std::uintptr_t(slot+1);cp.scriptCtx.local["player"]=(double)slot;
    if(playerNewKeys_[slot]||playerReleasedKeys_[slot]){if(cp.model->keyScript&&*cp.model->keyScript)runModelScript(cp.model->keyScript,cp.scriptCtx,"coop-key");auto keySpecific=std::string("scripts/key")+std::to_string(slot+1)+".c";if(std::filesystem::exists(root_/"assets"/"openbor-data"/keySpecific))runModelScript(keySpecific.c_str(),cp.scriptCtx,"global-key-player");if(std::filesystem::exists(root_/"assets"/"openbor-data"/"scripts"/"keyall.c"))runModelScript("scripts/keyall.c",cp.scriptCtx,"global-key-all");}
    runModelScript(cp.model->thinkScript,cp.scriptCtx,"coop-think");runModelScript(cp.model->updateScript,cp.scriptCtx,"coop-update");
    if(!(playerPlayKeys_[slot]&SK_ATTACK))attackPressed=false;if(!(playerPlayKeys_[slot]&SK_JUMP))jumpPressed=false;if(!(playerPlayKeys_[slot]&SK_ATTACK4))pickupPressed=false;if(dx<0&&!(playerPlayKeys_[slot]&SK_LEFT))dx=0;if(dx>0&&!(playerPlayKeys_[slot]&SK_RIGHT))dx=0;if(dz<0&&!(playerPlayKeys_[slot]&SK_UP))dz=0;if(dz>0&&!(playerPlayKeys_[slot]&SK_DOWN))dz=0;if(cp.model->noMove)dx=dz=0;if(!cp.model->noFlip&&cp.model->facingAdjust==0){if(dx<0)cp.facing=-1;else if(dx>0)cp.facing=1;}cp.facing=modelFacingValue(cp.model,cp.facing,scrollDir_);recordInputHistory(slot);if(pickupPressed)tryPickupWeapon(cp);
    const generated::Animation* coopCharge=findActionAnimation(cp.model,cp.equippedWeapon,"chargeattack");const bool coopChargePress=coopCharge&&coopCharge->chargeTime>0&&((playerNewKeys_[slot]&SK_ATTACK)!=0);const bool coopChargeRelease=coopCharge&&coopCharge->chargeTime>0&&((playerReleasedKeys_[slot]&SK_ATTACK)!=0);if(coopChargePress)attackPressed=false;
    if(cp.model->holdBlock&&findAnimation(cp.model,"block")&&cp.hitStun<=0&&!cp.jumping){constexpr int BS_ACTIVE=1;bool held=(playerPlayKeys_[slot]&SK_SPECIAL)!=0;if(held){cp.blockState|=BS_ACTIVE;if(cp.attackTicks<=0){auto*b=findAnimation(cp.model,"block");if(b&&cp.animation.animation()!=b){cp.animation.setAnimation(b);cp.lastFrame=(std::size_t)-1;}}}else if((cp.blockState&BS_ACTIVE)!=0){cp.blockState&=~BS_ACTIVE;auto n=cp.animation.animation()?lowerString(cp.animation.animation()->name?cp.animation.animation()->name:""):std::string{};if(n.rfind("block",0)==0){cp.animation.setAnimation(findActionAnimation(cp.model,cp.equippedWeapon,"idle"));cp.lastFrame=(std::size_t)-1;}}}
    if(cp.hitStun>0){--cp.hitStun;if(!cp.jumping){cp.animation.update(1);continue;}}
    if(cp.attackCooldown>0)--cp.attackCooldown;
    const generated::Character* commandModel=cp.equippedWeapon?cp.equippedWeapon:cp.model;bool commandActivated=false;if(cp.attackTicks<=0&&!cp.jumping){if(auto*special=commandTarget(commandModel,slot,cp.facing);special&&beginEnergyAnimation(cp.animation,special,cp.model,cp.health,cp.mp,cp.energyPending)){cp.lastFrame=(std::size_t)-1;cp.attackTicks=animationDuration(special);cp.attackCooldown=std::max(2,cp.attackTicks/3);cp.comboWindow=0;cp.projectileFired=false;cp.attackHasHit=false;cp.attackHits=0;++cp.attackId;commandActivated=true;attackPressed=jumpPressed=false;if(commandModel&&commandModel->onDoAttackScript&&*commandModel->onDoAttackScript){cp.scriptCtx.local["attack"]=std::string(special->name?special->name:"freespecial");cp.scriptCtx.local["target"]=std::uintptr_t(0);runModelScript(commandModel->onDoAttackScript,cp.scriptCtx,"coop-com");}}}
    if(jumpPressed&&!cp.jumping&&!commandActivated){cp.jumping=true;cp.knockdownAir=false;cp.runningJump=running&&cp.model->runSpeed>0.0f;cp.altitude=-dynamicPlatformHeight(cp.worldX,cp.z,nullptr,cp.model)-0.1f;float jh=cp.runningJump&&cp.model->runJumpHeight>0.0f?cp.model->runJumpHeight:(float)std::max(1,cp.model->jumpHeight);cp.verticalVelocity=-std::fabs(jh);if(cp.model->dustJumpModel&&*cp.model->dustJumpModel)queueModelDust(cp.model->dustJumpModel,cp.worldX,cp.z,cp.facing,(std::uintptr_t)slot+1);auto a=findActionAnimation(cp.model,cp.equippedWeapon,"jump");if(a)cp.animation.setAnimation(a);cp.lastFrame=(std::size_t)-1;}
    if(cp.comboWindow>0)--cp.comboWindow;else if(cp.attackTicks<=0){cp.comboStep=0;cp.comboBranch=-1;}
    if(cp.attackTicks>0&&!commandActivated){if(auto* ca=cancelTarget(commandModel,cp.animation.animation(),cp.animation.frameIndex(),cp.attackHits,slot,cp.facing);ca&&beginEnergyAnimation(cp.animation,ca,cp.model,cp.health,cp.mp,cp.energyPending)){cp.lastFrame=(std::size_t)-1;cp.attackTicks=animationDuration(ca);cp.attackCooldown=std::max(2,cp.attackTicks/3);cp.attackHasHit=false;cp.attackHits=0;cp.projectileFired=false;++cp.attackId;attackPressed=false;jumpPressed=false;}}
    if(!commandActivated&&coopChargeRelease&&cp.attackTicks<=0&&cp.attackCooldown<=0&&!cp.jumping){int held=heldDuration(playerInputHistory_[slot],(std::ptrdiff_t)playerInputHistory_[slot].size()-1,SK_ATTACK);int threshold=std::max(1,(int)std::lround(coopCharge->chargeTime*0.6f));if(held>=threshold&&beginEnergyAnimation(cp.animation,coopCharge,cp.model,cp.health,cp.mp,cp.energyPending)){cp.attackTicks=animationDuration(coopCharge);cp.attackCooldown=std::max(2,cp.attackTicks/3);cp.comboWindow=0;cp.attackHasHit=false;cp.attackHits=0;cp.projectileFired=false;++cp.attackId;cp.lastFrame=(std::size_t)-1;commandActivated=true;}else attackPressed=true;}
    if(!commandActivated&&attackPressed&&cp.attackTicks<=0&&cp.attackCooldown<=0){const generated::Animation* a=nullptr;int attackNumber=1;if(cp.jumping)a=findActionAnimation(cp.model,cp.equippedWeapon,"jumpattack");else{if(cp.comboWindow<=0){cp.comboStep=0;cp.comboBranch=-1;}else if(cp.attackHasHit||cp.model->comboStyle==2)++cp.comboStep;else{cp.comboStep=0;cp.comboBranch=-1;}float cdx=99999.0f,cdz=99999.0f,cda=0.0f,best=1.0e30f;for(const auto&e:entities_)if(e.alive&&e.visible&&e.model&&modelCanDamage(cp.model,e.model,true)){float tx=e.worldX-cp.worldX,tz=e.z-cp.z,d=std::fabs(tx)+std::fabs(tz);if(d<best){best=d;cdx=tx;cdz=tz;cda=e.altitude-cp.altitude;}}attackNumber=dynamicChainAttackNumber(cp.model,cp.comboStep,cp.comboBranch,cdx,cdz,cda);std::string wanted="attack"+std::to_string(attackNumber);a=findActionAnimation(cp.model,cp.equippedWeapon,wanted.c_str());}if(!a)a=findActionAnimation(cp.model,cp.equippedWeapon,"attack1");if(!a)a=findActionAnimation(cp.model,cp.equippedWeapon,"attack");if(a&&beginEnergyAnimation(cp.animation,a,cp.model,cp.health,cp.mp,cp.energyPending)){cp.attackTicks=animationDuration(a);cp.attackCooldown=std::max(2,cp.attackTicks/3);cp.comboWindow=comboWindowFor(cp.model,config_.comboWindow);cp.attackHasHit=false;cp.attackHits=0;cp.projectileFired=false;cp.attackId+=1;if(cp.attackId==0)cp.attackId=1;cp.lastFrame=(std::size_t)-1;if(cp.model->onDoAttackScript&&*cp.model->onDoAttackScript){cp.scriptCtx.local["attack"]=(double)attackNumber;cp.scriptCtx.local["target"]=std::uintptr_t(0);runModelScript(cp.model->onDoAttackScript,cp.scriptCtx,"coop-ondoattack");}}}
    float oldX=cp.worldX,oldZ=cp.z;
    cp.worldX+=cp.scriptVelocityX;cp.z+=cp.scriptVelocityZ;
    float coopGround=-dynamicPlatformHeight(cp.worldX,cp.z,nullptr,cp.model);
    bool coopWalkoff=!cp.jumping&&cp.altitude<coopGround-0.1f;
    if(cp.jumping||coopWalkoff){float airScale=cp.runningJump&&cp.model->runJumpLength>0.0f?std::max(0.7f,cp.model->runJumpLength):0.7f;if(cp.jumping||cp.model->walkoffMoveX>=2)cp.worldX+=dx*airScale;if(cp.jumping?(!cp.runningJump||cp.model->runMoveZ):(cp.model->walkoffMoveZ!=0))cp.z+=dz*0.7f;float beforeVy=cp.verticalVelocity;cp.altitude+=cp.verticalVelocity;cp.verticalVelocity+=config_.gravity*(1.0f-actorAntigravity(std::uintptr_t((&cp-&coopPlayers_[0])+2),cp.model));applyDropFrameOnApex(cp.animation,beforeVy,cp.verticalVelocity);cp.animation.update(1);coopGround=-dynamicPlatformHeight(cp.worldX,cp.z,nullptr,cp.model);if(cp.altitude>=coopGround){
        if(cp.landingDamage>0&&cp.alive){cp.health=std::max(0,cp.health-effectiveDamage(cp.model,cp.landingDamage,cp.landingType));if(cp.health==0){cp.alive=false;runModelScript(cp.model?cp.model->onDeathScript:"",cp.scriptCtx,"coop-ondeath");playDieSound(cp.model);auto*d=findAnimation(cp.model,"death");if(!d)d=findAnimation(cp.model,"fall");cp.animation.setAnimation(d);cp.lastFrame=(std::size_t)-1;}}
        cp.landingDamage=0;cp.landingMode=0;cp.landingType=-1;cp.altitude=coopGround;cp.verticalVelocity=0;cp.jumping=false;bool wasKnockdown=cp.knockdownAir;const char* dustName=wasKnockdown?cp.model->dustFallModel:cp.model->dustLandModel;if(dustName&&*dustName)queueModelDust(dustName,cp.worldX,cp.z,cp.facing,(std::uintptr_t)slot+1);cp.knockdownAir=false;cp.runningJump=false;if(wasKnockdown&&cp.model->riseInv>0)cp.invincibleTicks=std::max(cp.invincibleTicks,cp.model->riseInv*60);
        if(cp.alive){auto*la=cp.animation.animation();bool hasLandFrame=la&&la->landFrame>=0;applyLandFrame(cp.animation,cp.worldX,cp.z,cp.facing,(std::uintptr_t)slot+1);cp.lastFrame=(std::size_t)-1;if(hasLandFrame)cp.hitStun=std::max(cp.hitStun,animationDuration(la,cp.animation.frameIndex()));else if(cp.attackTicks<=0)cp.animation.setAnimation(findActionAnimation(cp.model,cp.equippedWeapon,"idle"));}
      }}
    else if(cp.attackTicks>0){maybeSpawnProjectile(cp.model,cp.animation.animation(),cp.animation.frameIndex(),cp.worldX,cp.z,cp.altitude,cp.facing,true,cp.projectileFired,cp.equippedWeapon,&cp.weaponUses);if(cp.equippedWeapon&&cp.equippedWeapon->shootNum>0&&cp.weaponUses<=0){if(cp.equippedWeapon->typeShot&&cp.weaponItemModel)dropCoopWeapon(cp);else setCoopWeaponIndex(cp,0);}--cp.attackTicks;cp.animation.update(1);if(cp.attackTicks==0){cp.projectileFired=false;cp.animation.setAnimation(findActionAnimation(cp.model,cp.equippedWeapon,"idle"));}}
    else{float walk=std::max(0.0f,cp.model->speed),run=cp.model->runSpeed>0?cp.model->runSpeed:walk*config_.runMultiplier;float speed=running?run:walk;cp.worldX+=dx*speed;cp.z+=dz*speed;cp.worldX=std::clamp(cp.worldX,cameraX_+4.0f,std::min(stageLength_-1.0f,cameraX_+(float)config_.logicalWidth-4.0f));if(stage_){if(cp.model->subjectToMinZ)cp.z=std::max(cp.z,(float)stage_->zMin);if(cp.model->subjectToMaxZ)cp.z=std::min(cp.z,(float)stage_->zMax);}const generated::Animation* wanted=findActionAnimation(cp.model,cp.equippedWeapon,(dx!=0||dz!=0)?(running?"run":"walk"):"idle");if(wanted&&wanted!=cp.animation.animation()){cp.animation.setAnimation(wanted);cp.lastFrame=(std::size_t)-1;}cp.animation.update(1);}
    if(applyActorTerrain(cp.model,cp.scriptCtx,cp.worldX,cp.z,cp.altitude,oldX,oldZ)){cp.health=std::max(1,cp.health-10);cp.worldX=(float)stage_->playerStartX+18.0f*(float)(ci+1);cp.z=(float)stage_->playerStartZ+7.0f*(float)(ci+1);}
    if(std::fabs(cp.worldX-oldX)>0.001f&&cp.model->onMoveXScript&&*cp.model->onMoveXScript){cp.scriptCtx.local["movex"]=(double)(cp.worldX-oldX);runModelScript(cp.model->onMoveXScript,cp.scriptCtx,"coop-onmovex");}
    if(std::fabs(cp.z-oldZ)>0.001f&&cp.model->onMoveZScript&&*cp.model->onMoveZScript){cp.scriptCtx.local["movez"]=(double)(cp.z-oldZ);runModelScript(cp.model->onMoveZScript,cp.scriptCtx,"coop-onmovez");}
  }
}
void Engine::startEnemyAttack(RuntimeEntity& e,float targetDistance,std::uintptr_t targetHandle){
  if(!e.alive || !e.model || e.attackCooldown>0 || e.attackTicks>0 || e.fallTicks>0 || e.recoveryTicks>0 || e.grabbed) return;
  constexpr int AI_NOATTACK=0x00000004,AI_ALWAYS=0x00000008,AI_LONG=0x00000001,AI_MELEE=0x00000002;
  if((e.model->aiAttack&AI_NOATTACK)!=0)return;
  std::vector<const generated::Animation*> all,projectile,melee;const generated::Character* attackModel=e.equippedWeapon?e.equippedWeapon:e.model;auto collectAttacks=[&](const generated::Character* src){if(!src)return;for(std::size_t i=0;i<src->animationCount;++i){auto* a=&src->animations[i];std::string n=lowerString(a->name?a->name:"");if(n=="attack"||n.rfind("attack",0)==0||n.rfind("shoot",0)==0||n.rfind("throw",0)==0){all.push_back(a);if(animationHasProjectile(a))projectile.push_back(a);else melee.push_back(a);}}};collectAttacks(attackModel);if(all.empty()&&attackModel!=e.model)collectAttacks(e.model);
  const generated::Character* targetModel=nullptr;bool targetGrounded=true;if(targetHandle>=1&&targetHandle<=4){if(targetHandle==1){targetModel=playerModel_;targetGrounded=std::fabs(playerAltitude_+dynamicPlatformHeight(playerWorldX_,playerZ_,nullptr,playerModel_))<2.0f&&!playerJumping_&&playerFallTicks_<=0;}else{std::size_t ci=(std::size_t)targetHandle-2;if(ci<coopPlayers_.size()){auto&cp=coopPlayers_[ci];targetModel=cp.model;targetGrounded=std::fabs(cp.altitude+dynamicPlatformHeight(cp.worldX,cp.z,nullptr,cp.model))<2.0f&&!cp.jumping;}}}else if(targetHandle>4){for(auto&other:entities_)if((std::uintptr_t)&other==targetHandle){targetModel=other.model;targetGrounded=other.fallTicks<=0&&std::fabs(other.altitude+dynamicPlatformHeight(other.worldX,other.z,&other,other.model))<2.0f;break;}}
  const generated::Animation* a=nullptr;auto* grab=findAnimation(attackModel,"grab");float grabRange=(float)std::max(config_.grabRange,e.model->grabDistance);if(grab&&targetModel&&!targetModel->noGrab&&targetGrounded&&e.model->grabForce>=targetModel->grabResistance&&targetDistance<=grabRange)a=grab;
  if(all.empty()&&!a)return;bool wantsLong=(e.model->aiAttack&AI_LONG)!=0||targetDistance>(float)config_.enemyAttackRange*1.15f;bool wantsMelee=(e.model->aiAttack&AI_MELEE)!=0;
  auto pick=[&](const std::vector<const generated::Animation*>& list)->const generated::Animation*{if(list.empty())return nullptr;std::size_t idx=(std::size_t)((tickCounter_+(unsigned long long)std::max(0,e.model->aggression))%list.size());return list[idx];};
  if(!a&&wantsLong)a=pick(projectile);if(!a&&wantsMelee)a=pick(melee);if(!a)a=pick(all);if(!a)return;
  if(!beginEnergyAnimation(e.animation,a,e.model,e.health,e.mp,e.energyPending))return;e.lastFrame=(std::size_t)-1;e.attackTicks=animationDuration(a);int aggr=std::clamp(e.model->aggression,-300,300);int rest=std::clamp(18-aggr/6,2,90);if((e.model->aiAttack&AI_ALWAYS)!=0)rest=2;e.attackCooldown=e.attackTicks+rest;e.attackHasHit=false;e.projectileFired=false;
  if(e.model->onDoAttackScript&&*e.model->onDoAttackScript){e.scriptCtx.local["attack"]=std::string(a->name?a->name:"attack");e.scriptCtx.local["target"]=targetHandle;runModelScript(e.model->onDoAttackScript,e.scriptCtx,"entity-ondoattack");}
}
bool Engine::tryEntityPickupWeapon(RuntimeEntity& e){
  if(!e.alive||!e.model||e.equippedWeapon||!e.model->weapons||e.model->weaponCount==0)return false;RuntimeEntity*best=nullptr;float bestD=1.0e30f;for(auto&it:entities_){if(&it==&e||!it.alive||!it.visible||!it.model)continue;auto typ=lowerString(it.model->type?it.model->type:"");auto sub=lowerString(it.model->subtype?it.model->subtype:"");if(typ!="item"&&sub.find("weapon")==std::string::npos&&sub.find("projectile")==std::string::npos)continue;int wi=it.model->weaponNumber;if(wi<=0||(std::size_t)wi>e.model->weaponCount)continue;std::string expected=e.model->weapons[wi-1]?e.model->weapons[wi-1]:"";if(expected.empty()||lowerString(expected)=="none")continue;float d=std::fabs(it.worldX-e.worldX)+std::fabs(it.z-e.z);if(d<bestD){bestD=d;best=&it;}}if(!best||bestD>180.0f)return false;float dx=best->worldX-e.worldX,dz=best->z-e.z;if(std::fabs(dx)<=20.0f&&std::fabs(dz)<=14.0f){int wi=best->model->weaponNumber;setEntityWeaponIndex(e,wi);e.weaponItemModel=best->model;e.weaponDropsRemaining=best->weaponDropsRemaining>=0?best->weaponDropsRemaining:std::max(0,best->model->weaponDropCounter);best->alive=false;best->visible=false;std::cout<<"AI picked weapon model="<<(best->model->name?best->model->name:"")<<" index="<<wi<<"\n";return true;}float step=std::max(0.5f,e.model->speed);if(std::fabs(dx)>2.0f){e.worldX+=dx>0?step:-step;e.facing=dx<0?-1:1;}if(std::fabs(dz)>2.0f)e.z+=dz>0?std::min(step,1.2f):-std::min(step,1.2f);setEntityAnimation(e,findAnimation(e.model,"walk"));return true;
}
static void applyDropFrameOnApex(AnimationPlayer& player,float before,float after){
  auto* a=player.animation();
  if(a&&a->dropFrame>=0&&before<0.0f&&after>=0.0f&&(int)player.frameIndex()<a->dropFrame)player.setFrame((std::size_t)a->dropFrame);
}
static int animationDuration(const generated::Animation* a,std::size_t first);
static int deathDuration(const generated::Character* model,const generated::Animation* animation);
void Engine::updateEntities(){
  for(auto& e:entities_){
    settleAnimationEnergy(e.energyPending,e.animation,e.health,e.mp);if(e.invincibleTicks>0)--e.invincibleTicks;
    if(!e.visible || !e.model) continue;
    e.scriptCtx.entity=&e; e.scriptCtx.local["self"]=std::uintptr_t((std::uintptr_t)&e); runModelScript(e.model->thinkScript,e.scriptCtx,"entity-think"); runModelScript(e.model->updateScript,e.scriptCtx,"entity-update");
    if(!e.alive){ if(e.deathTicks>0){ --e.deathTicks; e.animation.update(1); } else if(e.deathFollowDeath){e.deathFollowDeath=false;auto*d=findAnimation(e.model,"death");if(d){setEntityAnimation(e,d);e.deathTicks=deathDuration(e.model,d);}else e.visible=false;} else if(e.model&&e.model->noDieBlink==3){auto*da=e.animation.animation();if(da&&da->frameCount)e.animation.setFrame(da->frameCount-1);} else {e.scriptCtx.local["trigger"]=0.0;runModelScript(e.model?e.model->onKillScript:"",e.scriptCtx,"entity-onkill");e.visible=false;} continue; }
    if(e.animationEffect){e.animation.update(1);if(e.animation.finished()){e.alive=e.visible=false;runModelScript(e.model->onKillScript,e.scriptCtx,"landing-effect-onkill");}continue;}
    if(e.model->offscreenKill>0){float d=(float)e.model->offscreenKill;if(e.worldX<cameraX_-d||e.worldX>cameraX_+(float)config_.logicalWidth+d){e.health=0;e.alive=false;e.deathTicks=0;e.scriptCtx.local["trigger"]=1.0;runModelScript(e.model->onKillScript,e.scriptCtx,"entity-offscreenkill");e.visible=false;continue;}}
    if(e.lifeTicks>0 && --e.lifeTicks==0){e.health=0;runModelScript(e.model?e.model->onDeathScript:"",e.scriptCtx,"entity-lifespan-ondeath");playDieSound(e.model);e.alive=false;auto*d=findAnimation(e.model,"death");if(!d)d=findAnimation(e.model,"fall");e.deathTicks=deathDuration(e.model,d);setEntityAnimation(e,d);continue;}
    if(e.freezeTicks>0){--e.freezeTicks;if(e.freezeTicks==0&&e.preFreezePaletteMap>=0){e.paletteMap=e.preFreezePaletteMap;e.preFreezePaletteMap=-1;e.lastFrame=(std::size_t)-1;}else e.animation.update(1);continue;}
    if(e.grabbed){ e.animation.update(1); continue; }
    updateChildFollowing(e);
    float oldX=e.worldX,oldZ=e.z;
    if(std::fabs(e.scriptVelocityX)>0.0001f)e.worldX+=e.scriptVelocityX;
    if(std::fabs(e.scriptVelocityZ)>0.0001f)e.z+=e.scriptVelocityZ;
    if(e.attackCooldown>0) --e.attackCooldown;
    float entityGround=-dynamicPlatformHeight(e.worldX,e.z,&e,e.model);
    if(e.fallTicks>0 || (e.model->subjectToGravity && e.altitude<entityGround-0.1f)){
      if(e.fallTicks>0) --e.fallTicks; float beforeVy=e.verticalVelocity; e.altitude+=e.verticalVelocity; e.verticalVelocity+=0.35f*(1.0f-actorAntigravity((std::uintptr_t)&e,e.model)); applyDropFrameOnApex(e.animation,beforeVy,e.verticalVelocity);
      if(e.altitude>=entityGround){
        if(e.bouncesRemaining>0&&e.verticalVelocity>0.05f){e.altitude=entityGround-0.1f;e.verticalVelocity=-std::max(0.5f,std::fabs(e.verticalVelocity)*(e.model&&e.model->bounceFactor>0.0f?e.model->bounceFactor:0.5f));--e.bouncesRemaining;e.fallTicks=std::max(e.fallTicks,8);e.animation.update(1);continue;}
        if(e.landingDamage>0&&e.alive){int dealt=effectiveDamage(e.model,e.landingDamage,e.landingType);e.health=std::max(0,e.health-dealt);if(e.health==0){e.alive=false;runModelScript(e.model?e.model->onDeathScript:"",e.scriptCtx,"entity-ondeath");playDieSound(e.model);auto*d=findAnimation(e.model,"death");if(!d)d=findAnimation(e.model,"fall");e.deathTicks=deathDuration(e.model,d);setEntityAnimation(e,d);}}
        e.landingDamage=0;e.landingMode=0;e.landingType=-1;e.altitude=entityGround;e.verticalVelocity=0.0f;e.fallTicks=0;
        if(e.alive){if(e.model->dustFallModel&&*e.model->dustFallModel)queueModelDust(e.model->dustFallModel,e.worldX,e.z,e.facing,(std::uintptr_t)&e);auto*la=e.animation.animation();bool hasLandFrame=la&&la->landFrame>=0;applyLandFrame(e.animation,e.worldX,e.z,e.facing,(std::uintptr_t)&e);e.lastFrame=(std::size_t)-1;if(e.fallTicks<=0){e.recoveryTicks=hasLandFrame?animationDuration(la,e.animation.frameIndex()):std::max(1,config_.recoveryTicks-(int)std::lround((e.model?e.model->riseTime:0)*0.6f));if(!hasLandFrame){auto r=(e.model&&e.model->riseAttackType>0)?reactionAnimation(e.model,"rise",e.reactionType):nullptr;if(!r)r=findAnimation(e.model,"rise");if(r)setEntityAnimation(e,r);}}}
      }
      e.animation.update(1);
    } else if(e.recoveryTicks>0){ --e.recoveryTicks; e.animation.update(1); if(e.recoveryTicks==0){if(e.model->riseInv>0)e.invincibleTicks=std::max(e.invincibleTicks,e.model->riseInv*60);e.juggleRemaining=std::max(1,e.model->jugglePoints);setEntityAnimation(e,findAnimation(e.model,"idle"));} }
    else if(e.hitStun>0){ --e.hitStun; e.animation.update(1); if(e.hitStun==0) setEntityAnimation(e,findAnimation(e.model,"idle")); }
    else if(e.attackTicks>0){ maybeSpawnProjectile(e.model,e.animation.animation(),e.animation.frameIndex(),e.worldX,e.z,e.altitude,e.facing,false,e.projectileFired,e.equippedWeapon,&e.weaponUses); if(e.equippedWeapon&&e.equippedWeapon->shootNum>0&&e.weaponUses<=0){if(e.equippedWeapon->typeShot&&e.weaponItemModel)dropEntityWeapon(e);else setEntityWeaponIndex(e,0);} --e.attackTicks; e.animation.update(1); if(e.attackTicks==0) setEntityAnimation(e,findActionAnimation(e.model,e.equippedWeapon,"idle")); }
    else {
      auto entityType=lowerString(e.model->type);
      if(entityType=="obstacle" || entityType=="item" || entityType=="projectile" || entityType=="none" || !config_.enemyAI){ e.animation.update(1); }
      else {
        if(tryEntityPickupWeapon(e)){e.animation.update(1);continue;}
        bool anyTarget=false;float targetX=e.worldX,targetZ=e.z,bestDist=1.0e30f;std::uintptr_t targetHandle=0;
        if(playerAlive_&&modelIsHostileTo(e.model,playerModel_,true)&&modelCanPerceive(e.model,playerModel_)){float d=std::fabs(playerWorldX_-e.worldX)+std::fabs(playerZ_-e.z);targetX=playerWorldX_;targetZ=playerZ_;bestDist=d;targetHandle=std::uintptr_t(1);anyTarget=true;}
        for(std::size_t ci=0;ci<coopPlayers_.size();++ci){const auto& cp=coopPlayers_[ci];if(!cp.alive||!modelIsHostileTo(e.model,cp.model,true)||!modelCanPerceive(e.model,cp.model))continue;float d=std::fabs(cp.worldX-e.worldX)+std::fabs(cp.z-e.z);if(!anyTarget||d<bestDist){targetX=cp.worldX;targetZ=cp.z;bestDist=d;targetHandle=std::uintptr_t(ci+2);anyTarget=true;}}
        for(auto& other:entities_){if(&other==&e||!other.alive||!other.visible||!other.model)continue;if(!modelIsHostileTo(e.model,other.model,false)||!modelCanPerceive(e.model,other.model))continue;auto ot=lowerString(other.model->type?other.model->type:"");if(ot=="item"||ot=="projectile"||ot=="none")continue;float d=std::fabs(other.worldX-e.worldX)+std::fabs(other.z-e.z);if(!anyTarget||d<bestDist){targetX=other.worldX;targetZ=other.z;bestDist=d;targetHandle=std::uintptr_t((std::uintptr_t)&other);anyTarget=true;}}
        if(!anyTarget){e.animation.update(1);}else{
          float dx=targetX-e.worldX,dz=targetZ-e.z,adx=std::fabs(dx),adz=std::fabs(dz);if(!e.model->noFlip&&e.model->facingAdjust==0){if(dx<0)e.facing=-1;else if(dx>0)e.facing=1;}e.facing=modelFacingValue(e.model,e.facing,scrollDir_);
          constexpr int AI_DODGE=0x00010000,AI_DODGEMOVE=0x00020000,AI_LONG=0x00000001;constexpr int MV_CHASE=1<<1,MV_CHASEZ=1<<2,MV_CHASEX=1<<3,MV_AVOID=1<<4,MV_AVOIDZ=1<<5,MV_AVOIDX=1<<6,MV_WANDER=1<<7,MV_BIKER=1<<8,MV_ARROW=1<<9,MV_STAR=1<<10,MV_BOMB=1<<11,MV_NOMOVE=1<<12;std::string subtype=lowerString(e.model->subtype?e.model->subtype:"");int effectiveMove=e.model->aiMove;if(subtype.find("chase")!=std::string::npos)effectiveMove|=MV_CHASE;if(subtype.find("biker")!=std::string::npos)effectiveMove|=MV_BIKER;if(subtype.find("arrow")!=std::string::npos)effectiveMove|=MV_ARROW;
          bool threat=playerAlive_&&playerAttackTicks_>0&&std::fabs(playerWorldX_-e.worldX)<(float)config_.enemyAttackRange*1.8f;
          if(threat&&(e.model->aiAttack&(AI_DODGE|AI_DODGEMOVE))){auto dodge=findAnimation(e.model,"dodge");if(dodge)setEntityAnimation(e,dodge);float side=(playerZ_<=e.z?1.0f:-1.0f);if(!e.model->noMove){if((e.model->aiAttack&AI_DODGEMOVE)!=0)e.z+=side*std::max(1.0f,e.model->speed);else e.worldX-=e.facing*std::max(0.5f,e.model->speed*0.5f);}e.animation.update(1);}
          else {int move=e.model->aiMove&0xFFFF;float attackRange=(float)config_.enemyAttackRange;if((e.model->aiAttack&AI_LONG)!=0)attackRange*=2.25f;
            if(adx<=attackRange&&adz<=20.0f){startEnemyAttack(e,adx,targetHandle);e.animation.update(1);}
            else if(e.model->noMove||(move&MV_NOMOVE)!=0){e.animation.update(1);}
            else {float step=std::max(0.5f,e.model->speed*(0.55f+(float)std::clamp(e.model->aggression,0,100)/220.0f));float sx=dx>0?step:-step,sz=dz>0?std::min(step,1.5f):-std::min(step,1.5f);
              if((move&MV_WANDER)!=0){int phase=(int)((tickCounter_/90u+(unsigned long long)((std::uintptr_t)&e>>4))%4u);sx=(phase==0?step:phase==1?-step:0.0f);sz=(phase==2?std::min(step,1.2f):phase==3?-std::min(step,1.2f):0.0f);}
              else if((move&MV_AVOID)!=0){sx=-sx;sz=-sz;}else{if((move&MV_AVOIDX)!=0)sx=-sx;if((move&MV_AVOIDZ)!=0)sz=-sz;}
              if((move&MV_CHASEZ)!=0)sx=0.0f;if((move&MV_CHASEX)!=0)sz=0.0f;if((move&(MV_BIKER|MV_ARROW|MV_STAR|MV_BOMB))!=0){sx=(float)e.facing*std::max(step,1.0f);if((move&MV_STAR)!=0)sz=((tickCounter_/30)%2?1.0f:-1.0f)*std::min(step,1.0f);}
              if(adx>3.0f||((move&(MV_WANDER|MV_BIKER|MV_ARROW|MV_STAR|MV_BOMB))!=0))e.worldX+=sx;if(adz>3.0f||((move&(MV_WANDER|MV_STAR))!=0))e.z+=sz;setEntityAnimation(e,findActionAnimation(e.model,e.equippedWeapon,"walk"));e.animation.update(1);}
          }
        }
      }
    }
    if(e.subjectToScreen){float right=std::min(stageLength_-1.0f,cameraX_+(float)config_.logicalWidth-4.0f);e.worldX=std::clamp(e.worldX,cameraX_+4.0f,std::max(cameraX_+4.0f,right));}
    if(stage_){float attemptedZ=e.z;if(e.model->subjectToMinZ)e.z=std::max(e.z,(float)stage_->zMin);if(e.model->subjectToMaxZ)e.z=std::min(e.z,(float)stage_->zMax);if(e.z!=attemptedZ&&e.model->onBlockZScript&&*e.model->onBlockZScript){e.scriptCtx.local["plane"]=1.0;runModelScript(e.model->onBlockZScript,e.scriptCtx,"entity-onblockz");}}
    if(applyActorTerrain(e.model,e.scriptCtx,e.worldX,e.z,e.altitude,oldX,oldZ)&&(e.model->aiMove&0x00010000)==0){e.worldX=oldX;e.z=oldZ;if(!e.model->noFlip&&e.model->facingAdjust==0)e.facing=-e.facing;}e.facing=modelFacingValue(e.model,e.facing,scrollDir_);
    if(std::fabs(e.worldX-oldX)>0.001f&&e.model->onMoveXScript&&*e.model->onMoveXScript){e.scriptCtx.local["movex"]=(double)(e.worldX-oldX);runModelScript(e.model->onMoveXScript,e.scriptCtx,"entity-onmovex");}
    if(std::fabs(e.z-oldZ)>0.001f&&e.model->onMoveZScript&&*e.model->onMoveZScript){e.scriptCtx.local["movez"]=(double)(e.z-oldZ);runModelScript(e.model->onMoveZScript,e.scriptCtx,"entity-onmovez");}
  }
  applyEntityBindings();
}
bool Engine::detonateProjectile(RuntimeProjectile& p,bool contact){
  if(!p.bomb||p.exploded)return false;
  auto* boom=exactAnimation(p.model,contact?"attack2":"attack1");
  if(!boom){if(contact&&p.model->removeConfig)p.alive=false;return false;}
  p.exploded=true;p.vx=p.vy=p.vz=0;p.subjectToGravity=false;
  p.animation.setAnimation(boom);p.lastFrame=(std::size_t)-1;p.hitTargets.clear();
  p.life=animationDuration(boom);playDieSound(p.model);return true;
}
bool Engine::projectileContact(RuntimeProjectile& p){
  if(p.bomb&&!p.exploded){if(detonateProjectile(p,true))return true;}
  else if(!p.bomb&&p.model->removeConfig)p.alive=false;
  return false;
}
void Engine::updateProjectiles(){
  for(auto& p:projectiles_){
    if(!p.alive||!p.model)continue;if(--p.life<=0){p.alive=false;continue;}
    float beforeVy=p.vy;p.worldX+=p.vx;p.z+=p.vz;p.altitude+=p.vy;if(p.subjectToGravity&&!p.exploded)p.vy+=config_.gravity*(1.0f-(p.model?p.model->antigravity:0.0f));applyDropFrameOnApex(p.animation,beforeVy,p.vy);
    if(p.subjectToGravity&&p.altitude>=0.0f&&!p.exploded){
      if(p.bouncesLeft>0&&std::fabs(p.vy)>0.05f){p.altitude=-0.1f;p.vy=-std::fabs(p.vy)*std::max(0.0f,p.bounceFactor);--p.bouncesLeft;std::cout<<"Projectile bounce: "<<p.model->name<<" left="<<p.bouncesLeft<<"\n";}
      else if(p.bomb){p.altitude=0;if(!detonateProjectile(p,false)){p.vx=p.vz=p.vy=0;p.alive=false;continue;}}
      else {p.alive=false;continue;}
    }
    p.animation.update(1);float half=(float)std::max(160,config_.logicalWidth)/2.0f;if(p.worldX<cameraX_-half||p.worldX>cameraX_+(float)config_.logicalWidth+half)p.alive=false;
  }
  projectiles_.erase(std::remove_if(projectiles_.begin(),projectiles_.end(),[](const RuntimeProjectile& p){return !p.alive;}),projectiles_.end());
}
Engine::RectF Engine::bboxFor(const generated::Frame* f,float worldX,float worldY,int facing) const{
  if(!f) return {worldX-10,worldY-28,20,28}; if(!f->hasBBox) return {worldX-10,worldY-28,20,28}; float x=facing>=0?worldX-f->offsetX+f->bbox.x:worldX+f->offsetX-f->bbox.x-f->bbox.w; return {x,worldY-f->offsetY+f->bbox.y,(float)f->bbox.w,(float)f->bbox.h};
}
Engine::RectF Engine::attackFor(const generated::Frame* f,float worldX,float worldY,int facing) const{
  if(!f || !f->hasAttack) return {}; float x=facing>=0?worldX-f->offsetX+f->attack.x:worldX+f->offsetX-f->attack.x-f->attack.w; return {x,worldY-f->offsetY+f->attack.y,(float)f->attack.w,(float)f->attack.h};
}
bool Engine::overlaps(const RectF& a,const RectF& b){ return a.w>0&&a.h>0&&b.w>0&&b.h>0&&a.x<b.x+b.w&&a.x+a.w>b.x&&a.y<b.y+b.h&&a.y+a.h>b.y; }
void Engine::tryGrabNearest(){
  if(grabbedEntity_>=0 || !playerAlive_ || playerAttackTicks_>0 || std::fabs(playerAltitude_)>2.0f) return; if(auto f=player_.frame();f&&(f->moveX!=0.0f||f->moveZ!=0.0f))return; float best=(float)std::max(config_.grabRange,playerModel_?playerModel_->grabDistance:30); int found=-1;
  for(std::size_t i=0;i<entities_.size();++i){auto& e=entities_[i];if(!e.alive||e.grabbed||e.fallTicks>0||!e.model||lowerString(e.model->type)!="enemy"||e.model->noGrab)continue;int force=playerModel_?playerModel_->grabForce:0;if(force<e.model->grabResistance)continue;if(std::fabs(e.altitude)>=0.1f||std::fabs(e.altitude-playerAltitude_)>2.0f)continue;float dx=std::fabs(e.worldX-playerWorldX_),dz=std::fabs(e.z-playerZ_);if(dx<=best&&dz<=16.0f){best=dx;found=(int)i;}}
  if(found<0)return; grabbedEntity_=found;grabHoldTicks_=0;auto& e=entities_[(std::size_t)found];e.grabbed=true;e.attackTicks=0;e.hitStun=0;playerFacing_=e.worldX>=playerWorldX_?1:-1;
  if(auto g=findAnimation(playerModel_,"grab"))player_.setAnimation(g);if(auto g=findAnimation(e.model,"grabbed"))setEntityAnimation(e,g);std::cout<<"Grabbed enemy "<<(e.spawn?e.spawn->model:e.model->name)<<"\n";
}
void Engine::throwGrabbed(){
  if(grabbedEntity_<0||(std::size_t)grabbedEntity_>=entities_.size())return;auto& e=entities_[(std::size_t)grabbedEntity_];e.grabbed=false;e.worldX=playerWorldX_+(float)(playerFacing_*18);grabbedEntity_=-1;grabHoldTicks_=0;++playerAttackId_;
  if(auto t=findAnimation(playerModel_,"throw")){player_.setAnimation(t);lastFrame_=(std::size_t)-1;}int td=playerModel_&&playerModel_->throwDamage>0?playerModel_->throwDamage:config_.throwDamage;const generated::Character* victim=e.model;float dist=victim&&victim->throwDistance>0.0f?victim->throwDistance:18.0f;float h=victim&&victim->throwHeight>0.0f?victim->throwHeight:(victim?(float)victim->jumpHeight:5.0f);int drop=-(int)std::max(1.0f,std::round(h));e.worldX=playerWorldX_+(float)playerFacing_*dist;damageEnemy(e,td,(float)playerFacing_,true,drop,0,std::uintptr_t(1));std::cout<<"Throw executed damage="<<td<<" distance="<<dist<<" height="<<h<<"\n";
}
void Engine::playFrameSound(const generated::Frame* f){
  if(!f||!f->sound||!*f->sound)return;std::string snd=f->sound;bool file=snd.find('/')!=std::string::npos||snd.find('\\')!=std::string::npos||snd.find('.')!=std::string::npos;if(!file)return;auto path=resolveAudioAsset(root_/"assets"/"openbor-data",snd);if(std::filesystem::exists(path)&&!audio_.playEffect(path))std::cerr<<"Frame sound diagnostic: "<<audio_.lastError()<<"\n";
}
void Engine::playHitFx(const generated::Animation* a){
  if(!a||!a->hitFx||!*a->hitFx)return;auto p=resolveAudioAsset(root_/"assets"/"openbor-data",a->hitFx);if(std::filesystem::exists(p)&&!audio_.playEffect(p))std::cerr<<"hitfx diagnostic: "<<audio_.lastError()<<"\n";
}
void Engine::triggerQuake(const generated::Character* m,const generated::Animation* a,std::size_t frame){
  if(!a||!m||m->noQuake||a->quakeFrame<0||(int)frame!=a->quakeFrame)return;quakeIntensity_=std::max(quakeIntensity_,a->quakeIntensity>0?a->quakeIntensity:2);quakeTicks_=std::max(quakeTicks_,std::max(1,a->quakeLoops>0?a->quakeLoops*2:4));
}
void Engine::playDieSound(const generated::Character* m){
  if(!m||!m->dieSound||!*m->dieSound)return;auto p=resolveAudioAsset(root_/"assets"/"openbor-data",m->dieSound);if(std::filesystem::exists(p)&&!audio_.playEffect(p))std::cerr<<"diesound diagnostic: "<<audio_.lastError()<<"\n";
}
const generated::Defense* Engine::defenseFor(const generated::Character* m,int attackType) const{
  if(!m||!m->defenses||m->defenseCount==0)return nullptr;std::string type=attackType<0?"land":attackType==1001?"blast":attackType==1002?"burn":attackType==1003?"freeze":attackType==1004?"shock":attackType==1005?"steal":("normal"+std::to_string(std::max(1,attackType)));const generated::Defense* fallback=nullptr;const generated::Defense* normal=nullptr;for(std::size_t i=0;i<m->defenseCount;++i){auto&d=m->defenses[i];std::string k=lowerString(d.type?d.type:"");if(k=="all")fallback=&d;else if(k=="normal")normal=&d;if(k==type)return &d;}return normal?normal:fallback;
}
int Engine::effectiveDamage(const generated::Character* m,int raw,int attackType) const{
  auto*d=defenseFor(m,attackType);return d?std::max(0,(int)std::lround((float)raw*d->factor)):std::max(0,raw);
}
bool Engine::defenseAllowsPain(const generated::Character* m,int raw,int attackType) const{auto*d=defenseFor(m,attackType);return !d||d->pain<=0.0f||(float)raw>=d->pain;}
bool Engine::defenseAllowsKnockdown(const generated::Character* m,int attackType) const{auto*d=defenseFor(m,attackType);return !d||d->knockdown>0.0f;}
bool Engine::resolveKnockdown(const generated::Character* m,float& meter,bool requested,int attackType,int power) const{if(!m)return requested;if(m->noMove){meter=0.0f;return false;}float threshold=m->knockdownCount;if(threshold<0.0f){meter=0.0f;return true;}auto*d=defenseFor(m,attackType);float scale=d?std::max(0.0f,d->knockdown):1.0f;if(!requested||scale<=0.0f)return false;if(threshold<=0.0f)return true;float force=(float)std::max(1,power)*scale;meter+=force;if(force>=threshold||meter>=threshold){meter=0.0f;return true;}return false;}
static int blockedChipDamage(const generated::Character* m,const generated::Defense* d,int raw){float ratio=0.0f;if(d&&d->blockRatioDefined)ratio=std::max(0.0f,d->blockRatio);else if(m&&m->globalBlockRatio)ratio=0.25f;if(ratio<=0.0f)return 0;return std::max(0,(int)std::lround((float)std::max(0,raw)*ratio));}
static void applyBlockedChip(int& hp,int& mp,const generated::Character* m,const generated::Defense* d,int raw){int chip=blockedChipDamage(m,d,raw);if(chip<=0)return;int type=d&&d->blockTypeDefined?d->blockType:0;if(type==0)type=(m&&m->globalMpBlock)?1:-1;auto hitHp=[&](int amount){if(amount<=0)return;int floor=(m&&m->noChipDeath)?1:0;hp=std::max(floor,hp-amount);};if(type==1){int take=std::min(mp,chip);mp-=take;chip-=take;if(chip>0)hitHp(chip);}else if(type==2){mp=std::max(0,mp-chip);hitHp(chip);}else hitHp(chip);}
static int animationDuration(const generated::Animation* a,std::size_t first){
  if(!a||!a->frames||first>=a->frameCount)return 1;long long ticks=0;
  for(std::size_t i=first;i<a->frameCount;++i){if(a->frames[i].delay<0)return 36000;ticks+=std::max(1,a->frames[i].delay);}
  return (int)std::clamp(ticks+1,1LL,36000LL);
}
static int deathDuration(const generated::Character* model,const generated::Animation* animation){
  // nodieblink 2: never blink; remove exactly when the non-looping death/fall animation ends.
  if(model&&model->noDieBlink==2)return animationDuration(animation);
  return 30;
}
void Engine::applyLandFrame(AnimationPlayer& a,float x,float z,int facing,std::uintptr_t parent){
  auto*anim=a.animation();if(!anim||anim->landFrame<0||anim->frameCount==0||(std::size_t)anim->landFrame>=anim->frameCount||a.frameIndex()>=(std::size_t)anim->landFrame)return;
  a.setFrame((std::size_t)anim->landFrame);
  if(anim->landDustModel&&*anim->landDustModel){auto*model=findCharacter(anim->landDustModel);if(model){PendingChildSpawn q;q.model=model;q.worldX=x;q.z=z;q.facing=facing;q.parent=parent;q.animationEffect=true;pendingChildSpawns_.push_back(q);}}
}
void Engine::drawShadow(const generated::Character* m,float worldX,float z,float altitude){
  if(!m||m->gfxShadow==1||m->shadow<=0||altitude>0.1f)return;int idx=std::clamp(m->shadow,1,6);auto it=shadowCache_.find(idx);if(it==shadowCache_.end()){SpriteImage img;auto shadowName=std::string("sprites/shadow")+std::to_string(idx);auto path=resolveSpriteAsset(root_/"assets"/"openbor-data",shadowName.c_str());renderer_.loadSprite(path,img);it=shadowCache_.emplace(idx,std::move(img)).first;}int sx=(int)(worldX-cameraX_-(stage_?stage_->cameraOffsetX:0)),sy=(int)z+(stage_?stage_->cameraOffsetY:0);if(it->second.width>0)renderer_.drawImage(it->second,sx-it->second.width/2,sy-it->second.height/2);else renderer_.drawSolidRect(sx-8,sy-2,16,3,35,35,35);
}
bool Engine::tryBlockEntity(RuntimeEntity& e,const generated::Frame& atk,std::uintptr_t attacker){
  if(!e.alive||!e.model||!atk.hasAttack)return false;auto*m=e.model;auto block=findAnimation(m,"block");if(!block)return false;
  constexpr int BS_ACTIVE=1,BS_NATIVE=2,BS_IGNORE_CHANCE=4,BS_IGNORE_GUARD=8,BS_IGNORE_DIR=16,BS_IGNORE_ELIG=32,BS_IGNORE_BLOCKPAIN=64;
  bool forced=(e.blockState&BS_ACTIVE)!=0;bool native=forced||(e.blockState&BS_NATIVE)!=0||m->blockOdds>=0;if(!native)return false;
  if(!(e.blockState&BS_IGNORE_ELIG)){auto*d=defenseFor(m,atk.attack.type);int blockPower=d?d->blockPower:0;int penetration=std::max(0,atk.attack.penetration);if((blockPower!=0||penetration!=0)&&blockPower<=penetration)return false;int threshold=m->blockThreshold+(d?d->blockThreshold:0);if(threshold!=0&&atk.attack.damage>=threshold)return false;}
  float ax=e.worldX;int ps=(attacker>=1&&attacker<=4)?(int)attacker-1:-1;if(ps==0)ax=playerWorldX_;else if(ps>0&&(std::size_t)(ps-1)<coopPlayers_.size())ax=coopPlayers_[(std::size_t)(ps-1)].worldX;else for(auto&other:entities_)if((std::uintptr_t)&other==attacker){ax=other.worldX;break;}
  bool facingAttack=(ax<e.worldX&&e.facing<0)||(ax>e.worldX&&e.facing>0);if(!m->blockBack&&!(e.blockState&BS_IGNORE_DIR)&&!facingAttack)return false;
  if(!forced&&!(e.blockState&BS_IGNORE_CHANCE)){static std::mt19937 brng{0xB10C2026u};int odds=std::max(0,m->blockOdds);if(((int)brng()&odds)!=0)return false;}
  if(m->guardPoints>0&&!(e.blockState&BS_IGNORE_GUARD)&&e.guardPoints<=0){if(auto gb=findAnimation(m,"guardbreak"))setEntityAnimation(e,gb);return false;}
  int cost=std::max(0,atk.attack.guardCost);if(m->guardPoints>0&&!(e.blockState&BS_IGNORE_GUARD))e.guardPoints=std::max(0,e.guardPoints-cost);auto*def=defenseFor(m,atk.attack.type);applyBlockedChip(e.health,e.mp,m,def,atk.attack.damage);if(e.health<=0){e.alive=false;playDieSound(m);}
  const generated::Animation* react=block;if(!(e.blockState&BS_IGNORE_BLOCKPAIN)&&m->blockPain>0&&atk.attack.damage>=m->blockPain){react=reactionAnimation(m,"blockpain",atk.attack.type);if(!react)react=block;}setEntityAnimation(e,react);e.blocking=true;e.hitStun=std::max(2,atk.attack.pauseTime);
  e.scriptCtx.local["attacker"]=attacker;e.scriptCtx.local["damage"]=(double)atk.attack.damage;e.scriptCtx.local["attacktype"]=(double)atk.attack.type;e.scriptCtx.local["drop"]=atk.knockdown;e.scriptCtx.local["noblock"]=(double)atk.attack.penetration;e.scriptCtx.local["guardcost"]=(double)cost;e.scriptCtx.local["jugglecost"]=(double)atk.attack.juggleCost;e.scriptCtx.local["pauseadd"]=(double)atk.attack.pauseTime;e.scriptCtx.local["tag"]=(double)atk.attack.tag;runModelScript(m->didBlockScript,e.scriptCtx,"entity-didblock");return true;
}
bool Engine::tryBlockPlayer(int slot,const generated::Frame& atk,std::uintptr_t attacker){
  auto*m=slot==0?playerModel_:((std::size_t)(slot-1)<coopPlayers_.size()?coopPlayers_[(std::size_t)(slot-1)].model:nullptr);if(!m||!atk.hasAttack||!findAnimation(m,"block"))return false;constexpr int BS_ACTIVE=1,BS_IGNORE_GUARD=8,BS_IGNORE_DIR=16,BS_IGNORE_ELIG=32,BS_IGNORE_BLOCKPAIN=64;int&state=slot==0?playerBlockState_:coopPlayers_[(std::size_t)(slot-1)].blockState;int&guard=slot==0?playerGuardPoints_:coopPlayers_[(std::size_t)(slot-1)].guardPoints;std::string currentAnim;if(slot==0&&player_.animation()&&player_.animation()->name)currentAnim=player_.animation()->name;else if(slot>0){auto&cp=coopPlayers_[(std::size_t)(slot-1)];if(cp.animation.animation()&&cp.animation.animation()->name)currentAnim=cp.animation.animation()->name;}bool animBlock=lowerString(currentAnim).rfind("block",0)==0;if(!(state&BS_ACTIVE)&&!animBlock)return false;if(!(state&BS_IGNORE_ELIG)){auto*d=defenseFor(m,atk.attack.type);int blockPower=d?d->blockPower:0;int penetration=std::max(0,atk.attack.penetration);if((blockPower!=0||penetration!=0)&&blockPower<=penetration)return false;int threshold=m->blockThreshold+(d?d->blockThreshold:0);if(threshold!=0&&atk.attack.damage>=threshold)return false;}
  float px=slot==0?playerWorldX_:coopPlayers_[(std::size_t)(slot-1)].worldX;int face=slot==0?playerFacing_:coopPlayers_[(std::size_t)(slot-1)].facing;float ax=px;for(auto&other:entities_)if((std::uintptr_t)&other==attacker){ax=other.worldX;break;}bool facingAttack=(ax<px&&face<0)||(ax>px&&face>0);if(!m->blockBack&&!(state&BS_IGNORE_DIR)&&!facingAttack)return false;if(m->guardPoints>0&&!(state&BS_IGNORE_GUARD)&&guard<=0)return false;int cost=std::max(0,atk.attack.guardCost);if(m->guardPoints>0&&!(state&BS_IGNORE_GUARD))guard=std::max(0,guard-cost);auto*def=defenseFor(m,atk.attack.type);int&hp=slot==0?playerHealth_:coopPlayers_[(std::size_t)(slot-1)].health;int&mp=slot==0?playerMp_:coopPlayers_[(std::size_t)(slot-1)].mp;applyBlockedChip(hp,mp,m,def,atk.attack.damage);if(hp<=0){if(slot==0)playerAlive_=false;else coopPlayers_[(std::size_t)(slot-1)].alive=false;}
  auto react=findAnimation(m,"block");if(!(state&BS_IGNORE_BLOCKPAIN)&&m->blockPain>0&&atk.attack.damage>=m->blockPain){if(auto bp=reactionAnimation(m,"blockpain",atk.attack.type))react=bp;}if(slot==0){player_.setAnimation(react);lastFrame_=(std::size_t)-1;playerBlocking_=true;playerHitStun_=std::max(2,atk.attack.pauseTime);playerScriptCtx_.local["attacker"]=attacker;playerScriptCtx_.local["damage"]=(double)atk.attack.damage;playerScriptCtx_.local["attacktype"]=(double)atk.attack.type;playerScriptCtx_.local["drop"]=atk.knockdown;playerScriptCtx_.local["noblock"]=(double)atk.attack.penetration;playerScriptCtx_.local["guardcost"]=(double)cost;playerScriptCtx_.local["jugglecost"]=(double)atk.attack.juggleCost;playerScriptCtx_.local["pauseadd"]=(double)atk.attack.pauseTime;playerScriptCtx_.local["tag"]=(double)atk.attack.tag;runModelScript(m->didBlockScript,playerScriptCtx_,"player-didblock");}else{auto&cp=coopPlayers_[(std::size_t)(slot-1)];cp.animation.setAnimation(react);cp.lastFrame=(std::size_t)-1;cp.blocking=true;cp.hitStun=std::max(2,atk.attack.pauseTime);cp.scriptCtx.local["attacker"]=attacker;cp.scriptCtx.local["damage"]=(double)atk.attack.damage;cp.scriptCtx.local["attacktype"]=(double)atk.attack.type;cp.scriptCtx.local["guardcost"]=(double)cost;runModelScript(m->didBlockScript,cp.scriptCtx,"coop-didblock");}return true;
}
static int forcedFacingValue(int current,int attackerFacing,int mode){
  if(mode==1)return attackerFacing<0?-1:1;
  if(mode==-1)return attackerFacing<0?1:-1;
  if(mode==2)return 1;
  if(mode==-2)return -1;
  return current;
}
void Engine::damageEnemy(RuntimeEntity& e,int damage,float knockDirection,bool knockdown,int dropVy,int attackType,std::uintptr_t attacker,int landingDamage,int landingMode,int landingType,float dropVx,int forceDirection){
  if(!e.alive||e.invincibleTicks>0)return; e.facing=forcedFacingValue(e.facing,knockDirection<0?-1:1,forceDirection); int rawDamage=damage; bool painAllowed=e.model&&!e.model->noPain&&defenseAllowsPain(e.model,rawDamage,attackType); knockdown=resolveKnockdown(e.model,e.knockdownMeter,knockdown,attackType,std::abs(dropVy)); damage=effectiveDamage(e.model,damage,attackType); if(damage<=0&&rawDamage!=0)return; const generated::Character* activeWeapon=e.equippedWeapon;const generated::Character* lossSpec=activeWeapon?(activeWeapon->weaponLossDefined?activeWeapon:e.model):nullptr;if(activeWeapon&&lossSpec&&(!e.model||!e.model->noDrop)&&(lossSpec->weaponLossFlag==0||(knockdown&&(lossSpec->weaponLossFlag==1||activeWeapon->animalWeapon))))dropEntityWeapon(e); e.scriptCtx.entity=&e; e.scriptCtx.local["self"]=std::uintptr_t((std::uintptr_t)&e); e.scriptCtx.local["attacker"]=attacker; e.scriptCtx.local["damage"]=double(damage);e.scriptCtx.local["attacktype"]=(double)attackType;e.scriptCtx.local["drop"]=knockdown;e.scriptCtx.local["noblock"]=0.0;e.scriptCtx.local["guardcost"]=0.0;e.scriptCtx.local["jugglecost"]=0.0;e.scriptCtx.local["pauseadd"]=0.0; runModelScript(e.model?e.model->takeDamageScript:"",e.scriptCtx,"entity-takedamage");e.health=std::max(0,e.health-std::max(0,damage));float launchX=std::fabs(dropVx)>0.0001f?std::fabs(dropVx):(float)config_.knockback;e.worldX=std::max(0.0f,e.worldX+knockDirection*launchX);std::cout<<"Hit enemy "<<(e.spawn?e.spawn->model:e.model->name)<<" damage="<<damage<<" hp="<<e.health<<"/"<<e.maxHealth<<(knockdown?" knockdown":"")<<"\n";
  if(e.health<=0){int scoreGain=e.spawn?std::max(0,e.spawn->score):0;if(scoreGain>0){if(attacker==1)playerScore_+=scoreGain;else if(attacker>=2&&attacker<=4){auto ci=(std::size_t)(attacker-2);if(ci<coopPlayers_.size())coopPlayers_[ci].score+=scoreGain;}}if(activeWeapon&&lossSpec&&(!e.model||!e.model->noDrop)&&lossSpec->weaponLossFlag==2)dropEntityWeapon(e);if(e.model&&e.model->summonKill>0)unsummonChildren((std::uintptr_t)&e,e.model->summonKill>=2);runModelScript(e.model?e.model->onDeathScript:"",e.scriptCtx,"entity-ondeath");playDieSound(e.model);e.alive=false;e.grabbed=false;e.deathFollowDeath=false;auto d=attackType==1002?findAnimation(e.model,"bdeath"):nullptr;if(!d&&e.model&&e.model->fallDie==2){auto*f=findAnimation(e.model,"fall");auto*death=findAnimation(e.model,"death");if(f&&death){d=f;e.deathFollowDeath=true;}}if(!d&&e.model&&e.model->fallDie==0)d=findAnimation(e.model,"fall");if(!d)d=findAnimation(e.model,"death");if(!d)d=findAnimation(e.model,"fall");e.deathTicks=deathDuration(e.model,d);setEntityAnimation(e,d);auto kind=lowerString(e.model?e.model->type:"");std::cout<<(kind=="obstacle"?"Object destroyed: ":"Enemy defeated: ")<<(e.spawn?e.spawn->model:e.model->name)<<"\n";}
  else {if(attackType==1003&&e.model){if(e.freezeTicks<=0)e.preFreezePaletteMap=e.paletteMap;e.freezeTicks=std::max(e.freezeTicks,120);if(e.model->freezeMap>0)e.paletteMap=e.model->freezeMap;e.lastFrame=(std::size_t)-1;}if(knockdown){runModelScript(e.model?e.model->onFallScript:"",e.scriptCtx,"entity-onfall");e.reactionType=attackType;e.fallTicks=config_.fallTicks;e.bouncesRemaining=e.model?std::max(0,e.model->bounce):0;e.landingDamage=landingDamage;e.landingMode=landingMode;e.landingType=landingType;e.landingHitTargets.clear();e.altitude=-1.0f;e.verticalVelocity=(float)dropVy;e.juggleRemaining=std::max(1,e.model?e.model->jugglePoints:4);auto f=reactionAnimation(e.model,"fall",attackType);if(!f)f=findAnimation(e.model,"fall");if(f)setEntityAnimation(e,f);}
  else if(painAllowed){runModelScript(e.model?e.model->onPainScript:"",e.scriptCtx,"entity-onpain");e.reactionType=attackType;e.hitStun=8;auto pain=reactionAnimation(e.model,"pain",attackType);if(!pain)pain=findAnimation(e.model,"pain");setEntityAnimation(e,pain);} }
}
void Engine::damagePlayer(int damage,float knockDirection,bool knockdown,int dropVy,int attackType,std::uintptr_t attacker,int landingDamage,int landingMode,int landingType,float dropVx,int forceDirection){
  if(playerInvincibleTicks_>0)return;
  playerFacing_=forcedFacingValue(playerFacing_,knockDirection<0?-1:1,forceDirection); int rawDamage=damage; bool painAllowed=playerModel_&&!playerModel_->noPain&&defenseAllowsPain(playerModel_,rawDamage,attackType); knockdown=resolveKnockdown(playerModel_,playerKnockdownMeter_,knockdown,attackType,std::abs(dropVy));
  if(playerModel_){playerScriptCtx_.local["attacker"]=attacker;playerScriptCtx_.local["damage"]=double(damage);playerScriptCtx_.local["attacktype"]=(double)attackType;playerScriptCtx_.local["drop"]=knockdown;playerScriptCtx_.local["noblock"]=0.0;playerScriptCtx_.local["guardcost"]=0.0;playerScriptCtx_.local["jugglecost"]=0.0;playerScriptCtx_.local["pauseadd"]=0.0;runModelScript(playerModel_->takeDamageScript,playerScriptCtx_,"player-takedamage");}
  damage=effectiveDamage(playerModel_,damage,attackType);if(damage<=0&&rawDamage!=0)return;if(!playerAlive_||playerHitStun_>0||playerFallTicks_>0)return;const generated::Character*activeWeapon=equippedWeapon_;const generated::Character*lossSpec=activeWeapon?(activeWeapon->weaponLossDefined?activeWeapon:playerModel_):nullptr;if(activeWeapon&&lossSpec&&(!playerModel_||!playerModel_->noDrop)&&(lossSpec->weaponLossFlag==0||(knockdown&&(lossSpec->weaponLossFlag==1||activeWeapon->animalWeapon))))dropPlayerWeapon();playerHealth_=std::max(0,playerHealth_-std::max(0,damage));float launchX=std::fabs(dropVx)>0.0001f?std::fabs(dropVx):(float)config_.knockback;playerWorldX_=std::clamp(playerWorldX_+knockDirection*launchX,0.0f,std::max(0.0f,stageLength_-1.0f));std::cout<<"Player hit damage="<<damage<<" hp="<<playerHealth_<<"/"<<playerMaxHealth_<<(knockdown?" knockdown":"")<<"\n";
  if(playerHealth_<=0){if(activeWeapon&&lossSpec&&(!playerModel_||!playerModel_->noDrop)&&lossSpec->weaponLossFlag==2)dropPlayerWeapon();if(playerModel_&&playerModel_->summonKill>0)unsummonChildren(std::uintptr_t(1),playerModel_->summonKill>=2);if(playerModel_)runModelScript(playerModel_->onDeathScript,playerScriptCtx_,"player-ondeath");playDieSound(playerModel_);playerAlive_=false;auto d=attackType==1002?findAnimation(playerModel_,"bdeath"):nullptr;if(!d&&playerModel_&&playerModel_->fallDie!=1)d=findAnimation(playerModel_,"fall");if(!d)d=findAnimation(playerModel_,"death");if(!d)d=findAnimation(playerModel_,"fall");player_.setAnimation(d);lastFrame_=(std::size_t)-1;std::cout<<"GAME OVER\n";}
  else if(knockdown){if(playerModel_)runModelScript(playerModel_->onFallScript,playerScriptCtx_,"player-onfall");playerReactionType_=attackType;playerFallTicks_=config_.fallTicks;playerLandingDamage_=landingDamage;playerLandingMode_=landingMode;playerLandingType_=landingType;playerLandingHitTargets_.clear();playerAltitude_=-1.0f;playerVerticalVelocity_=(float)dropVy;auto f=reactionAnimation(playerModel_,"fall",attackType);if(!f)f=findAnimation(playerModel_,"fall");if(f)player_.setAnimation(f);lastFrame_=(std::size_t)-1;}
  else if(painAllowed){if(playerModel_)runModelScript(playerModel_->onPainScript,playerScriptCtx_,"player-onpain");playerReactionType_=attackType;playerHitStun_=10;auto pain=reactionAnimation(playerModel_,"pain",attackType);if(!pain)pain=findAnimation(playerModel_,"pain");player_.setAnimation(pain);lastFrame_=(std::size_t)-1;}
}
void Engine::damageCoopPlayer(RuntimeCoopPlayer& cp,int damage,float knockDirection,bool knockdown,int dropVy,int attackType,std::uintptr_t attacker,int landingDamage,int landingMode,int landingType,float dropVx,int forceDirection){
  if(cp.invincibleTicks>0)return;
  cp.facing=forcedFacingValue(cp.facing,knockDirection<0?-1:1,forceDirection); int rawDamage=damage; bool painAllowed=cp.model&&!cp.model->noPain&&defenseAllowsPain(cp.model,rawDamage,attackType); knockdown=resolveKnockdown(cp.model,cp.knockdownMeter,knockdown,attackType,std::abs(dropVy));
  if(cp.model){cp.scriptCtx.local["attacker"]=attacker;cp.scriptCtx.local["damage"]=(double)damage;cp.scriptCtx.local["attacktype"]=(double)attackType;cp.scriptCtx.local["drop"]=knockdown;cp.scriptCtx.local["noblock"]=0.0;cp.scriptCtx.local["guardcost"]=0.0;cp.scriptCtx.local["jugglecost"]=0.0;cp.scriptCtx.local["pauseadd"]=0.0;runModelScript(cp.model->takeDamageScript,cp.scriptCtx,"coop-takedamage");}
  damage=effectiveDamage(cp.model,damage,attackType);if(damage<=0&&rawDamage!=0)return;if(!cp.alive||cp.hitStun>0)return;const generated::Character*activeWeapon=cp.equippedWeapon;const generated::Character*lossSpec=activeWeapon?(activeWeapon->weaponLossDefined?activeWeapon:cp.model):nullptr;if(activeWeapon&&lossSpec&&(!cp.model||!cp.model->noDrop)&&(lossSpec->weaponLossFlag==0||(knockdown&&(lossSpec->weaponLossFlag==1||activeWeapon->animalWeapon))))dropCoopWeapon(cp);cp.health=std::max(0,cp.health-std::max(0,damage));float launchX=std::fabs(dropVx)>0.0001f?std::fabs(dropVx):(float)config_.knockback;cp.worldX=std::max(0.0f,cp.worldX+knockDirection*launchX);cp.reactionType=attackType;std::cout<<"Coop player hit damage="<<damage<<" hp="<<cp.health<<"/"<<cp.maxHealth<<"\n";if(cp.health<=0){if(activeWeapon&&lossSpec&&(!cp.model||!cp.model->noDrop)&&lossSpec->weaponLossFlag==2)dropCoopWeapon(cp);if(cp.model&&cp.model->summonKill>0)unsummonChildren(std::uintptr_t((&cp-&coopPlayers_[0])+2),cp.model->summonKill>=2);if(cp.model)runModelScript(cp.model->onDeathScript,cp.scriptCtx,"coop-ondeath");playDieSound(cp.model);cp.alive=false;auto d=attackType==1002?findAnimation(cp.model,"bdeath"):nullptr;if(!d&&cp.model&&cp.model->fallDie!=1)d=findAnimation(cp.model,"fall");if(!d)d=findAnimation(cp.model,"death");if(!d)d=findAnimation(cp.model,"fall");cp.animation.setAnimation(d);cp.lastFrame=(std::size_t)-1;}else if(knockdown||painAllowed){if(cp.model)runModelScript(knockdown?cp.model->onFallScript:cp.model->onPainScript,cp.scriptCtx,knockdown?"coop-onfall":"coop-onpain");cp.hitStun=10;auto p=reactionAnimation(cp.model,knockdown?"fall":"pain",attackType);if(!p)p=findAnimation(cp.model,knockdown?"fall":"pain");if(p)cp.animation.setAnimation(p);if(knockdown){cp.landingDamage=landingDamage;cp.landingMode=landingMode;cp.landingType=landingType;cp.landingHitTargets.clear();cp.jumping=true;cp.knockdownAir=true;cp.runningJump=false;cp.altitude=-1.0f;cp.verticalVelocity=(float)dropVy;}cp.lastFrame=(std::size_t)-1;}
}
void Engine::queueAttackFlash(const generated::Frame* frame,const generated::Character* target,bool blocked,const RectF& attack,const RectF& body,float targetX,float targetZ,int targetFacing){
  if(!frame||!target||frame->attack.noFlash||!overlaps(attack,body))return;
  const char* custom=blocked?frame->blockFlash:frame->hitFlash;
  const char* fallback=blocked?target->blockFlashModel:target->flashModel;
  const generated::Character* effect=nullptr;
  if(!target->noAttackFlash&&custom&&*custom&&lowerString(custom)!="none")effect=findCharacter(custom);
  if(!effect&&fallback&&*fallback&&lowerString(fallback)!="none")effect=findCharacter(fallback);
  if(!effect)return;
  float x=(std::max(attack.x,body.x)+std::min(attack.x+attack.w,body.x+body.w))*0.5f;
  float y=(std::max(attack.y,body.y)+std::min(attack.y+attack.h,body.y+body.h))*0.5f;
  PendingChildSpawn q;q.model=effect;q.worldX=x;q.z=targetZ;q.altitude=y-targetZ;q.facing=effect->flipFlash?(x>targetX?1:-1):targetFacing;q.animationEffect=true;q.effectSpawnType=9;pendingChildSpawns_.push_back(q);
}
void Engine::resolveCombat(){
  auto pf=player_.frame();RectF playerBox=bboxFor(pf,playerWorldX_,playerZ_+playerAltitude_,playerFacing_);
  auto activatePlayerFollow=[&](const generated::Animation* source){auto*f=followAnimationFor(playerModel_,source);if(!f)return false;player_.setAnimation(f);lastFrame_=(std::size_t)-1;playerAttackTicks_=animationDuration(f);playerAttackCooldown_=std::max(2,playerAttackTicks_/3);playerComboWindow_=0;playerQueuedAttack_=false;playerProjectileFired_=false;playerAttackHasHit_=false;playerAttackHits_=0;++playerAttackId_;return true;};
  auto activateCoopFollow=[&](RuntimeCoopPlayer&cp,const generated::Animation* source){auto*f=followAnimationFor(cp.model,source);if(!f)return false;cp.animation.setAnimation(f);cp.lastFrame=(std::size_t)-1;cp.attackTicks=animationDuration(f);cp.attackCooldown=std::max(2,cp.attackTicks/3);cp.comboWindow=0;cp.projectileFired=false;cp.attackHasHit=false;cp.attackHits=0;++cp.attackId;return true;};
  auto activateEntityFollow=[&](RuntimeEntity&e,const generated::Animation* source){auto*f=followAnimationFor(e.model,source);if(!f)return false;setEntityAnimation(e,f);e.hitStun=e.fallTicks=e.recoveryTicks=0;e.attackTicks=animationDuration(f);e.attackCooldown=std::max(2,e.attackTicks/3);e.projectileFired=false;e.attackHasHit=false;e.attackHits=0;return true;};
  auto activateEntityCounter=[&](RuntimeEntity&e,const CounterResult&cr){if(!cr.animation||!e.alive)return;setEntityAnimation(e,cr.animation);e.hitStun=e.fallTicks=e.recoveryTicks=0;e.attackTicks=animationDuration(cr.animation);e.attackCooldown=std::max(2,e.attackTicks/3);e.projectileFired=false;e.attackHasHit=false;e.attackHits=0;};
  auto activatePlayerCounter=[&](const CounterResult&cr){if(!cr.animation||!playerAlive_)return;player_.setAnimation(cr.animation);lastFrame_=(std::size_t)-1;playerHitStun_=playerFallTicks_=playerRecoveryTicks_=0;playerAttackTicks_=animationDuration(cr.animation);playerAttackCooldown_=std::max(2,playerAttackTicks_/3);playerProjectileFired_=false;playerAttackHasHit_=false;playerAttackHits_=0;playerQueuedAttack_=false;++playerAttackId_;};
  auto activateCoopCounter=[&](RuntimeCoopPlayer&cp,const CounterResult&cr){if(!cr.animation||!cp.alive)return;cp.animation.setAnimation(cr.animation);cp.lastFrame=(std::size_t)-1;cp.hitStun=0;cp.attackTicks=animationDuration(cr.animation);cp.attackCooldown=std::max(2,cp.attackTicks/3);cp.projectileFired=false;cp.attackHasHit=false;cp.attackHits=0;++cp.attackId;};
  auto collisionHook=[&](const generated::Character* model,ScriptContext& ctx,std::uintptr_t self,std::uintptr_t target){
    if(!model||!model->onEntityCollisionScript||!*model->onEntityCollisionScript)return;
    ctx.local["self"]=self;ctx.local["target"]=target;ctx.local["other"]=target;ctx.other=reinterpret_cast<void*>(target);
    runModelScript(model->onEntityCollisionScript,ctx,"actor-entitycollision");
    ctx.local.erase("target");ctx.local.erase("other");ctx.other=nullptr;
  };
  for(auto& e:entities_){if(!e.alive||!e.visible||!e.model)continue;
    auto body=bboxFor(e.animation.frame(),e.worldX,e.z+e.altitude,e.facing);
    if(playerAlive_&&overlaps(playerBox,body)){
      collisionHook(e.model,e.scriptCtx,(std::uintptr_t)&e,1);
      if(playerAlive_&&e.alive)collisionHook(playerModel_,playerScriptCtx_,1,(std::uintptr_t)&e);
    }
    for(std::size_t i=0;i<coopPlayers_.size();++i){auto& cp=coopPlayers_[i];if(!cp.alive||!e.alive)continue;
      if(overlaps(bboxFor(cp.animation.frame(),cp.worldX,cp.z+cp.altitude,cp.facing),body)){
        collisionHook(e.model,e.scriptCtx,(std::uintptr_t)&e,i+2);
        if(cp.alive&&e.alive)collisionHook(cp.model,cp.scriptCtx,i+2,(std::uintptr_t)&e);
      }
    }
  }
  // Player/coop victims use the same projectile-on-fall rule.
  if(playerAlive_&&playerLandingMode_>=1&&playerAltitude_<0.0f){
    auto* sf=player_.frame();if(sf&&sf->hasAttack){RectF satk=attackFor(sf,playerWorldX_,playerZ_+playerAltitude_,playerFacing_);
      for(std::size_t ci=0;ci<coopPlayers_.size();++ci){auto& target=coopPlayers_[ci];auto h=std::uintptr_t(ci+2);if(!target.alive||playerLandingHitTargets_.contains(h))continue;auto*tf=target.animation.frame();if(tf&&overlaps(satk,bboxFor(tf,target.worldX,target.z+target.altitude,target.facing))){playerLandingHitTargets_.insert(h);damageCoopPlayer(target,std::max(0,sf->attack.damage),(float)playerFacing_,true,sf->dropVy,sf->attack.type,1,0,0,-1,sf->dropVx,sf->attack.forceDirection);}}
    }
  }
  for(std::size_t si=0;si<coopPlayers_.size();++si){auto& source=coopPlayers_[si];if(!source.alive||source.landingMode<1||source.altitude>=0.0f)continue;auto*sf=source.animation.frame();if(!sf||!sf->hasAttack)continue;RectF satk=attackFor(sf,source.worldX,source.z+source.altitude,source.facing);
    if(playerAlive_&&!source.landingHitTargets.contains(1)&&overlaps(satk,playerBox)){source.landingHitTargets.insert(1);damagePlayer(std::max(0,sf->attack.damage),(float)source.facing,true,sf->dropVy,sf->attack.type,std::uintptr_t(si+2),0,0,-1,sf->dropVx,sf->attack.forceDirection);}
    for(std::size_t ti=0;ti<coopPlayers_.size();++ti){if(ti==si)continue;auto&target=coopPlayers_[ti];auto h=std::uintptr_t(ti+2);if(!target.alive||source.landingHitTargets.contains(h))continue;auto*tf=target.animation.frame();if(tf&&overlaps(satk,bboxFor(tf,target.worldX,target.z+target.altitude,target.facing))){source.landingHitTargets.insert(h);damageCoopPlayer(target,std::max(0,sf->attack.damage),(float)source.facing,true,sf->dropVy,sf->attack.type,std::uintptr_t(si+2),0,0,-1,sf->dropVx,sf->attack.forceDirection);}}
  }
  // OpenBOR damageonlanding mode 1: while airborne, the knocked-down entity
  // becomes a projectile. Its current FALL attack box may hit allied entities once per fall.
  for(auto& source:entities_){
    if(!source.alive||!source.visible||!source.model||source.landingMode<1||source.altitude>=0.0f)continue;
    auto* sf=source.animation.frame();if(!sf||!sf->hasAttack)continue;
    RectF satk=attackFor(sf,source.worldX,source.z+source.altitude,source.facing);
    auto sourceType=lowerString(source.model->type?source.model->type:"");
    for(auto& target:entities_){
      if(&target==&source||!target.alive||!target.visible||!target.model||source.landingHitTargets.contains((std::uintptr_t)&target))continue;
      auto targetType=lowerString(target.model->type?target.model->type:"");
      if(sourceType!=targetType)continue;
      auto* tf=target.animation.frame();if(!tf||!overlaps(satk,bboxFor(tf,target.worldX,target.z+target.altitude,target.facing)))continue;
      source.landingHitTargets.insert((std::uintptr_t)&target);
      int fallDamage=std::max(0,sf->attack.damage);
      damageEnemy(target,fallDamage,(float)source.facing,true,sf->dropVy,sf->attack.type,(std::uintptr_t)&source,0,0,-1,sf->dropVx,sf->attack.forceDirection);
      queueAttackFlash(sf,target.model,false,satk,bboxFor(tf,target.worldX,target.z+target.altitude,target.facing),target.worldX,target.z,target.facing);
    }
  }
  if(playerAlive_&&playerAttackTicks_>0&&pf&&pf->hasAttack){const generated::Animation* sourceAnim=player_.animation();RectF atk=attackFor(pf,playerWorldX_,playerZ_+playerAltitude_,playerFacing_);int damage=std::max(0,pf->attack.damage);for(auto& e:entities_){if(!e.alive||e.grabbed||!e.model||e.lastPlayerAttackId==playerAttackId_)continue;auto t=lowerString(e.model->type);if(t=="item"||t=="projectile"||t=="none")continue;if(!modelCanDamage(playerModel_,e.model,t=="enemy"||t=="obstacle"))continue;if((e.fallTicks>0||e.altitude<0.0f)&&e.juggleRemaining<=0)continue;auto ef=e.animation.frame();if(!overlaps(atk,bboxFor(ef,e.worldX,e.z+e.altitude,e.facing)))continue;auto hitBody=bboxFor(ef,e.worldX,e.z+e.altitude,e.facing);float hitX=e.worldX,hitZ=e.z;int hitFacing=e.facing;playHitFx(sourceAnim);e.lastPlayerAttackId=playerAttackId_;if(e.fallTicks>0||e.altitude<0.0f)--e.juggleRemaining;bool hostile=t=="enemy";bool fromFront=(playerWorldX_<e.worldX&&e.facing<0)||(playerWorldX_>e.worldX&&e.facing>0);CounterResult cr=counterFor(e.model,e.animation.animation(),e.animation.frameIndex(),hostile,pf->attack.penetration>0,fromFront,e.health,damage);bool blocked=false;bool kd=pf->knockdown;if(cr.animation){if(cr.takesDamage){int dealt=damage;if(cr.rage&&damage>=e.health)dealt=std::max(0,e.health-1);if(dealt>0)damageEnemy(e,dealt,(float)playerFacing_,false,pf->dropVy,pf->attack.type,std::uintptr_t(1));}activateEntityCounter(e,cr);}else{blocked=tryBlockEntity(e,*pf,std::uintptr_t(1));if(!blocked)damageEnemy(e,damage,(float)playerFacing_,kd,pf->dropVy,pf->attack.type,std::uintptr_t(1),pf->attack.landingDamage,pf->attack.landingMode,pf->attack.landingType,pf->dropVx,pf->attack.forceDirection);}queueAttackFlash(pf,e.model,blocked,atk,hitBody,hitX,hitZ,hitFacing);bool lethal=!e.alive;playerEnergyPending_.hit=true;playerAttackHasHit_=true;++playerAttackHits_;if(playerModel_){playerScriptCtx_.local["damagetaker"]=std::uintptr_t((std::uintptr_t)&e);playerScriptCtx_.local["damage"]=(double)damage;playerScriptCtx_.local["drop"]=kd;playerScriptCtx_.local["attacktype"]=(double)pf->attack.type;playerScriptCtx_.local["blocked"]=blocked;runModelScript(playerModel_->didHitScript,playerScriptCtx_,"player-didhit");}if(sourceAnim&&followConditionPass(sourceAnim->followCond,blocked,hostile,lethal,e.model->noGrab)&&activatePlayerFollow(sourceAnim))break;if(sourceAnim&&sourceAnim->attackOne)break;}}
  for(std::size_t pi=0;pi<coopPlayers_.size();++pi){auto& cp=coopPlayers_[pi];auto f=cp.animation.frame();if(!cp.alive||cp.attackTicks<=0||!f||!f->hasAttack)continue;const generated::Animation* sourceAnim=cp.animation.animation();unsigned id=(unsigned)((pi+2)*1000000u)+(cp.attackId%1000000u);RectF atk=attackFor(f,cp.worldX,cp.z+cp.altitude,cp.facing);for(auto& e:entities_){if(!e.alive||e.grabbed||!e.model||e.lastPlayerAttackId==id)continue;auto t=lowerString(e.model->type);if(t=="item"||t=="projectile"||t=="none")continue;if(!modelCanDamage(cp.model,e.model,t=="enemy"||t=="obstacle"))continue;if(!overlaps(atk,bboxFor(e.animation.frame(),e.worldX,e.z+e.altitude,e.facing)))continue;auto hitBody=bboxFor(e.animation.frame(),e.worldX,e.z+e.altitude,e.facing);float hitX=e.worldX,hitZ=e.z;int hitFacing=e.facing;playHitFx(sourceAnim);e.lastPlayerAttackId=id;std::cout<<"P"<<(pi+2)<<" hit "<<(e.model?e.model->name:"enemy")<<"\n";int damage=std::max(0,f->attack.damage);bool hostile=t=="enemy";bool fromFront=(cp.worldX<e.worldX&&e.facing<0)||(cp.worldX>e.worldX&&e.facing>0);CounterResult cr=counterFor(e.model,e.animation.animation(),e.animation.frameIndex(),hostile,f->attack.penetration>0,fromFront,e.health,damage);bool blocked=false;bool kd=f->knockdown;if(cr.animation){if(cr.takesDamage){int dealt=damage;if(cr.rage&&damage>=e.health)dealt=std::max(0,e.health-1);if(dealt>0)damageEnemy(e,dealt,(float)cp.facing,false,f->dropVy,f->attack.type,std::uintptr_t(pi+2));}activateEntityCounter(e,cr);}else{blocked=tryBlockEntity(e,*f,std::uintptr_t(pi+2));if(!blocked)damageEnemy(e,damage,(float)cp.facing,kd,f->dropVy,f->attack.type,std::uintptr_t(pi+2),f->attack.landingDamage,f->attack.landingMode,f->attack.landingType,f->dropVx,f->attack.forceDirection);}queueAttackFlash(f,e.model,blocked,atk,hitBody,hitX,hitZ,hitFacing);cp.scriptCtx.local["damagetaker"]=std::uintptr_t((std::uintptr_t)&e);cp.scriptCtx.local["blocked"]=blocked;runModelScript(cp.model?cp.model->didHitScript:"",cp.scriptCtx,"coop-didhit");cp.energyPending.hit=true;cp.attackHasHit=true;++cp.attackHits;bool lethal=!e.alive;if(sourceAnim&&followConditionPass(sourceAnim->followCond,blocked,hostile,lethal,e.model->noGrab)&&activateCoopFollow(cp,sourceAnim))break;if(sourceAnim&&sourceAnim->attackOne)break;}}
  for(auto& e:entities_){if(!e.alive||e.grabbed||!e.model||e.attackTicks<=0||e.attackHasHit||lowerString(e.model->type)!="enemy")continue;auto ef=e.animation.frame();if(!ef||!ef->hasAttack)continue;const generated::Animation* sourceAnim=e.animation.animation();RectF atk=attackFor(ef,e.worldX,e.z+e.altitude,e.facing);int dmg=std::max(0,ef->attack.damage);bool kd=ef->knockdown;if(playerAlive_&&modelCanDamage(e.model,playerModel_,true)&&overlaps(atk,playerBox)){float hitX=playerWorldX_,hitZ=playerZ_;int hitFacing=playerFacing_;playHitFx(sourceAnim);e.energyPending.hit=true;e.attackHasHit=true;++e.attackHits;bool fromFront=(e.worldX<playerWorldX_&&playerFacing_<0)||(e.worldX>playerWorldX_&&playerFacing_>0);CounterResult cr=counterFor(playerModel_,player_.animation(),player_.frameIndex(),true,ef->attack.penetration>0,fromFront,playerHealth_,dmg);bool blocked=false;if(cr.animation){if(cr.takesDamage){int dealt=dmg;if(cr.rage&&dmg>=playerHealth_)dealt=std::max(0,playerHealth_-1);if(dealt>0)damagePlayer(dealt,(float)e.facing,false,ef->dropVy,ef->attack.type,std::uintptr_t((std::uintptr_t)&e));}activatePlayerCounter(cr);}else{blocked=tryBlockPlayer(0,*ef,std::uintptr_t((std::uintptr_t)&e));if(!blocked)damagePlayer(dmg,(float)e.facing,kd,ef->dropVy,ef->attack.type,std::uintptr_t((std::uintptr_t)&e),ef->attack.landingDamage,ef->attack.landingMode,ef->attack.landingType,ef->dropVx,ef->attack.forceDirection);}queueAttackFlash(ef,playerModel_,blocked,atk,playerBox,hitX,hitZ,hitFacing);e.scriptCtx.local["damagetaker"]=std::uintptr_t(1);e.scriptCtx.local["damage"]=(double)dmg;e.scriptCtx.local["drop"]=kd;e.scriptCtx.local["attacktype"]=(double)ef->attack.type;e.scriptCtx.local["blocked"]=blocked;runModelScript(e.model->didHitScript,e.scriptCtx,"entity-didhit");bool lethal=!playerAlive_;if(sourceAnim&&followConditionPass(sourceAnim->followCond,blocked,true,lethal,playerModel_?playerModel_->noGrab:false))activateEntityFollow(e,sourceAnim);continue;}for(std::size_t ci=0;ci<coopPlayers_.size();++ci){auto&cp=coopPlayers_[ci];if(!cp.alive||!modelCanDamage(e.model,cp.model,true)||!overlaps(atk,bboxFor(cp.animation.frame(),cp.worldX,cp.z+cp.altitude,cp.facing)))continue;auto hitBody=bboxFor(cp.animation.frame(),cp.worldX,cp.z+cp.altitude,cp.facing);float hitX=cp.worldX,hitZ=cp.z;int hitFacing=cp.facing;playHitFx(sourceAnim);e.energyPending.hit=true;e.attackHasHit=true;++e.attackHits;bool fromFront=(e.worldX<cp.worldX&&cp.facing<0)||(e.worldX>cp.worldX&&cp.facing>0);CounterResult cr=counterFor(cp.model,cp.animation.animation(),cp.animation.frameIndex(),true,ef->attack.penetration>0,fromFront,cp.health,dmg);bool blocked=false;if(cr.animation){if(cr.takesDamage){int dealt=dmg;if(cr.rage&&dmg>=cp.health)dealt=std::max(0,cp.health-1);if(dealt>0)damageCoopPlayer(cp,dealt,(float)e.facing,false,ef->dropVy,ef->attack.type,std::uintptr_t((std::uintptr_t)&e));}activateCoopCounter(cp,cr);}else{blocked=tryBlockPlayer((int)ci+1,*ef,std::uintptr_t((std::uintptr_t)&e));if(!blocked)damageCoopPlayer(cp,dmg,(float)e.facing,kd,ef->dropVy,ef->attack.type,std::uintptr_t((std::uintptr_t)&e),ef->attack.landingDamage,ef->attack.landingMode,ef->attack.landingType,ef->dropVx,ef->attack.forceDirection);}queueAttackFlash(ef,cp.model,blocked,atk,hitBody,hitX,hitZ,hitFacing);e.scriptCtx.local["damagetaker"]=std::uintptr_t(ci+2);e.scriptCtx.local["damage"]=(double)dmg;e.scriptCtx.local["drop"]=kd;e.scriptCtx.local["attacktype"]=(double)ef->attack.type;e.scriptCtx.local["blocked"]=blocked;runModelScript(e.model->didHitScript,e.scriptCtx,"entity-didhit");bool lethal=!cp.alive;if(sourceAnim&&followConditionPass(sourceAnim->followCond,blocked,true,lethal,cp.model?cp.model->noGrab:false))activateEntityFollow(e,sourceAnim);break;}
    if(e.attackHasHit)continue;
    for(auto& target:entities_){
      if(&target==&e||!target.alive||target.grabbed||!target.model)continue;
      auto tt=lowerString(target.model->type?target.model->type:"");if(tt=="item"||tt=="projectile"||tt=="none")continue;
      if(!modelCanDamage(e.model,target.model,false)||!overlaps(atk,bboxFor(target.animation.frame(),target.worldX,target.z+target.altitude,target.facing)))continue;
      auto hitBody=bboxFor(target.animation.frame(),target.worldX,target.z+target.altitude,target.facing);float hitX=target.worldX,hitZ=target.z;int hitFacing=target.facing;playHitFx(sourceAnim);e.energyPending.hit=true;e.attackHasHit=true;++e.attackHits;bool hostile=modelIsHostileTo(e.model,target.model,false);bool fromFront=(e.worldX<target.worldX&&target.facing<0)||(e.worldX>target.worldX&&target.facing>0);CounterResult cr=counterFor(target.model,target.animation.animation(),target.animation.frameIndex(),hostile,ef->attack.penetration>0,fromFront,target.health,dmg);bool blocked=false;if(cr.animation){if(cr.takesDamage){int dealt=dmg;if(cr.rage&&dmg>=target.health)dealt=std::max(0,target.health-1);if(dealt>0)damageEnemy(target,dealt,(float)e.facing,false,ef->dropVy,ef->attack.type,std::uintptr_t((std::uintptr_t)&e));}activateEntityCounter(target,cr);}else{blocked=tryBlockEntity(target,*ef,std::uintptr_t((std::uintptr_t)&e));if(!blocked)damageEnemy(target,dmg,(float)e.facing,kd,ef->dropVy,ef->attack.type,std::uintptr_t((std::uintptr_t)&e),ef->attack.landingDamage,ef->attack.landingMode,ef->attack.landingType,ef->dropVx,ef->attack.forceDirection);}queueAttackFlash(ef,target.model,blocked,atk,hitBody,hitX,hitZ,hitFacing);e.scriptCtx.local["damagetaker"]=std::uintptr_t((std::uintptr_t)&target);e.scriptCtx.local["damage"]=(double)dmg;e.scriptCtx.local["drop"]=kd;e.scriptCtx.local["attacktype"]=(double)ef->attack.type;e.scriptCtx.local["blocked"]=blocked;runModelScript(e.model->didHitScript,e.scriptCtx,"entity-didhit-entity");bool lethal=!target.alive;if(sourceAnim&&followConditionPass(sourceAnim->followCond,blocked,hostile,lethal,target.model->noGrab))activateEntityFollow(e,sourceAnim);break;
    }
  }
  for(auto& p:projectiles_){if(!p.alive||!p.model)continue;auto f=p.animation.frame();if(!f||(p.exploded&&!f->hasAttack))continue;const generated::Animation* projectileAnim=p.animation.animation();if(projectileAnim&&projectileAnim->attackOne&&p.attackSpent)continue;RectF atk=f->hasAttack?attackFor(f,p.worldX,p.z+p.altitude,p.facing):bboxFor(f,p.worldX,p.z+p.altitude,p.facing);int damage=f->hasAttack?std::max(0,f->attack.damage):1;bool contactDetonated=false;
    auto targetAllowed=[&](const generated::Character* target,bool legacy){int bit=openborTypeBit(target);if(p.hitMask!=0)return bit!=0&&(p.hitMask&bit)!=0;return modelCanDamage(p.model,target,legacy,p.ownerModel);};
    for(auto& e:entities_){if(!p.alive)break;if(!e.alive||!e.model||p.hitTargets.contains((std::uintptr_t)&e)||(e.model==p.model&&lowerString(e.model->type)=="projectile"))continue;auto t=lowerString(e.model->type);bool legacy=p.fromPlayer&&(t=="enemy"||t=="obstacle");if(!targetAllowed(e.model,legacy))continue;if(overlaps(atk,bboxFor(e.animation.frame(),e.worldX,e.z+e.altitude,e.facing))){queueAttackFlash(f,e.model,false,atk,bboxFor(e.animation.frame(),e.worldX,e.z+e.altitude,e.facing),e.worldX,e.z,e.facing);playHitFx(p.animation.animation());damageEnemy(e,damage,(float)p.facing,f->knockdown,f->dropVy,f->attack.type,p.fromPlayer?std::uintptr_t(1):std::uintptr_t(0),f->attack.landingDamage,f->attack.landingMode,f->attack.landingType,f->dropVx,f->attack.forceDirection);p.hitTargets.insert((std::uintptr_t)&e);if(projectileAnim&&projectileAnim->attackOne)p.attackSpent=true;bool detonated=projectileContact(p);contactDetonated=detonated;std::cout<<"Projectile hit "<<e.model->name<<"\n";if(detonated||p.attackSpent)break;}}
    if(!p.alive||contactDetonated)continue;if(playerAlive_&&!p.hitTargets.contains(1)&&targetAllowed(playerModel_,!p.fromPlayer)&&overlaps(atk,playerBox)){queueAttackFlash(f,playerModel_,false,atk,playerBox,playerWorldX_,playerZ_,playerFacing_);playHitFx(p.animation.animation());damagePlayer(damage,(float)p.facing,f->knockdown,f->dropVy,f->attack.type,0,f->attack.landingDamage,f->attack.landingMode,f->attack.landingType,f->dropVx,f->attack.forceDirection);p.hitTargets.insert(1);if(projectileAnim&&projectileAnim->attackOne)p.attackSpent=true;if(projectileContact(p))continue;std::cout<<"Projectile hit player\n";if(p.attackSpent)continue;}
    for(auto& cp:coopPlayers_)if(p.alive&&cp.alive&&!p.hitTargets.contains((std::uintptr_t)(&cp-&coopPlayers_[0])+2)&&targetAllowed(cp.model,!p.fromPlayer)&&overlaps(atk,bboxFor(cp.animation.frame(),cp.worldX,cp.z+cp.altitude,cp.facing))){queueAttackFlash(f,cp.model,false,atk,bboxFor(cp.animation.frame(),cp.worldX,cp.z+cp.altitude,cp.facing),cp.worldX,cp.z,cp.facing);playHitFx(p.animation.animation());damageCoopPlayer(cp,damage,(float)p.facing,f->knockdown,f->dropVy,f->attack.type,0,f->attack.landingDamage,f->attack.landingMode,f->attack.landingType,f->dropVx,f->attack.forceDirection);p.hitTargets.insert((std::uintptr_t)(&cp-&coopPlayers_[0])+2);if(projectileAnim&&projectileAnim->attackOne)p.attackSpent=true;std::cout<<"Projectile hit coop player\n";if(projectileContact(p)||p.attackSpent)break;}
  }
}
void Engine::updateCombatLock(){
  if(!config_.cameraLockOnCombat) return; bool active=false; for(const auto& e:entities_) if(e.alive&&e.model&&lowerString(e.model->type)=="enemy"){active=true;break;}
  if(active && !combatLocked_ && cameraX_>1.0f){ combatLocked_=true; combatLockX_=cameraX_; std::cout<<"Camera locked for combat at "<<combatLockX_<<"\n"; }
  else if(!active && combatLocked_){ combatLocked_=false; std::cout<<"Camera released after wave\n"; }
}
float Engine::scrollMin() const{
  if(!stage_) return 0.0f;
  if(scrollDir_<0) return 0.0f;
  return cameraMaxX_;
}
float Engine::scrollMax() const{
  float view=(float)std::max(160,config_.logicalWidth);
  float hard=std::max(0.0f,stageLength_-view);
  if(scrollBlocked_) return std::min(hard, cameraX_);
  return hard;
}
void Engine::updateCamera(){
  float previousCamera=cameraX_;
  float view=(float)std::max(160,config_.logicalWidth);
  if(verticalScroll_){if(!scrollBlocked_)verticalStageScroll_+=100.0f/60.0f;cameraX_=0.0f;cameraMaxX_=0.0f;return;}
  if(cameraFixed_){ cameraX_=std::clamp(cameraX_,0.0f,std::max(0.0f,stageLength_-view)); cameraMaxX_=std::max(cameraMaxX_,cameraX_); return; }
  float focus=0.0f;int aliveCount=0;if(playerAlive_){focus+=playerWorldX_;++aliveCount;}for(const auto& cp:coopPlayers_)if(cp.alive){focus+=cp.worldX;++aliveCount;}if(aliveCount==0)return;focus/=(float)aliveCount;
  float target=cameraX_;float left=cameraX_+view*0.35f,right=cameraX_+view*0.65f;if(focus>right)target=focus-view*0.65f;else if(focus<left)target=focus-view*0.35f;
  if(scrollDir_<0){ target=std::clamp(target,0.0f,std::max(0.0f,stageLength_-view)); if(combatLocked_ && combatLockX_>1.0f) target=std::max(target,combatLockX_); cameraX_=target; }
  else if(allowBacktrack_){ float hi=std::max(0.0f,stageLength_-view);target=std::clamp(target,std::clamp(backtrackFloor_,0.0f,hi),hi);if(scrollBlocked_)target=std::min(target,cameraX_);if(combatLocked_&&combatLockX_>1.0f)target=std::min(target,combatLockX_);cameraX_=target; }
  else { target=std::clamp(target,0.0f,scrollMax()); if(combatLocked_ && combatLockX_>1.0f) target=std::min(target,std::max(combatLockX_,cameraMaxX_)); if(target<cameraMaxX_-1.0f) target=cameraMaxX_; cameraX_=target; }
  if(stage_&&stage_->scrollSpeed>0){float maxStep=(float)std::max(1,stage_->scrollSpeed);cameraX_=previousCamera+std::clamp(cameraX_-previousCamera,-maxStep,maxStep);}
  cameraMaxX_=std::max(cameraMaxX_,cameraX_);
}
void Engine::processStageInstructions(){
  if(!stage_)return;
  if(stage_->instructionCount==0){updateStageEvents();triggerSpawns();return;}

  int activeEnemies=0;for(const auto&e:entities_)if(e.alive&&e.model&&lowerString(e.model->type)=="enemy")++activeEnemies;
  // A wait freezes progress until the enemies spawned at/before that gate are gone.
  // On the frame the wait is encountered we keep consuming same-trigger actions,
  // matching the OpenBOR Build 3797 queue behavior.
  if(scrollBlocked_){if(activeEnemies>0)return;scrollBlocked_=false;}
  if(activeEnemies>=groupMin_)return;

  auto reached=[&](int at,bool hasAt){
    if(!hasAt||at<=0)return true;
    if(verticalScroll_)return verticalStageScroll_>=(float)at;
    if(scrollDir_<0)return cameraX_<=(float)at;
    return cameraX_+(float)std::max(160,config_.logicalWidth)>=(float)at;
  };
  auto findSpawnIndex=[&](int id)->std::size_t{for(std::size_t i=0;i<stage_->spawnCount;++i)if(stage_->spawns[i].id==id)return i;return (std::size_t)-1;};
  auto findEventIndex=[&](int id)->std::size_t{for(std::size_t i=0;i<stage_->eventCount;++i)if(stage_->events[i].id==id)return i;return (std::size_t)-1;};

  while(nextInstruction_<stage_->instructionCount){
    if(activeEnemies>=groupMax_)break;
    const auto&ins=stage_->instructions[nextInstruction_];
    if(ins.kind==0){
      std::size_t i=findSpawnIndex(ins.refId);if(i==(std::size_t)-1){++nextInstruction_;continue;}
      const auto&s=stage_->spawns[i];
      if(i<spawnState_.size()&&spawnState_[i]!=0){++nextInstruction_;continue;}
      if(!reached(s.at,s.hasAt))break; // authored trigger inversions intentionally gate later actions
      ++nextInstruction_;
      if(s.id<0){if(i<spawnState_.size())spawnState_[i]=2;continue;}
      if(i<spawnState_.size())spawnState_[i]=1;
      const generated::Character* spawnModel=findCharacter(s.model);
      RuntimeEntity e;e.spawn=&s;e.model=spawnModel;e.subjectToScreen=spawnModel?spawnModel->subjectToScreen:false;e.weaponDropsRemaining=spawnModel?std::max(0,spawnModel->weaponDropCounter):-1;
      e.worldX=(float)(verticalScroll_?s.x:(s.hasAt?s.at+s.x:s.x));e.z=(float)s.z;e.altitude=-(float)std::max(0,s.a);e.paletteMap=paletteIndexFromText(s.map);
      if(e.model){e.maxHealth=e.health=std::max(1,s.health>0?s.health:e.model->health);e.maxMp=e.mp=std::max(0,e.model->mp);e.lifeTicks=e.model->lifespanSeconds>0.0f?std::max(1,(int)std::lround(e.model->lifespanSeconds*60.0f)):-1;e.juggleRemaining=std::max(1,e.model->jugglePoints);e.facing=s.flip?-1:1;auto startAnim=findAnimation(e.model,"idle");if(!startAnim)startAnim=findAnimation(e.model,"walk");e.animation.setAnimation(startAnim);}
      std::string kind=e.model?lowerString(e.model->type):"";if(s.spawnType==1)kind="item";
      entities_.push_back(std::move(e));auto&spawned=entities_.back();spawned.scriptCtx.entity=&spawned;spawned.scriptCtx.local["self"]=std::uintptr_t((std::uintptr_t)&spawned);runModelScript(spawned.model?spawned.model->onSpawnScript:"",spawned.scriptCtx,"entity-onspawn");
      if(s.spawnScript&&*s.spawnScript){spawned.scriptCtx.local["spawnx"]=(double)spawned.worldX;spawned.scriptCtx.local["spawnz"]=(double)spawned.z;spawned.scriptCtx.local["spawny"]=(double)(-spawned.altitude);spawned.scriptCtx.local["spawnat"]=(double)s.at;runModelScript(s.spawnScript,spawned.scriptCtx,"spawnscript");}
      if(i<spawnState_.size())spawnState_[i]=2;++nextSpawn_;
      bool groupedEnemy=spawnModel&&lowerString(spawnModel->type)=="enemy"&&s.spawnType!=1&&s.spawnType!=2;if(groupedEnemy)++activeEnemies;
      if(s.boss&&!bossMusicStarted_&&stage_->bossMusic&&*stage_->bossMusic){auto bm=resolveAudioAsset(root_/"assets"/"openbor-data",stage_->bossMusic);if(audio_.playMusic(bm,true,(std::size_t)std::max(0,stage_->bossMusicOffset))){bossMusicStarted_=true;std::cout<<"Boss music started loop_offset_bytes="<<stage_->bossMusicOffset<<"\n";}else std::cerr<<"Boss music diagnostic: "<<audio_.lastError()<<"\n";}
      std::cout<<"Stage action spawn id="<<s.id<<" model="<<s.model<<" at="<<s.at<<" worldX="<<spawned.worldX<<"\n";
    }else{
      std::size_t i=findEventIndex(ins.refId);if(i==(std::size_t)-1){++nextInstruction_;continue;}
      const auto&ev=stage_->events[i];if(i<eventState_.size()&&eventState_[i]!=0){++nextInstruction_;continue;}
      if(!reached(ev.at,ev.hasAt))break;
      ++nextInstruction_;if(i<eventState_.size())eventState_[i]=2;std::string kind=lowerString(ev.kind?ev.kind:"");
      if(kind=="wait"){scrollBlocked_=true;std::cout<<"Wait gate armed at "<<ev.at<<"\n";}
      else if(kind=="group"){groupMin_=ev.value<1?100:ev.value;groupMax_=ev.group<1?1:ev.group;std::cout<<"Group rule min="<<groupMin_<<" max="<<groupMax_<<" at="<<ev.at<<"\n";}
      else if(kind=="blockade"){float floor=(float)(ev.value!=0?ev.value:ev.at);backtrackFloor_=std::max(backtrackFloor_,floor);std::cout<<"Blockade floor="<<backtrackFloor_<<" trigger="<<ev.at<<"\n";}
    }
  }
}

void Engine::updateStageEvents(){
  if(!stage_) return;
  auto reachedAt=[&](int at,bool hasAt){if(!hasAt||at<=0)return true;if(verticalScroll_)return verticalStageScroll_>=(float)at;float edge=scrollDir_<0?cameraX_:cameraX_+(float)std::max(160,config_.logicalWidth);return scrollDir_<0?cameraX_<=(float)at:edge>=(float)at;};
  int activeEnemies=0;for(const auto& e:entities_)if(e.alive&&e.model&&lowerString(e.model->type)=="enemy")++activeEnemies;
  if(stage_->instructionCount>0){
    if(!groupRefillActive_){if(activeEnemies>=groupMin_)return;groupRefillActive_=true;}
    while(nextInstruction_<stage_->instructionCount){
      const auto& ins=stage_->instructions[nextInstruction_];if(ins.kind==0)break;
      std::size_t ei=stage_->eventCount;for(std::size_t i=0;i<stage_->eventCount;++i)if(stage_->events[i].id==ins.refId){ei=i;break;}
      if(ei>=stage_->eventCount){++nextInstruction_;continue;}
      const auto& ev=stage_->events[ei];if(!reachedAt(ev.at,ev.hasAt)){groupRefillActive_=false;break;}
      std::string kind=lowerString(ev.kind?ev.kind:"");
      if(kind=="wait"){
        scrollBlocked_=true;eventState_[ei]=2;std::cout<<"Wait armed at "<<ev.at<<"\n";
      }else if(kind=="blockade"){
        float floor=(float)(ev.value!=0?ev.value:ev.at);backtrackFloor_=std::max(backtrackFloor_,floor);eventState_[ei]=2;std::cout<<"Blockade floor="<<backtrackFloor_<<" trigger="<<ev.at<<"\n";
      }else if(kind=="group"){
        groupMin_=ev.value<1?100:ev.value;groupMax_=ev.group<1?1:ev.group;eventState_[ei]=2;std::cout<<"Group rule min="<<groupMin_<<" max="<<groupMax_<<" at="<<ev.at<<"\n";
      }else{
        eventState_[ei]=2;
      }
      ++nextInstruction_;
      if(activeEnemies>=groupMax_){groupRefillActive_=false;break;}
    }
    return;
  }
  for(std::size_t i=0;i<stage_->eventCount && i<eventState_.size();++i){
    if(eventState_[i]!=0) continue;
    const auto& ev=stage_->events[i];std::string kind=lowerString(ev.kind?ev.kind:"");
    if(!reachedAt(ev.at,ev.hasAt))continue;
    if(kind=="wait"){
      bool enemies=false;for(const auto&e:entities_)if(e.alive&&e.model&&lowerString(e.model->type)=="enemy"){enemies=true;break;}
      if(enemies){scrollBlocked_=true;continue;}scrollBlocked_=false;eventState_[i]=2;std::cout<<"Wait cleared at "<<ev.at<<"\n";
    }else if(kind=="blockade"){
      float floor=(float)(ev.value!=0?ev.value:ev.at);backtrackFloor_=std::max(backtrackFloor_,floor);eventState_[i]=2;std::cout<<"Blockade floor="<<backtrackFloor_<<" trigger="<<ev.at<<"\n";
    }else if(kind=="group"){
      groupMin_=std::max(0,ev.value);groupMax_=std::max(groupMin_,ev.group);groupRefillActive_=false;eventState_[i]=2;std::cout<<"Group rule min="<<groupMin_<<" max="<<groupMax_<<" at="<<ev.at<<"\n";
    }else eventState_[i]=2;
  }
}
void Engine::triggerSpawns(){
  if(!stage_) return;
  auto reachedAt=[&](int at,bool hasAt){if(!hasAt||at<=0)return true;if(verticalScroll_)return verticalStageScroll_>=(float)at;float edge=scrollDir_<0?cameraX_:cameraX_+(float)std::max(160,config_.logicalWidth);return scrollDir_<0?cameraX_<=(float)at:edge>=(float)at;};
  int activeEnemies=0;for(const auto& e:entities_)if(e.alive&&e.model&&lowerString(e.model->type)=="enemy")++activeEnemies;
  auto spawnOne=[&](std::size_t i){
    const auto& s=stage_->spawns[i];if(s.id<0){spawnState_[i]=2;return;}
    spawnState_[i]=1;
    const generated::Character* spawnModel=findCharacter(s.model);
    RuntimeEntity e; e.spawn=&s; e.model=spawnModel; e.subjectToScreen=spawnModel?spawnModel->subjectToScreen:false; e.weaponDropsRemaining=spawnModel?std::max(0,spawnModel->weaponDropCounter):-1; e.worldX=(float)(s.hasAt?s.at+s.x:s.x); e.z=(float)s.z; e.altitude=-(float)std::max(0,s.a); e.paletteMap=paletteIndexFromText(s.map);
    if(e.model){ e.maxHealth=e.health=std::max(1,s.health>0?s.health:e.model->health); e.maxMp=e.mp=std::max(0,e.model->mp); e.lifeTicks=e.model->lifespanSeconds>0.0f?std::max(1,(int)std::lround(e.model->lifespanSeconds*60.0f)):-1; e.juggleRemaining=std::max(1,e.model->jugglePoints); e.facing=s.flip?-1:1; auto startAnim=findAnimation(e.model,"idle"); if(!startAnim) startAnim=findAnimation(e.model,"walk"); e.animation.setAnimation(startAnim); }
    entities_.push_back(std::move(e));auto& spawned=entities_.back(); spawned.scriptCtx.entity=&spawned; spawned.scriptCtx.local["self"]=std::uintptr_t((std::uintptr_t)&spawned); runModelScript(spawned.model?spawned.model->onSpawnScript:"",spawned.scriptCtx,"entity-onspawn");
    if(s.spawnScript&&*s.spawnScript){spawned.scriptCtx.local["spawnx"]=(double)spawned.worldX;spawned.scriptCtx.local["spawnz"]=(double)spawned.z;spawned.scriptCtx.local["spawny"]=(double)(-spawned.altitude);spawned.scriptCtx.local["spawnat"]=(double)s.at;runModelScript(s.spawnScript,spawned.scriptCtx,"spawnscript");}
    spawnState_[i]=2;++nextSpawn_;if(s.boss&&!bossMusicStarted_&&stage_->bossMusic&&*stage_->bossMusic){auto bm=resolveAudioAsset(root_/"assets"/"openbor-data",stage_->bossMusic);if(audio_.playMusic(bm,true,(std::size_t)std::max(0,stage_->bossMusicOffset))){bossMusicStarted_=true;std::cout<<"Boss music started loop_offset_bytes="<<stage_->bossMusicOffset<<"\n";}else std::cerr<<"Boss music diagnostic: "<<audio_.lastError()<<"\n";}
    std::cout<<"Spawn trigger id="<<s.id<<" model="<<s.model<<" at="<<s.at<<" worldX="<<spawned.worldX<<" boss="<<(s.boss?"yes":"no")<<" state=COMPLETED\n";
  };
  if(stage_->instructionCount>0){
    if(!groupRefillActive_){if(activeEnemies>=groupMin_)return;groupRefillActive_=true;}
    while(nextInstruction_<stage_->instructionCount){
      const auto& ins=stage_->instructions[nextInstruction_];if(ins.kind!=0)break;
      std::size_t si=stage_->spawnCount;for(std::size_t i=0;i<stage_->spawnCount;++i)if(stage_->spawns[i].id==ins.refId){si=i;break;}
      if(si>=stage_->spawnCount){++nextInstruction_;continue;}
      const auto& sp=stage_->spawns[si];if(!reachedAt(sp.at,sp.hasAt)){groupRefillActive_=false;break;}
      const generated::Character* m=findCharacter(sp.model);bool grouped=m&&lowerString(m->type)=="enemy"&&sp.spawnType!=1&&sp.spawnType!=2;
      if(grouped&&activeEnemies>=groupMax_){groupRefillActive_=false;break;}
      spawnOne(si);++nextInstruction_;if(grouped)++activeEnemies;
      if(grouped&&activeEnemies>=groupMax_){groupRefillActive_=false;break;}
    }
    if(scrollBlocked_){bool enemies=false;for(const auto&e:entities_)if(e.alive&&e.model&&lowerString(e.model->type)=="enemy"){enemies=true;break;}if(!enemies){scrollBlocked_=false;std::cout<<"Wait cleared\n";}}
    return;
  }
  if(groupMax_>0 && !groupRefillActive_ && activeEnemies<groupMin_)groupRefillActive_=true;
  for(std::size_t i=0;i<stage_->spawnCount && i<spawnState_.size();++i){
    if(spawnState_[i]!=0) continue;const auto& s=stage_->spawns[i];if(!reachedAt(s.at,s.hasAt))continue;
    if(scrollBlocked_ && !verticalScroll_ && s.hasAt && s.at>(int)cameraX_+(int)std::max(160,config_.logicalWidth)) continue;
    const generated::Character* spawnModel=findCharacter(s.model);bool groupedEnemy=spawnModel&&lowerString(spawnModel->type)=="enemy"&&s.spawnType!=1&&s.spawnType!=2;
    if(groupedEnemy&&groupMax_>0){if(!groupRefillActive_)continue;if(activeEnemies>=groupMax_){groupRefillActive_=false;continue;}}
    spawnOne(i);if(groupedEnemy&&groupMax_>0){++activeEnemies;if(activeEnemies>=groupMax_)groupRefillActive_=false;}
  }
}
void Engine::loadCurrentPlayerSprite(){
  settleAnimationEnergy(playerEnergyPending_,player_,playerHealth_,playerMp_);
  auto f=player_.frame(); if(!f) return; if(lastFrame_==player_.frameIndex()) return; lastFrame_=player_.frameIndex();
  if(playerModel_){playerScriptCtx_.local["frame"]=(double)player_.frameIndex();runAnimationCommand(playerModel_,f,playerScriptCtx_,"player-animation-frame",player_.animation());}
  auto a=player_.animation();triggerQuake(playerModel_,a,player_.frameIndex());if(a&&a->flipFrame>=0&&(int)player_.frameIndex()==a->flipFrame)playerFacing_=-playerFacing_;if(a&&a->weaponFrame>=0&&(int)player_.frameIndex()==a->weaponFrame)setPlayerWeaponIndex(a->weaponIndex);const generated::Character* frameOwner=(equippedWeapon_&&a&&exactAnimation(equippedWeapon_,a->name?a->name:"")==a)?equippedWeapon_:playerModel_;queueChildSpawn(frameOwner,a,player_.frameIndex(),playerWorldX_,playerZ_,playerAltitude_,playerFacing_,std::uintptr_t(1));if(a&&a->unsummonFrame>=0&&(int)player_.frameIndex()==a->unsummonFrame)unsummonChildren(std::uintptr_t(1),false);
  playerWorldX_+=f->moveX*(float)playerFacing_; playerZ_+=f->moveZ; if(f->hasSetA)playerAltitude_=-f->setA;else playerAltitude_-=f->moveA; playFrameSound(f); sprite_=SpriteImage{}; if(lowerString(f->sprite)!="none" && f->sprite[0]){renderer_.loadSprite(resolveSpriteAsset(root_/"assets"/"openbor-data",f->sprite),sprite_);applyCharacterPalette(renderer_,root_/"assets"/"openbor-data",playerModel_,f->draw.remap>0?f->draw.remap:playerPaletteMap_,sprite_);}
}
void Engine::loadEntitySprite(RuntimeEntity& e){
  auto f=e.animation.frame(); if(!f || e.lastFrame==e.animation.frameIndex()) return; e.lastFrame=e.animation.frameIndex();e.scriptCtx.local["frame"]=(double)e.animation.frameIndex();runAnimationCommand(e.model,f,e.scriptCtx,"entity-animation-frame",e.animation.animation());
  auto a=e.animation.animation();triggerQuake(e.model,a,e.animation.frameIndex());if(a&&a->flipFrame>=0&&(int)e.animation.frameIndex()==a->flipFrame)e.facing=-e.facing;if(a&&a->weaponFrame>=0&&(int)e.animation.frameIndex()==a->weaponFrame)setEntityWeaponIndex(e,a->weaponIndex);const generated::Character* frameOwner=(e.equippedWeapon&&a&&exactAnimation(e.equippedWeapon,a->name?a->name:"")==a)?e.equippedWeapon:e.model;queueChildSpawn(frameOwner,a,e.animation.frameIndex(),e.worldX,e.z,e.altitude,e.facing,std::uintptr_t((std::uintptr_t)&e));if(a&&a->unsummonFrame>=0&&(int)e.animation.frameIndex()==a->unsummonFrame)unsummonChildren(std::uintptr_t((std::uintptr_t)&e),false);
  e.worldX+=f->moveX*(float)e.facing; e.z+=f->moveZ; if(f->hasSetA)e.altitude=-f->setA;else e.altitude-=f->moveA; playFrameSound(f); e.sprite=SpriteImage{}; if(lowerString(f->sprite)!="none" && f->sprite[0]){renderer_.loadSprite(resolveSpriteAsset(root_/"assets"/"openbor-data",f->sprite),e.sprite);applyCharacterPalette(renderer_,root_/"assets"/"openbor-data",e.model,f->draw.remap>0?f->draw.remap:e.paletteMap,e.sprite);}
}
bool Engine::consumeRespawnResource(int playerSlot){
  const int baseLives=std::max(1,stage_&&stage_->lives>0?stage_->lives:1);
  const bool separate=stage_&&stage_->noShare>0;
  int* lives=&livesRemaining_;int* credits=&creditsRemaining_;
  if(separate&&playerSlot>0){for(auto&cp:coopPlayers_)if(cp.playerSlot==playerSlot){lives=&cp.livesRemaining;credits=&cp.creditsRemaining;break;}}
  if(*lives>1){--*lives;return true;}
  if(*credits>0){--*credits;*lives=baseLives;return true;}
  return false;
}
void Engine::respawnPlayerSlot(int playerSlot){
  if(!stage_)return;
  if(playerSlot==0){if(!playerModel_)return;playerAlive_=true;playerHealth_=std::max(1,playerMaxHealth_);playerMp_=std::max(0,playerMaxMp_);auto sp=stagePlayerSpawn(stage_,0,cameraX_,config_.logicalWidth,scrollDir_);playerWorldX_=sp.x;playerZ_=sp.z;playerAltitude_=sp.altitude;playerFacing_=sp.facing;playerVerticalVelocity_=0;playerJumpVelocityX_=playerJumpVelocityZ_=0;playerFallTicks_=playerRecoveryTicks_=playerHitStun_=playerAttackTicks_=0;playerJumping_=playerRunningJump_=playerAnimJumpTriggered_=false;player_.setAnimation(findAnimation(playerModel_,"idle"));if(!player_.frame())player_.setAnimation(findAnimation(playerModel_,"walk"));lastFrame_=(std::size_t)-1;runModelScript(playerModel_->onSpawnScript,playerScriptCtx_,"player-respawn");return;}
  for(auto&cp:coopPlayers_)if(cp.playerSlot==playerSlot){cp.alive=true;cp.health=std::max(1,cp.maxHealth);cp.mp=std::max(0,cp.maxMp);auto sp=stagePlayerSpawn(stage_,playerSlot,cameraX_,config_.logicalWidth,scrollDir_);cp.worldX=sp.x;cp.z=sp.z;cp.altitude=sp.altitude;cp.facing=sp.facing;cp.verticalVelocity=0;cp.scriptVelocityX=cp.scriptVelocityZ=0;cp.jumping=false;cp.knockdownAir=false;cp.runningJump=false;cp.hitStun=cp.attackTicks=cp.attackCooldown=0;cp.animation.setAnimation(findAnimation(cp.model,"idle"));if(!cp.animation.frame())cp.animation.setAnimation(findAnimation(cp.model,"walk"));cp.lastFrame=(std::size_t)-1;runModelScript(cp.model?cp.model->onSpawnScript:"",cp.scriptCtx,"coop-respawn");return;}
}
void Engine::drawHud(){
  auto iconFor=[&](const generated::Character* m,bool dead,int paletteMap)->const SpriteImage*{
    if(!m)return nullptr;const char* icon=(dead&&m->iconDiePath&&*m->iconDiePath)?m->iconDiePath:m->iconPath;if(!icon||!*icon)return nullptr;
    auto&cache=(dead&&m->iconDiePath&&*m->iconDiePath)?hudDeadIconCache_:hudIconCache_;
    std::string key=std::to_string((std::uintptr_t)m)+":"+std::to_string(m->iconUsesPalette?paletteMap:0);
    auto it=cache.find(key);if(it==cache.end()){SpriteImage img;renderer_.loadSprite(resolveSpriteAsset(root_/"assets"/"openbor-data",icon),img);if(m->iconUsesPalette&&paletteMap>0)applyCharacterPalette(renderer_,root_/"assets"/"openbor-data",m,paletteMap,img);it=cache.emplace(key,std::move(img)).first;}
    return it->second.width>0?&it->second:nullptr;
  };
  auto gaugeMetrics=[&](const generated::Character* m,int hp,int mx,int x,int y,bool popup){struct M{int x,y,w,h,fill,orientation;};int w=popup?std::max(1,m->lifeBarWidth):hudBarWidth_,h=popup?std::max(1,m->lifeBarHeight):hudBarHeight_;int type=popup?m->lifeBarType:1,orientation=popup?m->lifeBarOrientation:0;int capacity=orientation==1?h:w;int value=std::max(0,hp);int fill=type==1?(int)((float)capacity*(float)value/(float)std::max(1,mx)):std::min(capacity,value);return M{x,y,w,h,fill,orientation};};
  auto drawGauge=[&](const generated::Character* m,int hp,int mx,int x,int y,bool popup){if(!m)return;auto g=gaugeMetrics(m,hp,mx,x,y,popup);bool noBorder=popup&&m->lifeBarNoBorder!=0;if(!noBorder)renderer_.drawSolidRect(g.x,g.y,g.w,g.h,40,40,40);else renderer_.drawSolidRect(g.x,g.y,g.w,g.h,20,20,20);if(g.orientation==1){int fy=g.y+g.h-g.fill;renderer_.drawSolidRect(g.x,fy,g.w,g.fill,40,210,70);}else renderer_.drawSolidRect(g.x,g.y,g.fill,g.h,40,210,70);};
  auto drawOne=[&](const generated::Character* m,int hp,int mx,const std::string& label,int defaultX,int defaultY,bool selected,int paletteMap,bool popup){
    if(!m)return;int x=m->lifePositionX>=0?m->lifePositionX:defaultX,y=m->lifePositionY>=0?m->lifePositionY:defaultY;int nx=m->namePositionX>=0?m->namePositionX:x,ny=m->namePositionY>=0?m->namePositionY:y-8;const auto*ic=iconFor(m,hp<=0,paletteMap);int ix=ic?(m->iconPositionX>=0?m->iconPositionX:std::max(0,x-ic->width-3)):0,iy=ic?(m->iconPositionY>=0?m->iconPositionY:y-ic->height/2):0;
    bool showGauge=(popup&&m->lifeBarStatusDefined)||(!popup&&!m->noLife&&m->lifeBarStatus!=0);if(!popup||!m->lifeBarStatusDefined){renderer_.drawText(label,nx,ny,7,selected);if(ic)renderer_.drawImage(*ic,ix,iy);if(showGauge)drawGauge(m,hp,mx,x,y,false);return;}
    // lifebarstatus component layers are relative to the ordinary HUD/icon layer (0).
    // Stable sorting reproduces equal-layer source order while allowing negative layers
    // behind icons and positive layers in front, including OpenBOR's common +/- offsets.
    struct Part{int layer,kind,seq;};std::vector<Part> parts;int seq=0;parts.push_back({0,4,seq++});if(ic)parts.push_back({0,5,seq++});if(m->lifeBarNoBorder==0){parts.push_back({m->lifeBarShadowLayer,0,seq++});parts.push_back({m->lifeBarBorderLayer,1,seq++});}parts.push_back({m->lifeBarBackfillLayer,2,seq++});parts.push_back({m->lifeBarGraphLayer,3,seq++});std::stable_sort(parts.begin(),parts.end(),[](const Part&a,const Part&b){return a.layer==b.layer?a.seq<b.seq:a.layer<b.layer;});auto g=gaugeMetrics(m,hp,mx,x,y,true);for(const auto&p:parts){switch(p.kind){case 0:renderer_.drawSolidRect(g.x+1,g.y+1,g.w,g.h,15,15,15);break;case 1:renderer_.drawSolidRect(g.x-1,g.y-1,g.w+2,g.h+2,70,70,70);break;case 2:renderer_.drawSolidRect(g.x,g.y,g.w,g.h,20,20,20);break;case 3:if(g.orientation==1){int fy=g.y+g.h-g.fill;renderer_.drawSolidRect(g.x,fy,g.w,g.fill,40,210,70);}else renderer_.drawSolidRect(g.x,g.y,g.fill,g.h,40,210,70);break;case 4:renderer_.drawText(label,nx,ny,7,selected);break;case 5:renderer_.drawImage(*ic,ix,iy);break;}}
  };
  drawOne(playerModel_,playerHealth_,playerMaxHealth_,playerModel_&&playerModel_->name?playerModel_->name:"P1",8,10,true,playerPaletteMap_,false);
  if(stage_&&(stage_->lives>0||stage_->credits>0)){std::string lifeText;if(stage_->noShare>0){lifeText="P1 L"+std::to_string(std::max(0,livesRemaining_))+" C"+std::to_string(std::max(0,creditsRemaining_));for(const auto&cp:coopPlayers_)lifeText+="  P"+std::to_string(cp.playerSlot+1)+" L"+std::to_string(std::max(0,cp.livesRemaining))+" C"+std::to_string(std::max(0,cp.creditsRemaining));}else lifeText="LIVES "+std::to_string(std::max(0,livesRemaining_))+"  CREDITS "+std::to_string(std::max(0,creditsRemaining_));renderer_.drawText(lifeText,8,std::max(8,config_.logicalHeight-12),7,false);}
  for(std::size_t i=0;i<coopPlayers_.size();++i){auto&cp=coopPlayers_[i];drawOne(cp.model,cp.health,cp.maxHealth,cp.model&&cp.model->name?cp.model->name:("P"+std::to_string(i+2)),8+(int)(i+1)*(hudBarWidth_+8),10,false,cp.paletteMap,false);}
  int ey=28;for(const auto&e:entities_){if(!e.visible||!e.alive||!e.model)continue;std::string t=lowerString(e.model->type?e.model->type:"");if(t!="enemy"&&t!="obstacle")continue;bool popup=e.model->lifeBarStatusDefined;if(!popup&&e.model->noLife)continue;int defaultX=12,defaultY=ey;drawOne(e.model,e.health,e.maxHealth,e.model->name?e.model->name:"",defaultX,defaultY,false,e.paletteMap,popup);ey+=(popup?std::max(1,e.model->lifeBarHeight):hudBarHeight_)+3;if(ey>120)break;}
}
void Engine::renderScriptDrawQueue(){
  std::stable_sort(scriptDrawQueue_.begin(),scriptDrawQueue_.end(),[](const ScriptDrawCommand&a,const ScriptDrawCommand&b){return a.z<b.z;});
  for(const auto&c:scriptDrawQueue_){unsigned r=(c.color>>16)&255u,g=(c.color>>8)&255u,b=c.color&255u;switch(c.kind){
    case ScriptDrawCommand::Kind::Dot: renderer_.drawDot(c.x,c.y,c.color);break;
    case ScriptDrawCommand::Kind::Line: renderer_.drawLine(c.x,c.y,c.x2,c.y2,c.color);break;
    case ScriptDrawCommand::Kind::Box: renderer_.drawSolidRect(c.x,c.y,c.w,c.h,(unsigned char)r,(unsigned char)g,(unsigned char)b);break;
    case ScriptDrawCommand::Kind::Text: renderer_.drawText(c.text,c.x,c.y,std::max(6,8+c.font),false);break;
    case ScriptDrawCommand::Kind::Sprite:{auto it=scriptSprites_.find(c.sprite);if(it!=scriptSprites_.end())renderer_.drawImage(it->second,c.x,c.y);break;}
  }}
}
static SpriteImage legacyWaterSurface(const SpriteImage& src,int warp,int rock,unsigned long long tick){
  if(src.width<=0||src.height<=0||src.bgra.empty())return {};
  if(rock!=0&&rock!=1)return src;
  SpriteImage out;out.width=src.width;out.height=src.height;out.bgra.assign(src.bgra.size(),0);
  const double speed=(double)std::clamp(std::abs(warp),0,15);
  const double time=(double)tick/60.0;
  if(rock==0){
    // Classic `water path warp` effect: horizontal sine displacement is evaluated
    // independently for each scanline. `warp` controls animation speed (0 freezes
    // the phase), while amplitude/wavelength remain stable like the legacy command.
    const double phase=time*speed*1.65;const double wavelength=24.0;const double amplitude=5.0;
    for(int y=0;y<src.height;++y){int shift=(int)std::lround(std::sin(phase+(double)y*6.283185307179586/wavelength)*amplitude);for(int x=0;x<src.width;++x){int sx=(x-shift)%src.width;if(sx<0)sx+=src.width;std::size_t si=((std::size_t)y*src.width+sx)*4u,di=((std::size_t)y*out.width+x)*4u;std::memcpy(&out.bgra[di],&src.bgra[si],4);}}
    return out;
  }
  // rock 1 changes the water command from sine warp into the old perspective /
  // parallax pass: rows gradually widen toward the play field and the texture
  // advances with `warp`. Sampling wraps so horizontally tiled water stays seamless.
  const double travel=time*speed*2.0;
  for(int y=0;y<src.height;++y){double t=src.height>1?(double)y/(double)(src.height-1):1.0;double scale=0.76+0.42*t;double center=(src.width-1)*0.5;for(int x=0;x<src.width;++x){double u=(x-center)/scale+center+travel;int sx=(int)std::floor(u);sx%=src.width;if(sx<0)sx+=src.width;std::size_t si=((std::size_t)y*src.width+sx)*4u,di=((std::size_t)y*out.width+x)*4u;std::memcpy(&out.bgra[di],&src.bgra[si],4);}}
  return out;
}
void Engine::drawStage(){
  renderer_.beginFrame();
  int rockDx=0,rockDy=0;if(quakeTicks_>0){int q=std::max(1,quakeIntensity_);rockDx=(int)std::lround(std::sin((double)tickCounter_*2.13)*q);rockDy=(int)std::lround(std::cos((double)tickCounter_*1.71)*q);--quakeTicks_;if(quakeTicks_<=0)quakeIntensity_=0;}if(stage_&&stage_->rockMode>=1){double t=(double)tickCounter_/60.0;if(stage_->rockMode==1)rockDy=(int)std::lround(std::sin(t*1.8)*2.0);else if(stage_->rockMode==2){double cycle=std::fmod(t,2.2);if(cycle>1.55){double q=(cycle-1.55)*24.0;rockDx=(int)std::lround(std::sin(q)*3.0);rockDy=(int)std::lround(std::cos(q*0.75)*2.0);}}else if(stage_->rockMode==3){rockDx=(int)std::lround(std::sin(t*17.0)*1.5+std::sin(t*3.7)*1.0);rockDy=(int)std::lround(std::cos(t*13.0)*1.2+std::sin(t*2.1)*0.8);}}
  const float renderCameraX=cameraX_+(stage_?(float)stage_->cameraOffsetX:0.0f);const int cameraOffsetY=stage_?stage_->cameraOffsetY:0;
  auto drawLayer=[&](const RuntimeStageLayer&l){if(l.image.width<=0||l.image.height<=0)return;int stepX=std::max(1,l.image.width+l.xSpacing),stepY=std::max(1,l.image.height+l.zSpacing);int motion=(int)std::lround((double)tickCounter_*l.bgSpeedRatio/60.0);int base=l.xOffset-(int)(renderCameraX*l.xRatio)+motion+rockDx;int baseY=l.zOffset+cameraOffsetY+rockDy;int first=base;while(first>0)first-=stepX;int repeatX=l.xRepeat>0?std::min(256,l.xRepeat):256;int repeatY=l.zRepeat>0?std::min(64,l.zRepeat):1;int rowStart=baseY;while(rowStart>0&&repeatY>1)rowStart-=stepY;int rows=0;for(int y=rowStart;y<config_.logicalHeight&&rows<repeatY;y+=stepY,++rows){int drawn=0;for(int x=first;x<config_.logicalWidth&&drawn<repeatX;x+=stepX,++drawn){if(l.alpha>=1&&l.alpha<=6)renderer_.drawImageBlend(l.image,x,y,l.alpha);else renderer_.drawImage(l.image,x,y);}}};
  if(background_.width>0){if(verticalScroll_&&background_.height>0){int h=std::max(1,background_.height);int offset=(int)std::fmod(verticalStageScroll_*(float)verticalScrollSign_,(float)h);int start=backgroundOffsetY_+cameraOffsetY+rockDy-offset;while(start>0)start-=h;while(start<=-h)start+=h;for(int y=start;y<config_.logicalHeight;y+=h)renderer_.drawImage(background_,backgroundOffsetX_+rockDx,y);}else renderer_.drawImage(background_,backgroundOffsetX_-(int)(renderCameraX*backgroundRatioX_)+rockDx,backgroundOffsetY_+cameraOffsetY+rockDy);}
  for(const auto&l:backgroundLayers_)drawLayer(l);
  int panelX=-(int)renderCameraX+rockDx; for(const auto& p:panels_){ renderer_.drawImage(p,panelX,cameraOffsetY+rockDy); panelX+=p.width; }
  if(water_.width>0&&water_.height>0){int wy=(stage_?stage_->backgroundHeight:0)+cameraOffsetY;int warp=stage_?std::clamp(stage_->waterWarp,0,15):0;int rock=stage_?stage_->rockMode:0;SpriteImage transformed;if(rock==0||rock==1)transformed=legacyWaterSurface(water_,warp,rock,tickCounter_);const SpriteImage& drawWater=(transformed.width>0?transformed:water_);int floatY=(rock==1)?(int)std::lround(std::sin((double)tickCounter_/60.0*1.8)*2.0):0;int first=-drawWater.width+rockDx;while(first>0)first-=std::max(1,drawWater.width);for(int x=first;x<config_.logicalWidth;x+=std::max(1,drawWater.width))renderer_.drawImage(drawWater,x,wy+floatY+rockDy);}
  if(playerAlive_)drawShadow(playerModel_,playerWorldX_,playerZ_,playerAltitude_);for(auto&cp:coopPlayers_)if(cp.alive)drawShadow(cp.model,cp.worldX,cp.z,cp.altitude);for(auto&e:entities_)if(e.visible&&e.alive)drawShadow(e.model,e.worldX,e.z,e.altitude);
  struct ActorDraw {const SpriteImage* image;const generated::Frame* frame;const generated::Character* model;int x,y,groundY;bool flip;float depth;int sort;};
  std::vector<ActorDraw> actorDraws;
  auto queueActor=[&](std::uintptr_t h,const SpriteImage&img,const generated::Frame&frame,const generated::Character* model,float x,float z,float alt,int face){float depth=(model&&model->setLayer!=0)?(float)(stage_?stage_->zMin:0)+(float)model->setLayer:z;float shadowBase=z;if(model&&model->gfxShadow==1){int sb=std::clamp(model->gfxShadowBase,0,3);if((sb&2)!=0)shadowBase=z+alt;else if((sb&1)==0)shadowBase=z-dynamicPlatformHeight(x,z,nullptr,model);}actorDraws.push_back({&img,&frame,model,(int)(x-renderCameraX)+rockDx,(int)(z+alt)+cameraOffsetY+rockDy,(int)shadowBase+cameraOffsetY+rockDy,face<0,depth,bindingSortId(h)});};
  if(auto f=player_.frame()){ runModelScript(playerModel_?playerModel_->onDrawScript:"",playerScriptCtx_,"player-ondraw"); loadCurrentPlayerSprite(); queueActor(1,sprite_,*f,playerModel_,playerWorldX_,playerZ_,playerAltitude_,playerFacing_); }
  for(auto& cp:coopPlayers_){if(!cp.model)continue;auto f=cp.animation.frame();if(!f)continue;if(cp.lastFrame!=cp.animation.frameIndex()){cp.lastFrame=cp.animation.frameIndex();cp.scriptCtx.local["frame"]=(double)cp.animation.frameIndex();runAnimationCommand(cp.model,f,cp.scriptCtx,"coop-animation-frame",cp.animation.animation());auto ca=cp.animation.animation();triggerQuake(cp.model,ca,cp.animation.frameIndex());if(ca&&ca->flipFrame>=0&&(int)cp.animation.frameIndex()==ca->flipFrame)cp.facing=-cp.facing;if(ca&&ca->weaponFrame>=0&&(int)cp.animation.frameIndex()==ca->weaponFrame)setCoopWeaponIndex(cp,ca->weaponIndex);const generated::Character* frameOwner=(cp.equippedWeapon&&ca&&exactAnimation(cp.equippedWeapon,ca->name?ca->name:"")==ca)?cp.equippedWeapon:cp.model;queueChildSpawn(frameOwner,ca,cp.animation.frameIndex(),cp.worldX,cp.z,cp.altitude,cp.facing,std::uintptr_t((&cp-&coopPlayers_[0])+2));if(ca&&ca->unsummonFrame>=0&&(int)cp.animation.frameIndex()==ca->unsummonFrame)unsummonChildren(std::uintptr_t((&cp-&coopPlayers_[0])+2),false);cp.worldX+=f->moveX*(float)cp.facing;cp.z+=f->moveZ;if(f->hasSetA)cp.altitude=-f->setA;else cp.altitude-=f->moveA;playFrameSound(f);cp.sprite=SpriteImage{};if(lowerString(f->sprite)!="none"&&f->sprite[0]){renderer_.loadSprite(resolveSpriteAsset(root_/"assets"/"openbor-data",f->sprite),cp.sprite);applyCharacterPalette(renderer_,root_/"assets"/"openbor-data",cp.model,f->draw.remap>0?f->draw.remap:cp.paletteMap,cp.sprite);}}queueActor(std::uintptr_t((&cp-&coopPlayers_[0])+2),cp.sprite,*f,cp.model,cp.worldX,cp.z,cp.altitude,cp.facing);}
  for(auto& e:entities_){ if(!e.visible) continue; if(e.model){e.scriptCtx.entity=&e;e.scriptCtx.local["self"]=std::uintptr_t((std::uintptr_t)&e);runModelScript(e.model->onDrawScript,e.scriptCtx,"entity-ondraw");} auto f=e.animation.frame(); if(!f) continue; loadEntitySprite(e); queueActor((std::uintptr_t)&e,e.sprite,*f,e.model,e.worldX,e.z,e.altitude,e.facing); }
  // gfxshadow 1 projects the actor's current frame onto the ground plane. The
  // stage light vector controls flattening/shear and shadowalpha selects the
  // OpenBOR blend mode. gfxshadow 0 continues to use the generic shadow sprite.
  for(const auto&item:actorDraws){
    if(!item.model||item.model->gfxShadow!=1||!item.image||item.image->width<=0||!item.frame)continue;
    if(stage_&&stage_->shadowColor==-1)continue;
    generated::Frame shadowFrame=*item.frame;auto base=shadowFrame.draw;shadowFrame.draw.enabled=true;
    float lightY=stage_?(float)stage_->stageLightY:-80.0f;float lightX=stage_?(float)stage_->stageLightX:0.0f;
    float flatten=std::clamp(std::fabs(lightY)/180.0f,0.18f,1.0f);shadowFrame.draw.scaleX=base.enabled?base.scaleX:1.0f;shadowFrame.draw.scaleY=-flatten*std::max(0.01f,std::fabs(base.enabled?base.scaleY:1.0f));
    shadowFrame.draw.flipX=base.flipX;shadowFrame.draw.flipY=base.flipY;shadowFrame.draw.shiftX=(base.enabled?base.shiftX:0.0f)+(lightX/220.0f);
    shadowFrame.draw.rotate=0;shadowFrame.draw.flipRotate=false;shadowFrame.draw.remap=0;shadowFrame.draw.tintMode=0;shadowFrame.draw.tintColor=0;
    int blend=(stage_&&stage_->shadowAlpha>=1&&stage_->shadowAlpha<=6)?stage_->shadowAlpha:1;shadowFrame.draw.alphaMode=blend;
    if(stage_&&stage_->shadowColor==1)shadowFrame.draw.fillColor=0x101010;else if(!stage_||stage_->shadowAlpha<=0)shadowFrame.draw.fillColor=0x202020;else shadowFrame.draw.fillColor=0;
    renderer_.drawFrame(*item.image,shadowFrame,item.x,item.groundY,config_,item.flip,blend);
  }
  std::stable_sort(actorDraws.begin(),actorDraws.end(),[](const ActorDraw&a,const ActorDraw&b){return a.depth==b.depth?a.sort<b.sort:a.depth<b.depth;});
  for(const auto&item:actorDraws)renderer_.drawFrame(*item.image,*item.frame,item.x,item.y,config_,item.flip,item.model?item.model->alphaMode:0);
  for(auto& p:projectiles_){ if(!p.alive||!p.model)continue; auto f=p.animation.frame(); if(!f)continue; if(p.lastFrame!=p.animation.frameIndex()){p.lastFrame=p.animation.frameIndex();auto pa=p.animation.animation();triggerQuake(p.model,pa,p.animation.frameIndex());if(pa&&pa->flipFrame>=0&&(int)p.animation.frameIndex()==pa->flipFrame)p.facing=-p.facing;queueChildSpawn(p.model,pa,p.animation.frameIndex(),p.worldX,p.z,p.altitude,p.facing,std::uintptr_t(0));playFrameSound(f);p.sprite=SpriteImage{};if(lowerString(f->sprite)!="none" && f->sprite[0]){renderer_.loadSprite(resolveSpriteAsset(root_/"assets"/"openbor-data",f->sprite),p.sprite);applyCharacterPalette(renderer_,root_/"assets"/"openbor-data",p.model,f->draw.remap,p.sprite);}} renderer_.drawFrame(p.sprite,*f,(int)(p.worldX-renderCameraX)+rockDx,(int)(p.z+p.altitude)+cameraOffsetY+rockDy,config_,p.facing<0,p.model?p.model->alphaMode:0); }
  flushChildSpawns();
  renderScriptDrawQueue();
  for(const auto&l:foregroundLayers_)drawLayer(l);
  drawHud(); renderer_.endFrame();
}
int Engine::runSmokeGame(int frames){
  frames=std::clamp(frames,60,3600); smokeMode_=true; smokeFrameLimit_=frames; smokeFramesRun_=0;
  for(int i=0;i<4;++i){joinedPlayers_[i]=(i==0);selectIndexes_[i]=0;} config_.activePlayers=1; stageIndex_=0;
  smokeTrace("runSmokeGame before beginGame");
  suspendSave_=true; beginGame(); suspendSave_=false;
  smokeTrace("runSmokeGame after beginGame");
  if(frontendState_!=FrontendState::Playing||!stage_||!playerModel_){smokeMode_=false;std::cerr<<"SMOKE GAME FAIL: could not start gameplay\n";return 72;}
  const int savedFps=config_.fpsLimit; config_.fpsLimit=0;
  std::cout<<"SMOKE GAME START frames="<<frames<<" stage="<<(stage_->sourceFile?stage_->sourceFile:"")<<" player="<<(playerModel_->name?playerModel_->name:"")<<"\n";
  int rc=run(); config_.fpsLimit=savedFps;
  if(rc==0&&smokeFramesRun_>=smokeFrameLimit_)std::cout<<"SMOKE GAME OK frames="<<smokeFramesRun_<<"\n";
  else if(rc==0){std::cerr<<"SMOKE GAME FAIL gameplay_frames="<<smokeFramesRun_<<" expected="<<smokeFrameLimit_<<"\n";rc=73;}
  smokeMode_=false; return rc;
}
int Engine::run(){
  int headlessFrames=0,totalFrames=0,smokeTotalFrames=0;
  while(renderer_.isRunning() && renderer_.pumpEvents()){
    ++totalFrames; if(smokeMode_)++smokeTotalFrames;
    if(smokeMode_&&frontendState_==FrontendState::Playing)++smokeFramesRun_;
    if(frontendState_==FrontendState::Quit) break;
#ifdef _WIN32
    if(frontendState_==FrontendState::Playing && (frontendKeyPressed(VK_ESCAPE)||gamepadButtonPressed(XINPUT_GAMEPAD_START))){ frontendState_=FrontendState::Paused; pauseIndex_=0; }
#endif
    if(frontendState_!=FrontendState::Playing){
      updateFrontend(); drawFrontend();
    } else {
      scriptDrawQueue_.clear(); ++tickCounter_; pollAudioHotkeys(); if(std::filesystem::exists(root_/"assets"/"openbor-data"/"scripts"/"update.c"))runModelScript("scripts/update.c",stageScriptCtx_,"global-update"); updatePlayer(); updateCoopPlayers(); updateEntities(); applyEntityBindings(); updateProjectiles(); resolveCombat(); flushWeaponDrops(); updateCombatLock(); processStageInstructions(); updateCamera(); updateCombatLock(); if(std::filesystem::exists(root_/"assets"/"openbor-data"/"scripts"/"updated.c"))runModelScript("scripts/updated.c",stageScriptCtx_,"global-updated");
      if(tickCounter_%60==0){if(playerModel_&&playerModel_->guardPoints>0)playerGuardPoints_=std::min(playerModel_->guardPoints,playerGuardPoints_+std::max(1,playerModel_->guardRate));for(auto&cp:coopPlayers_)if(cp.model&&cp.model->guardPoints>0)cp.guardPoints=std::min(cp.model->guardPoints,cp.guardPoints+std::max(1,cp.model->guardRate));for(auto&e:entities_)if(e.model&&e.model->guardPoints>0)e.guardPoints=std::min(e.model->guardPoints,e.guardPoints+std::max(1,e.model->guardRate));}
      if(pendingBranchImmediate_ && pendingBranchTarget_!=(std::size_t)-1){auto target=pendingBranchTarget_;pendingBranchTarget_=(std::size_t)-1;pendingBranchImmediate_=false;int hp1=playerHealth_;bool p1Alive=playerAlive_;std::vector<int> coopHp;std::vector<bool> coopAlive;for(const auto&cp:coopPlayers_){coopHp.push_back(cp.health);coopAlive.push_back(cp.alive);}loadStage(target,true);playerAlive_=p1Alive;playerHealth_=p1Alive?std::clamp(hp1,1,std::max(1,playerMaxHealth_)):0;for(std::size_t i=0;i<coopPlayers_.size()&&i<coopHp.size();++i){coopPlayers_[i].alive=i<coopAlive.size()?coopAlive[i]:true;coopPlayers_[i].health=coopPlayers_[i].alive?std::clamp(coopHp[i],1,coopPlayers_[i].maxHealth):0;}}
      drawStage();
      if(!playerAlive_&&playerModel_&&consumeRespawnResource(0)){respawnPlayerSlot(0);std::cout<<"Respawn P1 lives="<<livesRemaining_<<" credits="<<creditsRemaining_<<"\n";}
      for(auto&cp:coopPlayers_)if(!cp.alive&&consumeRespawnResource(cp.playerSlot)){int slot=cp.playerSlot;respawnPlayerSlot(slot);std::cout<<"Respawn P"<<(slot+1)<<" lives="<<(stage_&&stage_->noShare>0?cp.livesRemaining:livesRemaining_)<<" credits="<<(stage_&&stage_->noShare>0?cp.creditsRemaining:creditsRemaining_)<<"\n";}
      bool anyPlayerAlive=playerAlive_;for(const auto&cp:coopPlayers_)anyPlayerAlive=anyPlayerAlive||cp.alive;if(!anyPlayerAlive){frontendState_=FrontendState::GameOver;saveProgress();
      } else if(stage_){bool pendingSequence=stage_->instructionCount>0&&nextInstruction_<stage_->instructionCount;bool pendingSpawn=false;if(stage_->instructionCount==0)for(std::size_t si=0;si<spawnState_.size();++si)if(spawnState_[si]==0&&stage_->spawns[si].id>=0){pendingSpawn=true;break;}bool enemies=false;for(const auto&e:entities_)if(e.alive&&e.model&&lowerString(e.model->type)=="enemy"){enemies=true;break;}float lead=playerAlive_?playerWorldX_:0.0f;for(const auto&cp:coopPlayers_)if(cp.alive)lead=std::max(lead,cp.worldX);bool exitReached=verticalScroll_||lead>=std::max(0.0f,stageLength_-(float)config_.logicalWidth*0.8f);if(!pendingSequence&&!pendingSpawn&&!enemies&&exitReached)advanceStage();}
    }
    if(smokeMode_&&smokeFramesRun_>=smokeFrameLimit_)break;
    if(smokeMode_&&smokeTotalFrames>=std::max(180,smokeFrameLimit_*3)){std::cerr<<"SMOKE GAME FAIL: gameplay stopped before target frames\n";saveSettings();return 74;}
    if(config_.fpsLimit>0){const int frameMs=std::max(1,1000/config_.fpsLimit);std::this_thread::sleep_for(std::chrono::milliseconds(frameMs));}
#ifndef _WIN32
    if(tickCounter_%120==0) std::cout<<"headless camera="<<cameraX_<<" player="<<playerWorldX_<<" max="<<cameraMaxX_<<"\n";
    if(++headlessFrames>900) break;
#endif
  }
  saveSettings();
#ifdef _WIN32
  if(totalFrames<3) return 70;
#endif
  return 0;
}
)CPP";

    std::ofstream main(src / "main.cpp");
    main << R"CPP(#include "PathEncoding.hpp"
#include "Engine.hpp"
#include "../generated/GeneratedCharacters.hpp"
#include "../generated/GeneratedStages.hpp"
#include <filesystem>
#include <fstream>
#include <iostream>
#include <exception>
#include <string>
#include <algorithm>
#include <cstdio>
#ifdef _WIN32
#define NOMINMAX
#include <windows.h>
#include <shellapi.h>
#endif

static std::filesystem::path executableDir(const char* argv0){
#ifdef _WIN32
  std::wstring buf(32768,L'\0'); DWORD n=GetModuleFileNameW(nullptr,buf.data(),(DWORD)buf.size());
  if(n>0 && n<buf.size()){buf.resize(n);return std::filesystem::path(buf).parent_path();}
#else
  std::error_code linkEc; auto self=std::filesystem::read_symlink("/proc/self/exe",linkEc); if(!linkEc && self.has_parent_path()) return self.parent_path();
#endif
  std::error_code ec; auto p=std::filesystem::absolute(PathEncoding::path(argv0?argv0:"openbor-port"),ec); if(!ec && p.has_parent_path()) return p.parent_path();
  return std::filesystem::current_path();
}
static std::filesystem::path findPortRoot(std::filesystem::path start){
  std::error_code ec; start=std::filesystem::absolute(start,ec);
  for(int depth=0;depth<8&&!start.empty();++depth){
    if(std::filesystem::is_directory(start/"assets"/"openbor-data",ec))return start;
    auto parent=start.parent_path();if(parent==start)break;start=parent;
  }
  return executableDir(nullptr);
}
static void appendStartupLog(const std::filesystem::path& logPath,const std::string& line){
  std::ofstream out(logPath,std::ios::app); if(out){out<<line<<"\n";out.flush();}
}
static bool gAutomatedRun=false;
static int failStartup(const std::filesystem::path& logPath,const std::string& msg){
  appendStartupLog(logPath,"FATAL: "+msg);
#ifdef _WIN32
  if(!gAutomatedRun){std::string text=msg+"\n\nLogs:\n"+PathEncoding::utf8(logPath)+"\n"+PathEncoding::utf8(logPath.parent_path()/"runtime-crash.log");
  MessageBoxW(nullptr,PathEncoding::path(text).wstring().c_str(),L"OpenBOR Native Port - erro de inicializacao",MB_OK|MB_ICONERROR|MB_SETFOREGROUND);}
#endif
  std::cerr<<msg<<"\n"; return 1;
}
#ifdef _WIN32
static wchar_t gCrashLogPath[32768]{};
static LONG WINAPI portUnhandledException(EXCEPTION_POINTERS* info){
  HANDLE h=CreateFileW(gCrashLogPath,FILE_APPEND_DATA,FILE_SHARE_READ|FILE_SHARE_WRITE,nullptr,OPEN_ALWAYS,FILE_ATTRIBUTE_NORMAL,nullptr);
  if(h!=INVALID_HANDLE_VALUE){
    char line[512]{};
    unsigned long code=info&&info->ExceptionRecord?info->ExceptionRecord->ExceptionCode:0;
    void* address=info&&info->ExceptionRecord?info->ExceptionRecord->ExceptionAddress:nullptr;
    MEMORY_BASIC_INFORMATION mbi{};wchar_t modulePath[32768]{};unsigned long long moduleOffset=0;
    if(address&&VirtualQuery(address,&mbi,sizeof(mbi))==sizeof(mbi)){auto base=(HMODULE)mbi.AllocationBase;GetModuleFileNameW(base,modulePath,(DWORD)(sizeof(modulePath)/sizeof(modulePath[0])));moduleOffset=(unsigned long long)((uintptr_t)address-(uintptr_t)base);}
    char moduleUtf8[32768]{};if(modulePath[0])WideCharToMultiByte(CP_UTF8,0,modulePath,-1,moduleUtf8,(int)sizeof(moduleUtf8),nullptr,nullptr);
    int n=snprintf(line,sizeof(line),"UNHANDLED SEH code=0x%08lX address=%p module=%s offset=0x%llX\r\n",code,address,moduleUtf8[0]?moduleUtf8:"?",moduleOffset);
    DWORD written=0;if(n>0)WriteFile(h,line,(DWORD)std::min<int>(n,(int)sizeof(line)-1),&written,nullptr);FlushFileBuffers(h);CloseHandle(h);
  }
  if(!gAutomatedRun)MessageBoxW(nullptr,L"O port encontrou uma falha fatal de baixo nivel.\n\nVeja runtime-crash.log na pasta do jogo.",L"OpenBOR Native Port - crash",MB_OK|MB_ICONERROR|MB_SETFOREGROUND);
  return EXCEPTION_EXECUTE_HANDLER;
}
static void installCrashHandler(const std::filesystem::path& root){
  auto p=(root/"runtime-crash.log").wstring();
  wcsncpy_s(gCrashLogPath,p.c_str(),_TRUNCATE);
  SetUnhandledExceptionFilter(portUnhandledException);
  SetErrorMode(SEM_FAILCRITICALERRORS|SEM_NOGPFAULTERRORBOX|SEM_NOOPENFILEERRORBOX);
}
#endif

static int runPort(int argc,char** argv){
  auto exe=executableDir(argc>0&&argv?argv[0]:nullptr); std::filesystem::path root=findPortRoot(exe); bool diagnose=false,smoke=false; int smokeFrames=600;
#ifdef _WIN32
  int wideCount=0;auto wideArgs=CommandLineToArgvW(GetCommandLineW(),&wideCount);
  if(wideArgs){
    for(int i=1;i<wideCount;++i){
      if(_wcsicmp(wideArgs[i],L"--diagnose")==0||_wcsicmp(wideArgs[i],L"--diagnostic")==0){diagnose=true;continue;}
      if(_wcsicmp(wideArgs[i],L"--smoke-game")==0){smoke=true;continue;}
      if(_wcsnicmp(wideArgs[i],L"--smoke-frames=",15)==0){smoke=true;try{smokeFrames=std::stoi(wideArgs[i]+15);}catch(...){smokeFrames=600;}continue;}
      if(wideArgs[i][0]!=L'-')root=findPortRoot(std::filesystem::path(wideArgs[i]));
    }
    LocalFree(wideArgs);
  }
#else
  for(int i=1;i<argc;++i){
    if(!argv[i])continue;
    std::string arg=argv[i];
    if(arg=="--diagnose"||arg=="--diagnostic"){diagnose=true;continue;}
    if(arg=="--smoke-game"){smoke=true;continue;}
    if(arg.rfind("--smoke-frames=",0)==0){smoke=true;try{smokeFrames=std::stoi(arg.substr(15));}catch(...){smokeFrames=600;}continue;}
    if(argv[i][0]!='-')root=findPortRoot(PathEncoding::path(argv[i]));
  }
#endif
  smokeFrames=std::clamp(smokeFrames,60,3600); gAutomatedRun=diagnose||smoke;
  auto logPath=root/"runtime-startup.log";
#ifdef _WIN32
  installCrashHandler(root);
  SetCurrentDirectoryW(root.wstring().c_str());
#endif
  appendStartupLog(logPath,"START exe="+PathEncoding::utf8(exe)+" root="+PathEncoding::utf8(root));
  try{
    std::error_code ec;
    const bool hasData=std::filesystem::is_directory(root/"assets"/"openbor-data",ec);
    appendStartupLog(logPath,std::string("PREFLIGHT assets=")+(hasData?"ok":"missing")+" characters="+std::to_string(generated::kCharacterCount)+" stages="+std::to_string(generated::kStageCount));
    if(!hasData) return failStartup(logPath,"Pasta assets/openbor-data nao encontrada. Mantenha o EXE junto das pastas assets e config.");
    if(generated::kCharacterCount==0) return failStartup(logPath,"Nenhum personagem foi gerado. O port precisa ser reconvertido pelo Builder.");
    if(generated::kStageCount==0) return failStartup(logPath,"Nenhuma fase foi gerada. O port precisa ser reconvertido pelo Builder.");
    if(diagnose){
      appendStartupLog(logPath,"DIAGNOSE OK");
      return 0;
    }
    Engine e;
    if(!e.initialize(root)) return failStartup(logPath,"Falha ao inicializar renderer/runtime. Veja runtime-startup.log.");
    appendStartupLog(logPath,"INITIALIZED OK");
    int rc=smoke?e.runSmokeGame(smokeFrames):e.run();
    if(smoke&&rc==0)appendStartupLog(logPath,"SMOKE GAME OK frames="+std::to_string(smokeFrames));
    appendStartupLog(logPath,"EXIT code="+std::to_string(rc));
    if(rc!=0) return failStartup(logPath,"O runtime encerrou de forma anormal (codigo "+std::to_string(rc)+").");
    return 0;
  }catch(const std::exception& ex){return failStartup(logPath,std::string("Excecao: ")+ex.what());}
   catch(...){return failStartup(logPath,"Excecao desconhecida durante a inicializacao.");}
}
#ifdef _WIN32
int WINAPI wWinMain(HINSTANCE,HINSTANCE,PWSTR,int){return runPort(0,nullptr);}
#else
int main(int argc,char** argv){return runPort(argc,argv);}
#endif
)CPP";

    std::ofstream cm(runtime / "CMakeLists.txt");
    cm << R"CMAKE(cmake_minimum_required(VERSION 3.20)
project(GeneratedOpenBORPort LANGUAGES CXX)
set(CMAKE_CXX_STANDARD 20)
if(MSVC)
  set(CMAKE_MSVC_RUNTIME_LIBRARY "MultiThreaded$<$<CONFIG:Debug>:Debug>")
endif()
if(WIN32)
  add_executable(openbor-port WIN32 src/main.cpp src/Engine.cpp src/Renderer.cpp src/AnimationPlayer.cpp src/RuntimeConfig.cpp src/AudioDecoder.cpp src/AudioSystem.cpp src/ScriptVM.cpp generated/GeneratedCharacters.cpp generated/GeneratedStages.cpp)
else()
  add_executable(openbor-port src/main.cpp src/Engine.cpp src/Renderer.cpp src/AnimationPlayer.cpp src/RuntimeConfig.cpp src/AudioDecoder.cpp src/AudioSystem.cpp src/ScriptVM.cpp generated/GeneratedCharacters.cpp generated/GeneratedStages.cpp)
endif()
target_include_directories(openbor-port PRIVATE include)
if(MSVC)
 target_compile_options(openbor-port PRIVATE /utf-8)
endif()
if(MINGW)
  target_link_options(openbor-port PRIVATE -static -static-libgcc -static-libstdc++)
endif()
if(WIN32)
  target_link_libraries(openbor-port PRIVATE windowscodecs ole32 user32 shell32 gdi32 msimg32 d3d11 dxgi d3dcompiler d2d1 dwrite mfplat mfreadwrite mfuuid)
  if(MINGW)
    target_link_libraries(openbor-port PRIVATE xaudio2_8 xinput9_1_0)
  else()
    target_link_libraries(openbor-port PRIVATE xaudio2 xinput)
  endif()
endif()
)CMAKE";

    std::ofstream portable(outDir / "BUILD-PORTABLE-WINDOWS.ps1");
    portable << R"PS1($ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Runtime = Join-Path $Root "runtime"
$Build = Join-Path $Runtime "build-portable-win64"
$Dist = Join-Path $Root "portable-win64"
if (Test-Path $Build) { Remove-Item $Build -Recurse -Force }
if (Test-Path $Dist) { Remove-Item $Dist -Recurse -Force }
New-Item -ItemType Directory -Force -Path $Dist | Out-Null
$attempts = @(
  @("-G","Visual Studio 18 2026","-A","x64","-T","ClangCL","-DCMAKE_MSVC_RUNTIME_LIBRARY=MultiThreaded"),
  @("-G","Visual Studio 17 2022","-A","x64","-T","ClangCL","-DCMAKE_MSVC_RUNTIME_LIBRARY=MultiThreaded"),
  @("-A","x64","-DCMAKE_MSVC_RUNTIME_LIBRARY=MultiThreaded"),
  @("-DCMAKE_BUILD_TYPE=Release")
)
$configured = $false
foreach ($extra in $attempts) {
  if (Test-Path $Build) { Remove-Item $Build -Recurse -Force }
  & cmake -S $Runtime -B $Build @extra
  if ($LASTEXITCODE -eq 0) { $configured = $true; break }
}
if (-not $configured) { throw "Nenhum toolchain Windows conseguiu configurar o runtime." }
cmake --build $Build --config Release
$BuiltExe = Get-ChildItem $Build -Recurse -Filter "openbor-port.exe" | Select-Object -First 1
if (-not $BuiltExe) { throw "openbor-port.exe nao foi encontrado apos a compilacao." }
Copy-Item $BuiltExe.FullName (Join-Path $Dist "OpenBOR-Port.exe")
Copy-Item (Join-Path $Root "assets") $Dist -Recurse
Copy-Item (Join-Path $Root "config") $Dist -Recurse
if (Test-Path (Join-Path $Root "saves")) { Copy-Item (Join-Path $Root "saves") $Dist -Recurse }
@'
@echo off
cd /d "%~dp0"
start "" /wait "OpenBOR-Port.exe"
set RC=%ERRORLEVEL%
if not "%RC%"=="0" (
  echo.
  echo O jogo encerrou com erro %RC%.
  if exist runtime-startup.log type runtime-startup.log
  if exist runtime-crash.log type runtime-crash.log
  pause
)
exit /b %RC%
'@ | Set-Content -Encoding ASCII (Join-Path $Dist "INICIAR-JOGO.cmd")
@'
@echo off
cd /d "%~dp0"
start "" /wait "OpenBOR-Port.exe" --diagnose
echo.
if exist runtime-startup.log type runtime-startup.log
if exist runtime-crash.log type runtime-crash.log
pause
'@ | Set-Content -Encoding ASCII (Join-Path $Dist "DIAGNOSTICO.cmd")
@'
@echo off
cd /d "%~dp0"
start "" /wait "OpenBOR-Port.exe" --smoke-game --smoke-frames=600
set RC=%ERRORLEVEL%
echo.
if exist runtime-startup.log type runtime-startup.log
if exist runtime-crash.log type runtime-crash.log
echo.
if "%RC%"=="0" (echo SMOKE TESTE: OK) else (echo SMOKE TESTE: FALHOU codigo %RC%)
pause
exit /b %RC%
'@ | Set-Content -Encoding ASCII (Join-Path $Dist "SMOKE-TESTE.cmd")
Write-Host "Portatil Win64 pronto em: $Dist"
)PS1";

    std::ofstream portableMingw(outDir / "BUILD-PORTABLE-MINGW.ps1");
    portableMingw << R"PS1($ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Runtime = Join-Path $Root "runtime"
$Build = Join-Path $Runtime "build-portable-mingw"
$Dist = Join-Path $Root "portable-win64"
$Cxx = (Get-Command x86_64-w64-mingw32-g++ -ErrorAction Stop).Source
$Cc = (Get-Command x86_64-w64-mingw32-gcc -ErrorAction Stop).Source
if (Test-Path $Build) { Remove-Item $Build -Recurse -Force }
if (Test-Path $Dist) { Remove-Item $Dist -Recurse -Force }
New-Item -ItemType Directory -Force -Path $Dist | Out-Null
cmake -S $Runtime -B $Build -G Ninja -DCMAKE_BUILD_TYPE=Release -DCMAKE_C_COMPILER=$Cc -DCMAKE_CXX_COMPILER=$Cxx
cmake --build $Build
Copy-Item (Join-Path $Build "openbor-port.exe") (Join-Path $Dist "OpenBOR-Port.exe")
Copy-Item (Join-Path $Root "assets") $Dist -Recurse
Copy-Item (Join-Path $Root "config") $Dist -Recurse
if (Test-Path (Join-Path $Root "saves")) { Copy-Item (Join-Path $Root "saves") $Dist -Recurse }
@'
@echo off
cd /d "%~dp0"
start "" /wait "OpenBOR-Port.exe"
set RC=%ERRORLEVEL%
if not "%RC%"=="0" (
  echo.
  echo O jogo encerrou com erro %RC%.
  if exist runtime-startup.log type runtime-startup.log
  if exist runtime-crash.log type runtime-crash.log
  pause
)
exit /b %RC%
'@ | Set-Content -Encoding ASCII (Join-Path $Dist "INICIAR-JOGO.cmd")
@'
@echo off
cd /d "%~dp0"
start "" /wait "OpenBOR-Port.exe" --diagnose
echo.
if exist runtime-startup.log type runtime-startup.log
if exist runtime-crash.log type runtime-crash.log
pause
'@ | Set-Content -Encoding ASCII (Join-Path $Dist "DIAGNOSTICO.cmd")
@'
@echo off
cd /d "%~dp0"
start "" /wait "OpenBOR-Port.exe" --smoke-game --smoke-frames=600
set RC=%ERRORLEVEL%
echo.
if exist runtime-startup.log type runtime-startup.log
if exist runtime-crash.log type runtime-crash.log
echo.
if "%RC%"=="0" (echo SMOKE TESTE: OK) else (echo SMOKE TESTE: FALHOU codigo %RC%)
pause
exit /b %RC%
'@ | Set-Content -Encoding ASCII (Join-Path $Dist "SMOKE-TESTE.cmd")
Write-Host "Portatil Win64 pronto em: $Dist"
)PS1";

    std::ofstream portableCmd(outDir / "BUILD-PORTABLE-WINDOWS.cmd");
    portableCmd << R"CMD(@echo off
setlocal
where cmake >nul 2>nul || (echo ERRO: CMake nao encontrado.& pause & exit /b 1)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0BUILD-PORTABLE-WINDOWS.ps1"
if errorlevel 1 pause
)CMD";


    std::ofstream compileRun(outDir / "COMPILAR-E-INICIAR-WINDOWS.cmd");
    compileRun << R"CMD(@echo off
setlocal
cd /d "%~dp0"
if not exist "portable-win64\OpenBOR-Port.exe" call "%~dp0BUILD-PORTABLE-WINDOWS.cmd"
if not exist "portable-win64\OpenBOR-Port.exe" (echo ERRO: executavel nao foi gerado.& pause & exit /b 1)
call "%~dp0portable-win64\INICIAR-JOGO.cmd"
)CMD";
}
