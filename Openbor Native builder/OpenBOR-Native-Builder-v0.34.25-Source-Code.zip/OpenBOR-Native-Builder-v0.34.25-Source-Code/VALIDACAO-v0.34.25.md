# Validacao — OpenBOR Native Builder v0.34.25

## Testes do Builder
- CMake/Ninja Release: PASS.
- ctest: 1/1 PASS.
- 9 suites de runtime: PASS.

## GoW real
- Models: 18.
- Stages: 5.
- Animations: 108.
- Scripts: 13.
- SUPPORTED: 2.783.
- PARTIAL: 0.
- UNSUPPORTED: 0.
- UNKNOWN: 1 (`heatlh`, typo do arquivo original).
- Runtime gerado: compilado em Release.
- Gameplay smoke: `SMOKE GAME OK frames=300`.

## Evil Dead v1.4.0 real
- Models: 125.
- Stages: 10.
- Animations: 634.
- Scripts: 31.
- SUPPORTED: 14.290.
- PARTIAL: 0.
- UNSUPPORTED: 0.
- UNKNOWN: 0.
- Runtime gerado: compilado em Release.
- Gameplay smoke: `SMOKE GAME OK frames=300`.

## Recursos novos verificados
- `water` sine warp por scanline.
- `water` rock 1 perspective/parallax.
- `rock` 0-3.
- include case-insensitive.
- include realocado por basename unico.
- include ausente redundante sem falso PARTIAL.
- include realmente necessario continua diagnosticado quando deixa simbolo sem implementacao.

## Windows x64 final
- GitHub Actions run: `37382260281` — PASS.
- Commit validado: `b8fe68d62006a4f6cdc56687a2b25c0a0b4b377f`.
- Builder Windows x64: compilado com Visual Studio 2026 + ClangCL — PASS.
- Fixture `water` + `rock` + include recovery: PASS.
- Runtime gerado Win64: compilado — PASS.
- `DIAGNOSE OK`: PASS.
- `SMOKE GAME OK frames=300`: PASS.
- EXE: PE32+ x86-64, Windows CUI.
- Dependencias importadas: `KERNEL32.dll`, `SHELL32.dll`, `USER32.dll`, `ole32.dll`, `COMDLG32.dll`.
- SHA-256 do EXE: `7f554e403a8d4d0011a9b28afc7d3f58e31f711ad1f9cebc0887b882813aaef7`.
- SHA-256 do ZIP portatil: `89808cbe9ed18774fa75deb7ff9c09be102c694a976c0b84b22145e866aa4008`.
