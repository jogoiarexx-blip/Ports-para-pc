# Changelog — v0.34.32

## Unified native scene queue
- Direct Drawing deixa de ser um passe separado depois dos atores: comandos de script entram na mesma fila Z/`sortid` de gameplay.
- Painel, sombras, `fglayer`, atores, projeteis, `frontpanel` e HUD recebem profundidades compativeis com os offsets historicos do OpenBOR.
- `drawsprite`/`drawscreen`/primitivas podem ficar atras, entre ou na frente de atores apenas pelo Z e `sortid`, sem hack de ordem fixa.
- Replays produzidos por `drawspriteq` tambem participam da fila compartilhada.
- `frontpanel` passa a usar xratio 1.5, evitando o scroll de background usado anteriormente por engano.
- Background e `bglayer` permanecem no passe de backdrop inferior, preservando a regra de serem as camadas de fundo.

## Testes
- CMake Release: PASS.
- Regression/ctest: 1/1 PASS.
- 10/10 suites de runtime: PASS.
- `runtime_commands` verifica Z abaixo/acima do jogador, desempate por `sortid`, e os offsets PANEL_Z/SHADOW_Z/FRONTPANEL_Z/HUD_Z.

---

# Changelog — v0.34.31

## Direct Drawing / ScriptVM
- `setdrawmethod` deixa de ser fallback/no-op e passa a manter drawmethod comum ou por entidade/jogador.
- `changedrawmethod` cobre reset, enabled/flag, scale X/Y, flip X/Y, shift X, alpha, remap/colourmap, fill color, rotate/fliprotate e tint mode/color.
- `drawsprite` captura uma copia imutavel do drawmethod no momento da submissao e preserva `sortid`.
- A fila de script ordena por Z, `sortid` e sequencia estavel.
- `drawspriteq` filtra min/max Z sem remover entradas, aplica dx/dy e rasteriza em subscreen; destino vazio cria replay para a superficie principal.
- `clearspriteq` limpa a porcao pendente sem invalidar replay ja descarregado.
- O transformador de imagem compartilhado aplica scale, flip, shift, fill, tint e rotate antes da composicao, incluindo subscreens.
- Drawmethod associado a ator e aplicado ao frame nativo da entidade durante o render.

## Compatibilidade honesta
- A fila de script ainda nao foi unificada fisicamente com a fila de backgrounds/atores/HUD; Z cruzado entre esses dois dominios continua parcial.
- Queue locking/`newonly` historico e propriedades avancadas de drawmethod (clip/channel/center/repeat/water) permanecem como trabalho de paridade, em vez de serem declarados completos.

## Testes
- CMake Release: PASS.
- Regression/ctest: 1/1 PASS.
- 10/10 suites de runtime: PASS.
- `runtime_commands` valida snapshot de drawmethod, escala fixa 256, `sortid`, override por entidade, `drawspriteq` em subscreen/vscreen e `clearspriteq`.

---

# Changelog — v0.34.30

## ScriptVM / native subscreens
- `allocscreen` deixa de retornar apenas um handle ficticio e passa a criar uma superficie BGRA independente com dimensoes reais e limites de seguranca.
- `clearscreen` limpa somente o subscreen selecionado; a fila principal de desenho deixa de ser apagada por engano.
- `drawboxtoscreen`, `drawlinetoscreen` e `drawdottoscreen` rasterizam diretamente no buffer off-screen, com blend opcional.
- `drawspritetoscreen` compoe o sprite no subscreen indicado em vez de vazar o desenho para o frame principal.
- `drawstringtoscreen` preserva texto associado ao subscreen e `drawscreen` apresenta a superficie com X/Y/Z/blend.
- `getgfxproperty` cobre width/height de sprites e subscreens; `free` libera ambos os tipos de handle.
- CompatibilityAnalyzer passa a reconhecer `drawlinetoscreen`/`drawdottoscreen` e identifica a cobertura como ScriptVM v0.34.30.

## Testes
- `runtime_commands` ganhou regressao para alocacao, raster off-screen, sprite, texto, drawscreen, clear e free.
- Fixture do analisador agora exercita a familia de subscreen APIs para impedir falso PARTIAL futuro.

---

# Changelog — v0.34.29

## Level-set lifecycle / ifcomplete
- `ifcomplete N` de `levels.txt` passa a fazer parte dos metadados gerados e do seletor nativo de campanhas.
- Contagem de conclusoes persistida em `saves/unlocks.ini`; level sets bloqueados exibem o requisito e recusam inicio antes do desbloqueio.
- `end`/`endlevel` em `levels.txt` marca o stage anterior como terminal da rota sequencial.
- Fases posteriores ao `end` continuam geradas e podem ser alcancadas por `branch`/`jumptobranch`.
- A progressao default agora respeita `setOrder`, impedindo cair automaticamente no set seguinte.
- `next` explicito ausente nao e tratado como conclusao valida e nao incrementa desbloqueios.

## Reconciliacao sem regressao
- Reintegrado o `TYPE_ENDLEVEL` da v0.34.26 entregue: `branch` em modelo, resolver case-insensitive, contato de jogador e `subtype both` para todos os jogadores ativos.
- A suite `runtime_endlevel` volta a fazer parte da validacao cumulativa, preservando simultaneamente file streams, StageInstruction/scroll e `nojoin/canjoin` das linhas posteriores.

## Testes
- CMake Release: PASS.
- Regression/ctest: 1/1 PASS.
- 10/10 suites de runtime: PASS.

---

# Changelog — v0.34.28

## StageInstruction / join gating
- O parser deixa de manter apenas um controle pendente por `at`: um mesmo ponto de fase pode carregar spawn, `wait`, `group`, `blockade` e `nojoin/canjoin` sem perder eventos.
- `at` passa a ser distribuido para todos os controles pendentes do mesmo bloco, preservando a ordem declarada e o `at` do spawn.
- `nojoin` e `canjoin` agora possuem estado executavel no runtime; `nojoin 1` e interpretado como booleano e pode ser aplicado imediatamente ou no `at` associado.
- `openborvariant("nojoin")`, `changeopenborvariant()` e `setopenborvariant()` compartilham o mesmo estado de join da fase.
- Entrada tardia nativa por gamepad foi adicionada para slots cooperativos contiguos e respeita o gate `nojoin/canjoin`.
- O novo jogador recebe spawn, contexto de script, palette/mapa, arma de fase e callbacks `joinN.c`/`joinall.c` quando disponiveis.
- O CompatibilityAnalyzer mantem `nojoin/canjoin` como PARTIAL por ocorrencia enquanto o frontend legado completo de selecao no momento do join ainda nao e reproduzido.

## Testes
- Regression/ctest cobre `spawn + nojoin + wait + group + blockade + at` no mesmo bloco e `canjoin` posterior.
- `runtime_compatibility` cobre gate fechado/aberto, entrada tardia de P2 e round-trip da variante `nojoin`.
- 1/1 teste CTest e 9/9 suites de runtime: PASS.

---

# Changelog — v0.34.27

## Stage scroll / StageInstruction fidelity
- `at` agora usa a posicao de scroll da fase, em vez da borda direita do viewport. Isso elimina disparos ate uma tela antes do ponto autorado.
- Em fases `direction left`, o progresso de `at` e convertido a partir da borda direita da fase, conforme a semantica original.
- O comprimento minimo da fase agora inclui todos os `at` de spawns e eventos, garantindo que gatilhos tardios sejam alcancaveis mesmo sem paineis/background largos.
- `coords X` de spawns passa a ser aplicado relativo a tela no instante real do spawn. Isso corrige entidades atrasadas por `group`, que antes usavam `at + coords` e podiam nascer fora da tela.
- `group min/max` usa a mesma normalizacao em todos os caminhos do runtime e continua persistente ate nova declaracao.
- A logica de alcance foi centralizada em `stageScrollPosition()`, `reachedStagePosition()` e `stageSpawnWorldX()`, removendo tres implementacoes divergentes.

## Testes
- Regression/ctest: 1/1 PASS.
- 9 suites de runtime: PASS.
- `runtime_compatibility` cobre trigger exato de `at`, alcance minimo de fase, spawn atrasado por `group` e coordenadas de `direction left`.

---

# Changelog — v0.34.26

## ScriptVM / file streams
- `ScriptFileStream` passa a preservar o buffer bruto e a posicao em bytes, aproximando a semantica do OpenBOR original.
- Implementados `getfilestreamline`, `getfilestreamposition`, `setfilestreamposition`, `filestreamappend`, `createfilestream` e `savefilestream`.
- `openfilestream(path, 1)` le da pasta portatil `saves`.
- `savefilestream` cria subpastas quando necessario e bloqueia caminhos absolutos ou com `..`.
- `getfilestreamargument` continua convertendo string/int/float e agora opera sobre a linha correspondente a posicao real do stream.
- CompatibilityAnalyzer atualizado para reconhecer as novas APIs sem falso PARTIAL.
- Parity Audit corrigido de `0.34.14` para `0.34.26`.

## Testes
- ctest/regression: 1/1 PASS.
- 9 suites de runtime: PASS.
- Novo runtime test cobre open/read line/read argument/next/seek/create/append/save/reopen/close.

---

# Changelog — v0.34.25

## Legacy water / stage motion
- `water` deixa de deslocar a imagem inteira e passa a usar deformacao horizontal por scanline em `rock 0`.
- `rock 1` usa perspectiva/parallax por linha, ampliando a superficie na direcao da area jogavel.
- `warp` e validado no intervalo legado 0-15 e controla a velocidade da animacao.
- `rock 0..3` passa a SUPPORTED por ocorrencia; modos 2/3 mantem o double-shake e rumble de cenario.
- O water overlay passa a ser ancorado diretamente no `BGHeight` da fase.

## Script include recovery
- Includes sao resolvidos case-insensitive.
- Se o caminho antigo nao existe, o Builder procura um unico arquivo com o mesmo basename dentro do data root.
- Includes ausentes redundantes deixam de gerar PARTIAL so por existirem.
- Se ainda houver chamada de funcao desconhecida, o relatorio mantem `api/function:<nome>` + `include-missing:<path>` de forma explicita.
- O ScriptVM aplica a mesma busca por basename unico em runtime antes de ignorar um include legado ausente.
- `spawn.h` continua usando os helpers nativos `spawn01`, `spawn01map` e `spawn000`.

## Validacao
- ctest/regression: 1/1 PASS.
- runtime_effects, contacts, grabs, bindings, unicode, terrain, energy, commands, compatibility: PASS.
- GoW: 2.783 SUPPORTED / 0 PARTIAL / 1 UNKNOWN; build + smoke 300 frames PASS.
- Evil Dead: 14.290 SUPPORTED / 0 PARTIAL / 0 UNKNOWN; build + smoke 300 frames PASS.
