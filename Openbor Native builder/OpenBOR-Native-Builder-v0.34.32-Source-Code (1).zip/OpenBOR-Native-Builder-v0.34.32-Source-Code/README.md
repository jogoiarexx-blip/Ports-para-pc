# OpenBOR Native Builder v0.34.32

Versao focada no gargalo estrutural de **renderizacao compartilhada**: Direct Drawing do ScriptVM deixa de ser um overlay separado e passa a participar da mesma ordenacao Z/`sortid` da cena nativa.

## Melhorias principais

- Painel normal entra na fila em `PLAYER_MIN_Z-50`, seguindo `PANEL_Z` do OpenBOR.
- Sombras entram em `PLAYER_MIN_Z-47` (`SHADOW_Z`).
- `fglayer` usa seu Z autorado na mesma fila de atores e scripts.
- Atores e projeteis compartilham a ordenacao por Z, `sortid` e sequencia estavel com `drawsprite`, `drawscreen`, `drawbox`, `drawline`, `drawdot` e `drawstring`.
- `frontpanel` entra em `PLAYER_MAX_Z+50`, acima da acao e abaixo do HUD.
- HUD entra em `FRONTPANEL_Z+10000`, permitindo que scripts com Z apropriado sejam ordenados antes/depois da interface como no modelo de sprite queue do OpenBOR.
- `drawspriteq()` continua preservando replay e faixa de Z; os comandos descarregados tambem entram na fila compartilhada.
- `frontpanel` passa a usar o scroll ratio legado 1.5 em vez do default de background.
- Um trace compacto da fila final foi adicionado ao runtime para regressao e diagnostico de paridade.

## Validacao real

- Build CMake Release: PASS.
- Regression/ctest: **1/1 PASS**.
- Runtime gerado: **10/10 suites PASS** — effects, contacts, grabs, bindings, unicode, terrain, energy, commands, compatibility e endlevel.
- `runtime_commands` valida interleaving de script abaixo/acima do jogador, empate de Z resolvido por `sortid`, PANEL_Z, SHADOW_Z, fglayer, FRONTPANEL_Z e HUD_Z.

## Limites conhecidos

- Background/bglayer continuam como backdrops reais abaixo da sprite queue, como no OpenBOR; water/neon/repeat e alguns detalhes historicos de camadas ainda nao possuem paridade exata.
- Queue locking/`newonly` historico ainda nao esta completo.
- Propriedades avancadas de drawmethod como clip rectangle, canais RGB, center/pivot, repeat/span e water continuam parciais.
- Exact indexed-palette LUT/remap e alguns efeitos historicos de shadow/lighting continuam parciais.
- Nao foi produzido um novo EXE Windows x64 neste ambiente; o fonte foi compilado e testado com GCC/CMake. Um Portable Windows deve ser reconstruido com toolchain Windows/MinGW/MSVC, sem renomear binario antigo.
