#pragma once
#include <filesystem>
#include <string>
#include <vector>

enum class SpawnState { NotTriggered, Active, Completed };

struct SpawnDef {
    int id = 0;
    std::string model;
    std::string alias;
    std::string item;
    std::string map;
    std::string spawnScript;
    int x = 0;
    int z = 200;
    int a = 0;
    int y = 0;
    int at = 0;
    int health = -1;
    int score = 0;
    int spawnType = 0; // 0 enemy, 1 item, 2 weapon, 3 npc/object, 4 boss
    bool boss = false;
    bool flip = false;
    bool hasAt = false;
    SpawnState state = SpawnState::NotTriggered;
};

struct GeometryDef {
    std::string kind;
    int x = 0;
    int z = 0;
    int w = 0;
    int h = 0;
    int depth = 0;
    int altitude = 0;
    bool openborShape=false;
    float shape[9]{}; // x,z,upperleft,lowerleft,upperright,lowerright,depth,height,type
};

struct LayerDef {
    std::string kind; // background, bglayer, panel, frontpanel, fglayer
    std::string path;
    float xRatio = 0.5f;
    float zRatio = 0.5f;
    int xOffset = 0;
    int zOffset = 0;
    int xSpacing = 0;
    int zSpacing = 0;
    int xRepeat = 0;
    int zRepeat = 0;
    int zOrder = 0; // fglayer depth parameter
    int transparency = 0;
    int alpha = 0;
    int waterMode = 0;
    int amplitude = 0;
    int wavelength = 0;
    float waveSpeed = 0.0f;
    float bgSpeedRatio = 0.0f;
};

struct StageInstructionDef { int sequence=0; int kind=0; int refId=0; }; // kind: 0 spawn, 1 event
struct CutsceneAnimationDef {
    std::string path;
    int x = 0;
    int y = 0;
    // OpenBOR scene syntax: skipone=0 means skip closes the current scene file;
    // skipone=1 skips only this animation. noskip=1 disables skip input.
    int skip = 0;
    int noSkip = 0;
    int durationTicks = 0;
    int sceneIndex = 0;
    std::string musicBefore;
    bool musicLoop = false;
    bool silenceBefore = false;
};

struct StageEventDef {
    int id = 0;
    std::string kind; // wait, group, blockade, camera, scrollx, scrolly, nojoin
    int at = 0;
    int value = 0;
    int group = 0;
    std::string text;
    bool hasAt = false;
    SpawnState state = SpawnState::NotTriggered;
};

struct StageDef {
    std::string sourceFile;
    std::string setName;
    std::string direction = "right"; // right, left, up, down, both, in, out
    std::string type;                // 1, 2, 0...
    std::string background;
    std::string music;
    std::string bossMusic;
    int bossMusicOffset = 0;
    std::string waterPath;
    int waterWarp = 0;
    int rockMode = 0;
    std::string preSceneFile;
    std::vector<std::string> preSceneFiles;
    std::string sceneMusic;
    bool sceneMusicLoop = false;
    std::vector<CutsceneAnimationDef> sceneAnimations;
    std::vector<std::string> postSceneFiles;
    std::string postSceneMusic;
    bool postSceneMusicLoop = false;
    std::vector<CutsceneAnimationDef> postSceneAnimations;
    int chapter = 0;
    std::vector<std::string> panels;
    std::string panelOrder;
    bool panelOrderValid = true;
    std::vector<LayerDef> layers;
    bool musicLoop = true;
    int order = 0;
    int setOrder = 0;
    int lives = 0;
    int credits = 0;
    int canSave = 0;
    int skipSelect = 0;
    int completeBg = 0;
    int noShare = 0;
    int ifComplete = 0;
    bool campaignEnd = false;
    int zMin = 160;
    int zMax = 232;
    int backgroundHeight = 160;
    int playerStartX = 80;
    int playerStartZ = 200;
    int playerStartA = 0;
    bool player1SpawnDefined = false;
    int player2StartX = 98, player2StartZ = 207, player2StartA = 0;
    int player3StartX = 116, player3StartZ = 214, player3StartA = 0;
    int player4StartX = 134, player4StartZ = 221, player4StartA = 0;
    bool player2SpawnDefined = false, player3SpawnDefined = false, player4SpawnDefined = false;
    int setWeapon = 0;
    int cameraOffsetX = 0, cameraOffsetY = 0;
    int stageLightX = 0, stageLightY = 0;
    int shadowColor = -1, shadowAlpha = 0;
    bool noSlow = false, noTime = false;
    int setTime = 0;
    int cameraType = 0; // 0 follow, 1 fixed
    int scrollSpeed = 0;
    std::vector<SpawnDef> spawns;
    std::vector<GeometryDef> geometry;
    std::vector<StageEventDef> events;
    std::vector<StageInstructionDef> instructions; // original cross-type declaration order
    std::string branchName; // levels.txt branch destination label for this stage
    std::string nextStage;
    std::string branchStage; // legacy/stage-local branch metadata
    std::string levelScript;
    bool endLevel = false;
};

struct LevelSetDef {
    std::string name;
    int order = 0;
    int lives = 0;
    int credits = 0;
    int canSave = 0;
    int skipSelect = 0;
    int completeBg = 0;
    int noShare = 0;
    int ifComplete = 0;
    int zMin = 160;
    int zMax = 232;
    int backgroundHeight = 160;
    std::vector<std::string> levelFiles;
    // Scenes before the first file remain pre-stage scenes for compatibility.
    // Scenes encountered after a file are attached to that stage as post-stage scenes,
    // matching OpenBOR Build 3797 campaign sequencing.
    std::vector<std::string> levelScenes;
    std::vector<std::vector<std::string>> levelPreScenes;
    std::vector<std::vector<std::string>> levelPostScenes;
    std::vector<int> levelChapters;
    // Metadata captured at each `file` entry in levels.txt. OpenBOR permits branch/z
    // directives to change between files inside the same set.
    std::vector<std::string> levelBranches;
    std::vector<int> levelZMin;
    std::vector<int> levelZMax;
    std::vector<int> levelBackgroundHeight;
    std::vector<bool> levelEnds;
};

struct VideoProfile {
    bool found = false;
    int videoMode = 0;
    int hResolution = 320;
    int vResolution = 240;
    std::string source;
};

class LevelParser {
public:
    static std::vector<LevelSetDef> parseLevelSets(const std::filesystem::path& levelsTxt);
    static StageDef parseStage(const std::filesystem::path& stageFile,
                               const std::filesystem::path& root,
                               const LevelSetDef& levelSet);
    static std::vector<StageDef> parseAll(const std::filesystem::path& dataDir,
                                          const std::filesystem::path& root);
    static VideoProfile parseVideo(const std::filesystem::path& dataDir);
};
