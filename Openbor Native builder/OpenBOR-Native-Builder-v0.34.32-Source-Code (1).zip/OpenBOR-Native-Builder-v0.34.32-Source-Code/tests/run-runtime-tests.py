#!/usr/bin/env python3
"""Generate fresh fixture ports and execute their native runtime tests on Linux.

Usage: python3 tests/run-runtime-tests.py /path/to/openbor-native-builder output
Requires a C++20 compiler. The Windows renderer is separately cross-compiled.
"""
import argparse
import concurrent.futures
import os
from pathlib import Path
import subprocess


def run(args, log):
    with log.open("w") as out:
        result = subprocess.run([str(x) for x in args], stdout=out, stderr=subprocess.STDOUT)
    if result.returncode:
        raise RuntimeError(f"Failed ({result.returncode}): {log}\n{log.read_text()[-4000:]}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("builder", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    builder = args.builder.resolve()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    tests = Path(__file__).resolve().parent
    suites = {
        "runtime_effects": ["runtime_effects", "runtime_contacts", "runtime_grabs", "runtime_bindings", "runtime_unicode"],
        "runtime_terrain": ["runtime_terrain"],
        "runtime_energy": ["runtime_energy"],
        "runtime_commands": ["runtime_commands"],
        "runtime_blocks": ["runtime_compatibility"],
        "runtime_endlevel": ["runtime_endlevel"],
    }
    for fixture in suites:
        run([builder, "convert", tests / "fixtures" / fixture, output / fixture], output / f"{fixture}-generate.log")
    compiler = os.environ.get("CXX", "g++")
    common = output / "runtime_effects" / "runtime"
    object_dir = output / "objects"
    object_dir.mkdir(exist_ok=True)
    sources = [p for p in (common / "src").glob("*.cpp") if p.name != "main.cpp"]
    def compile_common(source):
        obj = object_dir / (source.stem + ".o")
        run([compiler, "-std=c++20", "-O1", "-I", common / "include", "-c", source, "-o", obj], output / f"compile-{source.stem}.log")
        return obj
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        objects = list(pool.map(compile_common, sources))
    jobs = [(fixture, test) for fixture, names in suites.items() for test in names]
    def compile_test(job):
        fixture, name = job
        runtime = output / fixture / "runtime"
        exe = output / (name + "-test")
        run([compiler, "-std=c++20", "-O1", "-I", runtime / "include", tests / (name + ".cpp"),
             runtime / "generated/GeneratedCharacters.cpp", runtime / "generated/GeneratedStages.cpp",
             *objects, "-pthread", "-o", exe], output / (name + "-build.log"))
        return fixture, name, exe
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        executables = list(pool.map(compile_test, jobs))
    for fixture, name, exe in executables:
        run([exe, output / fixture], output / (name + ".log"))
        print(f"PASS {name}", flush=True)
    print("ALL RUNTIME TESTS PASS", flush=True)


if __name__ == "__main__":
    main()
