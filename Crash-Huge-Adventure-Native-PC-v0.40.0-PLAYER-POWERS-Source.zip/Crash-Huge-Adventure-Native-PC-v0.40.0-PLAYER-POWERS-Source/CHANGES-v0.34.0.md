# v0.34.0 — Generic Enemy Controller Coverage

## Gargalo medido

Depois da v0.33, 23/24 salas tile já entravam no runtime nativo, mas isso mascarava um gargalo maior: **225 inimigos/hazards normais e 7 spawners de focas eram carregados da ROM e ignorados pelo loop de gameplay**. Em várias fases Sewer/Space/Ice isso equivalia a 100% dos inimigos ausentes.

## Correção estrutural

- Novo dispatcher genérico de inimigos no `EntityWorld`, baseado no `EnemyCtrl` compartilhado do original.
- Os actors passam a usar seus **sprite banks reais da ROM**, flags de direção, ranges e timings dos parameter records.
- Cobertura adicionada para:
  - `0x29` Vulture — bank 11, trigger/dive;
  - `0x2B` jungle patrol — bank 14;
  - `0x2C` Blowgun Tribesman — bank 12, ciclo/shooter state;
  - `0x2D` Penguin — bank 15, patrol + attack state;
  - `0x2E` Seal Spawner — período original `0x78` e seal bank 17;
  - `0x2F` Polar Bear — bank 16;
  - `0x37` Laser Barrier — bank 25;
  - `0x38` stationary space enemy — bank 27;
  - `0x39` patrolling space enemy — bank 24;
  - `0x3A/0x3F` Saucer Lab Assistant — bank 29 e offset vertical original de 40 px;
  - `0x3B` Piston Crusher — bank 26;
  - `0x40` Flamethrower Lab Assistant — bank 23;
  - `0x41` homing sewer enemy — bank 22;
  - `0x42` patrolling sewer enemy — bank 20;
  - `0x43` Rat — bank 21;
  - `0x44` Frog — bank 19;
  - `0x4D` Wooden Crusher — bank 18.
- Laser/Piston/Wooden Crusher são tratados como hazards invulneráveis ao spin; inimigos normais entram no contador de kills.
- Spawners de foca agora criam actors temporários separados do vetor de entidades da sala, preservados em snapshot/checkpoint.
- Renderer e hitboxes passam a escolher dinamicamente o bank/animação da nova família.
- Novo `CrashEnemyCoverageTool` mede todas as salas tile e falha se algum tipo da família normal voltar a cair fora do dispatcher.

## Cobertura

Scanner da v0.34:

- 24 salas tile verificadas;
- 406 entidades da família normal encontradas;
- 31 já cobertas pelo runtime antigo (Lizard/Venus);
- 143 aquáticas da v0.33;
- 225 cobertas pelo novo controlador genérico;
- 7 Seal Spawners;
- **0 entidades dessa família ignoradas**.

## Limite honesto desta etapa

A camada estrutural, movimento, hitboxes, hazards, patrol/homing/attack cycles e spawners estão ativos. Alguns ataques especiais que no GBA criam child effects/projectiles ainda usam comportamento simplificado; eles ficam como próxima etapa de fidelidade, em vez de serem apresentados como byte-exatos.

## Validação

- `make -B -j8 all` PASS com C++17 + `-Wall -Wextra -Wpedantic -Werror`.
- 8/8 suítes PASS.
- `CrashEnemyCoverageTool`: 406 tratadas / 0 ignoradas.
- ASan + UBSan PASS em `TestEntities` e `TestRunState`.
- Diagnóstico visual: `reports/v034-generic-enemy-preview.png`.
