#!/usr/bin/env python3
"""Cross-check the independently written native renderer against the Python decoder."""
import csv,json,subprocess,tempfile
from pathlib import Path
from PIL import Image
import extract_scene as e
ROOT=e.ROOT
exe=str(ROOT/'CrashSceneTool');rom=str(ROOT/'input/crash.gba')
result=subprocess.run([exe,'digests',rom],check=True,capture_output=True,text=True)
count=0
for row in csv.reader(result.stdout.splitlines()):
 bank,index,palette,w,h,x,y,digest=map(int,row);bk=e.bank(bank);img,origin=e.frame(bk['frames'][index],e.pal(e.u(e.CONFIG['table']+8)+32*palette))
 assert img.size==(w,h) and origin==(x,y),(bank,index,'extent')
 hash=2166136261
 for r,g,b,a in img.getdata():
  for c in (b,g,r,a):hash=((hash^c)*16777619)&0xffffffff
 assert hash==digest,(bank,index,'pixels',hash,digest)
 count+=1
room=e.room(0);colors=e.pal(room['palette'],256)
with tempfile.TemporaryDirectory() as directory:
 temp=Path(directory)
 for l in room['layers']:
  path=temp/'map.bin';subprocess.run([exe,'map',rom,str(l['slot']),str(path)],check=True)
  assert path.read_bytes()==(ROOT/'assets/scene'/f"level00-layer{l['slot']}.map.bin").read_bytes(),l['slot']
 for cx,cy in [(0,240),(700,200),(2048,250),(3500,320)]:
  path=temp/'scene.bmp';subprocess.run([exe,'scene',rom,str(cx),str(cy),str(path)],check=True)
  actual=Image.open(path).convert('RGB');expected=Image.new('RGBA',(240,160),(*colors[0],255))
  for l in sorted([l for l in room['layers'] if l['slot']<4],key=lambda l:(-l['priority'],-(l['slot']+1 if l['slot']<3 else 0))):
   im=Image.open(ROOT/'assets/scene'/f"level00-layer{l['slot']}.png");ox=cx*l['scale_x']//256;oy=cy*l['scale_y']//256;expected.alpha_composite(im.crop((ox,oy,ox+240,oy+160)))
  assert actual.tobytes()==expected.convert('RGB').tobytes(),(cx,cy,'viewport')
report={'sprite_render_crosschecks':count,'layer_maps_crosschecked':5,'viewports_crosschecked':4,'result':'passed','crosscheck':'C++/Python frame pixels, origin, dimensions; map bytes; composed scene pixels'}
(ROOT/'reports/scene-validation.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
