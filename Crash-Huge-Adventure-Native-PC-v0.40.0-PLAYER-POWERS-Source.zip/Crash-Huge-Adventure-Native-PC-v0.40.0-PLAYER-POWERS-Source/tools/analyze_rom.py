#!/usr/bin/env python3
"""Evidence-based ROM inventory. Candidates are NOT identified game assets."""
import argparse, collections, hashlib, json, struct
from pathlib import Path

BASE=0x08000000

def lz10(data, offset, limit=262144):
    if offset+4>len(data) or data[offset]!=0x10: raise ValueError('header')
    size=int.from_bytes(data[offset+1:offset+4],'little')
    if not 32<=size<=limit: raise ValueError('size')
    p=offset+4; out=bytearray()
    def take():
        nonlocal p
        if p>=len(data): raise ValueError('truncated')
        v=data[p];p+=1;return v
    while len(out)<size:
        flags=take()
        for bit in range(7,-1,-1):
            if len(out)>=size: break
            if flags & (1<<bit):
                a,b=take(),take(); count=(a>>4)+3; distance=((a&15)<<8)+b+1
                if distance>len(out): raise ValueError('invalid backreference')
                for _ in range(min(count,size-len(out))):out.append(out[-distance])
            else:out.append(take())
    return bytes(out),p-offset

def code_map(rom, destination):
    try:
        from capstone import Cs,CS_ARCH_ARM,CS_MODE_THUMB,CS_MODE_ARM
        from capstone.arm import ARM_OP_IMM,ARM_OP_REG,ARM_OP_MEM,ARM_REG_PC
    except ImportError:
        return {'available':False,'reason':'Install requirements-analysis.txt for code map'}
    md=Cs(CS_ARCH_ARM,CS_MODE_THUMB);md.detail=True
    # Proven THUMB startup target: literal loaded by ARM BX r1 at 08000118.
    literal=struct.unpack_from('<I',rom,0x13c)[0]
    if literal!=0x08000171: raise ValueError('unexpected startup target')
    queue=[literal&~1];visited=set(); rows=[];calls=set();literals=set(); indirect=[]
    while queue and len(visited)<100000:
        pc=queue.pop()
        while BASE<=pc<BASE+len(rom) and pc not in visited:
            ins=next(md.disasm(rom[pc-BASE:pc-BASE+4],pc,count=1),None)
            if ins is None:break
            visited.add(pc);rows.append((pc,ins.mnemonic,ins.op_str))
            ops=ins.operands;mn=ins.mnemonic
            for op in ops:
                if op.type==ARM_OP_MEM and op.mem.base==ARM_REG_PC:
                    lp=((pc+4)&~3)+op.mem.disp
                    if BASE<=lp<=BASE+len(rom)-4:literals.add(lp)
            if mn in ('bl','blx') and ops and ops[0].type==ARM_OP_IMM:
                target=ops[0].imm;calls.add((pc,target));queue.append(target&~1)
            elif mn.startswith('b') and mn not in ('bic','bics','bx','bl','blx') and ops and ops[0].type==ARM_OP_IMM:
                queue.append(ops[0].imm)
                if mn=='b':break
            if mn in ('bx','blx') and ops and ops[0].type==ARM_OP_REG:
                indirect.append({'address':f'{pc:08X}','instruction':mn+' '+ins.op_str});break
            if mn=='pop' and any(op.type==ARM_OP_REG and op.reg==ARM_REG_PC for op in ops):break
            if mn=='mov' and ops and ops[0].type==ARM_OP_REG and ops[0].reg==ARM_REG_PC:break
            pc+=ins.size
    with (destination/'reachable-thumb.txt').open('w') as f:
        f.write('; Static direct-flow traversal from verified startup. Indirect targets unresolved.\n')
        for pc,mn,op in sorted(rows):f.write(f'{pc:08X}  {mn:8} {op}\n')
    with (destination/'calls.csv').open('w') as f:
        f.write('callsite,target\n')
        for src,tgt in sorted(calls):f.write(f'0x{src:08X},0x{tgt:08X}\n')
    arm=Cs(CS_ARCH_ARM,CS_MODE_ARM)
    (destination/'boot-arm.txt').write_text('\n'.join(f'{i.address:08X}  {i.mnemonic:8} {i.op_str}' for i in arm.disasm(rom[0xc0:0x120],BASE+0xc0))+'\n')
    (destination/'indirect-flow.json').write_text(json.dumps(indirect,indent=2))
    return {'available':True,'entry':f'{literal:08X}','instructions':len(visited),'direct_calls':len(calls),'literal_pool_words':len(literals),'unresolved_indirect_sites':len(indirect),'complete':False,'limitations':'Indirect calls, jump tables, copied RAM code and interrupt flow are unresolved; traversal is not a decompilation.'}

def analyze(path,root):
    rom=path.read_bytes()
    if len(rom)!=8388608 or rom[0xac:0xb0]!=b'ACQE':raise ValueError('Expected supplied ACQE 8 MiB ROM')
    assets=root/'assets';reports=root/'reports';assets.mkdir(parents=True,exist_ok=True);reports.mkdir(parents=True,exist_ok=True)
    pointers=collections.defaultdict(list)
    for i in range(0,len(rom)-3,4):
        v=struct.unpack_from('<I',rom,i)[0]
        if BASE<=v<BASE+len(rom):pointers[v-BASE].append(i)
    blocks=[];end=0
    for offset in range(0,len(rom)-4,4):
        if offset<end or rom[offset]!=0x10:continue
        try:raw,used=lz10(rom,offset)
        except ValueError:continue
        # Reject pathological accidental headers; references are still only byte-pattern candidates.
        if used<8 or len(raw)/used>128:continue
        name=f'lz_{offset:06X}.bin';(assets/name).write_bytes(raw)
        blocks.append({'offset':offset,'address':f'{BASE+offset:08X}','decoded_bytes':len(raw),'consumed_bytes':used,'file':name,'pointer_pattern_locations':[f'{BASE+p:08X}' for p in pointers.get(offset,[])],'classification':'valid_lz10_candidate_unidentified','sha256':hashlib.sha256(raw).hexdigest()});end=offset+used
    report={'rom':{'title':rom[0xa0:0xac].rstrip(b'\0').decode(),'game_code':rom[0xac:0xb0].decode(),'bytes':len(rom),'sha256':hashlib.sha256(rom).hexdigest(),'header_checksum_stored':rom[0xbd],'header_checksum_calculated':(-sum(rom[0xa0:0xbd])-0x19)&255,'save_signature':next((rom[p:p+16].split(b'\0')[0].decode('ascii','replace') for p in [rom.find(b'EEPROM_V')] if p>=0),None)},'compressed_candidates':blocks,'code_map':code_map(rom,reports),'notes':['Aligned LZ10 scan only; other compression and unaligned blocks are not covered.','Pointers are aligned byte patterns, not verified runtime references.','No sprite, palette, level or gameplay identity has yet been established.']}
    (reports/'rom-analysis.json').write_text(json.dumps(report,indent=2))
    (assets/'index.txt').write_text('\n'.join(f"{b['file']} {b['offset']} {b['decoded_bytes']}" for b in blocks)+'\n')
    print(json.dumps({'rom':report['rom'],'blocks':len(blocks),'decoded_bytes':sum(b['decoded_bytes'] for b in blocks),'code_map':report['code_map']},indent=2))
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('rom',type=Path);ap.add_argument('--output',type=Path,default=Path(__file__).resolve().parents[1]);args=ap.parse_args();analyze(args.rom,args.output)
