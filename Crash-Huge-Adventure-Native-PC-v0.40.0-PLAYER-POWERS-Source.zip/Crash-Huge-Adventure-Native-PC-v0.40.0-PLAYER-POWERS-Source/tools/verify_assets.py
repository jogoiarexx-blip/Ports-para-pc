#!/usr/bin/env python3
import json, subprocess, tempfile
from pathlib import Path
root=Path(__file__).resolve().parents[1]
report=json.loads((root/'reports/rom-analysis.json').read_text())
with tempfile.TemporaryDirectory() as tmp:
 for block in report['compressed_candidates']:
  out=Path(tmp)/'decoded.bin'
  subprocess.run([str(root/'CrashRomTool'),'lz',str(root/'input/crash.gba'),str(block['offset']),str(out)],check=True,stdout=subprocess.DEVNULL)
  assert out.read_bytes()==(root/'assets'/block['file']).read_bytes(),block['file']
print(f"PASS: C++ output equals Python output for all {len(report['compressed_candidates'])} ROM candidates")
