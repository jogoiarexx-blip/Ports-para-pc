# v0.20.0 — GAX2 ROM Sequencer / Original PCM / Warp Room Pass

## Áudio — maior evolução desta versão

- Novo `src/gax_rom.hpp`: parser/replayer GAX2 nativo específico para a ROM ACQE, sem executar código ARM do GBA.
- Descoberta e validação estrutural da tabela lógica de 19 músicas da ROM (`0x16A560` na revisão testada), em vez de depender só das strings de metadata.
- Parser de `GAX2_Song`, handlers de canais, `GaxSongData`, order lists, patterns compactados, tabela de instrumentos e tabela de waves.
- Banco musical validado: 52 instrumentos e 29 waves PCM não vazias (+ slot 0 vazio).
- Sequenciador nativo reproduz notas/ordens/loops usando as amostras PCM signed 8-bit da própria ROM.
- Suporte inicial aos comandos GAX de speed, volume e pattern break, com transpose de order e loop de samples.
- O backend Win32 `waveOut` usa o novo player da ROM quando a estrutura GAX valida e mantém o sintetizador v0.19 como fallback seguro.
- SFX: descoberta da tabela original de 99 rotas e do banco GAX SFX (88 instrumentos / 87 waves úteis na revisão ACQE).
- Cues já ligados ao banco original quando o ID é conhecido: navegação, confirmar/cancelar, salto, spin, Wumpa, caixa, vida, relógio, tiro, explosão, enemy down, boss hit e level clear. Cues ainda não confirmadas continuam usando o fallback sintetizado.
- `CrashGaxTool` agora mostra endereços/estruturas reais, canais, rows, orders, sample rate, banco SFX e contagens.

### Limite conhecido do replayer

A v0.20 toca **sequências e PCM originais da ROM**, mas ainda não é um clone bit-exact do mixer GAX 2.01D. Envelopes completos, vibrato, portamento, instrument-sequence effects, sweep/ping-pong e prioridade/voice stealing ainda precisam de uma etapa adicional.

## Warp Room / frontend

- Quatro Warp Rooms agora mostram cinco portais de fase + um portal de boss central por andar.
- Perspectiva do piso, moldura de pedra, portal de boss dedicado e secret portal refeitos.
- Estados LIBERADA/BLOQUEADA/CONCLUÍDA e save/progressão foram preservados.

## Callbacks / IA

- `JetAiProfile` deixou de ser apenas classificação auxiliar e agora é o dispatcher efetivo de atualização da IA.
- Tracker, depth runner, balloon orbit, parachute, rocket, cannon plane, airship e ring seguem caminhos explícitos.
- Paraquedas ganhou oscilação lateral durante a descida; regras anteriores de tracker, rocket, plane/cannon e airship foram preservadas pelos testes.

## Validação

- `make test`: 8/8 suítes PASS.
- Build estrito `-Wall -Wextra -Wpedantic -Werror`: PASS.
- ASan + UBSan: `TestAudio`, `TestFrontend`, `TestCategory`: PASS.
- `TestAudio`: tabela de 19 músicas, 29 waves PCM musicais, 99 rotas SFX e geração de PCM do sequenciador: PASS.
- ROM ACQE preservada, SHA-256 `6be639d1db218ca2bf2b1ff0ee0867334404cead5fb6684af4870d4644a15635`.
