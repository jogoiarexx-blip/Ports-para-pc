# v0.29.0 — Linked Balloon Pop + Parent Crate Fall

## Implementado

- balões filhos 40/41/42 dos crates Jetpack agora possuem 2 HP próprios;
- tiro do player prioriza colisão com o balão filho antes do crate pai;
- segundo tiro dispara a animação 1 de estouro do balão;
- estouro chama a transição equivalente a `BreakJetpackBalloonCrate`: state 1 e velocidade vertical zerada;
- crate em state 1 cai com aceleração `0x12` Q8/frame, limitada a `0x4C0`, e some após Y `0xE100`;
- crate já derrubado pelo balão não incrementa o contador de caixas quebradas novamente se for destruído durante a queda;
- crate em queda não recria nem libera um novo balão ao ser destruído;
- quebra normal do crate mantém o float-away do balão intacto implementado na v0.28;
- balão já liberado mantém 2 HP, continua shootable durante o float-away e usa a mesma animação 1 de pop ao morrer;
- renderer mostra o pop do child balloon separado do crate;
- testes cobrem 2-hit child HP, pop, callback do pai, aceleração inicial, balão liberado shootable e prevenção de contagem/liberação duplicadas.

## Base de fidelidade

O fluxo foi cruzado com `DamageJetpackBalloon`, `BreakJetpackBalloonCrate`, `JetpackBalloonCrateStateFall` e `UpdateJetpackBalloonCrate` do decomp público atual de Crash Bandicoot XS / The Huge Adventure.
