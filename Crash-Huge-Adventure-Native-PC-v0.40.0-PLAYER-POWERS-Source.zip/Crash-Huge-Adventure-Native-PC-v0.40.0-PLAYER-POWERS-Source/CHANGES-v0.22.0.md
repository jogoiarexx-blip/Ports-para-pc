# Crash Native v0.22.0 — Exact GAX Period + Original Menu/Pause

## Áudio

- O replayer GAX2 agora localiza e usa diretamente a tabela original de **3828 períodos** dentro da ROM ACQE (`0x5A4300`).
- A conversão de pitch deixou de depender da fórmula aproximada baseada em 8363 Hz; o valor original do GAX passa a determinar o avanço da wave PCM a 44,1 kHz.
- SFX passam a respeitar o volume original da tabela, limitado como `GAX_set_fx_volume` faz no motor.
- O seletor de fases agora usa os IDs originais confirmados:
  - mover cursor: `0x48`;
  - confirmar fase: `0x52`;
  - abertura do seletor: `0x51`;
  - sair/cancelar continua `0x49`.
- O tiro continua no fallback até o ID correto ser comprovado.

## Frontend

- Extração e composição do `gMenuSkyBg` original: palette 4bpp + tiles + tilemap.
- O Warp Room/level select agora reproduz a camada original **céu + plataforma**, em vez de usar apenas a plataforma sobre um gradiente criado pelo port.
- Extração e composição do `gPauseMenuBg` original em 8bpp.
- Pausar com `P` passa a mostrar a tela metálica original com o rosto do Crash e uma camada de controles do port.
- Todos esses assets continuam vindo da ROM fornecida pelo usuário; nenhum arquivo gráfico original é necessário fora dela.

## Qualidade do código

- Corrigidas construções antigas que causavam `-Wmisleading-indentation` em `rom.hpp`, `game_data.hpp` e `player.hpp`.
- O Makefile agora usa `-Werror` por padrão.
- A unidade Win32 passa `clang++ -fsyntax-only` com `-Wall -Wextra -Wpedantic -Werror` usando apenas stubs de declarações da API para a checagem neste ambiente.

## Validação

- 8/8 suítes PASS.
- Build de ferramentas/core com `-Werror` PASS.
- ASan + UBSan: Audio, Frontend e Category PASS.
- GAX: 19 músicas, 52 instrumentos musicais, 88 instrumentos SFX e tabela original de período encontrada.
- Frontend: menu sky, level-select e pause originais reconhecidos na ROM ACQE.

Ainda não é áudio GAX2 bit-exact completo: o DSP/echo/downmix/resampler do código ARM original continua sendo o principal alvo restante.
