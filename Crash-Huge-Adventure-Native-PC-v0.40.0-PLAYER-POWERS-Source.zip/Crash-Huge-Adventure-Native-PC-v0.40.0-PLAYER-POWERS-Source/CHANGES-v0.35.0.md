# v0.35.0 — Enemy Child Effects / Projectiles

## Gargalo atacado

Depois da v0.34, os inimigos normais finalmente participavam do runtime, mas dois ataques importantes ainda eram apenas animações no ator pai. O original cria objetos filhos reais via `LaunchEffectPart`: eles possuem sprite bank, animação, hitbox, velocidade, lifetime e colisão próprios.

## Correção estrutural

- Novo `EnemyChildEffect` no `EntityWorld`, separado de inimigos, caixas e efeitos cosméticos.
- Child effects possuem bank/animação, owner, posição, velocidade, flip, hitbox, lifetime e flag harmful independentes.
- Posicionamento reproduz a matemática de `LaunchEffectPart`: metade da largura do filho + metade da largura do pai + `margin`, respeitando flip, mais offset vertical `z`.
- Colisão com o Crash usa o hitbox da animação do próprio filho.
- Spin pode destruir o child effect antes do dano.
- Objetos não-looping encerram pelo tamanho real do clip; projéteis looping são removidos por alcance/tempo máximo.
- Retry/checkpoint limpa child effects transitórios em vez de ressuscitar um projétil que estava no ar no momento do snapshot.

## Blowgun Tribesman

O state 16 agora preserva o `controllerMode` e o caminho de `UpdateEnemyShooter`:

- child: sprite bank 12, animação/tag 6;
- trigger no frame 10 (ou frame 8 no caminho alternativo);
- velocidade original `0x400` Q8 = **4 px/frame**;
- offset vertical `-10` / `+8` conforme o modo;
- dardo tem hitbox próprio de 9×4 px e permanece ativo até impacto/saída de alcance.

## Flamethrower Lab Assistant

O kind `0x17` agora cria o filho confirmado por `UpdateEnemyAttackCycle`:

- child: sprite bank 23, animação/tag 4;
- trigger no frame 9 da animação de ataque;
- `margin = -0x2D`, `z = +2`, velocidade 0, como no `LaunchHarmfulEffectPart` original;
- clip não-looping de **24 ticks** e hitbox próprio de 12×4 px.

Na ROM USA usada pelo projeto isso afeta 8 Blowgun Tribesmen e 5 Flamethrower Lab Assistants em três fases tile.

## Máquina de animação

A família genérica passa a guardar `controllerMode/controllerTicks` e usa o `g*AnimMap` correspondente ao modo em vez de trocar animação por um limite artificial de 12 ticks. Isso prepara o runtime para os callbacks restantes do `EnemyCtrl` sem duplicar lógica por espécie.

## Ferramenta

Novo `CrashChildEffectTool ROM OUTPUT_BMP` gera um painel lado a lado de Blowgun + Flamethrower e confirma bank/animação/velocidade/lifetime.

## Validação

- 8/8 suítes PASS com C++17 + `-Wall -Wextra -Wpedantic -Werror`.
- Testes novos verificam spawn real dos dois child effects e dano do dardo no player.
- ASan + UBSan PASS em `TestEntities` e `TestRunState`.
- `CrashChildEffectTool`: Blowgun `bank=12 anim=6 speed=4`; Flamethrower `bank=23 anim=4 lifetime=24`.
- Preview: `reports/v035-enemy-child-effects.png`.
