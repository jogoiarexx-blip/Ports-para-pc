# Crash Native PC v0.32.0 — Gameplay stability: Venus, crate stacks, Win32 present

Esta rodada corrige três regressões visíveis da primeira fase sem refatorar os sistemas que já estavam estáveis.

## 1. Venus Flytrap agora pode morrer

- A entidade `0x2A` / bank 10 continua usando o comportamento próprio de planta: idle + ataque por trigger box.
- O runtime agora testa a hitbox de ataque do giro antes de iniciar/manter o ataque.
- Um spin válido remove a planta, cancela o ataque pendente e incrementa `enemyKills`.
- As 3 plantas da primeira sala passam a entrar no total de inimigos; o total nativo da sala passa de 5 para 8.
- O bank 10 tem somente os clips idle/attack usados pelo ator; por isso o port não inventa uma animação de morte de outra espécie.

## 2. Pilhas de caixas usam os links reais da sala

- `GameData::entityLinks()` lê `level_desc + 0x20`, o `level_link_list` original da sala.
- `EntityWorld` guarda `stackAbove`/`stackBelow` por id e valida os links somente quando ambos os lados são caixas válidas.
- A primeira fase contém 6 links reais de pilha e eles agora são carregados no runtime.
- As coordenadas X/Y originais da ROM são preservadas no carregamento/reset; o port não reposiciona a pilha artificialmente.
- Ao remover uma caixa ligada, o runtime mantém a cadeia de caixas superiores coerente em vez de deixar a relação perdida.

## 3. Ordem visual das caixas corrigida

No GBA, sprites OBJ com a mesma prioridade favorecem o menor índice OAM. O compositor software desenhava as caixas na ordem direta, fazendo a caixa criada depois sobrescrever a anterior. A passagem de caixas agora é composta em ordem reversa, preservando a prioridade visual do OAM para pilhas ligadas.

O teste de entidades procura um pixel de sobreposição real entre as duas caixas da pilha e confirma que o pixel da caixa superior é o que termina no framebuffer.

## 4. Flicker da janela Win32

- removido o clear direto do client DC antes de desenhar o frame;
- `WM_ERASEBKGND` retorna tratado, evitando apagamento automático entre frames;
- criado back buffer GDI persistente por tamanho da janela;
- background, frame escalado e textos são montados integralmente no back buffer;
- a janela recebe tudo em uma única operação `BitBlt`;
- back buffer é recriado somente quando o client size muda e liberado em `WM_DESTROY`.

Isso elimina a sequência anterior `FillRect(screen) -> StretchDIBits(screen)`, que podia expor um frame preto entre as duas operações.

## Validação

- build integral C++17: `-O2 -Wall -Wextra -Wpedantic -Werror` PASS;
- 8/8 suítes PASS;
- `TestEntities` com ASan + UBSan PASS;
- 6 links de pilha da primeira sala verificados;
- coordenadas de spawn das caixas continuam iguais às da ROM;
- teste de ordem visual OAM das caixas PASS;
- teste de spin-kill da Venus Flytrap PASS;
- painel de diagnóstico da planta e preview da pilha regenerados.

O executável Win32 continua sendo produzido por `COMPILAR-WINDOWS.cmd`; este ambiente não possui Windows SDK/MSVC para executar a janela nativa aqui.
