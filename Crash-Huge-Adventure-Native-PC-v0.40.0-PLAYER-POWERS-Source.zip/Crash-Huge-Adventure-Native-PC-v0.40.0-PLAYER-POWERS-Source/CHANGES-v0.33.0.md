# v0.33.0 — Underwater Core

## Gargalo encontrado

A auditoria mostrou que o maior gargalo do runtime de salas normais não estava mais na primeira fase: salas `kind 1` (subaquáticas) eram lidas da ROM, mas o port só aceitava o start terrestre `0x00` e o loop de entidades só executava IA para `0x28` e `0x2A`. Isso fazia a segunda fase e as demais salas aquáticas existirem nos dados, porém sem um caminho nativo completo de jogador/inimigos.

## Correções estruturais

- `Scene` agora preserva `room.kind` e `GameData::nativePlayable()` aceita salas kind 1 com start `0x02`.
- O boss Dingodile (`0x45`) continua bloqueado até o controller próprio existir, evitando falso suporte.
- `Player` ganhou modo `Underwater` separado do modo terrestre, usando sprite bank 1 e o start `0x02` da própria sala.
- Controle aquático 8-way: A/D/W/S ou setas, stroke em Espaço/Z e spin em X/K.
- Velocidades-base foram ancoradas nas constantes do original: stroke 704 Q8 e spin 960 Q8, com diagonais correspondentes.
- Renderer HD/ROM seleciona o bank do player dinamicamente, sem assumir bank 0.
- A família de inimigos aquáticos passa pelo loop nativo de entidades:
  - `0x30` Pufferfish — bank 5, ciclo de ataque + oscilação vertical por parâmetros da sala;
  - `0x31` Shark — bank 4, patrulha X + perseguição Y dentro dos ranges da ROM;
  - `0x32` Moray Eel — bank 3, orientação original e hazard estático;
  - `0x33` Electric Eel — bank 8, patrulha/ciclo de ataque;
  - `0x34` Squid — bank 7, movimento aquático/flip cycle nativo aproximado;
  - `0x35` Jellyfish — bank 9, bob vertical parametrizado;
  - `0x4B/0x4C` Sea Mine — bank 6, homing X/Y limitado pelos ranges da ROM.
- `0x5B` Seaweed agora é desenhada a partir do bank 45 como decoração da sala.
- `enemyTotal`/`enemyKills` passam a incluir a família aquática.
- A física final da v0.32 para pilhas de caixas, incluindo queda da cadeia superior, foi preservada integralmente.
- Novo `CrashUnderwaterTool` gera uma faixa de diagnóstico da segunda fase.

## Cobertura destravada

As quatro salas subaquáticas normais do jogo (levels 1, 8, 12 e 16 na tabela interna) agora passam pelo runtime de sala kind 1. A segunda fase possui 27 inimigos aquáticos ativos no runtime: 7 Pufferfish, 8 Sharks, 5 Moray Eels e 7 Sea Mines, além de 8 Seaweeds decorativas.

## Validação

- 8/8 suítes strict PASS.
- `make -B all` PASS com `-std=c++17 -O2 -Wall -Wextra -Wpedantic -Werror`.
- ASan + UBSan PASS em `TestPlayer`, `TestEntities` e `TestRunState`.
- Regressão da v0.32 verificada: Venus Flytrap, links/OAM/queda das pilhas de caixas, frontend, GAX e ActorCategory continuam passando.
- Windows EXE não foi compilado neste ambiente; `COMPILAR-WINDOWS.cmd` foi atualizado para v0.33.0 e inclui `CrashUnderwaterTool.exe`.
