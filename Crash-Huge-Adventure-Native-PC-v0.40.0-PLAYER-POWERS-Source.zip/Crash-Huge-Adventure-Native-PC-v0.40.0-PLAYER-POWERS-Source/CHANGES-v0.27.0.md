# v0.27.0 — Jetpack Ring Rewards + Hovercraft Part Death/Flash

## Jetpack rings

- Portada a cadeia confirmada de `PassJetpackRing`:
  1. +1 Wumpa;
  2. +5 Wumpas;
  3. +20 Wumpas;
  4. +20% de HP;
  5. +1 vida;
  depois a cadeia volta ao início.
- Intervalo `<= 0x14` frames não concede novo prêmio.
- Intervalo `> 0xBE` frames reseta a cadeia para o primeiro prêmio.
- Time trial não concede a cadeia de prêmios, igual ao original.
- Fila `gJetpackQueuedWumpa` reproduzida: cooldown inicial `0x0F` e drenagem em lotes 1/2/4/8 conforme o saldo.
- Em estados inativos/finalização a fila restante é creditada de uma vez.
- O ring kind 31 agora desenha também a segunda peça kind 43 criada pelo original; apenas kind 31 continua sendo o gatilho.

## Hovercraft

- `StartHovercraftHitFlash` / `UpdateHovercraftHitFlash` portados como latch compartilhado de 12 ticks, alternando a fase a cada 4 ticks.
- Corrigida vulnerabilidade das peças:
  - cannon: recebe dano mesmo fora da janela de disparo;
  - side guns: recebem dano enquanto vivos;
  - launcher: só recebe dano no estado ativo, como `DamageHovercraftLauncher`.
- Destruir uma peça agora reduz `partsLeft` imediatamente, mas mantém a peça em sua animação de morte até `animDone`:
  - cannon: anim 2;
  - launcher: anim 3;
  - side guns: anim 0/1 conforme o lado.
- Cannon/launcher passam a usar animações de estado também durante espera/ataque, em vez de sempre desenhar anim 0.
- Mantidos os timings originais `45/6/210`, `20/5/90`, `32/3/160` (perfil 0) e o segundo perfil já presente.

## Diagnóstico / validação

- `CrashJetpackTool` agora gera 5 painéis e inclui um painel de ring/reward.
- `TestCategory` cobre a sequência 1/5/20/HP/vida, os thresholds `0x14`/`0xBE`, fila de Wumpa, time trial, flash do Hovercraft, gating do launcher e duração da animação de morte do cannon.
- 8/8 suítes strict PASS.
- `make all` PASS.
- TestCategory, TestFrontend e TestAudio: ASan + UBSan PASS.

## Ainda não declarado 100%

- O flash do Hovercraft tem timing/latch original, mas a troca exata do índice de palette 15 ainda é uma aproximação no renderer RGBA host.
- Alguns efeitos visuais dos Wumpas voando até o HUD ainda podem ser aprofundados; a fila, quantidade e momento de crédito estão portados.
- GAX2 continua avançado, mas não declarado bit-exact em todos os casos raros do DSP.
