# v0.18.0 — Frontend, save e mapa

- Tela inicial nativa com Continuar / Novo Jogo / Sair.
- Mapa nativo com 25 fases e desbloqueio sequencial.
- Ao concluir a última etapa suportada de uma fase, o jogo registra a conclusão e retorna ao mapa.
- Save automático em `save/crash-native-v1.sav`.
- Save versionado preserva inventário global, níveis concluídos, melhores tempos, checkpoint e snapshots completos das salas normais.
- `F10` salva manualmente; `Esc` durante o gameplay salva e volta ao mapa.
- `TestFrontend` e `CrashFrontendTool` adicionados.
- Todas as actor-categories 0–6 e o hovercraft da v0.17 continuam funcionando.
- Áudio/música original e gráficos originais do menu/mapa continuam pendentes; esta versão entrega primeiro o fluxo funcional do front-end.
