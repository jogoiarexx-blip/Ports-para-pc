# v0.37.0 — Tiny Tiger boss controller

## Gargalo fechado

A v0.37 porta o boss Tiny Tiger (`0x47`) da sala 23 para o runtime nativo. Em vez de tratá-lo como inimigo genérico, o port agora mantém a máquina de estados própria do boss, os cinco Rock Platforms usados como anchors e os child effects da luta.

## Implementação

- sprite bank 55 do Tiny carregado diretamente da ROM, com 9 animações;
- controller dedicado seguindo os 16 estados do original;
- saltos parabólicos em 26 passos usando a tabela quadrática `i*i >> 8` de 257 entradas;
- seleção do próximo anchor pela distância Manhattan do Crash e pela tabela original `gTinyHopTargets` de 77 bytes;
- cinco Rock Platforms (`0x58`) da sala usados como anchors reais da luta;
- três rounds, com anchors de reset `{4, 1, 0}`;
- estado vulnerável em animação 6 e progressão de um round por spin hit;
- Rock Platform pisado pelo boss entra no fluxo de stomp e afunda a 4 px/frame até sair da arena;
- hazards de folhas usam bank 55 / anim 5 e velocidade vertical original de 0,5 px/frame;
- após o terceiro hit é criado o Tornado Spin power usando bank 38 / anim 0;
- a saída da sala só é liberada depois da conclusão da fuga e da coleta da recompensa;
- `CrashTinyTool` adicionado para diagnóstico isolado da luta;
- save em disco passa para formato v4 e preserva todos os campos transitórios do Tiny; leitura dos formatos v1-v3 continua suportada; a recompensa pendente é reconstruída no restore e uma luta já concluída/coletada mantém a saída liberada;
- `CrashEnemyCoverageTool` agora inclui Tiny/Cortex/Mega-Mix na auditoria de bosses, expondo corretamente os dois controllers ainda pendentes.

## Cobertura após esta versão

- `CrashRouteTool`: 24/24 salas tile com caminho nativo de player/runtime;
- `CrashEnemyCoverageTool`: 408 entidades da família inimigo/hazard/boss tratadas;
- pendências explicitamente detectadas: Cortex (`0x48`) e Mega-Mix (`0x49`).

## Validação

- build C++17 strict com `-Wall -Wextra -Wpedantic -Werror`;
- regressão completa das 8 suítes;
- testes específicos de Tiny: primeiro salto, folhas, pad stompado, três hits, recompensa e saída;
- persistência v4 do Tiny coberta em `TestRunState`;
- sanitizers ASan + UBSan em `TestEntities`, `TestRunState` e `TestPlayer`.
