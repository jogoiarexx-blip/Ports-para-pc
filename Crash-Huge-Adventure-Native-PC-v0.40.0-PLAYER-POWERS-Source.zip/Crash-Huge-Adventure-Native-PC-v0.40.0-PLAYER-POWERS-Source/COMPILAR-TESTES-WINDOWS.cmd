@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Crash Native v0.40.0 - Testes Windows x64
set "VSCMD_SKIP_SENDTELEMETRY=1"

where cl >nul 2>nul
if not errorlevel 1 goto :compiler_ok

for %%V in (
  "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat"
  "C:\Program Files\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat"
  "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat"
  "C:\Program Files\Microsoft Visual Studio\2022\Professional\VC\Auxiliary\Build\vcvars64.bat"
  "C:\Program Files\Microsoft Visual Studio\2022\Enterprise\VC\Auxiliary\Build\vcvars64.bat"
) do if exist "%%~V" (
  echo Carregando ambiente C++: %%~V
  call "%%~V" >nul
  goto :compiler_check
)

:compiler_check
where cl >nul 2>nul
if not errorlevel 1 goto :compiler_ok

echo.
echo ERRO: compilador C++ do Visual Studio 2022 nao encontrado.
echo Instale "Desktop development with C++" no Visual Studio Build Tools.
goto :erro

:compiler_ok
echo ============================================
echo  Crash Native v0.40.0 - compilando testes
echo ============================================
call :build TestCore.exe "tests\test_core.cpp" || goto :erro
call :build TestPlayer.exe "tests\test_player.cpp" || goto :erro
call :build TestEntities.exe "tests\test_entities.cpp" || goto :erro
call :build TestCategory.exe "tests\test_category.cpp" || goto :erro
call :build TestRunState.exe "tests\test_run_state.cpp" || goto :erro
call :build TestFrontend.exe "tests\test_frontend.cpp" || goto :erro
call :build TestAudio.exe "tests\test_audio.cpp" || goto :erro
call :build TestHD.exe "tests\test_hd.cpp src\png.cpp" || goto :erro

echo.
echo OK: todos os executaveis de teste Windows foram gerados.
if /I "%~1"=="/nopause" exit /b 0
pause
exit /b 0

:build
set "OUT=%~1"
set "SRC=%~2"
echo [C++] %OUT%
if exist "%OUT%" del /q "%OUT%" >nul 2>nul
cl /nologo /std:c++17 /EHsc /O2 /MT %SRC% /Fe"%OUT%"
if errorlevel 1 exit /b %errorlevel%
if not exist "%OUT%" (
  echo ERRO: o compilador terminou sem gerar "%OUT%".
  echo Verifique se o Windows Defender/antivirus bloqueou ou removeu o arquivo.
  exit /b 2
)
exit /b 0

:erro
echo.
echo FALHA ao compilar os testes da v0.40.0.
if /I "%~1"=="/nopause" exit /b 1
pause
exit /b 1
