#include "game_data.hpp"
#include <iomanip>
#include <iostream>

int main(int argc,char** argv){
    try{
        if(argc!=2){std::cerr<<"Usage: CrashRouteTool ROM\n";return 2;}
        crash::GameData data(crash::read(argv[1]));
        unsigned tileRooms=0,nativeRooms=0,actorStages=0,multiRoomLevels=0;
        for(unsigned level=0;level<25;++level){
            auto route=data.roomRoute(level);if(route.size()>1)++multiRoomLevels;
            std::cout<<"level="<<(level+1)<<" route="<<route.size();
            for(const auto& r:route){
                std::cout<<" | slot="<<(r.slot+1)<<" kind="<<r.kind;
                if(r.tileRoom()){++tileRooms;bool native=data.nativePlayable(r);if(native)++nativeRooms;std::cout<<" tile desc=0x"<<std::hex<<std::uppercase<<r.descriptor<<std::dec<<" native="<<(native?1:0);}
                else{++actorStages;std::cout<<" actor_category="<<r.category;}
            }
            std::cout<<"\n";
        }
        std::cout<<"summary tile_rooms="<<tileRooms<<" native_player_rooms="<<nativeRooms<<" actor_category_stages="<<actorStages<<" multi_room_levels="<<multiRoomLevels<<"\n";
        return 0;
    }catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}
}
