# v0.40.0 — ROM-derived Player Actions + Permanent Powers

## Gargalo atacado

A v0.39 encerrou a cobertura bruta dos atores das salas tile em 410/410. O maior gargalo seguinte era o controller terrestre de Crash, que ainda se limitava essencialmente a andar, pular e girar. A v0.40 começa a substituir essa simplificação pela action table e pelos motion records do jogo original.

## Controller terrestre

- R / Baixo: crouch;
- R/Baixo + direção: crawl (animação 20);
- direção + R: slide com velocidade inicial Q8 1408 e desaceleração Q8 56;
- salto a partir de crouch/slide: high jump;
- R no ar: Body Slam, aceleração/target baseados nos motion records Q8;
- ataque comum agora reconhece spin, slide e body slam onde apropriado;
- Super Body Slam cria impacto radial contra caixas breakable e inimigos comuns próximos;
- Double Jump adiciona o segundo salto no ar;
- Tornado Spin acumula presses de spin, prolonga o giro e reduz a aceleração de queda;
- Turbo Run: segurar L + direção após desbloqueio.

## Progressão e save

- Dingodile (nível 5): Super Body Slam;
- N. Gin (nível 11): Double Jump;
- Tiny (nível 17): Tornado Spin;
- Neo Cortex (nível 23): Turbo Run;
- save atualizado para v7 com `powerFlags`;
- leitor mantém compatibilidade v1-v6 e reconstrói poderes a partir dos bosses concluídos;
- reward de Tiny aplica Tornado Spin e reward de Cortex aplica Turbo Run já durante o runtime.

## Windows / testes

- novo `COMPILAR-TESTES-WINDOWS.cmd`;
- `TESTAR.cmd` detecta `Test*.exe` ausentes e recompila automaticamente;
- execução usa caminho explícito `./Test*.exe` no fluxo equivalente do Windows (`.\Test*.exe`);
- helpers `/Fe` validam se o executável realmente foi criado e param com diagnóstico claro se ele desaparecer/bloquear;
- `COMPILAR-WINDOWS.cmd` também passa a gerar as ferramentas ChildEffect, Dingodile, Tiny, Cortex e Mega-Mix que já existiam no Makefile.

## Validação

- build C++17 strict: PASS;
- 8/8 suítes: PASS;
- `CrashEnemyCoverageTool`: 410/410 entidades tratadas, `unsupported=0`;
- regressões novas cobrem crouch/crawl, slide/high-jump, Body/Super Body Slam, Double Jump, Tornado Spin, Turbo Run e persistência dos quatro poderes.
