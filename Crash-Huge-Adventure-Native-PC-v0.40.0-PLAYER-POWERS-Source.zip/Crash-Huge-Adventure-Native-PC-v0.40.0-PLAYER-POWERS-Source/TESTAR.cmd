@echo off
setlocal EnableExtensions
cd /d "%~dp0"

set "MISSING="
for %%T in (TestCore.exe TestPlayer.exe TestEntities.exe TestCategory.exe TestRunState.exe TestFrontend.exe TestAudio.exe TestHD.exe) do if not exist "%%T" (
  echo [AUSENTE] %%T
  set "MISSING=1"
)

if defined MISSING (
  echo.
  echo Um ou mais testes Windows ainda nao foram compilados.
  echo Compilando automaticamente os executaveis ausentes/necessarios...
  call "%~dp0COMPILAR-TESTES-WINDOWS.cmd" /nopause
  if errorlevel 1 goto :erro
)

echo.
echo Executando testes...
call :run TestCore.exe || goto :erro
call :run TestPlayer.exe || goto :erro
call :run TestEntities.exe || goto :erro
call :run TestCategory.exe || goto :erro
call :run TestRunState.exe || goto :erro
call :run TestFrontend.exe || goto :erro
call :run TestAudio.exe || goto :erro
call :run TestHD.exe || goto :erro

echo.
echo Testes concluidos com sucesso.
if /I "%~1"=="/nopause" exit /b 0
pause
exit /b 0

:run
if not exist "%~1" (
  echo ERRO: "%~1" nao existe mesmo depois da compilacao.
  exit /b 2
)
echo [TEST] %~1
".\%~1"
exit /b %errorlevel%

:erro
echo.
echo Falha nos testes.
if /I "%~1"=="/nopause" exit /b 1
pause
exit /b 1
