# v0.26.0 — Hovercraft Fireballs + Jetpack Death/Finish

## Implementado

- Hovercraft side guns agora criam fireball kind 39 real:
  - HP 2;
  - speed Z `0x95`;
  - decay `-5`, piso `0x14`;
  - dano 6;
  - death/explode animation da ROM.
- Hovercraft cannon usa cannonball kind 3:
  - projeção `angle/scale` original;
  - limite Manhattan `0xFFF`;
  - dano 2;
  - Z `-0x100`/frame.
- Enemy shots com actor kind usam sprite, `baseDepth` e AABB ROM.
- Bombers 5/6/8 do launcher mantidos como atores reais e ordem de update aproximada ao original corrigida.
- Jetpack player:
  - state 4 death/fall;
  - state 5 finish;
  - state 6 ring boost;
  - fatal damage não respawna mais instantaneamente;
  - finish do Hovercraft não conclui a fase no mesmo instante em que o boss some.
- Ring alinha o player ao centro e mantém state 6 até tick `0x32`.
- Render de peças/bombers/projéteis passa a usar `actorBaseDepth` da ROM.
- `CrashJetpackTool` atualizado com quatro painéis de diagnóstico.

## Ainda parcial

- cadeia de recompensas completa dos rings (1/5/20 Wumpa, cura, vida) ainda não foi portada integralmente;
- alguns efeitos visuais de hit/flash do Hovercraft ainda são simplificados no renderer PC;
- GAX2 permanece muito próximo do original, mas não é declarado bit-exact.
