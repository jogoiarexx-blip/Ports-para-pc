# Crash Native v0.21.0 — GAX2 Effects + Original Level Select Art

Esta versão aprofunda a tradução do áudio GAX2 para o runtime C++ nativo e aproxima o frontend dos dados gráficos originais da ROM ACQE.

## Áudio GAX2

- Corrigido o modelo de pitch: a nota do pattern e a nota interna da sequência do instrumento agora são estados separados, como no GAX2 original.
- Implementados envelopes com interpolação, sustain e loop.
- Implementado vibrato pela tabela senoidal GAX2 de 64 passos.
- Implementados pitch slide, volume slide/set, portamento, pattern break, note delay E-Dx e speed/alternating speed.
- Implementada a sequência interna de instrumentos, incluindo note/wave change, loop/jump e seus dois FX por passo.
- Implementados sample loop, ping-pong e sweep dinâmico por row de instrumento.
- SFX originais agora respeitam slot, prioridade e volume da tabela de 99 entradas; as duas vozes principais usam round-robin/prioridade.
- Checkpoint foi confirmado como SFX 0x17. O cue de tiro voltou ao fallback sintetizado até seu ID original ser confirmado, evitando tocar um efeito incorreto.
- Corrigido disparo duplicado de LevelClear.
- Backend Win32 otimizado: o lock do replayer GAX ocorre por buffer, não uma vez por sample.

### Cobertura validada na ROM ACQE

Banco musical: 52 instrumentos válidos, 52 envelopes, 7 instrumentos com vibrato, 6 com sequência interna multi-etapas, 31 rows com loop, 9 rows ping-pong e 6 rows com sweep.

Banco SFX: 88 instrumentos válidos, 88 envelopes e 99 rotas de gameplay/menu.

## Frontend / Warp Room

- Adicionado decodificador GBA LZ77/RGB555 seguro em `src/gba_art.hpp`.
- Na ROM ACQE validada, o port extrai palette, tiles 8bpp e tilemap 32x32 da arte original de level select e a usa como base visual do Warp Room.
- Se esses blocos não validarem em outra revisão de ROM, o frontend cai automaticamente no renderer procedural da v0.20.
- A navegação 5 fases + boss por andar e a progressão/save foram preservadas.

## Correções de robustez

- Corrigido UB detectado pelo UBSan ao aplicar transpose negativo; a conversão para unidades de pitch não usa mais left-shift de valor negativo.
- Bounds checks mantidos em ponteiros GBA, LZ77, instrumentos, envelopes, waves, patterns e tilemaps.
- O caminho sintetizado da v0.19 continua como fallback para cues/SFX ainda não confirmados.

## Validação

- 8/8 suítes: PASS.
- GCC strict `-Wall -Wextra -Wpedantic -Werror`: PASS.
- ASan + UBSan: Audio, Frontend e Category PASS após a correção do transpose.
- Sintaxe Win32 de `game_win32.cpp`: PASS com declarations-stub; não houve link MSVC/MinGW neste ambiente.

## Ainda não é bit-exact

O runtime já reproduz muito mais da semântica GAX2 usando os dados originais da ROM, mas ainda não é o mixer Shin'en 2.01D bit-a-bit. Echo/DSP, resampling/downmix exato, alguns detalhes de envelope/mixer e IDs restantes de SFX continuam como próximos alvos. Nenhum código ARM do GBA é executado pelo port.
