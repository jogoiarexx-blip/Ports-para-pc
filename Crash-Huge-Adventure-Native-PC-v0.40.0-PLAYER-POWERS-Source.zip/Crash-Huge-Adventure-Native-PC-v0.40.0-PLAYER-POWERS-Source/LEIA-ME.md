# Crash Bandicoot: The Huge Adventure — port nativo PC, v0.40.0



## v0.40.0 — controller terrestre e poderes permanentes

Esta rodada muda o gargalo principal do port: depois de fechar a cobertura bruta dos atores em 410/410, o foco passa para a fidelidade do próprio Crash. O controller terrestre agora implementa estados derivados da action table da ROM/decomp: agachar, crawl, slide, salto alto a partir de crouch/slide, body slam, Super Body Slam, Double Jump, Tornado Spin e Turbo Run.

- R (PC: `E`) ou Baixo agacha; com direção, Crash rasteja;
- direção + R inicia slide sem exigir que Crash já esteja correndo;
- salto durante crouch/slide usa o salto alto;
- R no ar executa Body Slam; após Dingodile, vira Super Body Slam com impacto radial;
- N. Gin libera Double Jump; Tiny libera Tornado Spin; Neo Cortex libera Turbo Run;
- os quatro poderes são permanentes e persistem no save v7; saves v1-v6 continuam aceitos e derivam os poderes dos bosses já concluídos;
- recompensas visuais já portadas de Tiny/Cortex também aplicam seus poderes imediatamente ao serem coletadas;
- `TESTAR.cmd` agora recompila automaticamente executáveis de teste ausentes no Windows e valida a existência de cada `.exe`, corrigindo o caso `TestPlayer.exe não é reconhecido`.

## v0.39.0 — Mega-Mix chase boss nativo

A v0.39 fecha o último boss explicitamente ausente da auditoria de salas tile. Mega-Mix (`0x49`) usa o bank 30 e seu controller de perseguição em três estados: acelera pelos quatro motion records originais, muda a direção conforme Crash, quebra/explode caixas no caminho e entra no grab quando o jogador alcança a janela original de aproximadamente 40×50 px. O grab usa a animação 1 e aplica o evento de dano no frame 8; Mega-Mix não possui HP e não é derrotado pelo spin, porque esta luta é uma perseguição.

A saída da fase também foi corrigida estruturalmente: o exit marker real fica em `x=7275` numa sala de 8000 px, antes do limiar heurístico usado pelas fases comuns. A presença do Mega-Mix agora arma esse marcador de saída explicitamente, evitando uma fase jogável porém impossível de concluir. O save sobe para v6 e preserva state, animação, motion mode, stamp/latch e velocidade do boss, mantendo leitura de saves v1-v5.

`CrashEnemyCoverageTool` agora reporta **410 entidades boss/enemy/hazard tratadas e 0 unsupported** nas 24 salas tile. `CrashMegaMixTool` foi adicionado para diagnosticar perseguição, destruição de caixas e grab isoladamente.


## v0.38.0 — Neo Cortex boss nativo

A v0.38 porta o Neo Cortex (`0x48`) com bank 53, cannon, target/crosshair, tiros lento/rápido, três boss gems, flip-platforms específicas da arena e recompensa Turbo Run. O save v5 preserva a fase completa da luta e a recompensa pendente. Após essa versão, Mega-Mix era a única entidade explicitamente unsupported na auditoria tile-room.


## v0.37.0 — Tiny Tiger boss nativo

A v0.37 porta Tiny Tiger (`0x47`) para um controller dedicado baseado na máquina de 16 estados do original. A luta usa o bank 55, os cinco Rock Platforms reais como anchors, saltos parabólicos de 26 passos, três rounds, pads stompados que afundam, hazards de folhas e a recompensa Tornado Spin do bank 38. O save sobe para v4 para preservar o estado transitório completo do boss, mantendo leitura de v1-v3; a recompensa também é reconstruída ao restaurar um save/checkpoint se ainda não tiver sido coletada, evitando softlock no fim da luta.

A auditoria de cobertura também foi ampliada para incluir os bosses seguintes: agora há **408 entidades tratadas**, e as duas pendências ficam explícitas em vez de escondidas pelo escopo antigo da ferramenta: Cortex (`0x48`) e Mega-Mix (`0x49`). `CrashTinyTool` fornece diagnóstico isolado da luta.


## v0.36.0 — Dingodile boss nativo

A v0.36 fecha a última sala tile bloqueada: Dingodile (`0x45`) agora possui controller dedicado com bank 54, shield, foguete, estalactite, tubarões, janela de vulnerabilidade, três acertos e queda/finalização. `CrashRouteTool` agora reporta **24/24 salas tile nativas** e `CrashEnemyCoverageTool` reporta **407/407 entidades tratadas / 0 unsupported**.

O save em disco sobe para v3 para preservar o estado do boss, mantendo leitura dos formatos v1/v2. `CrashDingodileTool` fornece diagnóstico isolado da luta. Rebuild strict, 8/8 suítes e ASan/UBSan de Player/EntityWorld/RunState permanecem verdes.


## v0.35.0 — child effects e projéteis reais

A v0.35 fecha o primeiro bloco de ataques-filhos do `EnemyCtrl`. Blowgun Tribesman passa a lançar o dardo real do bank 12/anim 6 a 4 px/frame, e Flamethrower Lab Assistant cria a chama do bank 23/anim 4 no frame 9 do ataque. Esses objetos não são dano “colado” no inimigo: têm posição, hitbox, velocidade, lifetime, colisão e cleanup próprios, usando a mesma matemática de `LaunchEffectPart` confirmada no decomp.

A família genérica também passa a manter `controllerMode/controllerTicks`, permitindo selecionar as animações pelo mesmo mapa de modos do original. `CrashChildEffectTool` foi adicionado para diagnóstico. 8/8 suítes e ASan/UBSan de EntityWorld/RunState permanecem verdes.

## v0.34.0 — controlador genérico de inimigos

A v0.34 eliminou o gargalo de entidades carregadas da ROM mas ignoradas pelo gameplay: 225 inimigos/hazards e 7 Seal Spawners passaram para um dispatcher compartilhado baseado no `EnemyCtrl`, fechando 406/406 entidades da família normal nas 24 salas tile.

## v0.33.0 — núcleo subaquático

A auditoria mostrou que o maior gargalo era o runtime de salas `kind 1`: a ROM já fornecia sala, start `0x02`, player scuba e inimigos, mas o port rejeitava esse modo e ignorava quase toda a família aquática. A v0.33 adiciona um caminho de controle subaquático separado do terrestre, seleciona o bank 1 do Crash scuba e ativa a família `0x30–0x35` + Sea Mine usando os próprios banks/parâmetros da ROM.

As quatro salas subaquáticas normais (levels internos 1, 8, 12 e 16) entram no runtime nativo. O boss Dingodile continua explicitamente bloqueado até receber seu controller específico. A segunda fase passa a ter 27 inimigos aquáticos ativos e 8 Seaweeds decorativas. `CrashUnderwaterTool` foi adicionado para diagnóstico.

A física/ordem de caixas e o double-buffer da v0.32 foram preservados; 8/8 suítes strict continuam passando, com ASan/UBSan em Player, EntityWorld e RunState.


## v0.32.0 — estabilidade da primeira fase

- Venus Flytrap (`0x2A`, bank 10) agora recebe o giro e morre; as plantas entram no contador real de inimigos.
- As pilhas de caixas passam a ler os `level_link_list` da própria sala; a primeira fase possui 6 relações `de baixo -> de cima`.
- O carregamento preserva as coordenadas exatas da ROM, sem correção artificial de Y.
- A composição das caixas respeita a prioridade equivalente ao OAM do GBA, corrigindo sobreposição visual nas pilhas.
- Ao quebrar a base de uma pilha, a caixa acima é deslinkada e cai até o novo apoio em vez de ser teleportada no mesmo frame. O save v2 preserva essa queda transitória e o loader ainda aceita saves v1.
- A apresentação Win32 usa back buffer GDI persistente, `WM_ERASEBKGND` bloqueado e um único `BitBlt` por paint, removendo o clear direto que causava piscadas.
- Build strict + 8/8 suítes PASS; `TestEntities` e `TestRunState` também passaram ASan + UBSan.

Este projeto converte o jogo para um runtime **C++ nativo de PC**. A ROM USA ACQE é usada como fonte de dados, áudio, gráficos e tabelas. O runtime não executa código ARM do GBA e não é um emulador.

## O avanço da v0.31

A v0.31 corrige um erro estrutural na leitura do `category_descriptor`. Os campos `+0x20..+0x30` deixam de ser tratados como seletores genéricos e passam a ter a semântica real do jogo: `maskAssistDeaths`, `bonusKindDeaths`, `retryBossDeaths`, `bossLevel` e `retryBossLevel`. Com isso, `kind`, `altKind` e `bonusKind` deixam de ser misturados e os retries passam a usar os perfis corretos dos bosses.

### Variantes e retries por descriptor

O runtime agora mantém o kind selecionado de cada evento em cache. Normal usa `kind`; Time Trial usa `altKind` com os folds originais; somente após o threshold de mortes o retry usa `bonusKind`. As mortes de categoria e de boss são contadas separadamente, e um retry reconstrói os eventos posteriores ao checkpoint sem transformar atores já ativos no meio do frame.

### Assist e perfis de boss

Nas categorias Jetpack, ao atingir `maskAssistDeaths`, o HP máximo passa de 100 para **120**, e curas de ring/health crate continuam sendo 20% do máximo. Airship agora possui os **6 registros** da tabela original (3 normais + 3 de retry), e o Hovercraft troca do perfil 0 para o perfil 1 quando `retryBossDeaths` é atingido; isso muda HP dos side guns e timings de ataque.

### Corrigido também

O fold Polar de Time Trial não converte mais kind 23 em 20: o dispatcher original mantém 23. Waypoints do Plane passam a consultar o kind já selecionado/cached, evitando divergência entre a rota usada pelo ator e a variante ativa da categoria.

## Mantido da v0.30

A v0.30 fechou a camada de fidelidade de SFX do Jetpack/Hovercraft: os efeitos sonoros de gameplay passam por **callbacks exatos do ator para a tabela GAX da ROM**. O evento preserva ID, volume e voz quando o original exige, além de manter duas chamadas no mesmo frame quando elas realmente existem no código do jogo.

### SFX por callback de ator

O runtime agora possui `playSfxId()` e uma fila `OriginalSfxEvent`. Entre os callbacks já ligados estão tiro `0x24` com volume `0xA0`/voz 2, dano do player `0x42`, ambiência bomber `0x37`, balloon pop `0x2E`, Rocket `0x2D`/`0x04`, Ring `0x3E`, Plane `0x25`, Airship hit `0x43` + queda `0x42`, Hovercraft hit `0x45`, Wumpa ao HUD `0x0E` e FinishJetpackRun `0x3B`. A morte de uma peça do Hovercraft preserva as **duas chamadas `0x04`** da sequência original.

### FinishJetpackRun real nas rotas 3/4/5

Ao alcançar o fim da rota, o Jetpack agora entra primeiro no state 5, toca `0x3B` e executa a saída em profundidade. `complete` só é marcado quando esse estado termina, em vez de encerrar instantaneamente no threshold.

## Mantido da v0.29

### Balão filho destrutível e queda do crate

Tiros do player agora testam primeiro o balão 40/41/42 ligado ao crate. No segundo acerto, o balão entra na animação 1 de estouro e o crate pai passa ao state 1 de queda. A queda usa a aceleração original `+0x12` Q8 por frame, limitada a `0x4C0`, e o crate é removido ao ultrapassar Y `0xE100`.

Se o crate em queda for atingido depois, ele ainda pode resolver seu reward normal, mas **não conta uma segunda caixa quebrada e não recria/libera outro balão**. O balão que foi liberado por uma quebra normal também mantém os **2 HP** e pode ser estourado por tiros durante o float-away. Isso preserva o ciclo completo do ator filho e o encadeamento filho → callback → pai do jogo original.

## Mantido da v0.28

### Wumpas voando para o HUD

A fila de reward continua usando cooldown `0x0F` e lotes 1/2/4/8, mas agora cada lote cria o **kind 44** visual. O efeito segue a matemática confirmada de `CreateJetpackCollectedWumpa`: mira `(16,16)` e só credita a quantidade ao chegar ao HUD. Em estado inativo/finalização, a fila restante continua sendo creditada imediatamente.

### Balloon crates

Health/question/time crates entram em state 2 / anim 1 antes da remoção. Question crates usam a fila 1/3/5, e os balões filhos 40/41/42 agora aparecem na cena. Ao quebrar o crate, o balão é liberado e sobe até sair da tela em vez de desaparecer no mesmo frame.

### Parachute Nitro e Rocket

O Parachute Nitro sobe reto a partir de Y=-250 em passos `0x140`; a oscilação X artificial foi removida. O Rocket agora usa dano 14, box ativada 42×42, órbita/step Y confirmados e animações separadas para trigger normal e destruição por tiro.

### Hovercraft palette

O flash foi separado em dois sistemas, como no original: o hit-flash de 12 ticks atua no medidor, enquanto `RunHovercraftState` alterna somente o **índice 15** da palette do boss/parts nos frames 8/16. Como kinds 11/12/13 usam palette bank 10, o renderer consegue substituir esse índice diretamente durante a decodificação RGBA.

## Mantido das versões anteriores

- GAX2 com 19 músicas, tabela original de 3828 períodos, envelopes, vibrato, slides, portamento, sequences, loops, ping-pong, sweep, nearest-neighbor Q11, mixer ARM-style e echo por taps/canais;
- Jetpack held-fire `0x12`, roll estados 2/3, morte estado 4, finish estado 5 e ring state 6;
- reward cycle dos rings 1/5/20 Wumpa → cura → vida, gates `0x14`/`0xBE` e peça visual kind 43;
- plane kind 1 com waypoints reais, bombers 4–9, Airship e Hovercraft;
- Polar com Nitro chain, boost, launcher, goal, Aku-Aku tiers e shock;
- frontend usando céu/menu, plataforma de level select e pause background originais da ROM.

## Ferramentas

- `CrashJetpackTool ROM OUTPUT_BMP`: 6 painéis de diagnóstico, incluindo Wumpa kind 44 em trânsito, Hovercraft e balloon-pop/queda do crate.
- `CrashHovercraftTool ROM OUTPUT_BMP`: estados/partes do boss.
- `CrashPolarTool ROM OUTPUT_BMP`: boost, launcher e goal Polar.
- `CrashAirshipTool ROM OUTPUT_BMP`: Airship e sequência de destruição.
- `CrashGaxTool [ROM]`: músicas, períodos, instrumentos, DSP/echo e SFX.
- `CrashChildEffectTool ROM OUTPUT_BMP`: diagnóstico lado a lado do dardo Blowgun e da chama do Flamethrower.
- demais ferramentas de rota, entidades, frontend e HD permanecem no pacote.

## Validação v0.35.0

- 8/8 suítes strict PASS;
- Blowgun child `bank 12 / anim 6 / 4 px-frame` e Flamethrower child `bank 23 / anim 4 / 24 ticks` cobertos por `TestEntities`;
- `CrashChildEffectTool` PASS e preview em `reports/v035-enemy-child-effects.png`;
- `make all` PASS com `-Werror`;
- TestEntities e TestRunState PASS em ASan + UBSan;
- Windows EXE não foi compilado neste ambiente; use `COMPILAR-WINDOWS.cmd` no Windows x64.

## Validação v0.34.0

- 8/8 suítes strict PASS;
- salas subaquáticas kind 1 + player bank 1 + inimigos 0x30–0x35/0x4B validados em TestPlayer/TestEntities;
- `make all` PASS com `-Werror`;
- descriptor/retry/bonus + callbacks GAX continuam cobertos em Category/Audio;
- Venus spin-kill + 6 links de pilha + prioridade visual das caixas cobertos em TestEntities;
- TestEntities e TestRunState passaram ASan + UBSan nesta rodada; Category / Frontend / Audio permanecem cobertos pelas validações anteriores;
- Windows EXE não foi compilado neste ambiente; use `COMPILAR-WINDOWS.cmd` no Windows x64.

## Controles

| Contexto | Teclas |
|---|---|
| Menu | Cima/Baixo + Enter; Esc sai |
| Warp Room | Esquerda/Direita = portal; Cima/Baixo = andar; Enter = jogar; Esc = menu |
| Sala normal | A/D ou setas; Espaço/Z = salto; X/K = giro; E ou Baixo = R (agachar/slide/body slam); Q = L (Turbo após Cortex) |
| Sala subaquática | A/D/W/S ou setas = nadar; Espaço/Z = stroke; X/K = spin |
| Polar | A/D ou setas; Espaço/Z = salto |
| Jetpack/Hovercraft | A/D/W/S; segurar Espaço/Z = tiro automático; Q/E = roll |
| Geral | P pausa; R reinicia; F10 salva; F11 tela cheia; C debug |
| Desenvolvimento | F5 recarrega PNG; F6 escala; F7/F8 troca fase; H alterna PNG/ROM |

## Compilar no Windows

Execute `COMPILAR-WINDOWS.cmd`. Ele procura Visual Studio 2022 / Build Tools, compila `CrashNative.exe`, as ferramentas e executa as oito suítes de teste. Se você executar `TESTAR.cmd` diretamente e algum `Test*.exe` estiver ausente, ele chama `COMPILAR-TESTES-WINDOWS.cmd` e recompila os testes automaticamente antes de rodá-los.

Este ambiente de entrega não possui MSVC/MinGW, portanto o **EXE Windows não foi produzido aqui**. O código portátil e as ferramentas foram compilados aqui em C++17 strict com warnings tratados como erro.

## ROM validada

USA ACQE — SHA-256:
`6be639d1db218ca2bf2b1ff0ee0867334404cead5fb6684af4870d4644a15635`

## Histórico — validação v0.27.0

- 8/8 suítes PASS;
- `-std=c++17 -O2 -Wall -Wextra -Wpedantic -Werror`;
- `make all` PASS;
- `TestCategory`, `TestFrontend` e `TestAudio`: ASan + UBSan PASS;
- cadeia de rings 1/5/20/HP/vida e thresholds `0x14`/`0xBE` cobertos;
- fila de Wumpa 1/2/4/8 coberta;
- ring visual 31+43 ativo;
- Hovercraft cannon/launcher/side-gun com gating de dano específico;
- animações de morte das peças e latch de flash cobertos.

## Próximas pendências fortes

Com as 24 salas tile liberadas, o maior gargalo passa a ser a fidelidade dos **outros boss controllers normais (Tiny/Cortex/Mega Mix) e seus objetos-filhos**, seguida pelos estados raros de ataques/hazards compartilhados. Depois disso, a reconstrução fina de checkpoint/retry da ActorCategory continua sendo a principal dívida estrutural do caminho vehicle/actor-category.
