#include "../src/entities.hpp"
#include <cassert>
#include <iostream>
#include <algorithm>
#include <cmath>
int main(){try{using namespace crash;
 GameData data(read("input/crash.gba"));auto scene=data.scene();auto list=data.entities(scene);
 assert(list.size()==79);assert(std::count_if(list.begin(),list.end(),[](const Entity& e){return e.type==EntityWorld::WumpaType;})==26);
 assert(std::count_if(list.begin(),list.end(),[](const Entity& e){return e.type==EntityWorld::GemType;})==1);
 assert(std::count_if(list.begin(),list.end(),[](const Entity& e){return EntityWorld::isCrate(e.type);})==40);
 assert(std::count_if(list.begin(),list.end(),[](const Entity& e){return e.type==EntityWorld::LevelPlatformType;})==1);
 assert(EntityWorld::crateAnimation(21)==31); // wooden X crate
 assert(EntityWorld::crateAnimation(22)==26); // C/checkpoint crate
 assert(EntityWorld::crateAnimation(23)==23); // Aku crate
 assert(EntityWorld::crateAnimation(30)==28); // Crash/life crate
 assert(EntityWorld::crateAnimation(31)==5);  // Nitro
 assert(EntityWorld::crateAnimation(32)==0);  // ? crate
 assert(EntityWorld::crateAnimation(33)==25); // bounce/slatted crate
 assert(EntityWorld::crateAnimation(35)==17); // TNT
 auto spawn=std::find_if(list.begin(),list.end(),[](const Entity& e){return e.type==0;});assert(spawn!=list.end()&&spawn->x==31&&spawn->y==363);
 auto links=data.entityLinks(scene);assert(links.size()==6);assert(std::any_of(links.begin(),links.end(),[](const EntityLink& l){return l.from==64&&l.to==63;}));
 Terrain terrain(data,scene);Player p(data,scene,terrain);EntityWorld world(data,scene);world.bind(p);
 assert(world.items.size()==79&&world.wumpaPlaced==26&&world.wumpaTotal==71&&world.gemTotal==1&&world.timeTrialTotal==1&&world.gemsCollected==0&&world.crateTotal==40&&world.levelObjectTotal==1&&world.wumpaCollected==0&&world.crateBroken==0&&world.wumpaFrames.size()==14&&world.crateLinkCount==6);
 auto& stackLower=world.items.at(64);auto& stackUpper=world.items.at(63);assert(stackLower.stackAbove==63&&stackUpper.stackBelow==64&&EntityWorld::isCrate(stackLower.source.type)&&EntityWorld::isCrate(stackUpper.source.type));assert(stackLower.y==stackLower.source.y&&stackUpper.y==stackUpper.source.y);auto stackLb=world.entityBox(stackLower),stackUb=world.entityBox(stackUpper);assert(stackLb[1]>=stackUb[3]);
 // Same-priority GBA OBJ sprites use lower OAM index as the visible top layer. The upper crate is spawned first, so it must win in the visual overlap.
 const auto& lowerFrame=world.crateClips[EntityWorld::crateAnimation(stackLower.source.type)].frames.front();const auto& upperFrame=world.crateClips[EntityWorld::crateAnimation(stackUpper.source.type)].frames.front();int overlapX=-1,overlapY=-1;uint32_t upperPixel=0;
 for(int yy=std::max(int(stackLower.y)+lowerFrame.y,int(stackUpper.y)+upperFrame.y);yy<std::min(int(stackLower.y)+lowerFrame.y+lowerFrame.height,int(stackUpper.y)+upperFrame.y+upperFrame.height)&&overlapX<0;yy++)for(int xx=std::max(int(stackLower.x)+lowerFrame.x,int(stackUpper.x)+upperFrame.x);xx<std::min(int(stackLower.x)+lowerFrame.x+lowerFrame.width,int(stackUpper.x)+upperFrame.x+upperFrame.width);xx++){uint32_t lp=lowerFrame.pixels[size_t((yy-int(stackLower.y)-lowerFrame.y)*lowerFrame.width+(xx-int(stackLower.x)-lowerFrame.x))],up=upperFrame.pixels[size_t((yy-int(stackUpper.y)-upperFrame.y)*upperFrame.width+(xx-int(stackUpper.x)-upperFrame.x))];if(lp&&up&&lp!=up){overlapX=xx;overlapY=yy;upperPixel=up;break;}}
 assert(overlapX>=0);std::vector<uint32_t> stackCanvas(80*80,0);int stackCamX=int(stackLower.x)-40,stackCamY=int(stackLower.y)-50;world.renderLogical(stackCanvas,80,80,stackCamX,stackCamY,false);assert(stackCanvas[size_t((overlapY-stackCamY)*80+(overlapX-stackCamX))]==upperPixel);
 // Breaking a normal lower crate removes it from the doubly-linked stack and leaves the upper crate as the new bottom instead of pointing at a dead node.
 auto& breakLower=world.items.at(10);auto& breakUpper=world.items.at(9);assert(breakLower.stackAbove==9&&breakUpper.stackBelow==10);double breakTarget=breakLower.y;p.x=breakLower.x-32;p.y=breakLower.y+24;p.spinTicks=10;world.step(p);assert(!breakLower.active&&breakUpper.active&&breakUpper.stackBelow==std::numeric_limits<unsigned>::max()&&breakUpper.stackFalling);p.spinTicks=0;p.x=31;p.y=363;for(int i=0;i<20&&breakUpper.stackFalling;i++)world.step(p);assert(!breakUpper.stackFalling&&std::abs(breakUpper.y-breakTarget)<.01);world.reset();p.reset();
 assert(!world.levelObjectClips[5].frames.empty());auto lb=world.levelObjectBounds[5];assert(std::abs((lb[2]-lb[0])-37.0)<.01);assert(std::abs((lb[3]-lb[1])-15.0)<.01);
 for(const auto& f:world.wumpaFrames){assert(f.width==32&&f.height==32);assert(std::any_of(f.pixels.begin(),f.pixels.end(),[](uint32_t v){return v!=0;}));}
 for(unsigned a:{0u,2u,5u,17u,23u,25u,26u,28u,31u,32u})assert(!world.crateClips[a].frames.empty());
 auto q5=std::find_if(world.items.begin(),world.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::QuestionCrateType&&e.triggerCap==5;});
 auto q10=std::find_if(world.items.begin(),world.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::QuestionCrateType&&e.triggerCap==10;});
 auto counter=std::find_if(world.items.begin(),world.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::CounterCrateType;});
 assert(q5!=world.items.end()&&q10!=world.items.end()&&counter!=world.items.end()&&counter->triggerCap==5);
 // Exact collision boxes are read from the ROM animation records, not guessed from the sprite image.
 auto normal=std::find_if(world.items.begin(),world.items.end(),[](const RuntimeEntity& e){return e.source.type==21;});assert(normal!=world.items.end());
 auto nb=world.entityBox(*normal);assert(std::abs((nb[2]-nb[0])-19.0)<.01&&std::abs((nb[3]-nb[1])-19.0)<.01);
 assert(p.dynamicSolids==&world.solids&&!world.solids.empty());
 // Wumpa collection.
 auto fruit=std::find_if(world.items.begin(),world.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::WumpaType;});assert(fruit!=world.items.end());
 p.x=fruit->source.x;p.y=fruit->source.y;world.step(p);assert(world.wumpaCollected>=1&&!fruit->active);auto before=world.wumpaCollected;world.step(p);assert(world.wumpaCollected==before);
 // Purple gem: level entity type 7 is dispatcher sub_801EA5C -> sprite bank 37 animation 0; collection persists through runtime state.
 auto gem=std::find_if(world.items.begin(),world.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::GemType;});assert(gem!=world.items.end()&&!world.gemClip.frames.empty());auto gb=world.entityBox(*gem);assert(gb[2]>gb[0]&&gb[3]>gb[1]);p.x=gem->x;p.y=gem->y;world.step(p);assert(!gem->active&&world.gemsCollected==1);
    // Type 16 is the time-trial clock: dispatcher sub_8021F70 -> master record 36 -> bank 36. It is gated until the level has been completed.
    auto clock=std::find_if(world.items.begin(),world.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::TimeTrialType;});assert(clock!=world.items.end()&&!clock->active&&!world.timeTrialClip.frames.empty());world.setTimeTrialAvailable(true);assert(clock->active);auto tb=world.entityBox(*clock);assert(tb[2]>tb[0]&&tb[3]>tb[1]);p.x=clock->x;p.y=clock->y;world.step(p);assert(!clock->active&&world.timeTrialStarted&&!world.timeTrialAvailable);world.timeTrialStarted=false;
 // A normal crate is destroyed by the native spin and creates a ROM-sprite break effect.
 world.reset();p.reset();normal=std::find_if(world.items.begin(),world.items.end(),[](const RuntimeEntity& e){return e.source.type==21;});p.x=normal->source.x;p.y=normal->source.y;p.spinTicks=10;world.step(p);assert(!normal->active&&world.crateBroken>=1&&!world.effects.empty());
 // Super Body Slam exposes the original radial-impact behavior: nearby normal
 // crates are destroyed without requiring direct body/spin overlap.
 world.reset();p.reset();p.grantPower(Player::SuperBodySlamPower);normal=std::find_if(world.items.begin(),world.items.end(),[](const RuntimeEntity& e){return e.source.type==21;});assert(normal!=world.items.end());p.x=normal->x-48.0;p.y=normal->y;p.slamImpactTicks=1;unsigned slamBroken=world.crateBroken;world.step(p);assert(!normal->active&&world.crateBroken>slamBroken);
 // Metal crate survives the spin and participates in dynamic solid collision.
 world.reset();p.reset();auto metal=std::find_if(world.items.begin(),world.items.end(),[](const RuntimeEntity& e){return e.source.type==28;});assert(metal!=world.items.end());p.x=metal->source.x;p.y=metal->source.y;p.spinTicks=10;world.step(p);assert(metal->active&&world.crateBroken==0);
 auto mb=world.entityBox(*metal);double floor= p.floorSurface(mb[0]+2,mb[2]-2,mb[1]-2,mb[1]+2);assert(std::abs(floor-mb[1])<.01);
 // Land on a metal box: the player stops exactly on its ROM collision top instead of passing through.
 p.spinTicks=0;p.x=metal->source.x;p.y=mb[1]-p.by-p.bh-8;p.vy=4;p.grounded=false;bool landed=false;for(int i=0;i<6;i++){p.step({});world.step(p);if(p.grounded){landed=true;break;}}assert(landed&&std::abs(p.feet()-mb[1])<.05);
 // Metal arrow crate is a solid bounce surface.
 world.reset();p.reset();auto arrow=std::find_if(world.items.begin(),world.items.end(),[](const RuntimeEntity& e){return e.source.type==29;});assert(arrow!=world.items.end());auto ab=world.entityBox(*arrow);p.x=arrow->source.x;p.y=ab[1]-p.by-p.bh-5;p.vy=4;p.grounded=false;bool bounced=false;for(int i=0;i<6;i++){p.step({});world.step(p);if(p.vy<0){bounced=true;break;}}assert(bounced);
 // ROM +6 cap: repeated trigger crate awards one Wumpa per valid landing and survives until the cap.
 world.reset();p.reset();q5=std::find_if(world.items.begin(),world.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::QuestionCrateType&&e.triggerCap==5;});auto qb=world.entityBox(*q5);unsigned wc=world.wumpaCollected;
 for(unsigned hit=0;hit<4;hit++){p.x=q5->source.x;p.y=qb[1]-p.by-p.bh;p.grounded=true;p.vy=0;p.lastDownImpact=3;world.step(p);assert(q5->active&&q5->hits==hit+1&&world.wumpaCollected==wc+hit+1);}
 p.x=q5->source.x;p.y=qb[1]-p.by-p.bh;p.grounded=true;p.vy=0;p.lastDownImpact=3;world.step(p);assert(!q5->active&&q5->hits==5&&world.wumpaCollected==wc+5);
 // C crate stores a native respawn checkpoint when broken.
 world.reset();p.reset();auto checkpoint=std::find_if(world.items.begin(),world.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::CheckpointCrateType;});assert(checkpoint!=world.items.end());p.x=checkpoint->source.x;p.y=checkpoint->source.y;p.spinTicks=10;world.step(p);assert(!checkpoint->active&&world.checkpointHits==1&&p.checkpointActive&&p.checkpointX==checkpoint->source.x);
 auto savedX=p.checkpointX;p.x=10;p.y=terrain.height()+100;p.respawn();assert(p.respawns==1&&p.checkpointActive&&p.x==savedX);
 // Aku crate grants protection; first Nitro consumes it, second one respawns Crash.
 world.reset();p.reset();unsigned respawnBase=p.respawns;auto aku=std::find_if(world.items.begin(),world.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::AkuCrateType;});assert(aku!=world.items.end());p.x=aku->source.x;p.y=aku->source.y;p.spinTicks=10;world.step(p);assert(world.akuMasks==1);
 p.spinTicks=0;unsigned nx=unsigned(p.x),ny=unsigned(p.y);world.items.emplace_back(Entity{900,EntityWorld::NitroCrateType,nx,ny,0,0});auto& nitro1=world.items.back();world.step(p);assert(!nitro1.active&&world.akuMasks==0&&p.respawns==respawnBase&&world.hazardHits==1);
 nx=unsigned(p.x);ny=unsigned(p.y);world.items.emplace_back(Entity{901,EntityWorld::NitroCrateType,nx,ny,0,0});world.step(p);assert(!world.items.back().active&&p.respawns==respawnBase+1&&world.hazardHits==2);
 // TNT: spin arms a short fuse; its own ROM animation phases are available and it eventually explodes.
 p.x=500;p.y=200;p.spinTicks=10;world.items.emplace_back(Entity{902,EntityWorld::TntCrateType,500,200,0,0});size_t ti=world.items.size()-1;world.step(p);assert(world.items[ti].triggered&&world.items[ti].countdown==8);p.spinTicks=0;p.x=700;p.y=100;for(int i=0;i<8;i++)world.step(p);assert(!world.items[ti].active);
 // Type 86: first non-crate level object, rendered from bank 39 animation 5 and present in the solid set.
 auto platform=std::find_if(world.items.begin(),world.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::LevelPlatformType;});assert(platform!=world.items.end());auto pb=world.entityBox(*platform);assert(std::abs((pb[2]-pb[0])-37.0)<.01&&std::abs((pb[3]-pb[1])-15.0)<.01);
 // Level 2 contains the first verified ROM mover family: entity type 79 / bank 39 animation 1.
 auto scene2=data.scene(2);Terrain terrain2(data,scene2);Player p2(data,scene2,terrain2);EntityWorld world2(data,scene2);world2.bind(p2);
 assert(world2.moverTotal==8);assert(!world2.levelObjectClips[1].frames.empty());
 auto mover=std::find_if(world2.items.begin(),world2.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::MovingPlatformType&&e.mover.inputDistX==40;});assert(mover!=world2.items.end()&&mover->mover.enabled&&mover->mover.rangeX==80);
 double mx0=mover->x;for(int i=0;i<40;i++)world2.step(p2);assert(std::abs(mover->x-mx0)>1.0);
 // Standing on the old top carries Crash by exactly the platform delta, like sub_801B624.
 world2.reset();p2.reset();mover=std::find_if(world2.items.begin(),world2.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::MovingPlatformType&&e.mover.inputDistX==40;});auto oldBox=world2.entityBox(*mover);p2.x=mover->x;p2.y=oldBox[1]-p2.by-p2.bh;p2.grounded=true;double px0=p2.x,oldX=mover->x;world2.step(p2);assert(world2.carriedTicks==1);assert(std::abs((p2.x-px0)-(mover->x-oldX))<1e-9);
 // After enough ticks it reverses, proving the center->edge->full-range oscillation is active.
 int firstDir=mover->mover.targetVxQ8;bool reversed=false;for(int i=0;i<260;i++){world2.step(p2);if(mover->mover.targetVxQ8==-firstDir){reversed=true;break;}}assert(reversed);
 // First native enemy: entity type 40, bank 13. Five are placed in room 0; patrol range comes from the room parameter record.
 assert(world.enemyTotal==8&&world.plantTotal==3&&world.exitMarkers==1&&world.canAutoExit()&&!world.enemyClips[0].frames.empty()&&!world.enemyClips[1].frames.empty());
 world.reset();p.reset();auto enemy=std::find_if(world.items.begin(),world.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::EnemyType&&e.triggerCap==0&&e.patrolRange==40;});assert(enemy!=world.items.end());double ex0=enemy->x;p.x=31;p.y=363;for(int i=0;i<12;i++)world.step(p);assert(std::abs(enemy->x-ex0)>1.0&&enemy->active&&!enemy->dying);
 // Spin changes the enemy to its non-looping bank-13 death clip, then removes it.
 p.x=enemy->x;p.y=enemy->y;p.spinTicks=10;world.step(p);assert(enemy->dying&&world.enemyKills==1);p.spinTicks=0;p.x=31;p.y=363;for(int i=0;i<40;i++)world.step(p);assert(!enemy->active);
 // Contact without spin is hazardous and uses the existing native respawn/checkpoint path.
 world.reset();p.reset();enemy=std::find_if(world.items.begin(),world.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::EnemyType;});unsigned enemyRespawns=p.respawns;p.x=enemy->x;p.y=enemy->y;world.step(p);assert(world.hazardHits==1&&p.respawns==enemyRespawns+1);
 // Type 42 plant: the decompiled state-3 controller uses a fixed 45x20 mirrored trigger, bank-10 anim 0 idle and non-looping anim 1 attack.
 world.reset();p.reset();auto plant=std::find_if(world.items.begin(),world.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::PlantType;});assert(plant!=world.items.end()&&plant->facingLeft);
 assert(world.plantClips[0].duration==3&&world.plantClips[0].frames.size()==9&&(world.plantClips[0].flags&2));assert(world.plantClips[1].duration==3&&world.plantClips[1].frames.size()==11&&!(world.plantClips[1].flags&2));
 auto plantBody=world.entityBox(*plant),plantTrigger=world.plantTriggerBox(*plant);assert(std::abs((plantBody[2]-plantBody[0])-38.0)<.01&&std::abs((plantBody[3]-plantBody[1])-42.0)<.01);assert(std::abs((plantTrigger[2]-plantTrigger[0])-45.0)<.01&&std::abs((plantTrigger[3]-plantTrigger[1])-20.0)<.01&&plantTrigger[2]<=plant->x+.01);
 // The first-level Venus Flytrap is a normal spin-kill enemy. Bank 10 has no dedicated death clip, so a valid spin removes it immediately.
 p.x=plant->x;p.y=plant->y;p.spinTicks=10;world.step(p);assert(!plant->active&&world.enemyKills==1);
 world.reset();p.reset();plant=std::find_if(world.items.begin(),world.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::PlantType;});assert(plant!=world.items.end()&&plant->active);
 unsigned plantRespawns=p.respawns;p.x=plant->x-20;p.y=plant->y;world.step(p);assert(plant->attacking&&plant->attackTicks==0&&world.plantAttacks==1&&p.respawns==plantRespawns);auto plantHit=world.plantHitBox(*plant);assert(std::abs((plantHit[2]-plantHit[0])-94.0)<.01&&std::abs((plantHit[3]-plantHit[1])-55.0)<.01);world.step(p);assert(plant->attackDamageDone&&p.respawns==plantRespawns+1);for(int i=0;i<40;i++)world.step(p);assert(!plant->attacking&&plant->active);
 // Room route parser: preserves the original 3-entry level with its actor-category stage in the middle instead of flattening it.
 auto route3=data.roomRoute(3);assert(route3.size()==3&&route3[0].tileRoom()&&!route3[1].tileRoom()&&route3[1].kind==3&&route3[1].category==0&&route3[2].tileRoom());auto room3b=data.scene(3,2);assert(room3b.record==route3[2].record);
 auto route6=data.roomRoute(6);assert(route6.size()==1&&!route6[0].tileRoom()&&route6[0].kind==3);
 // The exit auto-arm heuristic is ROM-position based: room 0's marker is 45px from the right edge; level 2's marker is not an exit.
 auto scene1=data.scene(1);Terrain waterTerrain(data,scene1);Player swimmer(data,scene1,waterTerrain);EntityWorld world1(data,scene1);world1.bind(swimmer);assert(!world1.canAutoExit());
 // The former largest room-runtime gap: underwater entity family 0x30..0x35
 // plus Sea Mine and seaweed now use their original sprite banks and native
 // parameter records instead of silently falling through the entity loop.
 assert(world1.enemyTotal==27&&world1.aquaticSets[0].bank==5&&world1.aquaticSets[1].bank==4&&world1.aquaticSets[2].bank==3&&world1.aquaticSets[6].bank==6&&world1.seaweedSet.bank==45);
 assert(std::count_if(world1.items.begin(),world1.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::PufferfishType;})==7);
 assert(std::count_if(world1.items.begin(),world1.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::SharkType;})==8);
 assert(std::count_if(world1.items.begin(),world1.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::MorayType;})==5);
 assert(std::count_if(world1.items.begin(),world1.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::SeaMineType;})==7);
 assert(std::count_if(world1.items.begin(),world1.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::SeaweedType;})==8);
 auto waterShark=std::find_if(world1.items.begin(),world1.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::SharkType;});double sharkX=waterShark->x;for(int i=0;i<20;i++)world1.step(swimmer);assert(std::abs(waterShark->x-sharkX)>5.0);
 auto puffer=std::find_if(world1.items.begin(),world1.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::PufferfishType;});double pufferY=puffer->y;for(int i=0;i<100;i++)world1.step(swimmer);assert(std::abs(puffer->y-pufferY)>5.0);unsigned waterKills=world1.enemyKills;swimmer.x=puffer->x;swimmer.y=puffer->y;swimmer.spinTicks=10;world1.step(swimmer);assert(!puffer->active&&world1.enemyKills==waterKills+1);
 // All four regular underwater rooms now instantiate the same generic family;
 // Dingodile now uses the native boss controller in its kind-1 room.
 for(unsigned level:{8u,12u,16u}){auto ws=data.scene(level);Terrain wt(data,ws);Player wp(data,ws,wt);EntityWorld ww(data,ws);ww.bind(wp);for(int i=0;i<3;i++){wp.step({false,true,false,false,false,false});ww.step(wp);}assert(ww.enemyTotal>0);}
 assert(data.nativePlayable(data.roomRoute(20)[0]));

 // v0.34: the rest of the normal enemy controller family is no longer silently ignored.
 // All placed generic enemy/hazard types share ROM banks, spawn parameters and a common runtime dispatch.
 unsigned genericAcrossRooms=0,spawnersAcrossRooms=0;
 for(unsigned level=0;level<25;level++)for(const auto& rr:data.roomRoute(level))if(rr.tileRoom()){auto gs=data.sceneFromRoom(rr);Terrain gt(data,gs);Player gp(data,gs,gt);EntityWorld gw(data,gs);genericAcrossRooms+=gw.genericEnemyTotal;spawnersAcrossRooms+=gw.enemySpawnerTotal;}
 assert(genericAcrossRooms==225&&spawnersAcrossRooms==7);
 assert(world.genericEnemySets[0].bank==11&&world.genericEnemySets[2].bank==12&&world.genericEnemySets[4].bank==17&&world.genericEnemySets[6].bank==25&&world.genericEnemySets[9].bank==29&&world.genericEnemySets[16].bank==18);
 // Sewer room: homing enemies and rats both execute instead of falling through the main loop.
 auto sewerScene=data.scene(4);Terrain sewerTerrain(data,sewerScene);Player sewerPlayer(data,sewerScene,sewerTerrain);EntityWorld sewerWorld(data,sewerScene);sewerWorld.bind(sewerPlayer);assert(sewerWorld.genericEnemyTotal==13);
 assert(std::count_if(sewerWorld.items.begin(),sewerWorld.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::HomingSewerType;})==7);
 assert(std::count_if(sewerWorld.items.begin(),sewerWorld.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::RatType;})==6);
 auto homing=std::find_if(sewerWorld.items.begin(),sewerWorld.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::HomingSewerType;});assert(homing!=sewerWorld.items.end());double homingX=homing->x;sewerPlayer.x=homing->x+80;sewerPlayer.y=homing->y-80;for(int i=0;i<20;i++)sewerWorld.step(sewerPlayer);assert(homing->x>homingX);
 // Space room: stationary shooters, laser barriers and saucers use their real banks; laser/crusher hazards are spin-invulnerable.
 auto spaceScene=data.scene(11);Terrain spaceTerrain(data,spaceScene);Player spacePlayer(data,spaceScene,spaceTerrain);EntityWorld spaceWorld(data,spaceScene);spaceWorld.bind(spacePlayer);assert(spaceWorld.genericEnemyTotal==29);
 auto laser=std::find_if(spaceWorld.items.begin(),spaceWorld.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::LaserBarrierType;});assert(laser!=spaceWorld.items.end());spacePlayer.x=laser->x;spacePlayer.y=laser->y;spacePlayer.spinTicks=10;spaceWorld.step(spacePlayer);assert(laser->active);
 // Killable shared-controller enemies do count normally.
 auto rat=std::find_if(sewerWorld.items.begin(),sewerWorld.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::RatType&&e.active;});assert(rat!=sewerWorld.items.end());unsigned genericKills=sewerWorld.enemyKills;sewerPlayer.x=rat->x;sewerPlayer.y=rat->y;sewerPlayer.spinTicks=10;sewerWorld.step(sewerPlayer);assert(!rat->active&&sewerWorld.enemyKills==genericKills+1);
 // Ice-room periodic spawner creates the original bank-17 seal on the 0x78-frame cadence.
 auto iceScene=data.scene(3);Terrain iceTerrain(data,iceScene);Player icePlayer(data,iceScene,iceTerrain);EntityWorld iceWorld(data,iceScene);auto sealSpawner=std::find_if(iceWorld.items.begin(),iceWorld.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::SealSpawnerType;});assert(sealSpawner!=iceWorld.items.end()&&iceWorld.enemySpawnerTotal==1);for(int i=0;i<120;i++){icePlayer.x=sealSpawner->x;icePlayer.y=sealSpawner->y-80;icePlayer.spinTicks=0;iceWorld.step(icePlayer);}assert(iceWorld.spawnedEnemies.size()==1&&iceWorld.spawnedEnemies.front().source.type==EntityWorld::SealRuntimeType&&iceWorld.genericEnemySets[4].bank==17);
 // v0.35: enemy child effects are independent runtime objects, matching LaunchEffectPart semantics.
 // Blowgun (state 16 / UpdateEnemyShooter) fires bank 12 anim 6 at Q8 speed 0x400 = 4 px/frame.
 auto blowScene=data.scene(13);Terrain blowTerrain(data,blowScene);Player blowPlayer(data,blowScene,blowTerrain);EntityWorld blowWorld(data,blowScene);blowWorld.bind(blowPlayer);
 auto blowgun=std::find_if(blowWorld.items.begin(),blowWorld.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::BlowgunType;});assert(blowgun!=blowWorld.items.end());
 for(auto& e:blowWorld.items)if(&e!=&*blowgun&&(EntityWorld::isGenericEnemy(e.source.type)||EntityWorld::isAquaticEnemy(e.source.type)||e.source.type==EntityWorld::EnemyType||e.source.type==EntityWorld::PlantType))e.active=false;
 blowPlayer.x=blowgun->x+200;blowPlayer.y=blowgun->y-80;for(int i=0;i<1000&&blowWorld.enemyChildEffectsSpawned==0;i++)blowWorld.step(blowPlayer);
 assert(blowWorld.enemyChildEffectsSpawned>0&&!blowWorld.childEffects.empty());auto dart=blowWorld.childEffects.front();assert(dart.bank==12&&dart.animation==6&&std::abs(std::abs(dart.vx)-4.0)<.001&&dart.maxTicks==240);
 unsigned childHits=blowWorld.enemyChildEffectHits;blowPlayer.x=dart.x+dart.vx;blowPlayer.y=dart.y;blowPlayer.spinTicks=0;blowWorld.step(blowPlayer);assert(blowWorld.enemyChildEffectHits==childHits+1&&blowWorld.childEffects.empty());
 // Flamethrower (kind 0x17) emits bank 23 anim 4 on animation frame 9; it is a 24-tick non-looping child flame.
 auto flameScene=data.scene(7);Terrain flameTerrain(data,flameScene);Player flamePlayer(data,flameScene,flameTerrain);EntityWorld flameWorld(data,flameScene);flameWorld.bind(flamePlayer);
 auto flame=std::find_if(flameWorld.items.begin(),flameWorld.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::FlamethrowerType;});assert(flame!=flameWorld.items.end());
 for(auto& e:flameWorld.items)if(&e!=&*flame&&(EntityWorld::isGenericEnemy(e.source.type)||EntityWorld::isAquaticEnemy(e.source.type)||e.source.type==EntityWorld::EnemyType||e.source.type==EntityWorld::PlantType))e.active=false;
 flamePlayer.x=flame->x+200;flamePlayer.y=flame->y-80;for(int i=0;i<1000&&flameWorld.enemyChildEffectsSpawned==0;i++)flameWorld.step(flamePlayer);
 assert(flameWorld.enemyChildEffectsSpawned>0&&!flameWorld.childEffects.empty());const auto flameFx=flameWorld.childEffects.front();assert(flameFx.bank==23&&flameFx.animation==4&&std::abs(flameFx.vx)<.001&&flameFx.maxTicks==24);

 // Type 85 is the room-end marker. Reaching its 100x100 sensor requests the normal transition.
 world.reset();p.reset();auto exit=std::find_if(world.items.begin(),world.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::ExitMarkerType;});assert(exit!=world.items.end());p.x=exit->x;p.y=exit->y;world.step(p);assert(!world.levelExitTriggered);world.armExitMarker();world.step(p);assert(world.levelExitTriggered);
 // Mover kind 5: once Crash lands, its 60-tick timer continues even after he leaves; then gravity target becomes 4 px/tick with 40/256 acceleration. No main USA room places one directly, so this exercises the generic native implementation.
 world2.reset();p2.reset();RuntimeEntity synthetic(Entity{990,EntityWorld::MovingPlatformType,500,200,0,0});synthetic.mover.enabled=true;synthetic.mover.kind=5;synthetic.mover.xQ8=500<<8;synthetic.mover.yQ8=200<<8;world2.items.push_back(synthetic);auto& drop=world2.items.back();auto db=world2.entityBox(drop);p2.x=drop.x;p2.y=db[1]-p2.by-p2.bh;p2.grounded=true;world2.step(p2);assert(drop.mover.specialTimer==1);p2.x=20;p2.y=20;p2.grounded=false;for(int i=0;i<59;i++)world2.step(p2);assert(drop.mover.falling&&drop.mover.vyQ8>0&&drop.mover.vyQ8<=1024);
 // Entity type 87 is original mover kind 6: it holds its frame for 120 ticks, plays the 33-frame clip, then rearms another 120-tick hold.
 auto scene11=data.scene(11);Terrain terrain11(data,scene11);Player p11(data,scene11,terrain11);EntityWorld world11(data,scene11);world11.bind(p11);assert(std::count_if(world11.items.begin(),world11.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::TimedPlatformType;})==10);auto timed=std::find_if(world11.items.begin(),world11.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::TimedPlatformType;});assert(timed!=world11.items.end()&&timed->mover.kind==6&&timed->mover.holdUntil==120);for(int i=0;i<286;i++)world11.step(p11);assert(timed->mover.holdUntil>285);
 // Entity type 88 is original mover kind 7: dormant until activated, then its non-looping clip removes the platform.
 auto scene22=data.scene(22);Terrain terrain22(data,scene22);Player p22(data,scene22,terrain22);EntityWorld world22(data,scene22);world22.bind(p22);assert(std::count_if(world22.items.begin(),world22.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::FallingPlatformType;})==5);auto falling=std::find_if(world22.items.begin(),world22.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::FallingPlatformType;});assert(falling!=world22.items.end()&&falling->mover.kind==7&&!falling->mover.active);falling->mover.active=true;falling->stateTicks=0;for(int i=0;i<60&&falling->active;i++)world22.step(p22);assert(!falling->active);
 // Reset + HUD/render path.
 world.reset();p.reset();assert(world.wumpaCollected==0&&world.gemsCollected==0&&world.crateBroken==0&&world.enemyKills==0&&!world.levelExitTriggered&&std::count_if(world.items.begin(),world.items.begin()+79,[](const RuntimeEntity& e){return e.active;})==78);
 // Dingodile: original bank-54 controller, rocket -> stalactite vulnerability loop, three spin hits and room exit.
 auto dScene=data.scene(20);assert(dScene.kind==1);Terrain dTerrain(data,dScene);Player diverBoss(data,dScene,dTerrain);EntityWorld dWorld(data,dScene);dWorld.bind(diverBoss);
 assert(dWorld.dingodileTotal==1&&dWorld.dingodileSet.bank==54&&dWorld.dingodileSet.clips.size()==10&&data.nativePlayable(data.roomRoute(20)[0]));
 auto dingBoss=std::find_if(dWorld.items.begin(),dWorld.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::DingodileType;});assert(dingBoss!=dWorld.items.end());
 dWorld.step(diverBoss);assert(dingBoss->dingodile.state==1&&dingBoss->dingodile.animation==0);
 diverBoss.placeAt(30,30);dingBoss->dingodile.state=6;dingBoss->dingodile.animation=4;dingBoss->dingodile.animationTicks=39;dingBoss->childSpawned=false;dWorld.step(diverBoss);
 auto rocket=std::find_if(dWorld.childEffects.begin(),dWorld.childEffects.end(),[](const EnemyChildEffect& f){return f.kind==EnemyChildEffect::DingodileRocket;});assert(rocket!=dWorld.childEffects.end()&&rocket->bank==54&&rocket->animation==7);
 rocket->y=8;dWorld.step(diverBoss);auto stal=std::find_if(dWorld.childEffects.begin(),dWorld.childEffects.end(),[](const EnemyChildEffect& f){return f.kind==EnemyChildEffect::DingodileStalactite;});assert(stal!=dWorld.childEffects.end()&&stal->animation==9);
 dingBoss->dingodile.stalactiteVulnerable=true;stal->x=dingBoss->x;stal->y=dingBoss->y;dWorld.step(diverBoss);assert(dingBoss->dingodile.state==7);dWorld.step(diverBoss);assert(dingBoss->dingodile.state==8&&dingBoss->dingodile.timer<=0xD2);
 for(unsigned hit=1;hit<=3;hit++){dingBoss->dingodile.state=8;dingBoss->dingodile.timer=0xD2;diverBoss.placeAt(dingBoss->x,dingBoss->y);diverBoss.spinTicks=10;dWorld.step(diverBoss);assert(dingBoss->dingodile.hits==hit&&dWorld.dingodileHits==hit&&dingBoss->dingodile.state==11);}
 diverBoss.spinTicks=0;diverBoss.placeAt(20,20);dWorld.step(diverBoss);assert(dingBoss->dingodile.state==16);dingBoss->y=dTerrain.height()+33;dWorld.step(diverBoss);assert(dingBoss->dingodile.complete&&dWorld.levelExitTriggered&&dWorld.enemyKills==1);
 // Tiny Tiger: original bank-55 16-state hopping boss with five rock anchors,
 // three rounds, falling leaves, stomped pads and the Tornado Spin reward.
 auto tScene=data.scene(22);Terrain tTerrain(data,tScene);Player tinyPlayer(data,tScene,tTerrain);EntityWorld tWorld(data,tScene);tWorld.bind(tinyPlayer);
 assert(tWorld.tinyTotal==1&&tWorld.tinySet.bank==55&&tWorld.tinySet.clips.size()==9&&tWorld.powerSet.bank==38);
 assert(std::count_if(tWorld.items.begin(),tWorld.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::FallingPlatformType;})==5);
 auto tinyBoss=std::find_if(tWorld.items.begin(),tWorld.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::TinyType;});assert(tinyBoss!=tWorld.items.end());
 tinyPlayer.placeAt(20,20);tWorld.step(tinyPlayer);assert(tinyBoss->tiny.state==1&&tinyBoss->tiny.animation==2&&tinyBoss->tiny.steps==26);
 // State 13 emits bank-55 animation 5 leaves at the original 0.5 px/frame fall speed.
 tinyBoss->tiny.state=13;tinyBoss->tiny.timer=4;tinyBoss->tiny.nextState=0;tinyPlayer.placeAt(20,20);tWorld.step(tinyPlayer);
 auto leaf=std::find_if(tWorld.childEffects.begin(),tWorld.childEffects.end(),[](const EnemyChildEffect& f){return f.kind==EnemyChildEffect::TinyLeaf;});assert(leaf!=tWorld.childEffects.end()&&leaf->bank==55&&leaf->animation==5&&std::abs(leaf->vy-.5)<.001);
 // Round one marks anchor 4; on the following Tiny update that pad enters the
 // stomped controller and then sinks by exactly 4 px/frame.
 tWorld.childEffects.clear();tinyBoss->tiny.state=12;tinyBoss->tiny.round=1;tinyBoss->tiny.stomped=-1;tWorld.step(tinyPlayer);assert(tinyBoss->tiny.stomped==4&&tinyBoss->tiny.state==3);
 RuntimeEntity* stomped=nullptr;unsigned rockIndex=0;for(auto& e:tWorld.items)if(e.source.type==EntityWorld::FallingPlatformType){if(rockIndex++==4){stomped=&e;break;}}assert(stomped);const double stompY=stomped->y;tWorld.step(tinyPlayer);assert(stomped->mover.falling&&stomped->active);tWorld.step(tinyPlayer);assert(std::abs(stomped->y-(stompY+4.0))<.001);
 // Fresh fight: three spin hits advance the three rounds. The last hit spawns
 // the bank-38 Tornado Spin power; Tiny completes only after his two 26-frame
 // escape arcs, and collecting the power opens the room exit.
 EntityWorld tinyFight(data,tScene);Player tinyFighter(data,tScene,tTerrain);tinyFight.bind(tinyFighter);auto tf=std::find_if(tinyFight.items.begin(),tinyFight.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::TinyType;});assert(tf!=tinyFight.items.end());
 for(unsigned hit=1;hit<=3;hit++){tf->tiny.state=8;tf->tiny.animation=6;tf->tiny.animationTicks=0;tf->tiny.timer=0xB4;tinyFighter.placeAt(tf->x,tf->y);tinyFighter.spinTicks=10;tinyFight.step(tinyFighter);assert(tf->tiny.round==hit&&tinyFight.tinyHits==hit);if(hit<3)assert(tf->tiny.state==9);}
 assert(tf->tiny.state==14&&tf->tiny.rewardSpawned);auto reward=std::find_if(tinyFight.childEffects.begin(),tinyFight.childEffects.end(),[](const EnemyChildEffect& f){return f.kind==EnemyChildEffect::TinyReward;});assert(reward!=tinyFight.childEffects.end()&&reward->bank==38&&reward->animation==0);
 tinyFighter.spinTicks=0;tinyFighter.placeAt(20,20);for(int i=0;i<60&&!tf->tiny.complete;i++)tinyFight.step(tinyFighter);assert(tf->tiny.complete&&tf->tiny.state==16&&tinyFight.enemyKills==1&&!tinyFight.levelExitTriggered);
 reward=std::find_if(tinyFight.childEffects.begin(),tinyFight.childEffects.end(),[](const EnemyChildEffect& f){return f.kind==EnemyChildEffect::TinyReward;});assert(reward!=tinyFight.childEffects.end());tinyFighter.placeAt(reward->x,reward->y);tinyFight.step(tinyFighter);assert(tf->tiny.rewardCollected&&tinyFight.levelExitTriggered&&tinyFighter.hasTornadoSpin());
 // Neo Cortex: bank-53 cannon/target controller, three boss gems, flip-platform phase and Turbo Run reward.
 auto cScene=data.scene(23);Terrain cTerrain(data,cScene);Player cortexPlayer(data,cScene,cTerrain);EntityWorld cWorld(data,cScene);cWorld.bind(cortexPlayer);
 assert(cWorld.cortexArena&&cWorld.cortexTotal==1&&cWorld.cortexGemTotal==3&&cWorld.cortexSet.bank==53&&cWorld.cortexSet.clips.size()==19&&cWorld.cortexGemSet.bank==32&&data.nativePlayable(data.roomRoute(23)[0]));
 assert(std::count_if(cWorld.items.begin(),cWorld.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::TimedPlatformType;})==3);for(const auto& e:cWorld.items)if(e.source.type==EntityWorld::TimedPlatformType)assert(e.controllerTicks==26&&e.mover.kind==106);
 auto cortexBoss=std::find_if(cWorld.items.begin(),cWorld.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::CortexType;});assert(cortexBoss!=cWorld.items.end());cortexPlayer.x=-100;cortexPlayer.y=-100;cWorld.step(cortexPlayer);assert(cortexBoss->cortex.state==1&&cortexBoss->cortex.childrenSpawned&&cortexBoss->cortex.targetState==1);
 bool opened=false;for(int i=0;i<900&&!opened;i++){cWorld.step(cortexPlayer);opened=std::any_of(cWorld.items.begin(),cWorld.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::TimedPlatformType&&e.controllerMode==1;});}assert(opened);
 const unsigned gemTypes[3]={0x0A,0x0B,0x0C};for(unsigned hit=0;hit<3;hit++){auto cg=std::find_if(cWorld.items.begin(),cWorld.items.end(),[&](const RuntimeEntity& e){return e.source.type==gemTypes[hit];});assert(cg!=cWorld.items.end()&&cg->active);cortexBoss->cortex.targetState=5;cortexBoss->cortex.targetTimer=1;cortexBoss->cortex.targetSteps=0;cortexBoss->cortex.targetX=cg->x;cortexBoss->cortex.targetY=cg->y;cWorld.step(cortexPlayer);assert(cg->controllerMode==1&&cortexBoss->cortex.counter==hit+1&&cWorld.cortexHits==hit+1);}
 assert(cortexBoss->cortex.state==3&&cortexBoss->cortex.rewardSpawned);auto turbo=std::find_if(cWorld.childEffects.begin(),cWorld.childEffects.end(),[](const EnemyChildEffect& f){return f.kind==EnemyChildEffect::CortexReward;});assert(turbo!=cWorld.childEffects.end()&&turbo->bank==38&&turbo->animation==3&&std::abs(turbo->x-140.0)<.01&&std::abs(turbo->y-152.0)<.01);
 cortexBoss->y=cWorld.worldHeight+64.0;cWorld.step(cortexPlayer);assert(cortexBoss->cortex.complete&&cortexBoss->cortex.state==4&&cWorld.enemyKills==1&&!cWorld.levelExitTriggered);turbo=std::find_if(cWorld.childEffects.begin(),cWorld.childEffects.end(),[](const EnemyChildEffect& f){return f.kind==EnemyChildEffect::CortexReward;});assert(turbo!=cWorld.childEffects.end());cortexPlayer.placeAt(turbo->x,turbo->y);cWorld.step(cortexPlayer);assert(cortexBoss->cortex.rewardCollected&&cWorld.levelExitTriggered&&cortexPlayer.hasTurboRun());
 // Mega-Mix: bank-30 chase controller. He accelerates after Crash, crushes nearby crates, grabs in the original 0x27FF/0x31FF range and cannot be killed by spin.
 auto mScene=data.scene(24);Terrain mTerrain(data,mScene);Player mPlayer(data,mScene,mTerrain);EntityWorld mWorld(data,mScene);mWorld.bind(mPlayer);assert(mWorld.megaMixArena&&mWorld.megaMixTotal==1&&mWorld.megaMixSet.bank==30&&mWorld.megaMixSet.clips.size()==3&&mWorld.canAutoExit()&&data.nativePlayable(data.roomRoute(24)[0]));
 auto mega=std::find_if(mWorld.items.begin(),mWorld.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::MegaMixType;});assert(mega!=mWorld.items.end()&&mega->megaMix.state==1&&mega->megaMix.stamp==-1&&!mega->facingLeft);const double megaStart=mega->x;mPlayer.placeAt(mega->x+220,mega->y);for(int i=0;i<30;i++)mWorld.step(mPlayer);assert(mega->x>megaStart&&mega->megaMix.targetVxQ8==450&&mega->active);
 auto smash=std::find_if(mWorld.items.begin(),mWorld.items.end(),[](const RuntimeEntity& e){return e.source.type==21;});assert(smash!=mWorld.items.end());smash->x=mega->x+20;smash->y=mega->y;const unsigned brokenBefore=mWorld.crateBroken;mWorld.step(mPlayer);assert(!smash->active&&mWorld.crateBroken==brokenBefore+1&&mWorld.megaMixCratesDestroyed>=1);
 // Spin does not damage the chase boss. Entering the grab range switches to animation 1; frame 8 delivers player event 1 (native damage/death abstraction).
 mPlayer.placeAt(mega->x+20,mega->y);mPlayer.spinTicks=10;const unsigned killsBefore=mWorld.enemyKills;mWorld.step(mPlayer);assert(mega->active&&mWorld.enemyKills==killsBefore&&mega->megaMix.state==2&&mega->megaMix.animation==1);mPlayer.spinTicks=0;const unsigned respawnsBefore=mPlayer.respawns;for(int i=0;i<12&&mWorld.megaMixGrabs==0;i++)mWorld.step(mPlayer);assert(mWorld.megaMixGrabs==1&&mPlayer.respawns==respawnsBefore+1);for(int i=0;i<20&&mega->megaMix.state==2;i++)mWorld.step(mPlayer);assert(mega->megaMix.state==1&&mega->megaMix.animation==0);
 // The real Mega-Mix exit marker is at x=7275, well before the 8000px room edge; the boss arena explicitly arms it so the chase is completable.
 auto megaExit=std::find_if(mWorld.items.begin(),mWorld.items.end(),[](const RuntimeEntity& e){return e.source.type==EntityWorld::ExitMarkerType;});assert(megaExit!=mWorld.items.end()&&megaExit->x==7275);mWorld.armExitMarker(mWorld.canAutoExit());mPlayer.placeAt(megaExit->x,megaExit->y);mWorld.step(mPlayer);assert(mWorld.levelExitTriggered);
 std::vector<uint32_t> canvas(240*160,0xff101018);int camX=0,camY=250;world.renderLogical(canvas,240,160,camX,camY,true);assert(std::any_of(canvas.begin(),canvas.end(),[](uint32_t v){return v!=0xff101018;}));
 std::cout<<"Entity checks passed: room 0 + crate stacks + Super Body Slam shockwave + underwater core + generic enemy controller family + native Dingodile/Tiny/Cortex/Mega-Mix bosses + power rewards + native movers/routes.\n";return 0;
 }catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
