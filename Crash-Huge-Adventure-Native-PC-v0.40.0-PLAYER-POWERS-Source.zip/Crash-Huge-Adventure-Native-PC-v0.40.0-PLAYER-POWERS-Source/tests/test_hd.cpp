#include "../src/hd_assets.hpp"
#include <cassert>
#include <iostream>
namespace fs=std::filesystem;
int main(){try{
 crash::GameData data(crash::read("input/crash.gba"));auto scene=data.scene();crash::Terrain terrain(data,scene);crash::Player p(data,scene,terrain);crash::ExternalSprites external;
 external.load(data,"assets/overrides");assert(external.errors.empty()&&external.sprites.size()==55&&external.textureBytes>0);
 unsigned comparisons=0;for(unsigned anim:{18u,13u,31u,16u}){const auto& a=data.banks[0].animations[anim];for(size_t i=0;i<a.sequence.size();i++)for(bool mirrored:{false,true})for(int scale:{1,4,6}){
  p.animation=anim;p.animationTicks=unsigned(i*std::max(1u,a.duration));p.facingLeft=mirrored;
  auto original=p.render(data,scene);auto hd=crash::renderHD(data,scene,p,external,scale);auto fallback=crash::renderHD(data,scene,p,external,scale,false);
  assert(hd==fallback);for(int y=0;y<160*scale;y++)for(int x=0;x<240*scale;x++)assert(hd[size_t(y*240*scale+x)]==original[size_t(y/scale*240+x/scale)]);++comparisons;
 }}
 auto detail=std::make_shared<crash::Image>(crash::loadPNG("tests/fixtures/detail.png"));assert(detail->width==2&&detail->height==2&&detail->pixels[2]==0x800000ff);
 crash::Replacement r{detail,0,0,2,2,0,0,1,1};std::vector<uint32_t> canvas(64,0xff000000);crash::drawReplacement(canvas,8,8,r,4,0,0,false);
 assert(canvas[0]==0xffff0000&&canvas[3]==0xff00ff00&&canvas[24]==0xff000080&&canvas[27]==0xff000000);
 std::fill(canvas.begin(),canvas.end(),0xff000000);crash::drawReplacement(canvas,8,8,r,4,4,0,true);assert(canvas[0]==0xff00ff00&&canvas[3]==0xffff0000);
 assert(crash::blend(0x8000ff00,0xff0000ff)==0xff00807f);
 bool rejected=false;try{crash::loadPNG("tests/fixtures/broken.png");}catch(const std::exception&){rejected=true;}assert(rejected);
 fs::path temp=fs::temp_directory_path()/"crash-native-hd-test";fs::create_directories(temp);fs::copy_file("tests/fixtures/detail.png",temp/"detail.png",fs::copy_options::overwrite_existing);
 auto& a=data.banks[0].animations[18];unsigned index=a.sequence[0];auto row=[&](const std::string& file,int sw=2){return "0,"+std::to_string(index)+","+std::to_string(a.paletteRecord)+","+file+",0,0,"+std::to_string(sw)+",2,0,0,1,1\n";};
 {std::ofstream f(temp/"manifest.csv");f<<row("detail.png");}
 external.load(data,temp);assert(external.sprites.size()==1&&external.errors.empty());p.reset();auto fine=crash::renderHD(data,scene,p,external,4);auto cam=p.camera();int ax=(int(std::lround(p.x))-cam.first)*4,ay=(int(std::lround(p.y))-cam.second)*4;
 assert(fine[size_t(ay*960+ax)]==0xffff0000&&fine[size_t(ay*960+ax+3)]==0xff00ff00);
 {std::ofstream f(temp/"manifest.csv");f<<row("missing.png")<<row("detail.png",999)<<row("../detail.png")<<"bad,row\n";}
 external.load(data,temp);assert(external.sprites.empty()&&external.errors.size()==4);assert(crash::renderHD(data,scene,p,external,1)==p.render(data,scene));
 // Reload replaces cached image data without changing the player state.
 auto x=p.x,y=p.y;{std::ofstream f(temp/"manifest.csv");f<<row("detail.png");}external.load(data,temp);assert(external.sprites.size()==1&&p.x==x&&p.y==y);
 {std::ofstream f(temp/"detail.png",std::ios::binary);f<<"broken";}external.load(data,temp);assert(external.sprites.empty()&&!external.errors.empty());
 {std::ofstream f(temp/"display.ini");f<<"render_scale=6\nexternal_sprites=0\n";}auto display=crash::settings(temp/"display.ini");assert(display.scale==6&&!display.external);
 {std::ofstream f(temp/"display.ini");f<<"render_scale=9999\nexternal_sprites=banana\n";}display=crash::settings(temp/"display.ini");assert(display.scale==4&&display.external);
 fs::remove_all(temp);external.load(data,"assets/overrides");p.reset();for(int i=0;i<100;i++)p.step({false,true,i>=65&&i<84});
 crash::bmp("reports/native-hd-960.bmp",crash::renderHD(data,scene,p,external,4),960,640);crash::bmp("reports/native-hd-1440.bmp",crash::renderHD(data,scene,p,external,6),1440,960);
 std::cout<<comparisons<<" frame/scale/mirror comparisons passed; fine PNG detail, crop, alpha, fallback, malformed input, reload and settings passed.\n";return 0;
 }catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
