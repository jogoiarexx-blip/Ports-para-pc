#include "../src/player.hpp"
#include <iostream>
#include <cassert>
int main(){try{
 crash::GameData data(crash::read("input/crash.gba"));auto scene=data.scene();crash::Terrain t(data,scene);crash::Player p(data,scene,t);
 assert(p.bx==-7&&p.by==-27&&p.bw==14&&p.bh==41);
 assert(p.startX==31&&p.startY==363);
 assert(p.grounded&&p.feet()==376);
 for(int i=0;i<120;i++)p.step({});
 assert(p.grounded&&p.feet()==376&&p.x==31);
 // Native spin state uses the ROM's animation 16 and exposes a wider attack box.
 p.step({false,false,false,true});assert(p.spinning()&&p.animation==16&&p.spinTicks==24);auto attack=p.attackBox();auto body=p.bodyBox();assert(attack[0]<body[0]&&attack[2]>body[2]);
 for(int i=0;i<23;i++){p.step({});}
 assert(p.spinning()&&p.animation==16);p.step({});assert(!p.spinning()&&p.animation==18);
 double floor=p.feet();p.step({false,false,true});
 assert(!p.grounded&&p.vy<0);double apex=p.y;
 for(int i=0;i<120;i++){p.step({false,false,true});apex=std::min(apex,p.y);}assert(p.grounded&&p.feet()==floor&&p.y-apex>60);
 p.step({});p.step({false,false,true});p.step({});
 assert(p.vy>=-2.8);for(int i=0;i<120;i++)p.step({});
 assert(p.grounded);

 // ROM-derived terrestrial action layer: R crouch/slide/body-slam, permanent
 // double-jump/tornado/turbo upgrades and their animation/state transitions.
 p.reset();p.step({false,false,false,false,false,false,true,false});assert(p.crouching&&p.animation==4&&!p.sliding());
 p.step({false,true,false,false,false,false,true,false});assert(p.crouching&&p.animation==20&&p.vx>0); // crawl while R+direction is held
 p.reset();p.step({false,true,false,false,false,false,true,false});assert(p.sliding()&&p.animation==15&&p.vx>4.0); // direction+R can start slide immediately
 p.step({false,true,true,false,false,false,true,false});assert(!p.grounded&&p.vy<-6.4&&!p.sliding()); // slide/high jump
 for(int i=0;i<120&&!p.grounded;i++)p.step({});
 p.reset();p.step({false,false,false,false,false,true,false,false});assert(p.crouching&&p.animation==4); // Down mirrors R on foot
 p.reset();p.grantPower(crash::Player::DoubleJumpPower);p.step({false,false,true});p.step({});p.step({false,false,true});assert(p.doubleJumpUsed&&p.vy<0&&p.animation==6);
 p.reset();p.grantPower(crash::Player::TornadoSpinPower);p.step({false,false,false,true});p.step({});p.step({false,false,false,true});assert(p.tornadoCharge==1&&p.spinTicks>24&&p.animation==23);
 p.reset();p.grantPower(crash::Player::TurboRunPower);for(int i=0;i<30;i++)p.step({false,true,false,false,false,false,false,true});assert(p.vx>3.5&&p.animation==24);
 p.reset();p.grantPower(crash::Player::SuperBodySlamPower);p.step({false,false,true});for(int i=0;i<4;i++)p.step({false,false,true});p.step({false,false,true,false,false,false,true,false});assert(p.bodySlamming&&p.vy>0);for(int i=0;i<120&&!p.grounded;i++)p.step({});assert(p.grounded&&p.superSlamImpact());
 // Real ROM slope traversal, both directions; assert contact and no respawn.
 p.reset();for(int i=0;i<280;i++)p.step({false,true,false});
 assert(p.x>750&&p.respawns==0&&p.grounded);
 assert(p.feet()<376);
 crash::bmp("reports/native-gameplay-preview.bmp",p.render(data,scene),240,160);
 for(int i=0;i<280;i++)p.step({true,false,false});
 assert(p.x<70&&p.grounded&&p.respawns==0);
 // Opposing directions stop rather than arbitrarily selecting a direction.
 for(int i=0;i<30;i++)p.step({true,true,false});
 assert(std::abs(p.vx)<.001);
 p.y=t.height()+90;p.step({});
 assert(p.respawns==1&&p.grounded&&p.x==p.startX);
 // Synthetic obstacle, ceiling, pit and high-speed thin-floor sweep on original profiles.
 auto custom=scene;auto& l=*std::find_if(custom.layers.begin(),custom.layers.end(),[](const auto& a){return a.slot==4;});std::fill(l.cells.begin(),l.cells.end(),0);
 for(unsigned xx=0;xx<l.wt;xx++)l.cells[47*l.gw*16+xx]=43;
 for(int yy=37;yy<47;yy++)l.cells[size_t(yy*l.gw*16+12)]=43;
 crash::Terrain wall(data,custom);crash::Player q(data,custom,wall);for(int i=0;i<100;i++)q.step({false,true,false});
 assert(q.x+q.bx+q.bw<=96.01&&q.grounded);
 // Ceiling at row 40: upward collision must end jump before crossing the tile.
 for(int xx=0;xx<10;xx++)l.cells[size_t(40*l.gw*16+xx)]=43;
 q.reset();q.step({false,false,true});for(int i=0;i<12;i++)q.step({false,false,true});
 assert(q.y+q.by>=328&&q.vy>=0);
 std::fill(l.cells.begin(),l.cells.end(),0);for(unsigned xx=0;xx<l.wt;xx++)l.cells[47*l.gw*16+xx]=43;
 q.reset();q.y=300;q.grounded=false;q.vy=8;for(int i=0;i<20;i++)q.step({});
 assert(q.grounded&&q.feet()==376);
 for(unsigned xx=0;xx<l.wt;xx++)l.cells[47*l.gw*16+xx]=0;
 q.reset();for(int i=0;i<100;i++)q.step({});
 assert(q.respawns>0);
 // ROM directional side masks and slopes are interpreted, not treated as full squares.
 assert(t.solid(32,376,0));
 assert(!crash::Terrain::enabled(0x302b,1));
 assert(!crash::Terrain::enabled(0x302b,3));
 assert(crash::Terrain::enabled(0x302b,0));
 assert(!crash::Terrain::enabled(0x402b,0));
 // Room kind 1 uses the original scuba Crash bank/start record and a separate
 // no-gravity 8-way controller instead of forcing the terrestrial physics.
 auto underwaterScene=data.scene(1);assert(underwaterScene.kind==1);crash::Terrain waterTerrain(data,underwaterScene);crash::Player diver(data,underwaterScene,waterTerrain);
 assert(diver.underwater()&&diver.spriteBank==1&&diver.startX==124&&diver.startY==101);assert(diver.bx==-5&&diver.by==-7&&diver.bw==18&&diver.bh==20&&!diver.grounded&&diver.animation==31);
 double ux=diver.x,uy=diver.y;for(int i=0;i<60;i++)diver.step({false,true,false,false,false,false});assert(diver.x>ux+40&&std::abs(diver.y-uy)<.01&&diver.animation==23);
 diver.step({false,false,true,false,false,false});assert(diver.strokeTicks==16&&diver.vx>2.6&&diver.animation==24);for(int i=0;i<20;i++)diver.step({});diver.step({false,false,false,true,true,false});assert(diver.spinning()&&diver.vy<-3.5&&diver.animation==39&&diver.tilt==0);
 auto waterRoute=data.roomRoute(1),bossWaterRoute=data.roomRoute(20);assert(data.nativePlayable(waterRoute[0])&&data.nativePlayable(bossWaterRoute[0]));
 std::cout<<"Player checks passed: terrestrial physics + ROM-derived crouch/slide/body-slam + permanent powers + native kind-1 underwater bank/start, 8-way swim, stroke/spin and route coverage including the Dingodile room.\n";return 0;
 }catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
