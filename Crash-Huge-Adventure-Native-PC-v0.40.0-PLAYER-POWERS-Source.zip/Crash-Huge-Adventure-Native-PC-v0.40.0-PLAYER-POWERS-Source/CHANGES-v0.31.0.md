# Crash Native PC v0.31.0 — ActorCategory retry / bonus semantics

A v0.31 corrige a semântica estrutural do descriptor das ActorCategories e liga os thresholds de morte/retry ao runtime.

## Corrigido

- campos `+0x20..+0x30` identificados e usados como `maskAssistDeaths`, `bonusKindDeaths`, `retryBossDeaths`, `bossLevel`, `retryBossLevel`;
- normal usa `kind`, Time Trial usa `altKind`, bonus retry usa `bonusKind`;
- removida a interpretação errada de `bossLevel` como seletor de `variantC`;
- removido fold inventado `23 -> 20` no Polar Time Trial;
- seleção de kind fica cached por evento e waypoints do Plane usam o mesmo kind selecionado;
- retry reconstrói eventos posteriores ao checkpoint e mantém contadores de morte normais/boss separados.

## Assist / bosses

- Jetpack passa a 120 HP máximo ao atingir `maskAssistDeaths`;
- ring heal e health crate curam 20% do HP máximo (20 ou 24);
- Airship recebe os seis registros da tabela original, incluindo os três profiles de retry;
- Hovercraft passa ao profile 1 no retry: side guns HP16 e timings alternativos.

## Validação

- 8/8 suítes strict PASS;
- `make -B all` PASS com C++17, `-Wall -Wextra -Wpedantic -Werror`;
- TestCategory, TestFrontend e TestAudio: ASan + UBSan PASS;
- novos testes cobrem divergência real normal/bonus/time-trial, thresholds, HP assist, Airship retry e Hovercraft retry.
