# v0.23.0 — ARM integer mixer, ambient Jetpack shot e Airship bursts

## Áudio GAX2

- O caminho de mixagem deixou de normalizar cada voz em `double` antes da soma.
- O replayer agora segue o comportamento observado no `gGaxArmResample` original:
  - sample PCM signed 8-bit;
  - posição Q11 / nearest-neighbor (o ARM original não interpola);
  - volume em Q8 com arithmetic shift;
  - acumulação por voz com wrap signed 16-bit.
- O downmix segue `gGaxArmDownmix`:
  - ganho `0x400` para 1 handler;
  - caso geral `(handlers + 8) << 6`;
  - shift aritmético por 10;
  - clamp final para `[-128, 127]`.
- A tabela de período original de 3828 entradas da v0.22 continua sendo usada.

## Jetpack — tiro original

O disparo do Jetpack foi confirmado no código original como:

`PlayAmbientSfx(gAudioContext, 0x24, 1000, 0xA0, force=1)`

O port agora roteia `Shot` para o SFX `0x24`, voz GAX 2, prioridade 0 e volume `0xA0`, com retrigger forçado. O beep sintetizado permanece apenas como fallback quando GAX/ROM não está disponível.

## Airship

A destruição do Airship deixou de usar um contador genérico. A sequência agora segue os marcos originais:

- tick 10: 1 explosão;
- tick 50: 2 explosões;
- tick 80: 3 explosões;
- tick 110: 4 explosões;
- tick 170: transição para a queda.

São 10 explosões no total. As posições usam a mesma família de caixa do boss (`-102,-12,-2,51,68,4`) e uma LCG compatível com `RandRange` para espalhar os bursts. A renderização dos bursts no PC é nativa e não pretende ser um sprite pixel-perfect do efeito GBA.

## Validação

- 8/8 suítes strict com `-Werror`: PASS.
- ASan + UBSan: Audio, Category e Frontend PASS.
- ROM ACQE continua validada pelo mesmo SHA-256.

## Ainda pendente

O replayer GAX2 está mais fiel, mas ainda não é bit-exact: o bloco de echo/FILT e outros DSP taps do ARM original ainda não foram traduzidos integralmente. Alguns callbacks específicos de Polar/Jetpack/Hovercraft também continuam em refinamento.
