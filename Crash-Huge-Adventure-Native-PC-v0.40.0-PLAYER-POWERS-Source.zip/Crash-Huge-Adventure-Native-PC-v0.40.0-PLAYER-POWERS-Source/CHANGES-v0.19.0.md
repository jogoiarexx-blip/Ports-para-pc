# v0.19.0 — Áudio nativo, Warp Room e callbacks

## Áudio

- Novo backend de áudio Win32 por `waveOut`, 44,1 kHz / 16-bit estéreo, com streaming em quatro buffers.
- Música funcional para menu, Warp Room, famílias de fase e chefes; mudança automática de faixa ao trocar de tela/fase.
- SFX nativos para navegação/confirmar/cancelar, salto, giro, Wumpa, caixa, checkpoint, dano, vida, gema, relógio, tiro, inimigo, hit de boss e conclusão.
- Novo `CrashGaxTool`: detecta o **GAX Sound Engine 2.01D** da ROM e indexa as 19 tags de música existentes nela.
- O backend atual é uma reconstrução/sintetizador nativo. A reprodução direta e bit-exact das sequências GAX 2.01D da ROM ainda não é declarada como concluída.

## Menu e mapa

- Tela principal redesenhada em pixel-art e desacoplada do gameplay.
- Mapa antigo de 25 nós substituído por um **Warp Room por andar + portal**, com seis portais nos quatro andares principais e portal secreto.
- Esquerda/Direita muda o portal; Cima/Baixo muda o andar; Enter entra na fase.
- O frontend mostra nome da fase, estado liberada/bloqueada/concluída e progressão persistente.
- `CrashFrontendTool` atualizado para validar o novo Warp Room.

## Callbacks e IA

- Kinds das categories 0/1/2 passam por callbacks explícitos: Wumpa, caixa, checkpoint, vida, freezes 1/2/3 e hazards consume/animate.
- HP, dano de contato e perfil de IA do family jetpack foram centralizados em tabelas/funções sem alterar os comportamentos já validados.
- Perfis explícitos cobrem cannon plane, tracker/bomber, depth runner, balloon orbit, parachute, rocket, airship e ring.
- Novos asserts em `TestCategory` validam dispatch de callbacks, HP/dano e classificação de IA.

## Validação

- `TestCore`, `TestPlayer`, `TestEntities`, `TestCategory`, `TestRunState`, `TestFrontend`, `TestAudio` e `TestHD`: PASS.
- ASan + UBSan: `TestAudio`, `TestFrontend` e `TestCategory`: PASS.
- Durante o passe ASan foi detectado e corrigido um overflow no glifo pixel-art `A` do novo frontend.
- ROM preservada: SHA-256 `6be639d1db218ca2bf2b1ff0ee0867334404cead5fb6684af4870d4644a15635`.
