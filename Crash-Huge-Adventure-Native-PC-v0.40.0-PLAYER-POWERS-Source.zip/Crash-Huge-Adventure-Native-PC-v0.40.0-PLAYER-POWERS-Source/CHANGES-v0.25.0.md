# v0.25.0 — Jetpack state machine + Hovercraft launcher actors

## Jetpack player

- Category 3/4/5/6 now uses one native Jetpack runtime path; Category 6 no longer depends on direct helper calls for the Hovercraft to advance.
- Fire input follows the original held-button rule: while A/Space/Z remains held, a new shot is emitted whenever the `0x12`-frame cooldown reaches zero.
- Roll is now represented as the original player states 2/3 rather than an invented generic cooldown.
- Roll burst uses `±0x100` Q8 for the first 5 state frames, then returns by `0x2D` Q8 per frame.
- Horizontal control and roll chaining reopen after stateTime `0x21`.
- Damage is ignored through stateTime `0x10` while rolling, matching `DamageJetpackPlayer`.
- Player shot spawn/XY velocity use the original offsets/scaling (`+0x1200`, `-0x1800`, `0x199/0x1000`).

## Jetpack enemies

- Bomber kinds 4–9 now receive the common `+0x60` Z update from `UpdateJetpackBomber`.
- Kind 9 therefore has the correct net depth delta: `-0x88 + 0x60 = -0x28` Q8 per frame.
- Kinds 1 and 4–9 enter a death animation instead of disappearing instantly on the final player shot.
- Kind 1 plane now reads the route target chain from the ROM: marker kinds 32–37 select the six original speeds (`0x1555`, `0x1155`, `0x0D55`, `0x0955`, `0x0555`, `0x0155`), while marker X/Y, depth and next-target drive each hop.
- Plane cannonballs now use the original angle/scale projection, 20/60-frame burst cooldown and `-0x100` Q8 Z step.
- Plane death now follows knock-out state 2 -> fall state 3 with the original 1/4 then 2/5 animation families and `accY = 0xA0`.

## Hovercraft

- Category 6 is updated by the normal `Category0Stage::step()` loop.
- Cannon and launcher accept player-shot damage only while their original active states are open.
- The launcher no longer fires a fake direct projectile. It performs the original projected-range check and creates real Jetpack actors, choosing kinds 5/6/8 with `RandRange(3)` semantics.
- Spawned launcher bombers use their own ROM animation frames, 2 HP, native state-family movement and 51-tick death animation.
- Hovercraft finish is split into the two original conditions: Y > `0x4B00` triggers the Jetpack-finish phase; the craft is only considered gone when depth <= `0x14FF`.

## Polar finish

- The old literal `185`-frame finish-leap approximation was replaced by the value derived from the original thresholds and Z step: `ceil((0x2F00 - 0x03FF) / 0x3C) = 184` frames, after the state-10 animation.
- The native PC representation is still an abstraction because the original depth calculation also depends on the GBA cell-animation distance.

## Tooling / validation

- New `CrashJetpackTool` creates a 3-panel diagnostic strip: held-fire, roll, and Hovercraft launcher bomber.
- 8/8 strict test suites pass with `-Werror`.
- `TestCategory`, `TestFrontend` and `TestAudio` pass ASan + UBSan.
- All portable tools compile strict; the large HD tool was also rebuilt separately after the combined build exceeded the environment time window.
