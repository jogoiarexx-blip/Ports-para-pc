# v0.36.0 — Dingodile boss controller

## Gargalo fechado

A única sala tile ainda bloqueada era o boss Dingodile (entity `0x45`, room kind 1). A v0.36 adiciona um controller dedicado em vez de tratar o boss como inimigo genérico. Com isso, `CrashRouteTool` passa de 23/24 para **24/24 salas tile nativas**.

## Implementação

- sprite bank 54 do Dingodile carregado diretamente da ROM, com 10 animações;
- máquina de estados própria com caminhada por pontos da arena, turn, idle/attack, recover, vulnerability e death/fall;
- tabelas de parada da arena e ramps de movimento derivados do comportamento original;
- shield do boss acompanha o corpo, pisca nos estados de transição e mantém colisão fora da janela vulnerável;
- foguete bank 54/anim 7 sobe com o ramp original e gera a estalactite;
- estalactite bank 54/anim 9 cai acelerando, impacta em anim 8 e abre a vulnerabilidade quando atinge o boss após o ataque;
- tubarões usam bank 4/anim 1 e atravessam a arena;
- 3 acertos de spin encerram a luta e a queda final aciona a saída da sala;
- save em disco passa para formato v3, preservando estado/timers/hits/animação/shield do Dingodile e mantendo compatibilidade de leitura com saves v1/v2;
- `CrashDingodileTool` adicionado para diagnóstico visual;
- `CrashEnemyCoverageTool` agora inclui boss: 407/407 entidades da família inimigo/hazard/boss tratadas, 0 unsupported.

## Validação

- rebuild integral C++17 com `-Wall -Wextra -Wpedantic -Werror`: PASS;
- 8/8 suítes: PASS;
- ASan + UBSan: `TestEntities`, `TestRunState` e `TestPlayer` PASS;
- `CrashRouteTool`: `tile_rooms=24 native_player_rooms=24`;
- ROM de teste preservada, sem execução de código ARM do GBA.
