# v0.24.0 — GAX echo nativo e callbacks Polar confirmados

## Áudio GAX2

- O replayer continua 100% C++ nativo: a ROM fornece estruturas, patterns, instrumentos, PCM e tabelas; nenhum código ARM do GBA é executado.
- Cada música agora é mixada internamente na **taxa GAX original da própria faixa** antes da adaptação para o dispositivo host de 44,1 kHz.
- O sample position passou a usar **Q11 inteiro** e o passo usa a tabela de períodos original + recíproco Q32 da taxa, aproximando o caminho real de `GaxChannelMix`.
- O echo original foi modelado como ring buffer signed 16-bit, com até três taps, delay em milissegundos convertido na taxa GAX e ganho **Q4**.
- O mixer respeita a separação original: apenas `dspPrimaryChannels` passam pelo echo; os demais canais musicais entram secos depois. No fluxo normal de `StartSong`, os SFX entram secos porque `fxEcho` fica desligado.
- Configurações confirmadas diretamente na ROM ACQE incluem:
  - Main menu Europe: 6 canais processados, 25 ms, ganho 8/16;
  - Cutscenes: 3 canais, 23 ms, 8/16;
  - Warp Room: 3 canais, 20 ms, 9/16;
  - Credits: 2 canais, 29 ms, 8/16.
- O bloco opcional **FILT** do GAX2 foi identificado, mas o `StartSong` normal do jogo deixa os flags em zero. Por isso ele **não é ligado artificialmente** no port.

## Polar

O despachante deixou de tratar vários objetos como hazards genéricos e agora usa callbacks baseados no factory/update original:

- kind 4: Nitro, estado usado `0x12` e detonação em cadeia no tick `0x14`;
- kind 5/6/7: time crates de 1/2/3 segundos;
- kind 8/35: extra life;
- kind 9 e question kind 31: Aku-Aku/mask;
- kind 12: boost pad, janela de 30 frames;
- kind 13: hazard persistente;
- kind 16/18/20: icicles persistentes;
- kind 22: launcher, com arco próprio em vez de dano genérico;
- kind 23: electric fence / shock;
- kind 24: penguin persistente;
- kind 25: goal / `FinishPolarRun`;
- kind 28/29/30: question crates de 1/3/5 Wumpas.

Também foram adicionados:

- mask tier 0–3;
- perda de uma máscara + invulnerabilidade `0x4B` ao receber dano;
- tier 3 com janela longa de invulnerabilidade;
- shock de `0x2D` frames antes da perda de vida sem máscara;
- Nitro chain usando a box original `{ -15, -15, -2, 30, 30, 5 }`;
- contadores de diagnóstico para boost, launcher, goal e chain de Nitros.

## Ferramenta nova

- `CrashPolarTool ROM OUTPUT_BMP`: gera uma faixa de diagnóstico nativa com boost, launcher e goal, útil para testar callbacks sem percorrer toda a fase.

## Validação

- 8/8 suítes strict PASS com `-std=c++17 -O2 -Wall -Wextra -Wpedantic -Werror`;
- Audio, Category e Frontend: ASan + UBSan PASS;
- `CrashGaxTool` e `CrashPolarTool`: build strict PASS;
- Windows EXE não compilado neste ambiente; `COMPILAR-WINDOWS.cmd` foi atualizado para também gerar `CrashPolarTool.exe`.

## Ainda não declarado 100% bit-exact

- Alguns casos de scheduling/envelope/sweep do GAX2 ainda podem divergir em bordas raras.
- O handoff final para o hardware Direct Sound do GBA não existe no PC; o port termina em PCM host.
- FILT permanece intencionalmente inativo no fluxo normal porque os flags do jogo não o habilitam.
- Alguns atores de Jetpack/Hovercraft e a animação completa de encerramento do Polar ainda precisam de tradução mais específica.
