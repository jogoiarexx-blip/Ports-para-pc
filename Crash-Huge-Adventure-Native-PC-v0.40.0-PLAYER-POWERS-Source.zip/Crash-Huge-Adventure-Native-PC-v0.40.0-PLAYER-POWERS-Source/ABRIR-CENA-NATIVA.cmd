@echo off
cd /d "%~dp0"
if not exist CrashNative-Scene.exe (
 echo Executavel ausente. Extraia o ZIP inteiro novamente.
 pause
 exit /b 1
)
start "" "%~dp0CrashNative-Scene.exe"
