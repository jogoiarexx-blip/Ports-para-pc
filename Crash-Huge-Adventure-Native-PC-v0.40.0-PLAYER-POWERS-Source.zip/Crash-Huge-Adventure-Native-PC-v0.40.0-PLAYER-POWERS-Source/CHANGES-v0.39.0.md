# v0.39.0 — Mega-Mix Chase Boss

## Gargalo fechado

A auditoria da v0.38 deixava uma única entidade boss/enemy/hazard explicitamente sem runtime nas 24 salas tile: Mega-Mix (`0x49`), da fase final de perseguição. A v0.39 porta esse controller e elimina o último `unsupported` dessa cobertura.

## Mega-Mix nativo

- sprite bank 30, com as 3 animações originais;
- controller de três estados (`active chase`, `grab`, `inactive/dead-player fallback`);
- quatro motion records X originais: `{0,0,0}`, `{0,32,450}`, `{0,32,620}`, `{450,32,750}` em Q8;
- `SetMegaMixMotionXFromSet` preserva velocidade corrente; caminhos `Start...` reiniciam pela velocidade inicial do record;
- virada para perseguir Crash e seleção de velocidade baseada no estado on-screen/latch;
- janela de grab original (`0x27FF` X / `0x31FF` Y em Q8);
- animação 1 de grab e dano no frame 8;
- Mega-Mix é invulnerável ao spin, como no original: a luta é chase, não batalha de HP;
- colisão de rota destrói caixas breakable e explode TNT/Nitro próximos, preservando caixas metálicas.

## Saída da fase

O exit marker real da sala está em `x=7275`, enquanto a largura é 8000 px. O critério comum `worldWidth - 300` nunca o armaria. Salas com Mega-Mix passam a habilitar explicitamente o marker real, removendo um softlock de conclusão.

## Persistência

- formato de save atualizado para v6;
- preserva state, animação/tick, motion mode, stamp, velocidade/target/step, latch e flag do golpe do grab;
- saves v1-v5 continuam legíveis.

## Ferramentas e cobertura

- novo `CrashMegaMixTool` com preview de três estados;
- `CrashEnemyCoverageTool` inclui Mega-Mix entre bosses suportados;
- cobertura: **410/410 entidades boss/enemy/hazard tratadas**, `unsupported=0`;
- 24/24 salas tile continuam com player/runtime nativo.

## Validação

- build C++17 strict com `-Wall -Wextra -Wpedantic -Werror`;
- 8/8 suítes PASS;
- ASan + UBSan PASS em EntityWorld, RunState e Player;
- diagnóstico Mega-Mix, cobertura de inimigos e cobertura de rotas executados sobre a ROM USA ACQE do projeto.
