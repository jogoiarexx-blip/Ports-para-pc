# Crash Native PC v0.30.0 — Jetpack/Hovercraft exact GAX SFX callbacks

A v0.30 troca a camada de efeitos sonoros do gameplay Jetpack/Hovercraft de inferência por contadores para **callbacks exatos do ator**, preservando o ID original do GAX, parâmetro de volume, voz forçada quando aplicável e múltiplas chamadas no mesmo frame.

## Novo caminho de SFX original

- `OriginalSfxEvent` transporta `id`, `volumeParam` e `forcedVoice`.
- `Category0Stage` mantém uma fila ordenada de callbacks e o runtime Win32 a drena a cada fixed tick.
- `GaxLitePlayer::playSfxId()` toca diretamente qualquer entrada válida da tabela original de 99 SFX.
- `Win32Audio::sfxId()` usa o GAX da ROM e mantém fallback sintético caso o GAX não esteja disponível.
- Os contadores genéricos de áudio foram desativados para Jetpack/Hovercraft para evitar som duplicado; Polar e salas normais continuam usando o caminho anterior.

## Callbacks fechados nesta versão

- tiro do player: `0x24`, volume `0xA0`, voz 2;
- dano não fatal do player: `0x42`;
- ambiência dos bombers: `0x37`, volume `min(0x100, count × 48)`, timer `0x16`;
- Wumpa visual chegando ao HUD: `0x0E`;
- Balloon pop: `0x2E`;
- crate normal/health/question/time: `0x03`;
- life crate / quinto reward do ring: `0x07`;
- time-trial crate: `0x18`;
- Parachute Nitro: `0x04`;
- Rocket spawn: `0x2D`; trigger/destruição: `0x04`;
- Ring: `0x3E` uma vez por ator;
- Plane death: `0x25`; bomber death: `0x04`;
- Airship hit não fatal: `0x43`; transição explosão → queda: `0x42`;
- Hovercraft part hit não fatal: `0x45`;
- Hovercraft part death: duas chamadas `0x04`, preservando `LoseHovercraftPart` + callback da peça;
- Hovercraft fireball death/contact: `0x04`;
- `FinishJetpackRun`: `0x3B`.

## Final de percurso Jetpack

Categorias Jetpack 3/4/5 não saltam mais diretamente de `routeEndThreshold` para `complete`. Ao alcançar o fim, entram no **state 5 / FinishJetpackRun**, disparam `0x3B`, avançam a profundidade do player e somente concluem após o limite de profundidade original já modelado pelo runtime.

## Testes

- 8/8 suítes strict PASS;
- `make all` PASS em C++17 com `-Wall -Wextra -Wpedantic -Werror`;
- TestCategory cobre IDs, ordem de chamadas duplicadas, volume/voz do tiro, ring, crates, balloon, rocket/parachute, Airship e Hovercraft;
- TestAudio cobre `playSfxId()` com IDs reais e rejeição de índice fora da tabela;
- TestCategory, TestFrontend e TestAudio: ASan + UBSan PASS.
