# Crash Bandicoot: The Huge Adventure Native PC — v0.38.0

## Neo Cortex boss controller

- Porta a entity `0x48` para um controller dedicado, sem HP genérico no corpo do boss.
- Usa o bank 53 original para Cortex, cannon, target/crosshair e shots.
- Cannon seleciona as animações 3/4/5 conforme a altura do target.
- Target implementa rota/hop, chase, blink e firing states usando as tabelas originais de timing.
- Slow shot usa anim 14; fast shot usa anim 17.
- Gemas do boss `0x0A/0x0B/0x0C` passam a participar da luta: bank 32 anims 3/2/0 e hit effects bank 53 anims 12/11/13.
- A luta avança por três gem hits; o terceiro inicia a sequência final do Cortex.
- As três flip-platforms da arena começam indisponíveis e se tornam sólidas durante a janela de perseguição/carga da mira.
- A conclusão cria a recompensa Turbo Run (bank 38 anim 3) e só libera a saída após a coleta.

## Persistência

- Save format atualizado para v5.
- Preserva Cortex state/counter, boss/cannon anims, target state/route/interpolation, gems, completion e reward state.
- Mantém leitura de saves v1-v4.
- Shots transitórios não são restaurados; recompensa pendente é reconstruída.
- Save de luta concluída + recompensa coletada restaura a saída liberada.

## Ferramentas e cobertura

- Novo `CrashCortexTool` com preview de três estágios da luta.
- `CrashEnemyCoverageTool` passa a tratar Cortex como boss suportado.
- Cobertura atual: 409 entidades boss/enemy/hazard tratadas; Mega-Mix (`0x49`) é o único explicitamente unsupported nessa auditoria.

## Validação

- 8/8 suítes PASS.
- Rebuild C++17 strict com `-Wall -Wextra -Wpedantic -Werror` PASS nos alvos alterados e `make all` consistente.
- ASan + UBSan PASS em EntityWorld, RunState e Player.
- `CrashCortexTool`, `CrashRouteTool` e `CrashEnemyCoverageTool` executados no pacote final.
