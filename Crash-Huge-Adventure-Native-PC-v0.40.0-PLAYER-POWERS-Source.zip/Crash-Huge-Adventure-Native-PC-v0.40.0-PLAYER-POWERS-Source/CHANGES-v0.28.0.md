# v0.28.0 — Jetpack HUD Wumpa + Balloon Crates + Rocket/Parachute + Hovercraft Palette

## Jetpack — Wumpa visual até o HUD

- `DispenseJetpackWumpa` deixa de creditar o lote no mesmo frame.
- A drenagem 1/2/4/8 cria agora um ator visual **kind 44**, como `SpawnJetpackCollectedWumpa`.
- O efeito parte da posição atual do player no renderer, calcula o divisor pela distância Manhattan / 8 e segue para o ponto `(16,16)`, reproduzindo a matemática do construtor original em coordenadas host.
- O Wumpa é creditado somente quando o efeito alcança X<=16 ou Y<=16; em estado inativo/final, a fila continua sendo drenada imediatamente, como no original.

## Balloon crates

- Health / question / time crates deixam de desaparecer instantaneamente: entram em **state 2 / anim 1** e só são removidos quando a animação termina.
- Question crates 20/21/22 alimentam a fila com **1/3/5 Wumpas**, em vez de somar direto ao contador.
- Health crate aplica +20 HP; life crate concede vida; time crates 24/25/26 mantêm 1/2/3 unidades de freeze; kind 29 inicia time trial sem contar broken crate.
- Os balões filhos agora são desenhados com os kinds originais: **40=time, 41=question, 42=health**.
- Ao quebrar o crate, o balão é liberado e sobe usando a sequência original: `velY -= 6`, com piso inicial `-0x12C`, até sair por `Y < -0xE100`.

## Parachute Nitro e Rocket

- Parachute Nitro kind 27 começa em Y=-250 e sobe reto `0x140` Q8 por frame até `limitY`; removida a oscilação lateral artificial da v0.27.
- Contato com Parachute Nitro causa 20 de dano e entra em anim 1; tiro também usa anim 1 antes da remoção.
- Rocket kind 28 mantém a órbita X `stateTime*4 + 0x40`, Y inicial 250, `limitY` clamped e `stepY=(limitY-250)/198`.
- Rocket passa a causar **14 de dano** no contato.
- Após trigger usa a box original `{-21,-21,-2,42,42,4}`; impacto por tiro usa anim 2, trigger normal usa anim 1.

## Hovercraft — palettes separadas corretamente

- Corrigida a interpretação da v0.27: `StartHovercraftHitFlash/UpdateHovercraftHitFlash` controla o **medidor de dano**, não o branco periódico do boss.
- O medidor host agora pisca branco com o latch de 12 ticks / toggle a cada 4 ticks.
- A troca do **índice 15 da palette** do boss/parts segue `RunHovercraftState`: branco no 16º frame e restauração no 8º intermediário.
- Parts 11/12/13 usam o banco OBJ 10 confirmado da ROM; o picture do boss recebe a mesma substituição do índice 15 no renderer.

## Validação

- 8/8 suítes strict PASS.
- `make all` PASS com `-Werror`.
- TestCategory / TestFrontend / TestAudio: ASan + UBSan PASS.
- `CrashJetpackTool` mostra reward kind 44 em trânsito, weapon panel e estados de death/finish.

## Ainda não declarado 100%

- O caminho visual do Wumpa usa a projeção host equivalente; não replica registradores BG2/OAM do GBA.
- O medidor do Hovercraft é uma representação nativa da paleta/HP, não uma cópia pixel-exata do widget GBA.
- Alguns crates/balloons ainda podem ter diferenças de ordem de draw/sortKey e efeitos sonoros de chegada.
