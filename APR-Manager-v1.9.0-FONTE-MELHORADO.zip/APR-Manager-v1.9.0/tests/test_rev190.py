"""Regressões de confiabilidade/escala APR Manager 1.9.0."""
from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from core.history import HistoryStore
from core.models import APRRecord, CompanyProfile, ParsedNumber
from core.pdf_reader import ExtractionCancelled, extract_pdf_content
from core.reporting import export_package, verify_export_package


class ExtractionFastPathTests(unittest.TestCase):
    sample = (
        "AUTORIZAÇÃO DE APLICAÇÃO E RESGATE - APR\n"
        "UNIDADE GESTORA DO RPPS - TESTE\n"
        "CNPJ: 05.360.812/0001-61\n"
        "Nº/ANO: 52/26\n"
        "DATA: 11/06/2026\n"
        "TIPO DE OPERAÇÃO: Resgate\n"
        "Cabeçalho de validação APR. Informações adicionais sobre operações financeiras.\n"
        "Solicitamos conferência dos dados da unidade gestora neste relatório.\n"
    )

    def test_good_mupdf_skips_pypdf_and_pdfium(self):
        with patch("core.pdf_reader._extract_mupdf_text", return_value=(self.sample, 2)), \
             patch("core.pdf_reader._extract_pypdf_text") as pypdf, \
             patch("core.pdf_reader._extract_pdfium_text") as pdfium:
            result = extract_pdf_content(Path("ok.pdf"), enable_ocr=False)
            self.assertEqual(result.text_source, "MuPDF/Fitz")
            self.assertEqual(result.page_count, 2)
            pypdf.assert_not_called()
            pdfium.assert_not_called()

    def test_weak_mupdf_runs_fallback(self):
        with patch("core.pdf_reader._extract_mupdf_text", return_value=("APR", 2)), \
             patch("core.pdf_reader._extract_pypdf_text", return_value=(self.sample, 2, 0, "")) as pypdf, \
             patch("core.pdf_reader._extract_pdfium_text") as pdfium:
            result = extract_pdf_content(Path("outro.pdf"), enable_ocr=False)
            self.assertEqual(result.text_source, "pypdf")
            pypdf.assert_called_once()
            pdfium.assert_not_called()

    def test_extraction_cancellation_propagates(self):
        with patch("core.pdf_reader._extract_mupdf_text", side_effect=ExtractionCancelled("cancelado")):
            with self.assertRaises(ExtractionCancelled):
                extract_pdf_content(Path("x.pdf"), enable_ocr=False)


class SQLCommentSafetyTests(unittest.TestCase):
    def test_profile_name_cannot_inject_statement_through_sql_comment(self):
        from core.reporting import build_sql
        profile = CompanyProfile("Instituto Seguro\nDELETE FROM transparencies;", "5", "892", "77")
        row = APRRecord(pdf=Path("APR 1.26.pdf"), name="1/26", slug="126",
                        date_sql="2026-06-01 00:00:00", file_db="/dist/5/2026/APR 1.26.pdf")
        sql = build_sql([row], profile)
        self.assertIn("-- Perfil: Instituto Seguro DELETE FROM transparencies;", sql)
        self.assertNotIn("\nDELETE FROM transparencies;", sql)


class VerificationHardeningTests(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp_dir.cleanup)
        profile = CompanyProfile("Empresa Exemplo", "5", "892", "77")
        row = APRRecord(
            pdf=Path("APR 52.26.pdf"), name="52/26", slug="5226",
            date_sql="2026-06-11 00:00:00", file_db="/dist/5/2026/APR 52.26.pdf"
        )
        self.output = export_package(Path(self.temp_dir.name), [row], profile)["output_dir"]
        self.assertTrue(verify_export_package(self.output)[0])

    def test_missing_mandatory_entry_rejected(self):
        checksums = self.output / "CHECKSUMS.sha256"
        checksums.write_text(
            "\n".join(x for x in checksums.read_text().splitlines() if "manifest_apr.json" not in x) + "\n",
            encoding="utf-8"
        )
        ok, messages = verify_export_package(self.output)
        self.assertFalse(ok)
        self.assertTrue(any("arquivo obrigatório" in m for m in messages))

    def test_sql_cannot_be_omitted_silently(self):
        checksums = self.output / "CHECKSUMS.sha256"
        checksums.write_text(
            "\n".join(x for x in checksums.read_text().splitlines() if "inserts_transparencies.sql" not in x) + "\n",
            encoding="utf-8"
        )
        ok, messages = verify_export_package(self.output)
        self.assertFalse(ok)
        self.assertTrue(any("SQL inconsistente" in m for m in messages))

    def test_duplicate_checksum_is_rejected(self):
        checksums = self.output / "CHECKSUMS.sha256"
        checksums.write_text(checksums.read_text() * 2, encoding="utf-8")
        ok, messages = verify_export_package(self.output)
        self.assertFalse(ok)
        self.assertTrue(any("mais de uma vez" in m for m in messages))

    def test_corrupt_utf8_checksum_reports_failure_without_crash(self):
        (self.output / "CHECKSUMS.sha256").write_bytes(b"\xff\xfe\x00")
        ok, messages = verify_export_package(self.output)
        self.assertFalse(ok)
        self.assertTrue(any("ilegível" in msg for msg in messages))

    def test_unlisted_extra_is_rejected(self):
        (self.output / "surpresa.txt").write_text("conteúdo inesperado", encoding="utf-8")
        ok, messages = verify_export_package(self.output)
        self.assertFalse(ok)
        self.assertTrue(any("extra/não listado" in m for m in messages))

    def test_checksum_path_outside_is_rejected(self):
        checksums = self.output / "CHECKSUMS.sha256"
        checksums.write_text(checksums.read_text() + "0" * 64 + "  ..\\secreto.txt\n", encoding="utf-8")
        ok, messages = verify_export_package(self.output)
        self.assertFalse(ok)
        self.assertTrue(any("inseguro/desconhecido" in m for m in messages))

    def test_checksum_unknown_filename_rejected(self):
        checksums = self.output / "CHECKSUMS.sha256"
        checksums.write_text(checksums.read_text() + "0" * 64 + "  surpresa.txt\n", encoding="utf-8")
        ok, messages = verify_export_package(self.output)
        self.assertFalse(ok)

    def test_symlink_is_rejected_if_supported(self):
        target = self.output / "relatorio_apr.html"
        content = target.read_bytes()
        target.unlink()
        alternative = Path(self.temp_dir.name) / "externo.html"
        alternative.write_bytes(content)
        try:
            target.symlink_to(alternative)
        except (OSError, NotImplementedError):
            self.skipTest("links simbólicos não disponíveis")
        ok, messages = verify_export_package(self.output)
        self.assertFalse(ok)
        self.assertTrue(any("link simbólico" in m for m in messages))


class OCRMultipageTests(unittest.TestCase):
    def test_ocr_never_silently_skips_later_pages(self):
        from core.ocr import extract_text_with_ocr

        class FakeDoc:
            def __len__(self):
                return 2
            def close(self):
                pass

        class FakeMuPDF:
            @staticmethod
            def open(_path):
                return FakeDoc()

        ocr_calls = []

        def fake_ocr(_engine, image):
            index = int(image)
            ocr_calls.append(index)
            if index == 0:
                return ("AUTORIZAÇÃO DE APLICAÇÃO APR\nCNPJ: 05.360.812/0001-61\n"
                        "Nº/ANO: 52/26\nDATA: 11/06/2026", 0.98)
            return "Nº/ANO: 99/26\nDATA: 12/06/2026", 0.98

        with patch("core.ocr._get_engine", return_value=object()), \
             patch("core.ocr._load_mupdf", return_value=FakeMuPDF), \
             patch("core.ocr._render_mupdf_page", side_effect=lambda doc, idx, scale: idx), \
             patch("core.ocr._ocr_image", side_effect=fake_ocr):
            result = extract_text_with_ocr(Path("APR 52.26.pdf"))
        self.assertIn(0, ocr_calls)
        self.assertIn(1, ocr_calls)
        self.assertIn("99/26", result.text)
        self.assertFalse(result.truncated)
        self.assertEqual(len(result.pages), 2)


class HugeHistoryBatchTests(unittest.TestCase):
    def test_1300_records_are_checked_in_chunks(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = HistoryStore(Path(tmp) / "historico.sqlite3")
            profile = CompanyProfile("Empresa Teste", "8", "93", "77")
            items = []
            for num in range(1, 1301):
                n = ParsedNumber(str(num), "26", num, 2026)
                items.append(APRRecord(
                    pdf=Path(f"APR_{num}.pdf"),
                    filename_number=n, name=n.display,
                    sha256=f"{num:064x}",
                ))
            store.record_export(items, profile, Path(tmp) / "lote")
            store.confirm_export(Path(tmp) / "lote")
            store.apply_checks(items, profile)
            self.assertEqual(sum(r.history_status == "CONFIRMADO" for r in items), 1300)
            self.assertTrue(all(r.history_blocking for r in items))


if __name__ == "__main__":
    unittest.main()
