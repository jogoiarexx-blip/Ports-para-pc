# APR Manager — Relatório técnico de evolução 1.8.4 → 1.9.0

Data da revisão: 21/10/2026

## Diagnóstico resumido

| Componente | Estado na 1.8.4 | Mudança na 1.9.0 | Evidência |
|---|---|---|---|
| Leitura PDF digital | Executava `pypdf` após MuPDF mesmo com texto suficiente | Fast-path só para texto com três marcadores, mais de 160 alfanuméricos, sem ruído e sem necessidade de OCR | Testes verificam que `pypdf` e PDFium não são chamados quando já há texto adequado e que o fallback funciona |
| OCR multipágina | Encerramento antecipado após reconhecer cabeçalho; podia omitir divergências nas páginas seguintes | Todas as páginas dentro do limite explícito são inspecionadas | Teste com APR número 52 na página 1 e número 99 na página 2 recupera ambas |
| Histórico SQLite | Consultas de `IN` criadas com todas as entradas; risco em SQLite com limite baixo de parâmetros | Lotes de até 400 valores por consulta | Caso com 1.300 APRs confirmadas validado |
| Integridade da exportação | Validava os hashes existentes, mas não exigia relatórios obrigatórios nem detectava alterações no inventário | Inventário fechado, relatório obrigatório, SQL coerente com resumo, duplicações, arquivos extras e links simbólicos recusados | Testes de falsificação e adulteração |
| SQL gerado | Nome de perfil editável inserido diretamente no comentário SQL | Quebras de linha e controles do cabeçalho são removidos | Teste confirma que uma nova instrução não surge a partir do nome |
| UI | Método copiado para `DropArea` que referenciava atributos inexistentes | Removido o método órfão | Compilação estática Python |

## Testes realizados

- **49/49** testes originais (v1.8.4), executados antes de editar.
- **63/63** testes após a revisão; 14 testes de regressão acrescentados.
- Teste de integração com PDF de camada textual (da suíte anterior) passou.
- Simulação de 1.300 APRs no SQLite e conferência de `state=confirmed` passou.
- `python -m compileall` passou nos módulos Python.

**Sem validação neste ambiente:** a interface gráfica Windows (PySide6 não instalado), OCR real (RapidOCR/ONNX não instalado), instalador e executável Windows. Não foram fornecidos lotes reais de APR para testar extração de modelos distintos. O pacote entregue é **código-fonte atualizado**, não um `.exe` já validado.

## Velocidade / impacto

A otimização de camada textual remove chamadas redundantes ao `pypdf` apenas em PDFs com bons marcadores. Um microbenchmark com PDFs sintéticos não mostrou redução de tempo de maneira consistente, portanto **não há percentual de ganho comprovado**. O OCR de documentos digitalizados com muitas páginas pode ficar mais lento, intencionalmente, para não ignorar páginas que podem conter dados conflitantes.

## Pendências prioritárias

1. Testar PDFs reais: APR digital, escaneada, multipágina, com PDF protegido por senha e arquivo parcialmente corrompido.
2. Rodar testes de interface em Windows, incluindo arrastar/soltar, cancelamento, scroll em 1366×768 e 125%/150% de escala.
3. Revisar o modelo de OCR com confiança por **campo crítico**, e não apenas média por página/documento; a média alta não prova que Nº/ANO e data foram reconhecidos corretamente.
4. Para proteção entre operadores, implementar **assinatura digital** dos pacotes: SHA-256 sem chave não prova autenticidade e pode ser recalculado por quem alterou o pacote.
5. Revisar idempotência concorrente no banco de produção: `INSERT WHERE NOT EXISTS` isoladamente não garante exclusão sob duas sessões simultâneas; índice único apropriado no banco deve ser avaliado antes de implantação.
6. Verificar obrigações de licença de PyMuPDF ao distribuir um aplicativo fechado.

## Referências open source consultadas

- PyMuPDF, extração de texto e organização de leitura: https://pymupdf.readthedocs.io/en/latest/page.html
- PyMuPDF, licenciamento AGPL/comercial: https://pymupdf.io/licensing
- pypdf, limites de memória da extração: https://pypdf.readthedocs.io/en/6.21.1/user/extract-text.html
- SQLite, limite de parâmetros SQL: https://www.sqlite.org/limits.html
- Qt for Python, regras de QThread e QObject: https://doc.qt.io/qtforpython-6.10/overviews/qtdoc-threads-qobject.html

## Como reproduzir

```bash
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
python -m compileall -q core ui app.py gerar_inserts_apr.py
```

No Windows, `executar.bat` inicializa a versão em fonte; `criar_exe.bat` utiliza o PyInstaller para gerar o executável, se as dependências puderem ser instaladas.
