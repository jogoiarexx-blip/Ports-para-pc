# Final Fight X v1.0.0 — validação com Builder v0.34.13

Resultado do ZIP original:

- 99 modelos
- 21 fases
- 1106 animações
- 5 scripts
- 103 arquivos de áudio
- 15465 comandos SUPPORTED
- 0 PARTIAL
- 0 UNSUPPORTED
- 0 UNKNOWN

Correções desta rodada: catálogo dos 139 UNKNOWN, propriedades `makeinv`, `playshotno`, `grabback`, `grabfinish`, `throwframewait`, `fastattack`, diretivas de HUD/menu/frontend e detecção genérica de token de modelo solto em fase.

A inicialização do runtime ganhou raiz de trabalho fixa, validação de assets, log persistente e caixa de erro no Windows.
