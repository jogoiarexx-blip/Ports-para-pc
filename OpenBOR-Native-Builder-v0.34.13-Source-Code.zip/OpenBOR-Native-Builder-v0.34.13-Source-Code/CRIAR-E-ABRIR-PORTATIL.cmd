@echo off
setlocal
chcp 65001 >nul
title OpenBOR Native Builder v0.34.13 - Portable Win64

echo ========================================================
echo OpenBOR Native Builder v0.34.13 - Criar Portable Win64
echo ========================================================
echo.
if exist "%~dp0dist-portable\OpenBOR-Native-Builder.exe" goto RUN

echo O executavel ainda nao existe. Preparando e compilando...
echo.
call "%~dp0GERAR-PORTATIL-WINDOWS.cmd"
if errorlevel 1 exit /b 1

:RUN
if not exist "%~dp0dist-portable\OpenBOR-Native-Builder.exe" (
  echo ERRO: o executavel portatil nao foi encontrado.
  pause
  exit /b 2
)
start "" "%~dp0dist-portable\OpenBOR-Native-Builder.exe"
endlocal
