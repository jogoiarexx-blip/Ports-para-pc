$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Build = Join-Path $Root "build-portable-mingw"
$Dist = Join-Path $Root "dist-portable"

function Find-CMake {
    $cmd = Get-Command cmake.exe -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    $paths = @(
        (Join-Path $Root "tools\cmake\bin\cmake.exe"),
        "$env:ProgramFiles\CMake\bin\cmake.exe",
        "${env:ProgramFiles(x86)}\CMake\bin\cmake.exe"
    )
    foreach ($p in $paths) { if ($p -and (Test-Path $p)) { return $p } }
    return $null
}
$CMake = Find-CMake
if (-not $CMake) { throw "CMake nao encontrado. Execute INSTALAR-FERRAMENTAS-WINDOWS.cmd." }
$Cxx = (Get-Command x86_64-w64-mingw32-g++ -ErrorAction Stop).Source
$Cc = (Get-Command x86_64-w64-mingw32-gcc -ErrorAction Stop).Source
if (Test-Path $Build) { Remove-Item $Build -Recurse -Force }
if (Test-Path $Dist) { Remove-Item $Dist -Recurse -Force }
New-Item -ItemType Directory -Force -Path $Dist | Out-Null
& $CMake -S $Root -B $Build -G Ninja -DCMAKE_BUILD_TYPE=Release -DCMAKE_C_COMPILER=$Cc -DCMAKE_CXX_COMPILER=$Cxx
& $CMake --build $Build
Copy-Item (Join-Path $Build "openbor-native-builder.exe") (Join-Path $Dist "OpenBOR-Native-Builder.exe")
Copy-Item (Join-Path $Root "README.md") $Dist
@"
OpenBOR Native Builder v0.34.13 - Portable Win64

Execute OpenBOR-Native-Builder.exe e selecione uma pasta, ZIP ou PAK do jogo OpenBOR.
O executavel foi ligado estaticamente com MinGW; DLLs normais do Windows continuam sendo fornecidas pelo proprio Windows.
"@ | Set-Content -Encoding UTF8 (Join-Path $Dist "LEIA-ME.txt")
Write-Host "Portable Win64 pronto em: $Dist"
