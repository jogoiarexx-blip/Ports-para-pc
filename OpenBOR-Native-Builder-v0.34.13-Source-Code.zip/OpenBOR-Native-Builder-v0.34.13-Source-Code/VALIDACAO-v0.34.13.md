# Validação v0.34.13

## Final Fight X v1.0.0

| Estado | v0.34.12 | v0.34.13 |
|---|---:|---:|
| SUPPORTED | 15391 | 15465 |
| PARTIAL | 0 | 0 |
| UNSUPPORTED | 0 | 0 |
| UNKNOWN | 139 | 0 |

Os 139 UNKNOWN foram classificados por semântica/contexto. Comandos de gameplay/modelo passam pelo parser/runtime; campos exclusivos do frontend legado que não alteram o runtime nativo são explicitamente `IGNORED_SAFELY`; token de modelo solto em arquivo de fase é detectado genericamente como linha malformada/no-op.

## Testes

- `ctest`: 1/1 PASS
- `tests/run-runtime-tests.py`: 8/8 PASS
- runtime completo do Final Fight X: CMake configure/build OK
- execução headless: exit 0
- `runtime-startup.log`: START -> INITIALIZED OK -> EXIT code=0

## Windows

A v0.34.13 adiciona diagnóstico persistente e launcher que mantém o erro visível. O ambiente de validação não possui toolchain PE/Windows, portanto o EXE Win64 é gerado no PC Windows por `COMPILAR-E-INICIAR-WINDOWS.cmd`/Visual Studio Build Tools + CMake.
