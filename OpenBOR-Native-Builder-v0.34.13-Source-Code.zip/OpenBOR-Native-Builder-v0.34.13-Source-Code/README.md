# OpenBOR Native Builder v0.34.13

Conversor/Builder C++ focado em portar conteúdo OpenBOR para um runtime PC nativo. A v0.34.13 foi validada diretamente com **Final Fight X v1.0.0 (2013) (JIAM)**.

## Resultado do Final Fight X

- SUPPORTED: **15465**
- PARTIAL: **0**
- UNSUPPORTED: **0**
- UNKNOWN: **0**

A v0.34.13 cataloga os 139 UNKNOWN da versão anterior. Comandos que realmente afetam modelo/runtime (`makeinv`, `grabback`, `grabfinish`, `throwframewait`, `fastattack`, `playshotno`, `maxplayers`, controles de cena e cores do HUD) agora têm tratamento explícito. Diretivas puramente de layout/capacidade do frontend legado são marcadas como `IGNORED_SAFELY`, sem serem falsamente promovidas a comportamento de gameplay. Linhas soltas que são apenas nomes de modelos registrados, como o `andore` perdido em um arquivo de fase do Final Fight X, são reconhecidas genericamente como linhas malformadas/no-op.

## Correção de inicialização Windows

O runtime gerado agora:

- procura a raiz do port por até 8 níveis e valida `assets/openbor-data`;
- força a raiz encontrada como diretório de trabalho no Windows;
- cria `runtime-startup.log` com START / INITIALIZED / EXIT;
- mostra uma caixa de erro no Windows em falhas de inicialização, em vez de fechar silenciosamente;
- gera `INICIAR-PORT.cmd` no pacote portátil;
- gera `COMPILAR-E-INICIAR-WINDOWS.cmd` para compilar (se necessário) e abrir pelo launcher de diagnóstico.

## Validação

- Build do Builder: OK
- CTest/regressão: OK
- 8 suítes de runtime: OK
- Port completo do Final Fight X: geração e compilação Linux/headless OK
- Execução headless: exit 0; fase 1, áudio, spawns, objetos, combate e IA OK

Consulte `VALIDACAO-v0.34.13.md` e `FINAL-FIGHT-X-v0.34.13.md`.
