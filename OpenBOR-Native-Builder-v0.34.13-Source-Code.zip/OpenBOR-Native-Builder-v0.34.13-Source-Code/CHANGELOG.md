# v0.34.13 — Final Fight X: 139 UNKNOWN -> 0 e diagnóstico de inicialização Windows

- Final Fight X: 15465 SUPPORTED / 0 PARTIAL / 0 UNSUPPORTED / 0 UNKNOWN.
- Novo parsing/emissão para `makeinv`, `playshotno`, `grabback`, `grabfinish`, `throwframewait` e `fastattack`.
- Catálogo explícito de diretivas legadas de HUD/menu/levels; itens exclusivos do frontend antigo são `IGNORED_SAFELY`, não falsos `SUPPORTED`.
- Detector genérico para nome de modelo solto em arquivo de fase (linha malformada/no-op), cobrindo o `andore` perdido do Final Fight X sem hardcode do jogo.
- Runtime Windows passa a validar `assets/openbor-data`, fixar o diretório de trabalho e gravar `runtime-startup.log`.
- Falhas de inicialização mostram MessageBox no Windows e o launcher `INICIAR-PORT.cmd` mantém o código/log visível.
- Novo `COMPILAR-E-INICIAR-WINDOWS.cmd`.
- Regressão e 8 suítes de runtime verdes; Final Fight X headless exit 0.

# v0.34.11 — Final Fight X: 255 PARTIAL -> 47

- damageonlanding 0 1, aimove chase, indexed GIF palette/remap, platform parsing, scene e outras correções dirigidas pelo Final Fight X.

# v0.34.10 — redução de PARTIAL em @cmd e combate legado

- Resolução de helpers de animation script e melhorias em attackone/dropv.
