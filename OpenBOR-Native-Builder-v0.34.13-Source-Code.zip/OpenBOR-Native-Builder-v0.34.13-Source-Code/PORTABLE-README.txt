OpenBOR Native Builder v0.34.13 - Windows x64

Extraia o ZIP e abra OpenBOR-Native-Builder.exe com dois cliques.
Escolha um PAK/ZIP ou a pasta do jogo. O executavel do Builder ja esta compilado.
A compilacao do jogo gerado requer as ferramentas C++ apropriadas.

Esta versao parte da v0.34.7 recuperada. Consulte o relatorio de validacao.
Para receber as correcoes, gere novamente os ports dos jogos.
