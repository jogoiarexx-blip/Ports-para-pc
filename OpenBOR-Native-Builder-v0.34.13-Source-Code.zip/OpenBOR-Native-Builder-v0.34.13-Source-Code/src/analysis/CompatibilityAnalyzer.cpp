#include "CompatibilityAnalyzer.hpp"
#include "TextDatabase.hpp"
#include "LevelParser.hpp"
#include "CharacterParser.hpp"
#include "SafePath.hpp"
#include <algorithm>
#include <cctype>
#include <fstream>
#include <functional>
#include <map>
#include <regex>
#include <set>
#include <sstream>

namespace {
std::string lower(std::string s){std::transform(s.begin(),s.end(),s.begin(),[](unsigned char c){return static_cast<char>(std::tolower(c));});return s;}
bool textLike(const std::filesystem::path&p){auto e=lower(p.extension().string());return e==".txt"||e==".c"||e==".h"||e==".cfg";}
// PAKs may bundle documentation and gettext catalogues inside data/. They are
// not OpenBOR command streams, even though they happen to use a .txt suffix.
bool ancillaryText(const std::filesystem::path& p){
 auto name=lower(p.filename().string());
 return name=="#translation#.txt" || name.rfind("nota",0)==0 ||
        name.rfind("readme",0)==0 || name.rfind("leame",0)==0 ||
        (name.size()<=14 && name[0]=='l' && name.find("ame.txt")!=std::string::npos);
}
std::vector<std::string> scriptUnsupported(const std::filesystem::path& path,const std::string* inlineSource=nullptr){
 std::string src;if(inlineSource)src=*inlineSource;else{std::ifstream in(path);if(!in)return {};std::ostringstream ss;ss<<in.rdbuf();src=ss.str();}auto lo=lower(src);std::vector<std::string> out;auto add=[&](std::string s){if(std::find(out.begin(),out.end(),s)==out.end())out.push_back(std::move(s));};
 // v0.22 handles object-like and function-like #define plus include/import preprocessing and a broader OpenBORScript API surface.
 static const std::set<std::string> allowed={
  "main","if","while","for","switch","getglobalvar","setglobalvar","clearglobalvar","getglobalvarindex","setglobalvarindex","maxglobalvarindex",
  "getindexedvar","setindexedvar","clearindexedvar","getlocalvar","setlocalvar","clearlocalvar","getlocalvarindex","setlocalvarindex",
  "array","size","get","set","add","delete","next","previous","reset","value","key","free",
  "isempty","rand","null","openborconstant","openborvariant","changeopenborvariant","setopenborvariant","getentityproperty","get_entity_property",
  "changeentityproperty","change_entity_property","setentityproperty","performattack","perform_attack","setanimation","changeanimation","damageentity","damage_entity",
  "bindentity","killentity","kill_entity","tossentity","checkhole","checkholeindex","checkwall","checkwallindex","playerkeys","getplayerproperty","get_player_property","changeplayerproperty","change_player_property","log","printf","debug","rgbcolor",
  "playmusic","pausemusic","loadsample","unloadsample","playsample","jumptobranch","getentity","findtarget","find_target","checkrange","check_range","getentityvar","get_entity_var","setentityvar","set_entity_var","clearentityvar","clear_entity_var","clearspawnentry","clear_spawn_entry","setspawnentry","set_spawn_entry","spawn","spawnentity","spawn_entity","projectile","setidle","updateframe","getmodelproperty","get_model_property","getlevelproperty","get_level_property","changelevelproperty","setlevelproperty","set_level_property","drawdot","drawline","drawbox","drawstring","drawsprite","loadsprite","freesprite","getgfxproperty","get_gfx_property","rgbcolour"
 };
 std::set<std::string> defined;
 std::regex macroDef(R"(#\s*define\s+([A-Za-z_][A-Za-z0-9_]*)\s*\()");
 for(std::sregex_iterator m(src.begin(),src.end(),macroDef),me;m!=me;++m) defined.insert(lower((*m)[1].str()));
 std::regex def(R"((?:void|int|float|char|string|mixed|decimal|pointer)\s+([A-Za-z_][A-Za-z0-9_]*)\s*\()");
 for(std::sregex_iterator i(src.begin(),src.end(),def),e;i!=e;++i)defined.insert(lower((*i)[1].str()));
 // Include/imported helper functions belong to the same script compilation unit after
 // v0.19 preprocessing. Teach the analyzer about them so supported includes do not
 // produce false "api/function" warnings.
 std::filesystem::path dataRoot;
 for(auto cur=path.parent_path(); !cur.empty(); cur=cur.parent_path()){
  auto leaf=lower(cur.filename().string());
  if(leaf=="data" || leaf=="openbor-data" || std::filesystem::exists(cur/"models.txt") || std::filesystem::exists(cur/"levels.txt")){
   dataRoot=cur; break;
  }
  if(cur==cur.root_path()) break;
 }
 std::regex incRe(R"(#\s*(?:include|import)\s*["<]([^">]+)[">])", std::regex::icase);
 std::set<std::string> visited{path.lexically_normal().generic_string()};
 std::function<void(const std::filesystem::path&,const std::string&,int)> imports;
 imports=[&](const std::filesystem::path& file,const std::string& body,int depth){
  if(depth>=32){add("include-depth-limit");return;}
  for(std::sregex_iterator i(body.begin(),body.end(),incRe),e;i!=e;++i){
   auto raw=(*i)[1].str();auto rel=SafePath::normalizeOpenBOR(raw);
   if(!SafePath::isSafeRelative(rel)){add("unsafe-include:"+raw);continue;}
   auto inc=SafePath::resolveWithin(dataRoot,raw);
   if(inc.empty()||!std::filesystem::exists(inc)){
    auto local=SafePath::resolveWithin(file.parent_path(),raw);
    if(!local.empty()&&SafePath::isWithin(dataRoot,local))inc=local;
   }
   if(inc.empty()||!SafePath::isWithin(dataRoot,inc)){add("unsafe-include:"+raw);continue;}
   if(!visited.insert(inc.lexically_normal().generic_string()).second)continue;
   std::ifstream imported(inc);if(!imported){add("include-missing:"+raw);continue;}
   std::ostringstream text;text<<imported.rdbuf();auto code=text.str();
   for(std::sregex_iterator d(code.begin(),code.end(),def),de;d!=de;++d)defined.insert(lower((*d)[1].str()));
   for(std::sregex_iterator d(code.begin(),code.end(),macroDef),de;d!=de;++d)defined.insert(lower((*d)[1].str()));
   imports(inc,code,depth+1);
  }
 };
 if(!dataRoot.empty())imports(path,src,0);
 // Name recognition alone cannot certify dynamic/advanced binding config.
 std::regex bindCall(R"(\bbindentity\s*\()",std::regex::icase);
 for(std::sregex_iterator it(src.begin(),src.end(),bindCall),end;it!=end;++it){
  std::vector<std::string> args;std::string part;int depth=1;char quote=0;bool closed=false;
  auto start=(std::size_t)(it->position()+it->length());
  for(std::size_t j=start;j<src.size();++j){char c=src[j];if(quote){part+=c;if(c=='\\'&&j+1<src.size())part+=src[++j];else if(c==quote)quote=0;continue;}if(c=='"'||c=='\''){quote=c;part+=c;continue;}if(c=='('){++depth;part+=c;}else if(c==')'){if(--depth==0){if(!part.empty()||!args.empty())args.push_back(part);closed=true;break;}part+=c;}else if(c==','&&depth==1){args.push_back(part);part.clear();}else part+=c;}
  if(!closed||args.size()<2||args.size()>8){add("api/function:bindentity-arguments");continue;}
  if(args.size()>6){auto config=args[6];config.erase(std::remove_if(config.begin(),config.end(),[](unsigned char c){return std::isspace(c);}),config.end());
   if(lower(config)=="null()"||lower(config)=="null")continue;
   try{std::size_t used=0;int flags=std::stoi(config,&used,0);constexpr int supported=15|64|128|256|512|1024|2048;if(used!=config.size())add("api/function:bindentity-config-dynamic");else if((flags&~supported)!=0)add("api/function:bindentity-config-advanced");}catch(...){add("api/function:bindentity-config-dynamic");}
  }
 }
 std::regex call(R"(([A-Za-z_][A-Za-z0-9_]*)\s*\()");
 for(std::sregex_iterator i(src.begin(),src.end(),call),e;i!=e;++i){auto n=lower((*i)[1].str());if(!allowed.contains(n)&&!defined.contains(n)&&n!="void"&&n!="int"&&n!="float"&&n!="char"&&n!="string"&&n!="mixed"&&n!="decimal"&&n!="pointer")add("api/function:"+n);}
 return out;
}
std::filesystem::path casePath(std::filesystem::path p){
 if(std::filesystem::exists(p))return p;std::filesystem::path out=p.root_path();
 for(const auto& part:p.relative_path()){auto next=out/part;if(!std::filesystem::exists(next)&&std::filesystem::is_directory(out))for(const auto&e:std::filesystem::directory_iterator(out))if(lower(e.path().filename().string())==lower(part.string())){next=e.path();break;}out=next;}return out;
}

std::filesystem::path resolveAnimationHelper(const std::string& raw,const std::filesystem::path& modelFile,const ScanReport& scan){
 auto rel=SafePath::normalizeOpenBOR(raw);
 if(!SafePath::isSafeRelative(rel))return {};
 std::filesystem::path relPath(rel);
 auto candidate=casePath(scan.dataDir/relPath);
 if(std::filesystem::exists(candidate)&&SafePath::isWithin(scan.dataDir,candidate))return candidate;
 // Some legacy packs keep animationscript beside the model while referring to
 // it by basename (or ship it in a moved character folder). Prefer the local
 // model folder and only fall back to a unique basename match.
 if(relPath.has_filename()){
  auto local=casePath(modelFile.parent_path()/relPath.filename());
  if(std::filesystem::exists(local)&&SafePath::isWithin(scan.dataDir,local))return local;
  std::filesystem::path unique;
  std::error_code ec;
  for(std::filesystem::recursive_directory_iterator it(scan.dataDir,std::filesystem::directory_options::skip_permission_denied,ec),end;it!=end;it.increment(ec)){
   if(ec){ec.clear();continue;}
   if(!it->is_regular_file(ec))continue;
   if(lower(it->path().filename().string())!=lower(relPath.filename().string()))continue;
   if(!unique.empty())return {}; // Ambiguous: do not guess.
   unique=it->path();
  }
  if(!unique.empty()&&SafePath::isWithin(scan.dataDir,unique))return unique;
 }
 return {};
}
bool parseNumber(const std::string& raw){
 try{std::size_t used=0;std::stod(raw,&used);return used==raw.size();}catch(...){return false;}
}
bool parseInteger(const std::string& raw,int* value=nullptr){
 try{std::size_t used=0;int v=std::stoi(raw,&used,0);if(used!=raw.size())return false;if(value)*value=v;return true;}catch(...){return false;}
}
bool simpleSceneSupported(const TextEntry& item,const std::filesystem::path& modelFile,const ScanReport& scan){
 if(item.values.size()!=1)return false;auto path=resolveAnimationHelper(item.values[0],modelFile,scan);if(path.empty())return false;
 for(const auto&e:TextDatabase::parse(path)){auto k=lower(e.key);if(k=="music"){if(e.values.empty()||e.values.size()>2)return false;}else if(k=="animation"){if(e.values.empty()||e.values.size()>6)return false;}else if(k!="silence")return false;}
 return true;
}
bool indexedGifAsset(const std::string& raw,const std::filesystem::path& modelFile,const ScanReport& scan){
 auto p=resolveAnimationHelper(raw,modelFile,scan);return !p.empty()&&lower(p.extension().string())==".gif";
}
bool executableAnimationScript(const TextEntry& item,const std::filesystem::path& modelFile,const ScanReport& scan){
 if(item.values.size()!=1)return false;auto p=resolveAnimationHelper(item.values[0],modelFile,scan);if(p.empty())return false;return scriptUnsupported(p).empty();
}
void refineOccurrence(CommandInfo& info,const TextEntry& item,const std::filesystem::path& file,const ScanReport& scan){
 if(info.status!=CommandStatus::Partial)return;const auto cmd=lower(item.key);auto supported=[&](const char* note){info.status=CommandStatus::Supported;info.parser=true;info.runtime=true;info.note=note;};
 int v=0;
 if(cmd=="damageonlanding"&&item.values.size()>=1&&item.values.size()<=3&&parseInteger(item.values[0])&&(item.values.size()<2||(parseInteger(item.values[1],&v)&&v>=0&&v<=1))){supported("Landing force/mode 0-1 is preserved; mode 1 enables falling-body projectile collisions until landing.");return;}
 if(cmd=="attackone"&&item.values.size()==1&&parseInteger(item.values[0],&v)&&v==1){supported("attackone 1 stops after the first collision for player, coop, enemy, and projectile attacks.");return;}
 if(cmd=="atchain"&&!item.values.empty()){
  bool ok=true,zero=false;for(const auto&x:item.values){int n=0;if(!parseInteger(x,&n)||n<0||n>12){ok=false;break;}if(n==0)zero=true;else if(zero){ok=false;break;}}
  if(ok){supported("Static/trailing-zero attack chains are executed by the native combo runtime.");return;}
 }
 if((cmd=="com"||cmd=="cmd")&&item.values.size()==2){static const std::set<std::string> keys={"a","a2","a3","a4","j","s","k","u","d","f","b","l","r"};if(keys.contains(lower(item.values[0]))){supported("Simple one-input custom command is parsed and matched by the runtime input history.");return;}}
 if(cmd=="aimove"&&item.values.size()==1&&lower(item.values[0])=="chase"){supported("Named aimove chase maps to the OpenBOR chase flag and is executed by enemy/NPC AI.");return;}
 if((cmd=="antigrab"||cmd=="grabresistance"||cmd=="grab_resistance")&&item.values.size()==1&&parseInteger(item.values[0],&v)&&v>=0){supported("Numeric grab resistance is enforced against attacker grabforce for player, coop, and AI grab selection.");return;}
 if(cmd=="grabforce"&&item.values.size()==1&&parseInteger(item.values[0],&v)&&v>=0){supported("Numeric grabforce gates native player/coop/AI grab selection against target antigrab/grab resistance.");return;}
 if(cmd=="bounce"&&item.values.size()==1&&parseInteger(item.values[0],&v)&&v>=0&&v<=8){supported("Numeric bounce count is applied to runtime projectiles and falling runtime entities on ground contact.");return;}
 if((cmd=="burn"||cmd=="shock")&&item.values.size()>=4&&item.values.size()<=10&&std::all_of(item.values.begin(),item.values.end(),parseNumber)){supported(cmd=="burn"?"Legacy burn attack box is parsed with burn pain/fall/death reaction selection and native attack metadata.":"Legacy shock attack box is parsed with shock pain/fall reaction selection and native attack metadata.");return;}
 if(cmd=="platform"&&item.values.size()==8&&std::all_of(item.values.begin(),item.values.end(),parseNumber)){supported("Eight-value entity platform trapezoid is emitted and participates in dynamic platform side/top collision.");return;}
 if((cmd=="lives"||cmd=="credits")&&item.values.size()==1&&parseInteger(item.values[0],&v)&&v>=0){supported("Level-set lives/credits are generated into stage metadata and consumed by native respawn/continue flow.");return;}
 if(cmd=="animationscript"&&executableAnimationScript(item,file,scan)){supported("Animation helper script resolves inside data/, uses the verified ScriptVM surface, and frame @cmd calls execute against it.");return;}
 if(cmd=="defense"&&item.values.size()==1&&lower(item.values[0])=="all"){supported("Legacy defense all without an explicit factor is preserved as factor 1.0.");return;}
 if(cmd=="nodieblink"&&item.values.size()==1&&parseInteger(item.values[0],&v)&&v==2){supported("nodieblink 2 keeps the death/fall animation visible through its last frame and removes without blinking.");return;}
 if(cmd=="wall"&&item.values.size()>=8&&item.values.size()<=9&&std::all_of(item.values.begin(),item.values.end(),parseNumber)){supported("Static OpenBOR trapezoid wall geometry and height are used by runtime collision and script wall queries.");return;}
 if(cmd=="blockade"&&item.values.size()==1&&parseInteger(item.values[0])){supported("Numeric blockade is emitted as a backward-scroll floor and activated by stage events.");return;}
 if(cmd=="frontpanel"&&item.values.size()==1){supported("Single-image frontpanel is loaded as a foreground stage layer.");return;}
 if(cmd=="palette"&&item.values.size()==1&&indexedGifAsset(item.values[0],file,scan)){supported("Indexed GIF base palette is preserved from the decoder palette table for native remaps.");return;}
 if(cmd=="remap"&&item.values.size()==2&&indexedGifAsset(item.values[0],file,scan)&&indexedGifAsset(item.values[1],file,scan)){supported("Indexed GIF source/target palette tables drive the native color-map remap.");return;}
 if(cmd=="scene"&&simpleSceneSupported(item,file,scan)){supported("Scene uses supported music/animation/silence directives; GIF playback runs a full animation cycle unless an explicit duration is supplied.");return;}
 if(cmd=="nocost"&&item.values.size()==1&&parseInteger(item.values[0],&v)&&(v==0||v==1)){supported("Global nocost is propagated to generated models and energy-cost execution.");return;}
 if(cmd=="end"&&item.values.empty()){supported("Bare end marks the stage as ending in the generated stage model.");return;}
 if(cmd=="remove"&&item.values.size()==1&&parseInteger(item.values[0],&v)&&(v==0||v==1)){supported("Projectile remove contact mode 0/1 is enforced by the runtime projectile lifecycle.");return;}
 if(cmd=="weapon"&&item.values.size()==1){supported("Stage weapon spawn is parsed as a weapon item spawn and resolved through model weapon indices.");return;}
 if(cmd=="weapons"&&!item.values.empty()){supported("Weapon model list is emitted and used for player/coop/AI weapon pickup and action-animation lookup.");return;}
 if((cmd=="weapnum"||cmd=="shootnum"||cmd=="counter")&&item.values.size()==1&&parseInteger(item.values[0],&v)&&v>=0){supported("Simple numeric weapon index/ammo/drop counter is consumed by the native weapon lifecycle.");return;}
 if(cmd=="typeshot"&&item.values.size()==1&&parseInteger(item.values[0],&v)&&(v==0||v==1)){supported("typeshot 0/1 controls weapon exhaustion/drop behavior in the native weapon lifecycle.");return;}
}
int helperFunctionArity(const std::string& source,const std::string& function){
 try{
  std::regex def("(?:void|int|float|char|string|mixed|decimal|pointer)\\s+"+function+"\\s*\\(([^)]*)\\)",std::regex::icase);
  std::smatch m;if(!std::regex_search(source,m,def))return -1;
  auto args=m[1].str();auto trim=[](std::string v){auto a=v.find_first_not_of(" \t\r\n");if(a==std::string::npos)return std::string{};auto b=v.find_last_not_of(" \t\r\n");return v.substr(a,b-a+1);};
  args=trim(args);if(args.empty()||lower(args)=="void")return 0;
  int count=1;int depth=0;char quote=0;
  for(std::size_t i=0;i<args.size();++i){char c=args[i];if(quote){if(c=='\\'&&i+1<args.size())++i;else if(c==quote)quote=0;continue;}if(c=='"'||c=='\'')quote=c;else if(c=='('||c=='[')++depth;else if(c==')'||c==']')--depth;else if(c==','&&depth==0)++count;}
  return count;
 }catch(...){return -1;}
}
AnimationCommandDiagnostic auditCommand(const TextEntry& item,const std::vector<TextEntry>& entries,std::size_t index,const std::filesystem::path&file,const ScanReport&scan){
 AnimationCommandDiagnostic d;d.file=std::filesystem::relative(file,scan.root);d.line=item.line;d.function=item.values.empty()?"<empty>":item.values[0];
 bool animation=false,frame=false;
 for(std::size_t i=0;i<index;++i){auto k=lower(entries[i].key);if(k=="anim"||k=="animation")animation=true;}
 for(std::size_t i=index+1;i<entries.size();++i){auto k=lower(entries[i].key);if(k=="anim"||k=="animation")break;if(k=="frame"){frame=true;break;}}
 for(const auto&e:entries)if(lower(e.key)=="animationscript"&&!e.values.empty())d.helper=e.values[0];
 auto prefix="function="+d.function+"; helper="+(d.helper.empty()?"<none>":d.helper)+"; ";
 if(!animation||!frame){d.detail=prefix+"no following animation frame; command cannot execute";return d;}
 if(item.values.empty()){d.detail=prefix+"empty command";return d;}
 if(!std::regex_match(d.function,std::regex("[A-Za-z_][A-Za-z0-9_]*"))){d.detail=prefix+"invalid function name";return d;}
 // A deliberately narrow, behavior-tested subset can be certified per call.
 // Engine-property APIs and custom helper bodies retain PARTIAL; static API
 // name recognition is not sufficient evidence of their full semantics.
 static const std::set<std::string> verified={"setglobalvar","getglobalvar","getlocalvar","setlocalvar","null","killentity"};
 auto function=lower(d.function);bool direct=verified.contains(function);
 std::size_t expected=function=="null"?0:(function=="setglobalvar"||function=="setlocalvar"?2:1);
 if(item.values.size()!=expected+1)direct=false;
 static const std::regex literal(R"CMD((?:"(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*'|[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?|0[xX][0-9A-Fa-f]+|true|false|null))CMD",std::regex::icase);
 static const std::regex simpleRead(R"CMD((?:null\(\s*\)|(?:getlocalvar|getglobalvar)\(\s*(?:"(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*')\s*\)))CMD",std::regex::icase);
 for(std::size_t i=1;i<item.values.size();++i)if(!std::regex_match(item.values[i],literal)&&!std::regex_match(item.values[i],simpleRead))direct=false;
 std::string args;for(std::size_t i=1;i<item.values.size();++i)args+=item.values[i]+" ";
 std::string code=args;char quote=0;for(std::size_t i=0;i<code.size();++i){char c=code[i];if(quote){code[i]=' ';if(c=='\\'&&i+1<code.size())code[++i]=' ';else if(c==quote)quote=0;}else if(c=='"'||c=='\''){quote=c;code[i]=' ';}}
 if(quote)direct=false;
 int balance=0;for(char c:code){if(c=='(')++balance;else if(c==')'&&--balance<0)direct=false;}if(balance!=0)direct=false;
 std::regex calls(R"(([A-Za-z_][A-Za-z0-9_]*)\s*\()");
 for(std::sregex_iterator i(code.begin(),code.end(),calls),e;i!=e;++i)if(!verified.contains(lower((*i)[1].str())))direct=false;
 // Bare unknown names can be constants/macros requiring preprocessing.
 std::regex names(R"([A-Za-z_][A-Za-z0-9_]*)");for(std::sregex_iterator i(code.begin(),code.end(),names),e;i!=e;++i){auto n=lower(i->str());if(!verified.contains(n)&&n!="true"&&n!="false")direct=false;}
 if(code.find_first_of("{};[]")!=std::string::npos)direct=false;
 if(!d.helper.empty()){
  auto rel=SafePath::normalizeOpenBOR(d.helper);
  if(!SafePath::isSafeRelative(rel)){d.detail=prefix+"unsafe helper path";return d;}
  auto path=resolveAnimationHelper(d.helper,file,scan);
  if(path.empty()){d.detail=prefix+"helper file missing or basename is ambiguous";return d;}
  std::ifstream f(path);if(!f){d.detail=prefix+"helper file missing";return d;}std::ostringstream text;text<<f.rdbuf();auto source=text.str();
  auto missing=scriptUnsupported(path);
  if(!missing.empty()){d.detail=prefix+"helper compilation unit requires: ";for(const auto&name:missing)d.detail+=name+" ";return d;}
  if(!direct){
   // The generated ScriptVM supports user-defined helper functions. Certify a
   // call when the helper really defines the function, its arity matches, all
   // APIs in the compilation unit are implemented, and the @cmd arguments stay
   // inside the expression subset already validated above.
   int arity=helperFunctionArity(source,d.function);
   bool simpleArgs=true;
   for(std::size_t i=1;i<item.values.size();++i)if(!std::regex_match(item.values[i],literal)&&!std::regex_match(item.values[i],simpleRead))simpleArgs=false;
   if(arity>=0&&arity==(int)item.values.size()-1&&simpleArgs)direct=true;
   else {d.detail=prefix+"custom helper function/arity or arguments still need behavioral validation; runtime executes and logs any failure";return d;}
  }
 }
 if(direct){d.status=CommandStatus::Supported;d.detail=prefix+"verified ScriptVM call, bound to the following frame";}
 else d.detail=prefix+"helper/API or arguments outside the verified subset; runtime executes and logs any failure";
 return d;
}
std::string jsonEscape(const std::string& s){
    std::string o; o.reserve(s.size());
    for(char c:s){ if(c=='\\'||c=='"'){o.push_back('\\'); o.push_back(c);} else if(c=='\n') o+="\\n"; else if(c=='\r') continue; else o.push_back(c); }
    return o;
}
}

CompatibilityReport CompatibilityAnalyzer::analyze(const ScanReport& scan){
    CompatibilityReport out;
    if(!scan.hasDataDir) return out;
    auto video = LevelParser::parseVideo(scan.dataDir);
    if(video.found){ out.logicalWidth=video.hResolution; out.logicalHeight=video.vResolution; out.openborVersionHint = "video.txt present (mode "+std::to_string(video.videoMode)+")"; }
    else out.openborVersionHint = "video.txt absent; logical resolution defaults to 320x240 until a project declares otherwise";

    auto characters = CharacterParser::parseAll(scan.dataDir, scan.root);
    out.models = characters.size();
    for(const auto& c: characters) out.animations += c.animations.size();
    const auto stages=LevelParser::parseAll(scan.dataDir, scan.root);
    out.stages=stages.size();
    std::set<std::string> invalidPanelOrder;
    for(const auto& stage:stages)if(!stage.panelOrderValid)invalidPanelOrder.insert(stage.sourceFile);

    std::set<std::string> modelAliases;
    auto modelsFile=casePath(scan.dataDir/"models.txt");
    if(std::filesystem::exists(modelsFile)) for(const auto& me:TextDatabase::parse(modelsFile)){
        auto mk=lower(me.key); if((mk=="load"||mk=="know")&&!me.values.empty()) modelAliases.insert(lower(me.values[0]));
    }

    for(const auto& entry: std::filesystem::recursive_directory_iterator(scan.dataDir)){
        if(!entry.is_regular_file()) continue;
        auto ext=lower(entry.path().extension().string());
        if(ext==".wav"||ext==".bor"||ext==".ogg"||ext==".mp3"||ext==".flac") ++out.audioFiles;
        if(!textLike(entry.path())) continue;
        if(ext==".txt" && ancillaryText(entry.path())) continue;
        ++out.scannedTextFiles;
        if(ext==".c"||ext==".h"){
            ++out.scripts;
            auto unsupported=scriptUnsupported(entry.path());
            ++out.recognizedCommands;
            if(!unsupported.empty()){
                CompatibilityIssue issue;
                issue.level=CompatibilityLevel::Yellow;
                issue.status=CommandStatus::Partial;
                issue.parser=true; issue.runtime=false;
                issue.file=std::filesystem::relative(entry.path(),scan.root);
                issue.line=1; issue.command="script-file";
                issue.message="ScriptVM v0.22 covers the extended C-like core and basic preprocessing, but this file uses: ";
                for(std::size_t i=0;i<unsupported.size();++i){ if(i) issue.message+=", "; issue.message+=unsupported[i]; }
                issue.message+=". Logged, not silently dropped.";
                out.issues.push_back(std::move(issue));
                ++out.partialCommands;
            }
            continue;
        }
        const auto textEntries=TextDatabase::parse(entry.path());
        for(std::size_t entryIndex=0;entryIndex<textEntries.size();++entryIndex){
            const auto&item=textEntries[entryIndex];const auto cmd=lower(item.key);
            ++out.commandUsage[cmd];
            if(cmd=="@script"){
                const auto unsupported=scriptUnsupported(entry.path(),&item.scriptBody);
                if(!unsupported.empty()){
                    CompatibilityIssue bodyIssue;bodyIssue.file=std::filesystem::relative(entry.path(),scan.root);bodyIssue.line=item.line;bodyIssue.command="inline-script-api";bodyIssue.status=CommandStatus::Partial;bodyIssue.level=CompatibilityLevel::Yellow;bodyIssue.parser=true;bodyIssue.runtime=false;bodyIssue.message="Inline body is preserved and executed, but requires: ";
                    for(const auto& name:unsupported)bodyIssue.message+=name+" ";
                    out.issues.push_back(std::move(bodyIssue));++out.partialCommands;++out.recognizedCommands;
                }
            }
            auto info=CommandRegistry::lookup(cmd);
            if(info.status==CommandStatus::Unknown && item.values.empty() && modelAliases.contains(cmd)){
                auto rel=lower(std::filesystem::relative(entry.path(),scan.dataDir).generic_string());
                if(rel.rfind("levels/",0)==0){
                    info.status=CommandStatus::IgnoredSafely; info.parser=true; info.runtime=true;
                    info.note="Bare model-registry token outside a spawn directive is a malformed/no-op stage line; ignored explicitly instead of treated as an unknown command.";
                }
            }
            if(cmd=="order" && invalidPanelOrder.contains(std::filesystem::relative(entry.path(),scan.root).generic_string())){
                info.status=CommandStatus::Partial;info.runtime=false;info.note="Panel order contains a non-letter or references an undefined panel; original panel definitions are retained as fallback.";
            }
            std::string commandDetail;
            if(cmd=="@cmd"){
                auto diagnostic=auditCommand(item,textEntries,entryIndex,entry.path(),scan);
                info.status=diagnostic.status;info.runtime=info.status==CommandStatus::Supported;
                commandDetail=diagnostic.detail;out.animationCommands.push_back(std::move(diagnostic));
            }
            else refineOccurrence(info,item,entry.path(),scan);
            ++out.commandStatusCounts[cmd][info.status];
            // Mixed occurrences remain conservatively PARTIAL in the summary;
            // the per-status counts and per-call audit show the exact split.
            auto prior=out.commandStatus.find(cmd);
            if(prior==out.commandStatus.end())out.commandStatus[cmd]=info.status;
            else if(prior->second!=info.status)prior->second=CommandStatus::Partial;
            CompatibilityIssue issue;
            issue.file=std::filesystem::relative(entry.path(),scan.root);
            issue.line=item.line;
            issue.command=cmd;
            issue.status=info.status;
            issue.parser=info.parser;
            issue.runtime=info.runtime;
            issue.message = commandDetail.empty()?(info.note?info.note:""):commandDetail;
            if(info.status==CommandStatus::Supported){ ++out.supportedCommands; ++out.recognizedCommands; continue; }
            if(info.status==CommandStatus::IgnoredSafely){ ++out.recognizedCommands; continue; }
            if(info.status==CommandStatus::Partial){ ++out.partialCommands; ++out.recognizedCommands; issue.level=CompatibilityLevel::Yellow; }
            else if(info.status==CommandStatus::Unsupported){ ++out.unsupportedCommands; ++out.recognizedCommands; issue.level=CompatibilityLevel::Red; }
            else { ++out.unknownCommands; issue.level=CompatibilityLevel::Yellow; issue.status=CommandStatus::Unknown; if(issue.message.empty()) issue.message="Uncatalogued command. Logged; conversion continues."; }
            out.issues.push_back(std::move(issue));
        }
    }
    return out;
}

const char* CompatibilityAnalyzer::levelName(CompatibilityLevel level){
    switch(level){case CompatibilityLevel::Green:return"GREEN";case CompatibilityLevel::Yellow:return"YELLOW";case CompatibilityLevel::Red:return"RED";}
    return"UNKNOWN";
}

void CompatibilityAnalyzer::writeReport(const ScanReport& scan, const CompatibilityReport& report, const std::filesystem::path& outDir){
    std::filesystem::create_directories(outDir);
    const double total = (double)std::max<std::size_t>(1, report.supportedCommands+report.partialCommands+report.unsupportedCommands+report.unknownCommands);
    auto pct=[&](std::size_t n){ return (int)(100.0*(double)n/total); };

    std::ofstream txt(outDir/"compatibility-report.txt");
    txt << "OPENBOR CONVERSION REPORT\n\n";
    txt << "Game: " << scan.root.filename().string() << "\n";
    txt << "Source: " << scan.root.generic_string() << "\n";
    txt << "OpenBOR hint: " << report.openborVersionHint << "\n";
    txt << "Logical resolution: " << report.logicalWidth << "x" << report.logicalHeight << "\n";
    txt << "Models: " << report.models << "\n";
    txt << "Stages: " << report.stages << "\n";
    txt << "Animations: " << report.animations << "\n";
    txt << "Scripts: " << report.scripts << "\n";
    txt << "Audio files: " << report.audioFiles << "\n";
    txt << "Text files: " << report.scannedTextFiles << "\n\n";
    txt << "Parser occurrences:\n";
    txt << "  SUPPORTED .... " << report.supportedCommands << " (" << pct(report.supportedCommands) << "%)\n";
    txt << "  PARTIAL ...... " << report.partialCommands << " (" << pct(report.partialCommands) << "%)\n";
    txt << "  UNSUPPORTED .. " << report.unsupportedCommands << "\n";
    txt << "  UNKNOWN ...... " << report.unknownCommands << "\n\n";
    txt << "Status means parser support AND runtime support. A parsed-but-not-executed command is PARTIAL.\n\n";
    txt << "Command registry:\n";
    for(const auto& [name,count]: report.commandUsage){
        auto st = report.commandStatus.count(name)? CommandRegistry::statusName(report.commandStatus.at(name)) : "UNKNOWN";
        txt << "  " << name << " x" << count << " -> " << st;
        auto counts=report.commandStatusCounts.find(name);if(counts!=report.commandStatusCounts.end()&&counts->second.size()>1){txt<<" (";bool first=true;for(const auto&[status,n]:counts->second){if(!first)txt<<", ";first=false;txt<<CommandRegistry::statusName(status)<<"="<<n;}txt<<")";}txt<<"\n";
    }
    txt << "\nIssues (file:line command impact):\n";
    for(const auto& issue: report.issues){
        txt << "  [" << CommandRegistry::statusName(issue.status) << "] "
            << issue.file.generic_string() << ":" << issue.line
            << " " << issue.command;
        if(!issue.message.empty()) txt << " - " << issue.message;
        txt << "\n";
    }

    std::ofstream cmdAudit(outDir/"animation-command-audit.txt");
    cmdAudit<<"ANIMATION COMMAND AUDIT\nPer-call diagnostics; no generic suppression of PARTIAL.\n\n";
    for(const auto& d:report.animationCommands)cmdAudit<<"["<<CommandRegistry::statusName(d.status)<<"] "<<d.file.generic_string()<<":"<<d.line<<" "<<d.detail<<"\n";

    std::ofstream json(outDir/"analysis.json");
    json << "{\n";
    json << "  \"game\": \"" << jsonEscape(scan.root.filename().string()) << "\",\n";
    json << "  \"logicalWidth\": " << report.logicalWidth << ",\n";
    json << "  \"logicalHeight\": " << report.logicalHeight << ",\n";
    json << "  \"models\": " << report.models << ",\n";
    json << "  \"stages\": " << report.stages << ",\n";
    json << "  \"animations\": " << report.animations << ",\n";
    json << "  \"scripts\": " << report.scripts << ",\n";
    json << "  \"audioFiles\": " << report.audioFiles << ",\n";
    json << "  \"supported\": " << report.supportedCommands << ",\n";
    json << "  \"partial\": " << report.partialCommands << ",\n";
    json << "  \"unsupported\": " << report.unsupportedCommands << ",\n";
    json << "  \"unknown\": " << report.unknownCommands << ",\n";
    json << "  \"commands\": {\n";
    std::size_t i=0;
    for(const auto& [name,count]: report.commandUsage){
        auto st = report.commandStatus.count(name)? CommandRegistry::statusName(report.commandStatus.at(name)) : "UNKNOWN";
        json << "    \"" << jsonEscape(name) << "\": {\"count\": " << count << ", \"status\": \"" << st << "\", \"statusCounts\": {";
        auto counts=report.commandStatusCounts.find(name);bool first=true;if(counts!=report.commandStatusCounts.end())for(const auto&[status,n]:counts->second){if(!first)json<<", ";first=false;json<<"\""<<CommandRegistry::statusName(status)<<"\": "<<n;}json<<"}}";
        if(++i!=report.commandUsage.size()) json << ",";
        json << "\n";
    }
    json << "  }\n}\n";
}
