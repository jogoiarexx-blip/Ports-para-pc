#pragma once
#include <filesystem>
#include <string>
#include <vector>

struct HitBoxDef { int x=0,y=0,w=0,h=0; };
struct PlatformDef { float x=0,z=0,lowerLeft=0,upperLeft=0,lowerRight=0,upperRight=0,depth=0,altitude=0; };
struct AttackBoxDef { int x=0,y=0,w=0,h=0,damage=0,type=0,fallForce=0,penetration=0,guardCost=0,juggleCost=0,pauseTime=0,tag=0,noFlash=0,zDepth=0,landingDamage=0,landingMode=0,landingType=-1; };
struct DrawMethodDef {
    bool enabled = false;
    float scaleX = 1.0f;
    float scaleY = 1.0f;
    bool flipX = false;
    bool flipY = false;
    float shiftX = 0.0f;
    int alphaMode = 0;
    int remap = 0;
    int fillColor = 0;
    int rotate = 0;
    bool flipRotate = false;
};
struct FrameDef {
    std::string sprite;
    int delay = 1;
    int offsetX = 0;
    int offsetY = 0;
    bool hasBBox = false;
    HitBoxDef bbox;
    bool hasPlatform = false;
    PlatformDef platform;
    bool hasAttack = false;
    AttackBoxDef attack;
    bool knockdown = false;
    float dropVx = 0.0f;
    int dropVy = -3;
    int pauseTime = 0;
    std::string sound;
    std::string hitFlash;
    std::string blockFlash;
    std::string animationCommand; // v0.32: @cmd call(s) bound to this frame.
    float moveX = 0.0f;
    float moveZ = 0.0f;
    float moveA = 0.0f;
    DrawMethodDef draw;
    bool hasSetA = false;
    float setA = 0.0f;
};
struct CommandDef { std::string sequence; std::string targetAnimation; };
struct DefenseDef {
    std::string type = "all";
    float factor = 1.0f;
    float pain = 1.0f;
    float knockdown = 1.0f;
    int blockPower = 0;
    int blockThreshold = 0;
    float blockRatio = 0.0f;
    bool blockRatioDefined = false;
    int blockType = 0;
    bool blockTypeDefined = false;
};
struct CancelDef {
    int startFrame = 0;
    int endFrame = 0;
    int hits = 0;
    std::string command;
    std::string targetAnimation;
};
struct AnimationDef {
    std::string name;
    int energyCost=0,energyMode=0,energyDisable=0;
    std::string inlineScript;
    std::vector<FrameDef> frames;
    bool loop = false;
    int loopStart = 0;
    int loopEnd = -1;
    int flipFrame = -1;
    bool ignoreAttackId = false;
    bool attackOne = false; // Legacy attackone: stop attack after first detected collision.
    int landFrame = -1;
    int landDust = 0;
    std::string landDustModel;
    int jumpFrame = -1;
    float jumpVelocityY = 0.0f;
    float jumpVelocityX = 0.0f;
    float jumpVelocityZ = 0.0f;
    int throwFrame = -1;
    int tossFrame = -1;
    int projectileOffsetY = 70;
    float projectileVelocityX = 2.0f;
    float projectileVelocityY = 0.0f;
    float projectileVelocityZ = 0.0f;
    std::string custKnife;
    std::string custBomb;
    int weaponFrame = -1;
    int weaponIndex = 0;
    int followAnim = 0;
    int followCond = 0;
    int counterStart = -1;
    int counterEnd = -1;
    int counterCond = 0;
    bool counterTakesDamage = true;
    // v0.26: OpenBOR animation activation ranges used by dynamic combostyle=1.
    bool hasRangeX = false;
    float rangeXMin = 0.0f;
    float rangeXMax = 75.0f;
    bool hasRangeZ = false;
    float rangeZMin = 0.0f;
    float rangeZMax = 0.0f;
    bool hasRangeA = false;
    float rangeAMin = -1000.0f;
    float rangeAMax = 1000.0f;
    std::vector<CancelDef> cancels;
    std::string custEntity;
    int spawnFrame = -1;
    float spawnOffsetX = 0.0f;
    float spawnOffsetZ = 0.0f;
    float spawnOffsetA = 0.0f;
    bool spawnScreenRelative = false;
    bool summonFrame = false;
    int unsummonFrame = -1;
    int quakeFrame = -1;
    int quakeLoops = 0;
    int quakeIntensity = 0;
    std::string hitFx;
    std::string hitFlash;
};
struct PaletteRemapDef { std::string source; std::string target; };
struct CharacterDef {
    std::string sourceFile;
    std::string modelName; // External registry name from models.txt (load/know alias)
    std::string name;      // Internal OpenBOR name from the model file
    std::string type = "none";
    std::string subtype;
    std::string flashModel;
    std::string blockFlashModel;
    bool noAttackFlash = false;
    bool flipFlash = false;
    int health = 100;
    int mp = 0;
    bool globalNoCost = false;
    bool globalBlockRatio = false;
    bool globalMpBlock = false;
    bool noChipDeath = false;
    float knockdownCount = 0.0f;
    float speed = 1.0f;
    float runSpeed = 0.0f;
    int jumpHeight = 4;
    int jumpMoveX = 0;
    int jumpMoveZ = 0;
    int jugglePoints = 4;
    int grabDistance = 30;
    int blockOdds = -1;
    int blockPain = 0;
    int blockThreshold = 0;
    int guardPoints = 0;
    int guardRate = 2;
    bool blockBack = false;
    // v0.24: Combo, follow/counter/cancel, weapons and child-spawn metadata.
    std::vector<int> attackChain;
    int comboStyle = 0;
    int comboDelay = 100;
    std::string subEntityModel;
    int weaponNumber = 0;
    int shootNum = 0;
    int reloadAmount = 0;
    // v0.25: command-input, weapon loss/drop and child lifecycle/follow compatibility.
    std::vector<CommandDef> commands;
    bool weaponLossDefined = false;
    int weaponLossFlag = 0;
    int weaponLossIndex = 0;
    int weaponDropCounter = 3;
    bool typeShot = false;
    bool animalWeapon = false;
    int summonKill = 0;
    float childFollowOffsetX = 0.0f;
    float childFollowOffsetY = 0.0f;
    float childFollowOffsetZ = 0.0f;
    float childFollowRange = 100.0f;
    float childRecallRange = 300.0f;
    // v0.26: per-axis follow/recall and model-copy compatibility.
    float childFollowRangeXMin = -100.0f, childFollowRangeXMax = 100.0f;
    float childFollowRangeYMin = -100.0f, childFollowRangeYMax = 100.0f;
    float childFollowRangeZMin = -100.0f, childFollowRangeZMax = 100.0f;
    float childRecallRangeXMin = -300.0f, childRecallRangeXMax = 300.0f;
    float childRecallRangeYMin = -300.0f, childRecallRangeYMax = 300.0f;
    float childRecallRangeZMin = -300.0f, childRecallRangeZMax = 300.0f;
    float childRecallOffsetX = 0.0f, childRecallOffsetY = 0.0f, childRecallOffsetZ = 0.0f;
    std::string childRecallAnimation = "respawn";
    int childDirectionAdjust = 0;
    int modelCopyFlags = 0; // 1=no_basic, 2=no_weapon, 4=no_script
    // v0.23: Generic OpenBOR AI/faction/grab/projectile behavior.
    int aggression = 0;
    int aiAttack = 0;
    int aiMove = 1;
    int canDamageMask = 0;
    int hostileMask = 0;
    int projectileHitMask = 0;
    bool noGrab = false;
    int grabForce = 0;
    int grabResistance = 0;
    int makeInv = 0;
    std::string playShotNo;
    bool grabBack = false;
    bool grabFinish = false;
    int throwFrameWait = 0;
    bool fastAttack = false;
    int throwDamage = 0;
    float throwDistance = 0.0f;
    float throwHeight = 0.0f;
    int bounce = 0;
    float bounceFactor = 0.5f;
    bool subjectToGravity = false;
    // v0.30: legacy physics/reaction/lifecycle flags still common in older OpenBOR games.
    float antigravity = 0.0f; // normalized 0..1 (legacy 100 => 1.0)
    bool noPain = false;
    bool noDrop = false;
    int noDieBlink = 0;
    bool noQuake = false;
    bool subjectToHole = true;
    bool subjectToWall = true;
    bool noMove = false;
    bool noFlip = false;
    bool noAdjustBase = false;
    int offscreenKill = 0;
    int fallDie = 0;
    int riseTime = 0;
    int riseAttackTime = -50;
    int riseAttackType = 0;
    int freezeMap = 0;
    int removeConfig = 1;
    int throwConfig = 0;
    // v0.27 gameplay parity: legacy per-model presentation/lifecycle/defense metadata.
    int shadow = 1;
    std::string dieSound;
    float lifespanSeconds = 0.0f;
    std::vector<DefenseDef> defenses;
    std::string iconPath;
    std::string iconDiePath;
    bool iconUsesPalette = false;
    bool noLife = false;
    // Popup/entity HUD configuration from lifebarstatus.
    // The old lifeBarStatus flag is retained for ABI/source compatibility with
    // generated runtime code, but the fields below carry the actual OpenBOR values.
    int lifeBarStatus = 1;
    bool lifeBarStatusDefined = false;
    int lifeBarWidth = 100;
    int lifeBarHeight = 5;
    int lifeBarNoBorder = 0;
    int lifeBarType = 0;
    int lifeBarOrientation = 0;
    int lifeBarBorderLayer = 0;
    int lifeBarShadowLayer = 0;
    int lifeBarGraphLayer = 0;
    int lifeBarBackfillLayer = 0;
    int lifePositionX = -1, lifePositionY = -1;
    int namePositionX = -1, namePositionY = -1;
    int iconPositionX = -1, iconPositionY = -1;
    std::string knifeModel;
    std::string bombModel;
    std::string projectModel;
    std::vector<std::string> weapons;
    std::string palettePath;
    std::vector<std::string> alternatePalettes;
    std::vector<PaletteRemapDef> paletteRemaps;
    std::vector<AnimationDef> animations;
    std::string thinkScript;
    std::string updateScript;
    std::string keyScript;
    std::string onMoveXScript;
    std::string onMoveZScript;
    std::string onBlockAScript;
    std::string onBlockYScript;
    std::string onBlockZScript;
    std::string onBlockSScript;
    std::string onBlockWScript;
    std::string onBlockOScript;
    std::string onBlockPScript;
    std::string didBlockScript;
    std::string onDoAttackScript;
    std::string onKillScript;
    std::string onEntityCollisionScript;
    std::string onModelCopyScript;
    std::string animationScript;
    std::string takeDamageScript;
    std::string didHitScript;
    std::string onDrawScript;
    std::string onSpawnScript;
    std::string onDeathScript;
    std::string onPainScript;
    std::string onFallScript;
};

class CharacterParser {
public:
    static CharacterDef parse(const std::filesystem::path& file, const std::filesystem::path& root);
    static std::vector<CharacterDef> parseAll(const std::filesystem::path& dataDir, const std::filesystem::path& root);
};
