#include "PortGenerator.hpp"
#include "NativeRuntimeTemplate.hpp"
#include "RepairPackage.hpp"
#include "CharacterParser.hpp"
#include "GameplayGenerator.hpp"
#include "LevelParser.hpp"
#include "StageGenerator.hpp"
#include "ParityAudit.hpp"
#include "SafePath.hpp"
#include <fstream>
#include <filesystem>
#include <cctype>
#include <stdexcept>


namespace {
void copyTreeSafe(const std::filesystem::path& source, const std::filesystem::path& target){
    std::filesystem::create_directories(target);
    std::error_code ec;
    for(std::filesystem::recursive_directory_iterator it(source, std::filesystem::directory_options::skip_permission_denied, ec), end; it!=end; it.increment(ec)){
        if(ec){ ec.clear(); continue; }
        const auto& entry=*it;
        if(entry.is_symlink(ec)){ if(entry.is_directory(ec)) it.disable_recursion_pending(); continue; }
        auto rel=std::filesystem::relative(entry.path(), source, ec);
        if(ec || !SafePath::isSafeRelative(rel)){ ec.clear(); if(entry.is_directory(ec)) it.disable_recursion_pending(); continue; }
        auto dest=target/rel;
        if(entry.is_directory(ec)) std::filesystem::create_directories(dest,ec);
        else if(entry.is_regular_file(ec)){
            std::filesystem::create_directories(dest.parent_path(),ec);
            ec.clear();
            std::filesystem::copy_file(entry.path(),dest,std::filesystem::copy_options::overwrite_existing,ec);
        }
        ec.clear();
    }
}
}

void PortGenerator::generate(const ScanReport& report, const CompatibilityReport& compatibility,
                             const std::filesystem::path& outDir) {
    if(report.hasDataDir && SafePath::isWithin(report.dataDir, outDir))
        throw std::runtime_error("Output folder must not be inside the source data/ directory.");
    std::filesystem::create_directories(outDir / "assets");
    std::filesystem::create_directories(outDir / "runtime");
    std::filesystem::create_directories(outDir / "config");
    std::filesystem::create_directories(outDir / "reports");

    if (report.hasDataDir) {
        auto target = outDir / "assets" / "openbor-data";
        std::filesystem::create_directories(target);
        copyTreeSafe(report.dataDir, target);
    }

    std::ofstream cfg(outDir / "config" / "port.ini");
    cfg << "[port]\nformat_version=3\nsource=OpenBOR\nruntime=native-cpp\nbuilder=0.34.13\ncompatibility_scan=true\nai_repair_package=true\n"
        << "logical_width=" << compatibility.logicalWidth << "\nlogical_height=" << compatibility.logicalHeight << "\n";
    std::ofstream videoCfg(outDir / "config" / "openbor-video.ini", std::ios::trunc);
    videoCfg << "logical_width=" << compatibility.logicalWidth << "\nlogical_height=" << compatibility.logicalHeight << "\n";

    std::ofstream rep(outDir / "reports" / "compatibility.txt");
    rep << "OpenBOR Native Builder - Compatibility Report\n";
    rep << "Files: " << report.files << "\nImages: " << report.images << "\nAudio: " << report.audio
        << "\nText/script-like: " << report.text << "\n";
    rep << "models.txt: " << (report.hasModels ? "OK" : "MISSING") << "\n";
    rep << "levels.txt: " << (report.hasLevels ? "OK" : "MISSING") << "\n";
    rep << "Scanned text files: " << compatibility.scannedTextFiles << "\n";
    rep << "Recognized commands: " << compatibility.recognizedCommands << "\n";
    rep << "Unknown commands: " << compatibility.unknownCommands << "\n";
    rep << "Issues: " << compatibility.issues.size() << "\n\n";
    for (const auto& issue : compatibility.issues) {
        rep << '[' << CompatibilityAnalyzer::levelName(issue.level) << "] "
            << issue.file.generic_string() << ':' << issue.line << " command=" << issue.command
            << " - " << issue.message << "\n";
    }
    for (const auto& w : report.warnings) rep << "[WARNING] " << w << "\n";

    std::ofstream commands(outDir / "reports" / "command-usage.csv");
    commands << "command,count\n";
    for (const auto& [name, count] : compatibility.commandUsage) commands << name << ',' << count << "\n";

    std::ofstream special(outDir / "reports" / "openbor-special-files.txt");
    special << "OpenBOR special/global files audit\n\n";
    special << "menu.txt: " << (report.hasMenu ? "FOUND - preserve/parse further for renamekey/disablekey and menu behavior" : "not present - native fallback menu will be generated") << "\n";
    special << "video.txt: " << (report.hasVideo ? "FOUND - preserved; native D3D11 renderer settings are generated separately in graphics.ini" : "not present") << "\n";
    special << "lifebar.txt: " << (report.hasLifebar ? "FOUND - preserved; custom lifebar layout still partial" : "not present") << "\n";
    special << "script.txt: " << (report.hasScriptConfig ? "FOUND - scripting compatibility required" : "not present") << "\n";
    special << "bgs/title.(gif/png/bmp): " << (report.hasTitleBackground ? "FOUND - used as native main-menu background (first image/frame path)" : "not present - generated menu uses fallback background") << "\n";
    special << "bgs/select.(gif/png/bmp): " << (report.hasSelectBackground ? "FOUND - preserved; native Character Select is generated (exact legacy layout may differ)" : "not present") << "\n";
    special << "bgs/loading/loading2: " << (report.hasLoadingBackground ? "FOUND - used by native loading flow when available" : "not present") << "\n";

    std::ofstream audioReport(outDir / "reports" / "audio-compatibility.txt");
    audioReport << "OpenBOR Native Builder 0.34.13 - Audio Compatibility Report\n";
    audioReport << "Supported directly: legacy .bor ADPCM plus PCM/float WAV.\n";
    audioReport << "Windows compressed-audio backend: Media Foundation decodes MP3/FLAC and attempts OGG/OGA/AAC/M4A when a system codec is available, then XAudio2 plays decoded PCM.\n\n";
    if (report.hasDataDir) {
        for (const auto& e : std::filesystem::recursive_directory_iterator(report.dataDir)) {
            if (!e.is_regular_file()) continue;
            auto ext=e.path().extension().string(); for(auto& c:ext)c=(char)std::tolower((unsigned char)c);
            if(ext==".bor"||ext==".wav"||ext==".ogg"||ext==".mp3"||ext==".flac") {
                auto rel=std::filesystem::relative(e.path(), report.root).generic_string();
                const char* status=(ext==".bor"||ext==".wav")?"NATIVE":"WINDOWS_MEDIA_FOUNDATION";
                audioReport << status << "\t" << rel << "\t" << std::filesystem::file_size(e.path()) << " bytes\n";
            }
        }
    }

    std::ofstream graphicsReport(outDir / "reports" / "graphics-backend.txt");
    graphicsReport << "OpenBOR Native Builder v0.34.13 - Graphics Backend\n\n";
    graphicsReport << "Windows primary backend: Direct3D 11 final-frame post-processing with hardware device, WARP fallback and Win32/GDI presentation fallback.\n";
    graphicsReport << "UI layer: Direct2D + DirectWrite on the logical OpenBOR surface. Sprite decoding remains WIC-compatible and preserves OpenBOR palette-index-0 transparency.\n";
    graphicsReport << "Upscale modes: original/nearest, sharp-bilinear, CAS-style sharpen, xBRZ-like edge-aware smoothing.\n";
    graphicsReport << "Filters: CRT mask, scanlines, optional curvature, bloom, contrast, saturation, banding reduction, configurable sharpen.\n";
    graphicsReport << "Image modes: pixel-perfect, keep 4:3, crop-fill 16:9 without stretching, integer 2x/3x/4x, nearest/bilinear.\n";
    graphicsReport << "Performance: V-Sync on/off, 60/120/144/unlimited FPS, presets Original/Improved/CRT/Sharp.\n";
    graphicsReport << "Important: GPU post-processing runs after gameplay rendering, so hitboxes, physics, entity coordinates and OpenBOR timing data are not modified by the filters.\n";

    std::ofstream inputReport(outDir / "reports" / "input-multiplayer.txt");
    inputReport << "OpenBOR Native Builder v0.34.13 - Input / Local Multiplayer\n\n";
    inputReport << "Players: native local simulation supports 1-4 players in the generated runtime.\n";
    inputReport << "Character Select: P1 is always available; P2-P4 can join with A/Start and leave with B. Each joined pad can change character with D-pad left/right.\n";
    inputReport << "Keyboard: P1 movement/actions are remappable in the Controls menu and persisted in graphics.ini.\n";
    inputReport << "Gamepad: attack/jump/pickup/dash/grab/throw button masks are remappable; controller slot 1-4 is selectable per local player.\n";
    inputReport << "Gameplay: extra local players have independent position, animation, HP, attack/jump state, enemy targeting, damage reception and HUD bars.\n";
    inputReport << "Save/Continue: active party, selected characters and HP are preserved in saves/slot1.sav.\n";
    inputReport << "Known partial areas: advanced per-player weapon ownership, grab/throw ownership and exact OpenBOR multiplayer edge cases remain compatibility work.\n\n";

    std::ofstream scriptReport(outDir / "reports" / "script-vm-compatibility.txt");
    scriptReport << "OpenBOR Native Builder v0.34.13 - Script VM Compatibility\n\n";
    scriptReport << "Implemented syntax: C-like main(), variables, assignments, arithmetic/comparison/logical/bitwise expressions, if/else, for/while/do, switch/case, ternary expressions, break/continue/return, arrays, string/number/bool literals, plus object-like/function-like #define and #include/#import preprocessing.\n";
    scriptReport << "Implemented VM storage: local/global variables and persistent per-entity local context.\n";
    scriptReport << "Host APIs: openborconstant/openborvariant/changeopenborvariant, getentity/findtarget/checkrange, get/changeentityproperty, get/set/clearentityvar, get/changeplayerproperty/playerkeys, clear/setspawnentry+spawn, performattack/setanimation/setidle/updateframe, damageentity, killentity, jumptobranch, playmusic/pausemusic, loadsample/playsample/unloadsample, log plus local/global/indexed var helpers.\n";
    scriptReport << "Hooks wired: think, update, keyscript/global keyN.c/keyall.c, onmovex/onmovez, entity-collision, animation (on frame entry), spawnscript, take-damage, did-hit, on-draw, on-spawn, on-death, on-pain and on-fall.\n";
    scriptReport << "Fallback: unmapped engine APIs are logged diagnostically and preserved in AI-Repair instead of being silently dropped.\n\n";
    if (report.hasDataDir) {
        for (const auto& e : std::filesystem::recursive_directory_iterator(report.dataDir)) {
            if (!e.is_regular_file()) continue;
            auto ext=e.path().extension().string(); for(auto& c:ext)c=(char)std::tolower((unsigned char)c);
            if(ext==".c"||ext==".h") scriptReport << "VM_CANDIDATE\t" << std::filesystem::relative(e.path(), report.root).generic_string() << "\n";
        }
    }

    auto characters = CharacterParser::parseAll(report.dataDir, report.root);
    GameplayGenerator::generate(characters, outDir);
    auto stages = LevelParser::parseAll(report.dataDir, report.root);
    StageGenerator::generate(stages, outDir);
    NativeRuntimeTemplate::generate(outDir);
    ParityAudit::writeMarkdown(outDir / "reports" / "openbor-parity.md");
    RepairPackage::generate(report, compatibility, outDir);

    std::ofstream readme(outDir / "README-PORT.txt");
    readme << "Generated by OpenBOR Native Builder 0.34.13\n\n";
    readme << "This project contains the preserved OpenBOR assets, compatibility diagnostics, an AI repair package and a compilable C++ runtime skeleton.\n";
    readme << "Character, animation, frame, delay, offset, bbox and basic attack data are translated into generated C++ structures. The preview runtime now plays frame timing, loads sprite images on Windows through WIC, applies OpenBOR offsets and can draw bbox/attack debug overlays. Legacy OpenBOR palette-index transparency is emulated before presentation; source alpha/shadows are preserved. Windows ports now use a Direct3D 11 post-process backend with Direct2D/DirectWrite UI, hardware/WARP/GDI fallback, selectable upscale modes, CRT/image filters, pixel-perfect/aspect/integer scaling, V-Sync and graphics presets. Legacy .bor music is now identified as OpenBOR ADPCM and decoded to PCM before playback; raw .bor bytes are never sent to XAudio2. Music/effects/master volumes are separated in runtime configuration. v0.5 adds PCM WAV decoding, WAV smpl loop metadata, automatic preview-music selection, config loading, runtime volume hotkeys and an audio compatibility report. v0.6 adds levels.txt parsing, generated native stage data, background loading, stage music selection, player start positions, keyboard movement, camera scrolling, Z-lane clamping and spawn triggers with basic enemy preview entities. On Windows, MP3/FLAC and other compressed formats use Media Foundation; OGG is attempted when a system codec is present. Non-Windows generated runtimes still preserve unsupported compressed audio with diagnostics.\n";
}
