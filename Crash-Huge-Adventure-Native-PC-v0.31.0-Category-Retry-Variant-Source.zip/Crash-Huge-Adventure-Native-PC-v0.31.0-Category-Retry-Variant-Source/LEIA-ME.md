# Crash Bandicoot: The Huge Adventure — port nativo PC, v0.31.0

Este projeto converte o jogo para um runtime **C++ nativo de PC**. A ROM USA ACQE é usada como fonte de dados, áudio, gráficos e tabelas. O runtime não executa código ARM do GBA e não é um emulador.

## O avanço da v0.31

A v0.31 corrige um erro estrutural na leitura do `category_descriptor`. Os campos `+0x20..+0x30` deixam de ser tratados como seletores genéricos e passam a ter a semântica real do jogo: `maskAssistDeaths`, `bonusKindDeaths`, `retryBossDeaths`, `bossLevel` e `retryBossLevel`. Com isso, `kind`, `altKind` e `bonusKind` deixam de ser misturados e os retries passam a usar os perfis corretos dos bosses.

### Variantes e retries por descriptor

O runtime agora mantém o kind selecionado de cada evento em cache. Normal usa `kind`; Time Trial usa `altKind` com os folds originais; somente após o threshold de mortes o retry usa `bonusKind`. As mortes de categoria e de boss são contadas separadamente, e um retry reconstrói os eventos posteriores ao checkpoint sem transformar atores já ativos no meio do frame.

### Assist e perfis de boss

Nas categorias Jetpack, ao atingir `maskAssistDeaths`, o HP máximo passa de 100 para **120**, e curas de ring/health crate continuam sendo 20% do máximo. Airship agora possui os **6 registros** da tabela original (3 normais + 3 de retry), e o Hovercraft troca do perfil 0 para o perfil 1 quando `retryBossDeaths` é atingido; isso muda HP dos side guns e timings de ataque.

### Corrigido também

O fold Polar de Time Trial não converte mais kind 23 em 20: o dispatcher original mantém 23. Waypoints do Plane passam a consultar o kind já selecionado/cached, evitando divergência entre a rota usada pelo ator e a variante ativa da categoria.

## Mantido da v0.30

A v0.30 fechou a camada de fidelidade de SFX do Jetpack/Hovercraft: os efeitos sonoros de gameplay passam por **callbacks exatos do ator para a tabela GAX da ROM**. O evento preserva ID, volume e voz quando o original exige, além de manter duas chamadas no mesmo frame quando elas realmente existem no código do jogo.

### SFX por callback de ator

O runtime agora possui `playSfxId()` e uma fila `OriginalSfxEvent`. Entre os callbacks já ligados estão tiro `0x24` com volume `0xA0`/voz 2, dano do player `0x42`, ambiência bomber `0x37`, balloon pop `0x2E`, Rocket `0x2D`/`0x04`, Ring `0x3E`, Plane `0x25`, Airship hit `0x43` + queda `0x42`, Hovercraft hit `0x45`, Wumpa ao HUD `0x0E` e FinishJetpackRun `0x3B`. A morte de uma peça do Hovercraft preserva as **duas chamadas `0x04`** da sequência original.

### FinishJetpackRun real nas rotas 3/4/5

Ao alcançar o fim da rota, o Jetpack agora entra primeiro no state 5, toca `0x3B` e executa a saída em profundidade. `complete` só é marcado quando esse estado termina, em vez de encerrar instantaneamente no threshold.

## Mantido da v0.29

### Balão filho destrutível e queda do crate

Tiros do player agora testam primeiro o balão 40/41/42 ligado ao crate. No segundo acerto, o balão entra na animação 1 de estouro e o crate pai passa ao state 1 de queda. A queda usa a aceleração original `+0x12` Q8 por frame, limitada a `0x4C0`, e o crate é removido ao ultrapassar Y `0xE100`.

Se o crate em queda for atingido depois, ele ainda pode resolver seu reward normal, mas **não conta uma segunda caixa quebrada e não recria/libera outro balão**. O balão que foi liberado por uma quebra normal também mantém os **2 HP** e pode ser estourado por tiros durante o float-away. Isso preserva o ciclo completo do ator filho e o encadeamento filho → callback → pai do jogo original.

## Mantido da v0.28

### Wumpas voando para o HUD

A fila de reward continua usando cooldown `0x0F` e lotes 1/2/4/8, mas agora cada lote cria o **kind 44** visual. O efeito segue a matemática confirmada de `CreateJetpackCollectedWumpa`: mira `(16,16)` e só credita a quantidade ao chegar ao HUD. Em estado inativo/finalização, a fila restante continua sendo creditada imediatamente.

### Balloon crates

Health/question/time crates entram em state 2 / anim 1 antes da remoção. Question crates usam a fila 1/3/5, e os balões filhos 40/41/42 agora aparecem na cena. Ao quebrar o crate, o balão é liberado e sobe até sair da tela em vez de desaparecer no mesmo frame.

### Parachute Nitro e Rocket

O Parachute Nitro sobe reto a partir de Y=-250 em passos `0x140`; a oscilação X artificial foi removida. O Rocket agora usa dano 14, box ativada 42×42, órbita/step Y confirmados e animações separadas para trigger normal e destruição por tiro.

### Hovercraft palette

O flash foi separado em dois sistemas, como no original: o hit-flash de 12 ticks atua no medidor, enquanto `RunHovercraftState` alterna somente o **índice 15** da palette do boss/parts nos frames 8/16. Como kinds 11/12/13 usam palette bank 10, o renderer consegue substituir esse índice diretamente durante a decodificação RGBA.

## Mantido das versões anteriores

- GAX2 com 19 músicas, tabela original de 3828 períodos, envelopes, vibrato, slides, portamento, sequences, loops, ping-pong, sweep, nearest-neighbor Q11, mixer ARM-style e echo por taps/canais;
- Jetpack held-fire `0x12`, roll estados 2/3, morte estado 4, finish estado 5 e ring state 6;
- reward cycle dos rings 1/5/20 Wumpa → cura → vida, gates `0x14`/`0xBE` e peça visual kind 43;
- plane kind 1 com waypoints reais, bombers 4–9, Airship e Hovercraft;
- Polar com Nitro chain, boost, launcher, goal, Aku-Aku tiers e shock;
- frontend usando céu/menu, plataforma de level select e pause background originais da ROM.

## Ferramentas

- `CrashJetpackTool ROM OUTPUT_BMP`: 6 painéis de diagnóstico, incluindo Wumpa kind 44 em trânsito, Hovercraft e balloon-pop/queda do crate.
- `CrashHovercraftTool ROM OUTPUT_BMP`: estados/partes do boss.
- `CrashPolarTool ROM OUTPUT_BMP`: boost, launcher e goal Polar.
- `CrashAirshipTool ROM OUTPUT_BMP`: Airship e sequência de destruição.
- `CrashGaxTool [ROM]`: músicas, períodos, instrumentos, DSP/echo e SFX.
- demais ferramentas de rota, entidades, frontend e HD permanecem no pacote.

## Validação v0.31.0

- 8/8 suítes strict PASS;
- `make all` PASS com `-Werror`;
- descriptor/retry/bonus + callbacks GAX cobertos em Category/Audio;
- Category / Frontend / Audio passaram ASan + UBSan;
- Windows EXE não foi compilado neste ambiente; use `COMPILAR-WINDOWS.cmd` no Windows x64.

## Controles

| Contexto | Teclas |
|---|---|
| Menu | Cima/Baixo + Enter; Esc sai |
| Warp Room | Esquerda/Direita = portal; Cima/Baixo = andar; Enter = jogar; Esc = menu |
| Sala normal | A/D ou setas; Espaço/Z = salto; X/K = giro |
| Polar | A/D ou setas; Espaço/Z = salto |
| Jetpack/Hovercraft | A/D/W/S; segurar Espaço/Z = tiro automático; Q/E = roll |
| Geral | P pausa; R reinicia; F10 salva; F11 tela cheia; C debug |
| Desenvolvimento | F5 recarrega PNG; F6 escala; F7/F8 troca fase; H alterna PNG/ROM |

## Compilar no Windows

Execute `COMPILAR-WINDOWS.cmd`. Ele procura Visual Studio 2022 / Build Tools, compila `CrashNative.exe`, as ferramentas e executa as oito suítes de teste.

Este ambiente de entrega não possui MSVC/MinGW, portanto o **EXE Windows não foi produzido aqui**. O código portátil e as ferramentas foram compilados aqui em C++17 strict com warnings tratados como erro.

## ROM validada

USA ACQE — SHA-256:
`6be639d1db218ca2bf2b1ff0ee0867334404cead5fb6684af4870d4644a15635`

## Histórico — validação v0.27.0

- 8/8 suítes PASS;
- `-std=c++17 -O2 -Wall -Wextra -Wpedantic -Werror`;
- `make all` PASS;
- `TestCategory`, `TestFrontend` e `TestAudio`: ASan + UBSan PASS;
- cadeia de rings 1/5/20/HP/vida e thresholds `0x14`/`0xBE` cobertos;
- fila de Wumpa 1/2/4/8 coberta;
- ring visual 31+43 ativo;
- Hovercraft cannon/launcher/side-gun com gating de dano específico;
- animações de morte das peças e latch de flash cobertos.

## Próximas pendências fortes

Depois desta correção estrutural, o maior alvo é fechar a **reconstrução de checkpoint/retry da ActorCategory** com a mesma granularidade do original (estado coletado/checkpoint por spawn), antes de voltar para ordem OAM/draw. Em seguida vêm callbacks raros de Jetpack/Airship/Hovercraft e estados raros do GAX2.
