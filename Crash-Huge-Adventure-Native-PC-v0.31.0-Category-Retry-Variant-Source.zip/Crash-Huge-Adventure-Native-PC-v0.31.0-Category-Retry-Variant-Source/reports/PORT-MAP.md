# Estado do port v0.31.0


## v0.31 — descriptor/retry/bonus semantics

- `category_descriptor +0x20..+0x30` agora é lido como `maskAssistDeaths`, `bonusKindDeaths`, `retryBossDeaths`, `bossLevel`, `retryBossLevel`;
- seleção de spawn separada: normal=`kind`, Time Trial=`altKind`, retry por mortes=`bonusKind`;
- kind selecionado fica em cache por evento, impedindo mudança de classe em ator já ativo;
- mortes normais e mortes de boss são contadas separadamente; retry reconstrói eventos após o checkpoint;
- Jetpack assist: HP máximo 120 no threshold e curas continuam em 20% do máximo;
- Airship: 6 profiles originais (3 normal + 3 retry);
- Hovercraft: profile 1 habilitado no `retryBossLevel`, incluindo side guns HP16 e timings alternativos;
- waypoint do Plane usa o kind cached; fold Polar Time Trial de kind 23 corrigido.

## v0.30 — exact GAX SFX callbacks

- fila ordenada `OriginalSfxEvent` no runtime de ActorCategory;
- playback direto por ID original (`playSfxId` / `sfxId`);
- tiro 0x24/A0/voice2, dano player 0x42, bomber ambience 0x37, Wumpa HUD 0x0E, balloon 0x2E, crate 0x03/0x07/0x18, rocket 0x2D/0x04, ring 0x3E, plane 0x25;
- Airship hit 0x43 + queda 0x42 e Hovercraft hit 0x45; morte de part preserva duas chamadas 0x04;
- route end Jetpack 3/4/5 passa por FinishJetpackRun state 5 + 0x3B.


## v0.29 — linked balloon HP / pop / parent fall

- Child balloons 40/41/42 attached to Jetpack crates now carry their own **2 HP** runtime state.
- Player shots resolve against the child balloon before the parent crate, using the child actor box read from ROM.
- The second hit creates the child balloon's animation 1 pop actor and runs the parent callback: crate state 1, fall speed reset to zero.
- Parent fall advances by current speed, then adds `0x12` Q8/frame, capped at `0x4C0`; removal threshold is Y `0xE100`.
- Breaking a crate after its balloon has already popped still awards the crate's effect, but does not increment the broken-crate counter twice and does not spawn a replacement/released balloon.
- Normal crate break/collection still releases an intact child balloon into the existing float-away state from v0.28; this released actor keeps 2 HP and remains shootable until popped or off-screen.
- `CrashJetpackTool` gains a sixth diagnostic panel for the linked-balloon pop/fall chain.


## v0.26 — Hovercraft weapons + Jetpack death/finish

- Side guns agora criam fireball kind 39 real: HP2, speed `0x95`, decay -5 até `0x14`, dano 6 e animação de morte ROM.
- Cannon usa cannonball kind 3 com projeção `angle/scale`, limite `0xFFF`, dano 2 e Z `-0x100`.
- Projéteis com actor kind usam AABB, sprite e baseDepth da ROM.
- Player Jetpack: state 4 death/fall com respawn atrasado, state 5 finish e state 6 ring boost.
- Hovercraft desaparecendo não conclui a fase sozinho; completion vem do state 5 em depth `>0xA000`.
- Ring alinha o player ao centro, zera velocidades e retorna ao voo no tick `0x32`.
- Bombers do launcher mantêm kinds 5/6/8 reais e ordem de update foi aproximada ao original.
- `CrashJetpackTool` ampliado para held-fire, death/fall, armas Hovercraft e finish.

## v0.25 — Jetpack states + Hovercraft launcher actors

- O runtime Jetpack agora atende `type != 0`, corrigindo a Category 6 no loop normal.
- Player Jetpack: voo estado 1, rolls estados 2/3, autofire por botão held a cada `0x12`, impulso/retorno Q8 e imunidade até `0x10`.
- Bomber kinds 4–9 recebem o `+0x60` Z comum; kind 9 fica em `-0x28` Q8 líquido.
- Plane kind 1 percorre as cadeias de target da ROM (markers 32–37), depois entra no home targetless; cannonball usa a projeção original 20/60.
- Plane usa death state 2 -> fall state 3; bombers 4–9 usam animação de morte antes da remoção.
- Hovercraft cannon/launcher só recebem dano nos estados ativos.
- Launcher usa a checagem projetada e cria atores kinds 5/6/8 com RNG da família `RandRange(3)`, 2 HP e animação de morte ROM.
- Fim do Hovercraft: Y `>0x4B00` arma o finish; singleton some apenas em depth `<=0x14FF`.
- Polar finish-leap passa a usar 184 frames derivados de `0x2F00`, `0x03FF` e passo `0x3C`, em vez de literal 185.
- Nova ferramenta `CrashJetpackTool`.

## v0.24 — GAX echo nativo + callbacks Polar

- Replayer GAX agora trabalha internamente na taxa original de cada song.
- Sample cursor/step do mixer usam Q11 inteiro e a tabela original de 3828 períodos.
- Echo GAX2 traduzido para C++: ring buffer signed 16-bit, até 3 taps, delay em ms convertido na taxa da música e ganho Q4.
- O mixer separa `dspPrimaryChannels` dos canais secos, seguindo o fluxo do `GaxMixerPlay` original.
- O fluxo normal de `StartSong` usa flags zero; por isso SFX continuam secos e o bloco opcional FILT não é habilitado artificialmente.
- Polar: kinds 4/9/12/13/16/18/20/22/23/24/25/28-31 deixaram de cair em callbacks genéricos e ganharam comportamento específico.
- Mask tier, invulnerabilidade `0x4B`, shock `0x2D`, boost `0x1E`, goal `0x16` e Nitro chain no tick `0x14` estão modelados.
- Nova ferramenta `CrashPolarTool` para diagnóstico rápido de boost/launcher/goal.

## Runtime nativo

O runtime é C++ nativo e não executa ARM do GBA. A ROM é fonte de dados, áudio, gráficos e tabelas. Gameplay normal, salas, player, entidades, save, time trial, actor-categories 0–6, Airship, Hovercraft, frontend e overrides HD continuam ativos.

## Áudio GAX2

- 19 músicas lidas da ROM ACQE.
- 52 instrumentos musicais / 52 envelopes.
- 29 waves PCM musicais não vazias.
- 88 instrumentos/envelopes SFX e 99 rotas.
- Pattern pitch e instrument-sequence pitch separados.
- Envelopes, sustain/loop, vibrato, portamento, pitch/volume slide, note delay, sequence FX, sample loop, ping-pong e sweep modelados.
- Tabela original de períodos localizada em `0x5A4300`.
- Mixer: PCM signed 8-bit -> volume Q8 -> acumulação signed 16-bit -> downmix ARM-style -> signed 8-bit -> host PCM.
- Echo confirmado em faixas específicas: menu EUR, cutscenes, Warp Room e credits.
- Jetpack Shot: ambient SFX `0x24`, voice 2, volume `0xA0`, retrigger forçado.
- Level select: `0x48` navegação, `0x52` confirmar, `0x51` abertura, `0x49` saída.

### Ainda parcial no áudio

O replayer já cobre o caminho usado pelas faixas normais com muito mais fidelidade, mas ainda não é declarado bit-exact. Casos raros de scheduling/envelope/sweep podem divergir, e o PC não replica o hardware Direct Sound/FIFO do GBA. O bloco FILT foi identificado, porém não é ativado no fluxo normal do jogo porque os flags originais permanecem zero.

## Polar

### Factory/callbacks corrigidos

- 4: Nitro.
- 5/6/7: time crates 1/2/3 s.
- 8/35: extra life.
- 9: Aku-Aku crate.
- 12: boost pad.
- 13: hazard persistente.
- 16/18/20: icicles.
- 22: launcher.
- 23: electric fence.
- 24: penguin.
- 25: goal.
- 28/29/30: question crates 1/3/5 Wumpas.
- 31: question crate Aku-Aku.

### Estado do jogador Polar

- mask tier 0–3;
- hit com mask: remove um tier e arma 75 frames (`0x4B`) de invulnerabilidade;
- tier 3: janela longa de invulnerabilidade;
- shock sem mask: 45 frames (`0x2D`) antes da perda de vida;
- boost: 30 frames (`0x1E`) com velocidade elevada;
- launcher: arco próprio, sem dano genérico;
- goal: inicia `FinishPolarRun` com timer `0x16`;
- Nitro: estado usado `0x12`, box original e chain scan no tick `0x14`.

A animação completa de fim da rota Polar ainda é uma abstração nativa; a próxima rodada pode aprofundar a sequência estado-10/finish-leap e os efeitos visuais do original.

## Frontend

- `gMenuSkyBg` original no level select.
- `gLevelSelectPageBg` original na plataforma.
- `gPauseMenuBg` original na pausa.
- Warp Room mantém agrupamento, bloqueios e progressão do port nativo.

## Bosses/actor categories

- Category 0–2: Polar, agora com callbacks bem mais específicos.
- Category 3–5: Jetpack/Airship.
- Category 6: Hovercraft.
- Airship mantém a sequência de 10 explosões em 1/2/3/4 bursts e queda no tick 170.
- Hovercraft continua funcional, porém ainda há comportamento de partes/projéteis a aproximar do original.

## Validação v0.24 (histórico)

- 8/8 suites strict PASS.
- Audio/Category/Frontend ASan + UBSan PASS.
- `CrashGaxTool` strict PASS.
- `CrashPolarTool` strict PASS.
- Windows EXE não compilado neste ambiente; build script atualizado para Visual Studio 2022 x64.

## v0.27 — Jetpack ring rewards / Hovercraft part lifecycle

- `PassJetpackRing`: reward chain 1/5/20 Wumpa, 20% heal, life; <=0x14 gate; >0xBE chain reset.
- `DispenseJetpackWumpa`: queued reward cooldown 0x0F and 1/2/4/8 drain tiers; inactive state drains all.
- `UpdateJetpackRing`: native state-6 alignment preserved; ring kind 31 now renders its paired kind-43 visual actor without a second collision trigger.
- `StartHovercraftHitFlash` / `UpdateHovercraftHitFlash`: 12-tick shared hit-flash latch/toggle state.
- `DamageHovercraftCannon`: cannon no longer incorrectly requires fire-active state to take damage.
- `DamageHovercraftLauncher`: launcher remains damageable only in active state 1.
- `DamageHovercraftSideGun`: side guns remain damageable while alive.
- Attached parts now decrement `partsLeft` immediately but stay in their ROM death animation until its duration completes.


## v0.28 — HUD Wumpa / balloon crates / Rocket-Parachute / palettes

- Reward queue cria ator kind 44 e só chama o equivalente a `CollectWumpa` na chegada ao HUD.
- Crates 19–26/29 usam break state 2 + anim 1; kinds 20/21/22 alimentam a queue 1/3/5.
- Child balloons 40/41/42 são desenhados presos aos crates e liberados em state float-away ao quebrar.
- Parachute Nitro: Y inicial -250, subida reta `0x140`, dano 20, anim 1.
- Rocket: dano 14, órbita original, step Y derivado de 198 frames, box trigger 42x42, anim 1/2 conforme trigger/dano.
- Hovercraft: hit-flash do medidor separado do flash periódico do índice 15 da palette; banks 10 dos kinds 11/12/13 são substituídos diretamente no decode host.
