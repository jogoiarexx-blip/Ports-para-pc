# Referências e origem dos dados

- ROM USA ACQE enviada pelo usuário; todos os recursos deste pacote foram lidos dela.
- [CrashBandicootXS-decomp](https://github.com/Almamu/CrashBandicootXS-decomp), de Almamu e colaboradores, commit `1f417177c20de6836370ecaa0a9f266923e56bbe`. Consultados os layouts documentados de bancos de sprites, peças, sequências, paletas e mapas de salas, além dos leitores de cache de paletas. O projeto trabalha com a ROM europeia e ainda está em andamento.
- [Formato de salas](https://github.com/Almamu/CrashBandicootXS-decomp/blob/1f417177c20de6836370ecaa0a9f266923e56bbe/docs/levels.md).
- [Layout dos bancos](https://github.com/Almamu/CrashBandicootXS-decomp/blob/1f417177c20de6836370ecaa0a9f266923e56bbe/include/sprite_bank.h).
- [Leitor de cache de paletas](https://github.com/Almamu/CrashBandicootXS-decomp/blob/1f417177c20de6836370ecaa0a9f266923e56bbe/src/graphics/graphics.c).
- [GBATEK](https://mgba-emu.github.io/gbatek/): formatos de tiles e cores de GBA.

O código C++/Python da prévia foi escrito para este port com verificações de limites. Não foi copiado o código-fonte nem o conteúdo gráfico da decompilação de referência. Os endereços europeus serviram de pista; a descoberta e a validação foram realizadas sobre os bytes da ROM americana fornecida.

## Referências adicionais usadas até a v0.19.0

- `src/data/actor_category_175558.c`: descritores e vtable das 7 actor-categories.
- `src/graphics/actor_part101.c` / `actor_part103.c`: inicialização da category, ordem de spawn e leitura do threshold do próximo registro.
- `src/graphics/actor_part_2ac28.c`: factory `sub_802AC28` e seleção dos kinds de atores.
- `include/actor_anim.h` e `src/graphics/actor_anim.c`: `table_A`, `table_B`, frames, duração/loop e lookup no sprite sheet descompactado.
- `src/graphics/sprite_frame_queue.c`: frames brutos dos atores comuns e cache/VRAM do sheet LZ.
- `src/iwram/sprite_arm.c` / `tools/rle_sprites.py`: formato zero-run RLE `0x30` usado pelo Crash montado.
- `src/graphics/actor_part50.c`: `InitActorPart`/`sub_802A7B8`, profundidade e avanço das animações.
- `src/graphics/graphics_loading_1ea5c.c`: tipo 7 -> bank 37 e condição de progresso da gema.
- `src/graphics/actor_part102.c` / `actor_part94.c`: seleção `variantA/B/C`, thresholds e modos das sub-effects.
- `src/system/game_loop2.c`: flags de conclusão, relógio, `TickLevelClock` e estado de time trial.
- `src/graphics/graphics_loading_21d80.c`: entidade tipo 16, master asset record 36 (`+0x1B0`).
- `src/data/dispatch_table_16c6a4.c`: dispatch unificado de 92 tipos de entidade.
- `src/graphics/actor_part19*.c`: callbacks confirmados de Wumpa/caixas/freeze e objetos usados pelas actor-categories.



## Áudio — v0.19.0

- Shin’en GAX Sound Engine specification / research note (loveemu): estrutura geral de música, tags `"Title" © Author`, samples e diferenças do layout GAX v2.
- `shinen-gax-python` (beanieaxolotl): usado como referência cruzada para scanners e constantes de versões GAX posteriores; não foi copiado como backend do port.
- A implementação audível da v0.19.0 é própria e sintetizada; o catálogo de 19 faixas é obtido diretamente da ROM enviada pelo usuário.

## Áudio — v0.20.0

Referência cruzada adicional: branch pública atual de `Almamu/CrashBandicootXS-decomp`, consultada em 2026-10-05, especialmente `docs/audio.md`, `sound/gax_manifest.json`, `lib/gax/src/gax_internal.h`, `gax_sound_handler_info.c`, `gax_sound_handler_channel_play.c`, `gax_channel_note_scheduler.c`, `gax_note_trigger.c`, `src/data/song_table_16aa20.c` e `include/audio.h`.

Esses arquivos foram usados para confirmar a semântica das estruturas GAX2 e dos comandos. O código do replayer deste port foi escrito separadamente para ler a ROM ACQE do usuário; endereços USA foram descobertos/validados nos bytes da ROM, não copiados dos endereços EUR da referência.


## Áudio e frontend — v0.21.0

A v0.21 cruzou a ROM ACQE com a branch pública atual de `Almamu/CrashBandicootXS-decomp`, em especial `lib/gax/src/gax_channel_envelope_tick.c`, `gax_note_lookup.c`, `gax_channel_effect_table.c`, `gax_channel_pos_sweep.c`, `gax_channel_note_cut_driver.c`, `gax_voice_steal.c`, `gax_channel_bind_instrument.c`, `gax_channel_note_scheduler.c`, `sound/sfx_table.json`, `src/data/bg_package_16c58c.c`, `data/data.s` e `include/graphics_package.h`.

Essas referências foram usadas para confirmar a semântica do GAX2 e identificar a composição palette/tiles/tilemap. O replayer e o decodificador deste port foram escritos para ler diretamente a ROM ACQE fornecida pelo usuário. O port não executa o código ARM da biblioteca GAX original.

## Áudio e frontend — v0.22.0

A v0.22 consultou a branch pública atual de `Almamu/CrashBandicootXS-decomp`, principalmente `lib/gax/data/gax_tables_5a6100.c`, `lib/gax/src/gax_note_trigger.c`, `lib/gax/src/gax_channel_mute_volume.c`, `src/menus/level_select.c`, `src/menus/level_select_pages.c`, `src/data/bg_package_16c484.c`, `src/data/bg_package_16b284.c`, `src/data/bg_package_16c58c.c`, `data/data.s` e `docs/graphics.md`.

A referência foi usada para confirmar a forma da tabela de períodos, a semântica de volume do GAX e quais pacotes gráficos/SFX pertencem ao level select e à pausa. A tabela de período e os gráficos usados no runtime são lidos dos bytes da ROM ACQE fornecida pelo usuário; o port não incorpora nem executa o código ARM da referência.

## Referências consultadas para v0.23

Repositório público `Almamu/CrashBandicootXS-decomp`, ramo corrente consultado em 2026-10-05:

- `lib/gax/src/gax_unknownc_play.c`: bytes ARM de `gGaxArmResample`, `gGaxArmDownmix` e fluxo do mixer.
- `lib/gax/src/gax_note_trigger.c`: volume Q8, tabela de período, sample position e loop/sweep.
- `src/vehicle/jetpack_spawn.c`: tiro do jogador via `PlayAmbientSfx(..., 0x24, 1000, 0xA0, force=1)`.
- `src/bosses/airship_explode.c`: bursts de destruição nos ticks 0x0A/0x32/0x50/0x6E e transição em 0xAA.
- `src/bosses/airship_damage.c` / `airship_fall.c`: dano, velocidade de queda e encerramento do boss.
- `src/util/rand.c`: LCG usada por `RandRange`.

## Referências consultadas para v0.24

Repositório público `Almamu/CrashBandicootXS-decomp`, branch corrente consultada em 2026-10-05:

- `lib/gax/src/gax_unknownc_play.c`: ordem de mixagem, `GaxMixerPlay`, `GaxMixFrame`, ARM downmix/echo/resampler.
- `lib/gax/src/gax_channel_table_alloc.c`: conversão dos DSP taps para step em bytes e leitura do ganho.
- `lib/gax/src/gax_playstart.c`: alocação do echo buffer, flags `fxEcho`/FILT e fluxo normal de inicialização.
- `lib/gax/include/gax.h`: parâmetros/flags de `GaxSongHeader`.
- `src/audio/audio.c`: `StartSong`, confirmando que o fluxo normal parte dos defaults de `GAX2_new` e não habilita FILT/FX echo.
- `src/actor/actor_factory.c`: factory dos kinds Polar e seus construtores corretos.
- `src/vehicle/polar_pickups.c`, `polar_crates.c`, `polar_nitro.c`: question/time/life/Nitro crates e chain de Nitros.
- `src/vehicle/polar_aku_aku.c`: Aku-Aku, boost pad, goal e checkpoint.
- `src/vehicle/polar_objects.c`: launcher, electric fence, penguin e icicles.
- `src/vehicle/polar_player.c`, `polar_player_states.c`, `polar_player_actions.c`: mask tiers, invulnerabilidade, shock, boost e sequência de finish.
- `src/data/actor_tables_17a728.c`: box original de Nitro e dados auxiliares do Polar.

Essas referências servem para confirmar estruturas e semântica. O runtime deste port lê a ROM ACQE fornecida pelo usuário e implementa o comportamento em C++ portátil; ele não executa nem incorpora o código ARM original.


## Referências consultadas para v0.25

Repositório público `Almamu/CrashBandicootXS-decomp`, branch corrente consultada em 2026-10-05:

- `src/vehicle/jetpack_spawn.c`: estados 1/2/3 do player, held-fire `0x12`, roll `0x100`/`0x2D`, janela de dano `0x10`.
- `src/vehicle/jetpack_plane.c`: plane kind 1, bombers 4–9, common Z `+0x60`, kind 9 `-0x88`, HP e death states.
- `src/data/actor_pmf_17c260.c`: tabelas de estados de plane e bomber.
- `src/iwram/iwram_data.c`: velocidades `gUnknown_0300089C`.
- `src/bosses/hovercraft_launcher.c`: gating do launcher, range projetado, `RandRange(3)` e criação dos kinds 5/6/8.
- `src/bosses/hovercraft_side_gun.c`: HP, offsets e burst timing das side guns.
- `src/bosses/hovercraft.c` / `hovercraft_parts.c`: estados do singleton e condição final de queda/remoção.
- `src/actor/actor_spawn.c` e `include/actor_anim.h`: formato `sub_effect_record` e accessors de target/offset.
- `src/vehicle/polar_player_actions.c` / `polar_player_states.c`: sequência state 10/11 e constantes do finish-leap.

A implementação PC continua sendo C++ portátil orientado pelos dados da ROM; nenhum código ARM do GBA é executado.


## Referências consultadas para v0.26

Repositório público `Almamu/CrashBandicootXS-decomp`, branch corrente consultada em 2026-10-06:

- `src/bosses/hovercraft.c`: fireball kind 39, HP, speed/decay, dano de contato, death state e estado do singleton.
- `src/bosses/hovercraft_cannon.c`: projeção do cannonball, limite `0xFFF`, cooldown/burst e gating do canhão.
- `src/bosses/hovercraft_side_gun.c`: spawn/timing das fireballs laterais.
- `src/bosses/hovercraft_launcher.c`: launcher e bombers kinds 5/6/8.
- `src/vehicle/jetpack_spawn.c`: player fly/roll/damage, cannonball kind 3, fireball kind 39 e respectivos SFX.
- `src/vehicle/jetpack_player.c`: states Fall/Finish/Boost e thresholds `0x7080`, `0xE100`, `0x8200`, `0xA000`, `0x32`.
- `src/vehicle/jetpack_run.c`: `FinishJetpackRun` e `PassJetpackRing`.
- `src/data/actor_pmf_17c1c0.c`: dispatch dos oito estados do player Jetpack.
- `src/actor/actor_category_frame.c`: world-space AABB de `JetpackIsTouchingPlayer`/`ActorsOverlap`.

Essas referências foram usadas para confirmar semântica e constantes. A implementação deste pacote é C++ portátil e lê os recursos da ROM ACQE do usuário; ela não executa o código ARM do GBA.

## Referências consultadas para v0.27

Repositório público `Almamu/CrashBandicootXS-decomp`, branch corrente consultada em 2026-10-06:

- `src/vehicle/jetpack_run.c`: `PassJetpackRing`, cadeia 1/5/20 Wumpa → cura → vida, gates `0x14`/`0xBE` e estados aceitos.
- `src/vehicle/jetpack_player.c`: `DispenseJetpackWumpa`, cooldown `0x0F`, tiers 1/2/4/8 e drain em estado inativo.
- `src/vehicle/jetpack_crates.c`: `UpdateJetpackRing` e cue one-shot.
- `src/vehicle/jetpack_spawn.c`: kind 31 cria dois `JetpackRing`, um deles usando a tabela do kind 43; kind 44 é o efeito de Wumpa coletado.
- `src/bosses/hovercraft_parts.c`: `StartHovercraftHitFlash`, `LoseHovercraftPart` e transição do singleton após a quarta peça.
- `src/bosses/hovercraft_cannon.c`: cannon recebe dano sem gate de estado e usa death anim 2.
- `src/bosses/hovercraft_launcher.c`: launcher só recebe dano em state 1 e usa death anim 3.
- `src/bosses/hovercraft_side_gun.c`: HP por perfil, death state/anim por lado e timing de burst.
- `src/data/singleton_kind_17c460.c`: parâmetros `60,{45,6,210},{20,5,90},{32,3,160}` e segundo perfil.

A implementação PC continua portátil e orientada pelos dados da ROM ACQE; nenhum código ARM do GBA é executado.


## Referências consultadas para v0.28

Repositório público `Almamu/CrashBandicootXS-decomp`, branch corrente consultada em 2026-10-06:

- `src/vehicle/jetpack_player.c`: `DispenseJetpackWumpa`, fila 1/2/4/8 e crédito em estado inativo.
- `src/bosses/hovercraft.c`: `Create/Update/DestroyJetpackCollectedWumpa`, matemática para `(0x1000,0x1000)`, fireball e `RunHovercraftState`.
- `src/vehicle/jetpack_crates.c`: question/health/time balloon crates, `JetpackBalloonCrateStateHang/Fall`, Parachute Nitro, Rocket, boxes e death transitions.
- `src/vehicle/jetpack_balloon.c`: `ReleaseJetpackBalloon` e `JetpackBalloonStateFloatAway`.
- `src/vehicle/jetpack_spawn.c`: factory kinds 19–29, child balloons 40/41/42 e reward kind 44.
- `src/data/actor_box_17c444.c`: box ativada do Rocket `{-21,-21,-2,42,42,4}`.
- `src/bosses/hovercraft_parts.c`: `SetHovercraftFlashColor` e distinção entre color-15 flash e hit-flash latch.
- `src/actor/actor_bg.c`: `GetActorBgCenterX/Y`, usados pelo reward visual.

A implementação continua em C++ portátil sobre os bytes da ROM ACQE; nenhum código ARM do GBA é executado.


## Referências consultadas para v0.29

Repositório público `Almamu/CrashBandicootXS-decomp`, consultado em 2026-10-06:

- `src/vehicle/jetpack_balloon.c`: child balloon HP=2, `DamageJetpackBalloon`, pop anim/state e callback do objeto pendente.
- `src/vehicle/jetpack_crates.c`: `BreakJetpackBalloonCrate`, `JetpackBalloonCrateStateFall`, `JetpackBalloonCrateStateHang`, thresholds `0x4C0`/`0xE100` e semântica de liberação do child.
- `src/data/actor_state_17c3fc.c`: dispatch dos três estados do balloon crate (hang/fall/death stub).
- `include/vehicle.h`: contratos dos handlers de balloon crate e child balloon usados para cruzar o fluxo pai/filho.

A implementação desta versão continua C++ portátil e lê os recursos da ROM ACQE fornecida pelo usuário; nenhum código ARM do GBA é executado.


## Referências consultadas para v0.30

Decomp público `Almamu/CrashBandicootXS-decomp`, com foco nos callbacks:

- `src/vehicle/jetpack_balloon.c` — `DamageJetpackBalloon` (`0x2E`);
- `src/vehicle/jetpack_crates.c` — crates, Parachute Nitro, Rocket e Ring (`0x03`, `0x04`, `0x07`, `0x18`, `0x2D`, `0x3E`);
- `src/vehicle/jetpack_run.c` — `FinishJetpackRun` (`0x3B`) e life reward (`0x07`);
- `src/vehicle/jetpack_plane.c` — Plane/Bomber death (`0x25` / `0x04`);
- `src/vehicle/jetpack_spawn.c` / `jetpack_player.c` — player hit (`0x42`) e bomber ambience (`0x37`, timer `0x16`, volume por count);
- `src/bosses/airship_damage.c` — hit não fatal (`0x43`);
- `src/bosses/hovercraft*.c` — hit de peça (`0x45`), `LoseHovercraftPart` + death (`0x04` + `0x04`) e fireball (`0x04`).


## Referências consultadas para v0.31

Decomp público `Almamu/CrashBandicootXS-decomp`, consultado em 2026-10-06:

- `include/actor_anim.h` — layout real de `category_descriptor` e `sub_effect_record`;
- `src/actor/actor_category_init.c` — thresholds de bonus/retry, contadores de morte e escolha `bossLevel`/`retryBossLevel`;
- `src/actor/actor_factory.c` — seleção Polar `kind`/`altKind`/`bonusKind` e folds de Time Trial;
- `src/vehicle/jetpack_spawn.c` — seleção Jetpack e fold `0x17 -> 0x14`;
- `src/data/weapon_kind_17c2d0.c` — seis perfis originais do Airship;
- `src/data/singleton_kind_17c460.c` — dois perfis originais do Hovercraft;
- `src/vehicle/jetpack_run.c` / `jetpack_spawn.c` — cura proporcional ao HP máximo e assist de 120 HP.

A ROM continua sendo usada somente como fonte de dados; o runtime PC não executa código ARM do GBA.
