@echo off
setlocal EnableDelayedExpansion
cd /d "%~dp0"
if "%~1"=="" goto :usage
set PATTERN=%~1
set OUT=%~2
set KNOW=%~3
if "%OUT%"=="" set OUT=docs\oracle-auto\batch
where cmake >nul 2>nul || (echo ERRO: CMake nao encontrado.& pause & exit /b 1)
cmake -S . -B build-tools -G "Visual Studio 17 2022" -A x64 -DDKC3_BUILD_OFFLINE_IMPORTER=ON || goto :err
cmake --build build-tools --config Release --target dkc3_oracle_batch || goto :err
set ARGS=
set COUNT=0
for %%F in ("%PATTERN%") do (
  set ARGS=!ARGS! "%%~fF"
  set /a COUNT+=1
)
if !COUNT! EQU 0 (
  echo ERRO: nenhum save-state encontrado em %PATTERN%
  if not defined DKC3_NOPAUSE pause
  exit /b 2
)
if exist "%OUT%" rmdir /S /Q "%OUT%"
set KNOWARG=
if not "%KNOW%"=="" (
  if exist "%KNOW%" (
    set KNOWARG=--knowledge "%KNOW%"
  ) else (
    echo AVISO: base de conhecimento nao encontrada: %KNOW%
  )
)
build-tools\Release\dkc3_oracle_batch.exe "%OUT%" !KNOWARG! !ARGS! || goto :err
echo.
echo ORACLE_BATCH_OK: !COUNT! states analisados.
echo Resultado: %OUT%\SUMMARY.txt
echo Conhecidos: %OUT%\known-detections.csv
echo Novos candidatos: %OUT%\AUTO-NEW-CANDIDATES.md
if not defined DKC3_NOPAUSE pause
exit /b 0
:usage
echo Uso: AUTO-ANALYZE-STATES.cmd "PADRAO-DE-STATES" "PASTA-DE-SAIDA" [BASE-DE-CONHECIMENTO.csv]
echo Exemplo: AUTO-ANALYZE-STATES.cmd "tools\offline_import\tidal-trouble-*.state" "docs\oracle-auto\tidal" "tools\offline_import\tidal-known-groups.csv"
if not defined DKC3_NOPAUSE pause
exit /b 2
:err
echo FALHA NA ANALISE AUTOMATICA.
if not defined DKC3_NOPAUSE pause
exit /b 1
