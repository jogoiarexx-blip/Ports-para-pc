@echo off
setlocal
cd /d "%~dp0"
where cmake >nul 2>nul || (echo ERRO: CMake nao encontrado.& pause & exit /b 1)
cmake -S . -B build-tools -G "Visual Studio 17 2022" -A x64 -DDKC3_BUILD_OFFLINE_IMPORTER=ON || goto :err
cmake --build build-tools --config Release --target dkc3_dump_state_frame || goto :err
if not exist docs\state_frames mkdir docs\state_frames
for %%S in (opening page1 page2) do (
  build-tools\Release\dkc3_dump_state_frame.exe tools\offline_import\tidal-trouble-%%S.state docs\state_frames\tidal-trouble-%%S.bmp || goto :err
)
echo.
echo STATE_FRAMES_OK: veja docs\state_frames\
pause
exit /b 0
:err
echo FALHA AO EXTRAIR FRAMES DOS SAVE-STATES.
pause
exit /b 1
