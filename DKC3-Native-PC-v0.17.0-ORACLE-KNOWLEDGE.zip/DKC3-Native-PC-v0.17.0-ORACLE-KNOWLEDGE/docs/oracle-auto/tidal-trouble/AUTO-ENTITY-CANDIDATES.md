# DKC3 Oracle - entity candidates

Generated automatically from 3 save-state(s). A family is only a candidate; inspect the BMP previews before integrating it.

## Family 0

- `tidal-trouble-opening` group 0 — slots 0-7, palette 2, 38x40, **known: kiddy_swim (100)** — `tidal-trouble-opening/groups/group_00_slots_0-7.bmp`
- `tidal-trouble-page1` group 2 — slots 6-15, palette 2, 46x40, **known: kiddy_swim (100)** — `tidal-trouble-page1/groups/group_02_slots_6-15.bmp`
- `tidal-trouble-page2` group 1 — slots 5-13, palette 2, 46x40, **known: kiddy_swim (100)** — `tidal-trouble-page2/groups/group_01_slots_5-13.bmp`

## Family 1

- `tidal-trouble-page1` group 3 — slots 16-26, palette 3, 48x24, **known: sneek (100)** — `tidal-trouble-page1/groups/group_03_slots_16-26.bmp`
- `tidal-trouble-page2` group 2 — slots 14-24, palette 3, 56x24, **known: sneek (100)** — `tidal-trouble-page2/groups/group_02_slots_14-24.bmp`

## Family 2

- `tidal-trouble-page1` group 4 — slots 27-31, palette 0, 16x32, **known: kong_k (100)** — `tidal-trouble-page1/groups/group_04_slots_27-31.bmp`
- `tidal-trouble-page2` group 3 — slots 25-28, palette 0, 8x32, **known: kong_k (100)** — `tidal-trouble-page2/groups/group_03_slots_25-28.bmp`

