# DKC3 Oracle - new/unknown candidates

Known sprites are filtered using the knowledge base. Review these tracks first; they are the best candidates for genuinely new entities.

No unknown tracks in this batch.
