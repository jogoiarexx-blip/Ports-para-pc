# v0.10.0 - Native Streaming Pass

## Streaming de cena nativa
- `native_scene_page` deixou de carregar todas as paginas no `Game::init`.
- Cada pagina guarda caminho + estado residente; o runtime carrega sob demanda a pagina ativa e pre-carrega apenas as vizinhas.
- Paginas distantes sao liberadas do cache. Em uma regressao sintetica com 5 paginas, o limite observado e 3 paginas residentes.
- O crossfade de 0,3 s continua preservado: a pagina anterior fica residente ate o fim da mistura.
- A pagina inicial passa a ser determinada pela camera/spawn, em vez de assumir sempre a pagina 0.
- Overlay F4 mostra `CACHE N` alem de pagina/camera.

## Render / desempenho
- `NativeScene` reutiliza buffers `main/subscreen` por thread, evitando alocacoes grandes a cada frame.
- O framebuffer temporario do crossfade tambem e reutilizado.
- Win32 ganhou F7 para alternar `PIXEL NITIDO` (COLORONCOLOR, padrao) e `FILTRO SUAVE` (HALFTONE).

## Runtime portatil
- `BUILD-WINDOWS.cmd` limpa `bin/` antes de empacotar para impedir arquivos antigos de vazarem para a distribuicao.
- `VERIFY-NATIVE-RUNTIME.cmd` falha se encontrar `.sfc`, `.smc`, `.state`, `.srm`, `.sav` ou pastas de desenvolvimento no runtime.
- O build gera `DKC3-Native-PC-v0.10.0-Portable-Windows-x64.zip` com EXE + assets convertidos.

## Testes
- Novo `streaming-test.level` com 5 paginas logicas para validar carregamento/descarregamento e limite do cache.
- Suite completa passou em Release e em AddressSanitizer + UndefinedBehaviorSanitizer.
- Fluxo headless Doorstop -> Tidal continua passando com o mesmo framehash final da v0.9.0.

## Limite conhecido
- Tidal Trouble ainda possui somente as 3 paginas autenticas capturadas anteriormente. Este passe nao replica/repite paginas para fingir uma fase completa; novas secoes dependem de novas capturas offline autenticas.
