# v0.9.0 - Sound Pass

## Audio (novo)
- `src/core/Audio.*`: `Sfx` (13 eventos) e `SfxMixer` (22050 Hz mono 16-bit, 12 vozes, limitador tanh, mudo, volume).
  Sintese procedural: ondas quadrada/triangular/serra/senoidal + ruido filtrado com envelopes; deterministico por voz.
- `Game` emite eventos (`takeSfx()`): Jump (inclui pulo saindo de agarre), Land (queda > 150 px/s), Coin, Stomp, Roll, EnemyHit,
  Hurt, Checkpoint, Lever, Switch, Door, Locked, Splash (so ao entrar/sair da agua; sem splash espurio ao iniciar em Tidal).
- `GameSession::takeSfx()` acumula os eventos, inclusive os do quadro em que a fase troca.
- Win32: `AudioOut` (waveOut, 4 buffers de 20 ms por polling); teclas M (mudo) e +/- (volume) com aviso na tela; F1 atualizado.
- Disparos simultaneos do mesmo efeito nao empilham (sem estouro de volume).

## Ferramentas / qualidade
- `dkc3_native_sfx <pasta>`: WAV por efeito + metricas; espectrogramas conferidos (arpejo do checkpoint, duas notas da moeda,
  vibrato do dano, pausa do "trancado").
- Corrigido bug de envelope do splash (ficava mudo apos 50 ms) e removido o warning de parametro nao usado em NativeScene.cpp.
- Testes: mixer (silencio, limite de pico, mudo, volume, expiracao, nao empilhar), todos os eventos de som e o fluxo Doorstop -> Tidal.
