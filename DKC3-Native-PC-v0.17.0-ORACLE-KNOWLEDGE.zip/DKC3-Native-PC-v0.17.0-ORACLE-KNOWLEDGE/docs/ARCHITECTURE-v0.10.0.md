# Arquitetura v0.10.0

O runtime continua um port C++ nativo. ROM e save-states pertencem somente ao pipeline offline de desenvolvimento e nao sao necessarios no executavel final.

## Fluxo de assets
`ROM PT-BR -> captura/oracle offline -> conversores -> .nscene/.ntiles/.nmap/.npal/.nspr/.nanim -> runtime C++`

O runtime nunca executa 65C816, PPU, SPC700, save-state ou ROM.

## Streaming de paginas
`World` le apenas a lista `native_scene_page <startX> <arquivo>`. `Game` cria descritores leves com caminho, mas nao materializa todas as cenas.

Janela de cache normal:
- pagina ativa;
- pagina anterior, quando existe;
- pagina seguinte, quando existe.

Ao cruzar uma fronteira, a pagina destino ja tende a estar pre-carregada. Durante o crossfade, a pagina de origem permanece protegida contra descarregamento. Depois, paginas fora da vizinhanca sao liberadas.

Isso faz o custo de memoria depender da janela local, nao do numero total de paginas de uma fase futura.

## Render
`NativeScene` monta BG1/BG2/BG3, main/subscreen, prioridade e color math diretamente dos assets convertidos. Buffers temporarios de main/subscreen sao reutilizados por thread. O crossfade tambem reutiliza seu framebuffer temporario.

## Plataforma Windows
A camada Win32 mantem GDI/XInput/waveOut separados do core. F7 muda apenas o filtro de apresentacao da imagem final; nao altera fisica, assets ou renderer logico.

## Empacotamento
`BUILD-WINDOWS.cmd` gera uma pasta `bin/` nova, copia somente runtime/assets e executa `VERIFY-NATIVE-RUNTIME.cmd`. A verificacao rejeita ROMs, save-states e pastas de desenvolvimento antes de criar o ZIP portatil.
