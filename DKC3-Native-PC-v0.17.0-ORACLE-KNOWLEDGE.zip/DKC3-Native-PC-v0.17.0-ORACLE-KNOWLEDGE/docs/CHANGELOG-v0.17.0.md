# DKC3 Native PC v0.17.0 - Oracle Knowledge Pass

- `dkc3_oracle_batch` aceita `--knowledge` e rotula automaticamente grupos OAM ja confirmados.
- Base `tools/offline_import/tidal-known-groups.csv` aprende Kiddy, Sneek, letra K, DK Barrel e HUD das capturas atuais.
- Novos `known-detections.csv`, `entity-tracks.csv` e `AUTO-NEW-CANDIDATES.md` reduzem revisao manual e falsos candidatos.
- Tracking temporal agora e um-para-um; grupos conhecidos so se conectam ao mesmo rotulo conhecido.
- Novo `AUTO-PROCESS-LEVEL.cmd`, reutilizavel por qualquer fase capturada.
- Novo `AUTO-PROCESS-SKIDDAS.cmd` pronto para a primeira captura de Skidda's Row.
- Novo `dkc3_update_level_pages`: adiciona paginas novas ao `.level` e amplia fase/camera/agua/corrente automaticamente.
- Novo `dkc3_make_level_scaffold`: cria um bootstrap de fase a partir dos metadados originais e das primeiras paginas importadas.
- Simulacao de `page3` em Tidal validou crescimento automatico de 512 para 608 px.
- Runtime nativo e gameplay existentes foram preservados; nenhuma dependencia de ROM foi adicionada ao runtime.
