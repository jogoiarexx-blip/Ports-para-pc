# Arquitetura v0.15.0 - inimigo OAM em Tidal

O runtime continua independente de ROM/save-state. A ferramenta offline `dkc3_import_oam_group` le o snapshot somente durante a conversao e grava um `.nspr`. Para o Sneek, o novo argumento opcional `flip_x` normaliza a direcao do raster ja recortado; isso permite manter a convencao do `Game`, em que o frame-base do inimigo olha para a direita e `drawNativeSprite(..., flipX)` cuida da direcao durante a patrulha.

A fase declara o Sneek usando a diretiva generica `enemy`: posicao, velocidade, limites de patrulha, animacao e hitbox. Nenhuma regra especial foi adicionada ao loop de gameplay. Assim, contato/dano, stomp, roll/cartwheel, SFX, render e debug continuam compartilhados com os inimigos de Doorstop.

A captura OAM de page1 contem o mesmo desenho do Sneek encontrado em page2. Como os pixels sao iguais, `sneek.nanim` possui um frame; novos frames so devem ser adicionados quando outra pose autentica for capturada.
