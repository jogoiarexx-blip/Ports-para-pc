# v0.11.0 - Tidal Current Pass

## Tidal Trouble: correnteza nativa
- Novo comando de fase `water_current x y w h driftX driftY`.
- A corrente altera o alvo de velocidade da natacao, permitindo deriva sem input e tornando o nado contra/a favor da corrente diferente.
- Tidal Trouble usa `-32 px/s` no eixo X dentro da agua, deixando o avanco para a direita mais dificil sem impedir a progressao.
- A zona de corrente aparece no overlay F4 e o estado corrente/forca fica exposto ao core para testes.

## Streaming mais estavel em agua
- A histerese ao voltar de pagina passa de 6 px para 18 px quando o jogador esta em uma zona de corrente.
- Isso evita uma segunda troca/crossfade apenas porque a corrente empurrou a camera alguns pixels depois da fronteira.
- O cache continua limitado a pagina ativa + vizinhas.

## Preparacao de inimigos/objetos autenticos
- Novo `dkc3_oam_audit` (somente ferramenta offline) lista os sprites OAM visiveis de um save-state em CSV.
- `AUDIT-TIDAL-OAM.cmd` gera auditorias para as 3 capturas atuais de Tidal.
- CSVs atuais ficam em `docs/oam-audit/` para ajudar a separar Kongs, itens e futuros inimigos/objetos antes da extracao de sprites.
- O importador offline de Doorstop teve duas indentacoes ambiguas corrigidas e agora passa no build com `-Werror` junto das demais ferramentas.

## Preparacao da terceira fase
- `make_level_capture_rom.py` generaliza o antigo helper de captura de Tidal para os primeiros IDs de fase suportados.
- `PREPARE-SKIDDAS-CAPTURE.cmd` prepara uma ROM temporaria de desenvolvimento para capturar Skidda's Row (ID 0x2B).
- Nenhuma ROM temporaria entra no runtime. Skidda's Row ainda nao foi adicionada ao catalogo porque ainda faltam snapshots autenticos dela.

## Testes
- Regressao nova valida parsing da corrente, deriva para a esquerda e nado para a direita mais lento contra a corrente.
- Suite completa passa em Release, build estrito (`-Wall -Wextra -Wpedantic -Werror`) e ASan/UBSan.
