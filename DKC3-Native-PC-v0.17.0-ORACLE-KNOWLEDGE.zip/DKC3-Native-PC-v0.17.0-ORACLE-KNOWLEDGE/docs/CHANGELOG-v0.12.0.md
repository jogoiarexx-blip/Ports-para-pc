# DKC3 Native-PC v0.12.0 - Tidal Entities Pass

- Primeiro objeto interativo autentico extraido da OAM de Tidal Trouble: **DK Barrel** da captura de abertura.
- Novo comando de fase `team_barrel ID X Y SPRITE W H`.
- Nova entidade `RuntimeTeamBarrel`: o barril permanece no mapa quando a dupla esta completa; se o jogador estiver SOLO e tocar nele, restaura o parceiro, exibe `DUPLA RESTAURADA`, emite SFX de troca e e consumido.
- Novo importador offline `dkc3_import_oam_group`: extrai um grupo exato de slots OAM para `.nspr`, preservando VRAM/CGRAM da captura e permitindo preview BMP.
- Novo `IMPORT-TIDAL-ENTITIES.cmd`, reproduzindo a extracao do DK Barrel a partir de `tidal-trouble-opening.state`, slots 8-20.
- F4 agora tambem mostra a hitbox dos `team_barrel` ativos.
- Tidal Trouble usa o sprite OAM real do barril em `native/entities/dk_barrel.nspr`; nenhuma arte provisoria foi desenhada para substitui-lo.
- Teste de regressao novo valida parser, carregamento do sprite, restauracao da dupla, consumo unico do barril e evento de som.
- Build estrito (`-Wall -Wextra -Wpedantic -Werror`) e ASan/UBSan passam.

Limites mantidos:
- Tidal ainda tem somente as 3 paginas graficas autenticas capturadas.
- O sistema completo de pegar/carregar/arremessar barris ainda nao existe; o DK Barrel usa interacao por contato nesta etapa.
- Skidda's Row continua aguardando snapshot autentico antes de entrar no runtime jogavel.
