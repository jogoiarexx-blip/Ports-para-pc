# DKC3 Native-PC v0.11.0 - arquitetura

O runtime continua sendo um port nativo C++: carrega apenas arquivos convertidos em `assets/`, executa fisica/camera/entidades proprias e nao abre ROM/save-state durante o jogo.

## Agua e corrente
`World` possui `waterZones` e agora `waterCurrents`. Uma corrente e um retangulo mais um vetor de deriva em px/s. Durante o nado, o `Game` soma todas as correntes que sobrepoem a hitbox do jogador e passa o vetor resultante para `updateSwimPlayer`. O componente e limitado antes de ser aplicado ao alvo de velocidade.

## Streaming de cenas
As paginas `.nscene` continuam lazy-loaded. O runtime mantem ativa + vizinhas e preserva a pagina anterior durante crossfade. A histerese de retorno e 6 px em condicao normal e 18 px enquanto o jogador estiver sob correnteza, evitando alternancia de pagina provocada por deriva ambiental.

## Ferramentas offline
`dkc3_import_scene_state` converte PPU/VRAM/CGRAM previamente capturados em assets estruturados. `dkc3_oam_audit` apenas inspeciona OAM de save-states de desenvolvimento e escreve CSV; ele nunca e incluido no runtime. `make_level_capture_rom.py` cria ROM temporaria para facilitar capturas de fases adicionais e tambem fica fora do runtime.
