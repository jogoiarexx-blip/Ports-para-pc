# v0.7.11 - Tidal Stream Pages

- Tidal Trouble passou de uma unica captura grafica para **3 paginas originais** capturadas offline.
- Novo comando de level: `native_scene_page <x> <arquivo.nscene>`.
- `Game` carrega todas as paginas no inicio da fase e troca de pagina conforme `camera.x`.
- A camera enviada ao renderer passa a ser local a pagina ativa, evitando somar o scroll capturado com o deslocamento global inteiro.
- page0 = frame 13000, page1 = 14000, page2 = 15500 do oracle offline.
- As tres paginas possuem VRAM/tilemaps/paleta diferentes; nao sao duplicatas.
- Novo `IMPORT-TIDAL-PAGES.cmd` regenera as 3 paginas dos states de desenvolvimento.
- Nenhuma ROM/state entra no runtime final.
