# DKC3 Native PC v0.16.0 - Automation Oracle Pass

- Adicionado `dkc3_oracle_batch` para analise de varios save-states em uma unica execucao.
- Exportacao automatica de framebuffers, OAM CSV, grupos OAM, previews BMP e candidatos `.nspr`.
- Matching de grupos entre capturas e familias candidatas de entidade.
- Relatorios de diferencas/hotspots de WRAM e correlacao com offsets PPU.
- `pages.csv` com hashes de VRAM/CGRAM/OAM/WRAM para comparar/deduplicar capturas.
- `AUTO-ANALYZE-STATES.cmd`, `AUTO-ANALYZE-TIDAL.cmd` e `AUTO-PROCESS-TIDAL-CAPTURES.cmd`.
- `IMPORT-TIDAL-PAGES.cmd` agora importa automaticamente qualquer `tidal-trouble-pageN.state`.
- Novo `dkc3_make_capture_rom` C++; Skidda 0x2B validado byte-a-byte contra o helper Python anterior.
- Novo `AUTO-PREPARE-CAPTURE.cmd` e fila `AUTO-PREPARE-EARLY-CAPTURES.cmd` para IDs 0x25..0x2B.
- Novo `dkc3_import_level_metadata` C++, byte-a-byte equivalente ao importador Python nos 7 metadados suportados.
- `IMPORT-ROM-LEVEL-METADATA.cmd` e `PREPARE-SKIDDAS-CAPTURE.cmd` deixam de exigir Python.
- Runtime/gameplay de v0.15 preservado; nenhuma emulacao/recomp foi adicionada.
