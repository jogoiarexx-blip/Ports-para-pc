# DKC3 Native-PC v0.13.0 - KONG Letter Pass

- A entidade provisoria `silver_coin_tidal` foi removida de Tidal Trouble.
- A letra **K** autentica foi identificada diretamente nos framebuffers das capturas e extraida da OAM em dois estados de rotacao:
  - `tidal-trouble-page1.state`, slots 27-31, 16x28;
  - `tidal-trouble-page2.state`, slots 25-28, 8x28.
- Os frames viraram `kong_k_0.nspr` e `kong_k_1.nspr`; `kong_k.nanim` alterna os dois a 110 ms.
- Novo comando de fase `kong_letter LETRA X Y ANIM W H`.
- Nova `RuntimeKongLetter`: animacao, hitbox, coleta unica, mascara K/O/N/G e contador por fase.
- HUD mostra `K O N G` em fases que possuem letras; coletadas ficam douradas.
- F4 mostra hitbox das letras ativas.
- `IMPORT-TIDAL-ENTITIES.cmd` passou a reproduzir tambem a extracao/animacao da K.
- Nova ferramenta offline `dkc3_dump_state_frame` e comando `DUMP-TIDAL-STATE-FRAMES.cmd` para exportar o framebuffer de snapshots e reduzir ambiguidades na identificacao de OAM.
- Testes novos validam parser, dois frames distintos, coleta unica, mascara K, toast e SFX.
- Build estrito com `-Wall -Wextra -Wpedantic -Werror` e ASan/UBSan passam.

## Limites mantidos
- Tidal ainda possui somente as 3 capturas estruturadas existentes; elas nao cobrem a fase completa.
- O/N/G ainda nao foram adicionadas porque nao ha capturas autenticas adequadas delas neste pacote.
- Skidda's Row continua preparada para captura, mas nao entra no catalogo jogavel sem snapshots reais.
