# Arquitetura v0.16.0 - Automation / Oracle

O port continua sendo um runtime C++ nativo. ROM, save-states e estruturas do SNES continuam restritos a `tools/offline_import` e nunca sao consultados pelo executavel final.

## Novo pipeline em lote

`dkc3_oracle_batch OUT STATE...` le uma sequencia de snapshots e transforma a analise que antes era manual em um lote reproduzivel. Para cada estado ele exporta:

- framebuffer em BMP;
- OAM visivel em CSV;
- agrupamentos consecutivos/espaciais de OAM;
- preview BMP e candidato `.nspr` de cada grupo;
- hashes de VRAM/CGRAM/OAM/WRAM e offsets de BG em `pages.csv`.

Entre estados, o Oracle calcula similaridade de grupos usando paleta, prioridade, nametable, quantidade/tamanho dos sprites, geometria e sobreposicao de tiles. Links com confianca alta formam familias candidatas, gravadas em `entity-families.csv` e `AUTO-ENTITY-CANDIDATES.md`. O sistema nao integra candidatos automaticamente no runtime: a revisao visual continua sendo a barreira contra falso positivo.

A mesma passada cria `wram-diff-ranges.csv`, `wram-hotspots.csv` e tenta correlacionar variaveis de WRAM com os offsets PPU de BG. Isso prepara a descoberta de camera, objetos e estados sem inspecionar enderecos um por um.

## Paginas sem lista fixa

`IMPORT-TIDAL-PAGES.cmd` procura `tidal-trouble-page*.state`. Assim, uma captura futura `tidal-trouble-page3.state` passa a ser convertida sem editar o script. `AUTO-PROCESS-TIDAL-CAPTURES.cmd` encadeia importacao e analise em lote.

## Ferramentas C++ sem Python

`dkc3_make_capture_rom` substitui `make_level_capture_rom.py` na rota ativa. `dkc3_import_level_metadata` substitui `import_level_metadata.py`. Os scripts Python antigos permanecem apenas como referencia/compatibilidade de desenvolvimento; os `.cmd` ativos nao dependem deles.

## Separacao runtime / oracle

`BUILD-WINDOWS.cmd` continua compilando e empacotando somente o runtime e `assets/`. Os alvos Oracle so existem com `DKC3_BUILD_OFFLINE_IMPORTER=ON`. A verificacao do pacote portatil continua rejeitando ROM/save-state/ferramentas offline.
