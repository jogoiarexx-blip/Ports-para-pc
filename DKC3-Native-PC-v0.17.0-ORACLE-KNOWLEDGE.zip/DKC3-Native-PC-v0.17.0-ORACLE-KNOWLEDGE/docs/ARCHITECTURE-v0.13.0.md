# DKC3 Native-PC v0.13.0 - arquitetura

O runtime continua sendo um port nativo C++: nao executa 65C816, nao abre ROM/save-state e nao contem emulador/recompilador. ROM e snapshots existem somente nas ferramentas offline de conversao.

## K-O-N-G nativo
`World` agora aceita `kong_letter LETRA X Y ANIM W H`. Cada definicao vira uma `RuntimeKongLetter` com animacao nativa, hitbox e estado `active`. A coleta atualiza uma mascara de 4 bits (K=1, O=2, N=4, G=8), dispara SFX e atualiza o HUD. O estado e local a fase, como o fluxo atual do runtime.

A primeira letra autentica e a K de Tidal. Ela usa dois snapshots OAM da mesma letra em angulos de giro diferentes. O runtime carrega somente `.nspr/.nanim`; os save-states nunca sao acessados durante o jogo.

## Inspecao offline de snapshots
`dkc3_dump_state_frame` le o framebuffer armazenado no snapshot de desenvolvimento e grava BMP. Isso permite confirmar visualmente o que um grupo OAM representa antes de transforma-lo em asset do runtime. O utilitario faz parte apenas do build `DKC3_BUILD_OFFLINE_IMPORTER=ON`.

## Entidades e streaming anteriores
O DK Barrel da v0.12.0, correnteza da v0.11.0 e cache deslizante de paginas da v0.10.0 permanecem ativos. A pagina atual e as vizinhas ficam carregadas e o crossfade preserva a pagina anterior durante a transicao.

## Proximos dados necessarios
Para completar Tidal ainda sao necessarias capturas reais de O/N/G, inimigos (Koco, Buzz, Knocka etc.) e paginas adicionais. Skidda's Row so entra no catalogo quando houver snapshots autenticos suficientes para grafico, colisao e entidades.
