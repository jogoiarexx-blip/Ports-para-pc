# DKC3 Native-PC v0.12.0 - arquitetura

O runtime continua sendo um port nativo C++: nenhum codigo 65C816 e executado e o jogo final nao abre ROM/save-state. ROM e states existem apenas nas ferramentas offline de conversao.

## Entidades OAM autenticas
A v0.12.0 adiciona `dkc3_import_oam_group`. A ferramenta le VRAM, CGRAM, OAM e OBSEL de um snapshot de desenvolvimento, recebe um intervalo explicito de slots OAM e rasteriza somente esse grupo para o formato nativo `.nspr`. O runtime ve apenas o `.nspr` final.

O primeiro uso e o DK Barrel da abertura de Tidal Trouble, identificado nos slots 8-20 de `tidal-trouble-opening.state`. O arquivo gerado e `assets/levels/tidal-trouble/native/entities/dk_barrel.nspr` (30x38).

## Team Barrel
`World` aceita `team_barrel`. `Game` carrega o sprite para `RuntimeTeamBarrel`, desenha-o junto das entidades e testa sua hitbox. Quando `partnerAvailable == false`, uma sobreposicao restaura o parceiro e desativa o barril. Isso e uma aproximacao nativa temporaria enquanto o sistema de carregar/arremessar barris ainda nao foi implementado.

## Agua e streaming
As correntes por zona e o streaming lazy-loaded da v0.11.0 permanecem inalterados: pagina atual + vizinhas em cache, crossfade e histerese ampliada sob correnteza.

## Skidda's Row
Os metadados originais e a ferramenta para preparar ROM temporaria de captura permanecem prontos, mas a fase nao e adicionada ao catalogo jogavel sem uma captura real.
