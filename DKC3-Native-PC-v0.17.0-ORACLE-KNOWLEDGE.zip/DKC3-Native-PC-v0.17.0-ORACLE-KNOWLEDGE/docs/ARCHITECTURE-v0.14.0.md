# DKC3 Native-PC v0.14.0 - arquitetura

O runtime continua sendo um port nativo C++: nao interpreta 65C816 e nao abre ROM/save-state durante o jogo. Capturas e ROM de desenvolvimento ficam restritas ao pipeline offline.

## Animacao de nado autentica do Kiddy
Tidal ja possuia tres snapshots OAM com poses inequivocas do Kiddy nadando. `dkc3_import_oam_group` converte cada grupo em `.nspr`; as origens foram normalizadas em `27,12`, de modo que sprites com tamanhos diferentes compartilham o mesmo ponto corporal no renderer.

`kiddy_swim.nanim` referencia somente esses assets convertidos. O arquivo `.level` associa essa animacao ao conjunto do Kiddy por `companion_anim swim`, e o sistema de personagem ativo/inativo do `Game` faz a mesma animacao servir ao Kiddy controlado ou parceiro.

## Separacao entre evidencia e conteudo
As capturas page1/page2 tambem contem um grupo semelhante a Sneek. Esse grupo nao foi promovido a inimigo porque o procedimento historico de captura usa uma ROM temporaria que troca registros de fase e pode preservar dados que nao pertencem a Tidal. A v0.14 registra a ambiguidade em vez de inventar autenticidade.

## Sistemas preservados
Continuam ativos o streaming/cache de paginas, crossfade, correnteza, DK Barrel, K-O-N-G, HUD/debug, audio nativo e transicao Doorstop -> Tidal. O runtime portatil continua sem ROM/save-state.
