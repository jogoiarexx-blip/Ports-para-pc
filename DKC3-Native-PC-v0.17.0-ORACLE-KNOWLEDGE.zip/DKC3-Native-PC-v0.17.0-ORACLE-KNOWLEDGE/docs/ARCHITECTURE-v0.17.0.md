# Arquitetura v0.17.0 - Oracle Knowledge

O runtime continua independente do SNES. ROM, save-states e Oracle existem somente no pipeline offline.

## Pipeline generico

`AUTO-PROCESS-LEVEL.cmd <slug>` executa:

1. importa `slug-opening.state` e `slug-pageN.state` para paginas `.nscene`;
2. atualiza automaticamente o manifesto de paginas da fase existente;
3. se a fase ainda nao existir e houver metadata original, cria um `.level` bootstrap;
4. adiciona o scaffold ao catalogo quando necessario;
5. executa Oracle em lote;
6. aplica a base de conhecimento opcional `slug-known-groups.csv`;
7. separa deteccoes conhecidas de candidatos realmente novos.

## Knowledge base

Cada linha referencia um grupo OAM confirmado e define `label`, `kind` e score minimo. O Oracle compara novas capturas com varias referencias do mesmo objeto/pose e gera `known-detections.csv`.

## Tracking

Capturas adjacentes usam matching um-para-um. Depois que um grupo recebe identidade conhecida, ele nao pode ser associado a um desconhecido ou a outro rotulo conhecido apenas por semelhanca geometrica.

## Crescimento de fase

`dkc3_update_level_pages` detecta `pageN`, calcula o inicio por passo de 96 px e mantem margem final de 320 px. Ao crescer a largura, camera e zonas globais de agua/corrente que cobriam a largura antiga acompanham a nova largura.

## Scaffold

`dkc3_make_level_scaffold` produz uma fase bootstrap navegavel para validacao visual a partir da metadata original e das primeiras capturas. O piso bootstrap e explicitamente temporario; colisao original continua sendo uma etapa posterior.
