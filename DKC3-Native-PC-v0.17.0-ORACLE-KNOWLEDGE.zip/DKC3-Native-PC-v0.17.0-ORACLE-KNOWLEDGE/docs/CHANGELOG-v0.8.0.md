# v0.8.0 - Quality Pass

Foco: sensacao de jogo, robustez do motor, ferramentas de desenvolvimento e launcher Win32.
Nenhum asset novo foi capturado (o oracle offline nao faz parte do pacote); o runtime continua 100% nativo.

## Gameplay / fisica
- Pulo por **borda de subida**: segurar o botao nao repete o pulo ao pousar.
- **Coyote time** (0,09 s) e **buffer de pulo** (0,10 s).
- **Altura variavel**: soltar cedo corta o impulso (minimo de 0,05 s segurado) - toque = pulo curto, segurar = pulo cheio.
- **Paredes invisiveis** nas bordas horizontais de toda fase. Bug corrigido: em Tidal era possivel nadar para alem de x=512,
  cair fora do mapa e ser reposicionado (parecia o personagem "voltando" sozinho).

## Renderizacao / apresentacao
- **Crossfade de 0,3 s** (smoothstep) entre paginas de cena de Tidal; histerese de 6 px ao voltar de pagina.
- **HUD nativo** (src/core/Hud.*): fonte bitmap 5x7 PT-BR sem acentos, caixas translucidas.
  Kong ativo, DUPLA/SOLO, moedas, cartao de titulo da fase, avisos (CHECKPOINT / PORTAO ABERTO / PORTA TRANCADA).
- **Overlay de debug** (F4): geometria do level, hitboxes, camera e pagina.

## Plataforma (Win32)
- Sem flicker (so as barras sao limpas), tela cheia (F11 / Alt+Enter), escala inteira (F6), pausa (P / Start / perda de foco),
  reiniciar (R / F5 / Back), print BMP (F2), ajuda (F1), `--level <id>` na linha de comando, `RUN-TIDAL.cmd`.
- `timeBeginPeriod(1)` + sleep proporcional ao quadro; limite de 8 passos de simulacao por quadro (sem espiral da morte).
- Titulo da janela usa `Version.h` (estava preso em "v0.7.10").

## Ferramentas
- `dkc3_native_frames <fase> <pasta> [quadros] [intervalo] [debug]`: grava BMPs de uma execucao headless.
- `saveBmp32` em `Bmp.h`.
- `GameSession::restart()`.

## Testes
- Novos: pulo por borda, altura variavel, coyote, buffer, limites de mapa (Tidal), crossfade + histerese, HUD/debug/toasts,
  sanitizador de texto, restart de sessao, round-trip de BMP. Dois levels de teste novos (`flat-test`, `coyote-test`).
- Suite completa tambem executada com AddressSanitizer + UBSanitizer.
