# DKC3 Native-PC v0.15.0 - Tidal Sneek Pass

- O grupo OAM roxo antes tratado como duvidoso foi conferido contra o framebuffer real de `tidal-trouble-page2.state`: ele e um Sneek visivel sobre o deque.
- `dkc3_import_oam_group` ganhou a transformacao opcional `flip_x`, aplicada depois do crop para normalizar a orientacao base do sprite sem tocar no runtime.
- Sneek e extraido dos slots OAM 14-24 de `tidal-trouble-page2.state` para `native/enemies/sneek.nspr` (56x24, origem 0,0).
- A captura mostra o Sneek olhando para a esquerda; o asset e salvo olhando para a direita para combinar com a convencao do sistema generico de inimigos.
- `native/enemies/sneek.nanim` usa um unico frame autentico. As capturas page1/page2 desse grupo sao visualmente iguais, portanto nenhum quadro intermediario foi inventado.
- Tidal instancia `sneek_deck` em `(318,138)`, com patrulha horizontal entre `302..356`, velocidade inicial `-24 px/s` e hitbox `44x22`.
- O inimigo herda dano, invulnerabilidade, stomp, roll/cartwheel, SFX e overlay F4 do sistema nativo existente.
- Testes cobrem carga do asset, dimensoes/origem, parser da entidade, limites de patrulha e inversao de direcao.

## Limites mantidos
- Tidal continua com tres paginas estruturadas.
- O Sneek tem somente uma pose unica confirmada neste conjunto de capturas.
- Dixie ainda usa a animacao provisoria de salto na agua: o grupo Sneek NAO e usado como Dixie.
- O/N/G e Skidda's Row ainda dependem de novas capturas autenticas.
