# Arquitetura v0.9.0

O runtime continua um jogo C++ nativo. A ROM PT-BR e os save-states existem apenas no pipeline offline.

Fluxo de Tidal (inalterado):
`ROM PT-BR -> oracle offline -> .state -> import_scene_state -> .nscene/.ntiles/.nmap/.npal -> runtime C++`

## Modulos (src/core)
- `World` - parser dos `.level` (geometria, entidades, paginas de cena, metadados originais).
- `Game` - simulacao fixa de 60 Hz, camera, equipe Dixie/Kiddy, combate, alavancas/portoes, paginas de cena, HUD e debug.
- `Player` - fisica de chao/ar/nado; estado de "feel" (coyote, buffer, altura variavel) vive na struct `Player`.
- `NativeScene` - renderer de camadas (BG1-3, main/subscreen, color math) a partir de tiles/mapas/paleta convertidos.
- `NativeSprite`/`Animation` - sprites `.nspr` e animacoes `.nanim`.
- `Hud` (novo) - fonte 5x7, caixas translucidas e contornos operando direto no framebuffer.
- `Bmp` - leitura de BMP 32 bpp e (novo) escrita para screenshots/ferramentas.
- `LevelSession` - catalogo de fases, transicoes e `restart()`.
- `Version.h` (novo) - versao unica usada pelo launcher.

## Paginas de cena
`Game` seleciona a pagina pelo X da camera (com histerese de 6 px ao voltar). Ao trocar, guarda a pagina anterior e
interpola por 0,3 s: a cena anterior e renderizada num buffer temporario e misturada (smoothstep) com a nova.
Fora desse intervalo o custo de render e o mesmo da v0.7.11.

## Limites de mapa
Depois da fisica, `Game::step` prende o jogador em `[0, world.width]`. A queda em poco (y) continua gerando respawn.

## Plataforma
`src/platform/win32_main.cpp` e a unica unidade com Win32/XInput. Nao ha emulacao no executavel final:
nao existe CPU 65C816, PPU, SPC700, ROM loader nem execucao de save-state.

## Audio (v0.9.0)
`Game` apenas emite enums `Sfx`; nao conhece dispositivo de audio. `GameSession::takeSfx()` entrega os eventos para a plataforma, que
aciona o `SfxMixer`. O mixer e puro (sem Win32), por isso testavel em Linux. Somente `win32_main.cpp` fala com waveOut.
