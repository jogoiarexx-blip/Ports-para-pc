# DKC3 Native-PC v0.14.0 - Kiddy Swim Pass

- Kiddy deixa de reutilizar `kiddy_jump.nanim` enquanto nada em Tidal Trouble.
- Tres poses autenticas de natacao foram extraidas diretamente das OAM ja existentes:
  - abertura: slots 0-7;
  - page1: slots 6-15;
  - page2: slots 5-13.
- Os tres `.nspr` usam ancora normalizada `27,12`, evitando jitter entre frames de dimensoes diferentes.
- Nova animacao `native/anims/kiddy_swim.nanim` fecha a bracada com sequencia 0 -> 1 -> 2 -> 1.
- A animacao e usada tanto quando Kiddy esta ativo quanto quando e o parceiro de Dixie dentro d'agua.
- `IMPORT-TIDAL-ENTITIES.cmd` agora regenera DK Barrel, K giratoria e tambem os sprites/animacao de nado do Kiddy.
- O grupo OAM semelhante a Sneek visto nas capturas foi auditado e deliberadamente NAO integrado como inimigo de Tidal, pois a origem nao e segura.
- O executavel headless foi atualizado para validar Tidal com a velocidade/correnteza atuais, alcancando novamente a terceira pagina.
- Release, build estrito e ASan/UBSan passam.

## Limites mantidos
- Dixie ainda usa animacao provisoria na agua ate existir captura autentica de nado.
- Tidal continua limitado as 3 paginas estruturadas existentes.
- O/N/G, inimigos autenticos e a fase completa ainda dependem de novas capturas.
- Skidda's Row continua fora do catalogo jogavel sem snapshots reais suficientes.
