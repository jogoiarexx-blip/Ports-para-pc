@echo off
call "%~dp0AUTO-PROCESS-LEVEL.cmd" skiddas-row
exit /b %errorlevel%
