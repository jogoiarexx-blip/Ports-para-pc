@echo off
call "%~dp0AUTO-ANALYZE-STATES.cmd" "tools\offline_import\tidal-trouble-*.state" "docs\oracle-auto\tidal" "tools\offline_import\tidal-known-groups.csv"
exit /b %errorlevel%
