@echo off
setlocal
cd /d "%~dp0"
where cmake >nul 2>nul || (echo ERRO: CMake nao encontrado.& pause & exit /b 1)
if not exist "input\dkc3_ptbr.sfc" (
  echo ERRO: input\dkc3_ptbr.sfc nao encontrado.
  if not defined DKC3_NOPAUSE pause
  exit /b 1
)
cmake -S . -B build-tools -G "Visual Studio 17 2022" -A x64 -DDKC3_BUILD_OFFLINE_IMPORTER=ON || goto :err
cmake --build build-tools --config Release --target dkc3_import_level_metadata || goto :err
build-tools\Release\dkc3_import_level_metadata.exe input\dkc3_ptbr.sfc assets\levels\original_metadata || goto :err
echo Metadados originais regenerados com sucesso SEM Python.
if not defined DKC3_NOPAUSE pause
exit /b 0
:err
echo FALHA AO IMPORTAR METADADOS.
if not defined DKC3_NOPAUSE pause
exit /b 1
