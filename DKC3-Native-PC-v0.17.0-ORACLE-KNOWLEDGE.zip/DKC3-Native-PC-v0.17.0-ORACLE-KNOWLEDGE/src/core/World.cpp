#include "World.h"
#include <filesystem>
#include <fstream>
#include <sstream>
namespace dkc3 {
bool loadWorld(const std::string& path, World& out){
  out={};std::ifstream f(path);if(!f)return false;const auto base=std::filesystem::path(path).parent_path();std::string line;
  auto resolve=[&](const std::string&v){return (base/v).lexically_normal().string();};
  while(std::getline(f,line)){if(line.empty()||line[0]=='#')continue;std::istringstream ss(line);std::string k;ss>>k;
    if(k=="id")ss>>out.id;
    else if(k=="display_name"){std::string v;std::getline(ss,v);if(!v.empty()&&v[0]==' ')v.erase(v.begin());out.displayName=v;}
    else if(k=="original_level_id"){std::string v;ss>>v;out.originalLevelId=v.empty()?-1:std::stoi(v,nullptr,0);}
    else if(k=="bootstrap"){int v=0;ss>>v;out.bootstrap=v!=0;}
    else if(k=="size")ss>>out.width>>out.height;
    else if(k=="background"){std::string v;ss>>v;out.background=resolve(v);}
    else if(k=="native_scene"){std::string v;ss>>v;out.nativeScene=resolve(v);}
    else if(k=="native_scene_page"){NativeScenePageDef d;std::string v;ss>>d.startX>>v;d.path=resolve(v);out.nativeScenePages.push_back(std::move(d));}
    else if(k=="solid"){Rect r;ss>>r.x>>r.y>>r.w>>r.h;out.solids.push_back(r);}
    else if(k=="water"){Rect r;ss>>r.x>>r.y>>r.w>>r.h;out.waterZones.push_back(r);}
    else if(k=="water_current"){WaterCurrentDef d;ss>>d.rect.x>>d.rect.y>>d.rect.w>>d.rect.h>>d.drift.x>>d.drift.y;out.waterCurrents.push_back(d);}
    else if(k=="spawn")ss>>out.spawn.x>>out.spawn.y;
    else if(k=="camera")ss>>out.cameraBounds.x>>out.cameraBounds.y>>out.cameraBounds.w>>out.cameraBounds.h;
    else if(k=="player_sprite"){std::string v;ss>>v;out.playerSprite=resolve(v);}
    else if(k=="companion_sprite"){std::string v;ss>>v;out.companionSprite=resolve(v);}
    else if(k=="player_anim"){AnimationDef d;std::string v;ss>>d.state>>v;d.path=resolve(v);out.playerAnimations.push_back(std::move(d));}
    else if(k=="companion_anim"){AnimationDef d;std::string v;ss>>d.state>>v;d.path=resolve(v);out.companionAnimations.push_back(std::move(d));}
    else if(k=="companion_offset")ss>>out.companionOffset.x>>out.companionOffset.y;
    else if(k=="door"){Door d;ss>>d.rect.x>>d.rect.y>>d.rect.w>>d.rect.h>>d.target;std::string tag;if(ss>>tag){if(tag=="requires")ss>>d.requiresLever;}out.doors.push_back(std::move(d));}
    else if(k=="checkpoint"){Checkpoint c;ss>>c.rect.x>>c.rect.y>>c.rect.w>>c.rect.h>>c.respawn.x>>c.respawn.y;out.checkpoints.push_back(c);}
    else if(k=="hang"){HangZone z;ss>>z.rect.x>>z.rect.y>>z.rect.w>>z.rect.h>>z.anchor.x>>z.anchor.y;out.hangZones.push_back(z);}
    else if(k=="lever"){LeverDef d;ss>>d.id>>d.rect.x>>d.rect.y>>d.rect.w>>d.rect.h>>d.anchor.x>>d.anchor.y>>d.gateId>>d.holdTime;out.levers.push_back(std::move(d));}
    else if(k=="gate"){GateDef d;std::string v;ss>>d.id>>d.rect.x>>d.rect.y>>d.rect.w>>d.rect.h;if(ss>>v)d.spritePath=resolve(v);out.gates.push_back(std::move(d));}
    else if(k=="sprite_object"){WorldSpriteDef d;int fg=0;std::string v;ss>>d.id>>d.pos.x>>d.pos.y>>v>>fg;d.spritePath=resolve(v);d.foreground=fg!=0;out.spriteObjects.push_back(std::move(d));}
    else if(k=="enemy"){EnemyDef d;std::string v;ss>>d.id>>d.pos.x>>d.pos.y>>d.speed>>d.minX>>d.maxX>>v>>d.w>>d.h;d.animationPath=resolve(v);out.enemies.push_back(std::move(d));}
    else if(k=="collectible"){CollectibleDef d;std::string v;ss>>d.id>>d.pos.x>>d.pos.y>>v>>d.w>>d.h>>d.value;d.animationPath=resolve(v);out.collectibles.push_back(std::move(d));}
    else if(k=="kong_letter"){KongLetterDef d;std::string letter,v;ss>>letter>>d.pos.x>>d.pos.y>>v>>d.w>>d.h;d.letter=letter.empty()?'K':letter[0];d.animationPath=resolve(v);out.kongLetters.push_back(std::move(d));}
    else if(k=="team_barrel"){TeamBarrelDef d;std::string v;ss>>d.id>>d.pos.x>>d.pos.y>>v>>d.w>>d.h;d.spritePath=resolve(v);out.teamBarrels.push_back(std::move(d));}
    else if(k=="original_rom_offset"){std::string v;ss>>v;out.originalMetadata.romOffset=v.empty()?-1:std::stoi(v,nullptr,0);}
    else if(k=="original_level_type"){std::string v;ss>>v;out.originalMetadata.levelType=v.empty()?-1:std::stoi(v,nullptr,0);}
    else if(k=="original_song_id"){std::string v;ss>>v;out.originalMetadata.songId=v.empty()?-1:std::stoi(v,nullptr,0);}
    else if(k=="original_shared_data"){std::string v;ss>>v;out.originalMetadata.sharedData=v.empty()?-1:std::stoi(v,nullptr,0);}
    else if(k=="original_point"){OriginalPoint d;std::string flags,x,y;ss>>d.kind>>d.index>>flags>>x>>y;d.flags=std::stoi(flags,nullptr,0);d.x=std::stoi(x,nullptr,0);d.y=std::stoi(y,nullptr,0);out.originalMetadata.points.push_back(std::move(d));}
    else if(k=="original_connection"){OriginalConnection d;std::string target;ss>>d.slot>>target;d.targetLevelId=std::stoi(target,nullptr,0);out.originalMetadata.connections.push_back(d);}
    else if(k=="original_breakable"){std::string vram,off,tile;ss>>vram>>off>>out.originalMetadata.breakableCount>>tile;out.originalMetadata.breakableVramWord=std::stoi(vram,nullptr,0);out.originalMetadata.breakableTilemapOffset=std::stoi(off,nullptr,0);out.originalMetadata.breakableTileId=std::stoi(tile,nullptr,0);}
  }
  if(out.cameraBounds.w<=0||out.cameraBounds.h<=0)out.cameraBounds={0,0,(float)out.width,(float)out.height};
  return out.width>0&&out.height>0&&(!out.nativeScene.empty()||!out.nativeScenePages.empty()||!out.background.empty());
}
}
