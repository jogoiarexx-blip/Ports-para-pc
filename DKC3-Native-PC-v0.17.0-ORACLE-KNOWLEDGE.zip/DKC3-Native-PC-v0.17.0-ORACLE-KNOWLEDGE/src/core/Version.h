#pragma once
namespace dkc3 {
constexpr const char* kVersion = "0.17.0";
constexpr const char* kVersionName = "Oracle Knowledge Pass";
}
