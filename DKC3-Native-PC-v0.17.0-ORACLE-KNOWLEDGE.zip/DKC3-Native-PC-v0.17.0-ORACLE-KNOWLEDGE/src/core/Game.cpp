#include "Game.h"
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cctype>
namespace dkc3 {
static void approach(float&v,float target,float amount){if(v<target)v=std::min(v+amount,target);else if(v>target)v=std::max(v-amount,target);}
static void drawAnim(const NativeAnimation* a,const AnimationPlayer& p,uint32_t*dst,int w,int h,int x,int y,bool flip){
  if(!a)return;
  auto*f=p.current(*a);if(!f)return;drawNativeSprite(f->sprite,dst,w,h,x+f->offsetX,y+f->offsetY,flip);
}
bool Game::loadAnimationMap(const std::vector<AnimationDef>&defs,std::map<std::string,NativeAnimation>&out){
  out.clear();for(const auto&d:defs){NativeAnimation a;if(!loadNativeAnimation(d.path,a))return false;out[d.state]=std::move(a);}return true;
}
const NativeAnimation* Game::findAnim(const std::map<std::string,NativeAnimation>&set,const std::string&key)const{
  auto i=set.find(key);if(i!=set.end())return &i->second;i=set.find("idle");return i==set.end()?nullptr:&i->second;
}
bool Game::ensureScenePageLoaded(size_t index){
  if(index>=scenePages_.size())return false;
  auto& p=scenePages_[index];
  if(p.loaded)return true;
  NativeScene next;
  if(!loadNativeScene(p.path,next))return false;
  p.scene=std::move(next);p.loaded=true;
  return true;
}
bool Game::prefetchSceneWindow(size_t center){
  if(scenePages_.empty()||center>=scenePages_.size())return true;
  if(!ensureScenePageLoaded(center))return false;
  if(center>0&&!ensureScenePageLoaded(center-1))return false;
  if(center+1<scenePages_.size()&&!ensureScenePageLoaded(center+1))return false;
  return true;
}
void Game::trimScenePageCache(){
  if(scenePages_.empty())return;
  for(size_t i=0;i<scenePages_.size();++i){
    const bool neighbor=(i==activeScenePage_)||(i+1==activeScenePage_)||(activeScenePage_+1==i);
    const bool fading=pageFade_<1.0f&&i==fadeFromPage_;
    if(scenePages_[i].loaded&&!neighbor&&!fading){scenePages_[i].scene=NativeScene{};scenePages_[i].loaded=false;}
  }
}
const std::map<std::string,NativeAnimation>& Game::activeAnimations()const{return activeCharacter_==CharacterId::Dixie?dixieAnimations_:kiddyAnimations_;}
const std::map<std::string,NativeAnimation>& Game::inactiveAnimations()const{return activeCharacter_==CharacterId::Dixie?kiddyAnimations_:dixieAnimations_;}
const NativeSprite& Game::activeFallbackSprite()const{return activeCharacter_==CharacterId::Dixie?playerSprite_:companionSprite_;}
const NativeSprite& Game::inactiveFallbackSprite()const{return activeCharacter_==CharacterId::Dixie?companionSprite_:playerSprite_;}
void Game::setPlayerAnimationState(const std::string&state){if(state!=playerAnimState_){playerAnimState_=state;playerAnimator_.reset();}}
void Game::applyCharacterDimensions(){
  if(activeCharacter_==CharacterId::Dixie){player_.width=18.0f;player_.height=34.0f;}
  else{player_.width=23.0f;player_.height=38.0f;}
}
void Game::switchCharacter(bool manualSwitch){
  if(!partnerAvailable_)return;
  const float feet=player_.pos.y+player_.height;
  activeCharacter_=activeCharacter_==CharacterId::Dixie?CharacterId::Kiddy:CharacterId::Dixie;
  applyCharacterDimensions();player_.pos.y=feet-player_.height;
  playerAnimator_.reset();companionAnimator_.reset();
  if(manualSwitch){++characterSwitches_;emit(Sfx::Switch);}
}
float Game::attackDuration() const { return activeCharacter_==CharacterId::Dixie ? 0.416f : 0.420f; }
float Game::attackReach() const { return activeCharacter_==CharacterId::Dixie ? 28.0f : 34.0f; }
bool Game::attackActive() const {
  if(attackTimer_<=0.0f)return false;
  const float elapsed=attackDuration()-attackTimer_;
  return elapsed>=0.045f && attackTimer_>=0.045f;
}
Rect Game::attackBounds() const {
  const float reach=attackReach();
  const float h=activeCharacter_==CharacterId::Dixie ? 25.0f : 30.0f;
  const float y=player_.pos.y+std::max(2.0f,(player_.height-h)*0.65f);
  if(player_.facingRight)return {player_.pos.x+player_.width-3.0f,y,reach,h};
  return {player_.pos.x-reach+3.0f,y,reach,h};
}
bool Game::leverActivated(const std::string& id)const{for(const auto&l:levers_)if(l.id==id)return l.activated;return false;}
void Game::activateLever(size_t index){
  if(index>=levers_.size()||levers_[index].activated)return;
  auto&l=levers_[index];l.activated=true;l.progress=l.holdTime;++leverActivations_;showToast("PORTAO ABERTO");emit(Sfx::Lever);
  for(auto&g:gates_)if(g.id==l.gateId)g.open=true;
}
void Game::applyDamage(float enemyCenterX){
  if(invulnerableTimer_>0.0f)return;
  ++damageCount_;emit(Sfx::Hurt);
  if(partnerAvailable_){
    switchCharacter(false);
    partnerAvailable_=false;
    player_.vel.x=(player_.pos.x+player_.width*0.5f<enemyCenterX)?-115.0f:115.0f;
    player_.vel.y=-155.0f;player_.grounded=false;player_.motion=PlayerMotion::Air;
    invulnerableTimer_=1.35f;
  }else{
    player_.pos=respawn_;player_.vel={};player_.motion=PlayerMotion::Air;player_.grounded=false;
    partnerAvailable_=true;companionPos_={respawn_.x+world_.companionOffset.x,respawn_.y+world_.companionOffset.y};invulnerableTimer_=1.0f;
  }
}
std::string Game::desiredPlayerAnimation()const{
  if(player_.motion==PlayerMotion::Hang)return "hang";
  if(player_.motion==PlayerMotion::Swim)return "swim";
  if(attackTimer_>0.0f)return "attack";
  if(!player_.grounded)return player_.vel.y<0?"jump":"fall";
  if(std::fabs(player_.vel.x)>12.0f)return "run";
  return "idle";
}
bool Game::init(const char* p,const GamePersistentState* persistent){
  if(!loadWorld(p,world_))return false;
  scenePages_.clear();activeScenePage_=0;hasScene_=false;
  if(!world_.nativeScenePages.empty()){
    for(const auto&d:world_.nativeScenePages){RuntimeScenePage p;p.startX=d.startX;p.path=d.path;scenePages_.push_back(std::move(p));}
    std::sort(scenePages_.begin(),scenePages_.end(),[](const auto&a,const auto&b){return a.startX<b.startX;});
    if(scenePages_.empty()||!ensureScenePageLoaded(0))return false;
    hasScene_=true;
  }else if(!world_.nativeScene.empty()){hasScene_=loadNativeScene(world_.nativeScene,scene_);if(!hasScene_)return false;}
  player_={};player_.pos=world_.spawn;respawn_=world_.spawn;
  activeCharacter_=persistent?persistent->activeCharacter:CharacterId::Dixie;partnerAvailable_=persistent?persistent->partnerAvailable:true;applyCharacterDimensions();
  companionPos_={world_.spawn.x+world_.companionOffset.x,world_.spawn.y+world_.companionOffset.y};
  const NativeScene& initialScene=scenePages_.empty()?scene_:scenePages_[0].scene;camera_.viewportW=hasScene_?initialScene.viewportW:256;camera_.viewportH=hasScene_?initialScene.viewportH:224;
  camera_.x=std::clamp(player_.pos.x-camera_.viewportW*0.5f,world_.cameraBounds.x,std::max(world_.cameraBounds.x,world_.cameraBounds.x+world_.cameraBounds.w-camera_.viewportW));
  camera_.y=std::clamp(player_.pos.y-camera_.viewportH*0.5f,world_.cameraBounds.y,std::max(world_.cameraBounds.y,world_.cameraBounds.y+world_.cameraBounds.h-camera_.viewportH));
  if(!scenePages_.empty()){
    size_t initialPage=0;for(size_t i=1;i<scenePages_.size();++i){if(camera_.x+0.01f>=scenePages_[i].startX)initialPage=i;else break;}
    activeScenePage_=initialPage;fadeFromPage_=initialPage;
    if(!prefetchSceneWindow(activeScenePage_))return false;
    trimScenePageCache();
  }
  if(!world_.playerSprite.empty()&&!loadNativeSprite(world_.playerSprite,playerSprite_))return false;
  if(!world_.companionSprite.empty()&&!loadNativeSprite(world_.companionSprite,companionSprite_))return false;
  if(!loadAnimationMap(world_.playerAnimations,dixieAnimations_)||!loadAnimationMap(world_.companionAnimations,kiddyAnimations_))return false;
  playerAnimState_="idle";companionAnimState_="idle";playerAnimator_.reset();companionAnimator_.reset();coins_=persistent?persistent->coins:0;damageCount_=defeatedEnemies_=characterSwitches_=0;leverActivations_=checkpointActivations_=lockedDoorAttempts_=teamBarrelRescues_=0;kongMask_=0;kongLettersCollected_=0;pendingLevel_.clear();
  sfx_.clear();prevGrounded_=false;prevInWater_=false;waterKnown_=false;lastAirVy_=0.0f;
  levelTime_=0.0f;toastTimer_=0.0f;toast_.clear();pageFade_=1.0f;fadeFromPage_=0;
  attackTimer_=attackCooldown_=invulnerableTimer_=0.0f;activeLever_=-1;inWater_=false;inWaterCurrent_=false;activeWaterCurrent_={};prevUp_=prevJump_=prevAttack_=prevSwitch_=false;
  spriteObjects_.clear();for(const auto&d:world_.spriteObjects){RuntimeSpriteObject o;o.id=d.id;o.pos=d.pos;o.foreground=d.foreground;if(!loadNativeSprite(d.spritePath,o.sprite))return false;spriteObjects_.push_back(std::move(o));}
  levers_.clear();for(const auto&d:world_.levers){RuntimeLever l;l.id=d.id;l.gateId=d.gateId;l.rect=d.rect;l.anchor=d.anchor;l.holdTime=std::max(0.05f,d.holdTime);levers_.push_back(std::move(l));}
  gates_.clear();for(const auto&d:world_.gates){RuntimeGate g;g.id=d.id;g.rect=d.rect;if(!d.spritePath.empty()&&!loadNativeSprite(d.spritePath,g.sprite))return false;gates_.push_back(std::move(g));}
  checkpointActive_.assign(world_.checkpoints.size(),false);
  enemies_.clear();for(const auto&d:world_.enemies){RuntimeEnemy e;e.id=d.id;e.pos=d.pos;e.speed=d.speed;e.minX=d.minX;e.maxX=d.maxX;e.w=d.w;e.h=d.h;e.facingRight=e.speed>0;if(!loadNativeAnimation(d.animationPath,e.animation))return false;enemies_.push_back(std::move(e));}
  collectibles_.clear();for(const auto&d:world_.collectibles){RuntimeCollectible c;c.id=d.id;c.pos=d.pos;c.w=d.w;c.h=d.h;c.value=d.value;if(!loadNativeAnimation(d.animationPath,c.animation))return false;collectibles_.push_back(std::move(c));}
  kongLetters_.clear();for(const auto&d:world_.kongLetters){RuntimeKongLetter k;k.letter=(char)std::toupper((unsigned char)d.letter);k.pos=d.pos;k.w=d.w;k.h=d.h;if(!loadNativeAnimation(d.animationPath,k.animation))return false;kongLetters_.push_back(std::move(k));}
  teamBarrels_.clear();for(const auto&d:world_.teamBarrels){RuntimeTeamBarrel b;b.id=d.id;b.pos=d.pos;b.w=d.w;b.h=d.h;if(!loadNativeSprite(d.spritePath,b.sprite))return false;teamBarrels_.push_back(std::move(b));}
  return true;
}
void Game::updateCamera(float dt){
  const float maxX=std::max(world_.cameraBounds.x,world_.cameraBounds.x+world_.cameraBounds.w-camera_.viewportW);const float maxY=std::max(world_.cameraBounds.y,world_.cameraBounds.y+world_.cameraBounds.h-camera_.viewportH);
  float tx=std::clamp(player_.pos.x+player_.width*0.5f-camera_.viewportW*0.5f,world_.cameraBounds.x,maxX);float ty=std::clamp(player_.pos.y+player_.height*0.5f-camera_.viewportH*0.58f,world_.cameraBounds.y,maxY);
  approach(camera_.x,tx,480.0f*dt);approach(camera_.y,ty,320.0f*dt);
  if(pageFade_<1.0f)pageFade_=std::min(1.0f,pageFade_+dt/0.30f);
  if(!scenePages_.empty()){
    size_t idx=0;for(size_t i=1;i<scenePages_.size();++i){if(camera_.x+0.01f>=scenePages_[i].startX)idx=i;else break;}
    // Histerese ao voltar: em agua com corrente usamos margem maior para a pagina nao oscilar
    // so porque o jogador soltou o direcional logo depois de cruzar a fronteira.
    const float backHysteresis=inWaterCurrent_?18.0f:6.0f;
    if(idx<activeScenePage_&&camera_.x>=scenePages_[activeScenePage_].startX-backHysteresis)idx=activeScenePage_;
    if(idx!=activeScenePage_&&ensureScenePageLoaded(idx)){fadeFromPage_=activeScenePage_;activeScenePage_=idx;pageFade_=0.0f;}
    prefetchSceneWindow(activeScenePage_);
    trimScenePageCache();
  }
}
void Game::render(uint32_t*dst,int w,int h)const{
  if(!dst||w<=0||h<=0)return;
  if(hasScene_){
    renderScenePage(activeScenePage_,dst,w,h);
    if(pageFade_<1.0f&&!scenePages_.empty()&&fadeFromPage_<scenePages_.size()&&fadeFromPage_!=activeScenePage_){
      static thread_local std::vector<uint32_t> from;from.resize((size_t)w*h);renderScenePage(fadeFromPage_,from.data(),w,h);
      const float t=pageFade_*pageFade_*(3.0f-2.0f*pageFade_);const int a=(int)(t*256.0f);
      for(size_t i=0,n=(size_t)w*h;i<n;++i){
        const uint32_t n0=dst[i],f0=from[i];
        auto ch=[&](int sh){int x=(int)((n0>>sh)&255),y=(int)((f0>>sh)&255);return (uint32_t)((y*(256-a)+x*a)>>8);};
        dst[i]=0xff000000u|(ch(16)<<16)|(ch(8)<<8)|ch(0);
      }
    }
  }else std::fill(dst,dst+(size_t)w*h,0xff202020u);
  auto drawObj=[&](bool fg){for(const auto&o:spriteObjects_)if(o.foreground==fg)drawNativeSprite(o.sprite,dst,w,h,(int)(o.pos.x-camera_.x),(int)(o.pos.y-camera_.y));};
  drawObj(false);
  for(const auto&g:gates_)if(!g.open){if(g.sprite.valid())drawNativeSprite(g.sprite,dst,w,h,(int)(g.rect.x-camera_.x),(int)(g.rect.y-camera_.y));else{int x0=std::max(0,(int)(g.rect.x-camera_.x)),y0=std::max(0,(int)(g.rect.y-camera_.y)),x1=std::min(w,(int)(g.rect.x+g.rect.w-camera_.x)),y1=std::min(h,(int)(g.rect.y+g.rect.h-camera_.y));for(int y=y0;y<y1;y++)for(int x=x0;x<x1;x++)dst[(size_t)y*w+x]=0xff8fc8e8u;}}
  for(const auto&c:collectibles_)if(c.active)drawAnim(&c.animation,c.animator,dst,w,h,(int)(c.pos.x-camera_.x),(int)(c.pos.y-camera_.y),false);
  for(const auto&k:kongLetters_)if(k.active)drawAnim(&k.animation,k.animator,dst,w,h,(int)(k.pos.x-camera_.x),(int)(k.pos.y-camera_.y),false);
  for(const auto&b:teamBarrels_)if(b.active&&b.sprite.valid())drawNativeSprite(b.sprite,dst,w,h,(int)(b.pos.x-camera_.x),(int)(b.pos.y-camera_.y));
  for(const auto&e:enemies_)if(e.active)drawAnim(&e.animation,e.animator,dst,w,h,(int)(e.pos.x-camera_.x),(int)(e.pos.y-camera_.y),!e.facingRight);
  if(partnerAvailable_){
    const auto*ca=findAnim(inactiveAnimations(),companionAnimState_);if(ca)drawAnim(ca,companionAnimator_,dst,w,h,(int)(companionPos_.x-camera_.x),(int)(companionPos_.y-camera_.y),!player_.facingRight);else if(inactiveFallbackSprite().valid())drawNativeSprite(inactiveFallbackSprite(),dst,w,h,(int)(companionPos_.x-camera_.x),(int)(companionPos_.y-camera_.y),!player_.facingRight);
  }
  const bool blink=invulnerableTimer_>0.0f && (int(invulnerableTimer_*14.0f)&1);
  if(!blink){const auto*pa=findAnim(activeAnimations(),playerAnimState_);if(pa)drawAnim(pa,playerAnimator_,dst,w,h,(int)(player_.pos.x-camera_.x),(int)(player_.pos.y-camera_.y),!player_.facingRight);else if(activeFallbackSprite().valid())drawNativeSprite(activeFallbackSprite(),dst,w,h,(int)(player_.pos.x-camera_.x),(int)(player_.pos.y-camera_.y),!player_.facingRight);}
  drawObj(true);
  if(hudEnabled_)drawHud(dst,w,h);
  if(debugOverlay_)drawDebug(dst,w,h);
}
void Game::step(const InputState& in,float dt){
  dt=std::max(0.0f,dt);levelTime_+=dt;toastTimer_=std::max(0.0f,toastTimer_-dt);attackTimer_=std::max(0.0f,attackTimer_-dt);attackCooldown_=std::max(0.0f,attackCooldown_-dt);invulnerableTimer_=std::max(0.0f,invulnerableTimer_-dt);
  const bool upPressed=in.up&&!prevUp_,jumpPressed=in.jump&&!prevJump_,attackPressed=in.attack&&!prevAttack_,switchPressed=in.switchCharacter&&!prevSwitch_;
  if(switchPressed&&player_.motion!=PlayerMotion::Hang&&attackTimer_<=0.0f)switchCharacter(true);
  if(attackPressed&&player_.grounded&&player_.motion!=PlayerMotion::Hang&&player_.motion!=PlayerMotion::Swim&&attackCooldown_<=0.0f){
    attackTimer_=attackDuration();attackCooldown_=0.50f;emit(Sfx::Roll);
    player_.vel.x=player_.facingRight?(activeCharacter_==CharacterId::Dixie?172.0f:184.0f):-(activeCharacter_==CharacterId::Dixie?172.0f:184.0f);
  }
  if(player_.motion==PlayerMotion::Hang){
    if(activeLever_>=0&&(size_t)activeLever_<levers_.size()&&!levers_[(size_t)activeLever_].activated){auto&l=levers_[(size_t)activeLever_];l.progress=std::min(l.holdTime,l.progress+dt);if(l.progress>=l.holdTime)activateLever((size_t)activeLever_);}
    if(jumpPressed||in.down||in.left||in.right){if(jumpPressed)emit(Sfx::Jump);player_.motion=PlayerMotion::Air;player_.vel.y=jumpPressed?-170.0f:70.0f;if(in.left){player_.vel.x=-70;player_.facingRight=false;}if(in.right){player_.vel.x=70;player_.facingRight=true;}activeLever_=-1;}
  }else{
    if(upPressed){
      for(size_t i=0;i<levers_.size();i++)if(overlaps(player_.bounds(),levers_[i].rect)){player_.pos=levers_[i].anchor;player_.vel={};player_.motion=PlayerMotion::Hang;player_.grounded=false;activeLever_=(int)i;break;}
      if(player_.motion!=PlayerMotion::Hang){for(const auto&z:world_.hangZones)if(overlaps(player_.bounds(),z.rect)){player_.pos=z.anchor;player_.vel={};player_.motion=PlayerMotion::Hang;player_.grounded=false;activeLever_=-1;break;}}
    }
    if(player_.motion!=PlayerMotion::Hang){
      InputState movement=in;if(attackTimer_>0.0f){movement.run=true;movement.left=!player_.facingRight;movement.right=player_.facingRight;}
      std::vector<Rect> collisions=world_.solids;for(const auto&g:gates_)if(!g.open)collisions.push_back(g.rect);
      bool water=false;for(const auto&w:world_.waterZones)if(overlaps(player_.bounds(),w)){water=true;break;}
      inWater_=water;inWaterCurrent_=false;activeWaterCurrent_={};
      if(water){for(const auto&c:world_.waterCurrents)if(overlaps(player_.bounds(),c.rect)){activeWaterCurrent_.x+=c.drift.x;activeWaterCurrent_.y+=c.drift.y;inWaterCurrent_=true;}}
      if(water)updateSwimPlayer(player_,movement,dt,collisions.data(),(int)collisions.size(),activeWaterCurrent_);
      else{if(player_.motion==PlayerMotion::Swim)player_.motion=PlayerMotion::Air;updatePlayer(player_,movement,dt,collisions.data(),(int)collisions.size());}
    }
  }
  // v0.9.0: sons de movimento (pulo, pouso, entrar/sair da agua).
  if(player_.justJumped)emit(Sfx::Jump);
  if(player_.grounded&&!prevGrounded_&&lastAirVy_>150.0f&&player_.motion==PlayerMotion::Ground)emit(Sfx::Land);
  if(!player_.grounded)lastAirVy_=player_.vel.y;
  prevGrounded_=player_.grounded;
  if(!waterKnown_){prevInWater_=inWater_;waterKnown_=true;}
  else if(inWater_!=prevInWater_){emit(Sfx::Splash);prevInWater_=inWater_;}
  // v0.8.0: paredes invisiveis nas bordas horizontais da fase (antes era possivel nadar/andar para fora do mapa).
  if(player_.pos.x<0.0f){player_.pos.x=0.0f;if(player_.vel.x<0.0f)player_.vel.x=0.0f;}
  if(player_.pos.x+player_.width>(float)world_.width){player_.pos.x=(float)world_.width-player_.width;if(player_.vel.x>0.0f)player_.vel.x=0.0f;}
  for(size_t i=0;i<world_.checkpoints.size();i++)if(overlaps(player_.bounds(),world_.checkpoints[i].rect)){respawn_=world_.checkpoints[i].respawn;if(i<checkpointActive_.size()&&!checkpointActive_[i]){checkpointActive_[i]=true;++checkpointActivations_;showToast("CHECKPOINT");emit(Sfx::Checkpoint);}}
  if(player_.pos.y>world_.height+64||player_.pos.x<-96||player_.pos.x>world_.width+96){player_.pos=respawn_;player_.vel={};player_.motion=PlayerMotion::Air;activeLever_=-1;partnerAvailable_=true;companionPos_={respawn_.x+world_.companionOffset.x,respawn_.y+world_.companionOffset.y};invulnerableTimer_=1.0f;}
  if(upPressed&&player_.motion!=PlayerMotion::Hang){for(const auto&d:world_.doors)if(overlaps(player_.bounds(),d.rect)){if(d.requiresLever.empty()||leverActivated(d.requiresLever)){pendingLevel_=d.target;emit(Sfx::Door);}else{++lockedDoorAttempts_;showToast("PORTA TRANCADA");emit(Sfx::Locked);}break;}}
  if(partnerAvailable_){float targetX=player_.pos.x+world_.companionOffset.x,targetY=player_.pos.y+world_.companionOffset.y;approach(companionPos_.x,targetX,220.0f*dt);approach(companionPos_.y,targetY,180.0f*dt);}
  for(auto&e:enemies_)if(e.active){
    e.pos.x+=e.speed*dt;
    if(e.pos.x<e.minX){e.pos.x=e.minX;e.speed=std::fabs(e.speed);e.facingRight=true;}
    else if(e.pos.x>e.maxX){e.pos.x=e.maxX;e.speed=-std::fabs(e.speed);e.facingRight=false;}
    e.animator.step(e.animation,dt);
    const Rect pb=player_.bounds(),eb=e.bounds();
    const bool attackHit=attackActive() && overlaps(attackBounds(),eb);
    if(attackHit){
      e.active=false;++defeatedEnemies_;emit(Sfx::EnemyHit);
      attackTimer_=std::max(attackTimer_,0.16f);
      player_.vel.x=player_.facingRight?(activeCharacter_==CharacterId::Dixie?158.0f:170.0f):-(activeCharacter_==CharacterId::Dixie?158.0f:170.0f);
      continue;
    }
    if(overlaps(pb,eb)){
      const float playerBottom=pb.y+pb.h;
      const bool stomp=player_.vel.y>45.0f && playerBottom<=eb.y+std::max(10.0f,eb.h*0.55f);
      if(stomp){
        e.active=false;++defeatedEnemies_;emit(Sfx::Stomp);
        player_.pos.y=e.pos.y-player_.height;player_.vel.y=-185.0f;player_.grounded=false;player_.motion=PlayerMotion::Air;
      }else applyDamage(e.pos.x+e.w*0.5f);
    }
  }
  for(auto&c:collectibles_)if(c.active){c.animator.step(c.animation,dt);if(overlaps(player_.bounds(),c.bounds())){c.active=false;coins_+=c.value;emit(Sfx::Coin);}}
  // v0.13.0: K-O-N-G fica separado das moedas. As letras giram usando frames
  // autenticos importados da OAM e o HUD acompanha o progresso da fase.
  for(auto&k:kongLetters_)if(k.active){
    k.animator.step(k.animation,dt);
    if(overlaps(player_.bounds(),k.bounds())){
      k.active=false;unsigned bit=0;
      switch(k.letter){case 'K':bit=1u;break;case 'O':bit=2u;break;case 'N':bit=4u;break;case 'G':bit=8u;break;default:break;}
      if(bit&&!(kongMask_&bit)){kongMask_|=bit;++kongLettersCollected_;emit(Sfx::Coin);if(kongMask_==15u)showToast("KONG COMPLETO");else showToast(std::string("LETRA ")+k.letter);}
    }
  }
  // v0.12.0: primeiro comportamento nativo do DK Barrel. Ainda nao ha sistema de
  // carregar/arremessar barris; quando o jogador esta SOLO, tocar nele restaura a dupla.
  for(auto&b:teamBarrels_)if(b.active&&!partnerAvailable_&&overlaps(player_.bounds(),b.bounds())){
    b.active=false;partnerAvailable_=true;++teamBarrelRescues_;
    companionPos_={player_.pos.x+world_.companionOffset.x,player_.pos.y+world_.companionOffset.y};
    emit(Sfx::Switch);showToast("DUPLA RESTAURADA");
  }
  setPlayerAnimationState(desiredPlayerAnimation());const auto*pa=findAnim(activeAnimations(),playerAnimState_);if(pa)playerAnimator_.step(*pa,dt);
  std::string desiredComp=desiredPlayerAnimation();if(desiredComp=="attack")desiredComp="run";
  if(desiredComp!=companionAnimState_){companionAnimState_=desiredComp;companionAnimator_.reset();}
  const auto*ca=findAnim(inactiveAnimations(),companionAnimState_);if(ca)companionAnimator_.step(*ca,dt);
  updateCamera(dt);prevUp_=in.up;prevJump_=in.jump;prevAttack_=in.attack;prevSwitch_=in.switchCharacter;
}
void Game::renderScenePage(size_t index,uint32_t*dst,int w,int h)const{
  if(scenePages_.empty()){renderNativeScene(scene_,dst,w,h,(int)camera_.x,(int)camera_.y);return;}
  const auto&p=scenePages_[std::min(index,scenePages_.size()-1)];
  if(!p.loaded){std::fill(dst,dst+(size_t)w*h,0xff000000u);return;}
  renderNativeScene(p.scene,dst,w,h,(int)(camera_.x-p.startX),(int)camera_.y);
}
void Game::drawHud(uint32_t*dst,int w,int h)const{
  const bool dixie=activeCharacter_==CharacterId::Dixie;
  const std::string name=dixie?"DIXIE":"KIDDY";const uint32_t nameColor=dixie?0xffff9ad2u:0xff7fd0ffu;
  char coinBuf[16];std::snprintf(coinBuf,sizeof coinBuf,"%03d",coins_);
  const std::string line2=std::string("MOEDAS ")+coinBuf;const std::string tag=partnerAvailable_?"DUPLA":"SOLO";
  const bool showKong=!kongLetters_.empty();
  const int kongW=hudTextWidth("K O N G");
  const int boxW=std::max({hudTextWidth(line2),hudTextWidth(name)+4+hudTextWidth(tag),showKong?kongW:0})+8;
  hudFillRect(dst,w,h,4,4,boxW,showKong?35:25,0x000000u,120);
  hudDrawText(dst,w,h,8,8,name,nameColor);
  hudDrawText(dst,w,h,8+hudTextWidth(name)+4,8,tag,partnerAvailable_?0xffa8ffa8u:0xffff8080u);
  hudDrawText(dst,w,h,8,18,line2,0xffffffffu);
  if(showKong){
    const char letters[4]={'K','O','N','G'};const unsigned bits[4]={1u,2u,4u,8u};int x=8;
    for(int i=0;i<4;i++){char t[2]={letters[i],0};hudDrawText(dst,w,h,x,28,t,(kongMask_&bits[i])?0xffffd840u:0xff707070u);x+=hudTextWidth(t)+hudTextWidth(" ");}
  }
  // Cartao de titulo da fase (some em ~2.8 s).
  if(levelTime_<2.8f){
    std::string title=world_.displayName.empty()?world_.id:world_.displayName;const auto par=title.find(" (");if(par!=std::string::npos)title.resize(par);
    const float a=levelTime_<2.0f?1.0f:std::max(0.0f,(2.8f-levelTime_)/0.8f);const int ty=(int)(h*0.36f);
    hudFillRect(dst,w,h,0,ty-6,w,26,0x000000u,(int)(130*a));
    if(a>0.45f)hudDrawText(dst,w,h,(w-hudTextWidth(title,2))/2,ty,title,0xffffe9a8u,2);
  }
  if(toastTimer_>0.0f&&!toast_.empty()){
    const int tw=hudTextWidth(toast_,1)+12;const int tx=(w-tw)/2,ty=h-28;
    hudFillRect(dst,w,h,tx,ty-3,tw,15,0x000000u,150);hudDrawText(dst,w,h,tx+6,ty,toast_,0xffffffffu);
  }
}
void Game::drawDebug(uint32_t*dst,int w,int h)const{
  auto box=[&](const Rect&r,uint32_t c){hudOutlineRect(dst,w,h,(int)(r.x-camera_.x),(int)(r.y-camera_.y),(int)r.w,(int)r.h,c);};
  for(const auto&r:world_.solids)box(r,0x40ff40);
  for(const auto&r:world_.waterZones)box(r,0x40a0ff);
  for(const auto&c:world_.waterCurrents)box(c.rect,0x40ffff);
  for(const auto&d:world_.doors)box(d.rect,0xffe040);
  for(const auto&c:world_.checkpoints)box(c.rect,0xff40ff);
  for(const auto&z:world_.hangZones)box(z.rect,0xff9020);
  for(const auto&l:levers_)box(l.rect,0x40ffff);
  for(const auto&g:gates_)if(!g.open)box(g.rect,0xff4040);
  for(const auto&e:enemies_)if(e.active)box(e.bounds(),0xff4040);
  for(const auto&c:collectibles_)if(c.active)box(c.bounds(),0xffe040);
  for(const auto&k:kongLetters_)if(k.active)box(k.bounds(),0xffff40);
  for(const auto&b:teamBarrels_)if(b.active)box(b.bounds(),0xffa020);
  box(player_.bounds(),0xffffff);
  if(attackActive())box(attackBounds(),0xff2020);
  char buf[224];
  if(inWaterCurrent_)std::snprintf(buf,sizeof buf,"CAM %d,%d PAG %d/%d CACHE %d X %d Y %d COR %d,%d",(int)camera_.x,(int)camera_.y,(int)activeScenePage()+1,(int)scenePageCount(),(int)loadedScenePageCount(),(int)player_.pos.x,(int)player_.pos.y,(int)activeWaterCurrent_.x,(int)activeWaterCurrent_.y);
  else std::snprintf(buf,sizeof buf,"CAM %d,%d PAG %d/%d CACHE %d X %d Y %d",(int)camera_.x,(int)camera_.y,(int)activeScenePage()+1,(int)scenePageCount(),(int)loadedScenePageCount(),(int)player_.pos.x,(int)player_.pos.y);
  hudFillRect(dst,w,h,0,h-11,hudTextWidth(buf)+8,11,0x000000u,170);hudDrawText(dst,w,h,4,h-9,buf,0xffffffffu);
}
}
