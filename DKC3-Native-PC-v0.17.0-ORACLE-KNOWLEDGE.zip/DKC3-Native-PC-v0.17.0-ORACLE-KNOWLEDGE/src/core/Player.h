#pragma once
#include "Math.h"
#include "Input.h"
namespace dkc3 {
enum class PlayerMotion { Ground, Air, Hang, Swim };
struct Player {
  Vec2 pos{92,132};
  Vec2 vel{};
  float width=18, height=34;
  bool grounded=false;
  bool facingRight=true;
  PlayerMotion motion=PlayerMotion::Air;
  // Estado de "feel" (v0.8.0): coyote time, buffer de pulo e pulo de altura variavel.
  float coyoteTimer=0.0f, jumpBuffer=0.0f, jumpTime=0.0f;
  bool jumpWasDown=false, jumping=false, justJumped=false;
  Rect bounds() const { return {pos.x,pos.y,width,height}; }
};
void updatePlayer(Player& p, const InputState& in, float dt, const Rect* solids, int solidCount);
void updateSwimPlayer(Player& p, const InputState& in, float dt, const Rect* solids, int solidCount, Vec2 current = {});
}
