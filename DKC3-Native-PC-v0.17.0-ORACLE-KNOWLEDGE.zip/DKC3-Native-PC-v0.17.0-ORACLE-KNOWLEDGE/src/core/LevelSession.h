#pragma once
#include "Game.h"
#include <map>
#include <string>
namespace dkc3 {
struct LevelCatalogEntry { std::string id; std::string path; };
class LevelCatalog {
 public:
  bool load(const std::string& path);
  const LevelCatalogEntry* find(const std::string& id) const;
  size_t size() const { return entries_.size(); }
 private:
  std::map<std::string,LevelCatalogEntry> entries_;
};
class GameSession {
 public:
  bool init(const std::string& catalogPath,const std::string& startLevel);
  void step(const InputState& in,float dt);
  // v0.8.0: recarrega a fase atual do zero (tecla R), preservando o catalogo.
  bool restart();
  // v0.9.0: sons acumulados (inclui os emitidos no quadro em que a fase trocou).
  std::vector<Sfx> takeSfx(){std::vector<Sfx> o;o.swap(sfx_);return o;}
  void render(uint32_t* dst,int w,int h) const { game_.render(dst,w,h); }
  const Game& game() const { return game_; }
  Game& game() { return game_; }
  const std::string& currentLevel() const { return currentLevel_; }
  int transitions() const { return transitions_; }
  const LevelCatalog& catalog() const { return catalog_; }
 private:
  bool loadLevel(const std::string& id,const GamePersistentState* persistent);
  LevelCatalog catalog_;
  Game game_;
  std::string currentLevel_;
  int transitions_=0;
  std::vector<Sfx> sfx_;
};
}
