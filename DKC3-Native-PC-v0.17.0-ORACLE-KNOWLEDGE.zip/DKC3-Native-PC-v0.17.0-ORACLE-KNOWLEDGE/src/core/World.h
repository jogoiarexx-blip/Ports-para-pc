#pragma once
#include "Math.h"
#include <vector>
#include <string>
namespace dkc3 {
struct Door { Rect rect; std::string target; std::string requiresLever; };
struct Checkpoint { Rect rect; Vec2 respawn; };
struct HangZone { Rect rect; Vec2 anchor; };
struct LeverDef { std::string id; Rect rect; Vec2 anchor; std::string gateId; float holdTime=0.45f; };
struct GateDef { std::string id; Rect rect; std::string spritePath; };
struct WorldSpriteDef { std::string id; Vec2 pos; std::string spritePath; bool foreground=false; };
struct AnimationDef { std::string state; std::string path; };
struct NativeScenePageDef { float startX=0; std::string path; };
struct EnemyDef { std::string id; Vec2 pos; float speed=30; float minX=0,maxX=0; std::string animationPath; float w=24,h=24; };
struct CollectibleDef { std::string id; Vec2 pos; std::string animationPath; float w=20,h=20; int value=1; };
// v0.13.0: letras K-O-N-G autenticas podem ser importadas da OAM e coletadas
// independentemente das moedas comuns. O progresso e por fase e reinicia ao trocar/reiniciar fase.
struct KongLetterDef { char letter='K'; Vec2 pos; std::string animationPath; float w=16,h=28; };
// v0.12.0: DK Barrel simplificado. O sprite vem de captura OAM autentica, mas o
// comportamento nativo atual restaura imediatamente o parceiro ao tocar no barril.
struct TeamBarrelDef { std::string id; Vec2 pos; std::string spritePath; float w=30,h=38; };
// v0.11.0: correnteza por zona. drift e a velocidade ambiental (px/s) somada ao alvo do nado.
struct WaterCurrentDef { Rect rect; Vec2 drift; };
struct OriginalPoint { std::string kind; int index=0; int flags=0; int x=0,y=0; };
struct OriginalConnection { int slot=0; int targetLevelId=0; };
struct OriginalLevelMetadata {
  int romOffset=-1;
  int levelType=-1;
  int songId=-1;
  int sharedData=-1;
  std::vector<OriginalPoint> points;
  std::vector<OriginalConnection> connections;
  int breakableVramWord=-1;
  int breakableTilemapOffset=-1;
  int breakableCount=0;
  int breakableTileId=-1;
};
struct World {
  std::string id,displayName; int originalLevelId=-1; bool bootstrap=false;
  int width=256,height=224;
  std::vector<Rect> solids,waterZones;
  std::vector<WaterCurrentDef> waterCurrents;
  std::string background,nativeScene;
  std::vector<NativeScenePageDef> nativeScenePages;
  Vec2 spawn{55,133};
  Rect cameraBounds{0,0,256,224};
  std::string playerSprite,companionSprite;
  Vec2 companionOffset{-28,-6};
  std::vector<AnimationDef> playerAnimations,companionAnimations;
  std::vector<Door> doors;
  std::vector<Checkpoint> checkpoints;
  std::vector<HangZone> hangZones;
  std::vector<LeverDef> levers;
  std::vector<GateDef> gates;
  std::vector<WorldSpriteDef> spriteObjects;
  std::vector<EnemyDef> enemies;
  std::vector<CollectibleDef> collectibles;
  std::vector<KongLetterDef> kongLetters;
  std::vector<TeamBarrelDef> teamBarrels;
  OriginalLevelMetadata originalMetadata;
};
bool loadWorld(const std::string& path, World& out);
}
