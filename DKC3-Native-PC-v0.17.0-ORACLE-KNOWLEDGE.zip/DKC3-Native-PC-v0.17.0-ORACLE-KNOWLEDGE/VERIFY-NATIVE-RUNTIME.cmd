@echo off
setlocal
cd /d "%~dp0"
set BAD=0
for %%E in (sfc smc state srm sav) do (
  for /r %%F in (*.%%E) do (
    echo ERRO: arquivo de ROM/save-state no runtime: %%~fF
    set BAD=1
  )
)
for %%D in (input tools src tests) do if exist "%%D" (
  echo ERRO: pasta de desenvolvimento presente no runtime: %%D
  set BAD=1
)
if not exist DKC3NativePC.exe (
  echo ERRO: DKC3NativePC.exe nao encontrado.
  set BAD=1
)
if "%BAD%"=="1" exit /b 1
echo OK: runtime portatil limpo. Nenhuma ROM/save-state/ferramenta de oracle foi encontrada.
exit /b 0
