@echo off
call "%~dp0AUTO-PREPARE-CAPTURE.cmd" 0x2B skiddas
exit /b %errorlevel%
