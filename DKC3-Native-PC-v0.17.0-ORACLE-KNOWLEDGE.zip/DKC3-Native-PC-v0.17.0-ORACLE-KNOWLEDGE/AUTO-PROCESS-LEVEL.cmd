@echo off
setlocal EnableDelayedExpansion
cd /d "%~dp0"
if "%~1"=="" goto :usage
set SLUG=%~1
set OUT=docs\oracle-auto\%SLUG%
set ROOT=assets\levels\%SLUG%\native\pages
set KNOW=tools\offline_import\%SLUG%-known-groups.csv
where cmake >nul 2>nul || (echo ERRO: CMake nao encontrado.& pause & exit /b 1)
echo ==================================================
echo DKC3 v0.17 - AUTO PROCESS LEVEL: %SLUG%
echo ==================================================
cmake -S . -B build-tools -G "Visual Studio 17 2022" -A x64 -DDKC3_BUILD_OFFLINE_IMPORTER=ON || goto :err
cmake --build build-tools --config Release --target dkc3_import_scene_state dkc3_oracle_batch dkc3_update_level_pages dkc3_make_level_scaffold || goto :err
if not exist "%ROOT%" mkdir "%ROOT%"
set COUNT=0
set ARGS=
if exist "tools\offline_import\%SLUG%-opening.state" (
  if exist "%ROOT%\page0" rmdir /S /Q "%ROOT%\page0"
  build-tools\Release\dkc3_import_scene_state.exe "tools\offline_import\%SLUG%-opening.state" "%ROOT%\page0" "%SLUG%-page0" || goto :err
  set ARGS=!ARGS! "%CD%\tools\offline_import\%SLUG%-opening.state"
  set /a COUNT+=1
)
if exist "tools\offline_import\%SLUG%-page*.state" (
  for %%F in (tools\offline_import\%SLUG%-page*.state) do (
    set N=%%~nF
    set N=!N:%SLUG%-page=!
    if exist "%ROOT%\page!N!" rmdir /S /Q "%ROOT%\page!N!"
    echo Importando %SLUG% page !N!...
    build-tools\Release\dkc3_import_scene_state.exe "%%F" "%ROOT%\page!N!" "%SLUG%-page!N!" || goto :err
    set ARGS=!ARGS! "%%~fF"
    set /a COUNT+=1
  )
)
if !COUNT! EQU 0 (
  echo ERRO: nenhuma captura encontrada para %SLUG%.
  echo Esperado: tools\offline_import\%SLUG%-opening.state ou %SLUG%-pageN.state
  if not defined DKC3_NOPAUSE pause
  exit /b 2
)
if exist "assets\levels\%SLUG%\%SLUG%.level" (
  echo Atualizando manifest de paginas da fase...
  build-tools\Release\dkc3_update_level_pages.exe "assets\levels\%SLUG%\%SLUG%.level" "%ROOT%" "%SLUG%" 96 320 || goto :err
) else (
  if exist "assets\levels\original_metadata\%SLUG%.original.txt" (
    echo Criando scaffold nativo inicial para %SLUG%...
    build-tools\Release\dkc3_make_level_scaffold.exe "assets\levels\original_metadata\%SLUG%.original.txt" "assets\levels\%SLUG%\%SLUG%.level" "%SLUG%" "%ROOT%" 96 320 || goto :err
    findstr /B /C:"level %SLUG% " assets\levels\levels.index >nul 2>nul || echo level %SLUG% %SLUG%/%SLUG%.level>>assets\levels\levels.index
  ) else (
    echo AVISO: metadata original de %SLUG% nao encontrada; nao foi possivel criar scaffold.
  )
)
if exist "%OUT%" rmdir /S /Q "%OUT%"
set KNOWARG=
if exist "%KNOW%" set KNOWARG=--knowledge "%KNOW%"
build-tools\Release\dkc3_oracle_batch.exe "%OUT%" !KNOWARG! !ARGS! || goto :err
echo.
echo AUTO_LEVEL_OK level=%SLUG% captures=!COUNT!
echo Paginas: %ROOT%
echo Resumo: %OUT%\SUMMARY.txt
echo Conhecidos: %OUT%\known-detections.csv
echo Novos: %OUT%\AUTO-NEW-CANDIDATES.md
if not defined DKC3_NOPAUSE pause
exit /b 0
:usage
echo Uso: AUTO-PROCESS-LEVEL.cmd ID-DA-FASE
echo Exemplo: AUTO-PROCESS-LEVEL.cmd tidal-trouble
echo Exemplo: AUTO-PROCESS-LEVEL.cmd skiddas-row
if not defined DKC3_NOPAUSE pause
exit /b 2
:err
echo FALHA AO PROCESSAR %SLUG%.
if not defined DKC3_NOPAUSE pause
exit /b 1
