@echo off
setlocal
cd /d "%~dp0"
if "%~1"=="" goto :usage
set LEVEL=%~1
set NAME=%~2
if "%NAME%"=="" set NAME=level-%LEVEL%
where cmake >nul 2>nul || (echo ERRO: CMake nao encontrado.& pause & exit /b 1)
if not exist input\dkc3_ptbr.sfc (echo ERRO: input\dkc3_ptbr.sfc nao encontrado.& pause & exit /b 1)
cmake -S . -B build-tools -G "Visual Studio 17 2022" -A x64 -DDKC3_BUILD_OFFLINE_IMPORTER=ON || goto :err
cmake --build build-tools --config Release --target dkc3_make_capture_rom || goto :err
if not exist tools\offline_import\_temp mkdir tools\offline_import\_temp
build-tools\Release\dkc3_make_capture_rom.exe input\dkc3_ptbr.sfc tools\offline_import\_temp\%NAME%-capture-temp.sfc --source-level %LEVEL% || goto :err
echo.
echo ROM TEMPORARIA DE CAPTURA CRIADA:
echo tools\offline_import\_temp\%NAME%-capture-temp.sfc
echo NAO copie esta ROM para bin/runtime.
if not defined DKC3_NOPAUSE pause
exit /b 0
:usage
echo Uso: AUTO-PREPARE-CAPTURE.cmd LEVEL_ID NOME
echo Exemplo: AUTO-PREPARE-CAPTURE.cmd 0x2B skiddas
if not defined DKC3_NOPAUSE pause
exit /b 2
:err
echo FALHA AO PREPARAR A ROM TEMPORARIA.
if not defined DKC3_NOPAUSE pause
exit /b 1
