DKC3 Native PC v0.17.0 - runtime portatil

Este runtime usa somente C++ nativo + assets convertidos em assets/.
Nao precisa e nao deve conter ROM .sfc/.smc, save-state ou ferramentas offline.

Destaques atuais:
- Doorstop Dash: gameplay nativo, equipe Dixie/Kiddy, combate, alavanca/portao, checkpoint e transicao.
- Tidal Trouble: 3 paginas graficas autenticas convertidas offline, streaming/cache nativo e correnteza.
- DK Barrel autentico extraido da OAM: restaura a dupla quando o jogador esta SOLO.
- Letra K autentica de Tidal: dois frames de giro extraidos de capturas OAM diferentes; sistema K-O-N-G e HUD de progresso prontos para O/N/G.
- Kiddy em Tidal: animacao de natacao com 3 poses OAM autenticas e ancora estabilizada, sem reutilizar o salto.
- Sneek autentico em Tidal: sprite OAM real confirmado no framebuffer, patrulha nativa, hitbox/dano/stomp/ataque e debug F4.
- HUD/debug, tela cheia, escala inteira, filtro suave opcional, screenshots e efeitos sonoros nativos.

Controles principais:
A/D ou setas = mover | Z/Espaco = pular/impulso de nado | W/S = subir/descer na agua
Shift = correr | X = roll/cartwheel | Q = trocar Kong | F4 = debug | F7 = filtro | F11 = tela cheia
M = mudo | +/- = volume | R/F5 = reiniciar fase
