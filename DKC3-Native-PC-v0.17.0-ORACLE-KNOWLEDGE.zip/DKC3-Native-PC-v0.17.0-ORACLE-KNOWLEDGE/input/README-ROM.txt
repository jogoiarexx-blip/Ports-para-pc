DKC3 Native PC - ROM de origem do projeto

- dkc3_ptbr.sfc: ROM modificada/ traduzida usada como FONTE de importacao e referencia.
- O runtime nativo NAO abre nem executa esta ROM.
- Os assets convertidos do port ficam em assets/ e os dados nativos em data/.
- A ROM permanece em input/ para futuras conversoes e comparacoes.
