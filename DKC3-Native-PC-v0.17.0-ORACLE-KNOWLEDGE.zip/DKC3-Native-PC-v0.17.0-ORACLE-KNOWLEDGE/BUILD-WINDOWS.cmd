@echo off
setlocal
cd /d "%~dp0"
where cmake >nul 2>nul || (echo ERRO: CMake nao encontrado.& pause & exit /b 1)
cmake -S . -B build-win -G "Visual Studio 17 2022" -A x64 || goto :err
cmake --build build-win --config Release --target DKC3NativePC dkc3_native_core_tests dkc3_native_frames dkc3_native_sfx || goto :err
ctest --test-dir build-win -C Release --output-on-failure || goto :err
if exist bin rmdir /S /Q bin
mkdir bin
copy /Y build-win\Release\DKC3NativePC.exe bin\DKC3NativePC.exe >nul
xcopy /E /I /Y assets bin\assets >nul
copy /Y RUN-WINDOWS.cmd bin\RUN-WINDOWS.cmd >nul
copy /Y RUN-TIDAL.cmd bin\RUN-TIDAL.cmd >nul
copy /Y VERIFY-NATIVE-RUNTIME.cmd bin\VERIFY-NATIVE-RUNTIME.cmd >nul
copy /Y RUNTIME-README.txt bin\RUNTIME-README.txt >nul
copy /Y VERSION.txt bin\VERSION.txt >nul
call bin\VERIFY-NATIVE-RUNTIME.cmd || goto :err
powershell -NoProfile -ExecutionPolicy Bypass -Command "Compress-Archive -Path 'bin\*' -DestinationPath 'DKC3-Native-PC-v0.17.0-Portable-Windows-x64.zip' -Force" || goto :err
echo.
echo OK: bin\DKC3NativePC.exe
echo OK: DKC3-Native-PC-v0.17.0-Portable-Windows-x64.zip
pause
exit /b 0
:err
echo.
echo FALHA NO BUILD NATIVO.
pause
exit /b 1
