@echo off
setlocal
cd /d "%~dp0"
where cmake >nul 2>nul || (echo ERRO: CMake nao encontrado.& pause & exit /b 1)
if not exist input\dkc3_ptbr.sfc (echo ERRO: input\dkc3_ptbr.sfc nao encontrado.& pause & exit /b 1)
cmake -S . -B build-tools -G "Visual Studio 17 2022" -A x64 -DDKC3_BUILD_OFFLINE_IMPORTER=ON || goto :err
cmake --build build-tools --config Release --target dkc3_make_capture_rom || goto :err
if not exist tools\offline_import\_temp mkdir tools\offline_import\_temp
call :make 0x25 lakeside-limbo || goto :err
call :make 0x26 kreeping-klasps || goto :err
call :make 0x27 tidal-trouble || goto :err
call :make 0x28 doorstop-dash || goto :err
call :make 0x29 squeals-on-wheels || goto :err
call :make 0x2A murky-mill || goto :err
call :make 0x2B skiddas-row || goto :err
echo.
echo CAPTURE_QUEUE_OK: 7 ROMs temporarias preparadas em tools\offline_import\_temp
pause
exit /b 0
:make
build-tools\Release\dkc3_make_capture_rom.exe input\dkc3_ptbr.sfc tools\offline_import\_temp\%2-capture-temp.sfc --source-level %1
exit /b %errorlevel%
:err
echo FALHA AO PREPARAR A FILA DE CAPTURAS.
pause
exit /b 1
