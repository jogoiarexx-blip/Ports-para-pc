@echo off
setlocal
cd /d "%~dp0"
where cmake >nul 2>nul || (echo ERRO: CMake nao encontrado.& pause & exit /b 1)
cmake -S . -B build-tools -G "Visual Studio 17 2022" -A x64 -DDKC3_BUILD_OFFLINE_IMPORTER=ON || goto :err
cmake --build build-tools --config Release --target dkc3_import_oam_group || goto :err
if not exist assets\levels\tidal-trouble\native\entities mkdir assets\levels\tidal-trouble\native\entities
if not exist assets\levels\tidal-trouble\native\sprites mkdir assets\levels\tidal-trouble\native\sprites
if not exist assets\levels\tidal-trouble\native\anims mkdir assets\levels\tidal-trouble\native\anims
if not exist assets\levels\tidal-trouble\native\enemies mkdir assets\levels\tidal-trouble\native\enemies
if not exist docs\native_scene_previews mkdir docs\native_scene_previews
build-tools\Release\dkc3_import_oam_group.exe ^
  tools\offline_import\tidal-trouble-opening.state 8 20 208 23 ^
  assets\levels\tidal-trouble\native\entities\dk_barrel.nspr ^
  docs\native_scene_previews\tidal-dk-barrel.bmp || goto :err
build-tools\Release\dkc3_import_oam_group.exe ^
  tools\offline_import\tidal-trouble-page1.state 27 31 188 42 ^
  assets\levels\tidal-trouble\native\entities\kong_k_0.nspr ^
  docs\native_scene_previews\tidal-kong-k-0.bmp || goto :err
build-tools\Release\dkc3_import_oam_group.exe ^
  tools\offline_import\tidal-trouble-page2.state 25 28 234 48 ^
  assets\levels\tidal-trouble\native\entities\kong_k_1.nspr ^
  docs\native_scene_previews\tidal-kong-k-1.bmp || goto :err
build-tools\Release\dkc3_import_oam_group.exe ^
  tools\offline_import\tidal-trouble-opening.state 0 7 68 105 ^
  assets\levels\tidal-trouble\native\sprites\kiddy_swim_0.nspr ^
  docs\native_scene_previews\tidal-kiddy-swim-0.bmp || goto :err
build-tools\Release\dkc3_import_oam_group.exe ^
  tools\offline_import\tidal-trouble-page1.state 6 15 12 136 ^
  assets\levels\tidal-trouble\native\sprites\kiddy_swim_1.nspr ^
  docs\native_scene_previews\tidal-kiddy-swim-1.bmp || goto :err
build-tools\Release\dkc3_import_oam_group.exe ^
  tools\offline_import\tidal-trouble-page2.state 5 13 61 133 ^
  assets\levels\tidal-trouble\native\sprites\kiddy_swim_2.nspr ^
  docs\native_scene_previews\tidal-kiddy-swim-2.bmp || goto :err
build-tools\Release\dkc3_import_oam_group.exe ^
  tools\offline_import\tidal-trouble-page2.state 14 24 126 138 ^
  assets\levels\tidal-trouble\native\enemies\sneek.nspr ^
  docs\native_scene_previews\tidal-sneek.bmp flip_x || goto :err
(
  echo NATIVE_ANIMATION 1
  echo loop 1
  echo frame kong_k_0.nspr 110 0 0
  echo frame kong_k_1.nspr 110 0 0
)>assets\levels\tidal-trouble\native\entities\kong_k.nanim
(
  echo NATIVE_ANIMATION 1
  echo loop 1
  echo frame ../sprites/kiddy_swim_0.nspr 115 0 0
  echo frame ../sprites/kiddy_swim_1.nspr 105 0 0
  echo frame ../sprites/kiddy_swim_2.nspr 115 0 0
  echo frame ../sprites/kiddy_swim_1.nspr 105 0 0
)>assets\levels\tidal-trouble\native\anims\kiddy_swim.nanim
(
  echo NATIVE_ANIMATION 1
  echo loop 1
  echo frame sneek.nspr 160 0 0
)>assets\levels\tidal-trouble\native\enemies\sneek.nanim
echo.
echo TIDAL_ENTITIES_IMPORT_OK
pause
exit /b 0
:err
echo FALHA AO IMPORTAR ENTIDADES DE TIDAL.
pause
exit /b 1
