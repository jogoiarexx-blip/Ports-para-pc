#!/usr/bin/env python3
"""Create a temporary capture ROM where Doorstop's metadata slot loads Tidal Trouble.
Development/oracle helper only. Never used by the native runtime.
"""
from pathlib import Path
import argparse
ap=argparse.ArgumentParser();ap.add_argument('rom',type=Path);ap.add_argument('out',type=Path);a=ap.parse_args()
d=bytearray(a.rom.read_bytes());
if len(d)==0x400200:d=d[0x200:]
if len(d)!=0x400000:raise SystemExit('expected 4 MiB headerless ROM')
t0,t1=0x3D071B,0x3D0751;d0,d1=0x3D0751,0x3D078C
tidal=bytes(d[t0:t1]);
if len(tidal)!=54 or tidal[45]!=0xff:raise SystemExit('unexpected metadata layout')
# Doorstop has one extra point; duplicate Tidal start only to preserve record length.
extra=bytes([0x00,0x3C,0x01,0x69,0x02]);patched=tidal[:45]+extra+tidal[45:]
assert len(patched)==d1-d0
d[d0:d1]=patched;a.out.write_bytes(d)
print(f'CAPTURE_ROM_OK {a.out}')
