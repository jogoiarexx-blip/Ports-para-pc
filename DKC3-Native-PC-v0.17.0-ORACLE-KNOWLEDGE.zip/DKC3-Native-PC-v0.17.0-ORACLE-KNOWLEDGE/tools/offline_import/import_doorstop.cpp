#include "LegacySnesState.h"
#include <algorithm>
#include <array>
#include <cstdint>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>

namespace fs = std::filesystem;
#pragma pack(push,1)
struct DevStateHeader { char magic[8]; uint32_t version,payloadSize; uint64_t romSize,romHash; };
struct TileHeader { char magic[4]={'N','T','I','L'}; uint16_t version=1; uint16_t bpp=0; uint32_t tileCount=1024; uint32_t tileW=8,tileH=8; uint32_t charBaseWord=0; };
struct MapHeader { char magic[4]={'N','M','A','P'}; uint16_t version=1; uint16_t reserved=0; uint32_t width=0,height=0; uint32_t mapBaseWord=0; };
struct PalHeader { char magic[4]={'N','P','A','L'}; uint16_t version=1; uint16_t colors=256; };
struct SpriteHeader { char magic[4]={'N','S','P','R'}; uint16_t version=1; uint16_t flags=0; uint16_t width=0,height=0; int16_t originX=0,originY=0; uint32_t pixelCount=0; };
#pragma pack(pop)

static uint16_t vramWord(const Snes& s,uint16_t wa){ const uint32_t b=(wa&0x7fff)*2u; return uint16_t(s.vram[b]) | uint16_t(s.vram[(b+1)&0xffff])<<8; }
static int tilePixel(const Snes& s,uint32_t byteAddr,int row,int col,int bpp){
  const uint32_t a=byteAddr+uint32_t(row*2); const uint8_t mask=uint8_t(0x80u>>col);
  auto pair=[&](uint32_t off,int sh){uint8_t p0=s.vram[(a+off)&0xffff],p1=s.vram[(a+off+1)&0xffff]; return ((p0&mask)?(1<<sh):0)|((p1&mask)?(2<<sh):0);};
  int px=pair(0,0); if(bpp>=4)px|=pair(16,2); if(bpp>=8){px|=pair(32,4);px|=pair(48,6);} return px;
}
static void bgInfo(const Snes&s,int bg,uint16_t& mapBase,uint16_t& chrBase,int& bpp,int& mapW,int& mapH){
  mapBase=uint16_t((s.bgsc[bg]&0xfcu)<<8);
  int chr=(bg<2)?((bg==0?(s.bg12nba&7):((s.bg12nba>>4)&7))<<12):((bg==2?(s.bg34nba&7):((s.bg34nba>>4)&7))<<12);
  chrBase=uint16_t(chr); const int mode=s.bgmode&7; bpp=2;
  if(mode==1)bpp=(bg==2)?2:4; else if(mode==2)bpp=(bg<2)?4:2; else if(mode==3)bpp=(bg==0)?8:4; else if(mode==4)bpp=(bg==0)?8:2; else if(mode==5)bpp=(bg==0)?4:2; else if(mode==6)bpp=4;
  int sc=s.bgsc[bg]&3; mapW=(sc&1)?64:32; mapH=(sc&2)?64:32;
}
static bool writeTiles(const fs::path&p,const Snes&s,uint16_t chrBase,int bpp){ std::ofstream o(p,std::ios::binary); if(!o)return false; TileHeader h; h.bpp=bpp; h.charBaseWord=chrBase; o.write((char*)&h,sizeof h); const uint32_t bytesPerTile=bpp*8; std::array<uint8_t,64> pix{}; for(uint32_t t=0;t<1024;t++){uint32_t base=(uint32_t(chrBase)*2u+t*bytesPerTile)&0xffffu; for(int y=0;y<8;y++)for(int x=0;x<8;x++)pix[y*8+x]=uint8_t(tilePixel(s,base,y,x,bpp)); o.write((char*)pix.data(),pix.size());} return bool(o); }
static bool writeMap(const fs::path&p,const Snes&s,uint16_t base,int mw,int mh){ std::ofstream o(p,std::ios::binary); if(!o)return false; MapHeader h;h.width=mw;h.height=mh;h.mapBaseWord=base;o.write((char*)&h,sizeof h); for(int ty=0;ty<mh;ty++)for(int tx=0;tx<mw;tx++){int page=0,mx=tx&31,my=ty&31;if(mw==64&&tx>=32)page+=1;if(mh==64&&ty>=32)page+=(mw==64?2:1);uint16_t e=vramWord(s,uint16_t(base+page*0x400+my*32+mx));o.write((char*)&e,2);} return bool(o); }
static bool writePal(const fs::path&p,const Snes&s){std::ofstream o(p,std::ios::binary);if(!o)return false;PalHeader h;o.write((char*)&h,sizeof h);o.write((const char*)s.cgram,sizeof s.cgram);return bool(o);}
static uint32_t bgra15(uint16_t c){auto cv=[](int v){return uint8_t((v<<3)|(v>>2));};uint8_t r=cv(c&31),g=cv((c>>5)&31),b=cv((c>>10)&31);return 0xff000000u|(uint32_t(r)<<16)|(uint32_t(g)<<8)|b;}
#pragma pack(push,1)
struct BFH{uint16_t type=0x4d42;uint32_t size=0;uint16_t r1=0,r2=0;uint32_t off=54;};struct BIH{uint32_t size=40;int32_t w=0,h=0;uint16_t planes=1,bpp=32;uint32_t comp=0,sizeImage=0;int32_t xppm=3780,yppm=3780;uint32_t used=0,important=0;};
#pragma pack(pop)
static bool writeBmp(const fs::path&p,int w,int h,const std::vector<uint32_t>&px){std::ofstream o(p,std::ios::binary);if(!o)return false;BFH f;BIH i;i.w=w;i.h=-h;i.sizeImage=w*h*4;f.size=f.off+i.sizeImage;o.write((char*)&f,sizeof f);o.write((char*)&i,sizeof i);o.write((const char*)px.data(),i.sizeImage);return bool(o);}
static bool previewLayer(const fs::path&p,const Snes&s,int bg){uint16_t mb,cb;int bpp,mw,mh;bgInfo(s,bg,mb,cb,bpp,mw,mh);int W=mw*8,H=mh*8;std::vector<uint32_t> out((size_t)W*H,0);const uint32_t bpt=bpp*8;for(int ty=0;ty<mh;ty++)for(int tx=0;tx<mw;tx++){int page=0;if(mw==64&&tx>=32)page++;if(mh==64&&ty>=32)page+=(mw==64?2:1);uint16_t e=vramWord(s,uint16_t(mb+page*0x400+(ty&31)*32+(tx&31)));int tile=e&0x3ff,pal=(e>>10)&7;bool hf=e&0x4000,vf=e&0x8000;uint32_t base=(uint32_t(cb)*2u+uint32_t(tile)*bpt)&0xffffu;for(int py=0;py<8;py++)for(int px=0;px<8;px++){int sx=hf?7-px:px,sy=vf?7-py:py;int pi=tilePixel(s,base,sy,sx,bpp);if(!pi)continue;int ci=pal*(1<<bpp)+pi;out[(ty*8+py)*W+(tx*8+px)]=bgra15(s.cgram[ci&255]);}}return writeBmp(p,W,H,out);}

static void objSizes(uint8_t obsel,int&small,int&large){
  static constexpr int sm[8]={8,8,8,16,16,32,16,16};
  static constexpr int lg[8]={16,32,64,32,64,64,32,32};
  int mode=(obsel>>5)&7;small=sm[mode];large=lg[mode];
}
static void drawObjSlot(const Snes&s,int slot,std::vector<uint32_t>&canvas,int W,int H,int xBias=128){
  const int o=slot*4;int x=s.oam[o],y=s.oam[o+1],tile=s.oam[o+2],attr=s.oam[o+3];int hi=s.oam[512+slot/4],sh=(slot&3)*2;x|=((hi>>sh)&1)<<8;if(x>=256)x-=512;bool big=((hi>>(sh+1))&1)!=0;int small=8,large=16;objSizes(s.obsel,small,large);int size=big?large:small;bool hf=(attr&0x40)!=0,vf=(attr&0x80)!=0;int pal=(attr>>1)&7;
  const uint32_t base1=(uint32_t(s.obsel&7)<<14);const uint32_t base2=base1+uint32_t((s.obsel&0x18)+8u)*0x400u;const uint32_t nameBase=(attr&1)?base2:base1;
  for(int dy=0;dy<size;dy++)for(int dx=0;dx<size;dx++){int sx=hf?size-1-dx:dx,sy=vf?size-1-dy:dy;int tx=sx>>3,ty=sy>>3;int px=sx&7,py=sy&7;int usedTile=((((tile>>4)+ty)<<4)|(((tile&15)+tx)&15))&0xff;uint32_t addr=(nameBase+uint32_t(usedTile)*32u)&0xffffu;int pi=tilePixel(s,addr,py,px,4);if(!pi)continue;int ci=128+pal*16+pi;int xx=xBias+x+dx,yy=(y+dy)&255;if((unsigned)xx<(unsigned)W&&(unsigned)yy<(unsigned)H)canvas[(size_t)yy*W+xx]=bgra15(s.cgram[ci&255]);}
}
static bool writeSpriteGroup(const fs::path&p,const fs::path&preview,const Snes&s,int first,int last,int anchorX,int anchorY){
  const int W=512,H=256,xBias=128;std::vector<uint32_t> canvas((size_t)W*H,0);
  for(int slot=last;slot>=first;--slot)drawObjSlot(s,slot,canvas,W,H,xBias);
  int minx=W,miny=H,maxx=-1,maxy=-1;for(int y=0;y<H;y++)for(int x=0;x<W;x++)if(canvas[(size_t)y*W+x]>>24){minx=std::min(minx,x);miny=std::min(miny,y);maxx=std::max(maxx,x);maxy=std::max(maxy,y);}if(maxx<minx||maxy<miny)return false;
  int sw=maxx-minx+1,sh=maxy-miny+1;std::vector<uint32_t> pix((size_t)sw*sh,0);for(int y=0;y<sh;y++)for(int x=0;x<sw;x++)pix[(size_t)y*sw+x]=canvas[(size_t)(miny+y)*W+(minx+x)];
  SpriteHeader h;h.width=(uint16_t)sw;h.height=(uint16_t)sh;h.originX=(int16_t)(xBias+anchorX-minx);h.originY=(int16_t)(anchorY-miny);h.pixelCount=(uint32_t)pix.size();std::ofstream o(p,std::ios::binary);if(!o)return false;o.write((char*)&h,sizeof h);o.write((char*)pix.data(),std::streamsize(pix.size()*4));if(!o)return false;
  std::vector<uint32_t> prev=pix;for(auto&c:prev)if(!(c>>24))c=0xff202020u;return writeBmp(preview,sw,sh,prev);
}

static bool loadStateFile(const fs::path& path,Snes& s){
  std::ifstream in(path,std::ios::binary);if(!in)return false;DevStateHeader h{};in.read((char*)&h,sizeof h);const char m[8]={'D','K','C','3','S','T','0','1'};if(!in||memcmp(h.magic,m,8)||h.version!=2)return false;
  const size_t cur=sizeof(Snes)-offsetof(Snes,wram);const size_t old=498832;std::vector<uint8_t>b(h.payloadSize);in.read((char*)b.data(),b.size());if(!in)return false;auto*dst=(uint8_t*)&s.wram[0];
  if(b.size()==cur){memcpy(dst,b.data(),b.size());return true;}
  if(b.size()==old){memset(dst,0,cur);constexpr size_t oldVideo=498368,oldBrr=498372,newVideo=498376,newBrr=498384;memcpy(dst,b.data(),oldVideo);memcpy(dst+newVideo,b.data()+oldVideo,oldBrr-oldVideo);memcpy(dst+newBrr,b.data()+oldBrr,b.size()-oldBrr);return true;}
  return false;
}
int main(int argc,char**argv){
  if(argc<3){std::cerr<<"usage: import_doorstop BASE_STATE OUTDIR [LEVER_STATE] [NEXT_STATE]\n";return 2;}
  Snes s;if(!loadStateFile(argv[1],s)){std::cerr<<"state open/layout failed\n";return 3;}
  fs::path out=argv[2];fs::create_directories(out);fs::create_directories(out/"sprites");if(!writePal(out/"palette.npal",s))return 7;
  std::ofstream meta(out/"doorstop.nscene");meta<<"NATIVE_SCENE 1\nmode "<<(int)(s.bgmode&7)<<"\nbg3_priority "<<((s.bgmode&8)?1:0)<<"\ntm "<<(int)s.tm<<"\nbackdrop 0\nviewport 256 224\npalette palette.npal\n";
  for(int bg=0;bg<3;bg++){uint16_t mb,cb;int bpp,mw,mh;bgInfo(s,bg,mb,cb,bpp,mw,mh);std::string n="bg"+std::to_string(bg+1);if(!writeTiles(out/(n+".ntiles"),s,cb,bpp)||!writeMap(out/(n+".nmap"),s,mb,mw,mh)||!previewLayer(out/(n+"_preview.bmp"),s,bg))return 8;meta<<"layer "<<n<<" "<<bpp<<" "<<mw<<" "<<mh<<" "<<s.bghofs[bg]<<" "<<s.bgvofs[bg]<<" "<<((s.tm>>bg)&1)<<" "<<n<<".ntiles "<<n<<".nmap\n";}
  meta<<"source_frame "<<s.frame<<"\n";meta.close();
  if(!writeSpriteGroup(out/"sprites/dixie_idle.nspr",out/"sprites/dixie_idle_preview.bmp",s,0,10,55,133))return 9;
  if(!writeSpriteGroup(out/"sprites/kiddy_idle.nspr",out/"sprites/kiddy_idle_preview.bmp",s,11,22,38,127))return 10;
  if(!writeSpriteGroup(out/"sprites/ice_column.nspr",out/"sprites/ice_column_preview.bmp",s,23,34,50,45))return 11;
  if(!writeSpriteGroup(out/"sprites/silver_coin.nspr",out/"sprites/silver_coin_preview.bmp",s,35,39,105,10))return 12;
  int extra=0;
  if(argc>=4){
    Snes lever;if(!loadStateFile(argv[3],lever))return 13;
    if(!writeSpriteGroup(out/"sprites/dixie_hang.nspr",out/"sprites/dixie_hang_preview.bmp",lever,15,23,71,78))return 14;
    if(!writeSpriteGroup(out/"sprites/kiddy_hang.nspr",out/"sprites/kiddy_hang_preview.bmp",lever,0,14,70,76))return 15;
    extra+=2;
  }
  if(argc>=5){
    Snes next;if(!loadStateFile(argv[4],next))return 16;
    if(!writeSpriteGroup(out/"sprites/green_enemy_0.nspr",out/"sprites/green_enemy_0_preview.bmp",next,9,15,16,143))return 17;
    if(!writeSpriteGroup(out/"sprites/green_enemy_1.nspr",out/"sprites/green_enemy_1_preview.bmp",next,27,33,-32,113))return 18;
    if(!writeSpriteGroup(out/"sprites/green_enemy_2.nspr",out/"sprites/green_enemy_2_preview.bmp",next,34,40,64,115))return 19;
    extra+=3;
  }
  std::cout<<"NATIVE_ASSETS_OK frame="<<s.frame<<" mode="<<(int)(s.bgmode&7)<<" tm="<<(int)s.tm<<" sprites="<<(4+extra)<<"\n";return 0;
}
