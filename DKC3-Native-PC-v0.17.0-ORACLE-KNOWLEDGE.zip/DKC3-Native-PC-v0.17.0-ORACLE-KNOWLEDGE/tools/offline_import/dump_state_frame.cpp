#include "LegacySnesState.h"
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <vector>
namespace fs=std::filesystem;
#pragma pack(push,1)
struct DevStateHeader{char magic[8];uint32_t version,payloadSize;uint64_t romSize,romHash;};
struct BmpFileHeader{uint16_t type=0x4d42;uint32_t size=0;uint16_t r1=0,r2=0;uint32_t off=54;};
struct BmpInfoHeader{uint32_t size=40;int32_t w=0,h=0;uint16_t planes=1,bpp=32;uint32_t comp=0,sizeImage=0;int32_t xppm=3780,yppm=3780;uint32_t used=0,important=0;};
#pragma pack(pop)
static bool loadState(const fs::path&p,Snes&s){
  std::ifstream in(p,std::ios::binary);DevStateHeader h{};in.read((char*)&h,sizeof h);
  const char magic[8]={'D','K','C','3','S','T','0','1'};if(!in||std::memcmp(h.magic,magic,8)||h.version!=2)return false;
  constexpr size_t oldPayload=498832;const size_t currentPayload=sizeof(Snes)-offsetof(Snes,wram);
  std::vector<uint8_t>b(h.payloadSize);in.read((char*)b.data(),(std::streamsize)b.size());if(!in)return false;auto*dst=(uint8_t*)&s.wram[0];
  if(b.size()==currentPayload){std::memcpy(dst,b.data(),b.size());return true;}
  if(b.size()==oldPayload){std::memset(dst,0,currentPayload);constexpr size_t oldVideo=498368,oldBrr=498372,newVideo=498376,newBrr=498384;std::memcpy(dst,b.data(),oldVideo);std::memcpy(dst+newVideo,b.data()+oldVideo,oldBrr-oldVideo);std::memcpy(dst+newBrr,b.data()+oldBrr,b.size()-oldBrr);return true;}
  return false;
}
static bool saveBmp(const fs::path&p,const uint32_t*px,int w,int h){
  fs::create_directories(p.parent_path());std::ofstream o(p,std::ios::binary);if(!o)return false;
  BmpFileHeader f;BmpInfoHeader i;i.w=w;i.h=-h;i.sizeImage=(uint32_t)(w*h*4);f.size=f.off+i.sizeImage;
  o.write((char*)&f,sizeof f);o.write((char*)&i,sizeof i);o.write((const char*)px,(std::streamsize)i.sizeImage);return bool(o);
}
int main(int argc,char**argv){
  if(argc<3){std::cerr<<"usage: dkc3_dump_state_frame STATE OUT_BMP\n";return 2;}
  Snes s;if(!loadState(argv[1],s)){std::cerr<<"state open/layout failed\n";return 3;}
  if(!saveBmp(argv[2],s.fb,256,224)){std::cerr<<"bmp write failed\n";return 4;}
  std::cout<<"STATE_FRAME_OK frame="<<s.frame<<" bg2="<<s.bghofs[1]<<","<<s.bgvofs[1]<<" out="<<argv[2]<<"\n";return 0;
}
