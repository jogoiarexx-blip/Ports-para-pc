#include "LegacySnesState.h"

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <map>
#include <numeric>
#include <set>
#include <sstream>
#include <string>
#include <tuple>
#include <unordered_map>
#include <utility>
#include <vector>

namespace fs = std::filesystem;

#pragma pack(push, 1)
struct DevStateHeader {
    char magic[8];
    std::uint32_t version, payloadSize;
    std::uint64_t romSize, romHash;
};
struct SpriteHeader {
    char magic[4] = {'N', 'S', 'P', 'R'};
    std::uint16_t version = 1, flags = 0, width = 0, height = 0;
    std::int16_t originX = 0, originY = 0;
    std::uint32_t pixelCount = 0;
};
struct BmpFileHeader {
    std::uint16_t type = 0x4d42;
    std::uint32_t size = 0;
    std::uint16_t r1 = 0, r2 = 0;
    std::uint32_t off = 54;
};
struct BmpInfoHeader {
    std::uint32_t size = 40;
    std::int32_t w = 0, h = 0;
    std::uint16_t planes = 1, bpp = 32;
    std::uint32_t comp = 0, sizeImage = 0;
    std::int32_t xppm = 3780, yppm = 3780;
    std::uint32_t used = 0, important = 0;
};
#pragma pack(pop)

namespace {
constexpr std::size_t kWramSize = 0x20000;

struct OamSprite {
    int slot = 0;
    int x = 0, y = 0, tile = 0, attr = 0, size = 0;
    int palette = 0, priority = 0, nametable = 0;
    bool hflip = false, vflip = false;
};

struct Group {
    int index = 0;
    std::vector<OamSprite> sprites;
    int minX = 0, minY = 0, maxX = -1, maxY = -1;
    std::uint64_t strictHash = 0, shapeHash = 0;
    std::string assetBase;
};

struct StateRecord {
    fs::path path;
    std::string stem;
    Snes snes{};
    std::vector<OamSprite> sprites;
    std::vector<Group> groups;
};

std::uint64_t fnv1a(const void* ptr, std::size_t len, std::uint64_t seed = 1469598103934665603ull) {
    const auto* p = static_cast<const std::uint8_t*>(ptr);
    std::uint64_t h = seed;
    for (std::size_t i = 0; i < len; ++i) {
        h ^= p[i];
        h *= 1099511628211ull;
    }
    return h;
}

template <class T>
void hashValue(std::uint64_t& h, const T& v) {
    h = fnv1a(&v, sizeof(v), h);
}

std::string hex64(std::uint64_t value) {
    std::ostringstream ss;
    ss << std::hex << std::uppercase << std::setw(16) << std::setfill('0') << value;
    return ss.str();
}

std::string hexAddr(std::size_t value) {
    std::ostringstream ss;
    ss << "0x" << std::hex << std::uppercase << std::setw(5) << std::setfill('0') << value;
    return ss.str();
}

std::string jsonEscape(const std::string& s) {
    std::ostringstream out;
    for (unsigned char c : s) {
        switch (c) {
            case '\\': out << "\\\\"; break;
            case '"': out << "\\\""; break;
            case '\n': out << "\\n"; break;
            case '\r': out << "\\r"; break;
            case '\t': out << "\\t"; break;
            default:
                if (c < 0x20) {
                    out << "\\u" << std::hex << std::setw(4) << std::setfill('0') << static_cast<int>(c) << std::dec;
                } else {
                    out << static_cast<char>(c);
                }
        }
    }
    return out.str();
}

bool loadState(const fs::path& path, Snes& s) {
    std::ifstream in(path, std::ios::binary);
    DevStateHeader h{};
    in.read(reinterpret_cast<char*>(&h), sizeof(h));
    const char magic[8] = {'D', 'K', 'C', '3', 'S', 'T', '0', '1'};
    if (!in || std::memcmp(h.magic, magic, 8) != 0 || h.version != 2) return false;
    constexpr std::size_t oldPayload = 498832;
    const std::size_t currentPayload = sizeof(Snes) - offsetof(Snes, wram);
    std::vector<std::uint8_t> bytes(h.payloadSize);
    in.read(reinterpret_cast<char*>(bytes.data()), static_cast<std::streamsize>(bytes.size()));
    if (!in) return false;
    auto* dst = reinterpret_cast<std::uint8_t*>(&s.wram[0]);
    if (bytes.size() == currentPayload) {
        std::memcpy(dst, bytes.data(), bytes.size());
        return true;
    }
    if (bytes.size() == oldPayload) {
        std::memset(dst, 0, currentPayload);
        constexpr std::size_t oldVideo = 498368, oldBrr = 498372, newVideo = 498376, newBrr = 498384;
        std::memcpy(dst, bytes.data(), oldVideo);
        std::memcpy(dst + newVideo, bytes.data() + oldVideo, oldBrr - oldVideo);
        std::memcpy(dst + newBrr, bytes.data() + oldBrr, bytes.size() - oldBrr);
        return true;
    }
    return false;
}

void spriteSizes(std::uint8_t obsel, int& small, int& large) {
    static constexpr int smallTable[8] = {8, 8, 8, 16, 16, 32, 16, 16};
    static constexpr int largeTable[8] = {16, 32, 64, 32, 64, 64, 32, 32};
    const int mode = (obsel >> 5) & 7;
    small = smallTable[mode];
    large = largeTable[mode];
}

std::vector<OamSprite> collectSprites(const Snes& s) {
    int small = 0, large = 0;
    spriteSizes(s.obsel, small, large);
    std::vector<OamSprite> out;
    for (int slot = 0; slot < 128; ++slot) {
        const int o = slot * 4;
        int x = s.oam[o];
        const int y = s.oam[o + 1];
        const int tile = s.oam[o + 2];
        const int attr = s.oam[o + 3];
        const std::uint8_t hi = s.oam[512 + slot / 4];
        const int shift = (slot & 3) * 2;
        x |= ((hi >> shift) & 1) << 8;
        if (x >= 256) x -= 512;
        const int size = ((hi >> (shift + 1)) & 1) ? large : small;
        if (x <= -size || x >= 256 || y >= 224) continue;
        OamSprite sp;
        sp.slot = slot;
        sp.x = x;
        sp.y = y;
        sp.tile = tile;
        sp.attr = attr;
        sp.size = size;
        sp.palette = (attr >> 1) & 7;
        sp.priority = (attr >> 4) & 3;
        sp.hflip = (attr & 0x40) != 0;
        sp.vflip = (attr & 0x80) != 0;
        sp.nametable = attr & 1;
        out.push_back(sp);
    }
    return out;
}

bool nearRect(const Group& g, const OamSprite& s, int margin = 28) {
    if (g.maxX < g.minX) return true;
    const int sx0 = s.x, sy0 = s.y, sx1 = s.x + s.size - 1, sy1 = s.y + s.size - 1;
    return sx1 >= g.minX - margin && sx0 <= g.maxX + margin && sy1 >= g.minY - margin && sy0 <= g.maxY + margin;
}

void updateBounds(Group& g, const OamSprite& s) {
    const int sx1 = s.x + s.size - 1;
    const int sy1 = s.y + s.size - 1;
    if (g.maxX < g.minX) {
        g.minX = s.x;
        g.minY = s.y;
        g.maxX = sx1;
        g.maxY = sy1;
    } else {
        g.minX = std::min(g.minX, s.x);
        g.minY = std::min(g.minY, s.y);
        g.maxX = std::max(g.maxX, sx1);
        g.maxY = std::max(g.maxY, sy1);
    }
}

void finalizeHashes(Group& g) {
    std::uint64_t strict = 1469598103934665603ull;
    std::uint64_t shape = 1469598103934665603ull;
    const int w = g.maxX - g.minX + 1;
    const int h = g.maxY - g.minY + 1;
    const int count = static_cast<int>(g.sprites.size());
    hashValue(shape, count);
    hashValue(shape, w);
    hashValue(shape, h);
    if (!g.sprites.empty()) {
        hashValue(shape, g.sprites.front().palette);
        hashValue(shape, g.sprites.front().priority);
        hashValue(shape, g.sprites.front().nametable);
    }
    for (const auto& s : g.sprites) {
        const int rx = s.x - g.minX;
        const int ry = s.y - g.minY;
        hashValue(strict, rx);
        hashValue(strict, ry);
        hashValue(strict, s.tile);
        hashValue(strict, s.attr);
        hashValue(strict, s.size);
        hashValue(shape, s.size);
    }
    g.strictHash = strict;
    g.shapeHash = shape;
}

std::vector<Group> makeGroups(const std::vector<OamSprite>& sprites) {
    std::vector<Group> groups;
    for (const auto& s : sprites) {
        bool append = false;
        if (!groups.empty()) {
            Group& g = groups.back();
            const OamSprite& prev = g.sprites.back();
            append = s.slot - prev.slot <= 3 &&
                     s.palette == prev.palette && s.priority == prev.priority &&
                     s.nametable == prev.nametable && nearRect(g, s);
            if (append) {
                g.sprites.push_back(s);
                updateBounds(g, s);
            }
        }
        if (!append) {
            Group g;
            g.index = static_cast<int>(groups.size());
            g.minX = 1;
            g.maxX = 0;
            g.sprites.push_back(s);
            updateBounds(g, s);
            groups.push_back(g);
        }
    }
    for (auto& g : groups) finalizeHashes(g);
    return groups;
}

int tilePixel(const Snes& s, std::uint32_t a, int y, int x) {
    const std::uint8_t mask = static_cast<std::uint8_t>(0x80u >> x);
    auto pair = [&](std::uint32_t off, int shift) {
        const std::uint8_t p0 = s.vram[(a + y * 2 + off) & 0xffff];
        const std::uint8_t p1 = s.vram[(a + y * 2 + off + 1) & 0xffff];
        return ((p0 & mask) ? (1 << shift) : 0) | ((p1 & mask) ? (2 << shift) : 0);
    };
    return pair(0, 0) | pair(16, 2);
}

std::uint32_t color15(std::uint16_t c) {
    auto q = [](int v) { return static_cast<std::uint8_t>((v << 3) | (v >> 2)); };
    return 0xff000000u | (std::uint32_t(q(c & 31)) << 16) |
           (std::uint32_t(q((c >> 5) & 31)) << 8) | q((c >> 10) & 31);
}

void drawSlot(const Snes& s, const OamSprite& sp, std::vector<std::uint32_t>& canvas, int width, int height, int xBias) {
    const int z = sp.size;
    const std::uint32_t base1 = (std::uint32_t(s.obsel & 7) << 14);
    const std::uint32_t base2 = base1 + std::uint32_t((s.obsel & 0x18) + 8u) * 0x400u;
    const std::uint32_t nameBase = sp.nametable ? base2 : base1;
    for (int dy = 0; dy < z; ++dy) {
        for (int dx = 0; dx < z; ++dx) {
            const int sx = sp.hflip ? z - 1 - dx : dx;
            const int sy = sp.vflip ? z - 1 - dy : dy;
            const int usedTile = ((((sp.tile >> 4) + (sy >> 3)) << 4) | (((sp.tile & 15) + (sx >> 3)) & 15)) & 255;
            const int pi = tilePixel(s, (nameBase + std::uint32_t(usedTile) * 32u) & 0xffffu, sy & 7, sx & 7);
            if (!pi) continue;
            const int xx = xBias + sp.x + dx;
            const int yy = (sp.y + dy) & 255;
            if (static_cast<unsigned>(xx) < static_cast<unsigned>(width) &&
                static_cast<unsigned>(yy) < static_cast<unsigned>(height)) {
                canvas[static_cast<std::size_t>(yy) * width + xx] = color15(s.cgram[(128 + sp.palette * 16 + pi) & 255]);
            }
        }
    }
}

bool saveBmp(const fs::path& path, int w, int h, std::vector<std::uint32_t> pixels, bool fillTransparent = false) {
    if (fillTransparent) {
        for (auto& c : pixels) if ((c >> 24) == 0) c = 0xff202020u;
    }
    if (path.has_parent_path()) fs::create_directories(path.parent_path());
    std::ofstream out(path, std::ios::binary);
    if (!out) return false;
    BmpFileHeader f;
    BmpInfoHeader i;
    i.w = w;
    i.h = -h;
    i.sizeImage = static_cast<std::uint32_t>(w * h * 4);
    f.size = f.off + i.sizeImage;
    out.write(reinterpret_cast<const char*>(&f), sizeof(f));
    out.write(reinterpret_cast<const char*>(&i), sizeof(i));
    out.write(reinterpret_cast<const char*>(pixels.data()), static_cast<std::streamsize>(pixels.size() * 4));
    return static_cast<bool>(out);
}

bool writeGroupAsset(const StateRecord& rec, Group& g, const fs::path& dir) {
    constexpr int canvasW = 512, canvasH = 256, xBias = 128;
    std::vector<std::uint32_t> canvas(static_cast<std::size_t>(canvasW) * canvasH, 0);
    for (auto it = g.sprites.rbegin(); it != g.sprites.rend(); ++it) drawSlot(rec.snes, *it, canvas, canvasW, canvasH, xBias);
    int minx = canvasW, miny = canvasH, maxx = -1, maxy = -1;
    for (int y = 0; y < canvasH; ++y) {
        for (int x = 0; x < canvasW; ++x) {
            if ((canvas[static_cast<std::size_t>(y) * canvasW + x] >> 24) != 0) {
                minx = std::min(minx, x);
                miny = std::min(miny, y);
                maxx = std::max(maxx, x);
                maxy = std::max(maxy, y);
            }
        }
    }
    if (maxx < minx) return false;
    const int sw = maxx - minx + 1;
    const int sh = maxy - miny + 1;
    std::vector<std::uint32_t> px(static_cast<std::size_t>(sw) * sh, 0);
    for (int y = 0; y < sh; ++y) {
        for (int x = 0; x < sw; ++x) {
            px[static_cast<std::size_t>(y) * sw + x] = canvas[static_cast<std::size_t>(miny + y) * canvasW + minx + x];
        }
    }
    std::ostringstream base;
    base << "group_" << std::setw(2) << std::setfill('0') << g.index << "_slots_"
         << g.sprites.front().slot << '-' << g.sprites.back().slot;
    g.assetBase = base.str();
    fs::create_directories(dir);
    SpriteHeader h;
    h.width = static_cast<std::uint16_t>(sw);
    h.height = static_cast<std::uint16_t>(sh);
    h.originX = 0;
    h.originY = 0;
    h.pixelCount = static_cast<std::uint32_t>(px.size());
    std::ofstream spr(dir / (g.assetBase + ".nspr"), std::ios::binary);
    if (!spr) return false;
    spr.write(reinterpret_cast<const char*>(&h), sizeof(h));
    spr.write(reinterpret_cast<const char*>(px.data()), static_cast<std::streamsize>(px.size() * 4));
    if (!spr) return false;
    return saveBmp(dir / (g.assetBase + ".bmp"), sw, sh, px, true);
}

bool saveFrame(const StateRecord& rec, const fs::path& path) {
    std::vector<std::uint32_t> pixels(std::begin(rec.snes.fb), std::end(rec.snes.fb));
    return saveBmp(path, 256, 224, std::move(pixels), false);
}

void writeOamCsv(const StateRecord& rec, const fs::path& path) {
    std::ofstream out(path);
    out << "slot,x,y,tile,attr,size,palette,priority,hflip,vflip,nametable\n";
    for (const auto& s : rec.sprites) {
        out << s.slot << ',' << s.x << ',' << s.y << ',' << s.tile << ',' << s.attr << ',' << s.size << ','
            << s.palette << ',' << s.priority << ',' << (s.hflip ? 1 : 0) << ',' << (s.vflip ? 1 : 0) << ',' << s.nametable << '\n';
    }
}

std::set<int> tileSet(const Group& g) {
    std::set<int> out;
    for (const auto& s : g.sprites) out.insert(s.tile);
    return out;
}

int overlapCount(const std::set<int>& a, const std::set<int>& b) {
    int count = 0;
    auto ia = a.begin();
    auto ib = b.begin();
    while (ia != a.end() && ib != b.end()) {
        if (*ia == *ib) { ++count; ++ia; ++ib; }
        else if (*ia < *ib) ++ia;
        else ++ib;
    }
    return count;
}

int matchScore(const Group& a, const Group& b) {
    if (a.sprites.empty() || b.sprites.empty()) return 0;
    const auto& sa = a.sprites.front();
    const auto& sb = b.sprites.front();
    int score = 0;
    if (sa.palette == sb.palette) score += 25;
    if (sa.priority == sb.priority) score += 10;
    if (sa.nametable == sb.nametable) score += 5;
    const int countDiff = std::abs(static_cast<int>(a.sprites.size()) - static_cast<int>(b.sprites.size()));
    if (countDiff == 0) score += 20;
    else if (countDiff <= 2) score += 12;
    const int aw = a.maxX - a.minX + 1, ah = a.maxY - a.minY + 1;
    const int bw = b.maxX - b.minX + 1, bh = b.maxY - b.minY + 1;
    if (std::abs(aw - bw) <= 8) score += 8;
    else if (std::abs(aw - bw) <= 16) score += 4;
    if (std::abs(ah - bh) <= 8) score += 8;
    else if (std::abs(ah - bh) <= 16) score += 4;
    const auto ta = tileSet(a), tb = tileSet(b);
    const int inter = overlapCount(ta, tb);
    const int uni = static_cast<int>(ta.size() + tb.size()) - inter;
    if (uni > 0) score += (24 * inter) / uni;
    const int hfA = std::count_if(a.sprites.begin(), a.sprites.end(), [](const OamSprite& s) { return s.hflip; });
    const int hfB = std::count_if(b.sprites.begin(), b.sprites.end(), [](const OamSprite& s) { return s.hflip; });
    if ((hfA * 2 >= static_cast<int>(a.sprites.size())) == (hfB * 2 >= static_cast<int>(b.sprites.size()))) score += 4;
    return std::min(score, 100);
}

struct Link {
    int stateA = 0, groupA = 0, stateB = 0, groupB = 0, score = 0;
};

struct KnowledgeSpec {
    std::string label;
    std::string kind;
    std::string stateStem;
    int group = -1;
    int minScore = 90;
};

struct ResolvedKnowledge {
    KnowledgeSpec spec;
    int stateIndex = -1;
    int groupIndex = -1;
};

struct Detection {
    std::string label;
    std::string kind;
    int score = 0;
    int refState = -1;
    int refGroup = -1;
};

std::vector<std::string> splitCsvSimple(const std::string& line) {
    std::vector<std::string> out;
    std::string cur;
    for (char c : line) {
        if (c == ',') { out.push_back(cur); cur.clear(); }
        else cur.push_back(c);
    }
    out.push_back(cur);
    return out;
}

std::vector<KnowledgeSpec> loadKnowledge(const fs::path& path) {
    std::vector<KnowledgeSpec> out;
    if (path.empty()) return out;
    std::ifstream in(path);
    if (!in) return out;
    std::string line;
    bool first = true;
    while (std::getline(in, line)) {
        if (line.empty() || line[0] == '#') continue;
        if (first) { first = false; if (line.rfind("label,", 0) == 0) continue; }
        const auto f = splitCsvSimple(line);
        if (f.size() < 5) continue;
        KnowledgeSpec k;
        k.label = f[0];
        k.kind = f[1];
        k.stateStem = f[2];
        try {
            k.group = std::stoi(f[3]);
            k.minScore = std::stoi(f[4]);
        } catch (...) {
            continue;
        }
        if (!k.label.empty() && !k.stateStem.empty() && k.group >= 0) out.push_back(std::move(k));
    }
    return out;
}

struct Dsu {
    std::vector<int> p;
    explicit Dsu(int n) : p(n) { std::iota(p.begin(), p.end(), 0); }
    int find(int a) { return p[a] == a ? a : p[a] = find(p[a]); }
    void unite(int a, int b) { a = find(a); b = find(b); if (a != b) p[b] = a; }
};

std::uint16_t wramWord(const Snes& s, std::size_t addr) {
    return static_cast<std::uint16_t>(s.wram[addr] | (std::uint16_t(s.wram[addr + 1]) << 8));
}

void writeWramReports(const std::vector<StateRecord>& states, const fs::path& outDir) {
    if (states.size() < 2) return;
    std::vector<int> changes(kWramSize, 0);
    std::ofstream ranges(outDir / "wram-diff-ranges.csv");
    ranges << "from_state,to_state,start,end,length\n";
    for (std::size_t i = 1; i < states.size(); ++i) {
        const auto& a = states[i - 1].snes;
        const auto& b = states[i].snes;
        std::size_t pos = 0;
        while (pos < kWramSize) {
            if (a.wram[pos] == b.wram[pos]) { ++pos; continue; }
            const std::size_t start = pos;
            while (pos < kWramSize && a.wram[pos] != b.wram[pos]) {
                ++changes[pos];
                ++pos;
            }
            ranges << states[i - 1].stem << ',' << states[i].stem << ',' << hexAddr(start) << ','
                   << hexAddr(pos - 1) << ',' << (pos - start) << '\n';
        }
    }
    std::vector<std::size_t> order(kWramSize);
    std::iota(order.begin(), order.end(), 0);
    std::stable_sort(order.begin(), order.end(), [&](std::size_t a, std::size_t b) { return changes[a] > changes[b]; });
    std::ofstream hot(outDir / "wram-hotspots.csv");
    hot << "address,changed_transitions,total_transitions,first_value,last_value\n";
    int emitted = 0;
    for (std::size_t addr : order) {
        if (changes[addr] == 0 || emitted >= 2048) break;
        hot << hexAddr(addr) << ',' << changes[addr] << ',' << (states.size() - 1) << ','
            << static_cast<int>(states.front().snes.wram[addr]) << ',' << static_cast<int>(states.back().snes.wram[addr]) << '\n';
        ++emitted;
    }

    struct Signal { std::string name; int bg = 0; bool vertical = false; };
    std::vector<Signal> signals;
    for (int bg = 0; bg < 4; ++bg) {
        signals.push_back({"bg" + std::to_string(bg + 1) + "_x", bg, false});
        signals.push_back({"bg" + std::to_string(bg + 1) + "_y", bg, true});
    }
    std::ofstream corr(outDir / "wram-ppu-correlations.csv");
    corr << "signal,address,values\n";
    for (const auto& sig : signals) {
        std::vector<std::uint16_t> values;
        values.reserve(states.size());
        for (const auto& st : states) values.push_back(sig.vertical ? st.snes.bgvofs[sig.bg] : st.snes.bghofs[sig.bg]);
        if (std::adjacent_find(values.begin(), values.end(), std::not_equal_to<>()) == values.end()) continue;
        int matches = 0;
        for (std::size_t addr = 0; addr + 1 < kWramSize && matches < 128; ++addr) {
            bool ok = true;
            for (std::size_t i = 0; i < states.size(); ++i) {
                if (wramWord(states[i].snes, addr) != values[i]) { ok = false; break; }
            }
            if (!ok) continue;
            corr << sig.name << ',' << hexAddr(addr) << ",\"";
            for (std::size_t i = 0; i < values.size(); ++i) {
                if (i) corr << ' ';
                corr << values[i];
            }
            corr << "\"\n";
            ++matches;
        }
    }
}

void writeManifest(const std::vector<StateRecord>& states, const std::vector<Link>& links, const fs::path& path) {
    std::ofstream out(path);
    out << "{\n  \"format\": \"DKC3_ORACLE_BATCH_1\",\n  \"states\": [\n";
    for (std::size_t i = 0; i < states.size(); ++i) {
        const auto& st = states[i];
        out << "    {\"name\":\"" << jsonEscape(st.stem) << "\",\"source\":\"" << jsonEscape(st.path.generic_string())
            << "\",\"frame\":" << st.snes.frame << ",\"bgmode\":" << int(st.snes.bgmode & 7)
            << ",\"tm\":" << int(st.snes.tm) << ",\"ts\":" << int(st.snes.ts)
            << ",\"visible_oam\":" << st.sprites.size() << ",\"groups\":" << st.groups.size() << "}";
        if (i + 1 != states.size()) out << ',';
        out << '\n';
    }
    out << "  ],\n  \"links\": [\n";
    for (std::size_t i = 0; i < links.size(); ++i) {
        const auto& l = links[i];
        out << "    {\"a\":\"" << jsonEscape(states[l.stateA].stem) << ":" << l.groupA
            << "\",\"b\":\"" << jsonEscape(states[l.stateB].stem) << ":" << l.groupB << "\",\"score\":" << l.score << "}";
        if (i + 1 != links.size()) out << ',';
        out << '\n';
    }
    out << "  ]\n}\n";
}

}  // namespace

int main(int argc, char** argv) {
    if (argc < 3) {
        std::cerr << "usage: dkc3_oracle_batch OUT_DIR [--knowledge FILE] STATE [STATE ...]\n";
        return 2;
    }
    const fs::path outDir = argv[1];
    fs::create_directories(outDir);

    fs::path knowledgePath;
    std::vector<fs::path> statePaths;
    for (int i = 2; i < argc; ++i) {
        const std::string arg = argv[i];
        if (arg == "--knowledge") {
            if (i + 1 >= argc) { std::cerr << "--knowledge requires a file\n"; return 2; }
            knowledgePath = argv[++i];
        } else {
            statePaths.emplace_back(arg);
        }
    }
    if (statePaths.empty()) { std::cerr << "no states supplied\n"; return 2; }

    std::vector<StateRecord> states;
    for (const auto& statePath : statePaths) {
        StateRecord rec;
        rec.path = statePath;
        rec.stem = rec.path.stem().string();
        if (!loadState(rec.path, rec.snes)) {
            std::cerr << "state open/layout failed: " << rec.path << "\n";
            return 3;
        }
        rec.sprites = collectSprites(rec.snes);
        rec.groups = makeGroups(rec.sprites);
        const fs::path stateDir = outDir / rec.stem;
        fs::create_directories(stateDir / "groups");
        if (!saveFrame(rec, stateDir / "frame.bmp")) {
            std::cerr << "frame export failed: " << rec.path << "\n";
            return 4;
        }
        writeOamCsv(rec, stateDir / "oam.csv");
        for (auto& g : rec.groups) {
            if (!writeGroupAsset(rec, g, stateDir / "groups")) {
                std::cerr << "group export failed: " << rec.path << " group " << g.index << "\n";
                return 5;
            }
        }
        states.push_back(std::move(rec));
    }

    const auto knowledgeSpecs = loadKnowledge(knowledgePath);
    std::vector<ResolvedKnowledge> knownRefs;
    for (const auto& spec : knowledgeSpecs) {
        for (int si = 0; si < static_cast<int>(states.size()); ++si) {
            if (states[si].stem != spec.stateStem) continue;
            if (spec.group < 0 || spec.group >= static_cast<int>(states[si].groups.size())) continue;
            knownRefs.push_back({spec, si, spec.group});
            break;
        }
    }
    std::vector<std::vector<Detection>> detections(states.size());
    for (std::size_t si = 0; si < states.size(); ++si) {
        detections[si].resize(states[si].groups.size());
        for (std::size_t gi = 0; gi < states[si].groups.size(); ++gi) {
            Detection best;
            for (const auto& ref : knownRefs) {
                const int score = matchScore(states[si].groups[gi], states[ref.stateIndex].groups[ref.groupIndex]);
                if (score < ref.spec.minScore || score <= best.score) continue;
                best.label = ref.spec.label;
                best.kind = ref.spec.kind;
                best.score = score;
                best.refState = ref.stateIndex;
                best.refGroup = ref.groupIndex;
            }
            detections[si][gi] = std::move(best);
        }
    }

    std::ofstream knownCsv(outDir / "known-detections.csv");
    knownCsv << "state,group,label,kind,score,reference_state,reference_group,asset\n";
    int knownCount = 0;
    for (std::size_t si = 0; si < states.size(); ++si) {
        for (std::size_t gi = 0; gi < states[si].groups.size(); ++gi) {
            const auto& d = detections[si][gi];
            if (d.label.empty()) continue;
            ++knownCount;
            knownCsv << states[si].stem << ',' << gi << ',' << d.label << ',' << d.kind << ',' << d.score << ','
                     << states[d.refState].stem << ',' << d.refGroup << ','
                     << states[si].stem << "/groups/" << states[si].groups[gi].assetBase << ".bmp\n";
        }
    }

    std::ofstream pagesCsv(outDir / "pages.csv");
    pagesCsv << "state,frame,bgmode,tm,ts,bg1_x,bg1_y,bg2_x,bg2_y,bg3_x,bg3_y,vram_hash,cgram_hash,oam_hash,wram_hash\n";
    for (const auto& st : states) {
        const auto vramHash = fnv1a(st.snes.vram, sizeof(st.snes.vram));
        const auto cgramHash = fnv1a(st.snes.cgram, sizeof(st.snes.cgram));
        const auto oamHash = fnv1a(st.snes.oam, sizeof(st.snes.oam));
        const auto wramHash = fnv1a(st.snes.wram, sizeof(st.snes.wram));
        pagesCsv << st.stem << ',' << st.snes.frame << ',' << int(st.snes.bgmode & 7) << ',' << int(st.snes.tm) << ',' << int(st.snes.ts) << ','
                 << st.snes.bghofs[0] << ',' << st.snes.bgvofs[0] << ',' << st.snes.bghofs[1] << ',' << st.snes.bgvofs[1] << ','
                 << st.snes.bghofs[2] << ',' << st.snes.bgvofs[2] << ',' << hex64(vramHash) << ',' << hex64(cgramHash) << ',' << hex64(oamHash) << ',' << hex64(wramHash) << '\n';
    }

    std::ofstream groupsCsv(outDir / "groups.csv");
    groupsCsv << "state,frame,group,first_slot,last_slot,sprites,palette,priority,nametable,min_x,min_y,width,height,strict_hash,shape_hash,asset\n";
    for (const auto& st : states) {
        for (const auto& g : st.groups) {
            const int w = g.maxX - g.minX + 1;
            const int h = g.maxY - g.minY + 1;
            groupsCsv << st.stem << ',' << st.snes.frame << ',' << g.index << ',' << g.sprites.front().slot << ',' << g.sprites.back().slot << ','
                      << g.sprites.size() << ',' << g.sprites.front().palette << ',' << g.sprites.front().priority << ',' << g.sprites.front().nametable << ','
                      << g.minX << ',' << g.minY << ',' << w << ',' << h << ',' << hex64(g.strictHash) << ',' << hex64(g.shapeHash) << ','
                      << st.stem << "/groups/" << g.assetBase << ".nspr\n";
        }
    }

    std::vector<Link> links;
    std::vector<std::pair<int, int>> flat;
    for (int si = 0; si < static_cast<int>(states.size()); ++si) {
        for (int gi = 0; gi < static_cast<int>(states[si].groups.size()); ++gi) flat.emplace_back(si, gi);
    }
    Dsu dsu(static_cast<int>(flat.size()));
    std::ofstream linksCsv(outDir / "entity-links.csv");
    linksCsv << "state_a,group_a,state_b,group_b,score\n";
    for (std::size_t a = 0; a < flat.size(); ++a) {
        for (std::size_t b = a + 1; b < flat.size(); ++b) {
            const auto [sa, ga] = flat[a];
            const auto [sb, gb] = flat[b];
            if (sa == sb) continue;
            const int score = matchScore(states[sa].groups[ga], states[sb].groups[gb]);
            if (score < 55) continue;
            links.push_back({sa, ga, sb, gb, score});
            linksCsv << states[sa].stem << ',' << ga << ',' << states[sb].stem << ',' << gb << ',' << score << '\n';
            if (score >= 80) dsu.unite(static_cast<int>(a), static_cast<int>(b));
        }
    }

    std::map<int, std::vector<int>> families;
    for (int i = 0; i < static_cast<int>(flat.size()); ++i) families[dsu.find(i)].push_back(i);
    int familyId = 0;
    std::ofstream familyCsv(outDir / "entity-families.csv");
    familyCsv << "family,state,group,label,confidence,palette,sprites,bbox,asset\n";
    std::ofstream report(outDir / "AUTO-ENTITY-CANDIDATES.md");
    report << "# DKC3 Oracle - entity candidates\n\n";
    report << "Generated automatically from " << states.size() << " save-state(s). A family is only a candidate; inspect the BMP previews before integrating it.\n\n";
    for (const auto& [root, members] : families) {
        std::set<int> stateSet;
        for (int m : members) stateSet.insert(flat[m].first);
        if (stateSet.size() < 2) continue;
        report << "## Family " << familyId << "\n\n";
        for (int m : members) {
            const auto [si, gi] = flat[m];
            const auto& g = states[si].groups[gi];
            const int w = g.maxX - g.minX + 1, h = g.maxY - g.minY + 1;
            const auto& det = detections[si][gi];
            familyCsv << familyId << ',' << states[si].stem << ',' << gi << ',' << (det.label.empty() ? "unknown" : det.label) << ',' << det.score << ','
                      << g.sprites.front().palette << ',' << g.sprites.size() << ',' << w << 'x' << h << ','
                      << states[si].stem << "/groups/" << g.assetBase << ".bmp\n";
            report << "- `" << states[si].stem << "` group " << gi << " — slots " << g.sprites.front().slot << '-' << g.sprites.back().slot
                   << ", palette " << g.sprites.front().palette << ", " << w << 'x' << h;
            if (!det.label.empty()) report << ", **known: " << det.label << " (" << det.score << ")**";
            report << " — `" << states[si].stem << "/groups/" << g.assetBase << ".bmp`\n";
        }
        report << '\n';
        ++familyId;
    }
    if (familyId == 0) report << "No repeated high-confidence families were found in this batch. More sequential captures usually improve matching.\n";

    // Greedy one-to-one temporal association between adjacent captures. This avoids
    // treating every similar sprite in every frame as the same physical entity.
    struct TrackRow { int track=0, state=0, group=0, score=0; };
    std::vector<TrackRow> trackRows;
    std::vector<int> prevTrack;
    int nextTrack = 0;
    if (!states.empty()) {
        prevTrack.resize(states[0].groups.size());
        for (int gi = 0; gi < static_cast<int>(states[0].groups.size()); ++gi) {
            prevTrack[gi] = nextTrack++;
            trackRows.push_back({prevTrack[gi], 0, gi, 0});
        }
        for (int si = 1; si < static_cast<int>(states.size()); ++si) {
            struct Pair { int a=0,b=0,score=0; };
            std::vector<Pair> pairs;
            for (int a = 0; a < static_cast<int>(states[si-1].groups.size()); ++a) {
                for (int b = 0; b < static_cast<int>(states[si].groups.size()); ++b) {
                    const auto& da = detections[si-1][a];
                    const auto& db = detections[si][b];
                    // Once an observation is identified, never attach it to an unknown or a different
                    // known identity just because the tile geometry happens to look similar.
                    if (da.label.empty() != db.label.empty()) continue;
                    if (!da.label.empty() && da.label != db.label) continue;
                    const int score = matchScore(states[si-1].groups[a], states[si].groups[b]);
                    if (score >= 60) pairs.push_back({a,b,score});
                }
            }
            std::sort(pairs.begin(), pairs.end(), [](const Pair& a,const Pair& b){ return a.score>b.score; });
            std::vector<int> currTrack(states[si].groups.size(), -1);
            std::vector<bool> usedPrev(states[si-1].groups.size(), false), usedCurr(states[si].groups.size(), false);
            std::vector<int> scoreFor(states[si].groups.size(), 0);
            for (const auto& p : pairs) {
                if (usedPrev[p.a] || usedCurr[p.b]) continue;
                usedPrev[p.a] = true; usedCurr[p.b] = true;
                currTrack[p.b] = prevTrack[p.a]; scoreFor[p.b] = p.score;
            }
            for (int b = 0; b < static_cast<int>(currTrack.size()); ++b) {
                if (currTrack[b] < 0) currTrack[b] = nextTrack++;
                trackRows.push_back({currTrack[b], si, b, scoreFor[b]});
            }
            prevTrack = std::move(currTrack);
        }
    }
    std::ofstream tracksCsv(outDir / "entity-tracks.csv");
    tracksCsv << "track,state,group,score_from_previous,label,kind,min_x,min_y,width,height,asset\n";
    std::map<int, std::vector<TrackRow>> tracks;
    for (const auto& row : trackRows) {
        tracks[row.track].push_back(row);
        const auto& g = states[row.state].groups[row.group];
        const auto& det = detections[row.state][row.group];
        tracksCsv << row.track << ',' << states[row.state].stem << ',' << row.group << ',' << row.score << ','
                  << (det.label.empty()?"unknown":det.label) << ',' << (det.kind.empty()?"unknown":det.kind) << ','
                  << g.minX << ',' << g.minY << ',' << (g.maxX-g.minX+1) << ',' << (g.maxY-g.minY+1) << ','
                  << states[row.state].stem << "/groups/" << g.assetBase << ".bmp\n";
    }
    std::ofstream newReport(outDir / "AUTO-NEW-CANDIDATES.md");
    newReport << "# DKC3 Oracle - new/unknown candidates\n\n";
    newReport << "Known sprites are filtered using the knowledge base. Review these tracks first; they are the best candidates for genuinely new entities.\n\n";
    int unknownTracks = 0;
    for (const auto& [trackId, rows] : tracks) {
        bool anyKnown = false;
        for (const auto& r : rows) if (!detections[r.state][r.group].label.empty()) anyKnown = true;
        if (anyKnown) continue;
        ++unknownTracks;
        newReport << "## Track " << trackId << " (" << rows.size() << " capture(s))\n\n";
        for (const auto& r : rows) {
            const auto& g = states[r.state].groups[r.group];
            newReport << "- `" << states[r.state].stem << "` group " << r.group << ", score-prev " << r.score
                      << ", bbox " << (g.maxX-g.minX+1) << 'x' << (g.maxY-g.minY+1)
                      << " at " << g.minX << ',' << g.minY << " — `" << states[r.state].stem << "/groups/" << g.assetBase << ".bmp`\n";
        }
        newReport << '\n';
    }
    if (unknownTracks == 0) newReport << "No unknown tracks in this batch.\n";

    writeWramReports(states, outDir);
    writeManifest(states, links, outDir / "manifest.json");

    std::ofstream summary(outDir / "SUMMARY.txt");
    summary << "DKC3 ORACLE BATCH\n"
            << "states=" << states.size() << "\n"
            << "visible_oam=";
    std::size_t totalOam = 0, totalGroups = 0;
    for (const auto& s : states) { totalOam += s.sprites.size(); totalGroups += s.groups.size(); }
    summary << totalOam << "\ngroups=" << totalGroups << "\nlinks=" << links.size() << "\nrepeated_families=" << familyId << "\n"
            << "knowledge_refs=" << knownRefs.size() << "\nknown_detections=" << knownCount << "\nunknown_tracks=" << unknownTracks << "\n"
            << "outputs=frames,oam_csv,group_bmp,group_nspr,wram_diffs,wram_hotspots,wram_ppu_correlations,entity_links,entity_tracks,known_detections,new_candidates,manifest\n";

    std::cout << "ORACLE_BATCH_OK states=" << states.size() << " groups=" << totalGroups
              << " links=" << links.size() << " families=" << familyId << " known=" << knownCount
              << " unknown_tracks=" << unknownTracks << " out=" << outDir.string() << "\n";
    return 0;
}
