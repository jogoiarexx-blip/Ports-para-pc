#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <map>
#include <optional>
#include <sstream>
#include <string>
#include <vector>

namespace fs = std::filesystem;

namespace {
constexpr std::size_t kLevelData = 0x3D06AF;
constexpr int kFirstLevel = 0x25;
constexpr int kLastLevel = 0x2B;
constexpr std::size_t kTidalBreakable = 0x33A7CC;

const std::map<int, std::string> kNames = {
    {0x25, "lakeside-limbo"}, {0x26, "kreeping-klasps"}, {0x27, "tidal-trouble"},
    {0x28, "doorstop-dash"}, {0x29, "squeals-on-wheels"}, {0x2A, "murky-mill"}, {0x2B, "skiddas-row"},
};
const std::vector<std::string> kPointNames = {"start", "checkpoint", "bonus1", "bonus2", "warp", "demo"};

struct Point { std::string kind; int index = 0; std::uint8_t flags = 0; std::uint16_t x = 0, y = 0; };
struct Connection { std::uint8_t slot = 0, target = 0; };
struct Record {
    std::size_t romOffset = 0;
    std::uint16_t levelType = 0, shared = 0, tail = 0;
    std::uint8_t song = 0;
    std::vector<std::uint8_t> rawHeader;
    std::vector<Point> points;
    std::vector<Connection> connections;
};

bool readFile(const fs::path& path, std::vector<std::uint8_t>& data) {
    std::ifstream in(path, std::ios::binary);
    if (!in) return false;
    in.seekg(0, std::ios::end);
    const auto size = in.tellg();
    if (size < 0) return false;
    in.seekg(0, std::ios::beg);
    data.resize(static_cast<std::size_t>(size));
    in.read(reinterpret_cast<char*>(data.data()), static_cast<std::streamsize>(data.size()));
    return static_cast<bool>(in);
}

std::uint16_t u16(const std::vector<std::uint8_t>& d, std::size_t off) {
    return static_cast<std::uint16_t>(d[off] | (std::uint16_t(d[off + 1]) << 8));
}

std::string hexN(std::uint64_t value, int width) {
    std::ostringstream ss;
    ss << "0x" << std::uppercase << std::hex << std::setw(width) << std::setfill('0') << value;
    return ss.str();
}

bool parseInt(const std::string& text, int& value) {
    try {
        std::size_t used = 0;
        value = std::stoi(text, &used, 0);
        return used == text.size();
    } catch (...) { return false; }
}

bool parseRecords(const std::vector<std::uint8_t>& data, std::map<int, Record>& out, std::string& error) {
    std::size_t p = kLevelData;
    for (int id = kFirstLevel; id <= kLastLevel; ++id) {
        if (p + 15 > data.size()) { error = "metadata header past ROM"; return false; }
        Record r;
        r.romOffset = p;
        r.levelType = u16(data, p);
        r.song = data[p + 2];
        r.shared = u16(data, p + 3);
        r.rawHeader.assign(data.begin() + static_cast<std::ptrdiff_t>(p), data.begin() + static_cast<std::ptrdiff_t>(p + 15));
        p += 15;
        int pointIndex = 0;
        while (p < data.size() && data[p] != 0xFF) {
            if (p + 5 > data.size()) { error = "point table past ROM"; return false; }
            Point q;
            q.index = pointIndex;
            q.kind = pointIndex < static_cast<int>(kPointNames.size()) ? kPointNames[pointIndex] : "point" + std::to_string(pointIndex);
            q.flags = data[p];
            q.x = u16(data, p + 1);
            q.y = u16(data, p + 3);
            r.points.push_back(q);
            ++pointIndex;
            p += 5;
        }
        if (p >= data.size()) { error = "missing point terminator"; return false; }
        ++p;
        while (p + 1 < data.size() && !(data[p] == 0xFF && data[p + 1] == 0xFF)) {
            r.connections.push_back({data[p + 1], data[p]});
            p += 2;
        }
        if (p + 1 >= data.size()) { error = "missing connection terminator"; return false; }
        p += 2;
        if (p + 2 > data.size()) { error = "metadata tail past ROM"; return false; }
        r.tail = u16(data, p);
        p += 2;
        out[id] = std::move(r);
    }
    return true;
}

bool writeRecord(const fs::path& path, int id, const Record& r, const std::vector<std::uint8_t>& data) {
    fs::create_directories(path.parent_path());
    std::ofstream out(path);
    if (!out) return false;
    out << "# Generated offline from input/dkc3_ptbr.sfc. Runtime does not read ROM.\n";
    out << "DKC3_LEVEL_META 1\n";
    out << "level_id " << hexN(id, 2) << "\n";
    out << "name " << kNames.at(id) << "\n";
    out << "rom_offset " << hexN(r.romOffset, 6) << "\n";
    out << "level_type " << hexN(r.levelType, 4) << "\n";
    out << "song_id " << hexN(r.song, 2) << "\n";
    out << "shared_data " << hexN(r.shared, 4) << "\n";
    out << "raw_header ";
    for (std::size_t i = 0; i < r.rawHeader.size(); ++i) {
        if (i) out << ' ';
        out << std::nouppercase << std::hex << std::setw(2) << std::setfill('0') << int(r.rawHeader[i]);
    }
    out << std::dec << std::uppercase << "\n";
    for (const auto& q : r.points) {
        out << "point " << q.kind << ' ' << q.index << ' ' << hexN(q.flags, 2) << ' ' << hexN(q.x, 4) << ' ' << hexN(q.y, 4) << "\n";
    }
    for (const auto& c : r.connections) out << "connection " << int(c.slot) << ' ' << hexN(c.target, 2) << "\n";
    out << "tail " << hexN(r.tail, 4) << "\n";
    if (id == 0x27) {
        if (kTidalBreakable + 6 > data.size()) return false;
        const auto vram = u16(data, kTidalBreakable);
        const auto tilemap = u16(data, kTidalBreakable + 2);
        const auto count = data[kTidalBreakable + 4];
        const auto tile = data[kTidalBreakable + 5];
        out << "breakable_vram_word " << hexN(vram, 4) << "\n";
        out << "breakable_tilemap_offset " << hexN(tilemap, 4) << "\n";
        out << "breakable_count " << int(count) << "\n";
        out << "breakable_tile_id " << hexN(tile, 2) << "\n";
    }
    return static_cast<bool>(out);
}
}  // namespace

int main(int argc, char** argv) {
    if (argc < 3) {
        std::cerr << "usage: dkc3_import_level_metadata ROM OUTDIR [--level LEVEL_ID]\n";
        return 2;
    }
    const fs::path romPath = argv[1];
    const fs::path outDir = argv[2];
    std::optional<int> only;
    for (int i = 3; i + 1 < argc; ++i) {
        if (std::string(argv[i]) == "--level") {
            int value = 0;
            if (!parseInt(argv[i + 1], value)) { std::cerr << "invalid level id\n"; return 3; }
            only = value;
            ++i;
        }
    }
    std::vector<std::uint8_t> data;
    if (!readFile(romPath, data)) { std::cerr << "cannot read ROM\n"; return 4; }
    if (data.size() == 0x400200) data.erase(data.begin(), data.begin() + 0x200);
    if (data.size() != 0x400000) { std::cerr << "unexpected ROM size: " << data.size() << " bytes\n"; return 5; }
    std::map<int, Record> records;
    std::string error;
    if (!parseRecords(data, records, error)) { std::cerr << "metadata parse failed: " << error << "\n"; return 6; }
    if (only && !records.count(*only)) { std::cerr << "level id out of supported range: " << hexN(*only, 2) << "\n"; return 7; }
    for (const auto& [id, r] : records) {
        if (only && id != *only) continue;
        const fs::path out = outDir / (kNames.at(id) + ".original.txt");
        if (!writeRecord(out, id, r, data)) { std::cerr << "cannot write metadata: " << out << "\n"; return 8; }
        std::cout << "META_OK id=" << hexN(id, 2) << " off=" << hexN(r.romOffset, 6)
                  << " points=" << r.points.size() << " connections=" << r.connections.size() << "\n";
    }
    return 0;
}
