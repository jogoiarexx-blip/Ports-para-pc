#include <algorithm>
#include <cctype>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
namespace fs=std::filesystem;

struct Page { int index=0; fs::path scene; };
static bool starts(const std::string&s,const std::string&p){return s.rfind(p,0)==0;}
static std::string titleFromSlug(std::string s){
  bool cap=true; for(char&c:s){ if(c=='-'||c=='_'){c=' ';cap=true;} else if(cap){c=static_cast<char>(std::toupper(static_cast<unsigned char>(c)));cap=false;} }
  return s;
}
int main(int argc,char**argv){
  if(argc<5){std::cerr<<"usage: dkc3_make_level_scaffold ORIGINAL_META OUT_LEVEL SLUG PAGES_DIR [STEP] [TAIL]\n";return 2;}
  fs::path metaPath=argv[1],outPath=argv[2],pagesDir=argv[4]; std::string slug=argv[3];
  int step=argc>=6?std::stoi(argv[5]):96, tail=argc>=7?std::stoi(argv[6]):320;
  std::ifstream in(metaPath); if(!in){std::cerr<<"metadata open failed\n";return 3;}
  std::string levelId,romOff,levelType,songId,sharedData; std::vector<std::string> points,connections;
  std::string brVram,brOff,brTile; int brCount=0; std::string line;
  while(std::getline(in,line)){
    if(line.empty()||line[0]=='#') continue;
    std::istringstream ss(line);
    std::string k;
    ss>>k;
    if(k=="level_id") ss>>levelId; else if(k=="rom_offset")ss>>romOff; else if(k=="level_type")ss>>levelType;
    else if(k=="song_id")ss>>songId; else if(k=="shared_data")ss>>sharedData;
    else if(k=="point"){std::string rest;std::getline(ss,rest);if(!rest.empty()&&rest[0]==' ')rest.erase(rest.begin());points.push_back(rest);}
    else if(k=="connection"){std::string rest;std::getline(ss,rest);if(!rest.empty()&&rest[0]==' ')rest.erase(rest.begin());connections.push_back(rest);}
    else if(k=="breakable_vram_word")ss>>brVram; else if(k=="breakable_tilemap_offset")ss>>brOff;
    else if(k=="breakable_count")ss>>brCount; else if(k=="breakable_tile_id")ss>>brTile;
  }
  std::vector<Page> pages;
  if(fs::exists(pagesDir))for(const auto&e:fs::directory_iterator(pagesDir)){ if(!e.is_directory())continue;auto n=e.path().filename().string();if(!starts(n,"page"))continue;int idx=-1;try{idx=std::stoi(n.substr(4));}catch(...){continue;}fs::path sc=e.path()/(slug+"-page"+std::to_string(idx)+".nscene");if(fs::exists(sc))pages.push_back({idx,sc});}
  if(pages.empty()){std::cerr<<"no pages available for scaffold\n";return 4;}
  std::sort(pages.begin(),pages.end(),[](auto&a,auto&b){return a.index<b.index;});
  int width=pages.back().index*step+tail; if(width<320)width=320;
  fs::create_directories(outPath.parent_path()); std::ofstream out(outPath); if(!out)return 5;
  out<<"# AUTO-SCAFFOLD: gerado a partir de metadata original + capturas. Colisoes/entidades ainda precisam de validacao.\n";
  out<<"id "<<slug<<"\ndisplay_name "<<titleFromSlug(slug)<<" (bootstrap)\n";
  if(!levelId.empty()) out<<"original_level_id "<<levelId<<"\n";
  out<<"bootstrap 1\n";
  if(!romOff.empty()) out<<"original_rom_offset "<<romOff<<"\n";
  if(!levelType.empty()) out<<"original_level_type "<<levelType<<"\n";
  if(!songId.empty()) out<<"original_song_id "<<songId<<"\n";
  if(!sharedData.empty()) out<<"original_shared_data "<<sharedData<<"\n";
  for(const auto&p:points) out<<"original_point "<<p<<"\n";
  for(const auto&c:connections) out<<"original_connection "<<c<<"\n";
  if(!brVram.empty()&&!brOff.empty()&&brCount>0&&!brTile.empty())out<<"original_breakable "<<brVram<<' '<<brOff<<' '<<brCount<<' '<<brTile<<"\n";
  out<<"size "<<width<<" 224\n";
  const fs::path base=outPath.parent_path(); for(const auto&p:pages)out<<"native_scene_page "<<p.index*step<<' '<<fs::relative(p.scene,base).generic_string()<<"\n";
  out<<"spawn 28 92\ncamera 0 0 "<<width<<" 224\n";
  out<<"player_sprite ../doorstop/native/sprites/dixie_idle.nspr\ncompanion_sprite ../doorstop/native/sprites/kiddy_idle.nspr\n";
  const char* states[]={"idle","run","jump","fall","hang","attack"};
  for(const char*st:states)out<<"player_anim "<<st<<" ../doorstop/native/anims/dixie_"<<st<<".nanim\n";
  for(const char*st:states)out<<"companion_anim "<<st<<" ../doorstop/native/anims/kiddy_"<<st<<".nanim\n";
  out<<"companion_offset -18 -5\n";
  out<<"# Piso bootstrap apenas para permitir navegacao/validacao visual inicial. Substituir pela colisao original quando extraida.\n";
  out<<"solid 0 190 "<<width<<" 34\n";
  std::cout<<"LEVEL_SCAFFOLD_OK level="<<slug<<" pages="<<pages.size()<<" width="<<width<<" out="<<outPath.string()<<"\n";
  return 0;
}
