#include "LegacySnesState.h"
#include <algorithm>
#include <cstdint>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>
namespace fs=std::filesystem;
#pragma pack(push,1)
struct DevStateHeader{char magic[8];uint32_t version,payloadSize;uint64_t romSize,romHash;};
struct SpriteHeader{char magic[4]={'N','S','P','R'};uint16_t version=1,flags=0,width=0,height=0;int16_t originX=0,originY=0;uint32_t pixelCount=0;};
struct BmpFileHeader{uint16_t type=0x4d42;uint32_t size=0;uint16_t r1=0,r2=0;uint32_t off=54;};
struct BmpInfoHeader{uint32_t size=40;int32_t w=0,h=0;uint16_t planes=1,bpp=32;uint32_t comp=0,sizeImage=0;int32_t xppm=3780,yppm=3780;uint32_t used=0,important=0;};
#pragma pack(pop)
static bool loadState(const fs::path&p,Snes&s){
  std::ifstream in(p,std::ios::binary);DevStateHeader h{};in.read((char*)&h,sizeof h);const char m[8]={'D','K','C','3','S','T','0','1'};
  if(!in||std::memcmp(h.magic,m,8)||h.version!=2)return false;
  const size_t current=sizeof(Snes)-offsetof(Snes,wram),old=498832;std::vector<uint8_t>b(h.payloadSize);in.read((char*)b.data(),(std::streamsize)b.size());if(!in)return false;auto*dst=(uint8_t*)&s.wram[0];
  if(b.size()==current){std::memcpy(dst,b.data(),b.size());return true;}
  if(b.size()==old){std::memset(dst,0,current);constexpr size_t oldVideo=498368,oldBrr=498372,newVideo=498376,newBrr=498384;std::memcpy(dst,b.data(),oldVideo);std::memcpy(dst+newVideo,b.data()+oldVideo,oldBrr-oldVideo);std::memcpy(dst+newBrr,b.data()+oldBrr,b.size()-oldBrr);return true;}
  return false;
}
static void spriteSizes(uint8_t o,int&sm,int&lg){static constexpr int S[8]={8,8,8,16,16,32,16,16},L[8]={16,32,64,32,64,64,32,32};const int m=(o>>5)&7;sm=S[m];lg=L[m];}
static int tilePixel(const Snes&s,uint32_t a,int y,int x){const uint8_t mask=(uint8_t)(0x80u>>x);auto pair=[&](uint32_t off,int sh){const uint8_t p0=s.vram[(a+y*2+off)&0xffff],p1=s.vram[(a+y*2+off+1)&0xffff];return ((p0&mask)?1<<sh:0)|((p1&mask)?2<<sh:0);};return pair(0,0)|pair(16,2);}
static uint32_t color15(uint16_t c){auto q=[](int v){return uint8_t((v<<3)|(v>>2));};return 0xff000000u|(uint32_t(q(c&31))<<16)|(uint32_t(q((c>>5)&31))<<8)|q((c>>10)&31);}
static void drawSlot(const Snes&s,int slot,std::vector<uint32_t>&canvas,int W,int H,int xBias){
  const int o=slot*4;int x=s.oam[o],y=s.oam[o+1],tile=s.oam[o+2],attr=s.oam[o+3];const int hi=s.oam[512+slot/4],shift=(slot&3)*2;x|=((hi>>shift)&1)<<8;if(x>=256)x-=512;
  int sm=0,lg=0;spriteSizes(s.obsel,sm,lg);const int z=((hi>>(shift+1))&1)?lg:sm;const bool hf=(attr&0x40)!=0,vf=(attr&0x80)!=0;const int pal=(attr>>1)&7;
  const uint32_t base1=(uint32_t(s.obsel&7)<<14),base2=base1+uint32_t((s.obsel&0x18)+8u)*0x400u,nameBase=(attr&1)?base2:base1;
  for(int dy=0;dy<z;dy++)for(int dx=0;dx<z;dx++){
    const int sx=hf?z-1-dx:dx,sy=vf?z-1-dy:dy,usedTile=((((tile>>4)+(sy>>3))<<4)|(((tile&15)+(sx>>3))&15))&255,pi=tilePixel(s,(nameBase+uint32_t(usedTile)*32u)&0xffffu,sy&7,sx&7);if(!pi)continue;
    const int xx=xBias+x+dx,yy=(y+dy)&255;if((unsigned)xx<(unsigned)W&&(unsigned)yy<(unsigned)H)canvas[(size_t)yy*W+xx]=color15(s.cgram[(128+pal*16+pi)&255]);
  }
}
static bool saveBmp(const fs::path&p,int w,int h,std::vector<uint32_t>px){for(auto&c:px)if(!(c>>24))c=0xff202020u;std::ofstream o(p,std::ios::binary);if(!o)return false;BmpFileHeader f;BmpInfoHeader i;i.w=w;i.h=-h;i.sizeImage=(uint32_t)(w*h*4);f.size=f.off+i.sizeImage;o.write((char*)&f,sizeof f);o.write((char*)&i,sizeof i);o.write((char*)px.data(),(std::streamsize)px.size()*4);return bool(o);}
int main(int argc,char**argv){
  if(argc<7){std::cerr<<"usage: dkc3_import_oam_group STATE FIRST_SLOT LAST_SLOT ANCHOR_X ANCHOR_Y OUT_NSPR [PREVIEW_BMP] [flip_x]\n";return 2;}
  Snes s;if(!loadState(argv[1],s)){std::cerr<<"state open/layout failed\n";return 3;}const int first=std::stoi(argv[2]),last=std::stoi(argv[3]),anchorX=std::stoi(argv[4]),anchorY=std::stoi(argv[5]);if(first<0||last>=128||first>last)return 4;
  const int W=512,H=256,xBias=128;std::vector<uint32_t>canvas((size_t)W*H,0);for(int slot=last;slot>=first;--slot)drawSlot(s,slot,canvas,W,H,xBias);
  int minx=W,miny=H,maxx=-1,maxy=-1;for(int y=0;y<H;y++)for(int x=0;x<W;x++)if(canvas[(size_t)y*W+x]>>24){minx=std::min(minx,x);miny=std::min(miny,y);maxx=std::max(maxx,x);maxy=std::max(maxy,y);}if(maxx<minx)return 5;
  const int sw=maxx-minx+1,sh=maxy-miny+1;std::vector<uint32_t>px((size_t)sw*sh);for(int y=0;y<sh;y++)for(int x=0;x<sw;x++)px[(size_t)y*sw+x]=canvas[(size_t)(miny+y)*W+minx+x];
  const bool flipOutput=argc>=9&&std::string(argv[8])=="flip_x";
  if(argc>=9&&!flipOutput){std::cerr<<"unknown output transform: "<<argv[8]<<"\n";return 9;}
  if(flipOutput)for(int y=0;y<sh;y++)std::reverse(px.begin()+(size_t)y*sw,px.begin()+(size_t)(y+1)*sw);
  SpriteHeader h;h.width=(uint16_t)sw;h.height=(uint16_t)sh;h.originX=(int16_t)(xBias+anchorX-minx);h.originY=(int16_t)(anchorY-miny);h.pixelCount=(uint32_t)px.size();fs::create_directories(fs::path(argv[6]).parent_path());std::ofstream out(argv[6],std::ios::binary);if(!out)return 6;out.write((char*)&h,sizeof h);out.write((char*)px.data(),(std::streamsize)px.size()*4);if(!out)return 7;
  if(argc>=8){fs::create_directories(fs::path(argv[7]).parent_path());if(!saveBmp(argv[7],sw,sh,px))return 8;}
  std::cout<<"OAM_GROUP_OK slots="<<first<<"-"<<last<<" size="<<sw<<"x"<<sh<<" origin="<<h.originX<<","<<h.originY<<" flip_x="<<(flipOutput?1:0)<<"\n";return 0;
}
