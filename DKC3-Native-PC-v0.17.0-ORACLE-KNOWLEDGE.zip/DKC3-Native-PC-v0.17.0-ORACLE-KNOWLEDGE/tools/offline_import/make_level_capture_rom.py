#!/usr/bin/env python3
"""Create a temporary development ROM that redirects Doorstop Dash's metadata slot
into another early DKC3 level. Offline capture helper only; never shipped/used by runtime.
"""
from pathlib import Path
import argparse

LEVEL_DATA = 0x3D06AF
FIRST, LAST = 0x25, 0x2B
DOORSTOP_ID = 0x28

def record_spans(data: bytes):
    p = LEVEL_DATA
    spans = {}
    for level_id in range(FIRST, LAST + 1):
        start = p
        p += 15
        while data[p] != 0xFF:
            p += 5
        p += 1
        while data[p:p+2] != b'\xff\xff':
            p += 2
        p += 2
        p += 2
        spans[level_id] = (start, p)
    return spans

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('rom', type=Path)
    ap.add_argument('out', type=Path)
    ap.add_argument('--source-level', type=lambda s:int(s,0), required=True)
    args = ap.parse_args()
    data = bytearray(args.rom.read_bytes())
    if len(data) == 0x400200:
        data = data[0x200:]
    if len(data) != 0x400000:
        raise SystemExit('expected 4 MiB headerless ROM')
    spans = record_spans(data)
    if args.source_level not in spans:
        raise SystemExit(f'unsupported source level id 0x{args.source_level:02X}')
    src0, src1 = spans[args.source_level]
    dst0, dst1 = spans[DOORSTOP_ID]
    src = bytes(data[src0:src1])
    dst_len = dst1-dst0
    if len(src) > dst_len:
        raise SystemExit(f'source record ({len(src)}) does not fit Doorstop slot ({dst_len})')
    # Early records are normally 54 bytes while Doorstop has one extra 5-byte point.
    # Duplicate source start point before its terminator so parser layout remains valid.
    while len(src) < dst_len:
        term = src.find(b'\xff', 15)
        if term < 20 or dst_len-len(src) < 5:
            raise SystemExit('cannot pad source metadata safely')
        first_point = src[15:20]
        src = src[:term] + first_point + src[term:]
    if len(src) != dst_len:
        raise SystemExit('padded metadata length mismatch')
    data[dst0:dst1] = src
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_bytes(data)
    print(f'CAPTURE_ROM_OK source=0x{args.source_level:02X} doorstop_slot=0x{dst0:06X} bytes={len(src)} out={args.out}')

if __name__ == '__main__':
    main()
