#include "LegacySnesState.h"
#include <algorithm>
#include <cstdint>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <vector>
namespace fs=std::filesystem;
#pragma pack(push,1)
struct DevStateHeader{char magic[8];uint32_t version,payloadSize;uint64_t romSize,romHash;};
struct SpriteHeader{char magic[4]={'N','S','P','R'};uint16_t version=1,flags=0,width=0,height=0;int16_t originX=0,originY=0;uint32_t pixelCount=0;};
#pragma pack(pop)
static bool load(const fs::path&p,Snes&s){std::ifstream in(p,std::ios::binary);DevStateHeader h{};in.read((char*)&h,sizeof h);const char m[8]={'D','K','C','3','S','T','0','1'};if(!in||memcmp(h.magic,m,8)||h.version!=2)return false;const size_t cur=sizeof(Snes)-offsetof(Snes,wram),old=498832;std::vector<uint8_t>b(h.payloadSize);in.read((char*)b.data(),b.size());if(!in)return false;auto*dst=(uint8_t*)&s.wram[0];if(b.size()==cur){memcpy(dst,b.data(),b.size());return true;}if(b.size()==old){memset(dst,0,cur);constexpr size_t oldVideo=498368,oldBrr=498372,newVideo=498376,newBrr=498384;memcpy(dst,b.data(),oldVideo);memcpy(dst+newVideo,b.data()+oldVideo,oldBrr-oldVideo);memcpy(dst+newBrr,b.data()+oldBrr,b.size()-oldBrr);return true;}return false;}
static void sizes(uint8_t o,int&sm,int&lg){static int S[8]={8,8,8,16,16,32,16,16},L[8]={16,32,64,32,64,64,32,32};int m=(o>>5)&7;sm=S[m];lg=L[m];}
static int pix(const Snes&s,uint32_t a,int y,int x){uint8_t m=0x80>>x;auto p=[&](uint32_t off,int sh){uint8_t a0=s.vram[(a+y*2+off)&0xffff],a1=s.vram[(a+y*2+off+1)&0xffff];return ((a0&m)?1<<sh:0)|((a1&m)?2<<sh:0);};return p(0,0)|p(16,2);}
static uint32_t col(uint16_t c){auto q=[](int v){return uint8_t((v<<3)|(v>>2));};return 0xff000000u|(uint32_t(q(c&31))<<16)|(uint32_t(q((c>>5)&31))<<8)|q((c>>10)&31);}
static void draw(const Snes&s,int sl,std::vector<uint32_t>&cv,int W,int H,int bias){int o=sl*4,x=s.oam[o],y=s.oam[o+1],t=s.oam[o+2],at=s.oam[o+3],hi=s.oam[512+sl/4],sh=(sl&3)*2;x|=((hi>>sh)&1)<<8;if(x>=256)x-=512;int sm,lg;sizes(s.obsel,sm,lg);int z=((hi>>(sh+1))&1)?lg:sm;bool hf=at&0x40,vf=at&0x80;int pal=(at>>1)&7;uint32_t b1=(s.obsel&7)<<14,b2=b1+uint32_t((s.obsel&0x18)+8)*0x400,name=(at&1)?b2:b1;for(int dy=0;dy<z;dy++)for(int dx=0;dx<z;dx++){int sx=hf?z-1-dx:dx,sy=vf?z-1-dy:dy,ut=((((t>>4)+(sy>>3))<<4)|(((t&15)+(sx>>3))&15))&255;int pi=pix(s,(name+ut*32)&0xffff,sy&7,sx&7);if(!pi)continue;int xx=bias+x+dx,yy=(y+dy)&255;if((unsigned)xx<(unsigned)W&&(unsigned)yy<(unsigned)H)cv[(size_t)yy*W+xx]=col(s.cgram[(128+pal*16+pi)&255]);}}
int main(int ac,char**av){if(ac<5){std::cerr<<"usage: dkc3_import_pose STATE OAM_ATTR OUT_NSPR ORIGIN_X\n";return 2;}Snes s;if(!load(av[1],s))return 3;int target=std::stoi(av[2],nullptr,0),originX=std::stoi(av[4]);const int W=512,H=256,bias=128;std::vector<uint32_t>cv((size_t)W*H);int count=0;for(int sl=127;sl>=0;--sl){int at=s.oam[sl*4+3];if((at&0x3f)!=target)continue;draw(s,sl,cv,W,H,bias);count++;}int minx=W,miny=H,maxx=-1,maxy=-1;for(int y=0;y<H;y++)for(int x=0;x<W;x++)if(cv[(size_t)y*W+x]>>24){minx=std::min(minx,x);miny=std::min(miny,y);maxx=std::max(maxx,x);maxy=std::max(maxy,y);}if(maxx<minx)return 4;int sw=maxx-minx+1,sh=maxy-miny+1;std::vector<uint32_t>px((size_t)sw*sh);for(int y=0;y<sh;y++)for(int x=0;x<sw;x++)px[(size_t)y*sw+x]=cv[(size_t)(miny+y)*W+minx+x];SpriteHeader h;h.width=sw;h.height=sh;h.originX=originX;h.originY=std::max(-8,sh-34);h.pixelCount=px.size();std::ofstream out(av[3],std::ios::binary);if(!out)return 5;out.write((char*)&h,sizeof h);out.write((char*)px.data(),std::streamsize(px.size()*4));if(!out)return 6;std::cout<<"POSE_OK attr="<<target<<" slots="<<count<<" size="<<sw<<"x"<<sh<<" origin="<<h.originX<<","<<h.originY<<"\n";}
