#include <algorithm>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

namespace fs = std::filesystem;

struct PageInfo {
    int index = 0;
    fs::path scene;
};

static bool startsWith(const std::string& s, const std::string& p) {
    return s.rfind(p, 0) == 0;
}

int main(int argc, char** argv) {
    if (argc < 4) {
        std::cerr << "usage: dkc3_update_level_pages LEVEL_FILE PAGES_DIR SLUG [STEP] [TAIL]\n";
        return 2;
    }
    const fs::path levelPath = argv[1];
    const fs::path pagesDir = argv[2];
    const std::string slug = argv[3];
    const int step = argc >= 5 ? std::stoi(argv[4]) : 96;
    const int tail = argc >= 6 ? std::stoi(argv[5]) : 320;
    if (step <= 0 || tail < 256) {
        std::cerr << "invalid step/tail\n";
        return 2;
    }
    std::ifstream in(levelPath);
    if (!in) {
        std::cerr << "level open failed: " << levelPath << "\n";
        return 3;
    }
    std::vector<std::string> lines;
    std::string line;
    int oldWidth = 0, oldHeight = 224;
    while (std::getline(in, line)) {
        lines.push_back(line);
        std::istringstream ss(line);
        std::string key;
        ss >> key;
        if (key == "size") ss >> oldWidth >> oldHeight;
    }
    if (oldWidth <= 0) {
        std::cerr << "level has no valid size line\n";
        return 4;
    }

    std::vector<PageInfo> pages;
    if (fs::exists(pagesDir)) {
        for (const auto& entry : fs::directory_iterator(pagesDir)) {
            if (!entry.is_directory()) continue;
            const std::string name = entry.path().filename().string();
            if (!startsWith(name, "page")) continue;
            int idx = -1;
            try { idx = std::stoi(name.substr(4)); } catch (...) { continue; }
            if (idx < 0) continue;
            fs::path scene = entry.path() / (slug + "-page" + std::to_string(idx) + ".nscene");
            if (!fs::exists(scene)) {
                // Compatibility with pre-v0.17 page names (e.g. tidal-page0.nscene).
                for (const auto& f : fs::directory_iterator(entry.path())) {
                    if (f.is_regular_file() && f.path().extension() == ".nscene") { scene = f.path(); break; }
                }
            }
            if (fs::exists(scene)) pages.push_back({idx, scene});
        }
    }
    if (pages.empty()) {
        std::cerr << "no imported pages found in " << pagesDir << "\n";
        return 5;
    }
    std::sort(pages.begin(), pages.end(), [](const PageInfo& a, const PageInfo& b){ return a.index < b.index; });
    pages.erase(std::unique(pages.begin(), pages.end(), [](const PageInfo& a, const PageInfo& b){ return a.index == b.index; }), pages.end());
    const int lastStart = pages.back().index * step;
    const int newWidth = std::max(oldWidth, lastStart + tail);

    std::vector<std::string> out;
    bool pagesInserted = false;
    auto emitPages = [&]() {
        if (pagesInserted) return;
        const fs::path base = levelPath.parent_path();
        for (const auto& p : pages) {
            const fs::path rel = fs::relative(p.scene, base);
            out.push_back("native_scene_page " + std::to_string(p.index * step) + " " + rel.generic_string());
        }
        pagesInserted = true;
    };

    for (const auto& src : lines) {
        if (startsWith(src, "native_scene_page ")) continue;
        std::istringstream ss(src);
        std::string key;
        ss >> key;
        if (key == "size") {
            int w=0,h=0; ss >> w >> h;
            out.push_back("size " + std::to_string(newWidth) + " " + std::to_string(h));
            emitPages();
            continue;
        }
        if (key == "camera") {
            float x=0,y=0,w=0,h=0; ss >> x >> y >> w >> h;
            if (static_cast<int>(w) == oldWidth) w = static_cast<float>(newWidth);
            std::ostringstream os; os << "camera " << x << ' ' << y << ' ' << w << ' ' << h;
            out.push_back(os.str());
            continue;
        }
        if (key == "water") {
            float x=0,y=0,w=0,h=0; ss >> x >> y >> w >> h;
            if (static_cast<int>(x) == 0 && static_cast<int>(w) == oldWidth) w = static_cast<float>(newWidth);
            std::ostringstream os; os << "water " << x << ' ' << y << ' ' << w << ' ' << h;
            out.push_back(os.str());
            continue;
        }
        if (key == "water_current") {
            float x=0,y=0,w=0,h=0,dx=0,dy=0; ss >> x >> y >> w >> h >> dx >> dy;
            if (static_cast<int>(x) == 0 && static_cast<int>(w) == oldWidth) w = static_cast<float>(newWidth);
            std::ostringstream os; os << "water_current " << x << ' ' << y << ' ' << w << ' ' << h << ' ' << dx << ' ' << dy;
            out.push_back(os.str());
            continue;
        }
        out.push_back(src);
    }
    if (!pagesInserted) emitPages();

    const fs::path temp = levelPath.string() + ".tmp";
    std::ofstream of(temp);
    if (!of) return 6;
    for (const auto& l : out) of << l << '\n';
    of.close();
    if (!of) return 6;
    std::error_code ec;
    fs::rename(temp, levelPath, ec);
    if (ec) {
        fs::remove(levelPath, ec);
        ec.clear();
        fs::rename(temp, levelPath, ec);
    }
    if (ec) {
        std::cerr << "replace failed: " << ec.message() << "\n";
        return 7;
    }
    std::cout << "LEVEL_PAGES_OK level=" << slug << " pages=" << pages.size()
              << " width=" << oldWidth << "->" << newWidth << " step=" << step << "\n";
    return 0;
}
