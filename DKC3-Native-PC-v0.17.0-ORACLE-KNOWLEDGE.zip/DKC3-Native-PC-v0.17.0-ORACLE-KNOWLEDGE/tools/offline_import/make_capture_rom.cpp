#include <algorithm>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <map>
#include <sstream>
#include <string>
#include <vector>

namespace fs = std::filesystem;

namespace {
constexpr std::size_t kLevelData = 0x3D06AF;
constexpr int kFirstLevel = 0x25;
constexpr int kLastLevel = 0x2B;
constexpr int kDoorstopId = 0x28;

bool readFile(const fs::path& path, std::vector<std::uint8_t>& data) {
    std::ifstream in(path, std::ios::binary);
    if (!in) return false;
    in.seekg(0, std::ios::end);
    const auto size = in.tellg();
    if (size < 0) return false;
    in.seekg(0, std::ios::beg);
    data.resize(static_cast<std::size_t>(size));
    in.read(reinterpret_cast<char*>(data.data()), static_cast<std::streamsize>(data.size()));
    return static_cast<bool>(in);
}

bool writeFile(const fs::path& path, const std::vector<std::uint8_t>& data) {
    if (path.has_parent_path()) fs::create_directories(path.parent_path());
    std::ofstream out(path, std::ios::binary);
    if (!out) return false;
    out.write(reinterpret_cast<const char*>(data.data()), static_cast<std::streamsize>(data.size()));
    return static_cast<bool>(out);
}

bool parseInt(const std::string& text, int& value) {
    try {
        std::size_t used = 0;
        value = std::stoi(text, &used, 0);
        return used == text.size();
    } catch (...) {
        return false;
    }
}

std::string hex2(int value) {
    std::ostringstream ss;
    ss << "0x" << std::uppercase << std::hex << std::setw(2) << std::setfill('0') << value;
    return ss.str();
}

bool scanRecords(const std::vector<std::uint8_t>& data,
                 std::map<int, std::pair<std::size_t, std::size_t>>& spans,
                 std::string& error) {
    std::size_t p = kLevelData;
    for (int levelId = kFirstLevel; levelId <= kLastLevel; ++levelId) {
        const std::size_t start = p;
        if (p + 15 > data.size()) {
            error = "level metadata header goes past ROM";
            return false;
        }
        p += 15;
        while (p < data.size() && data[p] != 0xFF) {
            if (p + 5 > data.size()) {
                error = "level point table goes past ROM";
                return false;
            }
            p += 5;
        }
        if (p >= data.size()) {
            error = "missing point-table terminator";
            return false;
        }
        ++p;
        while (p + 1 < data.size() && !(data[p] == 0xFF && data[p + 1] == 0xFF)) p += 2;
        if (p + 1 >= data.size()) {
            error = "missing exit-table terminator";
            return false;
        }
        p += 2;
        if (p + 2 > data.size()) {
            error = "level metadata tail goes past ROM";
            return false;
        }
        p += 2;
        spans[levelId] = {start, p};
    }
    return true;
}
}  // namespace

int main(int argc, char** argv) {
    if (argc < 5) {
        std::cerr << "usage: dkc3_make_capture_rom ROM OUT --source-level LEVEL_ID\n";
        return 2;
    }
    fs::path romPath = argv[1];
    fs::path outPath = argv[2];
    int sourceLevel = -1;
    for (int i = 3; i + 1 < argc; ++i) {
        if (std::string(argv[i]) == "--source-level") {
            if (!parseInt(argv[i + 1], sourceLevel)) {
                std::cerr << "invalid level id: " << argv[i + 1] << "\n";
                return 3;
            }
            ++i;
        }
    }
    if (sourceLevel < 0) {
        std::cerr << "missing --source-level LEVEL_ID\n";
        return 3;
    }

    std::vector<std::uint8_t> data;
    if (!readFile(romPath, data)) {
        std::cerr << "cannot read ROM: " << romPath << "\n";
        return 4;
    }
    if (data.size() == 0x400200) data.erase(data.begin(), data.begin() + 0x200);
    if (data.size() != 0x400000) {
        std::cerr << "expected 4 MiB headerless ROM (or 4 MiB + 512-byte copier header), got " << data.size() << " bytes\n";
        return 5;
    }

    std::map<int, std::pair<std::size_t, std::size_t>> spans;
    std::string error;
    if (!scanRecords(data, spans, error)) {
        std::cerr << "metadata scan failed: " << error << "\n";
        return 6;
    }
    if (!spans.count(sourceLevel)) {
        std::cerr << "unsupported source level id " << hex2(sourceLevel)
                  << " (supported " << hex2(kFirstLevel) << ".." << hex2(kLastLevel) << ")\n";
        return 7;
    }

    const auto [src0, src1] = spans[sourceLevel];
    const auto [dst0, dst1] = spans[kDoorstopId];
    std::vector<std::uint8_t> source(data.begin() + static_cast<std::ptrdiff_t>(src0),
                                     data.begin() + static_cast<std::ptrdiff_t>(src1));
    const std::size_t dstLen = dst1 - dst0;
    if (source.size() > dstLen) {
        std::cerr << "source record (" << source.size() << ") does not fit Doorstop slot (" << dstLen << ")\n";
        return 8;
    }
    while (source.size() < dstLen) {
        const auto term = std::find(source.begin() + 15, source.end(), static_cast<std::uint8_t>(0xFF));
        if (term == source.end() || std::distance(source.begin(), term) < 20 || dstLen - source.size() < 5) {
            std::cerr << "cannot pad source metadata safely\n";
            return 9;
        }
        const std::vector<std::uint8_t> firstPoint(source.begin() + 15, source.begin() + 20);
        source.insert(term, firstPoint.begin(), firstPoint.end());
    }
    if (source.size() != dstLen) {
        std::cerr << "padded metadata length mismatch\n";
        return 10;
    }

    std::copy(source.begin(), source.end(), data.begin() + static_cast<std::ptrdiff_t>(dst0));
    if (!writeFile(outPath, data)) {
        std::cerr << "cannot write output: " << outPath << "\n";
        return 11;
    }
    std::cout << "CAPTURE_ROM_OK source=" << hex2(sourceLevel)
              << " doorstop_slot=0x" << std::uppercase << std::hex << std::setw(6) << std::setfill('0') << dst0
              << std::dec << " bytes=" << source.size() << " out=" << outPath.string() << "\n";
    return 0;
}
