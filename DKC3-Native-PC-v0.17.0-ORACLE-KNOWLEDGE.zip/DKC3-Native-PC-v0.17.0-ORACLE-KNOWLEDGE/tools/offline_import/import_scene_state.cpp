#include "LegacySnesState.h"
#include <array>
#include <cstdint>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>
namespace fs=std::filesystem;
#pragma pack(push,1)
struct DevStateHeader{char magic[8];uint32_t version,payloadSize;uint64_t romSize,romHash;};
struct TileHeader{char magic[4]={'N','T','I','L'};uint16_t version=1,bpp=0;uint32_t tileCount=1024,tileW=8,tileH=8,charBaseWord=0;};
struct MapHeader{char magic[4]={'N','M','A','P'};uint16_t version=1,reserved=0;uint32_t width=0,height=0,mapBaseWord=0;};
struct PalHeader{char magic[4]={'N','P','A','L'};uint16_t version=1,colors=256;};
#pragma pack(pop)
static bool loadState(const fs::path&p,Snes&s){
  std::ifstream in(p,std::ios::binary);DevStateHeader h{};in.read((char*)&h,sizeof h);const char m[8]={'D','K','C','3','S','T','0','1'};if(!in||memcmp(h.magic,m,8)||h.version!=2)return false;
  constexpr size_t newPayload=sizeof(Snes)-offsetof(Snes,wram);constexpr size_t oldPayload=498832;std::vector<uint8_t>b(h.payloadSize);in.read((char*)b.data(),b.size());if(!in)return false;auto*dst=(uint8_t*)&s.wram[0];
  if(b.size()==newPayload){memcpy(dst,b.data(),b.size());return true;}
  if(b.size()==oldPayload){memset(dst,0,newPayload);constexpr size_t oldVideo=498368,oldBrr=498372,newVideo=498376,newBrr=498384;memcpy(dst,b.data(),oldVideo);memcpy(dst+newVideo,b.data()+oldVideo,oldBrr-oldVideo);memcpy(dst+newBrr,b.data()+oldBrr,b.size()-oldBrr);return true;}
  std::cerr<<"unsupported payload "<<b.size()<<" expected "<<newPayload<<" or "<<oldPayload<<"\n";return false;
}
static uint16_t vw(const Snes&s,uint16_t wa){uint32_t b=(wa&0x7fff)*2u;return uint16_t(s.vram[b])|uint16_t(s.vram[(b+1)&0xffff])<<8;}
static int tp(const Snes&s,uint32_t a,int y,int x,int bpp){uint8_t m=uint8_t(0x80u>>x);auto pair=[&](uint32_t off,int sh){uint8_t p0=s.vram[(a+y*2+off)&0xffff],p1=s.vram[(a+y*2+off+1)&0xffff];return ((p0&m)?(1<<sh):0)|((p1&m)?(2<<sh):0);};int v=pair(0,0);if(bpp>=4)v|=pair(16,2);if(bpp>=8){v|=pair(32,4);v|=pair(48,6);}return v;}
static void info(const Snes&s,int bg,uint16_t&mb,uint16_t&cb,int&bpp,int&mw,int&mh){mb=uint16_t((s.bgsc[bg]&0xfcu)<<8);int c=(bg<2)?((bg==0?(s.bg12nba&7):((s.bg12nba>>4)&7))<<12):((bg==2?(s.bg34nba&7):((s.bg34nba>>4)&7))<<12);cb=uint16_t(c);int mode=s.bgmode&7;bpp=2;if(mode==1)bpp=(bg==2)?2:4;else if(mode==2)bpp=(bg<2)?4:2;else if(mode==3)bpp=(bg==0)?8:4;else if(mode==4)bpp=(bg==0)?8:2;else if(mode==5)bpp=(bg==0)?4:2;else if(mode==6)bpp=4;int sc=s.bgsc[bg]&3;mw=(sc&1)?64:32;mh=(sc&2)?64:32;}
static bool tiles(const fs::path&p,const Snes&s,uint16_t cb,int bpp){std::ofstream o(p,std::ios::binary);if(!o)return false;TileHeader h;h.bpp=bpp;h.charBaseWord=cb;o.write((char*)&h,sizeof h);std::array<uint8_t,64>q{};uint32_t bpt=bpp*8;for(uint32_t t=0;t<1024;t++){uint32_t base=(uint32_t(cb)*2+t*bpt)&0xffff;for(int y=0;y<8;y++)for(int x=0;x<8;x++)q[y*8+x]=uint8_t(tp(s,base,y,x,bpp));o.write((char*)q.data(),64);}return bool(o);}
static bool map(const fs::path&p,const Snes&s,uint16_t base,int mw,int mh){std::ofstream o(p,std::ios::binary);if(!o)return false;MapHeader h;h.width=mw;h.height=mh;h.mapBaseWord=base;o.write((char*)&h,sizeof h);for(int y=0;y<mh;y++)for(int x=0;x<mw;x++){int page=0;if(mw==64&&x>=32)page++;if(mh==64&&y>=32)page+=(mw==64?2:1);uint16_t e=vw(s,uint16_t(base+page*0x400+(y&31)*32+(x&31)));o.write((char*)&e,2);}return bool(o);}
static bool pal(const fs::path&p,const Snes&s){std::ofstream o(p,std::ios::binary);if(!o)return false;PalHeader h;o.write((char*)&h,sizeof h);o.write((char*)s.cgram,sizeof s.cgram);return bool(o);}
int main(int ac,char**av){if(ac<3){std::cerr<<"usage: dkc3_import_scene_state STATE OUTDIR [SCENE_NAME]\n";return 2;}Snes s;if(!loadState(av[1],s)){std::cerr<<"state open/layout failed\n";return 3;}fs::path out=av[2];fs::create_directories(out);std::string scene=ac>=4?av[3]:"scene";if(!pal(out/"palette.npal",s))return 4;std::ofstream meta(out/(scene+".nscene"));meta<<"NATIVE_SCENE 1\nmode "<<(int)(s.bgmode&7)<<"\nbg3_priority "<<((s.bgmode&8)?1:0)<<"\ntm "<<(int)s.tm<<"\nts "<<(int)s.ts<<"\ncgwsel "<<(int)s.cgwsel<<"\ncgadsub "<<(int)s.cgadsub<<"\nfixed_color "<<s.fixedColor<<"\nbrightness "<<(int)(s.inidisp&15)<<"\nbackdrop 0\nviewport 256 224\npalette palette.npal\n";for(int bg=0;bg<3;bg++){uint16_t mb,cb;int bpp,mw,mh;info(s,bg,mb,cb,bpp,mw,mh);std::string n="bg"+std::to_string(bg+1);if(!tiles(out/(n+".ntiles"),s,cb,bpp)||!map(out/(n+".nmap"),s,mb,mw,mh))return 5;meta<<"layer "<<n<<" "<<bpp<<" "<<mw<<" "<<mh<<" "<<s.bghofs[bg]<<" "<<s.bgvofs[bg]<<" "<<((s.tm>>bg)&1)<<" "<<n<<".ntiles "<<n<<".nmap\n";}meta<<"source_frame "<<s.frame<<"\n";std::cout<<"SCENE_IMPORT_OK frame="<<s.frame<<" mode="<<(int)(s.bgmode&7)<<" tm="<<(int)s.tm<<" scene="<<scene<<"\n";return 0;}
