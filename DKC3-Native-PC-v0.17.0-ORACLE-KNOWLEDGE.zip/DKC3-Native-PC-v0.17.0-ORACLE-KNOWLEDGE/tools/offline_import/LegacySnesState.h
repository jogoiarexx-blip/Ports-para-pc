#pragma once
#include <cstdint>
#include <vector>
#include <string>

struct CpuState {
    uint16_t a = 0, x = 0, y = 0, sp = 0x01FF, dp = 0, pc = 0;
    uint8_t dbr = 0, pbr = 0, p = 0x34;
    bool e = true;
    bool stopped = false;
    bool waiting = false;
    uint64_t cycles = 0;
};

struct DmaChannel {
    uint8_t ctrl = 0, dest = 0;
    uint16_t src = 0, size = 0, hdmaTable = 0, hdmaIndirect = 0;
    uint8_t srcBank = 0, hdmaBank = 0, lineCounter = 0;
    bool active = false, repeat = false, doTransfer = false;
};

struct SpcState {
    uint8_t ram[0x10000]{};
    uint8_t dsp[128]{};
    uint16_t pc = 0xFFC0, ya = 0;
    uint8_t x = 0, sp = 0xEF, psw = 0;
    uint8_t control = 0x80;
    uint8_t dspAddr = 0;
    uint8_t portIn[4]{};
    uint8_t portOut[4]{};
    uint8_t timerOut[3]{};
    uint8_t timerTarget[3]{};
    int timerDiv[3]{};
    int timerStage[3]{};
    bool timersOn[3]{};
    uint8_t a() const { return ya & 0xFF; }
    uint8_t y() const { return ya >> 8; }
    void setA(uint8_t v) { ya = (ya & 0xFF00) | v; }
    void setY(uint8_t v) { ya = (ya & 0x00FF) | (uint16_t(v) << 8); }
};

struct Snes {
    std::vector<uint8_t> rom;
    uint8_t wram[0x20000]{};
    uint8_t sram[2048]{};
    uint8_t vram[0x10000]{};
    uint16_t cgram[256]{};
    uint8_t oam[544]{};
    uint8_t openBus = 0;
    bool sramDirty = false;

    CpuState cpu;
    SpcState spc;
    DmaChannel dma[8]{};

    uint8_t inidisp = 0x80, obsel = 0, bgmode = 0, mosaic = 0;
    uint8_t bgsc[4]{}, bg12nba = 0, bg34nba = 0;
    uint8_t bgofsLatch = 0, mode7Latch = 0, oamLatch = 0, cgramLatch = 0;
    bool cgramHi = false, oamHi = false;
    uint16_t bghofs[4]{}, bgvofs[4]{};
    uint16_t m7hofs = 0, m7vofs = 0;
    uint16_t vramAddr = 0;
    uint16_t vramReadBuffer = 0;
    uint8_t vmain = 0;
    uint16_t oamAddr = 0;
    uint16_t oamReloadAddr = 0;
    bool oamPriorityRotation = false;
    uint8_t cgramAddr = 0;
    uint8_t tm = 0, ts = 0, tmw = 0, tsw = 0;
    uint8_t w12sel = 0, w34sel = 0, wobjsel = 0, wh0 = 0, wh1 = 0, wh2 = 0, wh3 = 0, wbglog = 0, wobjlog = 0;
    uint8_t cgwsel = 0, cgadsub = 0;
    uint8_t setini = 0, coldata = 0;
    uint16_t m7a = 0, m7b = 0, m7c = 0, m7d = 0, m7x = 0, m7y = 0;
    uint8_t m7sel = 0;
    uint16_t fixedColor = 0;
    int32_t mode7MulResult = 0;
    uint8_t mode7MulB = 0;
    uint8_t stat77 = 0, stat78 = 0;

    uint8_t nmitimen = 0, wrmpya = 0, wrmpyb = 0, wrdivb = 0;
    uint16_t wrdiv = 0, mulResult = 0, divQuot = 0, divRem = 0;
    uint16_t htime = 0, vtime = 0;
    uint8_t mdmaen = 0, hdmaen = 0;
    uint8_t memsel = 0;
    uint8_t wrio = 0xFF;
    uint16_t wramAddr = 0;
    bool nmiFlag = false, nmiPending = false, irqFlag = false, vblank = false, hblank = false, joyReady = true;
    uint16_t joy[4]{};          // live host state in SNES bit order
    uint16_t joyAuto[4]{};      // $4218-$421F result latched by auto joypad read
    uint16_t joyLatch[4]{};     // manual $4016/$4017 shift registers
    uint8_t joyStrobe = 0;
    int joyShift[2]{};

    int scanline = 0;
    int lineCpuCycles = 180, lineCpuPos = 0;
    uint16_t hCounter = 0, latchedH = 0, latchedV = 0;
    bool hvLatched = false, ophctHi = false, opvctHi = false;
    uint32_t frame = 0;
    uint32_t joyReads = 0;
    int spcCycleAccum = 0;
    uint32_t fb[256 * 224]{};
    int16_t audio[800 * 2]{};
    int audioSamples = 0;
    uint64_t audioSampleAccum = 0; // v0.5.23 save-state field

    // Runtime profiling switches (do not affect emulated register state).
    bool videoEnabled = true;
    bool audioMixEnabled = true;
    int visibleForcedBlankLines = 0; // v0.5.23 save-state field

    // DSP playback
    int brrOffset[8]{};
    int brrNib[8]{};
    int16_t brrBuf[8][16]{};
    int brrHist[8][2]{};
    uint16_t pitchCnt[8]{};
    int env[8]{};
    bool voiceOn[8]{};
    uint8_t keyOn = 0, keyOff = 0, endFlags = 0;
    uint16_t bghofsLine[4]{}, bgvofsLine[4]{};
};

bool loadRom(Snes& s, const std::string& path);
void resetSnes(Snes& s);
void runFrame(Snes& s);
void setJoy(Snes& s, int player, uint16_t buttons);
uint8_t busRead(Snes& s, uint32_t addr);
void busWrite(Snes& s, uint32_t addr, uint8_t value);
int cpuStep(Snes& s);
void cpuInterrupt(Snes& s, uint16_t vec);
int spcStep(Snes& s);
void renderScanline(Snes& s, int line);
void dspMixFrame(Snes& s);
