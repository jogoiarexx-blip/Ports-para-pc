#!/usr/bin/env python3
"""Extract DKC3 level metadata from a user-provided headerless USA/PT-BR ROM.
Offline development tool only. The native runtime never opens the ROM.
"""
from __future__ import annotations
import argparse
from pathlib import Path

LEVEL_DATA_SNES = 0xFD06AF
FIRST_LEVEL_ID = 0x25
LAST_LEVEL_ID = 0x2B
TIDAL_BREAKABLE_SNES = 0xB3A7CC

NAMES = {
    0x25: 'lakeside-limbo', 0x26: 'kreeping-klasps', 0x27: 'tidal-trouble',
    0x28: 'doorstop-dash', 0x29: 'squeals-on-wheels', 0x2A: 'murky-mill',
    0x2B: 'skiddas-row',
}
POINT_NAMES = ['start','checkpoint','bonus1','bonus2','warp','demo']

def hirom_offset(addr: int) -> int:
    bank=(addr>>16)&0xff; lo=addr&0xffff
    return ((bank & 0x3f)<<16) | lo

def u16(data: bytes, off: int) -> int:
    return data[off] | (data[off+1]<<8)

def parse_entries(data: bytes):
    p=hirom_offset(LEVEL_DATA_SNES)
    out={}
    for level_id in range(FIRST_LEVEL_ID,LAST_LEVEL_ID+1):
        start=p
        level_type=u16(data,p); song=data[p+2]; shared=u16(data,p+3)
        raw_header=data[p:p+15]; p+=15
        points=[]; idx=0
        while data[p] != 0xff:
            flags=data[p]; x=u16(data,p+1); y=u16(data,p+3); p+=5
            kind=POINT_NAMES[idx] if idx<len(POINT_NAMES) else f'point{idx}'
            points.append((kind,idx,flags,x,y)); idx+=1
        p+=1
        connections=[]
        while data[p:p+2] != b'\xff\xff':
            connections.append((data[p+1],data[p])); p+=2
        p+=2
        tail=u16(data,p); p+=2
        out[level_id]={
            'rom_offset':start,'level_type':level_type,'song':song,'shared':shared,
            'raw_header':raw_header,'points':points,'connections':connections,'tail':tail,
        }
    return out

def write_level(path: Path, level_id: int, rec: dict, data: bytes):
    lines=[
        '# Generated offline from input/dkc3_ptbr.sfc. Runtime does not read ROM.',
        'DKC3_LEVEL_META 1',
        f'level_id 0x{level_id:02X}',
        f'name {NAMES.get(level_id,"unknown")}',
        f'rom_offset 0x{rec["rom_offset"]:06X}',
        f'level_type 0x{rec["level_type"]:04X}',
        f'song_id 0x{rec["song"]:02X}',
        f'shared_data 0x{rec["shared"]:04X}',
        'raw_header '+rec['raw_header'].hex(' '),
    ]
    for kind,idx,flags,x,y in rec['points']:
        lines.append(f'point {kind} {idx} 0x{flags:02X} 0x{x:04X} 0x{y:04X}')
    for slot,target in rec['connections']:
        lines.append(f'connection {slot} 0x{target:02X}')
    lines.append(f'tail 0x{rec["tail"]:04X}')
    if level_id==0x27:
        o=hirom_offset(TIDAL_BREAKABLE_SNES)
        vram=u16(data,o); tm=u16(data,o+2); count=data[o+4]; tile=data[o+5]
        lines += [f'breakable_vram_word 0x{vram:04X}',f'breakable_tilemap_offset 0x{tm:04X}',f'breakable_count {count}',f'breakable_tile_id 0x{tile:02X}']
    path.write_text('\n'.join(lines)+'\n',encoding='utf-8')

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('rom',type=Path)
    ap.add_argument('outdir',type=Path)
    ap.add_argument('--level',type=lambda s:int(s,0),default=None)
    a=ap.parse_args()
    data=a.rom.read_bytes()
    if len(data) not in (0x400000,0x400200):
        raise SystemExit(f'ROM size inesperado: {len(data)} bytes')
    if len(data)==0x400200:
        data=data[0x200:]
    entries=parse_entries(data); a.outdir.mkdir(parents=True,exist_ok=True)
    ids=[a.level] if a.level is not None else sorted(entries)
    for level_id in ids:
        if level_id not in entries: raise SystemExit(f'level id fora do intervalo suportado: 0x{level_id:02X}')
        write_level(a.outdir/f'{NAMES.get(level_id,f"level-{level_id:02x}")}.original.txt',level_id,entries[level_id],data)
        r=entries[level_id]
        print(f'META_OK id=0x{level_id:02X} off=0x{r["rom_offset"]:06X} points={len(r["points"])} connections={len(r["connections"])}')
if __name__=='__main__': main()
