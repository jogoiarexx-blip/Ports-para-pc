#include "LegacySnesState.h"
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <vector>
namespace fs=std::filesystem;
#pragma pack(push,1)
struct DevStateHeader{char magic[8];uint32_t version,payloadSize;uint64_t romSize,romHash;};
#pragma pack(pop)
static bool loadState(const fs::path&p,Snes&s){
  std::ifstream in(p,std::ios::binary);DevStateHeader h{};in.read((char*)&h,sizeof h);
  const char magic[8]={'D','K','C','3','S','T','0','1'};if(!in||std::memcmp(h.magic,magic,8)||h.version!=2)return false;
  constexpr size_t oldPayload=498832;const size_t currentPayload=sizeof(Snes)-offsetof(Snes,wram);
  std::vector<uint8_t>b(h.payloadSize);in.read((char*)b.data(),(std::streamsize)b.size());if(!in)return false;auto*dst=(uint8_t*)&s.wram[0];
  if(b.size()==currentPayload){std::memcpy(dst,b.data(),b.size());return true;}
  if(b.size()==oldPayload){std::memset(dst,0,currentPayload);constexpr size_t oldVideo=498368,oldBrr=498372,newVideo=498376,newBrr=498384;std::memcpy(dst,b.data(),oldVideo);std::memcpy(dst+newVideo,b.data()+oldVideo,oldBrr-oldVideo);std::memcpy(dst+newBrr,b.data()+oldBrr,b.size()-oldBrr);return true;}
  return false;
}
static void spriteSizes(uint8_t obsel,int&small,int&large){static constexpr int s[8]={8,8,8,16,16,32,16,16},l[8]={16,32,64,32,64,64,32,32};const int mode=(obsel>>5)&7;small=s[mode];large=l[mode];}
int main(int argc,char**argv){
  if(argc<2){std::cerr<<"usage: dkc3_oam_audit STATE [OUT_CSV]\n";return 2;}Snes s;if(!loadState(argv[1],s)){std::cerr<<"state open/layout failed\n";return 3;}
  std::ofstream file;std::ostream*out=&std::cout;if(argc>=3){file.open(argv[2]);if(!file)return 4;out=&file;}
  int small=0,large=0;spriteSizes(s.obsel,small,large);*out<<"slot,x,y,tile,attr,size,palette,priority,hflip,vflip,nametable\n";int visible=0;
  for(int slot=0;slot<128;++slot){const int o=slot*4;int x=s.oam[o],y=s.oam[o+1],tile=s.oam[o+2],attr=s.oam[o+3];const uint8_t hi=s.oam[512+slot/4];const int shift=(slot&3)*2;x|=((hi>>shift)&1)<<8;if(x>=256)x-=512;const int size=((hi>>(shift+1))&1)?large:small;if(x<=-size||x>=256||y>=224)continue;
    *out<<slot<<','<<x<<','<<y<<','<<tile<<','<<attr<<','<<size<<','<<((attr>>1)&7)<<','<<((attr>>4)&3)<<','<<((attr&0x40)?1:0)<<','<<((attr&0x80)?1:0)<<','<<(attr&1)<<'\n';++visible;
  }
  std::cerr<<"OAM_AUDIT_OK frame="<<s.frame<<" visible="<<visible<<" obsel="<<(int)s.obsel<<" small="<<small<<" large="<<large<<"\n";return 0;
}
