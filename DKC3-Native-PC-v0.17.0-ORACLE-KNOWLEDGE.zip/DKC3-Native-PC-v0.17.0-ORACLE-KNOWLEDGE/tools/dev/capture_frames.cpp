// Ferramenta de desenvolvimento (v0.8.0): roda uma fase de forma headless com input roteirizado e grava BMPs.
// Uso: dkc3_native_frames <fase> <pasta-saida> [quadros=600] [intervalo=60] [debug=0]
// Serve para regressao visual sem abrir a janela (ex.: conferir paginas de Tidal, HUD, crossfade).
#include "core/Bmp.h"
#include "core/LevelSession.h"
#include <cstdio>
#include <cstdlib>
#include <filesystem>
#include <string>
#include <vector>
int main(int argc, char** argv) {
  using namespace dkc3;
  if (argc < 3) { std::fprintf(stderr, "uso: %s <fase> <pasta-saida> [quadros] [intervalo] [debug]\n", argv[0]); return 1; }
  const std::string level = argv[1], outDir = argv[2];
  const int frames = argc > 3 ? std::atoi(argv[3]) : 600, every = argc > 4 ? std::max(1, std::atoi(argv[4])) : 60;
  GameSession s;
  if (!s.init("assets/levels/levels.index", level)) { std::fprintf(stderr, "falha ao carregar fase '%s'\n", level.c_str()); return 2; }
  if (argc > 5 && std::atoi(argv[5])) s.game().setDebugOverlay(true);
  std::filesystem::create_directories(outDir);
  std::vector<uint32_t> fb(256 * 224);
  InputState in{}; in.right = true; in.run = true;
  int written = 0;
  for (int i = 0; i <= frames; ++i) {
    if (i % every == 0) {
      s.render(fb.data(), 256, 224);
      char name[256]; std::snprintf(name, sizeof name, "%s/%s_%05d.bmp", outDir.c_str(), level.c_str(), i);
      if (!saveBmp32(name, fb.data(), 256, 224)) { std::fprintf(stderr, "falha ao gravar %s\n", name); return 3; }
      ++written;
    }
    s.step(in, 1.0f / 60.0f);
  }
  std::printf("FRAMES_OK level=%s written=%d page=%zu/%zu\n", s.currentLevel().c_str(), written, s.game().activeScenePage() + 1, s.game().scenePageCount());
  return 0;
}
