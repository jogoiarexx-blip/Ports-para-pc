// Ferramenta de desenvolvimento (v0.9.0): renderiza cada efeito sonoro para WAV e imprime metricas
// (duracao, pico, RMS, frequencia dominante por cruzamentos de zero) para conferir o som sem ouvir.
// Uso: dkc3_native_sfx <pasta-saida>
#include "core/Audio.h"
#include <cmath>
#include <cstdio>
#include <filesystem>
#include <string>
#include <vector>
using namespace dkc3;
static void writeWav(const std::string& path, const std::vector<int16_t>& pcm) {
  FILE* f = std::fopen(path.c_str(), "wb"); if (!f) return;
  const uint32_t bytes = (uint32_t)pcm.size() * 2, rate = SfxMixer::kRate, br = rate * 2, riff = 36 + bytes; const uint16_t fmt = 1, ch = 1, ba = 2, bits = 16; const uint32_t sixteen = 16;
  std::fwrite("RIFF", 1, 4, f); std::fwrite(&riff, 4, 1, f); std::fwrite("WAVEfmt ", 1, 8, f); std::fwrite(&sixteen, 4, 1, f);
  std::fwrite(&fmt, 2, 1, f); std::fwrite(&ch, 2, 1, f); std::fwrite(&rate, 4, 1, f); std::fwrite(&br, 4, 1, f); std::fwrite(&ba, 2, 1, f); std::fwrite(&bits, 2, 1, f);
  std::fwrite("data", 1, 4, f); std::fwrite(&bytes, 4, 1, f); std::fwrite(pcm.data(), 2, pcm.size(), f); std::fclose(f);
}
int main(int argc, char** argv) {
  const std::string dir = argc > 1 ? argv[1] : "sfx_out";
  std::filesystem::create_directories(dir);
  for (int i = 0; i < (int)Sfx::Count; ++i) {
    SfxMixer m; m.setVolume(1.0f); m.trigger((Sfx)i);
    std::vector<int16_t> pcm((size_t)(SfxMixer::kRate * (sfxDuration((Sfx)i) + 0.1f)));
    m.mix(pcm.data(), (int)pcm.size());
    int peak = 0; double sum = 0; int zc = 0; int last = 0, active = 0;
    for (size_t k = 0; k < pcm.size(); ++k) { int v = pcm[k]; peak = std::max(peak, std::abs(v)); sum += (double)v * v; if (v) { active = (int)k; if ((v > 0) != (last > 0) && last) ++zc; last = v; } }
    const double dur = (double)active / SfxMixer::kRate;
    std::printf("%-11s dur=%.3fs peak=%5d rms=%6.0f zc_freq=%6.0fHz voices_after=%d\n", sfxName((Sfx)i), dur, peak, std::sqrt(sum / pcm.size()), dur > 0 ? zc / 2.0 / dur : 0.0, m.activeVoices());
    writeWav(dir + "/" + sfxName((Sfx)i) + ".wav", pcm);
  }
  return 0;
}
