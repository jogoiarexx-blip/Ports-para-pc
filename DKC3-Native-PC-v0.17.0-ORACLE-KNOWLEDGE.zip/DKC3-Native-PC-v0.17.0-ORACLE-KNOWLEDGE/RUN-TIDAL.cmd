@echo off
cd /d "%~dp0"
if exist DKC3NativePC.exe (DKC3NativePC.exe --level tidal-trouble) else if exist bin\DKC3NativePC.exe (cd bin && DKC3NativePC.exe --level tidal-trouble) else (echo Execute BUILD-WINDOWS.cmd primeiro.& pause)
