DKC3 NATIVE PC v0.17.0 - ORACLE KNOWLEDGE PASS

Esta e a linha de PORT NATIVO de PC. Nao e recomp e nao e emulador.



NOVO v0.17.0 - ORACLE KNOWLEDGE PASS
- O Oracle agora aceita uma base de conhecimento (`--knowledge`) e reconhece automaticamente grupos ja confirmados.
- Tidal inclui referencias confirmadas de Kiddy nadando, Sneek, letra K, DK Barrel e elementos do HUD. Nas 3 capturas atuais, 12/12 grupos ficam classificados e 0 ficam como falso "novo inimigo".
- Novo `known-detections.csv`: identidade, tipo, score e referencia usada.
- Novo `entity-tracks.csv`: associacao temporal um-para-um entre capturas adjacentes; identidades conhecidas nunca sao misturadas com grupos desconhecidos apenas por semelhanca visual.
- Novo `AUTO-NEW-CANDIDATES.md`: mostra primeiro apenas o que realmente ainda e desconhecido.
- `AUTO-PROCESS-LEVEL.cmd FASE` generaliza o pipeline para qualquer fase; Tidal e Skidda usam a mesma infraestrutura.
- `dkc3_update_level_pages` atualiza automaticamente `native_scene_page`, largura da fase/camera e zonas globais de agua/corrente quando entram novas paginas.
- Simulacao com page3: Tidal foi atualizado de 512 para 608 px automaticamente, sem edicao manual do .level.
- `dkc3_make_level_scaffold` cria uma fase bootstrap automaticamente a partir de metadata original + primeiras capturas. Quando Skidda tiver sua primeira captura, o pipeline ja pode criar `skiddas-row.level` e registrar a fase no catalogo.
- `AUTO-PROCESS-SKIDDAS.cmd` esta pronto para usar as capturas de Skidda assim que elas existirem.
- Runtime/gameplay v0.15-v0.16 permanece intacto; a aceleracao continua offline, sem ROM no executavel final.

NOVO v0.16.0 - AUTOMATION ORACLE PASS
- O runtime C++ nativo foi preservado; este passe ataca o gargalo de conversao manual.
- Novo `dkc3_oracle_batch`: recebe varios save-states de uma vez e gera frame BMP, OAM CSV, grupos OAM, previews BMP, candidatos .nspr, hashes de pagina, links de entidades e relatorios de WRAM/PPU.
- O agrupador reconhece familias repetidas entre capturas por paleta/prioridade/tiles/geometria; nas 3 capturas atuais de Tidal encontrou automaticamente as poses de Kiddy, Sneek e letra K.
- `AUTO-ANALYZE-STATES.cmd` processa qualquer lote futuro de .state; `AUTO-ANALYZE-TIDAL.cmd` usa todas as capturas Tidal existentes.
- `IMPORT-TIDAL-PAGES.cmd` deixou de ter 3 paginas fixas: todo `tidal-trouble-pageN.state` novo e importado automaticamente para `native/pages/pageN`.
- `AUTO-PROCESS-TIDAL-CAPTURES.cmd` executa importacao de paginas + analise Oracle em uma unica passada.
- Novo `dkc3_make_capture_rom` em C++ substitui o helper Python de ROM temporaria. O resultado de Skidda 0x2B foi validado byte-a-byte contra o script antigo.
- `AUTO-PREPARE-CAPTURE.cmd` prepara uma fase por ID e `AUTO-PREPARE-EARLY-CAPTURES.cmd` gera de uma vez as 7 ROMs temporarias 0x25..0x2B.
- `dkc3_import_level_metadata` tambem foi portado para C++; `IMPORT-ROM-LEVEL-METADATA.cmd` nao depende mais de Python e produz arquivos byte-a-byte equivalentes ao importador antigo.
- `docs/oracle-auto/tidal/` ja contem a analise automatica das tres capturas atuais como exemplo/linha de base.
- Nada do Oracle, ROM ou save-state entra no executavel portatil; toda a automacao continua exclusivamente offline.

NOVO v0.15.0 - TIDAL SNEEK PASS
- O grupo OAM roxo que antes estava em duvida foi confirmado pelo framebuffer de page2: e um Sneek real sobre o deque de Tidal.
- Sneek foi extraido dos slots 14-24 de tidal-trouble-page2.state e convertido para .nspr; o runtime nao le o save-state.
- O importador dkc3_import_oam_group ganhou transformacao opcional `flip_x` para normalizar sprites capturados virados.
- sneek.nspr fica com base voltada para a direita e o sistema generico de inimigos espelha de acordo com a patrulha.
- Tidal agora instancia `sneek_deck` em x=318,y=138, patrulhando x=302..356 a 24 px/s, com hitbox 44x22.
- Colisao, dano, stomp/ataque e overlay F4 usam o sistema nativo de inimigos ja existente.
- Nao foi criada animacao falsa: as duas capturas OAM disponiveis do Sneek sao visualmente identicas, entao este passe usa um unico frame autentico.
- Dixie ainda aguarda captura real de natacao; o sprite do Sneek nao foi reutilizado como personagem.

NOVO v0.14.0 - KIDDY SWIM PASS
- Kiddy agora possui animacao de natacao autentica em Tidal Trouble, em vez de reutilizar os frames de salto.
- Tres poses reais foram extraidas da OAM dos snapshots existentes e convertidas para .nspr.
- As poses usam ancora normalizada 27,12 para evitar jitter durante a bracada.
- A animacao 0 -> 1 -> 2 -> 1 funciona com Kiddy ativo e tambem como parceiro de Dixie.
- IMPORT-TIDAL-ENTITIES.cmd agora regenera DK Barrel, letra K e os sprites/animacao de nado do Kiddy.
- Um grupo OAM semelhante a Sneek foi deliberadamente deixado fora de Tidal porque sua origem nao e segura no metodo de captura usado.
- main_headless foi atualizado para a velocidade/correnteza atual e volta a validar chegada a terceira pagina.
- Release, build estrito e ASan/UBSan passam.
- Dixie ainda aguarda capturas autenticas de natacao; Tidal continua com 3 paginas reais neste pacote.

NOVO v0.13.0 - KONG LETTER PASS
- A moeda provisoria de Tidal foi removida daquela posicao e substituida pela letra K autentica do jogo original.
- Dois frames reais do giro da K foram extraidos das OAM de tidal-trouble-page1.state (slots 27-31) e page2.state (slots 25-28).
- Novo comando `kong_letter LETRA X Y ANIM W H`, reutilizavel para K/O/N/G quando novas capturas existirem.
- O runtime agora acompanha mascara/progresso K-O-N-G por fase; coleta unica, animacao, SFX e toast `LETRA K`.
- HUD de Tidal mostra K O N G; letras coletadas ficam douradas e as ausentes ficam cinza.
- F4 mostra hitbox das letras K-O-N-G.
- IMPORT-TIDAL-ENTITIES.cmd agora regenera DK Barrel + os dois frames da K + a animacao .nanim.
- Nova ferramenta offline dkc3_dump_state_frame exporta o framebuffer armazenado no save-state para BMP, ajudando a identificar objetos antes de importa-los.
- Build Release, build estrito e ASan/UBSan passam.
- O/N/G e inimigos autenticos ainda dependem de capturas apropriadas; nada foi inventado para preencher essas lacunas.

NOVO v0.12.0 - TIDAL ENTITIES PASS
- Primeiro objeto interativo autentico de Tidal extraido diretamente da OAM de uma captura offline: DK Barrel (slots 8-20 da abertura).
- O sprite foi convertido para assets/levels/tidal-trouble/native/entities/dk_barrel.nspr (30x38); o runtime nao le o save-state.
- Novo comando de fase `team_barrel`: quando o jogador esta SOLO e toca no barril, o parceiro volta, o barril e consumido e aparece "DUPLA RESTAURADA".
- Novo importador offline dkc3_import_oam_group e novo IMPORT-TIDAL-ENTITIES.cmd para reproduzir a extracao do barril.
- F4 tambem mostra a hitbox do DK Barrel.
- Testes cobrem parser, sprite, restauracao da dupla, consumo unico e evento de som.
- Build estrito e ASan/UBSan passam.
- O sistema completo de pegar/carregar/arremessar barris ainda nao existe; por enquanto a interacao e por contato.
- Skidda's Row continua fora do catalogo jogavel ate existir snapshot autentico.

NOVO v0.11.0 - TIDAL CURRENT PASS
- Tidal Trouble agora tem correnteza nativa: a agua atual aplica drift de -32 px/s e torna o nado para a direita mais dificil, como a caracteristica da fase original.
- Novo comando `water_current` permite correntes por zona e vetor, reutilizavel em outras fases.
- Streaming ganhou histerese maior enquanto o jogador esta na corrente, evitando troca/crossfade de pagina causada por pequena deriva da camera.
- F4 desenha as zonas de corrente e informa quando o jogador esta sob corrente.
- Novo dkc3_oam_audit (offline) gera CSV dos sprites OAM visiveis das capturas, preparando a extracao de inimigos/objetos reais de Tidal.
- PREPARE-SKIDDAS-CAPTURE.cmd + dkc3_make_capture_rom preparam a captura offline da terceira fase, Skidda's Row (0x2B), sem Python.
- Importadores offline tambem passam no build estrito sem warnings.
- Skidda's Row ainda NAO esta jogavel: faltam snapshots autenticos; nao foi criado cenario falso para esconder essa pendencia.

NOVO v0.10.0 - NATIVE STREAMING PASS
- Streaming real das paginas .nscene: a fase nao precisa mais manter todas as paginas convertidas na memoria.
- Cache deslizante: pagina atual + anterior/proxima; paginas distantes sao descarregadas. Em um teste de 5 paginas, no maximo 3 ficam residentes.
- Crossfade continua funcionando porque a pagina anterior e preservada enquanto a transicao termina.
- A pagina inicial agora e escolhida pela posicao real da camera/spawn, preparando checkpoints e entradas futuras no meio da fase.
- Renderer reaproveita buffers de main/subscreen e do crossfade, reduzindo alocacoes de heap por quadro.
- F7 alterna o filtro de escala do Windows: PIXEL NITIDO (padrao) / FILTRO SUAVE. F6 continua controlando escala inteira.
- BUILD-WINDOWS.cmd agora recria bin/ do zero, valida que o runtime portatil nao contem ROM/save-state/ferramentas e gera
  DKC3-Native-PC-v0.10.0-Portable-Windows-x64.zip automaticamente.
- F4 mostra tambem CACHE N, facilitando validar quantas paginas graficas estao residentes.

IMPORTANTE: este passe melhora a arquitetura e o desempenho, mas NAO inventa dados que ainda nao foram capturados do jogo original.
Tidal Trouble continua com as 3 paginas autenticas existentes; novas paginas ainda exigem novas capturas offline.

NOVO v0.9.0 - SOUND PASS
- Efeitos sonoros nativos, 100% sintetizados em codigo (sem samples e sem ROM): pulo, pouso, moeda, pisao,
  rolamento, inimigo derrotado, dano, checkpoint, alavanca, trocar Kong, porta, porta trancada e splash na agua.
- Mixer proprio (22050 Hz, mono, 16-bit, ate 12 vozes, limitador suave) + saida waveOut no Windows.
- M = mudo | + / - = volume. O som da porta nao se perde na troca de fase.
- Ferramenta dkc3_native_sfx: exporta cada efeito em WAV e imprime duracao/pico/RMS/frequencia.
- Aviso: a trilha musical original continua fora do escopo (depende do oracle offline / SPC); isto sao so efeitos.

v0.8.0 - QUALITY PASS
- Fisica com "feel" de plataforma: pulo por borda (segurar nao repete), coyote time (0,09 s),
  buffer de pulo (0,10 s) e altura variavel (soltar cedo da um pulo curto; segurar da o pulo cheio).
- Paredes invisiveis nas bordas horizontais: antes era possivel nadar para fora de Tidal e cair do mapa.
- Transicao suave (crossfade de 0,3 s) entre as paginas de cena de Tidal + histerese de 6 px ao voltar,
  sem "pop" nem piscar quando a camera oscila sobre a fronteira de pagina.
- HUD nativo (fonte bitmap 5x7 propria): Kong ativo, DUPLA/SOLO, moedas, cartao de titulo da fase e avisos
  (CHECKPOINT, PORTAO ABERTO, PORTA TRANCADA).
- Overlay de debug (F4): solidos, agua, portas, checkpoints, zonas de agarrar, alavancas, portoes, inimigos,
  hitbox do jogador e do ataque, camera e pagina atual.
- Launcher Win32 reescrito: sem flicker, tela cheia (F11 / Alt+Enter), escala inteira (F6), pausa (P / Start),
  pausa automatica ao perder o foco, reiniciar fase (R / Back), print em BMP (F2 -> screenshots/), ajuda (F1),
  fase inicial por linha de comando: DKC3NativePC.exe --level tidal-trouble (veja RUN-TIDAL.cmd).
- Nova ferramenta dkc3_native_frames: roda uma fase headless e grava BMPs (regressao visual sem janela).
- Suite de testes ampliada (fisica, limites, crossfade, HUD, toasts, restart, BMP) e verificada com ASan/UBSan.

LIMITE CONHECIDO (inalterado): Tidal Trouble continua com 3 paginas capturadas. Novas paginas/entidades
dependem de novas capturas do oracle offline (o oracle e os states novos nao fazem parte deste pacote).

RUNTIME
- C++ nativo compilado diretamente para PC.
- Win32/GDI nesta etapa, XInput + teclado, timestep fixo de 60 Hz.
- Movimento, gravidade, natacao, colisao, camera, equipe, combate e entidades proprios.
- Sprites em .nspr, animacoes em .nanim, cenarios em .ntiles/.nmap/.npal/.nscene.
- Catalogo de fases em assets/levels/levels.index.
- O executavel final NAO abre .sfc/.smc, save-state nem ferramentas do oracle.
- Nao interpreta 65C816 e nao possui PPU/APU/SPC700 emulados ou snesrecomp.

v0.7.11 (anterior)
- Tidal Trouble deixou de usar o fundo bootstrap.
- A abertura original foi capturada offline no jogo original e convertida para:
  * BG1/BG2/BG3 em .ntiles/.nmap
  * paleta em palette.npal
  * cena em tidal-original.nscene
- Nada disso e screenshot no runtime: o renderer monta a cena por tiles/camadas.
- O renderer nativo ganhou suporte a main screen/subscreen e color math basico:
  * TM / TS
  * CGWSEL / CGADSUB
  * add/subtract
  * half-color
  * fixed color
  * brightness
- Em Tidal, BG1 original fica no subscreen e BG2/BG3 no main screen; a composicao nativa recupera o ceu e a agua que antes apareciam pretos.
- Novo dkc3_import_scene_state aceita o checkpoint v0.5.23 de Tidal e tambem preserva compatibilidade com os checkpoints antigos de Doorstop.
- IMPORT-TIDAL-PAGES.cmd regenera as 3 paginas de Tidal no Windows.

ESCOPO ATUAL DE TIDAL
- A pagina/abertura mostrada na v0.7.11 usa grafico original estruturado e color math nativo.
- A fase INTEIRA ainda nao esta portada: DKC3 faz tile streaming conforme a camera avanca, entao as paginas seguintes precisam ser capturadas/convertidas nos proximos passes.
- Colisoes, inimigos e objetos de Tidal ainda sao simplificados nesta etapa; o foco deste passe foi substituir o visual bootstrap por dados autenticos.

DOORSTOP DASH
- Continua com Dixie/Kiddy, animacoes reais de corrida/salto/queda/cartwheel/roll, troca de personagem, dano/i-frames, stomp, ataque lateral, inimigos, coletavel, alavanca, portao, checkpoint e transicao de fase.
- Seus importadores antigos continuam funcionando; a compatibilidade de save-state foi mantida.

ROM E FERRAMENTAS OFFLINE
- input/dkc3_ptbr.sfc e a ROM PT-BR modificada usada como FONTE offline.
- tools/offline_import/tidal-trouble-opening.state e uma captura de desenvolvimento sem ROM embutida.
- dkc3_make_capture_rom gera apenas ROMs TEMPORARIAS de captura; nenhuma delas faz parte do runtime/bin.
- BUILD-WINDOWS.cmd nao copia input/ nem tools/ para bin/.
- O executavel final usa somente os assets convertidos.

CONTROLES
Teclado:
- A/D ou setas: mover
- Z ou Space: pular / impulso de nado
- W/seta para cima: subir na agua, porta ou agarrar alavanca
- S/seta para baixo: descer na agua / soltar alavanca
- Shift: correr sem atacar
- X: correr + cartwheel/roll
- Q: trocar Dixie/Kiddy
- ESC: sair
- P: pausa | R / F5: reiniciar fase | F1: ajuda | F2: print (BMP) | F3: HUD | F4: debug
- F6: escala inteira | F7: filtro de escala | F11 ou Alt+Enter: tela cheia
- Segure o botao de pulo para o pulo cheio; toque rapido = pulo curto

Controle XInput:
- A: pular / impulso de nado
- X: correr + cartwheel/roll
- RB: correr sem atacar
- Y: trocar Dixie/Kiddy
- direcional/analogico: mover/nadar
- Start: pausa | Back: reiniciar fase

BUILD WINDOWS
Execute BUILD-WINDOWS.cmd. O build roda os testes e copia somente o runtime e assets para bin/.

REIMPORTAR
- IMPORT-DOORSTOP-ASSETS.cmd: regenera os assets autenticos ja capturados de Doorstop.
- IMPORT-ROM-LEVEL-METADATA.cmd: regenera metadados originais de fases a partir da ROM.
- IMPORT-TIDAL-PAGES.cmd: regenera BG1/BG2/BG3/paleta/cena de todas as capturas Tidal encontradas.
- IMPORT-TIDAL-ENTITIES.cmd: regenera DK Barrel, letra K e as tres poses autenticas de natacao do Kiddy a partir das OAM capturadas.
- DUMP-TIDAL-STATE-FRAMES.cmd: exporta os framebuffers salvos dos states para BMP para inspecao offline.


TIDAL (desde v0.7.11)
---------------------
Tidal Trouble usa as paginas graficas originais ja capturadas e faz streaming nativo por camera. Use AUTO-PROCESS-TIDAL-CAPTURES.cmd para importar/registrar novas paginas e rodar o Oracle. A fase completa ainda esta em progresso.
