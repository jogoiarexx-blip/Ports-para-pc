@echo off
setlocal
cd /d "%~dp0"
where cmake >nul 2>nul || (echo ERRO: CMake nao encontrado.& pause & exit /b 1)
cmake -S . -B build-tools -G "Visual Studio 17 2022" -A x64 -DDKC3_BUILD_OFFLINE_IMPORTER=ON || goto :err
cmake --build build-tools --config Release --target dkc3_oam_audit || goto :err
if not exist docs\oam-audit mkdir docs\oam-audit
for %%S in (tidal-trouble-opening tidal-trouble-page1 tidal-trouble-page2) do (
  build-tools\Release\dkc3_oam_audit.exe "tools\offline_import\%%S.state" "docs\oam-audit\%%S.csv" || goto :err
)
echo OK: docs\oam-audit\*.csv
pause
exit /b 0
:err
echo FALHA NO OAM AUDIT.
pause
exit /b 1
