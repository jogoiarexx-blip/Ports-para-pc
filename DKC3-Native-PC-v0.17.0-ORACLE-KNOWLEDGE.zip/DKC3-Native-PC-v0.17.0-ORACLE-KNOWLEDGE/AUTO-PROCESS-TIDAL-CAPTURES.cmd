@echo off
setlocal
set DKC3_NOPAUSE=1
call "%~dp0AUTO-PROCESS-LEVEL.cmd" tidal-trouble
set RC=%errorlevel%
if not "%RC%"=="0" exit /b %RC%
echo.
echo TIDAL: base conhecida filtra Kiddy, Sneek, letra K, DK Barrel e HUD.
echo Revise primeiro docs\oracle-auto\tidal-trouble\AUTO-NEW-CANDIDATES.md
exit /b 0
