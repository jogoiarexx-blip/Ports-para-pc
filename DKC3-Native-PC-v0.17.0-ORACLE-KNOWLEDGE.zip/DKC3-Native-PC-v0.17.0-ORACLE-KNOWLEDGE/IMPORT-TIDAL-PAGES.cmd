@echo off
setlocal EnableDelayedExpansion
cd /d "%~dp0"
where cmake >nul 2>nul || (echo ERRO: CMake nao encontrado.& pause & exit /b 1)
cmake -S . -B build-tools -G "Visual Studio 17 2022" -A x64 -DDKC3_BUILD_OFFLINE_IMPORTER=ON || goto :err
cmake --build build-tools --config Release --target dkc3_import_scene_state || goto :err
set ROOT=assets\levels\tidal-trouble\native\pages
if not exist "%ROOT%" mkdir "%ROOT%"
set COUNT=0
if exist tools\offline_import\tidal-trouble-opening.state (
  if exist "%ROOT%\page0" rmdir /S /Q "%ROOT%\page0"
  build-tools\Release\dkc3_import_scene_state.exe tools\offline_import\tidal-trouble-opening.state "%ROOT%\page0" tidal-page0 || goto :err
  set /a COUNT+=1
)
for %%F in (tools\offline_import\tidal-trouble-page*.state) do (
  set N=%%~nF
  set N=!N:tidal-trouble-page=!
  if exist "%ROOT%\page!N!" rmdir /S /Q "%ROOT%\page!N!"
  echo Importando Tidal page !N! de %%~nxF...
  build-tools\Release\dkc3_import_scene_state.exe "%%F" "%ROOT%\page!N!" tidal-page!N! || goto :err
  set /a COUNT+=1
)
if !COUNT! EQU 0 (
  echo ERRO: nenhuma captura de Tidal encontrada.
  if not defined DKC3_NOPAUSE pause
  exit /b 2
)
echo.
echo TIDAL_PAGE_IMPORT_OK pages=!COUNT!
echo Novos arquivos tidal-trouble-pageN.state serao incluidos automaticamente.
if not defined DKC3_NOPAUSE pause
exit /b 0
:err
echo FALHA AO IMPORTAR PAGINAS DE TIDAL.
if not defined DKC3_NOPAUSE pause
exit /b 1
