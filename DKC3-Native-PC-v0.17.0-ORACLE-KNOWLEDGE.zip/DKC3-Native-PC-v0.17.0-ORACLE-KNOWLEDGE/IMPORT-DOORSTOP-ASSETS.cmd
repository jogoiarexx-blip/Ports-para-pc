@echo off
setlocal
cd /d "%~dp0"
where cmake >nul 2>nul || (echo ERRO: CMake nao encontrado.& pause & exit /b 1)
cmake -S . -B build-import -G "Visual Studio 17 2022" -A x64 -DDKC3_BUILD_OFFLINE_IMPORTER=ON || goto :err
cmake --build build-import --config Release --target dkc3_import_doorstop dkc3_import_pose || goto :err
if not exist assets\levels\doorstop\native mkdir assets\levels\doorstop\native
build-import\Release\dkc3_import_doorstop.exe ^
 tools\offline_import\doorstop-prelever.state ^
 assets\levels\doorstop\native ^
 tools\offline_import\lever3-hanging.state ^
 tools\offline_import\next-lever.state || goto :err

set SPR=assets\levels\doorstop\native\sprites
for %%F in (4 8 12 16 20 24) do (
  build-import\Release\dkc3_import_pose.exe tools\offline_import\anim_states\run_%%F.state 0x23 %SPR%\dixie_run_%%F.tmp.nspr 16 || goto :err
  build-import\Release\dkc3_import_pose.exe tools\offline_import\anim_states\run_%%F.state 0x25 %SPR%\kiddy_run_%%F.tmp.nspr 27 || goto :err
)
move /Y %SPR%\dixie_run_4.tmp.nspr %SPR%\dixie_run_0.nspr >nul
move /Y %SPR%\dixie_run_8.tmp.nspr %SPR%\dixie_run_1.nspr >nul
move /Y %SPR%\dixie_run_12.tmp.nspr %SPR%\dixie_run_2.nspr >nul
move /Y %SPR%\dixie_run_16.tmp.nspr %SPR%\dixie_run_3.nspr >nul
move /Y %SPR%\dixie_run_20.tmp.nspr %SPR%\dixie_run_4.nspr >nul
move /Y %SPR%\dixie_run_24.tmp.nspr %SPR%\dixie_run_5.nspr >nul
move /Y %SPR%\kiddy_run_4.tmp.nspr %SPR%\kiddy_run_0.nspr >nul
move /Y %SPR%\kiddy_run_8.tmp.nspr %SPR%\kiddy_run_1.nspr >nul
move /Y %SPR%\kiddy_run_12.tmp.nspr %SPR%\kiddy_run_2.nspr >nul
move /Y %SPR%\kiddy_run_16.tmp.nspr %SPR%\kiddy_run_3.nspr >nul
move /Y %SPR%\kiddy_run_20.tmp.nspr %SPR%\kiddy_run_4.nspr >nul
move /Y %SPR%\kiddy_run_24.tmp.nspr %SPR%\kiddy_run_5.nspr >nul

for %%F in (4 8 12 16 20 24 28 32) do (
  build-import\Release\dkc3_import_pose.exe tools\offline_import\anim_states\jump_%%F.state 0x23 %SPR%\dixie_jump_%%F.nspr 16 || goto :err
  build-import\Release\dkc3_import_pose.exe tools\offline_import\anim_states\jump_%%F.state 0x25 %SPR%\kiddy_jump_%%F.nspr 27 || goto :err
)
for %%F in (36 40 48) do (
  build-import\Release\dkc3_import_pose.exe tools\offline_import\anim_states\jump_%%F.state 0x23 %SPR%\dixie_fall_%%F.nspr 16 || goto :err
  build-import\Release\dkc3_import_pose.exe tools\offline_import\anim_states\jump_%%F.state 0x25 %SPR%\kiddy_fall_%%F.nspr 27 || goto :err
)

rem Cartwheel/roll reais capturados offline; a ROM nunca e lida pelo runtime do jogo.
for %%F in (2 4 6 8 10 12 14 16 18 20 24 28 32) do (
  build-import\Release\dkc3_import_pose.exe tools\offline_import\attack_states\dixie\roll_%%F.state 0x23 %SPR%\dixie_roll_%%F.nspr 16 || goto :err
)
for %%F in (102 104 108 110 112 114 116 118 120 124 128 132) do (
  build-import\Release\dkc3_import_pose.exe tools\offline_import\attack_states\kiddy\roll_%%F.state 0x25 %SPR%\kiddy_roll_%%F.nspr 27 || goto :err
)
echo.
echo OK: cenario + sprites + corrida/salto/cartwheel/roll reais regenerados offline.
pause
exit /b 0
:err
echo.
echo FALHA NA IMPORTACAO OFFLINE.
pause
exit /b 1
