#include "PathEncoding.hpp"
#include "CompatibilityAnalyzer.hpp"
#include "TextDatabase.hpp"
#include "LevelParser.hpp"
#include "CharacterParser.hpp"
#include "SafePath.hpp"
#include <algorithm>
#include <cctype>
#include <cmath>
#include <fstream>
#include <functional>
#include <map>
#include <regex>
#include <set>
#include <sstream>

namespace {
std::string lower(std::string s){std::transform(s.begin(),s.end(),s.begin(),[](unsigned char c){return static_cast<char>(std::tolower(c));});return s;}
bool textLike(const std::filesystem::path&p){auto e=lower(PathEncoding::utf8(p.extension()));return e==".txt"||e==".c"||e==".h"||e==".cfg";}
// PAKs may bundle documentation and gettext catalogues inside data/. They are
// not OpenBOR command streams, even though they happen to use a .txt suffix.
bool ancillaryText(const std::filesystem::path& p){
 auto name=lower(PathEncoding::utf8(p.filename()));
 return name=="#translation#.txt" || name=="translation.txt" || name.rfind("nota",0)==0 ||
        name.rfind("readme",0)==0 || name.rfind("leame",0)==0 ||
        (name.size()<=14 && name[0]=='l' && name.find("ame.txt")!=std::string::npos);
}

std::string sanitizeScriptCalls(const std::string& src){
 std::string out=src; enum class Mode{Code,LineComment,BlockComment,String,Char}; Mode mode=Mode::Code;
 for(std::size_t i=0;i<src.size();++i){char c=src[i],n=i+1<src.size()?src[i+1]:'\0';
  if(mode==Mode::Code){
   if(c=='/'&&n=='/'){out[i]=out[i+1]=' ';++i;mode=Mode::LineComment;continue;}
   if(c=='/'&&n=='*'){out[i]=out[i+1]=' ';++i;mode=Mode::BlockComment;continue;}
   if(c=='"'){out[i]=' ';mode=Mode::String;continue;}
   if(c=='\''){out[i]=' ';mode=Mode::Char;continue;}
  }else if(mode==Mode::LineComment){if(c=='\n'||c=='\r')mode=Mode::Code;else out[i]=' ';continue;}
  else if(mode==Mode::BlockComment){if(c=='*'&&n=='/'){out[i]=out[i+1]=' ';++i;mode=Mode::Code;}else if(c!='\n'&&c!='\r')out[i]=' ';continue;}
  else if(mode==Mode::String||mode==Mode::Char){char end=mode==Mode::String?'"':'\'';if(c=='\\'&&i+1<src.size()){out[i]=' ';if(src[i+1]!='\n'&&src[i+1]!='\r')out[i+1]=' ';++i;continue;}if(c==end){out[i]=' ';mode=Mode::Code;}else if(c!='\n'&&c!='\r')out[i]=' ';continue;}
 }
 return out;
}
std::vector<std::string> scriptUnsupported(const std::filesystem::path& path,const std::string* inlineSource=nullptr){
 std::string src;if(inlineSource)src=*inlineSource;else{std::ifstream in(path);if(!in)return {};std::ostringstream ss;ss<<in.rdbuf();src=ss.str();}auto lo=lower(src);auto scanSrc=sanitizeScriptCalls(src);std::vector<std::string> out;auto add=[&](std::string s){if(std::find(out.begin(),out.end(),s)==out.end())out.push_back(std::move(s));};
 // v0.22 handles object-like and function-like #define plus include/import preprocessing and a broader OpenBORScript API surface.
 static const std::set<std::string> allowed={
  "main","if","while","for","switch","getglobalvar","setglobalvar","clearglobalvar","getglobalvarindex","setglobalvarindex","maxglobalvarindex",
  "getindexedvar","setindexedvar","clearindexedvar","getlocalvar","setlocalvar","clearlocalvar","getlocalvarindex","setlocalvarindex",
  "array","size","get","set","add","delete","next","previous","reset","value","key","free",
  "isempty","rand","null","sin","cos","sqrt","atan","atan2","pow","abs","floor","ceil","openborconstant","openborvariant","changeopenborvariant","setopenborvariant","getentityproperty","get_entity_property",
  "changeentityproperty","change_entity_property","setentityproperty","performattack","perform_attack","setanimation","changeanimation","damageentity","damage_entity",
  "bindentity","killentity","kill_entity","tossentity","checkhole","checkholeindex","checkwall","checkwallindex","playerkeys","getplayerproperty","get_player_property","changeplayerproperty","change_player_property","log","printf","debug","rgbcolor",
  "playmusic","pausemusic","fademusic","playsound","loadsample","unloadsample","playsample","jumptobranch","getentity","findtarget","find_target","checkrange","check_range","getentityvar","get_entity_var","setentityvar","set_entity_var","clearentityvar","clear_entity_var","getscriptvar","setscriptvar","clearspawnentry","clear_spawn_entry","setspawnentry","set_spawn_entry","spawn","spawnentity","spawn_entity","spawn01","spawn01map","spawn000","projectile","setidle","updateframe","getmodelproperty","get_model_property","getlevelproperty","get_level_property","changelevelproperty","setlevelproperty","set_level_property","drawdot","drawline","drawbox","drawstring","drawsprite","loadsprite","freesprite","getgfxproperty","get_gfx_property","rgbcolour",
  "openfilestream","getfilestreamargument","filestreamnextline","closefilestream","strlength","allocscreen","clearscreen","drawspritetoscreen","drawboxtoscreen","drawstringtoscreen","drawscreen","drawspriteq","clearspriteq","changedrawmethod",
  "aichecklie","aicheckgrabbed","aicheckgrab","aicheckescape","aicheckbusy","aicheckattack","aicheckmove"
 };
 std::set<std::string> defined;
 std::regex macroDef(R"(#\s*define\s+([A-Za-z_][A-Za-z0-9_]*)\s*\()");
 std::regex objectMacroDef(R"(#\s*define\s+([A-Za-z_][A-Za-z0-9_]*)\s+(?!\()[^\r\n]+)");
 for(std::sregex_iterator m(scanSrc.begin(),scanSrc.end(),macroDef),me;m!=me;++m) defined.insert(lower((*m)[1].str()));
 for(std::sregex_iterator m(scanSrc.begin(),scanSrc.end(),objectMacroDef),me;m!=me;++m) defined.insert(lower((*m)[1].str()));
 std::regex def(R"((?:void|int|float|char|string|mixed|decimal|pointer)\s+([A-Za-z_][A-Za-z0-9_]*)\s*\()");
 for(std::sregex_iterator i(scanSrc.begin(),scanSrc.end(),def),e;i!=e;++i)defined.insert(lower((*i)[1].str()));
 // Include/imported helper functions belong to the same script compilation unit after
 // v0.19 preprocessing. Teach the analyzer about them so supported includes do not
 // produce false "api/function" warnings.
 std::filesystem::path dataRoot;
 for(auto cur=path.parent_path(); !cur.empty(); cur=cur.parent_path()){
  auto leaf=lower(PathEncoding::utf8(cur.filename()));
  if(leaf=="data" || leaf=="openbor-data" || std::filesystem::exists(cur/"models.txt") || std::filesystem::exists(cur/"levels.txt")){
   dataRoot=cur; break;
  }
  if(cur==cur.root_path()) break;
 }
 std::regex incRe(R"(#\s*(?:include|import)\s*["<]([^">]+)[">])", std::regex::icase);
 std::set<std::string> visited{PathEncoding::utf8(path.lexically_normal())};
 std::function<void(const std::filesystem::path&,const std::string&,int)> imports;
 imports=[&](const std::filesystem::path& file,const std::string& body,int depth){
  if(depth>=32){add("include-depth-limit");return;}
  for(std::sregex_iterator i(body.begin(),body.end(),incRe),e;i!=e;++i){
   auto raw=(*i)[1].str();auto rel=SafePath::normalizeOpenBOR(raw);
   if(!SafePath::isSafeRelative(PathEncoding::path(rel))){add("unsafe-include:"+raw);continue;}
   // Legacy scripts frequently include "data/scripts/..." even though the analyzer's
   // trusted root is already the OpenBOR data directory. Avoid resolving that as data/data/.
   auto rootRel=rel;auto relLower=lower(rootRel);auto rootLeaf=lower(PathEncoding::utf8(dataRoot.filename()));
   if((rootLeaf=="data"||rootLeaf=="openbor-data")&&relLower.rfind("data/",0)==0)rootRel=rootRel.substr(5);
   auto inc=SafePath::resolveWithin(dataRoot,rootRel);
   if(inc.empty()||!std::filesystem::exists(inc)){
    auto local=SafePath::resolveWithin(file.parent_path(),raw);
    if(!local.empty()&&SafePath::isWithin(dataRoot,local))inc=local;
   }
   if(inc.empty()||!SafePath::isWithin(dataRoot,inc)){add("unsafe-include:"+raw);continue;}
   if(!visited.insert(PathEncoding::utf8(inc.lexically_normal())).second)continue;
   std::ifstream imported(inc);if(!imported){add("include-missing:"+raw);continue;}
   std::ostringstream text;text<<imported.rdbuf();auto code=text.str();auto codeScan=sanitizeScriptCalls(code);
   for(std::sregex_iterator d(codeScan.begin(),codeScan.end(),def),de;d!=de;++d)defined.insert(lower((*d)[1].str()));
   for(std::sregex_iterator d(codeScan.begin(),codeScan.end(),macroDef),de;d!=de;++d)defined.insert(lower((*d)[1].str()));
   for(std::sregex_iterator d(codeScan.begin(),codeScan.end(),objectMacroDef),de;d!=de;++d)defined.insert(lower((*d)[1].str()));
   imports(inc,code,depth+1);
  }
 };
 if(!dataRoot.empty())imports(path,src,0);
 // Name recognition alone cannot certify dynamic/advanced binding config.
 std::regex bindCall(R"(\bbindentity\s*\()",std::regex::icase);
 for(std::sregex_iterator it(scanSrc.begin(),scanSrc.end(),bindCall),end;it!=end;++it){
  std::vector<std::string> args;std::string part;int depth=1;char quote=0;bool closed=false;
  auto start=(std::size_t)(it->position()+it->length());
  for(std::size_t j=start;j<scanSrc.size();++j){char c=scanSrc[j];if(quote){part+=c;if(c=='\\'&&j+1<scanSrc.size())part+=scanSrc[++j];else if(c==quote)quote=0;continue;}if(c=='"'||c=='\''){quote=c;part+=c;continue;}if(c=='('){++depth;part+=c;}else if(c==')'){if(--depth==0){if(!part.empty()||!args.empty())args.push_back(part);closed=true;break;}part+=c;}else if(c==','&&depth==1){args.push_back(part);part.clear();}else part+=c;}
  if(!closed||args.size()<2||args.size()>8){add("api/function:bindentity-arguments");continue;}
  if(args.size()>6){auto config=args[6];config.erase(std::remove_if(config.begin(),config.end(),[](unsigned char c){return std::isspace(c);}),config.end());
   if(lower(config)=="null()"||lower(config)=="null")continue;
   try{std::size_t used=0;int flags=std::stoi(config,&used,0);constexpr int supported=15|64|128|256|512|1024|2048;if(used!=config.size())add("api/function:bindentity-config-dynamic");else if((flags&~supported)!=0)add("api/function:bindentity-config-advanced");}catch(...){add("api/function:bindentity-config-dynamic");}
  }
 }
 std::regex call(R"(([A-Za-z_][A-Za-z0-9_]*)\s*\()");
 for(std::sregex_iterator i(scanSrc.begin(),scanSrc.end(),call),e;i!=e;++i){auto n=lower((*i)[1].str());if(!allowed.contains(n)&&!defined.contains(n)&&n!="void"&&n!="int"&&n!="float"&&n!="char"&&n!="string"&&n!="mixed"&&n!="decimal"&&n!="pointer")add("api/function:"+n);}
 return out;
}
std::filesystem::path casePath(std::filesystem::path p){
 if(std::filesystem::exists(p)) return p;
 std::filesystem::path out=p.root_path();
 for(const auto& part:p.relative_path()){
  auto next=out/part;
  if(!std::filesystem::exists(next)&&std::filesystem::is_directory(out)){
   for(const auto&e:std::filesystem::directory_iterator(out)){
    if(lower(PathEncoding::utf8(e.path().filename()))==lower(PathEncoding::utf8(part))){next=e.path();break;}
   }
  }
  out=next;
 }
 return out;
}

std::filesystem::path resolveAnimationHelper(const std::string& raw,const std::filesystem::path& modelFile,const ScanReport& scan){
 auto rel=SafePath::normalizeOpenBOR(raw);
 if(!SafePath::isSafeRelative(PathEncoding::path(rel)))return {};
 auto relPath=PathEncoding::path(rel);
 auto candidate=casePath(scan.dataDir/relPath);
 if(std::filesystem::exists(candidate)&&SafePath::isWithin(scan.dataDir,candidate))return candidate;
 // Some legacy packs keep animationscript beside the model while referring to
 // it by basename (or ship it in a moved character folder). Prefer the local
 // model folder and only fall back to a unique basename match.
 if(relPath.has_filename()){
  auto local=casePath(modelFile.parent_path()/relPath.filename());
  if(std::filesystem::exists(local)&&SafePath::isWithin(scan.dataDir,local))return local;
  std::filesystem::path unique;
  std::error_code ec;
  for(std::filesystem::recursive_directory_iterator it(scan.dataDir,std::filesystem::directory_options::skip_permission_denied,ec),end;it!=end;it.increment(ec)){
   if(ec){ec.clear();continue;}
   if(!it->is_regular_file(ec))continue;
   if(lower(PathEncoding::utf8(it->path().filename()))!=lower(PathEncoding::utf8(relPath.filename())))continue;
   if(!unique.empty())return {}; // Ambiguous: do not guess.
   unique=it->path();
  }
  if(!unique.empty()&&SafePath::isWithin(scan.dataDir,unique))return unique;
 }
 return {};
}
bool parseNumber(const std::string& raw){
 try{std::size_t used=0;std::stod(raw,&used);return used==raw.size();}catch(...){return false;}
}
bool parseInteger(const std::string& raw,int* value=nullptr){
 try{std::size_t used=0;int v=std::stoi(raw,&used,0);if(used!=raw.size())return false;if(value)*value=v;return true;}catch(...){return false;}
}
bool simpleSceneSupported(const TextEntry& item,const std::filesystem::path& modelFile,const ScanReport& scan){
 if(item.values.size()!=1) return false;
 auto path=resolveAnimationHelper(item.values[0],modelFile,scan);
 if(path.empty()) return false;
 for(const auto&e:TextDatabase::parse(path)){auto k=lower(e.key);if(k=="music"){if(e.values.empty()||e.values.size()>2)return false;}else if(k=="animation"){if(e.values.empty()||e.values.size()>6)return false;}else if(k!="silence")return false;}
 return true;
}
std::filesystem::path resolvePaletteAsset(const std::string& raw,const std::filesystem::path& modelFile,const ScanReport& scan){
 if(lower(raw)=="none"||raw=="0")return {};
 auto p=resolveAnimationHelper(raw,modelFile,scan);if(!p.empty())return p;
 auto rel=SafePath::normalizeOpenBOR(raw);if(!SafePath::isSafeRelative(PathEncoding::path(rel)))return {};
 auto rp=PathEncoding::path(rel);
 static const char* exts[]={".gif",".png",".bmp",".act"};
 if(rp.has_extension()){std::filesystem::path stem=rp;stem.replace_extension();std::filesystem::path unique;for(auto* ext:exts){auto q=casePath(scan.dataDir/stem);q+=ext;q=casePath(q);if(!std::filesystem::exists(q)||!SafePath::isWithin(scan.dataDir,q))continue;if(!unique.empty()&&unique!=q)return {};unique=q;}if(!unique.empty())return unique;return {};}
 for(auto* ext:exts){auto q=casePath(scan.dataDir/rp);q+=ext;q=casePath(q);if(std::filesystem::exists(q)&&SafePath::isWithin(scan.dataDir,q))return q;}
 if(rp.has_filename())for(auto* ext:exts){auto q=casePath(modelFile.parent_path()/rp.filename());q+=ext;q=casePath(q);if(std::filesystem::exists(q)&&SafePath::isWithin(scan.dataDir,q))return q;}
 return {};
}
bool indexedPaletteAsset(const std::string& raw,const std::filesystem::path& modelFile,const ScanReport& scan){
 auto p=resolvePaletteAsset(raw,modelFile,scan);if(p.empty())return false;auto ext=lower(PathEncoding::utf8(p.extension()));
 if(ext==".gif"||ext==".act")return true;
 std::ifstream in(p,std::ios::binary);if(!in)return false;unsigned char h[64]{};in.read(reinterpret_cast<char*>(h),sizeof(h));auto n=(std::size_t)in.gcount();
 if(ext==".png"&&n>=26){static const unsigned char sig[8]={137,80,78,71,13,10,26,10};if(std::equal(sig,sig+8,h)&&h[25]==3)return true;}
 if(ext==".bmp"&&n>=30&&h[0]=='B'&&h[1]=='M'){unsigned bpp=(unsigned)h[28]|((unsigned)h[29]<<8);return bpp>0&&bpp<=8;}
 return false;
}
bool executableAnimationScript(const TextEntry& item,const std::filesystem::path& modelFile,const ScanReport& scan){
 if(item.values.size()!=1) return false;
 auto p=resolveAnimationHelper(item.values[0],modelFile,scan);
 if(p.empty()) return false;
 return scriptUnsupported(p).empty();
}
void refineOccurrence(CommandInfo& info,const TextEntry& item,const std::filesystem::path& file,const ScanReport& scan){
 if(info.status!=CommandStatus::Partial) return;
 const auto cmd=lower(item.key);
 auto supported=[&](const char* note){info.status=CommandStatus::Supported;info.parser=true;info.runtime=true;info.note=note;};
 int v=0;
 auto inputTokenSupported=[](std::string token){
  token=lower(token);token.erase(std::remove_if(token.begin(),token.end(),[](unsigned char c){return std::isspace(c);}),token.end());
  while(!token.empty()&&(token.front()=='~'||token.front()=='*'||token.front()=='['))token.erase(token.begin());
  while(!token.empty()&&(token.back()==']'||token.back()=='*'))token.pop_back();
  if(token.empty())return false;
  static const std::set<std::string> keys={"a","a2","a3","a4","j","s","k","u","d","f","b","l","r"};
  std::size_t start=0;while(start<token.size()){auto plus=token.find('+',start);auto part=token.substr(start,plus==std::string::npos?std::string::npos:plus-start);if(!keys.contains(part))return false;if(plus==std::string::npos)break;start=plus+1;}return true;
 };
 if(cmd=="drawmethod"&&!item.values.empty()){
  auto sub=lower(item.values[0]);
  bool numericPos=std::all_of(item.values.begin(),item.values.end(),parseNumber);
  if(numericPos&&item.values.size()<=6){supported("Legacy positional drawmethod scale/flip/shift/alpha subset is executed by the native compositor.");return;}
  if(sub=="tintmode"&&item.values.size()==2&&parseInteger(item.values[1],&v)&&v>=0&&v<=6){supported("drawmethod tintmode 0-6 uses the OpenBOR screen/multiply/overlay/hardlight/dodge/half channel blend order.");return;}
  if(sub=="tintcolor"&&item.values.size()==2&&std::regex_match(item.values[1],std::regex(R"((?:[0-9]{1,3}_[0-9]{1,3}_[0-9]{1,3}|0[xX][0-9A-Fa-f]+|[0-9]+))"))){supported("drawmethod tintcolor is parsed and combined with tintmode in the native compositor.");return;}
  static const std::set<std::string> direct={"scale","scalex","scaley","flipx","flipy","shiftx","alpha","fillcolor","rotate","fliprotate"};
  if(direct.contains(sub)){supported("Direct drawmethod transform is parsed and executed by the native compositor.");return;}
 }
 if(cmd=="@script"&&scriptUnsupported(file,&item.scriptBody).empty()){supported("Inline script body uses only the verified ScriptVM surface and executes in source order on animation frame entry.");return;}
 if(cmd=="defense"&&item.values.size()>=2&&item.values.size()<=7){
  auto t=lower(item.values[0]);bool ok=(t=="all"||t=="normal"||t=="shock"||t=="burn"||t=="freeze"||t=="steal"||t=="blast");
  for(std::size_t i=1;ok&&i<item.values.size();++i)ok=parseNumber(item.values[i]);
  if(ok){supported("Typed legacy defense factor/pain/knockdown/block fields are consumed by the native defense resolver.");return;}
 }
 if(cmd=="risetime"&&!item.values.empty()&&item.values.size()<=2&&std::all_of(item.values.begin(),item.values.end(),parseNumber)){supported("Numeric risetime adjusts native knockdown recovery using OpenBOR centisecond timing, including negative values that lengthen recovery.");return;}
 if(cmd=="rock"&&item.values.size()==1&&parseInteger(item.values[0],&v)&&v>=0&&v<=2){supported("Legacy rock mode 0-2 is applied by native stage motion/shake rendering.");return;}
 if(cmd=="subject_to_wall"&&item.values.size()==1&&parseInteger(item.values[0],&v)&&(v==0||v==1)){supported("subject_to_wall 0/1 directly gates native wall collision for player, coop and runtime entities.");return;}
 if(cmd=="subject_to_obstacle"&&item.values.size()==1&&parseInteger(item.values[0],&v)&&v==0){supported("subject_to_obstacle 0 explicitly opts the model out of obstacle blocking and requires no obstacle collision response.");return;}
 if(cmd=="nodieblink"&&item.values.size()==1&&parseInteger(item.values[0],&v)&&v==0){supported("nodieblink 0 selects the native default death lifecycle.");return;}
 if(cmd=="projectilehit"&&!item.values.empty()){
  static const std::set<std::string> types={"none","ground","player","enemy","item","obstacle","projectile","steamer","shot","trap","textbox","endlevel","npc","panel"};
  bool ok=true;for(const auto&x:item.values)if(!types.contains(lower(x))){ok=false;break;}if(ok){supported("Named projectilehit type masks are converted to OpenBOR type bits and enforced by native projectile collision targeting.");return;}
 }
 if(cmd=="combostyle"&&item.values.size()==1&&parseInteger(item.values[0],&v)&&v>=0&&v<=2){supported("combostyle 0-2 is consumed by native attack-chain progression, including free-chain style 2.");return;}
 if(cmd=="facing"&&item.values.size()==1&&parseInteger(item.values[0],&v)&&v>=0&&v<=3){supported("Legacy facing mode is enforced for player, coop and runtime entities; 0 follows movement, 1/2 force right/left, 3 follows stage scroll direction.");return;}
 if(cmd=="combodelay"&&item.values.size()==1&&parseInteger(item.values[0],&v)&&v>=0){supported("Numeric combodelay is consumed by native attack-chain timing and resets combo progression after the configured window.");return;}
 if(cmd=="light"&&item.values.size()==2&&parseNumber(item.values[0])&&parseNumber(item.values[1])){supported("Stage light vector is consumed by projected gfxshadow rendering.");return;}
 if(cmd=="shadowalpha"&&item.values.size()==1&&parseInteger(item.values[0],&v)&&v>=0&&v<=6){supported("OpenBOR shadow alpha/blend mode 0-6 is consumed by native projected shadow rendering.");return;}
 if(cmd=="settime"&&item.values.size()==1&&parseInteger(item.values[0],&v)&&v==0){supported("settime 0 disables the stage countdown; the native stage remains untimed.");return;}
 if(cmd=="notime"&&item.values.size()==1&&parseInteger(item.values[0],&v)&&v==1){supported("notime 1 disables the stage countdown; the native stage remains untimed.");return;}
 if(cmd=="platform"&&(item.values.size()==6||item.values.size()==8)&&std::all_of(item.values.begin(),item.values.end(),parseNumber)){supported("Legacy 6-field and modern 8-field animation platform geometry are converted to native sloped platform collision.");return;}
 if(cmd=="throw"&&item.values.size()>=1&&item.values.size()<=2&&std::all_of(item.values.begin(),item.values.end(),parseNumber)){supported("Legacy throw distance/height are stored as victim model traits and consumed by native grab throws.");return;}
 if(cmd=="blast"){
  bool clear=item.values.size()==4&&std::all_of(item.values.begin(),item.values.end(),[](const std::string&x){int n=0;return parseInteger(x,&n)&&n==0;});
  bool box=item.values.size()>=5&&item.values.size()<=10&&std::all_of(item.values.begin(),item.values.end(),parseNumber);
  if(clear||box){supported("Legacy blast boxes use OpenBOR blast knockdown, 2.5 horizontal launch and falling-body projectile contact semantics; both 9-field and transitional 10-field forms are handled, and four zero coordinates clear the active box.");return;}
 }
 if(cmd=="pbombframe"&&item.values.size()>=1&&item.values.size()<=2&&std::all_of(item.values.begin(),item.values.end(),parseNumber)){supported("Legacy pbombframe aliases tossframe: trigger frame and projectile altitude drive native bomb spawning.");return;}
 if(cmd=="cameraoffset"&&item.values.size()==2&&std::all_of(item.values.begin(),item.values.end(),parseNumber)){supported("Camera X/Z offsets are applied to native world-to-screen projection for layers, actors, projectiles and shadows.");return;}
 if(cmd=="shadowcolor"&&item.values.size()==1&&parseInteger(item.values[0],&v)&&(v==-1||v==0||v==1)){supported("Legacy shadowcolor -1/0/1 maps to disabled/default/dark native shadow presentation; indexed dark color 1 is reproduced without requiring a game-specific palette.");return;}
 if((cmd=="bglayer"||cmd=="fglayer")&&!item.values.empty()){bool ok=true;for(std::size_t i=1;i<item.values.size();++i)if(!parseNumber(item.values[i])){ok=false;break;}std::size_t water=(cmd=="fglayer"?12:11);if(ok&&item.values.size()<= (cmd=="fglayer"?17u:16u)){int wm=0,amp=0,wlen=0;double ws=0;if(item.values.size()>water){ok=parseInteger(item.values[water],&wm)&&wm==0;}if(ok&&item.values.size()>water+1){ok=parseInteger(item.values[water+1],&amp)&&amp==0;}if(ok&&item.values.size()>water+2){ok=parseInteger(item.values[water+2],&wlen)&&wlen==0;}if(ok&&item.values.size()>water+3){try{ws=std::stod(item.values[water+3]);ok=std::fabs(ws)<0.000001;}catch(...){ok=false;}}if(ok){supported("Legacy stage layer ratios, offsets, spacing/repeat, depth and OpenBOR alpha blend mode are rendered natively; this occurrence does not request unsupported wave distortion.");return;}}}
 if(cmd=="gfxshadow"&&item.values.size()==1&&parseInteger(item.values[0],&v)&&(v==0||v==1)){supported(v==0?"gfxshadow 0 uses the generic OpenBOR shadow sprite beneath native actors.":"gfxshadow 1 projects the current actor frame onto the ground using stage light direction and shadow alpha blend mode.");return;}
 if(cmd=="holdblock"&&item.values.size()==1&&parseInteger(item.values[0],&v)&&v==1){supported("holdblock 1 keeps player/coop block state and animation active while Special is held, resuming after blockpain until release.");return;}
 if(cmd=="running"&&item.values.size()>=1&&item.values.size()<=5&&std::all_of(item.values.begin(),item.values.end(),parseNumber)){supported("running speed/jump-height/jump-length/Z-control/land-continuation parameters are consumed by native player and coop movement.");return;}
 if(cmd=="chargetime"&&item.values.size()==1&&parseNumber(item.values[0])){supported("Chargeattack release timing is enforced from the declared centisecond threshold for player and coop input.");return;}
 if(cmd=="riseinv"&&item.values.size()>=1&&item.values.size()<=2&&std::all_of(item.values.begin(),item.values.end(),parseNumber)){supported("Post-rise invulnerability duration is enforced for player, coop and runtime entities; no-blink mode requires no visibility cadence.");return;}
 if(cmd=="dust"&&item.values.size()>=1&&item.values.size()<=3&&std::all_of(item.values.begin(),item.values.end(),[](const std::string&x){return !x.empty();})){supported("Model fall/land/jump dust entities are spawned through the generic child-effect runtime at the corresponding movement events.");return;}
 if((cmd=="subject_to_minz"||cmd=="subject_to_maxz")&&item.values.size()==1&&parseInteger(item.values[0],&v)&&(v==0||v==1)){supported("Model Z-bound participation flag is enforced for player, coop and runtime entities against stage min/max Z.");return;}
 if(cmd=="subject_to_platform"&&item.values.size()==1&&parseInteger(item.values[0],&v)&&(v==0||v==1)){supported("subject_to_platform controls both dynamic platform top height and side collision for player, coop and runtime entities.");return;}
 if(cmd=="cameratype"&&item.values.size()==1&&parseInteger(item.values[0],&v)&&(v==0||v==1)){supported("cameratype 0/1 maps to scrolling versus fixed native camera behavior.");return;}
 if(cmd=="nomove"&&item.values.size()>=1&&item.values.size()<=2){bool ok=true;for(const auto&x:item.values){int n=0;if(!parseInteger(x,&n)||(n!=0&&n!=1)){ok=false;break;}}if(ok){supported("Legacy nomove 0/1 movement constraint is enforced for player, coop and AI entities; optional facing lock is preserved by noflip/facing handling.");return;}}
 if(cmd=="fmap"&&item.values.size()==1&&parseInteger(item.values[0],&v)&&v==-1){supported("fmap -1 explicitly disables freeze-map palette substitution and requires no runtime remap.");return;}
 if(cmd=="burn"&&item.values.size()==1&&parseInteger(item.values[0],&v)&&v==0){supported("burn 0 disables the legacy burn attack box for the current frame.");return;}
 if(cmd=="falldie"&&item.values.size()==1&&parseInteger(item.values[0],&v)&&v==1){supported("falldie 1 selects immediate death animation instead of entering fall first.");return;}
 if(cmd=="nodieblink"&&item.values.size()==1&&parseInteger(item.values[0],&v)&&(v==2||v==3)){supported(v==2?"nodieblink 2 removes after the final death frame without blinking.":"nodieblink 3 leaves the final death frame as a persistent corpse without blink removal.");return;}
 if(cmd=="aimove"&&!item.values.empty()){
  static const std::set<std::string> modes={"normal","chase","chasez","chasex","avoid","avoidz","avoidx","wander","biker","arrow","star","bomb","nomove","ignoreholes","notargetidle"};
  bool ok=true;for(const auto&x:item.values)if(!modes.contains(lower(x))){ok=false;break;}
  if(ok){supported("Named aimove flags are mapped to native chase/avoid/wander/projectile-style movement branches.");return;}
 }
 if(cmd=="damageonlanding"&&item.values.size()>=1&&item.values.size()<=3&&parseInteger(item.values[0])&&(item.values.size()<2||(parseInteger(item.values[1],&v)&&v>=0&&v<=1))){supported("Landing force/mode 0-1 is preserved; mode 1 enables falling-body projectile collisions until landing.");return;}
 if(cmd=="attackone"&&item.values.size()==1&&parseInteger(item.values[0],&v)&&v==1){supported("attackone 1 stops after the first collision for player, coop, enemy, and projectile attacks.");return;}
 if(cmd=="atchain"&&!item.values.empty()){
  bool ok=true,zero=false;for(const auto&x:item.values){int n=0;if(!parseInteger(x,&n)||n<0||n>12){ok=false;break;}if(n==0)zero=true;else if(zero){ok=false;break;}}
  if(ok){supported("Static/trailing-zero attack chains are executed by the native combo runtime.");return;}
 }
 if((cmd=="com"||cmd=="cmd")&&item.values.size()>=2){bool ok=true;for(std::size_t i=0;i+1<item.values.size();++i)if(!inputTokenSupported(item.values[i])){ok=false;break;}if(ok){supported("Custom command sequence uses native-supported direction/action/chord tokens and is matched by runtime input history.");return;}}
 if(cmd=="cancel"&&item.values.size()>=5){int a=0,b=0,h=0;bool ok=parseInteger(item.values[0],&a)&&parseInteger(item.values[1],&b)&&parseInteger(item.values[2],&h)&&a>=0&&b>=a&&h>=0;for(std::size_t i=3;ok&&i+1<item.values.size();++i)ok=inputTokenSupported(item.values[i]);if(ok){supported("Animation cancel window/hit threshold and supported command sequence are executed by the native cancel matcher.");return;}}
 if(cmd=="aimove"&&item.values.size()==1&&lower(item.values[0])=="chase"){supported("Named aimove chase maps to the OpenBOR chase flag and is executed by enemy/NPC AI.");return;}
 if((cmd=="antigrab"||cmd=="grabresistance"||cmd=="grab_resistance")&&item.values.size()==1&&parseInteger(item.values[0],&v)&&v>=0){supported("Numeric grab resistance is enforced against attacker grabforce for player, coop, and AI grab selection.");return;}
 if(cmd=="grabforce"&&item.values.size()==1&&parseInteger(item.values[0],&v)&&v>=0){supported("Numeric grabforce gates native player/coop/AI grab selection against target antigrab/grab resistance.");return;}
 if(cmd=="bounce"&&item.values.size()==1&&parseInteger(item.values[0],&v)&&v>=0&&v<=8){supported("Numeric bounce count is applied to runtime projectiles and falling runtime entities on ground contact.");return;}
 if((cmd=="burn"||cmd=="shock")&&item.values.size()>=4&&item.values.size()<=10&&std::all_of(item.values.begin(),item.values.end(),parseNumber)){supported(cmd=="burn"?"Legacy burn attack box is parsed with burn pain/fall/death reaction selection and native attack metadata.":"Legacy shock attack box is parsed with shock pain/fall reaction selection and native attack metadata.");return;}
 if(cmd=="platform"&&item.values.size()==8&&std::all_of(item.values.begin(),item.values.end(),parseNumber)){supported("Eight-value entity platform trapezoid is emitted and participates in dynamic platform side/top collision.");return;}
 if((cmd=="lives"||cmd=="credits")&&item.values.size()==1&&parseInteger(item.values[0],&v)&&v>=0){supported("Level-set lives/credits are generated into stage metadata and consumed by native respawn/continue flow.");return;}
 if(cmd=="animationscript"&&executableAnimationScript(item,file,scan)){supported("Animation helper script resolves inside data/, uses the verified ScriptVM surface, and frame @cmd calls execute against it.");return;}
 if(cmd=="defense"&&item.values.size()==1&&lower(item.values[0])=="all"){supported("Legacy defense all without an explicit factor is preserved as factor 1.0.");return;}
 if(cmd=="nodieblink"&&item.values.size()==1&&parseInteger(item.values[0],&v)&&v==2){supported("nodieblink 2 keeps the death/fall animation visible through its last frame and removes without blinking.");return;}
 if(cmd=="wall"&&item.values.size()>=8&&item.values.size()<=9&&std::all_of(item.values.begin(),item.values.end(),parseNumber)){supported("Static OpenBOR trapezoid wall geometry and height are used by runtime collision and script wall queries.");return;}
 if(cmd=="blockade"&&item.values.size()==1&&parseInteger(item.values[0])){supported("Numeric blockade is emitted as a backward-scroll floor and activated by stage events.");return;}
 if(cmd=="frontpanel"&&item.values.size()==1){supported("Single-image frontpanel is loaded as a foreground stage layer.");return;}
 if(cmd=="palette"&&item.values.size()==1&&lower(item.values[0])=="none"){supported("palette none explicitly disables model palette remapping and requires no native conversion.");return;}
 if(cmd=="palette"&&item.values.size()==1&&indexedPaletteAsset(item.values[0],file,scan)){supported("Indexed GIF/PNG/BMP or ACT base palette is preserved through the native palette loader for remaps.");return;}
 if(cmd=="alternatepal"&&item.values.size()==1&&indexedPaletteAsset(item.values[0],file,scan)){supported("Indexed alternate palette asset is loaded through the same native palette-table path used for remaps.");return;}
 if(cmd=="remap"&&item.values.size()==2&&indexedPaletteAsset(item.values[0],file,scan)&&indexedPaletteAsset(item.values[1],file,scan)){supported("Indexed source/target palette tables drive the native color-map remap.");return;}
 if(cmd=="scene"&&simpleSceneSupported(item,file,scan)){supported("Scene uses supported music/animation/silence directives; GIF playback runs a full animation cycle unless an explicit duration is supplied.");return;}
 if(cmd=="nocost"&&item.values.size()==1&&parseInteger(item.values[0],&v)&&(v==0||v==1)){supported("Global nocost is propagated to generated models and energy-cost execution.");return;}
 if(cmd=="end"&&item.values.empty()){supported("Bare end marks the stage as ending in the generated stage model.");return;}
 if(cmd=="remove"&&item.values.size()==1&&parseInteger(item.values[0],&v)&&(v==0||v==1)){supported("Projectile remove contact mode 0/1 is enforced by the runtime projectile lifecycle.");return;}
 if(cmd=="weapon"&&item.values.size()==1){supported("Stage weapon spawn is parsed as a weapon item spawn and resolved through model weapon indices.");return;}
 if(cmd=="weapons"&&!item.values.empty()){supported("Weapon model list is emitted and used for player/coop/AI weapon pickup and action-animation lookup.");return;}
 if((cmd=="weapnum"||cmd=="shootnum"||cmd=="counter")&&item.values.size()==1&&parseInteger(item.values[0],&v)&&v>=0){supported("Simple numeric weapon index/ammo/drop counter is consumed by the native weapon lifecycle.");return;}
 if(cmd=="typeshot"&&item.values.size()==1&&parseInteger(item.values[0],&v)&&(v==0||v==1)){supported("typeshot 0/1 controls weapon exhaustion/drop behavior in the native weapon lifecycle.");return;}
}
std::string helperCompilationSource(const std::filesystem::path& path){
 std::filesystem::path dataRoot;
 for(auto cur=path.parent_path();!cur.empty();cur=cur.parent_path()){
  auto leaf=lower(PathEncoding::utf8(cur.filename()));
  if(leaf=="data"||leaf=="openbor-data"||std::filesystem::exists(cur/"models.txt")||std::filesystem::exists(cur/"levels.txt")){dataRoot=cur;break;}
  if(cur==cur.root_path())break;
 }
 std::set<std::string> visited;std::ostringstream all;
 std::regex incRe(R"(#\s*(?:include|import)\s*[\"<]([^\">]+)[\">])",std::regex::icase);
 std::function<void(const std::filesystem::path&,int)> visit;
 visit=[&](const std::filesystem::path& file,int depth){
  if(depth>=32)return;auto norm=PathEncoding::utf8(file.lexically_normal());if(!visited.insert(norm).second)return;
  std::ifstream in(file);if(!in)return;std::ostringstream ss;ss<<in.rdbuf();auto body=ss.str();all<<"\n"<<body<<"\n";
  if(dataRoot.empty())return;
  for(std::sregex_iterator i(body.begin(),body.end(),incRe),e;i!=e;++i){auto raw=(*i)[1].str();auto rel=SafePath::normalizeOpenBOR(raw);if(!SafePath::isSafeRelative(PathEncoding::path(rel)))continue;auto rootRel=rel;auto rl=lower(rootRel),leaf=lower(PathEncoding::utf8(dataRoot.filename()));if((leaf=="data"||leaf=="openbor-data")&&rl.rfind("data/",0)==0)rootRel=rootRel.substr(5);auto inc=SafePath::resolveWithin(dataRoot,rootRel);if(inc.empty()||!std::filesystem::exists(inc)){auto local=SafePath::resolveWithin(file.parent_path(),raw);if(!local.empty()&&SafePath::isWithin(dataRoot,local))inc=local;}if(!inc.empty()&&SafePath::isWithin(dataRoot,inc))visit(casePath(inc),depth+1);}
 };
 visit(path,0);return all.str();
}
int helperFunctionArity(const std::string& source,const std::string& function){
 try{
  std::regex def("(?:void|int|float|char|string|mixed|decimal|pointer)\\s+"+function+"\\s*\\(([^)]*)\\)",std::regex::icase);
  std::smatch m;if(!std::regex_search(source,m,def))return -1;
  auto args=m[1].str();auto trim=[](std::string v){auto a=v.find_first_not_of(" \t\r\n");if(a==std::string::npos)return std::string{};auto b=v.find_last_not_of(" \t\r\n");return v.substr(a,b-a+1);};
  args=trim(args);if(args.empty()||lower(args)=="void")return 0;
  int count=1;int depth=0;char quote=0;
  for(std::size_t i=0;i<args.size();++i){char c=args[i];if(quote){if(c=='\\'&&i+1<args.size())++i;else if(c==quote)quote=0;continue;}if(c=='"'||c=='\'')quote=c;else if(c=='('||c=='[')++depth;else if(c==')'||c==']')--depth;else if(c==','&&depth==0)++count;}
  return count;
 }catch(...){return -1;}
}
AnimationCommandDiagnostic auditCommand(const TextEntry& item,const std::vector<TextEntry>& entries,std::size_t index,const std::filesystem::path&file,const ScanReport&scan){
 AnimationCommandDiagnostic d;d.file=std::filesystem::relative(file,scan.root);d.line=item.line;d.function=item.values.empty()?"<empty>":item.values[0];
 bool animation=false,frame=false;
 for(std::size_t i=0;i<index;++i){auto k=lower(entries[i].key);if(k=="anim"||k=="animation")animation=true;}
 for(std::size_t i=index+1;i<entries.size();++i){auto k=lower(entries[i].key);if(k=="anim"||k=="animation")break;if(k=="frame"){frame=true;break;}}
 for(const auto&e:entries)if(lower(e.key)=="animationscript"&&!e.values.empty())d.helper=e.values[0];
 auto prefix="function="+d.function+"; helper="+(d.helper.empty()?"<none>":d.helper)+"; ";
 if(!animation||!frame){d.detail=prefix+"no following animation frame; command cannot execute";return d;}
 if(item.values.empty()){d.detail=prefix+"empty command";return d;}
 if(!std::regex_match(d.function,std::regex("[A-Za-z_][A-Za-z0-9_]*"))){d.detail=prefix+"invalid function name";return d;}
 // A deliberately narrow, behavior-tested subset can be certified per call.
 // Engine-property APIs and custom helper bodies retain PARTIAL; static API
 // name recognition is not sufficient evidence of their full semantics.
 static const std::set<std::string> verified={"setglobalvar","getglobalvar","getlocalvar","setlocalvar","null","killentity"};
 auto function=lower(d.function);bool direct=verified.contains(function);
 std::size_t expected=function=="null"?0:(function=="setglobalvar"||function=="setlocalvar"?2:1);
 if(item.values.size()!=expected+1)direct=false;
 static const std::regex literal(R"CMD((?:"(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*'|[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?|0[xX][0-9A-Fa-f]+|true|false|null))CMD",std::regex::icase);
 static const std::regex simpleRead(R"CMD((?:null\(\s*\)|(?:getlocalvar|getglobalvar)\(\s*(?:"(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*')\s*\)))CMD",std::regex::icase);
 for(std::size_t i=1;i<item.values.size();++i)if(!std::regex_match(item.values[i],literal)&&!std::regex_match(item.values[i],simpleRead))direct=false;
 std::string args;for(std::size_t i=1;i<item.values.size();++i)args+=item.values[i]+" ";
 std::string code=args;char quote=0;for(std::size_t i=0;i<code.size();++i){char c=code[i];if(quote){code[i]=' ';if(c=='\\'&&i+1<code.size())code[++i]=' ';else if(c==quote)quote=0;}else if(c=='"'||c=='\''){quote=c;code[i]=' ';}}
 if(quote)direct=false;
 int balance=0;for(char c:code){if(c=='(')++balance;else if(c==')'&&--balance<0)direct=false;}if(balance!=0)direct=false;
 std::regex calls(R"(([A-Za-z_][A-Za-z0-9_]*)\s*\()");
 for(std::sregex_iterator i(code.begin(),code.end(),calls),e;i!=e;++i)if(!verified.contains(lower((*i)[1].str())))direct=false;
 // Bare unknown names can be constants/macros requiring preprocessing.
 std::regex names(R"([A-Za-z_][A-Za-z0-9_]*)");for(std::sregex_iterator i(code.begin(),code.end(),names),e;i!=e;++i){auto n=lower(i->str());if(!verified.contains(n)&&n!="true"&&n!="false")direct=false;}
 if(code.find_first_of("{};[]")!=std::string::npos)direct=false;
 if(!d.helper.empty()){
  auto rel=SafePath::normalizeOpenBOR(d.helper);
  if(!SafePath::isSafeRelative(PathEncoding::path(rel))){d.detail=prefix+"unsafe helper path";return d;}
  auto path=resolveAnimationHelper(d.helper,file,scan);
  if(path.empty()){d.detail=prefix+"helper file missing or basename is ambiguous";return d;}
  std::ifstream f(path);if(!f){d.detail=prefix+"helper file missing";return d;}std::ostringstream text;text<<f.rdbuf();auto source=text.str();
  auto missing=scriptUnsupported(path);
  if(!missing.empty()){d.detail=prefix+"helper compilation unit requires: ";for(const auto&name:missing)d.detail+=name+" ";return d;}
  if(!direct){
   // The generated ScriptVM supports user-defined helper functions. Certify a
   // call when the helper really defines the function, its arity matches, all
   // APIs in the compilation unit are implemented, and the @cmd arguments stay
   // inside the expression subset already validated above.
   auto compilationSource=helperCompilationSource(path);int arity=helperFunctionArity(compilationSource.empty()?source:compilationSource,d.function);
   bool simpleArgs=true;
   for(std::size_t i=1;i<item.values.size();++i)if(!std::regex_match(item.values[i],literal)&&!std::regex_match(item.values[i],simpleRead))simpleArgs=false;
   if(arity>=0&&arity==(int)item.values.size()-1&&simpleArgs)direct=true;
   else {d.detail=prefix+"custom helper function/arity or arguments still need behavioral validation; runtime executes and logs any failure";return d;}
  }
 }
 if(direct){d.status=CommandStatus::Supported;d.detail=prefix+"verified ScriptVM call, bound to the following frame";}
 else d.detail=prefix+"helper/API or arguments outside the verified subset; runtime executes and logs any failure";
 return d;
}
std::string jsonEscape(const std::string& s){
    std::string o; o.reserve(s.size());
    for(char c:s){ if(c=='\\'||c=='"'){o.push_back('\\'); o.push_back(c);} else if(c=='\n') o+="\\n"; else if(c=='\r') continue; else o.push_back(c); }
    return o;
}
}

CompatibilityReport CompatibilityAnalyzer::analyze(const ScanReport& scan){
    CompatibilityReport out;
    if(!scan.hasDataDir) return out;
    auto video = LevelParser::parseVideo(scan.dataDir);
    if(video.found){ out.logicalWidth=video.hResolution; out.logicalHeight=video.vResolution; out.openborVersionHint = "video.txt present (mode "+std::to_string(video.videoMode)+")"; }
    else out.openborVersionHint = "video.txt absent; logical resolution defaults to 320x240 until a project declares otherwise";

    auto characters = CharacterParser::parseAll(scan.dataDir, scan.root);
    out.models = characters.size();
    for(const auto& c: characters) out.animations += c.animations.size();
    const auto stages=LevelParser::parseAll(scan.dataDir, scan.root);
    out.stages=stages.size();
    std::set<std::string> invalidPanelOrder;
    for(const auto& stage:stages)if(!stage.panelOrderValid)invalidPanelOrder.insert(stage.sourceFile);

    std::set<std::string> modelAliases;
    auto modelsFile=casePath(scan.dataDir/"models.txt");
    if(std::filesystem::exists(modelsFile)) for(const auto& me:TextDatabase::parse(modelsFile)){
        auto mk=lower(me.key); if((mk=="load"||mk=="know")&&!me.values.empty()) modelAliases.insert(lower(me.values[0]));
    }

    for(const auto& entry: std::filesystem::recursive_directory_iterator(scan.dataDir)){
        if(!entry.is_regular_file()) continue;
        auto ext=lower(PathEncoding::utf8(entry.path().extension()));
        if(ext==".wav"||ext==".bor"||ext==".ogg"||ext==".mp3"||ext==".flac") ++out.audioFiles;
        if(!textLike(entry.path())) continue;
        if(ext==".txt" && ancillaryText(entry.path())) continue;
        ++out.scannedTextFiles;
        if(ext==".c"||ext==".h"){
            ++out.scripts;
            auto unsupported=scriptUnsupported(entry.path());
            ++out.recognizedCommands;
            if(!unsupported.empty()){
                CompatibilityIssue issue;
                issue.level=CompatibilityLevel::Yellow;
                issue.status=CommandStatus::Partial;
                issue.parser=true; issue.runtime=false;
                issue.file=std::filesystem::relative(entry.path(),scan.root);
                issue.line=1; issue.command="script-file";
                issue.message="ScriptVM v0.22 covers the extended C-like core and basic preprocessing, but this file uses: ";
                for(std::size_t i=0;i<unsupported.size();++i){ if(i) issue.message+=", "; issue.message+=unsupported[i]; }
                issue.message+=". Logged, not silently dropped.";
                out.issues.push_back(std::move(issue));
                ++out.partialCommands;
            }
            continue;
        }
        const auto textEntries=TextDatabase::parse(entry.path());
        for(std::size_t entryIndex=0;entryIndex<textEntries.size();++entryIndex){
            const auto&item=textEntries[entryIndex];const auto cmd=lower(item.key);
            ++out.commandUsage[cmd];
            if(cmd=="@script"){
                const auto unsupported=scriptUnsupported(entry.path(),&item.scriptBody);
                if(!unsupported.empty()){
                    CompatibilityIssue bodyIssue;bodyIssue.file=std::filesystem::relative(entry.path(),scan.root);bodyIssue.line=item.line;bodyIssue.command="inline-script-api";bodyIssue.status=CommandStatus::Partial;bodyIssue.level=CompatibilityLevel::Yellow;bodyIssue.parser=true;bodyIssue.runtime=false;bodyIssue.message="Inline body is preserved and executed, but requires: ";
                    for(const auto& name:unsupported)bodyIssue.message+=name+" ";
                    out.issues.push_back(std::move(bodyIssue));++out.partialCommands;++out.recognizedCommands;
                }
            }
            auto info=CommandRegistry::lookup(cmd);
            if(info.status==CommandStatus::Unknown && item.values.empty() && modelAliases.contains(cmd)){
                auto rel=lower(PathEncoding::utf8(std::filesystem::relative(entry.path(),scan.dataDir)));
                if(rel.rfind("levels/",0)==0){
                    info.status=CommandStatus::IgnoredSafely; info.parser=true; info.runtime=true;
                    info.note="Bare model-registry token outside a spawn directive is a malformed/no-op stage line; ignored explicitly instead of treated as an unknown command.";
                }
            }
            if(cmd=="order" && invalidPanelOrder.contains(PathEncoding::utf8(std::filesystem::relative(entry.path(),scan.root)))){
                info.status=CommandStatus::Partial;info.runtime=false;info.note="Panel order contains a non-letter or references an undefined panel; original panel definitions are retained as fallback.";
            }
            std::string commandDetail;
            if(cmd=="@cmd"){
                auto diagnostic=auditCommand(item,textEntries,entryIndex,entry.path(),scan);
                info.status=diagnostic.status;info.runtime=info.status==CommandStatus::Supported;
                commandDetail=diagnostic.detail;out.animationCommands.push_back(std::move(diagnostic));
            }
            else refineOccurrence(info,item,entry.path(),scan);
            ++out.commandStatusCounts[cmd][info.status];
            // Mixed occurrences remain conservatively PARTIAL in the summary;
            // the per-status counts and per-call audit show the exact split.
            auto prior=out.commandStatus.find(cmd);
            if(prior==out.commandStatus.end())out.commandStatus[cmd]=info.status;
            else if(prior->second!=info.status)prior->second=CommandStatus::Partial;
            CompatibilityIssue issue;
            issue.file=std::filesystem::relative(entry.path(),scan.root);
            issue.line=item.line;
            issue.command=cmd;
            issue.status=info.status;
            issue.parser=info.parser;
            issue.runtime=info.runtime;
            issue.message = commandDetail.empty()?(info.note?info.note:""):commandDetail;
            if(info.status==CommandStatus::Supported){ ++out.supportedCommands; ++out.recognizedCommands; continue; }
            if(info.status==CommandStatus::IgnoredSafely){ ++out.recognizedCommands; continue; }
            if(info.status==CommandStatus::Partial){ ++out.partialCommands; ++out.recognizedCommands; issue.level=CompatibilityLevel::Yellow; }
            else if(info.status==CommandStatus::Unsupported){ ++out.unsupportedCommands; ++out.recognizedCommands; issue.level=CompatibilityLevel::Red; }
            else { ++out.unknownCommands; issue.level=CompatibilityLevel::Yellow; issue.status=CommandStatus::Unknown; if(issue.message.empty()) issue.message="Uncatalogued command. Logged; conversion continues."; }
            out.issues.push_back(std::move(issue));
        }
    }
    return out;
}

const char* CompatibilityAnalyzer::levelName(CompatibilityLevel level){
    switch(level){case CompatibilityLevel::Green:return"GREEN";case CompatibilityLevel::Yellow:return"YELLOW";case CompatibilityLevel::Red:return"RED";}
    return"UNKNOWN";
}

void CompatibilityAnalyzer::writeReport(const ScanReport& scan, const CompatibilityReport& report, const std::filesystem::path& outDir){
    std::filesystem::create_directories(outDir);
    const double total = (double)std::max<std::size_t>(1, report.supportedCommands+report.partialCommands+report.unsupportedCommands+report.unknownCommands);
    auto pct=[&](std::size_t n){ return (int)(100.0*(double)n/total); };

    std::ofstream txt(outDir/"compatibility-report.txt");
    txt << "OPENBOR CONVERSION REPORT\n\n";
    txt << "Game: " << PathEncoding::utf8(scan.root.filename()) << "\n";
    txt << "Source: " << PathEncoding::utf8(scan.root) << "\n";
    txt << "OpenBOR hint: " << report.openborVersionHint << "\n";
    txt << "Logical resolution: " << report.logicalWidth << "x" << report.logicalHeight << "\n";
    txt << "Models: " << report.models << "\n";
    txt << "Stages: " << report.stages << "\n";
    txt << "Animations: " << report.animations << "\n";
    txt << "Scripts: " << report.scripts << "\n";
    txt << "Audio files: " << report.audioFiles << "\n";
    txt << "Text files: " << report.scannedTextFiles << "\n\n";
    txt << "Parser occurrences:\n";
    txt << "  SUPPORTED .... " << report.supportedCommands << " (" << pct(report.supportedCommands) << "%)\n";
    txt << "  PARTIAL ...... " << report.partialCommands << " (" << pct(report.partialCommands) << "%)\n";
    txt << "  UNSUPPORTED .. " << report.unsupportedCommands << "\n";
    txt << "  UNKNOWN ...... " << report.unknownCommands << "\n\n";
    txt << "Status means parser support AND runtime support. A parsed-but-not-executed command is PARTIAL.\n\n";
    txt << "Command registry:\n";
    for(const auto& [name,count]: report.commandUsage){
        auto st = report.commandStatus.count(name)? CommandRegistry::statusName(report.commandStatus.at(name)) : "UNKNOWN";
        txt << "  " << name << " x" << count << " -> " << st;
        auto counts=report.commandStatusCounts.find(name);if(counts!=report.commandStatusCounts.end()&&counts->second.size()>1){txt<<" (";bool first=true;for(const auto&[status,n]:counts->second){if(!first)txt<<", ";first=false;txt<<CommandRegistry::statusName(status)<<"="<<n;}txt<<")";}txt<<"\n";
    }
    txt << "\nIssues (file:line command impact):\n";
    for(const auto& issue: report.issues){
        txt << "  [" << CommandRegistry::statusName(issue.status) << "] "
            << PathEncoding::utf8(issue.file) << ":" << issue.line
            << " " << issue.command;
        if(!issue.message.empty()) txt << " - " << issue.message;
        txt << "\n";
    }

    std::ofstream cmdAudit(outDir/"animation-command-audit.txt");
    cmdAudit<<"ANIMATION COMMAND AUDIT\nPer-call diagnostics; no generic suppression of PARTIAL.\n\n";
    for(const auto& d:report.animationCommands)cmdAudit<<"["<<CommandRegistry::statusName(d.status)<<"] "<<PathEncoding::utf8(d.file)<<":"<<d.line<<" "<<d.detail<<"\n";

    std::ofstream json(outDir/"analysis.json");
    json << "{\n";
    json << "  \"game\": \"" << jsonEscape(PathEncoding::utf8(scan.root.filename())) << "\",\n";
    json << "  \"logicalWidth\": " << report.logicalWidth << ",\n";
    json << "  \"logicalHeight\": " << report.logicalHeight << ",\n";
    json << "  \"models\": " << report.models << ",\n";
    json << "  \"stages\": " << report.stages << ",\n";
    json << "  \"animations\": " << report.animations << ",\n";
    json << "  \"scripts\": " << report.scripts << ",\n";
    json << "  \"audioFiles\": " << report.audioFiles << ",\n";
    json << "  \"supported\": " << report.supportedCommands << ",\n";
    json << "  \"partial\": " << report.partialCommands << ",\n";
    json << "  \"unsupported\": " << report.unsupportedCommands << ",\n";
    json << "  \"unknown\": " << report.unknownCommands << ",\n";
    json << "  \"commands\": {\n";
    std::size_t i=0;
    for(const auto& [name,count]: report.commandUsage){
        auto st = report.commandStatus.count(name)? CommandRegistry::statusName(report.commandStatus.at(name)) : "UNKNOWN";
        json << "    \"" << jsonEscape(name) << "\": {\"count\": " << count << ", \"status\": \"" << st << "\", \"statusCounts\": {";
        auto counts=report.commandStatusCounts.find(name);bool first=true;if(counts!=report.commandStatusCounts.end())for(const auto&[status,n]:counts->second){if(!first)json<<", ";first=false;json<<"\""<<CommandRegistry::statusName(status)<<"\": "<<n;}json<<"}}";
        if(++i!=report.commandUsage.size()) json << ",";
        json << "\n";
    }
    json << "  }\n}\n";
}
