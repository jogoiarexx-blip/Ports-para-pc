# Validacao — OpenBOR Native Builder v0.34.21

## Regressao
- CMake/Ninja Linux: PASS.
- `ctest --output-on-failure`: 1/1 PASS.

## Evil Dead v1.4.0
Entrada: `Evil Dead v1.4.0 (2017) (Thatcher Productions)-Native-Port-Portable-Win64.zip`.
- `assets/openbor-data` descoberto automaticamente: PASS.
- Models: 125.
- Stages: 10.
- Supported: 14285.
- PARTIAL: 9 (includes referenciados mas ausentes do pacote enviado).
- Runtime C++ build: PASS.
- `--smoke-game --smoke-frames=300`: PASS / exit 0.

## GoW OpenBOR
Entrada fornecida como `gowopenbor.zip`, assinatura real RAR v4.
- Detectado como `rar-mislabeled-zip`: PASS.
- Extracao: PASS.
- Models: 18.
- Stages: 5.
- Supported: 2728.
- Runtime C++ build: PASS.
- `--smoke-game --smoke-frames=300`: PASS / exit 0.

## Cyber Robot
Baseado no relatorio de compatibilidade enviado pelo usuario:
- `skipselect` nao deve mais ser IGNORED_SAFELY; agora controla o fluxo do frontend.
- Corrigida a dupla leitura de Enter no Character Select.
- `sin`, `cos` e `sqrt` agora fazem parte do ScriptVM/analyzer, cobrindo a dependencia matematica observada em `enemy.c` e helpers relacionados.

## Pendencias de fidelidade
O runtime ainda nao reproduz pixel-a-pixel todo `menu.txt`/`select.txt`. Quando `skipselect=1`, a tela generica nao deve aparecer. Jogos que realmente usam selecao devem ser tratados em uma proxima etapa de fidelidade de frontend.
