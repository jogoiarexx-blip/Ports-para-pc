# Changelog — v0.34.22

## Levels / campanha
- `completebg` passa de metadata parcial para apresentacao nativa de `bgs/complete` antes da troca de fase.
- `completebg` pode ser definido antes do primeiro `set` e e herdado pelos sets seguintes; override por set e preservado.
- `noshare` passa a ser parseado e propagado em `LevelSetDef`, `StageDef`, `GeneratedStages` e `stage-data.json`.
- `noshare` continua PARTIAL porque o split individual de creditos/continues P1-P4 ainda nao esta completo.

## Spawns / palette
- `map N`, `colourmap`, `colormap` e `palette` continuam suportados.
- Novo recovery generico para shorthand `map1`, `map2`, ... sem argumento; o sufixo numerico vira o palette map do spawn.

## Movimento / IA
- `stealth` + `perception` sao lidos pelo parser e usados na aquisicao de alvo da IA e ScriptVM `findtarget`.
- `walkoffmove` ganha comportamento runtime para controle X/Z em queda natural de plataforma e passa a SUPPORTED.
- Knockdown/fall reactions nao recebem walkoff air control.

## Compatibilidade / analise
- `nocheats` e `nodebug` sao explicitamente `IGNORED_SAFELY`.
- Linhas iniciadas por `//` sao comentarios e nao comandos.
- Mantido aviso honesto para includes realmente ausentes; nenhum helper faltante e fabricado silenciosamente.

## Validacao
- ctest/regression: 1/1 PASS.
- runtime_effects, contacts, grabs, bindings, unicode, terrain, energy, commands, compatibility: PASS.
- GoW: convert + native runtime build + 300-frame smoke PASS.
- Evil Dead v1.4.0: convert + native runtime build + 300-frame smoke PASS.
