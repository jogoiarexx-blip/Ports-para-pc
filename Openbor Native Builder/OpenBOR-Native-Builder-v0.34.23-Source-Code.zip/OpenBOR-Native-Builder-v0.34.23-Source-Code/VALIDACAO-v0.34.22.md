# Validacao — OpenBOR Native Builder v0.34.22

## Builder
- Linux/Ninja build: PASS
- ctest: 1/1 PASS
- Runtime suites: 9/9 PASS

## GoW OpenBOR
- Input: arquivo `gowopenbor.zip` identificado por conteudo como RAR.
- SUPPORTED: 2744 (98%)
- PARTIAL: 41 (1%)
- UNSUPPORTED: 0
- UNKNOWN: 1 (`heatlh`, typo do source)
- `completebg`: SUPPORTED
- `map1`: SUPPORTED
- `stealth`: SUPPORTED
- `jumpspeed`: SUPPORTED
- `walkoffmove`: SUPPORTED
- Runtime C++ build: PASS
- `--smoke-game --smoke-frames=300`: PASS

## Evil Dead v1.4.0
- SUPPORTED: 14290 (99%)
- PARTIAL: 9
- UNSUPPORTED: 0
- UNKNOWN: 0
- Runtime C++ build: PASS
- `--smoke-game --smoke-frames=300`: PASS

## Pendencias honestas
- `noshare`: metadata preservado; pool de creditos por jogador ainda parcial.
- GoW referencia cinco includes de script que nao existem no pacote recebido. O Builder reporta a ausencia e nao cria codigo ficticio.

## Windows x64 CI
- GitHub Actions run: 37366761869
- Builder Win64/ClangCL: PASS
- Fixture v0.34.22 com `completebg`, `map1`, `noshare`, `skipselect`, `stealth` e `walkoffmove`: conversao PASS
- Runtime do jogo gerado Win64: build PASS
- `--diagnose`: PASS
- `--smoke-game --smoke-frames=300`: PASS
- Builder EXE SHA-256: `4ed1f31efa5d5271a52ab2ac3ca841e3034fb17e65d94b0670c6636434e10d98`
- Portable ZIP SHA-256: `fb65a76a689a1bc1418fc0d53e8ee6d96da3519ba81ac0168b13c51b7f5d27d3`
