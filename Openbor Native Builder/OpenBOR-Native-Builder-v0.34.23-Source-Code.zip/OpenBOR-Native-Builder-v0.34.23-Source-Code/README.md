# OpenBOR Native Builder v0.34.22

Versao focada em fidelidade de campanha/fase e nos gaps encontrados nos testes reais de Cyber Robot, Evil Dead e GoW.

## Melhorias principais

- `completebg` agora e propagado de `levels.txt` para o runtime e exibe `bgs/complete` antes da proxima fase, com fallback de texto quando o asset nao existe.
- `map1`, `map2`, etc. sao aceitos como shorthand legado de `map N` em spawns, preservando o palette map do inimigo/item.
- `stealth {stealth} {perception}` e aplicado pela IA e por `findtarget`: um alvo stealth so entra na selecao quando a percepcao do atacante permite.
- `walkoffmove` agora controla X/Z durante queda natural ao sair de plataformas; quedas por knockdown continuam sem esse controle.
- `nocheats` e `nodebug` sao classificados como `IGNORED_SAFELY`, pois o frontend nativo nao expoe os menus legados de cheat/debug.
- `noshare` e preservado no metadata de campanha/stage e no `stage-data.json`. O split completo de creditos/continues por jogador ainda permanece `PARTIAL`.
- Comentarios `//` nao entram mais no banco de comandos.
- Mantidas as melhorias da v0.34.21: multiplos `set` como campanhas, `skipselect`, background/animacao `select`, helpers de include, `jumpspeed`/`walkoffmove` e frontend legado.
- Mantidas as correcoes da v0.34.20/v0.34.19: RAR por assinatura, ports `assets/openbor-data` como entrada, status separado de conversao/build, smoke gameplay, Save V2, safe spawn e recuperacao D3D11 -> GDI.

## Validacao real

- Regression/ctest: PASS.
- 9 suites de runtime: PASS.
- GoW: 2.744 SUPPORTED, 41 PARTIAL, 0 UNSUPPORTED, 1 UNKNOWN (`heatlh`, typo existente no arquivo do jogo); runtime compilado e smoke de 300 frames PASS.
- Evil Dead v1.4.0: 14.290 SUPPORTED, 9 PARTIAL, 0 UNSUPPORTED, 0 UNKNOWN; runtime compilado e smoke de 300 frames PASS.

## Limites conhecidos

- `noshare`: metadata preservado, mas creditos/continues ainda usam o pool compartilhado do runtime nativo.
- GoW possui includes de scripts que nao estao presentes no pacote (`library/spawn.h`, `library/basic.h`, `library/target.h`, `levelup/lvup.c`, `pblock.c`). Eles continuam reportados como PARTIAL em vez de serem inventados pelo Builder.
- `heatlh` e mantido como UNKNOWN por ser um typo no arquivo de origem; o Builder nao o corrige silenciosamente para `health`.
