# Validacao — OpenBOR Native Builder v0.34.23

## Builder / regressao
- Linux/Ninja build: PASS
- ctest: 1/1 PASS
- Runtime suites: 9/9 PASS

## Multiplayer / Save V3
- `noshare 1`: P2 consome somente a propria vida: PASS
- `noshare 1`: P2 consome somente o proprio credito e recarrega suas vidas: PASS
- `noshare 0`: P2 continua usando o pool compartilhado: PASS
- Save V3 `joined_mask`: P1+P3 restaurados sem inventar P2: PASS
- Save V3 estado morto: P3 eliminado permanece morto ao carregar: PASS
- Save V3 vidas/creditos independentes de P3: PASS

## GoW OpenBOR
- Input `.zip` identificado por conteudo como RAR: PASS
- SUPPORTED: 2745 (98%)
- PARTIAL: 40 (1%)
- UNSUPPORTED: 0
- UNKNOWN: 1 (`heatlh`, typo do source)
- `noshare`: SUPPORTED
- `walkoffmove`: SUPPORTED
- `completebg`, `map1`, `stealth`, `jumpspeed`: SUPPORTED
- Runtime C++ build: PASS
- `--smoke-game --smoke-frames=300`: PASS

## Evil Dead v1.4.0
- SUPPORTED: 14290 (99%)
- PARTIAL: 9
- UNSUPPORTED: 0
- UNKNOWN: 0
- Runtime C++ build: PASS
- `--smoke-game --smoke-frames=300`: PASS

## Script helper fallback
- `spawn01`: native relative spawn + direction mirror: PASS
- `spawn01map`: native relative spawn + palette copy: PASS
- Missing includes remain diagnostics instead of being hidden.

## Windows x64
- GitHub Actions run: `37372920298`: PASS
- Builder Win64 ClangCL: PASS
- Fixture `noshare 1` + Save V3: conversion/report checks PASS
- Generated game Win64 build: PASS
- `--diagnose`: PASS (`DIAGNOSE OK`)
- `--smoke-game --smoke-frames=300`: PASS (`SMOKE GAME OK frames=300`)
- Executavel: PE32+ x86-64
- Imports: KERNEL32.dll, SHELL32.dll, USER32.dll, ole32.dll, COMDLG32.dll
- SHA-256 Builder EXE: `b7edcc052c23d1bd8d1f850950d9e4e6672cb75c4b6f12eeb9f693399aeaf9ab`
- SHA-256 Portable ZIP: `22b3700cc9dbaf82f10b027fbddb5da70aea6fd2351faf1824c4102ac64ddc0b`
