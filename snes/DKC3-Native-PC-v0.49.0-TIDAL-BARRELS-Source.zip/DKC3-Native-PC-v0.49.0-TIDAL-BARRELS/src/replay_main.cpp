#include "core/NativeReplay.h"
#include "core/LevelSession.h"
#include "core/NativeScene.h"
#include "core/input_recording.h"
#include <fstream>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <vector>
int main(int argc,char**argv){using namespace dkc3;
 if(argc<4||argc>5){std::cerr<<"Usage: dkc3_native_replay boat|game input.txt trace.csv [level-id]\n";return 2;}
 const std::string mode=argv[1];if(mode!="boat"&&mode!="game")return 2;
 NativeReplay replay;std::string error;if(!replay.load(argv[2],error)){std::cerr<<error<<"\n";return 3;}
 std::ofstream out(argv[3]);if(!out){std::cerr<<"Unable to write trace\n";return 4;}
 GameSession session;WorldMap map;
 if(mode=="boat"){if(!map.init({},"rom/dkc3_ptbr.sfc"))return 5;map.setRuntimeAvailableMask(WorldMap::stageBit("lakeside-limbo"));}
 else if(!session.init("assets/levels/levels.index",argc==5?argv[4]:"lakeside-limbo"))return 5;
 out<<"frame,mask,mode,x,y,vx,vy,grounded,area,level,framehash,wall,air_wall,ground_follow\n"<<std::setprecision(9);
 Dkc3InputRecorder recorder{};char recordError[256]{};
 const char* recordPath=std::getenv("DKC3_NATIVE_INPUT_REC");
 if(recordPath&&!Dkc3InputRecorderOpen(&recorder,recordPath,recordError,sizeof recordError)){std::cerr<<recordError<<"\n";return 7;}
 std::vector<uint32_t> pixels(256*224);
 for(size_t i=0;i<replay.count();++i){const auto mask=replay.frame(i);
  if(recordPath&&!Dkc3InputRecorderWrite(&recorder,mask,recordError,sizeof recordError)){std::cerr<<recordError<<"\n";Dkc3InputRecorderClose(&recorder,nullptr,0);return 7;}
  float x=0,y=0,vx=0,vy=0;bool ground=false;int area=-1;unsigned wall=0,air=0,follow=0;std::string level;
  if(mode=="boat"){map.step(nativeMapInputFromSnes(mask),1.f/60);map.render(pixels.data(),256,224);x=map.state().boatX;y=map.state().boatY;area=static_cast<int>(map.area());level=map.currentLevel();}
  else{session.step(nativeInputFromSnes(mask),1.f/60);session.render(pixels.data(),256,224);const auto&p=session.game().player();x=p.pos.x;y=p.pos.y;vx=p.vel.x;vy=p.vel.y;ground=p.grounded;wall=p.nativeWallHits;air=p.nativeAirWallHits;follow=p.nativeGroundFollows;level=session.currentLevel();}
  out<<i<<','<<std::hex<<mask<<std::dec<<','<<mode<<','<<x<<','<<y<<','<<vx<<','<<vy<<','<<ground<<','<<area<<','<<level<<','<<std::hex<<hashFrame(pixels.data(),pixels.size())<<std::dec<<','<<wall<<','<<air<<','<<follow<<'\n';
 }
 if(recordPath&&!Dkc3InputRecorderClose(&recorder,recordError,sizeof recordError)){std::cerr<<recordError<<"\n";return 7;}
 if(!out){std::cerr<<"Trace write failed\n";return 6;}
 std::cout<<"NATIVE_REPLAY_OK mode="<<mode<<" frames="<<replay.count()<<"\n";return 0;
}
