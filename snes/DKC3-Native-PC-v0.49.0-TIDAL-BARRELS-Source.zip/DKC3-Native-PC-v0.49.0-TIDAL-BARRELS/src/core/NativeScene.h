#pragma once
#include <cstdint>
#include <string>
#include <vector>
namespace dkc3 {
struct NativeTileSet { int bpp=0; uint32_t tileCount=0; std::vector<uint8_t> pixels; };
struct NativeTileMap { int width=0,height=0; std::vector<uint16_t> entries; };
struct NativeLayer { std::string name; int bpp=0; int scrollX=0,scrollY=0; bool enabled=false; NativeTileSet tiles; NativeTileMap map; };
struct NativeScene { int mode=1; bool bg3Priority=false; uint8_t tm=0,ts=0,cgwsel=0,cgadsub=0; uint16_t fixedColor=0; int brightness=15; int viewportW=256,viewportH=224; int backdrop=0; std::vector<uint16_t> palette; std::vector<NativeLayer> layers; };
bool loadNativeScene(const std::string& path, NativeScene& out);
void renderNativeScene(const NativeScene& s, uint32_t* dst, int w, int h, int cameraX=0, int cameraY=0);
uint64_t hashFrame(const uint32_t* pixels, size_t count);
}
