#pragma once
#include "RomData.h"
namespace dkc3 {
enum class RomObjectBehavior { Unknown, Sneek, Kobble, BearCoin, Banana, LifeBalloon,
  KongLetter, Checkpoint, EndFlag, BarrelCannon, TeamBarrel };
struct RomObjectDefinition {
  uint16_t spriteId;
  RomObjectBehavior behavior;
  RomSupport support;
  const char* name;
  const char* limitation;
};
const RomObjectDefinition& findRomObject(uint16_t spriteId);
RomObjectBehavior romObjectBehavior(uint16_t spriteId);
struct RomSpawnRecord {
  size_t placementIndex;
  RomLevelPlacement placement;
  RomObjectDefinition definition;
};
class RomSpawnRuntime {
 public:
  void build(const std::vector<RomLevelPlacement>& placements);
  const std::vector<RomSpawnRecord>& records() const { return records_; }
  size_t count(RomSupport support) const;
  std::string report() const;
 private:
  std::vector<RomSpawnRecord> records_;
};
}
