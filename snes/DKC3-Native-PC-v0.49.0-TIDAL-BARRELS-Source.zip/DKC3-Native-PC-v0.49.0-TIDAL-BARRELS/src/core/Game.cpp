#include "Game.h"
#include "RomObjectRuntime.h"
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cctype>
namespace dkc3 {
static void approach(float&v,float target,float amount){if(v<target)v=std::min(v+amount,target);else if(v>target)v=std::max(v-amount,target);}
static void drawAnim(const NativeAnimation* a,const AnimationPlayer& p,uint32_t*dst,int w,int h,int x,int y,bool flip){
  if(!a)return;
  auto*f=p.current(*a);if(!f)return;drawNativeSprite(f->sprite,dst,w,h,x+f->offsetX,y+f->offsetY,flip);
}
static NativeAnimation romWalkAnimation(const std::vector<RomSpriteFrame>& frames,float duration,int hitW,int hitH,int anchorBelowSurface){
  NativeAnimation a;a.loop=true;a.frames.reserve(frames.size());
  for(const auto& rf:frames){
    AnimationFrame f;f.duration=duration;f.sprite.width=rf.width;f.sprite.height=rf.height;f.sprite.originX=0;f.sprite.originY=0;f.sprite.bgra=rf.pixels;
    // RuntimeEnemy::pos e o canto superior esquerdo do hitbox. Os frames da
    // ROM usam um anchor interno; estes offsets preservam o anchor authored.
    f.offsetX=hitW/2-rf.anchorX;f.offsetY=hitH+anchorBelowSurface-rf.anchorY;a.frames.push_back(std::move(f));
  }
  return a;
}
static NativeAnimation romCenteredAnimation(const std::vector<RomSpriteFrame>& frames,float duration,int hitW,int hitH){
  NativeAnimation a;a.loop=true;a.frames.reserve(frames.size());
  for(const auto& rf:frames){
    AnimationFrame f;f.duration=duration;f.sprite.width=rf.width;f.sprite.height=rf.height;f.sprite.originX=0;f.sprite.originY=0;f.sprite.bgra=rf.pixels;
    f.offsetX=hitW/2-rf.anchorX;f.offsetY=hitH/2-rf.anchorY;a.frames.push_back(std::move(f));
  }
  return a;
}
static NativeAnimation romSingleCenteredFrame(const RomSpriteFrame& rf,int hitW,int hitH){
  NativeAnimation a;a.loop=true;AnimationFrame f;f.duration=1.0f;f.sprite.width=rf.width;f.sprite.height=rf.height;f.sprite.originX=0;f.sprite.originY=0;f.sprite.bgra=rf.pixels;
  f.offsetX=hitW/2-rf.anchorX;f.offsetY=hitH/2-rf.anchorY;a.frames.push_back(std::move(f));return a;
}
static const RomCollisionRect* nearestPlatform(const RomLevelRuntime& rom,float anchorX,float expectedY,float maxDY=20.0f){
  const RomCollisionRect* best=nullptr;float bestScore=1.0e9f;
  for(const auto& r:rom.collisionRects()){
    if(anchorX<(float)r.x-12.0f||anchorX>(float)(r.x+r.width)+12.0f)continue;
    const float dy=std::fabs((float)r.y-expectedY);if(dy>maxDY)continue;
    const float dx=anchorX<(float)r.x?(float)r.x-anchorX:(anchorX>(float)(r.x+r.width)?anchorX-(float)(r.x+r.width):0.0f);
    const float score=dy*4.0f+dx;if(score<bestScore){bestScore=score;best=&r;}
  }
  return best;
}
static BarrelCannonRole barrelRole(uint16_t type){
  switch(type){
    case 0x0140:return BarrelCannonRole::WarpEntry;
    case 0x0142:return BarrelCannonRole::WarpExit;
    case 0x0148:return BarrelCannonRole::BonusEntry1;
    case 0x0152:return BarrelCannonRole::BonusExit1;
    case 0x014a:return BarrelCannonRole::BonusEntry2;
    case 0x0154:return BarrelCannonRole::BonusExit2;
    default:return BarrelCannonRole::Unknown;
  }
}
static bool barrelIsExit(BarrelCannonRole r){return r==BarrelCannonRole::WarpExit||r==BarrelCannonRole::BonusExit1||r==BarrelCannonRole::BonusExit2;}
static bool barrelIsBonusEntry(BarrelCannonRole r){return r==BarrelCannonRole::BonusEntry1||r==BarrelCannonRole::BonusEntry2;}
bool Game::loadAnimationMap(const std::vector<AnimationDef>&defs,std::map<std::string,NativeAnimation>&out){
  out.clear();for(const auto&d:defs){NativeAnimation a;if(!loadNativeAnimation(d.path,a))return false;out[d.state]=std::move(a);}return true;
}
const NativeAnimation* Game::findAnim(const std::map<std::string,NativeAnimation>&set,const std::string&key)const{
  auto i=set.find(key);if(i!=set.end())return &i->second;i=set.find("idle");return i==set.end()?nullptr:&i->second;
}
bool Game::ensureScenePageLoaded(size_t index){
  if(index>=scenePages_.size())return false;
  auto& p=scenePages_[index];
  if(p.loaded)return true;
  NativeScene next;
  if(!loadNativeScene(p.path,next))return false;
  p.scene=std::move(next);p.loaded=true;
  return true;
}
bool Game::prefetchSceneWindow(size_t center){
  if(scenePages_.empty()||center>=scenePages_.size())return true;
  if(!ensureScenePageLoaded(center))return false;
  if(center>0&&!ensureScenePageLoaded(center-1))return false;
  if(center+1<scenePages_.size()&&!ensureScenePageLoaded(center+1))return false;
  return true;
}
void Game::trimScenePageCache(){
  if(scenePages_.empty())return;
  for(size_t i=0;i<scenePages_.size();++i){
    const bool neighbor=(i==activeScenePage_)||(i+1==activeScenePage_)||(activeScenePage_+1==i);
    const bool fading=pageFade_<1.0f&&i==fadeFromPage_;
    if(scenePages_[i].loaded&&!neighbor&&!fading){scenePages_[i].scene=NativeScene{};scenePages_[i].loaded=false;}
  }
}
const std::map<std::string,NativeAnimation>& Game::activeAnimations()const{return activeCharacter_==CharacterId::Dixie?dixieAnimations_:kiddyAnimations_;}
const std::map<std::string,NativeAnimation>& Game::inactiveAnimations()const{return activeCharacter_==CharacterId::Dixie?kiddyAnimations_:dixieAnimations_;}
const NativeSprite& Game::activeFallbackSprite()const{return activeCharacter_==CharacterId::Dixie?playerSprite_:companionSprite_;}
const NativeSprite& Game::inactiveFallbackSprite()const{return activeCharacter_==CharacterId::Dixie?companionSprite_:playerSprite_;}
void Game::setPlayerAnimationState(const std::string&state){if(state!=playerAnimState_){playerAnimState_=state;playerAnimator_.reset();}}
void Game::applyCharacterDimensions(){
  player_.nativeMotion=hasRomScene_?(activeCharacter_==CharacterId::Dixie?dixieMotion_:kiddyMotion_):RomMotionProfile{};
  if(activeCharacter_==CharacterId::Dixie){player_.width=18.0f;player_.height=34.0f;}
  else{player_.width=23.0f;player_.height=38.0f;}
}
void Game::switchCharacter(bool manualSwitch){
  if(!partnerAvailable_)return;
  const float feet=player_.pos.y+player_.height;
  activeCharacter_=activeCharacter_==CharacterId::Dixie?CharacterId::Kiddy:CharacterId::Dixie;
  applyCharacterDimensions();player_.pos.y=feet-player_.height;
  playerAnimator_.reset();companionAnimator_.reset();
  if(manualSwitch){++characterSwitches_;emit(Sfx::Switch);}
}
float Game::attackDuration() const { return activeCharacter_==CharacterId::Dixie ? 0.416f : 0.420f; }
float Game::attackReach() const { return activeCharacter_==CharacterId::Dixie ? 28.0f : 34.0f; }
bool Game::attackActive() const {
  if(attackTimer_<=0.0f)return false;
  const float elapsed=attackDuration()-attackTimer_;
  return elapsed>=0.045f && attackTimer_>=0.045f;
}
Rect Game::attackBounds() const {
  const float reach=attackReach();
  const float h=activeCharacter_==CharacterId::Dixie ? 25.0f : 30.0f;
  const float y=player_.pos.y+std::max(2.0f,(player_.height-h)*0.65f);
  if(player_.facingRight)return {player_.pos.x+player_.width-3.0f,y,reach,h};
  return {player_.pos.x-reach+3.0f,y,reach,h};
}
bool Game::leverActivated(const std::string& id)const{for(const auto&l:levers_)if(l.id==id)return l.activated;return false;}
void Game::activateLever(size_t index){
  if(index>=levers_.size()||levers_[index].activated)return;
  auto&l=levers_[index];l.activated=true;l.progress=l.holdTime;++leverActivations_;showToast("PORTAO ABERTO");emit(Sfx::Lever);
  for(auto&g:gates_)if(g.id==l.gateId)g.open=true;
}
void Game::applyDamage(float enemyCenterX){
  if(invulnerableTimer_>0.0f)return;
  dropCarriedBarrel();
  ++damageCount_;emit(Sfx::Hurt);
  if(partnerAvailable_){
    switchCharacter(false);
    partnerAvailable_=false;
    player_.vel.x=(player_.pos.x+player_.width*0.5f<enemyCenterX)?-115.0f:115.0f;
    player_.vel.y=-155.0f;player_.grounded=false;player_.motion=PlayerMotion::Air;
    invulnerableTimer_=1.35f;
  }else{
    lives_=std::max(0,lives_-1);
    showToast(lives_>0?"VIDA -1":"GAME OVER",1.0f);
    player_.pos=respawn_;
    if(activeCharacter_==CharacterId::Kiddy)player_.pos.y-=4.0f; // respawn e authored para os pes de Dixie (34px)
    player_.vel={};player_.motion=PlayerMotion::Air;player_.grounded=false;
    partnerAvailable_=true;companionPos_={player_.pos.x+world_.companionOffset.x,player_.pos.y+world_.companionOffset.y};invulnerableTimer_=1.0f;
  }
}
void Game::breakTeamBarrel(size_t index,bool rescue){
  if(index>=teamBarrels_.size())return;auto& b=teamBarrels_[index];if(!b.active)return;
  b.active=false;b.state=CarryBarrelState::Broken;b.velocity={};b.remainder=0;++barrelBreaks_;
  if(carriedBarrel_==static_cast<int>(index))carriedBarrel_=-1;
  spriteEffect("smoke",{b.pos.x+b.w*.5f,b.pos.y+b.h*.5f});emit(Sfx::EnemyHit);
  if(rescue&&!partnerAvailable_){partnerAvailable_=true;++teamBarrelRescues_;
    companionPos_={player_.pos.x+world_.companionOffset.x,player_.pos.y+world_.companionOffset.y};emit(Sfx::Switch);showToast("DUPLA RESTAURADA");}
}
void Game::dropCarriedBarrel(){
  if(carriedBarrel_<0)return;auto& b=teamBarrels_[static_cast<size_t>(carriedBarrel_)];
  b.state=CarryBarrelState::Dropped;b.velocity={};b.age=0;b.remainder=0;carriedBarrel_=-1;
}
bool Game::handleCarryBarrelInput(const InputState& in,bool attackPressed){
  if(barrelReleaseBlocked_){if(!in.attack)barrelReleaseBlocked_=false;return false;}
  if(carryingBarrel()){
    if(in.left!=in.right)player_.facingRight=in.right;
    auto& b=teamBarrels_[static_cast<size_t>(carriedBarrel_)];
    if(in.down&&in.attack&&player_.grounded){
      b.pos={player_.facingRight?player_.pos.x+player_.width+2.f:player_.pos.x-b.w-2.f,player_.pos.y+player_.height-b.h};dropCarriedBarrel();barrelReleaseBlocked_=true;return true;
    }
    if(!in.attack){
      b.state=CarryBarrelState::Thrown;b.velocity={player_.facingRight?280.f:-280.f,-100.f};b.age=0;b.remainder=0;carriedBarrel_=-1;++barrelThrows_;emit(Sfx::Roll);return true;
    }
    return true;
  }
  if(!in.attack||!player_.grounded||player_.motion!=PlayerMotion::Ground)return false;
  const auto pb=player_.bounds();const Rect reach{pb.x-9.f,pb.y-4.f,pb.w+18.f,pb.h+8.f};
  for(size_t i=0;i<teamBarrels_.size();++i){auto& b=teamBarrels_[i];
    if(b.active&&b.state==CarryBarrelState::Resting&&overlaps(reach,b.bounds())){
      if(!partnerAvailable_){breakTeamBarrel(i);return true;}
      carriedBarrel_=static_cast<int>(i);b.state=CarryBarrelState::Carried;b.velocity={};b.remainder=0;attackTimer_=0;++barrelPickups_;emit(Sfx::Switch);return true;}
  }
  (void)attackPressed;return false;
}
void Game::stepCarryBarrels(float dt){
  std::vector<Rect> solids=world_.solids;for(const auto& g:gates_)if(!g.open)solids.push_back(g.rect);
  if(carryingBarrel()){
    auto& b=teamBarrels_[static_cast<size_t>(carriedBarrel_)];
    b.pos={player_.facingRight?player_.pos.x+player_.width-3.f:player_.pos.x-b.w+3.f,player_.pos.y+player_.height-b.h-7.f};
    if(inWater_||player_.motion==PlayerMotion::Hang)dropCarriedBarrel();
  }
  if(carryingBarrel()){
    const size_t index=static_cast<size_t>(carriedBarrel_);const auto& b=teamBarrels_[index];
    for(auto& e:enemies_)if(e.active&&overlaps(b.bounds(),e.bounds())){
      e.active=false;++defeatedEnemies_;++barrelEnemyHits_;spriteEffect(e.id=="rom-kobble"?"kobble-death":"smoke",e.id=="rom-kobble"?e.pos:Vec2{e.pos.x+e.w*.5f,e.pos.y+e.h*.5f},!e.facingRight);breakTeamBarrel(index);break;
    }
    if(teamBarrels_[index].active){
      bool blocked=false;for(const auto& solid:solids)blocked|=overlaps(b.bounds(),solid);
      if(hasRomScene_)for(int y=static_cast<int>(b.pos.y)+1;y<static_cast<int>(b.pos.y+b.h)-1;++y)
        blocked|=romLakeside_.terrain().solidBodyPoint(static_cast<int>(b.pos.x+(player_.facingRight?b.w-1:0)),y);
      if(blocked)breakTeamBarrel(index);
    }
  }
  for(size_t i=0;i<teamBarrels_.size();++i){auto& b=teamBarrels_[i];if(!b.active)continue;
    // Process one native tick at a time so enemy sweeps cannot hit behind a wall.
    float remaining=std::max(0.f,dt);
    while(remaining>0&&b.active){const float slice=std::min(remaining,1.f/60.f);remaining-=slice;
      const auto previous=b.pos;const auto impact=advanceCarryBarrel(b,slice,solids,world_.oneWayPlatforms,hasRomScene_?&romLakeside_.terrain():nullptr,world_.width,world_.height);
      if(b.state==CarryBarrelState::Thrown){const auto sweep=carryBarrelSweepBounds(b,previous);
        for(auto& e:enemies_)if(e.active&&overlaps(sweep,e.bounds())){
          e.active=false;++defeatedEnemies_;++barrelEnemyHits_;spriteEffect(e.id=="rom-kobble"?"kobble-death":"smoke",e.id=="rom-kobble"?e.pos:Vec2{e.pos.x+e.w*.5f,e.pos.y+e.h*.5f},!e.facingRight);breakTeamBarrel(i);break;}
      }
      if(b.active&&impact!=CarryBarrelImpact::None)breakTeamBarrel(i,impact!=CarryBarrelImpact::Outside);
    }
  }
}
void Game::spriteEffect(const std::string& name,Vec2 pos,bool flip){
  if(spriteEffects_.size()<32 && suppliedSprites_.animation(name))spriteEffects_.push_back({name,pos,{},flip});
}
void Game::emit(Sfx s){
  if(sfx_.size()<64)sfx_.push_back(s);
  if(s==Sfx::Coin)spriteEffect("pickup-spark",{player_.pos.x+player_.width*.5f,player_.pos.y+player_.height*.5f});
}
std::string Game::desiredPlayerAnimation()const{
  if(activeCharacter_==CharacterId::Kiddy && invulnerableTimer_>1.12f)return "hit";
  if(player_.motion==PlayerMotion::Hang)return "hang";
  if(player_.motion==PlayerMotion::Swim)return "swim";
  if(!carryingBarrel()&&attackTimer_>0.0f)return "attack";
  if(!player_.grounded)return player_.vel.y<0?"jump":"fall";
  if(std::fabs(player_.vel.x)>12.0f)return "run";
  if(activeCharacter_==CharacterId::Kiddy && crouchVisual_)return "duck";
  return "idle";
}
bool Game::init(const char* p,const GamePersistentState* persistent){
  spriteEffects_.clear();crouchVisual_=false;carriedBarrel_=-1;barrelPickups_=barrelThrows_=barrelBreaks_=barrelEnemyHits_=0;barrelReleaseBlocked_=false;
  if(!suppliedSprites_.load() || !loadBmp32("assets/sprites/dkc3/screens/game-over.bmp",gameOverImage_))return false;
  romSpawnRuntime_.build({});
  if(!loadWorld(p,world_))return false;
  scenePages_.clear();activeScenePage_=0;hasScene_=false;hasRomScene_=false;
  if(!world_.romScene.empty()){
    if((world_.romScene!="lakeside-limbo"&&world_.romScene!="tidal-trouble")||!romLakeside_.load(RomLevelRequest{static_cast<uint16_t>(world_.originalLevelId),static_cast<uint16_t>(world_.originalMetadata.sharedData),static_cast<uint8_t>(world_.originalMetadata.submap)}))return false;
    if(world_.originalLevelId==0x25&&(!romBonus1_.load(1)||!romBonus2_.load(2)))return false;
    // ROM spawn point is the original foot word, never a captured-screen position.
    const auto spawn=romLakeside_.startPoint();world_.spawn={static_cast<float>(spawn.first),static_cast<float>(spawn.second-34)};
    romSpawnRuntime_.build(romLakeside_.placements());
    hasRomScene_=true;
    if(!loadRomMotionProfiles(romLakeside_.romInfo().path,dixieMotion_,kiddyMotion_))return false;
    // Terrain surfaces and water height come from ROM definitions.
    // Collision response remains the host one-way/platform controller.
    world_.width=romLakeside_.width();
    world_.height=romLakeside_.height();
    world_.cameraBounds={0,0,(float)world_.width,(float)world_.height};
    world_.solids.clear();world_.oneWayPlatforms.clear();world_.waterZones.clear();
    for(const auto& r:romLakeside_.collisionRects())
      world_.oneWayPlatforms.push_back({(float)r.x,(float)r.y,(float)r.width,(float)r.height});
    // Host swimming still uses rectangle overlap, not the original foot/state query.
    world_.waterZones.push_back({0.0f,(float)romLakeside_.waterSurfaceY()+1.0f,(float)world_.width,(float)(world_.height-romLakeside_.waterSurfaceY()-1)});
    if(world_.originalLevelId==0x27){world_.waterCurrents.clear();world_.waterCurrents.push_back({world_.waterZones.front(),{-32,0}});}

    // Placements da ROM: o bytecode Spawn Script resolve o Sprite ID real.
    // Nesta etapa ativamos apenas os tipos cujo comportamento/grafico nativo ja
    // existe no motor; os demais continuam preservados em RomData para os proximos passes.
    world_.enemies.clear();
    for(const auto& p:romLakeside_.placements())if(romObjectBehavior(p.spriteId)==RomObjectBehavior::Sneek){ // Sneek
      const float anchorX=(float)((int)p.x-0x100),expectedSurface=(float)((int)p.y-0x100-9);
      const auto* platform=nearestPlatform(romLakeside_,anchorX,expectedSurface);if(!platform)continue;
      constexpr float w=22.0f,h=22.0f;const float left=(float)platform->x,right=(float)(platform->x+platform->width)-w;
      const float x=std::clamp(anchorX-w*0.5f,left,std::max(left,right));const float y=(float)platform->y-h;
      world_.enemies.push_back({"rom-sneek",{x,y},-24.0f,left,std::max(left,right),"assets/levels/tidal-trouble/native/enemies/sneek.nanim",w,h});
    }
    // SpriteID $03C8 e a familia Skidda/Kobble. Em Lakeside os seis placements
    // usam o Kobble; os oito frames de caminhada e a paleta sao lidos direto
    // da ROM. O bit $0100 do parametro preserva as duas orientacoes authored.
    for(const auto& p:romLakeside_.placements())if(romObjectBehavior(p.spriteId)==RomObjectBehavior::Kobble){
      const float anchorX=(float)((int)p.x-0x100),expectedSurface=(float)((int)p.y-0x100-9);
      const auto* platform=nearestPlatform(romLakeside_,anchorX,expectedSurface);if(!platform)continue;
      constexpr float w=24.0f,h=36.0f;const float left=(float)platform->x,right=(float)(platform->x+platform->width)-w;
      const float x=std::clamp(anchorX-w*0.5f,left,std::max(left,right));const float y=(float)platform->y-h;
      const float speed=(p.parameter&0x0100u)?34.0f:-34.0f;
      world_.enemies.push_back({"rom-kobble",{x,y},speed,left,std::max(left,right),"@rom:kobble",w,h});
    }
    // v0.32: os collectibles cujo Sprite ID resolve de forma unica saem da
    // lista de placements e entram no runtime nas coordenadas authored.
    world_.collectibles.clear();
    for(const auto& p:romLakeside_.placements()){
      const float x=(float)((int)p.x-0x100),y=(float)((int)p.y-0x100);
      if(romObjectBehavior(p.spriteId)==RomObjectBehavior::BearCoin)world_.collectibles.push_back({"rom-bear-coin",{x-10.0f,y-10.0f},"@rom:bearcoin",20,20,1});
      else if(romObjectBehavior(p.spriteId)==RomObjectBehavior::Banana)world_.collectibles.push_back({"rom-banana",{x-8.0f,y-8.0f},"@rom:banana",16,16,1});
      else if(romObjectBehavior(p.spriteId)==RomObjectBehavior::LifeBalloon)world_.collectibles.push_back({"rom-life-balloon",{x-12.0f,y-18.0f},"@rom:life-balloon",24,36,1});
    }
    // The descriptor scripts $64C5/$64D5/$64E5/$64F5 set masks 1/2/4/8.
    // Letter identity must not change when an earlier placement is absent.
    world_.kongLetters.clear();
    for(const auto& p:romLakeside_.placements())if(romObjectBehavior(p.spriteId)==RomObjectBehavior::KongLetter){
      char letter=0;switch(p.descriptor){case 0x64c5:letter='K';break;case 0x64d5:letter='O';break;case 0x64e5:letter='N';break;case 0x64f5:letter='G';break;}
      if(!letter)continue;
      const float x=static_cast<float>(p.x-256)-8.f,y=static_cast<float>(p.y-256)-8.f;
      world_.kongLetters.push_back({letter,{x,y},std::string("@rom:kong:")+letter,16,16});
    }
    world_.teamBarrels.clear();
    for(const auto& p:romLakeside_.placements())if(romObjectBehavior(p.spriteId)==RomObjectBehavior::TeamBarrel)
      world_.teamBarrels.push_back({"rom-dk-barrel",{static_cast<float>(p.x-256)-15.f,static_cast<float>(p.y-256)-19.f},"assets/levels/tidal-trouble/native/entities/dk_barrel.nspr",30,38});
    // Checkpoint e bandeira final tambem deixam de depender de coordenadas inventadas.
    for(const auto& p:romLakeside_.placements()){
      const float x=(float)((int)p.x-0x100);
      if(romObjectBehavior(p.spriteId)==RomObjectBehavior::Checkpoint){
        const auto checkpoint=romLakeside_.checkpointPoint();
        world_.checkpoints.clear();world_.checkpoints.push_back({{x-24.0f,0.0f,64.0f,(float)world_.height},{static_cast<float>(checkpoint.first),static_cast<float>(checkpoint.second-34)}});
      }else if(romObjectBehavior(p.spriteId)==RomObjectBehavior::EndFlag){const std::string target=world_.goals.empty()?"doorstop":world_.goals.front().target;world_.goals.clear();world_.goals.push_back({{x-16.0f,0.0f,96.0f,(float)world_.height},target});}
    }
  }else if(!world_.nativeScenePages.empty()){
    for(const auto&d:world_.nativeScenePages){RuntimeScenePage p;p.startX=d.startX;p.path=d.path;scenePages_.push_back(std::move(p));}
    std::sort(scenePages_.begin(),scenePages_.end(),[](const auto&a,const auto&b){return a.startX<b.startX;});
    if(scenePages_.empty()||!ensureScenePageLoaded(0))return false;
    hasScene_=true;
  }else if(!world_.nativeScene.empty()){hasScene_=loadNativeScene(world_.nativeScene,scene_);if(!hasScene_)return false;}
  mainWorld_=world_;
  player_={};player_.pos=world_.spawn;respawn_=world_.spawn;
  activeCharacter_=persistent?persistent->activeCharacter:CharacterId::Dixie;partnerAvailable_=persistent?persistent->partnerAvailable:true;applyCharacterDimensions();
  if(activeCharacter_==CharacterId::Kiddy)player_.pos.y-=4.0f;
  companionPos_={player_.pos.x+world_.companionOffset.x,player_.pos.y+world_.companionOffset.y};
  const NativeScene& initialScene=scenePages_.empty()?scene_:scenePages_[0].scene;camera_.viewportW=hasScene_?initialScene.viewportW:256;camera_.viewportH=hasScene_?initialScene.viewportH:224;
  camera_.x=std::clamp(player_.pos.x-camera_.viewportW*0.5f,world_.cameraBounds.x,std::max(world_.cameraBounds.x,world_.cameraBounds.x+world_.cameraBounds.w-camera_.viewportW));
  camera_.y=std::clamp(player_.pos.y-camera_.viewportH*0.5f,world_.cameraBounds.y,std::max(world_.cameraBounds.y,world_.cameraBounds.y+world_.cameraBounds.h-camera_.viewportH));
  if(!scenePages_.empty()){
    size_t initialPage=0;for(size_t i=1;i<scenePages_.size();++i){if(camera_.x+0.01f>=scenePages_[i].startX)initialPage=i;else break;}
    activeScenePage_=initialPage;fadeFromPage_=initialPage;
    if(!prefetchSceneWindow(activeScenePage_))return false;
    trimScenePageCache();
  }
  if(!world_.playerSprite.empty()&&!loadNativeSprite(world_.playerSprite,playerSprite_))return false;
  if(!world_.companionSprite.empty()&&!loadNativeSprite(world_.companionSprite,companionSprite_))return false;
  if(!loadAnimationMap(world_.playerAnimations,dixieAnimations_)||!loadAnimationMap(world_.companionAnimations,kiddyAnimations_))return false;
  for(const auto* state:{"idle","run","jump","fall","attack","swim","hang","duck","hit"})kiddyAnimations_[state]=*suppliedSprites_.animation(std::string("kiddy-")+state);
  // Keep common Dixie motions from the ROM; supplied sheet top is DKC2.
  for(const auto* state:{"idle","hang"})dixieAnimations_[state]=*suppliedSprites_.animation(std::string("dixie-")+state);

  playerAnimState_="idle";companionAnimState_="idle";playerAnimator_.reset();companionAnimator_.reset();coins_=persistent?persistent->coins:0;bananas_=persistent?persistent->bananas:0;lives_=persistent?persistent->lives:5;bonusCoins_=persistent?persistent->bonusCoins:0;lakesideBonusMask_=persistent?persistent->lakesideBonusMask:0;damageCount_=defeatedEnemies_=characterSwitches_=0;leverActivations_=checkpointActivations_=lockedDoorAttempts_=teamBarrelRescues_=0;barrelEntries_=warpShortcuts_=bonusBarrelAttempts_=0;kongMask_=0;kongLettersCollected_=0;pendingLevel_.clear();
  sfx_.clear();prevGrounded_=false;prevInWater_=false;waterKnown_=false;lastAirVy_=0.0f;
  levelTime_=0.0f;toastTimer_=0.0f;toast_.clear();pageFade_=1.0f;fadeFromPage_=0;
  attackTimer_=attackCooldown_=invulnerableTimer_=0.0f;activeLever_=-1;activeBarrel_=-1;barrelHoldTimer_=barrelCooldown_=0.0f;inBonus_=false;activeBonus_=bonusCollected_=bonusGreenIndex_=0;bonusTimeRemaining_=bonusGreenLife_=0.0f;bonusCollectibles_.clear();bonusCoin_={};inWater_=false;inWaterCurrent_=false;activeWaterCurrent_={};prevUp_=prevJump_=prevAttack_=prevSwitch_=false;
  spriteObjects_.clear();for(const auto&d:world_.spriteObjects){RuntimeSpriteObject o;o.id=d.id;o.pos=d.pos;o.foreground=d.foreground;if(!loadNativeSprite(d.spritePath,o.sprite))return false;spriteObjects_.push_back(std::move(o));}
  levers_.clear();for(const auto&d:world_.levers){RuntimeLever l;l.id=d.id;l.gateId=d.gateId;l.rect=d.rect;l.anchor=d.anchor;l.holdTime=std::max(0.05f,d.holdTime);levers_.push_back(std::move(l));}
  gates_.clear();for(const auto&d:world_.gates){RuntimeGate g;g.id=d.id;g.rect=d.rect;if(!d.spritePath.empty()&&!loadNativeSprite(d.spritePath,g.sprite))return false;gates_.push_back(std::move(g));}
  checkpointActive_.assign(world_.checkpoints.size(),false);
  enemies_.clear();for(const auto&d:world_.enemies){RuntimeEnemy e;e.id=d.id;e.pos=d.pos;e.speed=d.speed;e.minX=d.minX;e.maxX=d.maxX;e.w=d.w;e.h=d.h;e.facingRight=e.speed>0;
    if(d.animationPath=="@rom:kobble")e.animation=*suppliedSprites_.animation("kobble-walk");
    else if(!loadNativeAnimation(d.animationPath,e.animation))return false;
    if(!e.animation.valid())return false;
    enemies_.push_back(std::move(e));
  }
  collectibles_.clear();for(const auto&d:world_.collectibles){RuntimeCollectible c;c.id=d.id;c.pos=d.pos;c.w=d.w;c.h=d.h;c.value=d.value;
    if(d.animationPath=="@rom:bearcoin")c.animation=romCenteredAnimation(romLakeside_.bearCoinFrames(),0.085f,(int)d.w,(int)d.h);
    else if(d.animationPath=="@rom:banana")c.animation=romCenteredAnimation(romLakeside_.bananaSpinFrames(),0.075f,(int)d.w,(int)d.h);
    else if(d.animationPath=="@rom:life-balloon")c.animation=romCenteredAnimation(romLakeside_.lifeBalloonFrames(),0.095f,(int)d.w,(int)d.h);
    else if(!loadNativeAnimation(d.animationPath,c.animation))return false;
    if(d.animationPath=="@rom:bearcoin")c.animation=*suppliedSprites_.animation("bear-coin");
    else if(d.animationPath=="@rom:banana")c.animation=*suppliedSprites_.animation("banana");
    else if(d.animationPath=="@rom:life-balloon")c.animation=*suppliedSprites_.animation("life-balloon");
    if(!c.animation.valid())return false;
    collectibles_.push_back(std::move(c));
  }
  kongLetters_.clear();for(const auto&d:world_.kongLetters){RuntimeKongLetter k;k.letter=(char)std::toupper((unsigned char)d.letter);k.pos=d.pos;k.w=d.w;k.h=d.h;
    if(d.animationPath.rfind("@rom:kong:",0)==0){
      size_t index=0;if(k.letter=='O')index=1;else if(k.letter=='N')index=2;else if(k.letter=='G')index=3;
      if(index>=romLakeside_.kongLetterFrames().size())return false;
      k.animation=romSingleCenteredFrame(romLakeside_.kongLetterFrames()[index],(int)d.w,(int)d.h);
    }else if(!loadNativeAnimation(d.animationPath,k.animation))return false;
    if(!k.animation.valid())return false;
    if(k.letter=='K'||k.letter=='O'||k.letter=='N'||k.letter=='G')k.animation=*suppliedSprites_.animation(std::string("kong-")+k.letter);
    kongLetters_.push_back(std::move(k));
  }
  teamBarrels_.clear();for(const auto&d:world_.teamBarrels){RuntimeTeamBarrel b;b.id=d.id;b.pos=d.pos;b.w=d.w;b.h=d.h;if(!loadNativeSprite(d.spritePath,b.sprite))return false;b.sprite=suppliedSprites_.animation("dk-barrel")->frames.front().sprite;teamBarrels_.push_back(std::move(b));}
  barrelCannons_.clear();
  if(hasRomScene_){
    for(const auto& p:romLakeside_.placements())if(romObjectBehavior(p.spriteId)==RomObjectBehavior::BarrelCannon){
      RuntimeBarrelCannon b;b.placementType=p.type;b.role=world_.originalLevelId==0x25?barrelRole(p.type):BarrelCannonRole::Unknown;b.hidden=b.role==BarrelCannonRole::WarpEntry;
      const float cx=(float)((int)p.x-0x100),cy=(float)((int)p.y-0x100);b.pos={cx-b.w*0.5f,cy-b.h*0.5f};
      const auto& source=barrelIsExit(b.role)?romLakeside_.barrelCannonAutoFrames():romLakeside_.barrelCannonFrames();
      b.animation=romCenteredAnimation(source,0.085f,(int)b.w,(int)b.h);if(!b.animation.valid())return false;
      // ROM scripts for Lakeside use the base orientation on entry barrels and
      // the authored auto-fire orientation on their return/exit partners.
      b.animator.frame=barrelIsExit(b.role)?12u:0u;
      barrelCannons_.push_back(std::move(b));
    }
  }
  return true;
}

bool Game::enterBonus(int bonusIndex){
  if(!hasRomScene_||world_.originalLevelId!=0x25||inBonus_||(bonusIndex!=1&&bonusIndex!=2))return false;
  const RomLakesideBonusVisuals& rv=bonusIndex==1?romBonus1_:romBonus2_;if(!rv.valid())return false;
  dropCarriedBarrel();spriteEffects_.clear();
  ++bonusBarrelAttempts_;inBonus_=true;activeBonus_=bonusIndex;bonusCollected_=0;bonusGreenIndex_=0;bonusTimeRemaining_=rv.timeLimit();bonusGreenLife_=2.6f;activeBarrel_=-1;barrelHoldTimer_=0.0f;barrelCooldown_=0.45f;
  world_=mainWorld_;world_.width=rv.width();world_.height=rv.height();world_.cameraBounds={0,0,(float)world_.width,(float)world_.height};world_.solids.clear();world_.oneWayPlatforms.clear();world_.waterZones.clear();world_.waterCurrents.clear();world_.doors.clear();world_.goals.clear();world_.checkpoints.clear();world_.hangZones.clear();
  for(const auto&r:rv.collisionRects())world_.oneWayPlatforms.push_back({(float)r.x,(float)r.y,(float)r.width,(float)r.height});
  const auto sp=rv.startPoint();player_.pos={(float)sp.first,(float)sp.second-player_.height};
  player_.motion=PlayerMotion::Air;player_.grounded=false;player_.vel={};
  player_.nativeRope=-1;player_.ropeRemainder=0;player_.ropeRegrabDelay=0;player_.ropeJumpPending=false;player_.nativeRemainder=0;player_.nativeJumpPending=false;
  respawn_=player_.pos;companionPos_={player_.pos.x+world_.companionOffset.x,player_.pos.y+world_.companionOffset.y};inWater_=false;inWaterCurrent_=false;activeWaterCurrent_={};attackTimer_=0.0f;invulnerableTimer_=0.25f;
  bonusCollectibles_.clear();bonusCoin_={};
  if(bonusIndex==1){
    const auto anim=*suppliedSprites_.animation("bonus-star");
    int id=0;for(const auto& pt:rv.starPositions()){RuntimeCollectible c;c.id="rom-bonus-star-"+std::to_string(id++);c.pos={(float)pt.first-7.0f,(float)pt.second-7.0f};c.w=c.h=14.0f;c.value=1;c.animation=anim;bonusCollectibles_.push_back(std::move(c));}
  }else{
    RuntimeCollectible c;c.id="rom-green-banana";c.w=c.h=16.0f;c.value=1;c.animation=*suppliedSprites_.animation("green-banana");const auto& gp=rv.greenBananaPositions();if(gp.empty())return false;c.pos={(float)gp[0].first-8.0f,(float)gp[0].second-8.0f};bonusCollectibles_.push_back(std::move(c));
  }
  for(const auto&p:rv.placements())if(p.spriteId==0x028cu){bonusCoin_.id="rom-bonus-coin";bonusCoin_.w=24;bonusCoin_.h=24;bonusCoin_.active=false;bonusCoin_.pos={(float)((int)p.x-0x100)-12.0f,(float)((int)p.y-0x100)-12.0f};bonusCoin_.animation=*suppliedSprites_.animation("bonus-coin");break;}
  if(!bonusCoin_.animation.valid())return false;
  camera_.x=std::clamp(player_.pos.x-camera_.viewportW*0.5f,0.0f,std::max(0.0f,(float)world_.width-camera_.viewportW));camera_.y=std::clamp(player_.pos.y-camera_.viewportH*0.58f,0.0f,std::max(0.0f,(float)world_.height-camera_.viewportH));
  showToast(bonusIndex==1?"COLETE 50 ESTRELAS!":"PEGUE 15 BANANAS!",1.35f);emit(Sfx::Door);return true;
}

void Game::leaveBonus(bool completed){
  if(!inBonus_) return;
  const int leaving=activeBonus_;
  if(completed){const unsigned bit=1u<<(unsigned)(leaving-1);if(!(lakesideBonusMask_&bit)){lakesideBonusMask_|=bit;++bonusCoins_;}showToast("BONUS COIN!",1.1f);emit(Sfx::Coin);}else{showToast("BONUS ENCERRADO",0.95f);emit(Sfx::Locked);}
  player_.nativeRope=-1;player_.ropeRemainder=0;player_.ropeJumpPending=false;
  inBonus_=false;activeBonus_=0;bonusCollected_=0;bonusTimeRemaining_=0.0f;bonusCollectibles_.clear();bonusCoin_={};world_=mainWorld_;respawn_=world_.spawn;inWater_=false;inWaterCurrent_=false;activeWaterCurrent_={};
  BarrelCannonRole target=leaving==1?BarrelCannonRole::BonusExit1:BarrelCannonRole::BonusExit2;bool placed=false;
  for(auto&b:barrelCannons_)if(b.role==target){const float cx=b.pos.x+b.w*0.5f,cy=b.pos.y+b.h*0.5f;player_.pos={cx-player_.width*0.5f,cy-player_.height*0.5f};player_.vel={205.0f,-125.0f};player_.motion=PlayerMotion::Air;player_.grounded=false;player_.facingRight=true;b.revealed=true;placed=true;break;}
  if(!placed){player_.pos=world_.spawn;player_.vel={};player_.motion=PlayerMotion::Air;player_.grounded=false;}
  companionPos_={player_.pos.x+world_.companionOffset.x,player_.pos.y+world_.companionOffset.y};invulnerableTimer_=0.45f;barrelCooldown_=0.55f;camera_.x=std::clamp(player_.pos.x-camera_.viewportW*0.5f,world_.cameraBounds.x,std::max(world_.cameraBounds.x,world_.cameraBounds.x+world_.cameraBounds.w-camera_.viewportW));camera_.y=std::clamp(player_.pos.y-camera_.viewportH*0.58f,world_.cameraBounds.y,std::max(world_.cameraBounds.y,world_.cameraBounds.y+world_.cameraBounds.h-camera_.viewportH));
}

void Game::stepBonus(const InputState& in,float dt){
  const RomLakesideBonusVisuals& rv=activeBonus_==1?romBonus1_:romBonus2_;
  bonusTimeRemaining_=std::max(0.0f,bonusTimeRemaining_-dt);if(bonusTimeRemaining_<=0.0f){leaveBonus(false);return;}
  const bool jumpPressed=in.jump&&!prevJump_,switchPressed=in.switchCharacter&&!prevSwitch_;
  if(switchPressed)switchCharacter(true);
  (void)jumpPressed;
  updateRomRopePlayer(player_,in,dt,rv.terrain());
  player_.pos.x=std::clamp(player_.pos.x,0.0f,(float)world_.width-player_.width);
  if(player_.pos.y>world_.height+48){leaveBonus(false);return;}
  if(partnerAvailable_){float tx=player_.pos.x+world_.companionOffset.x,ty=player_.pos.y+world_.companionOffset.y;approach(companionPos_.x,tx,220.0f*dt);approach(companionPos_.y,ty,180.0f*dt);}
  for(auto& c:bonusCollectibles_)if(c.active){c.animator.step(c.animation,dt);if(overlaps(player_.bounds(),c.bounds())){c.active=false;++bonusCollected_;emit(Sfx::Coin);if(activeBonus_==2&&bonusCollected_<15){const auto& gp=rv.greenBananaPositions();bonusGreenIndex_=(bonusGreenIndex_+1)%(int)gp.size();c.pos={(float)gp[(size_t)bonusGreenIndex_].first-8.0f,(float)gp[(size_t)bonusGreenIndex_].second-8.0f};c.active=true;bonusGreenLife_=2.6f;}if(bonusCollected_>=rv.targetCount()){bonusCoin_.active=true;showToast("BONUS COIN LIBERADA",1.0f);}}}
  if(activeBonus_==2&&bonusCollected_<15&&!bonusCollectibles_.empty()){bonusGreenLife_-=dt;if(bonusGreenLife_<=0.0f){auto& c=bonusCollectibles_[0];const auto&gp=rv.greenBananaPositions();bonusGreenIndex_=(bonusGreenIndex_+1)%(int)gp.size();c.pos={(float)gp[(size_t)bonusGreenIndex_].first-8.0f,(float)gp[(size_t)bonusGreenIndex_].second-8.0f};c.active=true;bonusGreenLife_=2.6f;}}
  if(bonusCoin_.active){bonusCoin_.animator.step(bonusCoin_.animation,dt);if(overlaps(player_.bounds(),bonusCoin_.bounds())){leaveBonus(true);return;}}
  setPlayerAnimationState(desiredPlayerAnimation());if(const auto*pa=findAnim(activeAnimations(),playerAnimState_))playerAnimator_.step(*pa,dt);std::string dc=desiredPlayerAnimation();if(dc=="attack")dc="run";if(dc!=companionAnimState_){companionAnimState_=dc;companionAnimator_.reset();}if(const auto*ca=findAnim(inactiveAnimations(),companionAnimState_))companionAnimator_.step(*ca,dt);
  updateCamera(dt);
}

void Game::renderBonusScene(uint32_t* dst,int w,int h)const{
  if(!dst||w<=0||h<=0||!inBonus_) return;
  const RomLakesideBonusVisuals& rv=activeBonus_==1?romBonus1_:romBonus2_;
  const auto& src=rv.pixels();
  const int sw=rv.width(),sh=rv.height(),cx=(int)camera_.x,cy=(int)camera_.y;
  for(int y=0;y<h;++y){
    const int sy=cy+y;
    for(int x=0;x<w;++x){
      const int sx=cx+x;
      uint32_t c=0;
      if(sx>=0&&sy>=0&&sx<sw&&sy<sh)c=src[(size_t)sy*(size_t)sw+(size_t)sx];
      dst[(size_t)y*(size_t)w+(size_t)x]=0xff000000u|(c&0x00ffffffu);
    }
  }
}

void Game::updateCamera(float dt){
  const float maxX=std::max(world_.cameraBounds.x,world_.cameraBounds.x+world_.cameraBounds.w-camera_.viewportW);const float maxY=std::max(world_.cameraBounds.y,world_.cameraBounds.y+world_.cameraBounds.h-camera_.viewportH);
  float tx=std::clamp(player_.pos.x+player_.width*0.5f-camera_.viewportW*0.5f,world_.cameraBounds.x,maxX);float ty=std::clamp(player_.pos.y+player_.height*0.5f-camera_.viewportH*0.58f,world_.cameraBounds.y,maxY);
  approach(camera_.x,tx,480.0f*dt);approach(camera_.y,ty,320.0f*dt);
  if(pageFade_<1.0f)pageFade_=std::min(1.0f,pageFade_+dt/0.30f);
  if(!scenePages_.empty()){
    size_t idx=0;for(size_t i=1;i<scenePages_.size();++i){if(camera_.x+0.01f>=scenePages_[i].startX)idx=i;else break;}
    // Histerese ao voltar: em agua com corrente usamos margem maior para a pagina nao oscilar
    // so porque o jogador soltou o direcional logo depois de cruzar a fronteira.
    const float backHysteresis=inWaterCurrent_?18.0f:6.0f;
    if(idx<activeScenePage_&&camera_.x>=scenePages_[activeScenePage_].startX-backHysteresis)idx=activeScenePage_;
    if(idx!=activeScenePage_&&ensureScenePageLoaded(idx)){fadeFromPage_=activeScenePage_;activeScenePage_=idx;pageFade_=0.0f;}
    prefetchSceneWindow(activeScenePage_);
    trimScenePageCache();
  }
}
void Game::render(uint32_t*dst,int w,int h)const{
  if(!dst||w<=0||h<=0)return;
  if(lives_<=0 && !gameOverImage_.bgra.empty()){
    for(int y=0;y<h;++y)for(int x=0;x<w;++x)dst[static_cast<size_t>(y)*w+x]=gameOverImage_.bgra[static_cast<size_t>(y*gameOverImage_.h/h)*gameOverImage_.w+x*gameOverImage_.w/w]|0xff000000u;
    hudFillRect(dst,w,h,0,h-31,w,31,0x000000u,200);hudDrawText(dst,w,h,16,h-25,"GAME OVER",0xffffffffu,1);hudDrawText(dst,w,h,16,h-13,"R/SELECT REINICIAR",0xffffd080u,1);return;
  }
  if(hasRomScene_){
    if(inBonus_)renderBonusScene(dst,w,h);else renderRomScene(dst,w,h);
  }else if(hasScene_){
    renderScenePage(activeScenePage_,dst,w,h);
    if(pageFade_<1.0f&&!scenePages_.empty()&&fadeFromPage_<scenePages_.size()&&fadeFromPage_!=activeScenePage_){
      static thread_local std::vector<uint32_t> from;from.resize((size_t)w*h);renderScenePage(fadeFromPage_,from.data(),w,h);
      const float t=pageFade_*pageFade_*(3.0f-2.0f*pageFade_);const int a=(int)(t*256.0f);
      for(size_t i=0,n=(size_t)w*h;i<n;++i){
        const uint32_t n0=dst[i],f0=from[i];
        auto ch=[&](int sh){int x=(int)((n0>>sh)&255),y=(int)((f0>>sh)&255);return (uint32_t)((y*(256-a)+x*a)>>8);};
        dst[i]=0xff000000u|(ch(16)<<16)|(ch(8)<<8)|ch(0);
      }
    }
  }else std::fill(dst,dst+(size_t)w*h,0xff202020u);
  auto drawObj=[&](bool fg){for(const auto&o:spriteObjects_)if(o.foreground==fg)drawNativeSprite(o.sprite,dst,w,h,(int)(o.pos.x-camera_.x),(int)(o.pos.y-camera_.y));};
  if(inBonus_){
    for(const auto&c:bonusCollectibles_)if(c.active)drawAnim(&c.animation,c.animator,dst,w,h,(int)(c.pos.x-camera_.x),(int)(c.pos.y-camera_.y),false);
    if(bonusCoin_.active)drawAnim(&bonusCoin_.animation,bonusCoin_.animator,dst,w,h,(int)(bonusCoin_.pos.x-camera_.x),(int)(bonusCoin_.pos.y-camera_.y),false);
  }else{
    drawObj(false);
    for(const auto&g:gates_)if(!g.open){if(g.sprite.valid())drawNativeSprite(g.sprite,dst,w,h,(int)(g.rect.x-camera_.x),(int)(g.rect.y-camera_.y));else{int x0=std::max(0,(int)(g.rect.x-camera_.x)),y0=std::max(0,(int)(g.rect.y-camera_.y)),x1=std::min(w,(int)(g.rect.x+g.rect.w-camera_.x)),y1=std::min(h,(int)(g.rect.y+g.rect.h-camera_.y));for(int y=y0;y<y1;y++)for(int x=x0;x<x1;x++)dst[(size_t)y*w+x]=0xff8fc8e8u;}}
    for(const auto&c:collectibles_)if(c.active)drawAnim(&c.animation,c.animator,dst,w,h,(int)(c.pos.x-camera_.x),(int)(c.pos.y-camera_.y),false);
    for(const auto&k:kongLetters_)if(k.active)drawAnim(&k.animation,k.animator,dst,w,h,(int)(k.pos.x-camera_.x),(int)(k.pos.y-camera_.y),false);
    for(const auto&b:teamBarrels_)if(b.active&&b.state!=CarryBarrelState::Carried&&b.sprite.valid())drawNativeSprite(b.sprite,dst,w,h,(int)(b.pos.x-camera_.x),(int)(b.pos.y-camera_.y));
    for(size_t i=0;i<barrelCannons_.size();++i){const auto&b=barrelCannons_[i];if(b.hidden&&!b.revealed&&(int)i!=activeBarrel_)continue;drawAnim(&b.animation,b.animator,dst,w,h,(int)(b.pos.x-camera_.x),(int)(b.pos.y-camera_.y),false);}
    for(const auto&e:enemies_)if(e.active)drawAnim(&e.animation,e.animator,dst,w,h,(int)(e.pos.x-camera_.x),(int)(e.pos.y-camera_.y),!e.facingRight);
  }
  if(partnerAvailable_&&activeBarrel_<0){
    const auto*ca=findAnim(inactiveAnimations(),companionAnimState_);if(ca)drawAnim(ca,companionAnimator_,dst,w,h,(int)(companionPos_.x-camera_.x),(int)(companionPos_.y-camera_.y),!player_.facingRight);else if(inactiveFallbackSprite().valid())drawNativeSprite(inactiveFallbackSprite(),dst,w,h,(int)(companionPos_.x-camera_.x),(int)(companionPos_.y-camera_.y),!player_.facingRight);
  }
  const bool blink=invulnerableTimer_>0.0f && (int(invulnerableTimer_*14.0f)&1);
  if(!blink&&activeBarrel_<0){const auto*pa=findAnim(activeAnimations(),playerAnimState_);if(pa)drawAnim(pa,playerAnimator_,dst,w,h,(int)(player_.pos.x-camera_.x),(int)(player_.pos.y-camera_.y),!player_.facingRight);else if(activeFallbackSprite().valid())drawNativeSprite(activeFallbackSprite(),dst,w,h,(int)(player_.pos.x-camera_.x),(int)(player_.pos.y-camera_.y),!player_.facingRight);}
  for(const auto& b:teamBarrels_)if(b.active&&b.state==CarryBarrelState::Carried)drawNativeSprite(b.sprite,dst,w,h,static_cast<int>(b.pos.x-camera_.x),static_cast<int>(b.pos.y-camera_.y));
  for(const auto& fx:spriteEffects_)drawAnim(suppliedSprites_.animation(fx.name),fx.animator,dst,w,h,static_cast<int>(fx.pos.x-camera_.x),static_cast<int>(fx.pos.y-camera_.y),fx.flip);
  if(!inBonus_)drawObj(true);
  if(hudEnabled_)drawHud(dst,w,h);
  if(debugOverlay_)drawDebug(dst,w,h);
}
void Game::step(const InputState& in,float dt){
  if(lives_<=0)return;
  crouchVisual_=in.down && player_.grounded && std::fabs(player_.vel.x)<12.f;
  for(auto& fx:spriteEffects_)if(const auto* anim=suppliedSprites_.animation(fx.name))fx.animator.step(*anim,std::max(0.f,dt));
  std::erase_if(spriteEffects_,[](const SpriteEffect& fx){return fx.animator.finished;});
  dt=std::max(0.0f,dt);levelTime_+=dt;toastTimer_=std::max(0.0f,toastTimer_-dt);attackTimer_=std::max(0.0f,attackTimer_-dt);attackCooldown_=std::max(0.0f,attackCooldown_-dt);invulnerableTimer_=std::max(0.0f,invulnerableTimer_-dt);barrelCooldown_=std::max(0.0f,barrelCooldown_-dt);
  for(auto&b:barrelCannons_)b.animator.step(b.animation,dt);
  const bool upPressed=in.up&&!prevUp_,jumpPressed=in.jump&&!prevJump_,attackPressed=in.attack&&!prevAttack_,switchPressed=in.switchCharacter&&!prevSwitch_;
  if(inBonus_){stepBonus(in,dt);prevUp_=in.up;prevJump_=in.jump;prevAttack_=in.attack;prevSwitch_=in.switchCharacter;return;}
  if(activeBarrel_>=0&&(size_t)activeBarrel_<barrelCannons_.size()){
    auto& b=barrelCannons_[(size_t)activeBarrel_];b.revealed=true;barrelHoldTimer_+=dt;
    player_.pos={b.pos.x+b.w*0.5f-player_.width*0.5f,b.pos.y+b.h*0.5f-player_.height*0.5f};player_.vel={};player_.grounded=false;player_.motion=PlayerMotion::Air;inWater_=false;inWaterCurrent_=false;activeWaterCurrent_={};
    companionPos_={player_.pos.x+world_.companionOffset.x,player_.pos.y+world_.companionOffset.y};
    if(b.role==BarrelCannonRole::WarpEntry&&barrelHoldTimer_>=0.18f){
      for(size_t i=0;i<barrelCannons_.size();++i)if(barrelCannons_[i].role==BarrelCannonRole::WarpExit){activeBarrel_=(int)i;barrelCannons_[i].revealed=true;barrelHoldTimer_=0.0f;++warpShortcuts_;showToast("ATALHO WARP",0.85f);emit(Sfx::Door);break;}
    }else if(b.role==BarrelCannonRole::WarpExit&&barrelHoldTimer_>=0.24f){
      const float cx=b.pos.x+b.w*0.5f,cy=b.pos.y+b.h*0.5f;activeBarrel_=-1;barrelHoldTimer_=0.0f;barrelCooldown_=0.45f;
      player_.pos={cx-player_.width*0.5f,cy-player_.height*0.5f};player_.vel={245.0f,-155.0f};player_.motion=PlayerMotion::Air;player_.grounded=false;player_.facingRight=true;invulnerableTimer_=std::max(invulnerableTimer_,0.35f);companionPos_={player_.pos.x+world_.companionOffset.x,player_.pos.y+world_.companionOffset.y};emit(Sfx::Jump);
    }
    updateCamera(dt);prevUp_=in.up;prevJump_=in.jump;prevAttack_=in.attack;prevSwitch_=in.switchCharacter;return;
  }
  const bool barrelInput=handleCarryBarrelInput(in,attackPressed);
  if(!carryingBarrel()&&!barrelInput&&switchPressed&&player_.motion!=PlayerMotion::Hang&&attackTimer_<=0.0f)switchCharacter(true);
  if(!barrelInput&&!carryingBarrel()&&attackPressed&&player_.grounded&&player_.motion!=PlayerMotion::Hang&&player_.motion!=PlayerMotion::Swim&&attackCooldown_<=0.0f){
    attackTimer_=attackDuration();attackCooldown_=0.50f;emit(Sfx::Roll);
    player_.vel.x=player_.facingRight?(activeCharacter_==CharacterId::Dixie?172.0f:184.0f):-(activeCharacter_==CharacterId::Dixie?172.0f:184.0f);
  }
  if(hasRomScene_&&player_.nativeRope>=0){
    updateRomRopePlayer(player_,in,dt,romLakeside_.terrain());
  }else if(player_.motion==PlayerMotion::Hang){
    if(activeLever_>=0&&(size_t)activeLever_<levers_.size()&&!levers_[(size_t)activeLever_].activated){auto&l=levers_[(size_t)activeLever_];l.progress=std::min(l.holdTime,l.progress+dt);if(l.progress>=l.holdTime)activateLever((size_t)activeLever_);}
    if(jumpPressed||in.down||in.left||in.right){if(jumpPressed)emit(Sfx::Jump);player_.motion=PlayerMotion::Air;player_.vel.y=jumpPressed?-170.0f:70.0f;if(in.left){player_.vel.x=-70;player_.facingRight=false;}if(in.right){player_.vel.x=70;player_.facingRight=true;}activeLever_=-1;}
  }else{
    if(upPressed&&!carryingBarrel()){
      for(size_t i=0;i<levers_.size();i++)if(overlaps(player_.bounds(),levers_[i].rect)){player_.pos=levers_[i].anchor;player_.vel={};player_.motion=PlayerMotion::Hang;player_.grounded=false;activeLever_=(int)i;break;}
      if(player_.motion!=PlayerMotion::Hang){for(const auto&z:world_.hangZones)if(overlaps(player_.bounds(),z.rect)){player_.pos=z.anchor;player_.vel={};player_.motion=PlayerMotion::Hang;player_.grounded=false;activeLever_=-1;break;}}
    }
    if(player_.motion!=PlayerMotion::Hang){
      InputState movement=in;if(attackTimer_>0.0f){movement.run=true;movement.left=!player_.facingRight;movement.right=player_.facingRight;}
      std::vector<Rect> collisions=world_.solids;for(const auto&g:gates_)if(!g.open)collisions.push_back(g.rect);
      bool water=false;for(const auto&w:world_.waterZones)if(overlaps(player_.bounds(),w)){water=true;break;}
      inWater_=water;inWaterCurrent_=false;activeWaterCurrent_={};
      if(water){for(const auto&c:world_.waterCurrents)if(overlaps(player_.bounds(),c.rect)){activeWaterCurrent_.x+=c.drift.x;activeWaterCurrent_.y+=c.drift.y;inWaterCurrent_=true;}}
      if(water)updateSwimPlayer(player_,movement,dt,collisions.data(),(int)collisions.size(),activeWaterCurrent_,world_.oneWayPlatforms.data(),(int)world_.oneWayPlatforms.size());
      else{if(player_.motion==PlayerMotion::Swim)player_.motion=PlayerMotion::Air;if(hasRomScene_&&!carryingBarrel())updateRomRopePlayer(player_,movement,dt,romLakeside_.terrain());else updatePlayer(player_,movement,dt,collisions.data(),(int)collisions.size(),world_.oneWayPlatforms.data(),(int)world_.oneWayPlatforms.size(),hasRomScene_?&romLakeside_.terrain():nullptr);}
    }
  }
  // v0.9.0: sons de movimento (pulo, pouso, entrar/sair da agua).
  if(player_.justJumped)emit(Sfx::Jump);
  if(player_.grounded&&!prevGrounded_&&lastAirVy_>150.0f&&player_.motion==PlayerMotion::Ground)emit(Sfx::Land);
  if(!player_.grounded)lastAirVy_=player_.vel.y;
  prevGrounded_=player_.grounded;
  if(!waterKnown_){prevInWater_=inWater_;waterKnown_=true;}
  else if(inWater_!=prevInWater_){emit(Sfx::Splash);prevInWater_=inWater_;}
  // v0.8.0: paredes invisiveis nas bordas horizontais da fase (antes era possivel nadar/andar para fora do mapa).
  if(player_.pos.x<0.0f){player_.pos.x=0.0f;if(player_.vel.x<0.0f)player_.vel.x=0.0f;}
  if(player_.pos.x+player_.width>(float)world_.width){player_.pos.x=(float)world_.width-player_.width;if(player_.vel.x>0.0f)player_.vel.x=0.0f;}
  if(!carryingBarrel()&&barrelCooldown_<=0.0f&&(upPressed||jumpPressed)){
    for(size_t i=0;i<barrelCannons_.size();++i){auto&b=barrelCannons_[i];if(!overlaps(player_.bounds(),b.bounds()))continue;
      if(b.role==BarrelCannonRole::WarpEntry){activeBarrel_=(int)i;barrelHoldTimer_=0.0f;b.revealed=true;++barrelEntries_;player_.vel={};emit(Sfx::Switch);showToast("WARP BARREL",0.70f);break;}
      if(barrelIsBonusEntry(b.role)){if(enterBonus(b.role==BarrelCannonRole::BonusEntry1?1:2)){prevUp_=in.up;prevJump_=in.jump;prevAttack_=in.attack;prevSwitch_=in.switchCharacter;return;}break;}
    }
  }
  for(size_t i=0;i<world_.checkpoints.size();i++)if(overlaps(player_.bounds(),world_.checkpoints[i].rect)){respawn_=world_.checkpoints[i].respawn;if(i<checkpointActive_.size()&&!checkpointActive_[i]){checkpointActive_[i]=true;++checkpointActivations_;showToast("CHECKPOINT");emit(Sfx::Checkpoint);}}
  if(player_.pos.y>world_.height+64||player_.pos.x<-96||player_.pos.x>world_.width+96){dropCarriedBarrel();lives_=std::max(0,lives_-1);showToast(lives_>0?"VIDA -1":"GAME OVER",1.0f);player_.pos=respawn_;player_.vel={};player_.motion=PlayerMotion::Air;activeLever_=-1;partnerAvailable_=true;companionPos_={respawn_.x+world_.companionOffset.x,respawn_.y+world_.companionOffset.y};invulnerableTimer_=1.0f;}
  if(upPressed&&player_.motion!=PlayerMotion::Hang){for(const auto&d:world_.doors)if(overlaps(player_.bounds(),d.rect)){if(d.requiresLever.empty()||leverActivated(d.requiresLever)){pendingLevel_=d.target;emit(Sfx::Door);}else{++lockedDoorAttempts_;showToast("PORTA TRANCADA");emit(Sfx::Locked);}break;}}
  // v0.20.0: goals representam a saida natural da fase; nao exigem interacao.
  if(pendingLevel_.empty()){for(const auto&g:world_.goals)if(overlaps(player_.bounds(),g.rect)){pendingLevel_=g.target;emit(Sfx::Door);break;}}
  if(partnerAvailable_){float targetX=player_.pos.x+world_.companionOffset.x,targetY=player_.pos.y+world_.companionOffset.y;approach(companionPos_.x,targetX,220.0f*dt);approach(companionPos_.y,targetY,180.0f*dt);}
  stepCarryBarrels(dt);
  for(auto&e:enemies_)if(e.active){
    e.pos.x+=e.speed*dt;
    if(e.pos.x<e.minX){e.pos.x=e.minX;e.speed=std::fabs(e.speed);e.facingRight=true;}
    else if(e.pos.x>e.maxX){e.pos.x=e.maxX;e.speed=-std::fabs(e.speed);e.facingRight=false;}
    e.animator.step(e.animation,dt);
    const Rect pb=player_.bounds(),eb=e.bounds();
    const bool attackHit=attackActive() && overlaps(attackBounds(),eb);
    if(attackHit){
      e.active=false;++defeatedEnemies_;spriteEffect(e.id=="rom-kobble"?"kobble-death":"smoke",e.id=="rom-kobble"?e.pos:Vec2{e.pos.x+e.w*.5f,e.pos.y+e.h*.5f},!e.facingRight);emit(Sfx::EnemyHit);
      attackTimer_=std::max(attackTimer_,0.16f);
      player_.vel.x=player_.facingRight?(activeCharacter_==CharacterId::Dixie?158.0f:170.0f):-(activeCharacter_==CharacterId::Dixie?158.0f:170.0f);
      continue;
    }
    if(overlaps(pb,eb)){
      const float playerBottom=pb.y+pb.h;
      const bool stomp=player_.vel.y>45.0f && playerBottom<=eb.y+std::max(10.0f,eb.h*0.55f);
      if(stomp){
        e.active=false;++defeatedEnemies_;spriteEffect(e.id=="rom-kobble"?"kobble-death":"smoke",e.id=="rom-kobble"?e.pos:Vec2{e.pos.x+e.w*.5f,e.pos.y+e.h*.5f},!e.facingRight);emit(Sfx::Stomp);
        player_.pos.y=e.pos.y-player_.height;player_.vel.y=-185.0f;player_.grounded=false;player_.motion=PlayerMotion::Air;
      }else applyDamage(e.pos.x+e.w*0.5f);
    }
  }
  for(auto&c:collectibles_)if(c.active){
    c.animator.step(c.animation,dt);
    if(overlaps(player_.bounds(),c.bounds())){
      c.active=false;
      if(c.id=="rom-banana"){
        bananas_=std::max(0,bananas_+c.value);
        if(bananas_>=100){const int extra=bananas_/100;bananas_%=100;lives_=std::max(0,lives_+extra);showToast("100 BANANAS = VIDA +"+std::to_string(extra),1.15f);}
        else showToast("BANANA +"+std::to_string(c.value),0.75f);
      }else if(c.id=="rom-life-balloon"){
        lives_=std::max(0,lives_+c.value);
        showToast("VIDA +"+std::to_string(c.value),0.95f);
      }else{
        coins_=std::max(0,coins_+c.value);
        if(c.id=="rom-bear-coin")showToast("BEAR COIN",0.85f);
      }
      emit(Sfx::Coin);
    }
  }
  // v0.13.0: K-O-N-G fica separado das moedas. As letras giram usando frames
  // autenticos importados da OAM e o HUD acompanha o progresso da fase.
  for(auto&k:kongLetters_)if(k.active){
    k.animator.step(k.animation,dt);
    if(overlaps(player_.bounds(),k.bounds())){
      k.active=false;unsigned bit=0;
      switch(k.letter){case 'K':bit=1u;break;case 'O':bit=2u;break;case 'N':bit=4u;break;case 'G':bit=8u;break;default:break;}
      if(bit&&!(kongMask_&bit)){kongMask_|=bit;++kongLettersCollected_;emit(Sfx::Coin);if(kongMask_==15u)showToast("KONG COMPLETO");else showToast(std::string("LETRA ")+k.letter);}
    }
  }
  // Solo touch rescue goes through the same break lifecycle as a thrown impact.
  for(size_t i=0;i<teamBarrels_.size();++i){auto& b=teamBarrels_[i];
    if(b.active&&b.state==CarryBarrelState::Resting&&!partnerAvailable_&&overlaps(player_.bounds(),b.bounds()))breakTeamBarrel(i);
  }
  setPlayerAnimationState(desiredPlayerAnimation());const auto*pa=findAnim(activeAnimations(),playerAnimState_);if(pa)playerAnimator_.step(*pa,dt);
  std::string desiredComp=desiredPlayerAnimation();if(desiredComp=="attack")desiredComp="run";
  if(desiredComp!=companionAnimState_){companionAnimState_=desiredComp;companionAnimator_.reset();}
  const auto*ca=findAnim(inactiveAnimations(),companionAnimState_);if(ca)companionAnimator_.step(*ca,dt);
  updateCamera(dt);prevUp_=in.up;prevJump_=in.jump;prevAttack_=in.attack;prevSwitch_=in.switchCharacter;
}
void Game::renderRomScene(uint32_t* dst,int w,int h)const{
  if(!dst||w<=0||h<=0||!romLakeside_.valid()){return;}
  const auto& src=romLakeside_.pixels();
  const int sw=romLakeside_.width(),sh=romLakeside_.height();
  const int cx=(int)camera_.x,cy=(int)camera_.y;
  for(int y=0;y<h;++y){
    const int sy=cy+y;
    for(int x=0;x<w;++x){
      const int sx=cx+x;
      uint32_t c=0;
      if(sx>=0&&sy>=0&&sx<sw&&sy<sh)c=src[(size_t)sy*(size_t)sw+(size_t)sx];
      dst[(size_t)y*(size_t)w+(size_t)x]=0xff000000u|(c&0x00ffffffu);
    }
  }
}
void Game::renderScenePage(size_t index,uint32_t*dst,int w,int h)const{
  if(scenePages_.empty()){renderNativeScene(scene_,dst,w,h,(int)camera_.x,(int)camera_.y);return;}
  const auto&p=scenePages_[std::min(index,scenePages_.size()-1)];
  if(!p.loaded){std::fill(dst,dst+(size_t)w*h,0xff000000u);return;}
  renderNativeScene(p.scene,dst,w,h,(int)(camera_.x-p.startX),(int)camera_.y);
}
void Game::drawHud(uint32_t*dst,int w,int h)const{
  if(inBonus_){
    const int remain=std::max(0,bonusTarget()-bonusCollected_);char tb[16];std::snprintf(tb,sizeof tb,"%02d",(int)std::ceil(std::max(0.0f,bonusTimeRemaining_)));
    const std::string title=activeBonus_==1?"BONUS 1  50 ESTRELAS":"BONUS 2  15 BANANAS";const std::string count=(activeBonus_==1?"FALTAM ":"FALTAM ")+std::to_string(remain)+"  TEMPO "+tb;
    const int bw=std::max(hudTextWidth(title),hudTextWidth(count))+12;hudFillRect(dst,w,h,4,4,bw,27,0x000000u,150);hudDrawText(dst,w,h,10,8,title,0xffffe080u);hudDrawText(dst,w,h,10,19,count,0xffffffffu);
    if(toastTimer_>0.0f&&!toast_.empty()){const int tw=hudTextWidth(toast_)+12,tx=(w-tw)/2,ty=h-28;hudFillRect(dst,w,h,tx,ty-3,tw,15,0x000000u,150);hudDrawText(dst,w,h,tx+6,ty,toast_,0xffffffffu);}
    return;
  }
  const bool dixie=activeCharacter_==CharacterId::Dixie;
  const std::string name=dixie?"DIXIE":"KIDDY";const uint32_t nameColor=dixie?0xffff9ad2u:0xff7fd0ffu;
  char coinBuf[16],bananaBuf[16],lifeBuf[16];std::snprintf(coinBuf,sizeof coinBuf,"%03d",coins_);std::snprintf(bananaBuf,sizeof bananaBuf,"%02d",bananas_);std::snprintf(lifeBuf,sizeof lifeBuf,"%02d",lives_);
  const std::string line2=std::string("BEAR ")+coinBuf+"  BAN "+bananaBuf+"  VIDA "+lifeBuf;const std::string tag=partnerAvailable_?"DUPLA":"SOLO";
  const bool showKong=!kongLetters_.empty();
  const int kongW=hudTextWidth("K O N G");
  const int boxW=std::max({hudTextWidth(line2),hudTextWidth(name)+4+hudTextWidth(tag),showKong?kongW:0})+8;
  hudFillRect(dst,w,h,4,4,boxW,showKong?35:25,0x000000u,120);
  hudDrawText(dst,w,h,8,8,name,nameColor);
  hudDrawText(dst,w,h,8+hudTextWidth(name)+4,8,tag,partnerAvailable_?0xffa8ffa8u:0xffff8080u);
  hudDrawText(dst,w,h,8,18,line2,0xffffffffu);
  if(showKong){
    const char letters[4]={'K','O','N','G'};const unsigned bits[4]={1u,2u,4u,8u};int x=8;
    for(int i=0;i<4;i++){char t[2]={letters[i],0};hudDrawText(dst,w,h,x,28,t,(kongMask_&bits[i])?0xffffd840u:0xff707070u);x+=hudTextWidth(t)+hudTextWidth(" ");}
  }
  // Cartao de titulo da fase (some em ~2.8 s).
  if(levelTime_<2.8f){
    std::string title=world_.displayName.empty()?world_.id:world_.displayName;const auto par=title.find(" (");if(par!=std::string::npos)title.resize(par);
    const float a=levelTime_<2.0f?1.0f:std::max(0.0f,(2.8f-levelTime_)/0.8f);const int ty=(int)(h*0.36f);
    hudFillRect(dst,w,h,0,ty-6,w,26,0x000000u,(int)(130*a));
    if(a>0.45f)hudDrawText(dst,w,h,(w-hudTextWidth(title,2))/2,ty,title,0xffffe9a8u,2);
  }
  if(toastTimer_>0.0f&&!toast_.empty()){
    const int tw=hudTextWidth(toast_,1)+12;const int tx=(w-tw)/2,ty=h-28;
    hudFillRect(dst,w,h,tx,ty-3,tw,15,0x000000u,150);hudDrawText(dst,w,h,tx+6,ty,toast_,0xffffffffu);
  }
}
void Game::drawDebug(uint32_t*dst,int w,int h)const{
  auto box=[&](const Rect&r,uint32_t c){hudOutlineRect(dst,w,h,(int)(r.x-camera_.x),(int)(r.y-camera_.y),(int)r.w,(int)r.h,c);};
  for(const auto&r:world_.solids)box(r,0x40ff40);
  for(const auto&r:world_.oneWayPlatforms)box(r,0x90ff40);
  for(const auto&r:world_.waterZones)box(r,0x40a0ff);
  for(const auto&c:world_.waterCurrents)box(c.rect,0x40ffff);
  for(const auto&d:world_.doors)box(d.rect,0xffe040);
  for(const auto&g:world_.goals)box(g.rect,0x40ff80);
  for(const auto&c:world_.checkpoints)box(c.rect,0xff40ff);
  for(const auto&z:world_.hangZones)box(z.rect,0xff9020);
  for(const auto&l:levers_)box(l.rect,0x40ffff);
  for(const auto&g:gates_)if(!g.open)box(g.rect,0xff4040);
  for(const auto&e:enemies_)if(e.active)box(e.bounds(),0xff4040);
  for(const auto&c:collectibles_)if(c.active)box(c.bounds(),0xffe040);
  for(const auto&k:kongLetters_)if(k.active)box(k.bounds(),0xffff40);
  for(const auto&b:teamBarrels_)if(b.active)box(b.bounds(),0xffa020);
  for(const auto&b:barrelCannons_)if(!b.hidden||b.revealed)box(b.bounds(),barrelIsExit(b.role)?0xff60ff:0xffc040);
  box(player_.bounds(),0xffffff);
  if(attackActive())box(attackBounds(),0xff2020);
  char buf[224];
  if(inWaterCurrent_)std::snprintf(buf,sizeof buf,"CAM %d,%d PAG %d/%d CACHE %d X %d Y %d COR %d,%d",(int)camera_.x,(int)camera_.y,(int)activeScenePage()+1,(int)scenePageCount(),(int)loadedScenePageCount(),(int)player_.pos.x,(int)player_.pos.y,(int)activeWaterCurrent_.x,(int)activeWaterCurrent_.y);
  else std::snprintf(buf,sizeof buf,"CAM %d,%d PAG %d/%d CACHE %d X %d Y %d",(int)camera_.x,(int)camera_.y,(int)activeScenePage()+1,(int)scenePageCount(),(int)loadedScenePageCount(),(int)player_.pos.x,(int)player_.pos.y);
  hudFillRect(dst,w,h,0,h-11,hudTextWidth(buf)+8,11,0x000000u,170);hudDrawText(dst,w,h,4,h-9,buf,0xffffffffu);
}
}
