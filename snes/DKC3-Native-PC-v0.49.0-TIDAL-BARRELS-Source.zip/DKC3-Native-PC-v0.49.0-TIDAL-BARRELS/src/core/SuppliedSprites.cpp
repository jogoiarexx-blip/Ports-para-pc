#include "SuppliedSprites.h"
namespace dkc3 {
bool SuppliedSprites::load(const std::string& directory){
  animations_.clear();
  // Explicit activation allowlist; raw source sheets are never runtime inputs.
  static constexpr const char* names[]={"kiddy-idle","kiddy-run","kiddy-jump","kiddy-fall","kiddy-attack","kiddy-swim","kiddy-hang","kiddy-duck","kiddy-hit",
    "dixie-idle","dixie-hang","dixie-map","wrinkly-idle","kobble-walk","kobble-death","banana","green-banana","bear-coin","life-balloon","bonus-star","bonus-coin","kong-K","kong-O","kong-N","kong-G","dk-barrel","pickup-spark","smoke"};
  for(const auto* name:names){NativeAnimation anim;if(!loadNativeAnimation(directory+"/anims/"+name+".nanim",anim)){animations_.clear();return false;}animations_.emplace(name,std::move(anim));}
  return true;
}
const NativeAnimation* SuppliedSprites::animation(const std::string& name)const{
  const auto it=animations_.find(name);return it==animations_.end()?nullptr:&it->second;
}
}
