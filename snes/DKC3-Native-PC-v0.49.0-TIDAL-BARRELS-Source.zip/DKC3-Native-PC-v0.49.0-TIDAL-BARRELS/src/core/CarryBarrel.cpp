#include "CarryBarrel.h"
#include "RomTerrain.h"
#include <algorithm>
#include <cmath>
namespace dkc3 {
Rect carryBarrelSweepBounds(const CarryBarrelBody& b,Vec2 previous){
 const float x=std::min(previous.x,b.pos.x),y=std::min(previous.y,b.pos.y);
 return {x,y,b.w+std::fabs(b.pos.x-previous.x),b.h+std::fabs(b.pos.y-previous.y)};
}
CarryBarrelImpact advanceCarryBarrel(CarryBarrelBody& b,float dt,const std::vector<Rect>& solids,const std::vector<Rect>& platforms,const RomPierTerrain* terrain,int width,int height){
 if(b.state!=CarryBarrelState::Thrown&&b.state!=CarryBarrelState::Dropped)return CarryBarrelImpact::None;
 b.remainder+=std::max(0.f,dt);constexpr double tick=1.0/60.0;
 while(b.remainder+1e-9>=tick){
  b.remainder=std::max(0.0,b.remainder-tick);b.age+=static_cast<float>(tick);
  b.velocity.y=std::min(420.f,b.velocity.y+720.f/60.f);
  const float dx=b.velocity.x/60.f,dy=b.velocity.y/60.f;
  const int steps=std::max(1,static_cast<int>(std::ceil(std::max(std::fabs(dx),std::fabs(dy)))));
  for(int n=0;n<steps;++n){
   const Vec2 old=b.pos;b.pos.x+=dx/steps;b.pos.y+=dy/steps;
   if(b.pos.x<0||b.pos.x+b.w>width||b.pos.y>height+64)return CarryBarrelImpact::Outside;
   bool hit=false;float top=0;
   for(const auto& solid:solids)if(overlaps(b.bounds(),solid)){hit=true;top=solid.y;break;}
   if(!hit&&dy>=0)for(const auto& platform:platforms)
    if(b.pos.x+b.w>platform.x&&b.pos.x<platform.x+platform.w&&old.y+b.h<=platform.y+.01f&&b.pos.y+b.h>=platform.y){hit=true;top=platform.y;break;}
   if(!hit&&terrain){
    const int edge=static_cast<int>(std::floor(b.pos.x+(dx<0?0:b.w-1)));
    for(int y=static_cast<int>(b.pos.y)+1;y<static_cast<int>(b.pos.y+b.h)-1;++y)
     if(terrain->solidBodyPoint(edge,y)&&!terrain->solidBodyPoint(static_cast<int>(old.x+(dx<0?0:b.w-1)),y)){hit=true;break;}
    if(!hit&&dy<0)for(int x=static_cast<int>(b.pos.x)+1;x<static_cast<int>(b.pos.x+b.w)-1;++x)
     if(terrain->solidBodyPoint(x,static_cast<int>(b.pos.y))&&!terrain->solidBodyPoint(x,static_cast<int>(old.y))){hit=true;break;}
   }
   if(hit){
    if(b.state==CarryBarrelState::Dropped&&dy>=0&&old.y+b.h<=top+.01f){b.pos.y=top-b.h;b.velocity={};b.state=CarryBarrelState::Resting;b.remainder=0;return CarryBarrelImpact::None;}
    b.pos=old;return CarryBarrelImpact::Terrain;
   }
  }
 }
 return CarryBarrelImpact::None;
}
}
