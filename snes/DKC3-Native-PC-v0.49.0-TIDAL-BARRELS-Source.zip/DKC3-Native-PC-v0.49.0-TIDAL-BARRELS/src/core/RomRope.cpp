#include "Player.h"
#include "RomTerrain.h"
#include <algorithm>
#include <cmath>
namespace dkc3 {
namespace {
int16_t fixed(float speed){return static_cast<int16_t>(std::clamp(std::lround(speed*256.0f/60.0f),-32768l,32767l));}
float speed(int16_t v){return static_cast<float>(v)*60.0f/256.0f;}
void release(Player& p,bool jump,const InputState& in){
 p.nativeRope=-1;p.motion=PlayerMotion::Air;p.grounded=false;p.ropeRegrabDelay=0.15f;
 p.nativeGravity=p.nativeMotion.fallingGravity;p.vel.y=60.0f;
 // Original horizontal exit impulse B8:D82F..D842. Vertical/animation
 // transition remains the host drop adapter, not a full state translation.
 if(jump&&(in.left||in.right)){p.vel.x=in.right?150.0f:-150.0f;p.facingRight=in.right;}
 p.jumpWasDown=in.jump;p.nativeJumpPending=false;
}
}
void updateRomRopePlayer(Player& p,const InputState& in,float dt,const RomPierTerrain& terrain){
 if(!std::isfinite(dt)||dt<=0)return;
 if(in.jump&&!p.jumpWasDown)p.ropeJumpPending=true;
 p.jumpWasDown=in.jump;p.justJumped=false;p.ropeRemainder+=dt;
 constexpr double tick=1.0/60.0;
 while(p.ropeRemainder+1e-9>=tick){
  p.ropeRemainder=std::max(0.0,p.ropeRemainder-tick);p.ropeRegrabDelay=std::max(0.0f,p.ropeRegrabDelay-1.0f/60.0f);
  if(p.nativeRope>=0&&static_cast<size_t>(p.nativeRope)<terrain.ropes().size()&&p.motion==PlayerMotion::Hang){
   const auto& rope=terrain.ropes()[static_cast<size_t>(p.nativeRope)];
   const float center=p.pos.x+p.width*0.5f,hands=p.pos.y+p.height-40.0f;
   // External placement/character switches must not teleport back to a rope.
   if(center<rope.x-1||center>rope.x+rope.width+1||std::fabs(hands-rope.y)>2){release(p,false,in);}
   else if(p.ropeJumpPending&&(in.left||in.right||in.down)){release(p,true,in);p.ropeJumpPending=false;continue;}
   else{
    // B8:A4C9 integrates previous 8.8 X speed before mode-11 interpolation.
    float next=center+p.vel.x/60.0f;
    const uint16_t whole=static_cast<uint16_t>(std::clamp(std::floor(next),0.0f,65535.0f));
    const uint16_t frac=static_cast<uint16_t>(std::clamp(std::lround((next-std::floor(next))*65536.0f),0l,65535l));
    const uint16_t target=static_cast<uint16_t>(in.right?128:(in.left?-128:0));
    const auto clamped=romHorizontalRopeClamp(whole,frac,static_cast<uint16_t>(rope.x),static_cast<uint16_t>(rope.x+rope.width),target,static_cast<uint16_t>(fixed(p.vel.x)),0);
    if(clamped.stopped){next=clamped.x;++p.nativeRopeStops;}
    p.pos.x=next-p.width*0.5f;p.pos.y=rope.y+40.0f-p.height;
    p.vel={speed(romInterpolateSpeed(static_cast<int16_t>(clamped.velocity),static_cast<int16_t>(clamped.target),11)),0};
    if(in.left||in.right)p.facingRight=in.right;
    p.grounded=false;p.ropeJumpPending=false;continue;
   }
  }else if(p.nativeRope>=0)p.nativeRope=-1;
  const float oldHands=p.pos.y+p.height-40.0f;
  InputState frame=in;p.jumpWasDown=in.jump;
  if(p.ropeJumpPending){p.nativeJumpPending=true;p.ropeJumpPending=false;}
  updatePlayer(p,frame,1.0f/60.0f,nullptr,0,nullptr,0,&terrain);
  const float hands=p.pos.y+p.height-40.0f,center=p.pos.x+p.width*0.5f;
  if(p.ropeRegrabDelay<=0&&!in.jump&&(p.vel.y>=0||in.up)){
   for(size_t i=0;i<terrain.ropes().size();++i){const auto& rope=terrain.ropes()[i];
    if(center>=rope.x&&center<=rope.x+rope.width&&((oldHands<=rope.y&&hands>=rope.y)||(in.up&&std::fabs(hands-rope.y)<=8))){
     p.nativeRope=static_cast<int>(i);p.motion=PlayerMotion::Hang;p.grounded=false;p.vel={};p.nativeRemainder=0;p.pos.y=rope.y+40.0f-p.height;++p.nativeRopeGrabs;break;
    }
   }
  }
 }
}
}
