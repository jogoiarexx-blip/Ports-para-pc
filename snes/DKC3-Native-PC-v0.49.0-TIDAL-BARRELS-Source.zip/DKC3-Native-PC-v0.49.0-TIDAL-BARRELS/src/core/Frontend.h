#pragma once
#include "Game.h"
#include "WorldMap.h"
#include "RomData.h"
#include "Bmp.h"
#include <array>
#include <cstdint>
#include <string>

namespace dkc3 {

enum class FrontendScreen {
  BootPublisher,
  BootStudio,
  Title,
  SaveSelect
};

struct FrontendInput {
  bool up=false,down=false;
  bool confirm=false,cancel=false,start=false;
};

struct SaveSlotData {
  bool exists=false;
  int slot=0;
  int percent=0;
  int playSeconds=0;
  std::string currentLevel="lakeside-limbo";
  GamePersistentState persistent{};
  WorldMapState worldMap{};
};

struct FrontendLaunchRequest {
  int slot=0;
  std::string level="lakeside-limbo";
  GamePersistentState persistent{};
  WorldMapState worldMap{};
};

class Frontend {
 public:
  bool init(const std::string& saveDirectory="saves",const std::string& romPath="");
  void step(const FrontendInput& in,float dt);
  void render(uint32_t* dst,int w,int h) const;
  FrontendScreen screen() const{return screen_;}
  int selectedSlot() const{return selectedSlot_;}
  int activeSlot() const{return activeSlot_;}
  const std::array<SaveSlotData,3>& slots() const{return slots_;}
  bool takeLaunchRequest(FrontendLaunchRequest& out);
  bool syncActiveSave(const std::string& level,const GamePersistentState& persistent,const WorldMapState* worldMap=nullptr);
  const std::string& saveDirectory() const{return saveDirectory_;}
  bool romVisualsReady() const{return romVisuals_.valid();}
  const RomInfo& romInfo() const{return romVisuals_.romInfo();}
  static const char* screenName(FrontendScreen s);
 private:
  bool loadSlot(int index);
  bool writeSlot(int index) const;
  void enter(FrontendScreen next);
  bool pressed(bool now,bool old) const{return now&&!old;}
  std::string slotPath(int index) const;
  std::array<SaveSlotData,3> slots_{};
  std::string saveDirectory_="saves";
  FrontendScreen screen_=FrontendScreen::BootPublisher;
  int selectedSlot_=0,activeSlot_=-1;
  float screenTime_=0.0f,titleBlink_=0.0f;
  bool launchPending_=false;
  FrontendLaunchRequest launch_{};
  FrontendInput prev_{};
  Bitmap publisherSheet_,studioSheet_,titleSheet_;
  RomFrontendVisuals romVisuals_{};
};

}
