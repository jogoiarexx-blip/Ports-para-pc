#pragma once
namespace dkc3 {
constexpr const char* kVersion = "0.49.0";
constexpr const char* kVersionName = "Tidal ROM and Carry Barrels";
}
