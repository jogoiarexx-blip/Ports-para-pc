#include "NativeSprite.h"
#include <algorithm>
#include <cstring>
#include <fstream>
namespace dkc3 {
#pragma pack(push,1)
struct SpriteHeader{char magic[4];uint16_t version;uint16_t flags;uint16_t width,height;int16_t originX,originY;uint32_t pixelCount;};
#pragma pack(pop)
bool loadNativeSprite(const std::string& path, NativeSprite& out){
  out={};std::ifstream f(path,std::ios::binary);SpriteHeader h{};f.read((char*)&h,sizeof h);
  if(!f||std::memcmp(h.magic,"NSPR",4)||h.version!=1||!h.width||!h.height||h.pixelCount!=(uint32_t)h.width*h.height)return false;
  out.width=h.width;out.height=h.height;out.originX=h.originX;out.originY=h.originY;out.bgra.resize(h.pixelCount);
  f.read((char*)out.bgra.data(),std::streamsize(out.bgra.size()*sizeof(uint32_t)));return bool(f);
}
void drawNativeSprite(const NativeSprite& s,uint32_t* dst,int w,int h,int x,int y,bool flipX){
  if(!dst||!s.valid())return;
  const int dx0=x-s.originX,dy0=y-s.originY;
  for(int sy=0;sy<s.height;sy++){int dy=dy0+sy;if((unsigned)dy>=(unsigned)h)continue;for(int sx=0;sx<s.width;sx++){int dx=dx0+sx;if((unsigned)dx>=(unsigned)w)continue;int srcx=flipX?(s.width-1-sx):sx;uint32_t c=s.bgra[(size_t)sy*s.width+srcx];uint32_t a=c>>24;if(!a)continue;if(a==255){dst[(size_t)dy*w+dx]=c;continue;}uint32_t d=dst[(size_t)dy*w+dx],ia=255-a;uint32_t rb=(((c&0x00ff00ffu)*a+(d&0x00ff00ffu)*ia)>>8)&0x00ff00ffu;uint32_t g=(((c&0x0000ff00u)*a+(d&0x0000ff00u)*ia)>>8)&0x0000ff00u;dst[(size_t)dy*w+dx]=0xff000000u|rb|g;}}
}
uint64_t hashSprite(const NativeSprite&s){uint64_t h=1469598103934665603ull;auto mix=[&](const uint8_t*b,size_t n){for(size_t i=0;i<n;i++){h^=b[i];h*=1099511628211ull;}};mix((const uint8_t*)&s.width,sizeof s.width);mix((const uint8_t*)&s.height,sizeof s.height);mix((const uint8_t*)&s.originX,sizeof s.originX);mix((const uint8_t*)&s.originY,sizeof s.originY);if(!s.bgra.empty())mix((const uint8_t*)s.bgra.data(),s.bgra.size()*4);return h;}
}
