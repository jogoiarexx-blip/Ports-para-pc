#pragma once
#include "Math.h"
#include <vector>
namespace dkc3 {
class RomPierTerrain;
enum class CarryBarrelState { Resting, Carried, Thrown, Dropped, Broken };
struct CarryBarrelBody {
 Vec2 pos{},velocity{};float w=30,h=38;CarryBarrelState state=CarryBarrelState::Resting;
 double remainder=0;float age=0;
 Rect bounds()const{return {pos.x,pos.y,w,h};}
};
enum class CarryBarrelImpact { None, Terrain, Outside };
// Fixed 60Hz native simulation. Object speeds are host tuning, not original states.
CarryBarrelImpact advanceCarryBarrel(CarryBarrelBody& barrel,float dt,const std::vector<Rect>& solids,const std::vector<Rect>& platforms,const RomPierTerrain* terrain,int width,int height);
Rect carryBarrelSweepBounds(const CarryBarrelBody& barrel,Vec2 previous);
}
