#pragma once
#include <cstdint>
#include "RomTerrain.h"
#include <string>
#include <vector>
#include <utility>

namespace dkc3 {

struct RomInfo {
  bool valid=false;
  std::string path;
  std::string title;
  uint32_t crc32=0;
  size_t size=0;
};

class RomImage {
 public:
  bool load(const std::string& path);
  bool loadFirstAvailable(const std::vector<std::string>& paths);
  const RomInfo& info() const { return info_; }
  bool range(size_t begin,size_t end,std::vector<uint8_t>& out) const;
  const std::vector<uint8_t>& bytes() const { return data_; }
 private:
  std::vector<uint8_t> data_;
  RomInfo info_{};
};

bool dkc3BigDataDecompress(const uint8_t* data,size_t size,std::vector<uint8_t>& out,size_t* consumed=nullptr);
bool dkc3SmallDataDecompress(const uint8_t* data,size_t size,std::vector<uint8_t>& out,size_t* consumed=nullptr);

struct RomLayer {
  int widthTiles=0;
  int heightTiles=0;
  std::vector<uint8_t> gfx4bpp;
  std::vector<uint8_t> tilemap;
  std::vector<uint8_t> palette;
  bool transparentZero=false;
  int bpp=4;
  bool snesScreenBlocks=false;
};

bool renderSnes4bppLayer(const RomLayer& layer,std::vector<uint32_t>& out,int outW,int outH,int dstX=0,int dstY=0);
bool renderSnesLayer(const RomLayer& layer,std::vector<uint32_t>& out,int outW,int outH,int dstX=0,int dstY=0,std::vector<uint8_t>* opaqueMask=nullptr);

class RomFrontendVisuals {
 public:
  bool load(const std::string& romPath="");
  bool valid() const { return valid_; }
  const RomInfo& romInfo() const { return info_; }
  const std::vector<uint32_t>& title() const { return title_; }
  const std::vector<uint32_t>& fileSelect() const { return fileSelect_; }
  int titleW() const { return 256; }
  int titleH() const { return 224; }
  std::string status() const;
 private:
  bool valid_=false;
  RomInfo info_{};
  std::vector<uint32_t> title_;
  std::vector<uint32_t> fileSelect_;
};

struct RomSpriteFrame {
  int width=0;
  int height=0;
  int anchorX=0;
  int anchorY=0;
  std::vector<uint32_t> pixels;
};



struct RomLevelPlacement {
  uint16_t parameter=0;
  uint16_t x=0;
  uint16_t y=0;
  uint16_t type=0;
  // Endereco do descriptor em $FF obtido pela mesma tabela que o jogo usa
  // ($FF:0040 + type). Mantemos isso para traduzir os placements sem adivinhar.
  uint16_t descriptor=0;
  // Sprite ID final resolvido pelo bytecode Spawn Script da ROM (OpFF).
  // 0xFFFF significa que o script nao resolve para um unico sprite estatico.
  uint16_t spriteId=0xffff;
};

bool decodeRomPlacements(const RomImage& rom,const std::vector<uint8_t>& data,std::vector<RomLevelPlacement>& out);

struct RomCollisionRect {
  int x=0;
  int y=0;
  int width=0;
  int height=0;
};

enum class RomSupport { Supported, Partial, Unknown };
const char* romSupportName(RomSupport support);
struct RomLevelRequest {
  uint16_t originalLevelId=0x25;
  uint16_t sharedData=0x19f0;
  uint8_t submap=0;
};
struct RomScenarioCodec {
  uint16_t sharedData;
  const char* name;
  RomSupport support;
};
const RomScenarioCodec* findRomScenarioCodec(uint16_t sharedData);

class RomLevelRuntime {
 public:
  bool load(const std::string& romPath="") { return load(RomLevelRequest{},romPath); }
  bool load(const RomLevelRequest& request,const std::string& romPath="");
  const RomLevelRequest& request() const { return request_; }
  std::pair<int,int> startPoint() const { return startPoint_; }
  std::pair<int,int> checkpointPoint() const { return checkpointPoint_; }
  const std::string& error() const { return error_; }
  bool valid() const { return valid_; }
  const RomInfo& romInfo() const { return info_; }
  int width() const { return width_; }
  int height() const { return height_; }
  const std::vector<RomCollisionRect>& collisionRects() const { return collisionRects_; }
  const std::vector<RomCollisionRect>& groundSpans() const { return groundSpans_; }
  const std::vector<RomCollisionRect>& waterGaps() const { return waterGaps_; }
  const RomPierTerrain& terrain() const { return terrain_; }
  int waterSurfaceY() const { return waterSurfaceY_; }
  const std::vector<uint32_t>& pixels() const { return pixels_; }
  const std::vector<uint8_t>& foregroundMask() const { return foregroundMask_; }
  const std::vector<RomLevelPlacement>& placements() const { return placements_; }
  const std::vector<uint8_t>& placementData() const { return placementData_; }
  const std::vector<RomSpriteFrame>& kobbleWalkFrames() const { return kobbleWalkFrames_; }
  const std::vector<RomSpriteFrame>& bananaSpinFrames() const { return bananaSpinFrames_; }
  const std::vector<RomSpriteFrame>& bearCoinFrames() const { return bearCoinFrames_; }
  const std::vector<RomSpriteFrame>& lifeBalloonFrames() const { return lifeBalloonFrames_; }
  const std::vector<RomSpriteFrame>& barrelCannonFrames() const { return barrelCannonFrames_; }
  const std::vector<RomSpriteFrame>& barrelCannonAutoFrames() const { return barrelCannonAutoFrames_; }
  const std::vector<RomSpriteFrame>& kongLetterFrames() const { return kongLetterFrames_; }
 private:
  RomLevelRequest request_{};
  std::pair<int,int> startPoint_{},checkpointPoint_{};
  std::string error_;
  bool valid_=false;
  RomInfo info_{};
  int width_=6240;
  int height_=512;
  RomPierTerrain terrain_;
  int waterSurfaceY_=288;
  std::vector<RomCollisionRect> collisionRects_;
  std::vector<RomCollisionRect> groundSpans_;
  std::vector<RomCollisionRect> waterGaps_;
  std::vector<uint32_t> pixels_;
  std::vector<uint8_t> foregroundMask_;
  std::vector<RomLevelPlacement> placements_;
  std::vector<uint8_t> placementData_;
  std::vector<RomSpriteFrame> kobbleWalkFrames_;
  std::vector<RomSpriteFrame> bananaSpinFrames_;
  std::vector<RomSpriteFrame> bearCoinFrames_;
  std::vector<RomSpriteFrame> lifeBalloonFrames_;
  std::vector<RomSpriteFrame> barrelCannonFrames_;
  std::vector<RomSpriteFrame> barrelCannonAutoFrames_;
  std::vector<RomSpriteFrame> kongLetterFrames_;
};


using RomLakesideLimboVisuals = RomLevelRuntime; // Compatibility for existing clients.

class RomLakesideBonusVisuals {
 public:
  bool load(int bonusIndex,const std::string& romPath="");
  const RomPierTerrain& terrain() const { return terrain_; }
  bool valid() const { return valid_; }
  int bonusIndex() const { return bonusIndex_; }
  int width() const { return width_; }
  int height() const { return height_; }
  const std::vector<uint32_t>& pixels() const { return pixels_; }
  const std::vector<uint8_t>& foregroundMask() const { return foregroundMask_; }
  const std::vector<RomCollisionRect>& collisionRects() const { return collisionRects_; }
  const std::vector<RomLevelPlacement>& placements() const { return placements_; }
  const std::vector<RomSpriteFrame>& starFrames() const { return starFrames_; }
  const std::vector<RomSpriteFrame>& greenBananaFrames() const { return greenBananaFrames_; }
  const std::vector<RomSpriteFrame>& bonusCoinFrames() const { return bonusCoinFrames_; }
  const std::vector<std::pair<int,int>>& starPositions() const { return starPositions_; }
  const std::vector<std::pair<int,int>>& greenBananaPositions() const { return greenBananaPositions_; }
  int targetCount() const { return bonusIndex_==1?50:15; }
  float timeLimit() const { return bonusIndex_==1?20.0f:30.0f; }
  std::pair<int,int> startPoint() const;
  std::pair<int,int> returnPoint() const;
 private:
  RomPierTerrain terrain_;
  std::pair<int,int> startPoint_{},checkpointPoint_{};
  bool valid_=false;
  int bonusIndex_=0,width_=0,height_=512;
  std::vector<uint32_t> pixels_;
  std::vector<uint8_t> foregroundMask_;
  std::vector<RomCollisionRect> collisionRects_;
  std::vector<RomLevelPlacement> placements_;
  std::vector<RomSpriteFrame> starFrames_,greenBananaFrames_,bonusCoinFrames_;
  std::vector<std::pair<int,int>> starPositions_,greenBananaPositions_;
};

class RomLakeOrangatangaVisuals {
 public:
  bool load(const std::string& romPath="");
  bool valid() const { return valid_; }
  const RomInfo& romInfo() const { return info_; }
  int width() const { return 256; }
  int height() const { return 224; }
  const std::vector<uint32_t>& mapPixels() const { return map_; }
  const std::vector<uint8_t>& collisionData() const { return collision_; }
  const std::vector<RomSpriteFrame>& dixieWalkFrames() const { return dixieWalkFrames_; }
 private:
  bool valid_=false;
  RomInfo info_{};
  std::vector<uint32_t> map_;
  std::vector<uint8_t> collision_;
  std::vector<RomSpriteFrame> dixieWalkFrames_;
};

class RomWorldMapVisuals {
 public:
  bool load(const std::string& romPath="");
  bool valid() const { return valid_; }
  const RomInfo& romInfo() const { return info_; }
  int width() const { return width_; }
  int height() const { return height_; }
  const std::vector<uint32_t>& mapPixels() const { return map_; }
  const std::vector<uint8_t>& landMask() const { return landMask_; }
  const std::vector<RomSpriteFrame>& boatFrames() const { return boatFrames_; }
  bool landAt(int x,int y) const;
  bool boatBlocked(float x,float y,int halfW=7,int halfH=7) const;
 private:
  bool valid_=false;
  RomInfo info_{};
  int width_=512;
  int height_=512;
  std::vector<uint32_t> map_;
  std::vector<uint8_t> landMask_;
  std::vector<RomSpriteFrame> boatFrames_;
};

}
