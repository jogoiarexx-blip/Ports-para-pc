#include "Player.h"
#include "RomTerrain.h"
#include <algorithm>
#include <cmath>
namespace dkc3 {
static void approach(float& v,float target,float amount){ if(v<target) v=std::min(v+amount,target); else if(v>target) v=std::max(v-amount,target); }
static void updatePlayerFrame(Player& p,const InputState& in,float dt,const Rect* solids,int solidCount,const Rect* platforms,int platformCount,const RomPierTerrain* terrain){
  if(p.motion==PlayerMotion::Hang){p.vel={};p.grounded=false;return;}
  if(p.nativeMotion.valid){
    // Speeds use the original signed 8.8 pixels/frame representation.
    const auto fixed=[](float v){return static_cast<int16_t>(std::clamp(std::lround(v*256.0f/60.0f),-32768l,32767l));};
    // Original input processing: direction selects using the PREVIOUS Y/run
    // flag; Y is processed afterwards (B8:CD13, CD56, DA4F, DC77).
    const int16_t target=romHorizontalTarget(p.nativeMotion,p.nativeControlFlags,in.left,in.right);
    p.nativeHorizontalTarget=target;
    if(in.left||in.right)p.facingRight=in.right;
    if(in.run&&(in.left||in.right))p.nativeControlFlags|=4u;
    else p.nativeControlFlags&=static_cast<uint16_t>(~4u);
    const auto vx=romInterpolateSpeed(fixed(p.vel.x),target,p.grounded?p.nativeMotion.groundInterpolation:p.nativeMotion.airInterpolation);
    auto vy=fixed(p.vel.y);
    if(p.nativeJumpPending&&p.grounded){
      vy=p.nativeMotion.jumpImpulse;p.grounded=false;p.justJumped=true;p.jumping=true;
      p.nativeGravity=p.nativeMotion.risingGravity;
    }else if(!in.jump||vy>=0||p.nativeGravity<=0){
      // No-B action B8:D96C/E179 resets gravity even while rising.
      // Re-pressing B in the air does not restore the initial jump gravity.
      p.nativeGravity=p.nativeMotion.fallingGravity;
    }
    p.nativeJumpPending=false;p.coyoteTimer=0.0f;p.jumpBuffer=0.0f;
    vy=romGravityStep(vy,p.nativeGravity,p.nativeMotion.terminalSpeed);
    p.vel={static_cast<float>(vx)*60.0f/256.0f,static_cast<float>(vy)*60.0f/256.0f};
    p.jumping=vy<0;
  }else{
  const float maxSpeed = in.run ? 150.0f : 95.0f;
  const float accel = p.grounded ? 650.0f : 360.0f;
  const float friction = p.grounded ? 900.0f : 120.0f;
  float target=0;
  if(in.left!=in.right){ target=in.left?-maxSpeed:maxSpeed; p.facingRight=!in.left; approach(p.vel.x,target,accel*dt); }
  else approach(p.vel.x,0.0f,friction*dt);
  // v0.8.0: pulo por borda de subida + coyote time + buffer + altura variavel.
  p.justJumped=false;
  const float kCoyote=0.09f,kBuffer=0.10f,kJumpSpeed=-255.0f,kCutSpeed=-120.0f,kMinHold=0.05f;
  const bool jumpPressed=in.jump&&!p.jumpWasDown;p.jumpWasDown=in.jump;
  p.coyoteTimer=p.grounded?kCoyote:std::max(0.0f,p.coyoteTimer-dt);
  p.jumpBuffer=jumpPressed?kBuffer:std::max(0.0f,p.jumpBuffer-dt);
  if(p.jumpBuffer>0.0f && (p.grounded||p.coyoteTimer>0.0f)){ p.vel.y=kJumpSpeed; p.grounded=false; p.coyoteTimer=0.0f; p.jumpBuffer=0.0f; p.jumping=true; p.jumpTime=0.0f; p.justJumped=true; }
  if(p.jumping){ p.jumpTime+=dt; if(p.vel.y>=0.0f)p.jumping=false; else if(!in.jump&&p.jumpTime>=kMinHold&&p.vel.y<kCutSpeed)p.vel.y=kCutSpeed; }
  p.vel.y = std::min(p.vel.y + 720.0f*dt, 420.0f);

  }

  const bool startedGrounded=p.grounded;
  const Vec2 previousPosition=p.pos;
  p.pos.x += p.nativeMotion.valid?p.vel.x/60.0f:p.vel.x*dt;
  Rect b=p.bounds();
  for(int i=0;i<solidCount;i++) if(overlaps(b,solids[i])){
    if(p.vel.x>0) p.pos.x=solids[i].x-p.width; else if(p.vel.x<0) p.pos.x=solids[i].x+solids[i].w;
    p.vel.x=0; b=p.bounds();
  }

  if(terrain&&p.nativeMotion.valid&&!p.grounded&&p.vel.x!=0.0f){
    // Host airborne body adapter: sweep the leading edge through every crossed
    // pixel column. Existing overlap is allowed to leave. Vertical motion is
    // resolved later; this cannot replace the original Kong collision states.
    const int direction=p.vel.x>0.0f?1:-1;
    const float edgeOffset=direction>0?p.width-0.001f:0.0f;
    const int oldEdge=static_cast<int>(std::floor(previousPosition.x+edgeOffset));
    const int newEdge=static_cast<int>(std::floor(p.pos.x+edgeOffset));
    const int firstY=static_cast<int>(std::ceil(p.pos.y));
    const int lastY=static_cast<int>(std::ceil(p.pos.y+p.height))-1;
    bool blocked=false;
    for(int x=oldEdge+direction;direction>0?x<=newEdge:x>=newEdge;x+=direction){
      for(int y=firstY;y<=lastY;++y){
        if(!terrain->solidBodyPoint(oldEdge,y)&&terrain->solidBodyPoint(x,y)){blocked=true;break;}
      }
      if(blocked)break;
    }
    if(blocked){
      const auto previousX=static_cast<uint16_t>(std::clamp(std::floor(previousPosition.x),0.0f,65535.0f));
      const auto previousY=static_cast<uint16_t>(std::clamp(std::floor(previousPosition.y+p.height+256.0f),0.0f,65535.0f));
      const auto speed=static_cast<uint16_t>(static_cast<int16_t>(std::clamp(std::lround(p.vel.x*256.0f/60.0f),-32768l,32767l)));
      // Air entry does not set the moving-platform $1000 bit. Preserve the
      // existing flags and satisfy its requery if another state has set it.
      const auto restoredX=static_cast<uint16_t>(std::clamp(std::floor(static_cast<float>(previousX)+p.width*0.5f),0.0f,65535.0f));
      const auto restored=terrain->query(restoredX,previousY);const int floor=restored.surfaceY();
      const uint16_t surface=restored.supported&&floor>=0?static_cast<uint16_t>(floor+256):0x7f00;
      const auto response=romWallCollision(previousX,previousY,previousY,static_cast<uint16_t>(p.nativeHorizontalTarget),speed,p.nativeTerrainFlags,surface);
      p.pos.x=static_cast<float>(response.x);p.vel.x=0;
      p.nativeBlockedTarget=static_cast<int16_t>(response.savedTarget);p.nativeBlockedVelocity=static_cast<int16_t>(response.savedVelocity);
      p.nativeHorizontalTarget=0;p.nativeTerrainFlags=response.flags;++p.nativeWallHits;++p.nativeAirWallHits;
    }
  }

  if(terrain&&p.nativeMotion.valid&&p.grounded&&p.vel.x!=0.0f){
    // Host grounded-foot adapter. Original lateral probes/state remain pending.
    const auto x=static_cast<uint16_t>(std::clamp(std::floor(p.pos.x+p.width*0.5f),0.0f,65535.0f));
    const float feet=p.pos.y+p.height;
    const auto y=static_cast<uint16_t>(std::clamp(std::floor(feet+256.0f),0.0f,65535.0f));
    const auto hit=terrain->query(x,y);const int surface=hit.surfaceY();
    if(hit.supported&&surface>=0&&!hit.ceiling&&!(hit.initialAttributes&0x4000u)&&!(hit.attributes&0x1800u)&&surface<feet){
      if(feet-surface<=3.0f)p.pos.y=static_cast<float>(surface)-p.height;
      else{
        const auto priorX=static_cast<uint16_t>(std::clamp(std::floor(previousPosition.x),0.0f,65535.0f));
        const auto priorY=static_cast<uint16_t>(std::clamp(std::floor(previousPosition.y+p.height+256.0f),0.0f,65535.0f));
        const auto speed=static_cast<uint16_t>(static_cast<int16_t>(std::clamp(std::lround(p.vel.x*256.0f/60.0f),-32768l,32767l)));
        uint16_t queriedSurface=static_cast<uint16_t>(surface+256);
        if(p.nativeTerrainFlags&0x1000u){
          const auto restoredProbe=static_cast<uint16_t>(std::clamp(std::floor(static_cast<float>(priorX)+p.width*0.5f),0.0f,65535.0f));
          const auto restored=terrain->query(restoredProbe,y);const int restoredFloor=restored.surfaceY();
          queriedSurface=restored.supported&&restoredFloor>=0?static_cast<uint16_t>(restoredFloor+256):0x7f00;
        }
        const auto response=romWallCollision(priorX,priorY,y,static_cast<uint16_t>(p.nativeHorizontalTarget),speed,p.nativeTerrainFlags,queriedSurface);
        p.pos.x=static_cast<float>(response.x);p.pos.y=static_cast<float>(response.y)-256.0f-p.height;p.vel.x=0;
        p.nativeBlockedTarget=static_cast<int16_t>(response.savedTarget);p.nativeBlockedVelocity=static_cast<int16_t>(response.savedVelocity);
        p.nativeHorizontalTarget=0;p.nativeTerrainFlags=response.flags;++p.nativeWallHits;
      }
    }
  }

  const float oldBottom=p.pos.y+p.height;
  p.pos.y += p.nativeMotion.valid?p.vel.y/60.0f:p.vel.y*dt;
  p.grounded=false; b=p.bounds();
  for(int i=0;i<solidCount;i++) if(overlaps(b,solids[i])){
    if(p.vel.y>0){ p.pos.y=solids[i].y-p.height; p.grounded=true; }
    else if(p.vel.y<0) p.pos.y=solids[i].y+solids[i].h;
    p.vel.y=0; b=p.bounds();
  }
  if(!p.grounded&&p.vel.y<0.0f&&terrain){
    // Host adapter probes the head. The complete original Kong probes/state
    // are still pending; the bounded rising response below is translated.
    const auto x=static_cast<uint16_t>(std::clamp(std::floor(p.pos.x+p.width*0.5f),0.0f,65535.0f));
    const auto y=static_cast<uint16_t>(std::clamp(std::floor(p.pos.y+256.0f),0.0f,65535.0f));
    const auto hit=terrain->query(x,y);const int surface=hit.surfaceY();
    if(hit.supported&&surface>=0&&surface<p.pos.y&&!(hit.initialAttributes&0x4000u)&&!(hit.attributes&0x1800u)){
      RomTerrainQuery next;
      if(!hit.ceiling){const auto nextY=static_cast<uint16_t>((static_cast<uint16_t>(y+31u)&0xffe0u)+1u);next=terrain->query(x,nextY);}
      if(hit.ceiling||next.supported){
        const auto response=romRisingCollision(y,hit.ceiling,hit.ceilingSlope,next.ceiling,next.ceilingSlope,p.nativeTerrainFlags);
        p.pos.y=static_cast<float>(response.position)-256.0f;p.vel.y=0;p.jumping=false;
        p.nativeTerrainFlags=response.flags;p.nativeTerrainAttributes=response.attributes;++p.nativeCeilingHits;
      }
    }
  }
  if(!p.grounded&&p.vel.y>=0.0f&&terrain){
    const float newBottom=p.pos.y+p.height;
    const auto x=static_cast<uint16_t>(std::clamp(std::floor(p.pos.x+p.width*0.5f),0.0f,65535.0f));
    const auto y=static_cast<uint16_t>(std::clamp(std::floor(newBottom+256.0f),0.0f,65535.0f));
    const auto hit=terrain->query(x,y);const int floor=hit.surfaceY();
    // Host crossing guard; full B9:EEA0 response is not translated yet.
    bool follow=false;
    if(startedGrounded&&hit.supported&&floor>=0&&!hit.ceiling&&!(hit.initialAttributes&0x4000u)&&!(hit.attributes&0x1800u)&&newBottom<floor){
      // Host maps prior grounded state to $0100. The original branch selection
      // below is translated; snapping/zero speed remain the landing adapter.
      const auto gap=static_cast<uint16_t>(floor-static_cast<int>(std::floor(newBottom)));
      follow=romGroundFollow(gap,hit.attributes,static_cast<uint16_t>(p.nativeTerrainFlags|0x0100u)).attach;
      if(follow)++p.nativeGroundFollows;
    }
    if(hit.supported&&floor>=0&&!hit.ceiling&&!(hit.attributes&0x1800u)&&((oldBottom<=floor+1.0f&&newBottom>=floor)||follow)){
      p.pos.y=static_cast<float>(floor)-p.height;p.vel.y=0;p.grounded=true;
    }
  }
  if(!terrain&&!p.grounded&&p.vel.y>=0.0f&&platforms){
    const float newBottom=p.pos.y+p.height;
    for(int i=0;i<platformCount;i++){const Rect&r=platforms[i];const bool xOverlap=p.pos.x+p.width>r.x&&p.pos.x<r.x+r.w;
      if(xOverlap&&oldBottom<=r.y+1.0f&&newBottom>=r.y&&p.pos.y<r.y){p.pos.y=r.y-p.height;p.vel.y=0;p.grounded=true;break;}
    }
  }
  p.motion=p.grounded?PlayerMotion::Ground:PlayerMotion::Air;
}
void updatePlayer(Player& p,const InputState& in,float dt,const Rect* solids,int solidCount,const Rect* platforms,int platformCount,const RomPierTerrain* terrain){
  if(!p.nativeMotion.valid){updatePlayerFrame(p,in,dt,solids,solidCount,platforms,platformCount,terrain);return;}
  p.justJumped=false;
  if(p.motion==PlayerMotion::Hang){p.vel={};p.grounded=false;p.nativeRemainder=0.0;p.nativeJumpPending=false;p.jumpWasDown=in.jump;return;}
  if(!std::isfinite(dt)||dt<=0.0f)return;
  if(in.jump&&!p.jumpWasDown)p.nativeJumpPending=true;
  p.jumpWasDown=in.jump;
  p.nativeRemainder+=dt;
  constexpr double tick=1.0/60.0;
  while(p.nativeRemainder+1e-9>=tick){
    updatePlayerFrame(p,in,1.0f/60.0f,solids,solidCount,platforms,platformCount,terrain);
    p.nativeRemainder=std::max(0.0,p.nativeRemainder-tick);
  }
}

}

namespace dkc3 {
void updateSwimPlayer(Player& p,const InputState& in,float dt,const Rect* solids,int solidCount,Vec2 current,const Rect* platforms,int platformCount){
  if(p.motion==PlayerMotion::Hang){p.vel={};p.grounded=false;return;}
  p.justJumped=false;p.jumpWasDown=in.jump;p.jumping=false;p.coyoteTimer=0.0f;p.jumpBuffer=0.0f;
  const float maxX=in.run?105.0f:78.0f,maxY=86.0f,accel=310.0f,drag=250.0f;
  float tx=0.0f,ty=18.0f;
  if(in.left!=in.right){tx=in.left?-maxX:maxX;p.facingRight=!in.left;}
  if(in.up!=in.down)ty=in.up?-maxY:maxY;
  if(in.jump)ty=-112.0f;
  // Correnteza altera o alvo do nado: contra a corrente o avanco cai, a favor aumenta,
  // e sem input o jogador deriva naturalmente. Limites evitam correntes absurdas no arquivo de fase.
  tx+=std::clamp(current.x,-70.0f,70.0f);ty+=std::clamp(current.y,-55.0f,55.0f);
  tx=std::clamp(tx,-145.0f,145.0f);ty=std::clamp(ty,-145.0f,145.0f);
  approach(p.vel.x,tx,(std::fabs(tx)<0.01f?drag:accel)*dt);approach(p.vel.y,ty,230.0f*dt);
  p.pos.x+=p.vel.x*dt;Rect b=p.bounds();
  for(int i=0;i<solidCount;i++)if(overlaps(b,solids[i])){if(p.vel.x>0)p.pos.x=solids[i].x-p.width;else if(p.vel.x<0)p.pos.x=solids[i].x+solids[i].w;p.vel.x=0;b=p.bounds();}
  const float oldTop=p.pos.y,oldBottom=p.pos.y+p.height;
  p.pos.y+=p.vel.y*dt;b=p.bounds();
  for(int i=0;i<solidCount;i++)if(overlaps(b,solids[i])){if(p.vel.y>0)p.pos.y=solids[i].y-p.height;else if(p.vel.y<0)p.pos.y=solids[i].y+solids[i].h;p.vel.y=0;b=p.bounds();}
  if(platforms){
    const float newTop=p.pos.y,newBottom=p.pos.y+p.height;
    for(int i=0;i<platformCount;i++){const Rect&r=platforms[i];const bool xOverlap=p.pos.x+p.width>r.x&&p.pos.x<r.x+r.w;if(!xOverlap)continue;
      if(p.vel.y>0.0f&&oldBottom<=r.y+1.0f&&newBottom>=r.y){p.pos.y=r.y-p.height;p.vel.y=0;break;}
      if(p.vel.y<0.0f&&oldTop>=r.y+r.h-1.0f&&newTop<=r.y+r.h){p.pos.y=r.y+r.h;p.vel.y=0;break;}
    }
  }
  p.grounded=false;p.motion=PlayerMotion::Swim;
}
}
