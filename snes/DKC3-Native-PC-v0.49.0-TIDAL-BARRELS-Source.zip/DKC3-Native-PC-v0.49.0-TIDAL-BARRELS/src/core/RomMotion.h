#pragma once
#include <cstdint>
#include <string>
namespace dkc3 {
struct RomMotionProfile {
  bool valid=false;
  uint32_t sourceAddress=0;
  int16_t risingGravity=0, fallingGravity=0, terminalSpeed=0, jumpImpulse=0;
  int16_t walkSpeed=0, runSpeed=0;
  uint16_t groundInterpolation=0, airInterpolation=0;
};
bool loadRomMotionProfiles(const std::string& path, RomMotionProfile& dixie, RomMotionProfile& kiddy);
// Native arithmetic translations of B8:A035 and B9:F4B0 (mode 3/7/11).
int16_t romGravityStep(int16_t velocity, int16_t gravity, int16_t limit);
int16_t romInterpolateSpeed(int16_t velocity, int16_t target, uint16_t mode);
// Unladen, unmounted branch of B8:D4C2 followed by direction assignment.
int16_t romHorizontalTarget(const RomMotionProfile& profile, uint16_t controlFlags, bool left, bool right);
}
