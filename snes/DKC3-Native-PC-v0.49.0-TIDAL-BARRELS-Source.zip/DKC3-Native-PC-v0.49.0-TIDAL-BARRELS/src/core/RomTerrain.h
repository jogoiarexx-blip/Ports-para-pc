#pragma once
#include <cstdint>
#include <vector>
namespace dkc3 {
struct RomTerrainSample {
  bool supported=true;
  int16_t height=-1;
  uint16_t attributes=0;
};
// Native translation of B7:CF68 and the shape routines used by Pier main.
// queryY is the original sprite Y word; required by shapes $4B/$4C (ceilings).
RomTerrainSample romPierTerrainSample(uint16_t metatile,uint16_t left,uint16_t right,uint16_t localX,uint16_t queryY=0);
struct RomHorizontalRope {int x=0,y=0,width=0;};
bool buildRomPierRopes(const std::vector<uint8_t>& level,const std::vector<uint8_t>& definitions,int columns,int rows,std::vector<RomHorizontalRope>& out);
struct RomTerrainSurface {int x=0,y=0,width=0,height=8;};
bool buildRomPierSurfaces(const std::vector<uint8_t>& level,const std::vector<uint8_t>& definitions,int columns,int rows,std::vector<RomTerrainSurface>& out);
}

namespace dkc3 {
struct RomTerrainQuery {
  bool supported=true;
  uint16_t encoded=0xffc0,attributes=0,initialAttributes=0,ceiling=0,ceilingSlope=0;
  int surfaceY() const {return (encoded&0x8000)?-1:0x6200-static_cast<int>(encoded);}
};
class RomPierTerrain {
 public:
  bool load(const std::vector<uint8_t>& level,const std::vector<uint8_t>& definitions,const std::vector<uint8_t>& attributeTable,int columns);
  // B7:CD1F: X is world X, Y includes original $0100 origin.
  const std::vector<RomHorizontalRope>& ropes() const { return ropes_; }
  RomTerrainQuery query(uint16_t worldX,uint16_t originalY) const;
  // Host volume adapter over ROM floor shapes, not an original Kong probe.
  // Excludes rope and conditional ceiling shapes; no out-of-map clamping.
  bool solidBodyPoint(int worldX,int worldY) const;
 private:
  std::vector<uint8_t> level_,definitions_,attributeTable_;
  std::vector<RomHorizontalRope> ropes_;
  int columns_=0;
};
}

namespace dkc3 {
struct RomRisingCollision {
  uint16_t position=0,velocity=0,targetVelocity=0,nextSurface=0x7f00,distance=0x8050,flags=0,attributes=0;
};
// B9:EFB9..EFF0, entered only after rising penetration was established.
RomRisingCollision romRisingCollision(uint16_t position,uint16_t ceiling,uint16_t ceilingSlope,uint16_t nextCeiling,uint16_t nextSlope,uint16_t flags);
}

namespace dkc3 {
struct RomWallCollision {
  uint16_t x=0,y=0,fraction=0,target=0,velocity=0,savedTarget=0,savedVelocity=0,flags=0;
};
// B9:F181..F1AD; called only after horizontal blockage is established.
RomWallCollision romWallCollision(uint16_t previousX,uint16_t previousY,uint16_t currentY,uint16_t target,uint16_t velocity,uint16_t flags,uint16_t queriedSurface);
}

namespace dkc3 {
struct RomGroundFollow {uint16_t distance=0;bool attach=false;};
// B9:F060..F083 selection, assuming the caller has a positive floor gap.
// Stops at F019 (attach path) or F083 (keep distance); not their responses.
RomGroundFollow romGroundFollow(uint16_t distance,uint16_t attributes,uint16_t flags);
}

namespace dkc3 {
struct RomRopeClamp {uint16_t x=0,fraction=0,target=0,velocity=0,direction=0;bool stopped=false;};
// B8:A4A0..A4C8, no-slip branch. Direction is updated only when clamped.
RomRopeClamp romHorizontalRopeClamp(uint16_t x,uint16_t fraction,uint16_t lower,uint16_t upper,uint16_t target,uint16_t velocity,uint16_t direction);
}
