#include "RomObjectRuntime.h"
#include <sstream>
#include <iomanip>
namespace dkc3 {
namespace {
constexpr RomObjectDefinition definitions[]={
  {0x0170,RomObjectBehavior::TeamBarrel,RomSupport::Partial,"DK Barrel","Native carry/throw/break; original object states and timing pending"},
  {0x02f8,RomObjectBehavior::Sneek,RomSupport::Partial,"Sneek","Host patrol; original AI not complete"},
  {0x03c8,RomObjectBehavior::Kobble,RomSupport::Partial,"Kobble/Skidda","Pier Kobble only; non-Pier family variant selection pending"},
  {0x0284,RomObjectBehavior::BearCoin,RomSupport::Partial,"Bear coin","Host overlap pickup"},
  {0x0298,RomObjectBehavior::Banana,RomSupport::Partial,"Banana","Host overlap pickup"},
  {0x029c,RomObjectBehavior::LifeBalloon,RomSupport::Partial,"Life balloon","Red variant only; host overlap pickup"},
  {0x0294,RomObjectBehavior::KongLetter,RomSupport::Partial,"KONG letter","Letter selected by original descriptor mask"},
  {0x02bc,RomObjectBehavior::Checkpoint,RomSupport::Partial,"Checkpoint","Host full-height trigger"},
  {0x0124,RomObjectBehavior::EndFlag,RomSupport::Partial,"End flag","Host full-height trigger"},
  {0x02b4,RomObjectBehavior::BarrelCannon,RomSupport::Partial,"Barrel cannon","Lakeside type-specific destinations"}
};
}
const RomObjectDefinition& findRomObject(uint16_t spriteId){
  for(const auto& d:definitions)if(d.spriteId==spriteId)return d;
  static constexpr RomObjectDefinition unknown={0xffff,RomObjectBehavior::Unknown,RomSupport::Unknown,"Unimplemented object","Preserved for audit; no gameplay handler"};
  return unknown;
}
RomObjectBehavior romObjectBehavior(uint16_t spriteId){return findRomObject(spriteId).behavior;}
void RomSpawnRuntime::build(const std::vector<RomLevelPlacement>& placements){
  records_.clear();records_.reserve(placements.size());
  for(size_t i=0;i<placements.size();++i){auto definition=findRomObject(placements[i].spriteId);
    definition.spriteId=placements[i].spriteId;records_.push_back({i,placements[i],definition});}
}
size_t RomSpawnRuntime::count(RomSupport support) const {
  size_t n=0;for(const auto& r:records_)n+=r.definition.support==support;return n;
}
std::string RomSpawnRuntime::report() const {
  std::ostringstream out;
  out<<"placements="<<records_.size()<<" SUPPORTED="<<count(RomSupport::Supported)
     <<" PARTIAL="<<count(RomSupport::Partial)<<" UNKNOWN="<<count(RomSupport::Unknown)<<"\n";
  out<<"index,sprite_id,descriptor,type,parameter,x,y,status,behavior,limitation\n";
  for(const auto& r:records_){const auto& p=r.placement;
    out<<std::dec<<r.placementIndex<<",0x"<<std::hex<<p.spriteId<<",0x"<<p.descriptor
       <<",0x"<<p.type<<",0x"<<p.parameter<<std::dec<<","<<p.x<<","<<p.y
       <<","<<romSupportName(r.definition.support)<<","<<r.definition.name<<","<<r.definition.limitation<<"\n";}
  return out.str();
}
}
