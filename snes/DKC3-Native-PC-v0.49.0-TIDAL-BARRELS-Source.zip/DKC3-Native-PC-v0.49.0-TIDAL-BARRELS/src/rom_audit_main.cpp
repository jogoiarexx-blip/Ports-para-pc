#include "core/RomObjectRuntime.h"
#include <iostream>
int main(int argc,char** argv){
  dkc3::RomLevelRuntime level;
  if(!level.load(dkc3::RomLevelRequest{},argc>1?argv[1]:"rom/dkc3_ptbr.sfc")){
    std::cerr<<"ROM level load failed: "<<level.error()<<"\n";return 1;}
  dkc3::RomSpawnRuntime spawn;spawn.build(level.placements());
  std::cout<<spawn.report();return 0;
}
