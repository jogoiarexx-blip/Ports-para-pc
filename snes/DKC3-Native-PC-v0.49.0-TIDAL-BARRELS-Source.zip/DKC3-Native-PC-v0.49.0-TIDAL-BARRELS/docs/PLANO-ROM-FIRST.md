# Próximos critérios — v0.49.0

Carregador PIER compartilhado: Lakeside ($25/0), Tidal ($27/2), bônus Lakeside
($50/3 e $51/4). Tidal ativa é ROM-first. Os codecs $198D/$1998/$19DA ainda
não têm decoder; requests desconhecidos falham sem fallback silencioso.

Object runtime: tabela por SpriteID e registro completo. Lakeside 47 registros:
36 PARTIAL, 11 UNKNOWN, zero SUPPORTED. Tidal 61: 20 PARTIAL, 41 UNKNOWN.
O DK Barrel agora tem ciclo nativo funcional, permanecendo PARTIAL quanto à
rotina/poses/tempos originais. Não confundir registros com entidades jogáveis.

Restante:
1. Resolver scripts dinâmicos/objetos faltantes, peixes e inimigos de Tidal;
   destinos de barrels e os dois bônus de Tidal. Usar descriptor/parameter.
2. Portar probes e estados completos do Kong, inclusive transição água/chão,
   salto com carga e acionamento fiel da bandeira/checkpoint.
3. Replay Lakeside desde spawn até checkpoint, Warp, bandeira e dois bônus,
   concluindo 50 estrelas/15 bananas sem injetar posição. As rotas v0.49
   apenas chegam ao trigger de saída atual e não são esse teste ouro.
4. Cordas verticais/sliding/entrada/saída/regrab e poses/estados SNES de barris.
5. Skidda, Murky e Belcha para completar Lake Orangatanga, com boss/transições.
6. Stream original do mapa E9:26FB e renderer/extração nativa de música/SFX.

Validação atual: docs/VALIDACAO-v0.49.0.txt e docs/TIDAL-BARRELS.md.
