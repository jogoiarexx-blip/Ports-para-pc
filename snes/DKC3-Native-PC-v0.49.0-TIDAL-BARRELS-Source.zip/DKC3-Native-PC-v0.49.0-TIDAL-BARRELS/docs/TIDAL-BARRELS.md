# Tidal ROM e ciclo dos barris — v0.49.0

## Dados de Tidal

`RomLevelRuntime` cataloga $27/$19F0/2. Os limites de submapa em B7:B431
selecionam as colunas 195..443 do bloco PierLevels (E5:2618). Resultado:
249 colunas, 7968×512 pixels. Stream FE:0926..FE:0B10: 61 placements.
Definições E5:4A01..E5:4C41: 180 superfícies. A busca BB:B7BC seleciona o
índice 8 de BB:B831 e retorna água Y=$0298 (408 no espaço nativo).
Spawn do header FD:071B: X=$013C/Y=$0269, pés nativos (60,361).
Checkpoint de retorno do mesmo header: pés (3840,352). As posições não são
mais as coordenadas visuais calibradas para a captura de abertura.

As três `.nscene` antigas permanecem no source somente para testes de
compatibilidade do streaming; Tidal ativa não as carrega, e o build Windows
remove a pasta dessas páginas do pacote portátil. Não foram criadas páginas
adicionais. Sprites OAM antigos ainda necessários como dependências de teste
/declarações de animação permanecem disponíveis.

A forma $4D (B7:D183) é um teto plano condicional: só retorna altura 31 quando
((queryY-1)&31)<16. Seu teto/slope são calculados em `RomPierTerrain::query`.
Ela não vira piso one-way nem parede sólida por inferência visual. O oracle
comparou 98.309 amostras e 20.132 consultas reais de Tidal com a ROM.

## DK Barrel

SpriteID $0170 é resolvido dos scripts de spawn. O Game cria um DK Barrel
nas coordenadas authored de cada fase. `CarryBarrelBody` separa Resting,
Carried, Thrown, Dropped e Broken. Simulação do objeto em 60Hz, subdivisão do
movimento por pixel, colisões de volume/pisos ROM e gates; sweep para inimigos
até o ponto livre anterior ao impacto. Não acerta inimigos atrás de uma parede.

O input segura X para carregar, solta para lançar, baixo+X coloca, soltar e
pressionar novamente pega de novo. Enquanto carrega, não rola nem troca Kong,
pode pular, e o barril segue posição/direção do personagem. Dano/água solta.
Quebra remove a entidade uma vez, emite efeito/som e, se SOLO, restaura parceiro
uma vez. Reiniciar recria o placement. Não há save de um projétil em voo.

As velocidades 280/-100 e gravidade 720 são ajustes nativos declarados, não
constantes ROM verificadas. Poses específicas de carregar/arremessar, salto
com carga e toda a rotina original de objetos ainda precisam ser traduzidas.
Isso mantém o objeto PARTIAL apesar de agora ter ciclo funcional.

## Replays e limites

`tests/native_stages_tests.cpp` gera e relê dois arquivos de input fixos:
Lakeside, 3299 quadros; Tidal, 6206. Começam no spawn lido da ROM, passam no
checkpoint e alcançam o trigger de saída. A segunda execução compara posição,
vidas, danos e destino. Nenhuma posição/velocidade é injetada nesse teste.
Os CSVs registram todos os quadros. Ombro direito usa máscara $0800 para correr
sem segurar o botão de carregar/rolar; os formatos de playback existentes são
preservados. No replay CLI, R/ombro é convenção do adaptador nativo.

Esses replays não são o teste ouro solicitado: os triggers de checkpoint/saída
continuam amplos, os objetos desconhecidos não ganham comportamento, e não
há conclusão por input dos dois bônus nem do Warp. O fim de Tidal retorna ao
mapa em direção a Skidda; Skidda não está disponível para jogar neste pacote.
Tidal mantém 41 UNKNOWN e 20 PARTIAL; Lakeside fica em 11 UNKNOWN/36 PARTIAL.

`carry_barrel_tests.cpp` cobre os dois Kongs/direções, salto segurando, impacto
lançado/carregado, dano evitado pelo barril, drop/regrab, SOLO, parede fina,
inimigo protegido por parede, tick dividido e criação por placement ROM.
18 suites e headless passaram no Linux. Windows não compilado/executado.

Fonte auxiliar consultada para organização dos bancos:
https://github.com/H4v0c21/DKC3-Disassembly
As traduções/endereços deste passo foram conferidos nos bytes da ROM fornecida;
nenhum banco completo de disassembly foi copiado para o runtime.
