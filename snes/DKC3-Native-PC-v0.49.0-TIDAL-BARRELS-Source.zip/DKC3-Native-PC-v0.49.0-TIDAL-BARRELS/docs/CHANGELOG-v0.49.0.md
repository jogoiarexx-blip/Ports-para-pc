# v0.49.0

- Tidal substitui três capturas por submapa ROM PIER completo, 7968×512.
- Spawn/checkpoint/água lidos na ROM; forma de teto $4D traduzida e comparada.
- DK Barrel físico com carregar, salto, throw/drop/regrab, colisões, quebra e rescue.
- SpriteID $0170 integrado ao registro e placements de Lakeside/Tidal.
- Letras KONG selecionadas pelo descriptor, corrigindo a identidade de G em Tidal.
- Duas rotas reproduzidas somente por input; CLI headless e build Windows atualizados.
- 18 suites aprovadas no Linux. Original completo de estados/bônus segue pendente.
