#include "core/Game.h"
#include "core/NativeScene.h"
#include "core/NativeSprite.h"
#include "core/LevelSession.h"
#include <algorithm>
#include <cmath>
#include <cstdio>
#include "core/Audio.h"
#include "core/Bmp.h"
#include "core/Hud.h"
#include <iostream>
#include <vector>
#define CHECK(x) do{if(!(x)){std::cerr<<"CHECK_FAIL line="<<__LINE__<<" expr="<<#x<<"\n";return 10;}}while(0)
#define BCHECK(x) do{if(!(x)){std::cerr<<"BONUS_CHECK_FAIL line="<<__LINE__<<" expr="<<#x<<"\n";std::exit(10);}}while(0)
int main(){
  using namespace dkc3;
  Game lakeside;CHECK(lakeside.init("assets/levels/lakeside-limbo/lakeside-limbo.level"));CHECK(lakeside.hasRomScene());CHECK(lakeside.hasNativeScene());CHECK(lakeside.world().id=="lakeside-limbo");CHECK(lakeside.world().originalLevelId==0x25);CHECK(lakeside.world().goals.size()==1);CHECK(lakeside.world().goals[0].target=="doorstop");CHECK(lakeside.world().checkpoints.size()==1);CHECK(lakeside.world().width==6240&&lakeside.world().height==512);CHECK(lakeside.world().solids.empty());CHECK(lakeside.world().oneWayPlatforms.size()==375);CHECK(lakeside.world().waterZones.size()==1);CHECK(lakeside.enemies().size()==11);CHECK(lakeside.collectibles().size()==13);CHECK(lakeside.barrelCannons().size()==6);
  size_t warpEntry=0,warpExit=0,bonusEntry=0,bonusExit=0;for(const auto&b:lakeside.barrelCannons()){CHECK(b.animation.frames.size()==16);warpEntry+=b.role==BarrelCannonRole::WarpEntry;warpExit+=b.role==BarrelCannonRole::WarpExit;bonusEntry+=b.role==BarrelCannonRole::BonusEntry1||b.role==BarrelCannonRole::BonusEntry2;bonusExit+=b.role==BarrelCannonRole::BonusExit1||b.role==BarrelCannonRole::BonusExit2;}CHECK(warpEntry==1u&&warpExit==1u&&bonusEntry==2u&&bonusExit==2u);
  size_t runtimeSneeks=0,runtimeKobbles=0;for(const auto&e:lakeside.enemies()){runtimeSneeks+=e.id=="rom-sneek";runtimeKobbles+=e.id=="rom-kobble";if(e.id=="rom-kobble")CHECK(e.animation.frames.size()==8);}
  CHECK(runtimeSneeks==5u&&runtimeKobbles==6u);
  CHECK(lakeside.kongLetters().size()==3);CHECK(lakeside.kongLetters()[0].letter=='K');CHECK(lakeside.kongLetters()[1].letter=='O');CHECK(lakeside.kongLetters()[2].letter=='N');
  std::vector<uint32_t> lakesideFrame(256*224);lakeside.render(lakesideFrame.data(),256,224);CHECK(hashFrame(lakesideFrame.data(),lakesideFrame.size())==0xb3c29fd0119c8158ull);
  InputState lakeNone{};for(int i=0;i<30;i++)lakeside.step(lakeNone,1.0f/60.0f);CHECK(lakeside.player().grounded);
  bool sawWater=false;for(int i=0;i<10000&&lakeside.pendingLevel().empty();i++){InputState travel{};travel.right=true;travel.run=true;travel.jump=(i%100)<15;if(lakeside.inWater()){travel.up=true;travel.jump=true;}else if((i%34)==0)travel.attack=true;lakeside.step(travel,1.0f/60.0f);sawWater=sawWater||lakeside.inWater();}
  CHECK(sawWater);CHECK(lakeside.defeatedEnemies()>=1);CHECK(lakeside.damageCount()<=2);CHECK(lakeside.camera().x>0.0f);CHECK(lakeside.checkpointActivations()==1);CHECK(lakeside.pendingLevel()=="doorstop");
  CHECK(lakeside.player().nativeAirWallHits>=1);CHECK(lakeside.player().nativeGroundFollows>=1);CHECK(lakeside.bananas()>=1);// Separate overlap fixture: the traversal bot does not aim at ROM K/O/N.
  Game letterFixture;CHECK(letterFixture.init("assets/levels/lakeside-limbo/lakeside-limbo.level"));
  auto& letterPlayer=const_cast<Player&>(letterFixture.player());letterPlayer.pos=letterFixture.kongLetters()[0].pos;letterPlayer.vel={};
  letterFixture.step(lakeNone,1.0f/240.0f);CHECK(letterFixture.kongLettersCollected()==1);
  size_t bearRuntime=0,bananaRuntime=0,balloonRuntime=0;for(const auto&c:lakeside.collectibles()){bearRuntime+=c.id=="rom-bear-coin";bananaRuntime+=c.id=="rom-banana";balloonRuntime+=c.id=="rom-life-balloon";}CHECK(bearRuntime==3u&&bananaRuntime==5u&&balloonRuntime==5u);CHECK(lakeside.lives()>=5);

  // v0.34.0: os dois Bonus Barrels entram nos submaps PIER autorados pela
  // ROM, usam os alvos/tempos originais e retornam pelos barris pareados.
  {
    Game warp;CHECK(warp.init("assets/levels/lakeside-limbo/lakeside-limbo.level"));size_t entry=warp.barrelCannons().size();
    for(size_t i=0;i<warp.barrelCannons().size();++i){if(warp.barrelCannons()[i].role==BarrelCannonRole::WarpEntry){entry=i;break;}}
    CHECK(entry<warp.barrelCannons().size());
    auto& wp=const_cast<Player&>(warp.player());const auto& wb=warp.barrelCannons()[entry];wp.pos={wb.pos.x+wb.w*0.5f-wp.width*0.5f,wb.pos.y+wb.h*0.5f-wp.height*0.5f};wp.vel={};
    InputState enter{};enter.up=true;warp.step(enter,1.0f/60.0f);CHECK(warp.inBarrel());CHECK(warp.barrelEntries()==1);CHECK(warp.toast()=="WARP BARREL");enter.up=false;
    for(int i=0;i<40&&warp.inBarrel();++i){warp.step(enter,1.0f/60.0f);}
    CHECK(!warp.inBarrel());CHECK(warp.warpShortcuts()==1);CHECK(warp.player().pos.x>5900.0f);CHECK(warp.player().vel.x>200.0f);

    auto runBonus=[](int which,int target,int expectedWidth,int priorCoins,unsigned priorMask)->GamePersistentState{
      Game bonus;GamePersistentState ps;ps.bonusCoins=priorCoins;ps.lakesideBonusMask=priorMask;BCHECK(bonus.init("assets/levels/lakeside-limbo/lakeside-limbo.level",&ps));
      const BarrelCannonRole role=which==1?BarrelCannonRole::BonusEntry1:BarrelCannonRole::BonusEntry2;size_t be=bonus.barrelCannons().size();for(size_t i=0;i<bonus.barrelCannons().size();++i)if(bonus.barrelCannons()[i].role==role){be=i;break;}BCHECK(be<bonus.barrelCannons().size());
      auto& bp=const_cast<Player&>(bonus.player());const auto& bb=bonus.barrelCannons()[be];bp.pos={bb.pos.x+bb.w*0.5f-bp.width*0.5f,bb.pos.y+bb.h*0.5f-bp.height*0.5f};bp.vel={};InputState bu{};bu.up=true;bonus.step(bu,1.0f/60.0f);
      BCHECK(bonus.inBonus());BCHECK(bonus.activeBonus()==which);BCHECK(bonus.bonusBarrelAttempts()==1);BCHECK(bonus.bonusTarget()==target);BCHECK(bonus.world().width==expectedWidth&&bonus.world().height==512);BCHECK(bonus.bonusTimeRemaining()>19.0f);
      if(which==1)BCHECK(bonus.bonusCollectibles().size()==50u);else BCHECK(bonus.bonusCollectibles().size()==1u);
      InputState none2{};
      int guard=0;while(bonus.inBonus()&&bonus.bonusCollected()<target&&guard++<target*3){
        const RuntimeCollectible* pick=nullptr;for(const auto&c:bonus.bonusCollectibles())if(c.active){pick=&c;break;}BCHECK(pick!=nullptr);const int before=bonus.bonusCollected();bp.pos=pick->pos;bp.vel={};bonus.step(none2,1.0f/240.0f);BCHECK(bonus.bonusCollected()>before);
      }
      BCHECK(bonus.inBonus());BCHECK(bonus.bonusCollected()==target);
      BCHECK(bonus.bonusCoin().active);bp.pos=bonus.bonusCoin().pos;bp.vel={};bonus.step(none2,1.0f/240.0f);BCHECK(!bonus.inBonus());BCHECK(bonus.bonusCoins()==priorCoins+1);BCHECK((bonus.lakesideBonusMask()&(1u<<(which-1)))!=0u);BCHECK(bonus.world().width==6240&&bonus.world().height==512);BCHECK(bonus.player().vel.x>150.0f);
      const auto saved=bonus.persistentState();Game restored;BCHECK(restored.init("assets/levels/lakeside-limbo/lakeside-limbo.level",&saved));BCHECK(restored.bonusCoins()==bonus.bonusCoins());BCHECK(restored.lakesideBonusMask()==bonus.lakesideBonusMask());
      return saved;
    };
    const auto after1=runBonus(1,50,384,0,0);const auto after2=runBonus(2,15,384,after1.bonusCoins,after1.lakesideBonusMask);CHECK(after2.bonusCoins==2);CHECK((after2.lakesideBonusMask&3u)==3u);
  }

  Game g;CHECK(g.init("assets/levels/doorstop/doorstop.level"));CHECK(g.hasNativeScene());CHECK(g.scene().layers.size()==3);
  CHECK(g.playerSprite().valid());CHECK(g.companionSprite().valid());CHECK(g.spriteObjects().size()==1);CHECK(g.enemies().size()==3);CHECK(g.collectibles().size()==1);
  CHECK(g.world().doors.size()==1);CHECK(g.world().checkpoints.size()==1);CHECK(g.world().hangZones.size()==1);CHECK(g.world().levers.size()==1);CHECK(g.world().gates.size()==1);CHECK(g.levers().size()==1);CHECK(g.gates().size()==1);CHECK(!g.levers()[0].activated);CHECK(!g.gates()[0].open);CHECK(g.world().playerAnimations.size()>=6);CHECK(g.world().companionAnimations.size()>=6);
  CHECK(g.activeCharacter()==CharacterId::Dixie);CHECK(g.partnerAvailable());
  CHECK(g.playerSprite().width==48&&g.playerSprite().height==33);CHECK(g.companionSprite().width==54&&g.companionSprite().height==39);
  NativeAnimation dixieRoll,kiddyRoll;CHECK(loadNativeAnimation("assets/levels/doorstop/native/anims/dixie_attack.nanim",dixieRoll));CHECK(loadNativeAnimation("assets/levels/doorstop/native/anims/kiddy_attack.nanim",kiddyRoll));CHECK(dixieRoll.frames.size()==13&&!dixieRoll.loop);CHECK(kiddyRoll.frames.size()==12&&!kiddyRoll.loop);CHECK(hashSprite(dixieRoll.frames.front().sprite)!=hashSprite(dixieRoll.frames.back().sprite));CHECK(hashSprite(kiddyRoll.frames.front().sprite)!=hashSprite(kiddyRoll.frames.back().sprite));
  std::vector<uint32_t> fb(256*224);g.render(fb.data(),256,224);auto initialHash=hashFrame(fb.data(),fb.size());CHECK(initialHash!=0);

  InputState none{};for(int i=0;i<120;i++)g.step(none,1.0f/60.0f);CHECK(g.player().grounded);CHECK(g.playerAnimationState()=="idle");CHECK(g.companionAnimationState()=="idle");
  const float enemyStart=g.enemies()[0].pos.x;for(int i=0;i<30;i++)g.step(none,1.0f/60.0f);CHECK(std::fabs(g.enemies()[0].pos.x-enemyStart)>1.0f);

  // Tag manual: Dixie <-> Kiddy sem perder o parceiro.
  InputState tag{};tag.switchCharacter=true;g.step(tag,1.0f/60.0f);CHECK(g.activeCharacter()==CharacterId::Kiddy);CHECK(g.partnerAvailable());CHECK(g.characterSwitches()==1);CHECK(std::fabs(g.player().width-23.0f)<0.01f);
  tag.switchCharacter=false;g.step(tag,1.0f/60.0f);tag.switchCharacter=true;g.step(tag,1.0f/60.0f);CHECK(g.activeCharacter()==CharacterId::Dixie);CHECK(g.characterSwitches()==2);
  tag.switchCharacter=false;g.step(tag,1.0f/60.0f);

  InputState run{};run.right=true;run.run=true;for(int i=0;i<8;i++)g.step(run,1.0f/60.0f);CHECK(g.player().vel.x>0);CHECK(g.playerAnimationState()=="run");CHECK(g.companionAnimationState()=="run");CHECK(g.playerAnimationFrame()>0);
  InputState jump{};jump.jump=true;g.step(jump,1.0f/60.0f);CHECK(!g.player().grounded);CHECK(g.playerAnimationState()=="jump");CHECK(g.companionAnimationState()=="jump");
  jump.jump=false;for(int i=0;i<18;i++)g.step(jump,1.0f/60.0f);CHECK(g.playerAnimationFrame()>0);for(int i=0;i<40;i++)g.step(jump,1.0f/60.0f);CHECK(g.playerAnimationState()=="fall"||g.player().grounded);

  // Ataque/roll: estado proprio e derrota lateral de inimigo.
  Game attack;CHECK(attack.init("tests/data/team-combat-test.level"));for(int i=0;i<100;i++)attack.step(none,1.0f/60.0f);CHECK(attack.player().grounded);
  InputState atk{};atk.right=true;atk.run=true;atk.attack=true;attack.step(atk,1.0f/60.0f);CHECK(attack.attacking());CHECK(attack.playerAnimationState()=="attack");CHECK(attack.attackBounds().x>attack.player().pos.x);CHECK(attack.attackBounds().w>=28.0f);
  atk.attack=false;for(int i=0;i<4;i++)attack.step(atk,1.0f/60.0f);CHECK(attack.attackActive());CHECK(attack.playerAnimationFrame()>0);for(int i=0;i<24;i++)attack.step(atk,1.0f/60.0f);CHECK(attack.defeatedEnemies()==1);CHECK(!attack.enemies()[0].active);CHECK(attack.damageCount()==0);

  // Kiddy: roll real separado e alcance frontal maior.
  Game kattack;CHECK(kattack.init("tests/data/team-combat-test.level"));for(int i=0;i<100;i++)kattack.step(none,1.0f/60.0f);InputState ktag{};ktag.switchCharacter=true;kattack.step(ktag,1.0f/60.0f);CHECK(kattack.activeCharacter()==CharacterId::Kiddy);ktag.switchCharacter=false;kattack.step(ktag,1.0f/60.0f);InputState katk{};katk.right=true;katk.run=true;katk.attack=true;kattack.step(katk,1.0f/60.0f);CHECK(kattack.playerAnimationState()=="attack");CHECK(kattack.attackBounds().w>=34.0f);katk.attack=false;for(int i=0;i<5;i++)kattack.step(katk,1.0f/60.0f);CHECK(kattack.attackActive());CHECK(kattack.playerAnimationFrame()>0);for(int i=0;i<24;i++)kattack.step(katk,1.0f/60.0f);CHECK(kattack.defeatedEnemies()==1);CHECK(kattack.damageCount()==0);

  // Dano: com dois Kongs, o ativo troca para o parceiro e ganha i-frames.
  Game dmg;CHECK(dmg.init("tests/data/damage-test.level"));CHECK(dmg.activeCharacter()==CharacterId::Dixie);dmg.step(none,1.0f/60.0f);CHECK(dmg.damageCount()==1);CHECK(dmg.activeCharacter()==CharacterId::Kiddy);CHECK(!dmg.partnerAvailable());CHECK(dmg.invulnerabilityTime()>1.0f);
  const int firstDamage=dmg.damageCount();for(int i=0;i<20;i++)dmg.step(none,1.0f/60.0f);CHECK(dmg.damageCount()==firstDamage);CHECK(dmg.invulnerabilityTime()>0.0f);
  for(int i=0;i<100;i++)dmg.step(none,1.0f/60.0f);
  CHECK(dmg.invulnerabilityTime()==0.0f);
  InputState recover{};recover.right=true;recover.run=true;for(int i=0;i<260&&dmg.damageCount()==firstDamage;i++)dmg.step(recover,1.0f/60.0f);CHECK(dmg.damageCount()==2);CHECK(dmg.partnerAvailable());CHECK(dmg.invulnerabilityTime()>0.0f);CHECK(dmg.lives()==4);

  Game h;CHECK(h.init("assets/levels/doorstop/doorstop.level"));InputState up{};up.up=true;h.step(up,1.0f/60.0f);CHECK(h.player().motion==PlayerMotion::Hang);CHECK(h.playerAnimationState()=="hang");CHECK(h.companionAnimationState()=="hang");CHECK(!h.levers()[0].activated);
  up.up=false;for(int i=0;i<30;i++)h.step(up,1.0f/60.0f);CHECK(h.levers()[0].activated);CHECK(h.gates()[0].open);CHECK(h.leverActivations()==1);
  up.jump=true;h.step(up,1.0f/60.0f);CHECK(h.player().motion==PlayerMotion::Air);CHECK(h.player().vel.y<0);

  // Porta com requisito nao libera antes da alavanca.
  Game locked;CHECK(locked.init("tests/data/door-requirement-test.level"));InputState lockedUp{};lockedUp.up=true;locked.step(lockedUp,1.0f/60.0f);CHECK(locked.pendingLevel().empty());CHECK(locked.lockedDoorAttempts()==1);

  Game stomp;CHECK(stomp.init("tests/data/stomp-test.level"));for(int i=0;i<90;i++)stomp.step(none,1.0f/60.0f);CHECK(stomp.defeatedEnemies()==1);CHECK(stomp.damageCount()==0);CHECK(!stomp.enemies()[0].active);CHECK(stomp.player().vel.y<0||stomp.player().grounded);

  // O portao fisico bloqueia a progressao enquanto a alavanca esta fechada.
  Game blocked;CHECK(blocked.init("assets/levels/doorstop/doorstop.level"));for(int i=0;i<120;i++)blocked.step(none,1.0f/60.0f);InputState br{};br.right=true;br.run=true;for(int i=0;i<180;i++)blocked.step(br,1.0f/60.0f);CHECK(blocked.player().pos.x<132.0f);CHECK(!blocked.gates()[0].open);

  // Fluxo completo da secao: ativa alavanca -> abre portao -> checkpoint -> porta.
  Game d;CHECK(d.init("assets/levels/doorstop/doorstop.level"));for(int i=0;i<120;i++)d.step(none,1.0f/60.0f);InputState leverUp{};leverUp.up=true;d.step(leverUp,1.0f/60.0f);leverUp.up=false;for(int i=0;i<30;i++)d.step(leverUp,1.0f/60.0f);CHECK(d.leverActivations()==1);CHECK(d.gates()[0].open);
  InputState right{};right.right=true;right.run=true;for(int i=0;i<220;i++)d.step(right,1.0f/60.0f);CHECK(d.player().pos.x>160);CHECK(d.camera().x>0);CHECK(d.checkpointActivations()==1);right.right=false;right.run=false;right.up=true;d.step(right,1.0f/60.0f);CHECK(d.pendingLevel()=="tidal-trouble");auto rp=d.respawnPoint();CHECK(std::fabs(rp.x-112.0f)<0.01f&&std::fabs(rp.y-132.0f)<0.01f);

  d.render(fb.data(),256,224);auto movedHash=hashFrame(fb.data(),fb.size());CHECK(movedHash!=initialHash);

  // Sessao nativa: Doorstop realmente troca para um segundo .level e preserva o Kong ativo.
  GameSession session;CHECK(session.init("assets/levels/levels.index","doorstop"));CHECK(session.catalog().size()==3);CHECK(session.currentLevel()=="doorstop");
  for(int i=0;i<120;i++)session.step(none,1.0f/60.0f);
  InputState stag{};stag.switchCharacter=true;session.step(stag,1.0f/60.0f);CHECK(session.game().activeCharacter()==CharacterId::Kiddy);stag.switchCharacter=false;session.step(stag,1.0f/60.0f);
  InputState sup{};sup.up=true;session.step(sup,1.0f/60.0f);sup.up=false;for(int i=0;i<30;i++)session.step(sup,1.0f/60.0f);CHECK(session.game().leverActivations()==1);
  InputState sright{};sright.right=true;sright.run=true;for(int i=0;i<220;i++)session.step(sright,1.0f/60.0f);sright.right=false;sright.run=false;sright.up=true;session.step(sright,1.0f/60.0f);
  CHECK(session.transitions()==1);CHECK(session.currentLevel()=="tidal-trouble");CHECK(session.game().hasRomScene());CHECK(session.game().scenePageCount()==1);CHECK(session.game().world().width==7968);CHECK(session.game().romSpawnRuntime().records().size()==61);CHECK(session.game().activeCharacter()==CharacterId::Kiddy);
  const auto& meta=session.game().world().originalMetadata;CHECK(meta.romOffset==0x3D071B);CHECK(meta.sharedData==0x19F0);CHECK(meta.points.size()==6);CHECK(meta.connections.size()==2);
  GamePersistentState persisted{CharacterId::Kiddy,false,7};Game persistentProbe;CHECK(persistentProbe.init("assets/levels/tidal-trouble/tidal-trouble.level",&persisted));CHECK(persistentProbe.activeCharacter()==CharacterId::Kiddy);CHECK(!persistentProbe.partnerAvailable());CHECK(persistentProbe.coins()==7);
  session.setAutoTransitions(false);bool tidalWater=false;std::string tidalExit;
  for(int i=0;i<10000&&!session.takeExitRequest(tidalExit);++i){InputState in{};in.right=true;in.run=true;in.jump=i%100<15;if(session.game().inWater()){in.up=true;in.jump=true;}else in.attack=i%34==0;session.step(in,1.f/60);tidalWater|=session.game().inWater();}
  CHECK(tidalWater);CHECK(tidalExit=="skiddas-row");CHECK(session.game().checkpointActivations()==1);CHECK(session.game().lives()>0);CHECK(session.game().world().nativeScenePages.empty());
  std::vector<uint32_t> tidalFb(256*224);session.render(tidalFb.data(),256,224);auto tidalHash=hashFrame(tidalFb.data(),tidalFb.size());CHECK(tidalHash!=0&&tidalHash!=initialHash);



  // ===================== v0.8.0 =====================
  // Pulo por borda: segurar o botao nao repete o pulo ao pousar.
  {
    Game j;CHECK(j.init("tests/data/flat-test.level"));for(int i=0;i<60;i++)j.step(none,1.0f/60.0f);CHECK(j.player().grounded);
    InputState hold{};hold.jump=true;float minY=j.player().pos.y;int airFrames=0;for(int i=0;i<180;i++){j.step(hold,1.0f/60.0f);minY=std::min(minY,j.player().pos.y);if(!j.player().grounded)++airFrames;}
    CHECK(minY<j.player().pos.y-20.0f);CHECK(airFrames<60);CHECK(j.player().grounded);
  }
  // Altura variavel: toque curto sobe bem menos que segurar o pulo.
  {
    auto apex=[&](int holdFrames){Game j;j.init("tests/data/flat-test.level");for(int i=0;i<60;i++)j.step(none,1.0f/60.0f);const float y0=j.player().pos.y;float top=y0;InputState in{};
      for(int i=0;i<90;i++){in.jump=i<holdFrames;j.step(in,1.0f/60.0f);top=std::min(top,j.player().pos.y);}return y0-top;};
    const float tap=apex(2),full=apex(60);CHECK(full>35.0f);CHECK(tap<full*0.6f);CHECK(tap>4.0f);
  }
  // Coyote time: pulo logo depois de sair da borda funciona; muito depois, nao.
  {
    auto tryJump=[&](int lateFrames)->bool{Game c;c.init("tests/data/coyote-test.level");for(int i=0;i<60;i++)c.step(none,1.0f/60.0f);
      InputState r{};r.right=true;int guard=0;while(c.player().grounded&&guard++<400)c.step(r,1.0f/60.0f);if(c.player().grounded)return false;
      for(int i=0;i<lateFrames;i++)c.step(r,1.0f/60.0f);
      r.jump=true;c.step(r,1.0f/60.0f);return c.player().vel.y<-150.0f;};
    CHECK(tryJump(2));CHECK(!tryJump(12));
  }
  // Buffer de pulo: apertar um pouco antes de pousar dispara o pulo ao tocar o chao.
  {
    Game b;CHECK(b.init("tests/data/flat-test.level"));for(int i=0;i<60;i++)b.step(none,1.0f/60.0f);InputState in{};in.jump=true;b.step(in,1.0f/60.0f);in.jump=false;
    int guard=0;while(!(b.player().vel.y>0.0f&&b.player().pos.y+b.player().height>192.0f-8.0f)&&guard++<200)b.step(in,1.0f/60.0f);CHECK(guard<200);
    in.jump=true;b.step(in,1.0f/60.0f);in.jump=false;float bestVy=0.0f;for(int i=0;i<12;i++){b.step(in,1.0f/60.0f);bestVy=std::min(bestVy,b.player().vel.y);}CHECK(bestVy<-150.0f);
  }
  // Paredes de limite: nao da para sair do mapa lateralmente (Tidal: nadar ate o fim nao derruba o jogador).
  {
    Game w;CHECK(w.init("tests/data/tidal-legacy-test.level"));InputState r{};r.right=true;float maxX=0.0f;for(int i=0;i<700;i++){w.step(r,1.0f/60.0f);maxX=std::max(maxX,w.player().pos.x);}
    CHECK(maxX<=w.world().width-w.player().width+0.01f);CHECK(w.player().pos.y<w.world().height);CHECK(w.player().pos.x>w.world().width-w.player().width-1.0f);
    InputState l{};l.left=true;float minX=1e9f;for(int i=0;i<900;i++){w.step(l,1.0f/60.0f);minX=std::min(minX,w.player().pos.x);}CHECK(minX>=0.0f);CHECK(w.player().pos.x<1.0f);
  }
  // Transicao suave entre paginas de cena (crossfade) com camera estavel.
  {
    Game t;CHECK(t.init("tests/data/tidal-legacy-test.level"));InputState r{};r.right=true;bool sawFade=false;float maxProgress=0.0f;size_t startPage=t.activeScenePage();
    for(int i=0;i<400&&t.activeScenePage()==startPage;i++)t.step(r,1.0f/60.0f);
    CHECK(t.activeScenePage()>startPage);CHECK(t.pageFading());sawFade=true;
    std::vector<uint32_t> a((size_t)256*224),b2((size_t)256*224);t.render(a.data(),256,224);
    for(int i=0;i<30;i++){t.step(InputState{},1.0f/60.0f);maxProgress=std::max(maxProgress,t.pageFadeProgress());}CHECK(sawFade&&!t.pageFading()&&maxProgress>=1.0f);
    // Voltar nao pisca: dentro da histerese a pagina atual e mantida.
    const size_t pg=t.activeScenePage();InputState back{};back.left=true;for(int i=0;i<4;i++)t.step(back,1.0f/60.0f);CHECK(t.activeScenePage()==pg);
  }
  // HUD, toast, debug overlay e utilitarios de texto.
  {
    CHECK(hudSanitize("A\xC3\xA7\xC3\xA3o P\xC3\xB4r")=="ACAO POR");CHECK(hudTextWidth("AB")==11);CHECK(hudTextWidth("")==0);
    Game hdr;CHECK(hdr.init("assets/levels/doorstop/doorstop.level"));for(int i=0;i<30;i++)hdr.step(none,1.0f/60.0f);
    std::vector<uint32_t> withHud((size_t)256*224),noHud((size_t)256*224),dbg((size_t)256*224);hdr.render(withHud.data(),256,224);
    hdr.setHudEnabled(false);hdr.render(noHud.data(),256,224);CHECK(hashFrame(withHud.data(),withHud.size())!=hashFrame(noHud.data(),noHud.size()));
    hdr.setDebugOverlay(true);hdr.render(dbg.data(),256,224);CHECK(hashFrame(dbg.data(),dbg.size())!=hashFrame(noHud.data(),noHud.size()));
    Game lk;CHECK(lk.init("tests/data/door-requirement-test.level"));InputState lu{};lu.up=true;lk.step(lu,1.0f/60.0f);CHECK(lk.toast()=="PORTA TRANCADA"&&lk.toastTime()>1.0f);
    Game cp;CHECK(cp.init("assets/levels/doorstop/doorstop.level"));for(int i=0;i<120;i++)cp.step(none,1.0f/60.0f);InputState lev{};lev.up=true;cp.step(lev,1.0f/60.0f);lev.up=false;for(int i=0;i<30;i++)cp.step(lev,1.0f/60.0f);CHECK(cp.toast()=="PORTAO ABERTO");
  }
  // Sessao: restart recarrega a fase atual do zero e mantem as opcoes de HUD/debug.
  {
    GameSession rs;CHECK(rs.init("assets/levels/levels.index","doorstop"));rs.game().setDebugOverlay(true);InputState rr{};rr.right=true;for(int i=0;i<60;i++)rs.step(rr,1.0f/60.0f);
    CHECK(rs.game().player().pos.x>rs.game().world().spawn.x+5.0f);CHECK(rs.restart());CHECK(rs.currentLevel()=="doorstop");CHECK(std::fabs(rs.game().player().pos.x-rs.game().world().spawn.x)<0.01f);CHECK(rs.game().debugOverlay());CHECK(rs.game().levelTime()==0.0f);
  }
  // BMP: ida e volta sem perda.
  {
    std::vector<uint32_t> px={0xff112233u,0xff445566u,0xff778899u,0xffaabbccu,0xffddeeffu,0xff010203u};CHECK(saveBmp32("core_tests_tmp.bmp",px.data(),3,2));Bitmap bm;CHECK(loadBmp32("core_tests_tmp.bmp",bm));CHECK(bm.w==3&&bm.h==2&&bm.bgra==px);std::remove("core_tests_tmp.bmp");
  }
  // ===================== v0.9.0 - audio =====================
  auto has=[&](const std::vector<Sfx>&v,Sfx x){for(auto s2:v)if(s2==x)return true;return false;};
  {
    // Pulo e pouso emitem eventos; segurar o botao nao repete o som.
    Game a;CHECK(a.init("tests/data/flat-test.level"));for(int i=0;i<60;i++)a.step(none,1.0f/60.0f);a.takeSfx();
    InputState hold{};hold.jump=true;int jumps=0,lands=0;for(int i=0;i<120;i++){a.step(hold,1.0f/60.0f);for(auto s2:a.takeSfx()){if(s2==Sfx::Jump)++jumps;if(s2==Sfx::Land)++lands;}}
    CHECK(jumps==1);CHECK(lands==1);CHECK(a.takeSfx().empty());
    Game lk;CHECK(lk.init("tests/data/door-requirement-test.level"));InputState lu{};lu.up=true;lk.step(lu,1.0f/60.0f);CHECK(has(lk.takeSfx(),Sfx::Locked));
  }
  {
    // Mixer: silencio sem vozes, pico limitado, mudo, volume, voz expira, nao empilha disparos simultaneos.
    SfxMixer m;std::vector<int16_t> buf(2048,123);m.mix(buf.data(),(int)buf.size());for(auto v:buf)CHECK(v==0);
    m.setVolume(1.0f);for(int i=0;i<(int)Sfx::Count;++i)m.trigger((Sfx)i);CHECK(m.activeVoices()<=SfxMixer::kMaxVoices);
    int peak=0;for(int k=0;k<40;k++){m.mix(buf.data(),(int)buf.size());for(auto v:buf)peak=std::max(peak,std::abs((int)v));}CHECK(peak>3000&&peak<=32000);CHECK(m.activeVoices()==0);
    std::vector<int16_t> a1(2000),a2(2000);
    SfxMixer mu;mu.setMuted(true);mu.trigger(Sfx::Hurt);mu.mix(a1.data(),2000);for(auto v:a1)CHECK(v==0);
    SfxMixer lo;lo.setVolume(0.2f);lo.trigger(Sfx::Hurt);lo.mix(a1.data(),2000);SfxMixer hi;hi.setVolume(1.0f);hi.trigger(Sfx::Hurt);hi.mix(a2.data(),2000);
    int pl=0,ph2=0;for(int k=0;k<2000;k++){pl=std::max(pl,std::abs((int)a1[k]));ph2=std::max(ph2,std::abs((int)a2[k]));}CHECK(pl>0&&pl<ph2);
    for(int i=0;i<(int)Sfx::Count;++i){CHECK(sfxDuration((Sfx)i)>0.05f&&sfxDuration((Sfx)i)<0.5f);CHECK(std::string(sfxName((Sfx)i))!="?");}
    SfxMixer r;for(int i=0;i<5;i++)r.trigger(Sfx::Jump);CHECK(r.activeVoices()==1);
  }
  {
    auto run=[&](Game&g,int n,const InputState&in){std::vector<Sfx> o;for(int i=0;i<n;i++){g.step(in,1.0f/60.0f);auto e=g.takeSfx();o.insert(o.end(),e.begin(),e.end());}return o;};
    Game dm;CHECK(dm.init("tests/data/damage-test.level"));CHECK(has(run(dm,2,none),Sfx::Hurt));
    Game st;CHECK(st.init("tests/data/stomp-test.level"));CHECK(has(run(st,90,none),Sfx::Stomp));
    Game ra;CHECK(ra.init("tests/data/team-combat-test.level"));run(ra,100,none);InputState atk{};atk.right=true;atk.run=true;atk.attack=true;CHECK(has(run(ra,1,atk),Sfx::Roll));
    atk.attack=false;CHECK(has(run(ra,40,atk),Sfx::EnemyHit));
    Game sw;CHECK(sw.init("tests/data/team-combat-test.level"));run(sw,100,none);InputState q{};q.switchCharacter=true;CHECK(has(run(sw,1,q),Sfx::Switch));
    Game dp;CHECK(dp.init("assets/levels/doorstop/doorstop.level"));run(dp,120,none);InputState up{};up.up=true;run(dp,1,up);up.up=false;CHECK(has(run(dp,30,up),Sfx::Lever));
  }
  {
    // Sessao: o som da porta sobrevive a troca de fase no mesmo quadro; Tidal nao gera splash espurio ao iniciar.
    GameSession as;CHECK(as.init("assets/levels/levels.index","doorstop"));InputState none2{};for(int i=0;i<120;i++)as.step(none2,1.0f/60.0f);
    InputState up{};up.up=true;as.step(up,1.0f/60.0f);up.up=false;for(int i=0;i<30;i++)as.step(up,1.0f/60.0f);
    InputState rr{};rr.right=true;rr.run=true;for(int i=0;i<400&&as.currentLevel()=="doorstop";i++)as.step(rr,1.0f/60.0f);
    as.takeSfx();InputState dr{};dr.up=true;for(int i=0;i<120&&as.currentLevel()=="doorstop";i++)as.step(dr,1.0f/60.0f);
    std::vector<Sfx> ev=as.takeSfx();
    CHECK(as.currentLevel()=="tidal-trouble");
    {CHECK(has(ev,Sfx::Door));as.step(none2,1.0f/60.0f);CHECK(!has(as.takeSfx(),Sfx::Splash));}
  }

  // ===================== v0.20.0 - goal / saida automatica =====================
  {
    Game goal;CHECK(goal.init("tests/data/goal-test.level"));CHECK(goal.world().goals.size()==1);
    InputState gr{};gr.right=true;gr.run=true;for(int i=0;i<60&&goal.pendingLevel().empty();++i)goal.step(gr,1.0f/60.0f);
    CHECK(goal.pendingLevel()=="next-level");CHECK(has(goal.takeSfx(),Sfx::Door));
  }

  // ===================== v0.23.0 - saida para o mapa mundial =====================
  {
    GameSession ms;CHECK(ms.init("tests/data/session-manual.index","goaltest"));ms.setAutoTransitions(false);
    InputState mr{};mr.right=true;mr.run=true;std::string exit;for(int i=0;i<90&&!ms.takeExitRequest(exit);++i)ms.step(mr,1.0f/60.0f);
    if(exit.empty()){CHECK(ms.takeExitRequest(exit));}
    CHECK(exit=="next-level");CHECK(ms.currentLevel()=="goaltest");CHECK(ms.transitions()==0);
  }

  // ===================== v0.11.0 - correnteza de Tidal =====================
  {
    // A zona e lida do arquivo de fase e empurra para a esquerda.
    Game cur;CHECK(cur.init("tests/data/water-current-test.level"));CHECK(cur.world().waterCurrents.size()==1);
    const float x0=cur.player().pos.x;for(int i=0;i<90;i++)cur.step(none,1.0f/60.0f);
    CHECK(cur.inWater());CHECK(cur.inWaterCurrent());CHECK(cur.activeWaterCurrent().x<-20.0f);CHECK(cur.player().pos.x<x0-12.0f);
    // Nadar para a direita contra a corrente continua possivel, mas e mais lento que em agua calma.
    Player calm,against;calm.pos={100,80};against.pos=calm.pos;InputState swimRight{};swimRight.right=true;swimRight.run=true;
    for(int i=0;i<120;i++){updateSwimPlayer(calm,swimRight,1.0f/60.0f,nullptr,0,{});updateSwimPlayer(against,swimRight,1.0f/60.0f,nullptr,0,{-32,0});}
    CHECK(calm.pos.x>against.pos.x+45.0f);CHECK(against.pos.x>100.0f);
    Game tidal;CHECK(tidal.init("assets/levels/tidal-trouble/tidal-trouble.level"));CHECK(tidal.world().waterCurrents.size()==1);CHECK(tidal.world().waterCurrents[0].drift.x==-32.0f);
  }

  // ===================== v0.12.0 - entidades OAM de Tidal =====================
  {
    // O DK Barrel autentico e carregado como entidade nativa. Em estado SOLO,
    // tocar no barril restaura o parceiro uma unica vez e consome a entidade.
    GamePersistentState solo;solo.partnerAvailable=false;
    Game barrel;CHECK(barrel.init("tests/data/team-barrel-test.level",&solo));
    CHECK(barrel.world().teamBarrels.size()==1);CHECK(barrel.teamBarrels().size()==1);CHECK(barrel.teamBarrels()[0].active);CHECK(!barrel.partnerAvailable());
    barrel.takeSfx();barrel.step(none,1.0f/60.0f);
    CHECK(barrel.partnerAvailable());CHECK(!barrel.teamBarrels()[0].active);CHECK(barrel.teamBarrelRescues()==1);CHECK(barrel.toast()=="DUPLA RESTAURADA");CHECK(has(barrel.takeSfx(),Sfx::Switch));
    for(int i=0;i<10;i++)barrel.step(none,1.0f/60.0f);
    CHECK(barrel.teamBarrelRescues()==1);
    Game tidalEntity;CHECK(tidalEntity.init("assets/levels/tidal-trouble/tidal-trouble.level"));CHECK(tidalEntity.teamBarrels().size()==1);CHECK(tidalEntity.teamBarrels()[0].sprite.valid());
  }

  // ===================== v0.13.0 - letra K autentica / sistema K-O-N-G =====================
  {
    Game kong;CHECK(kong.init("tests/data/kong-letter-test.level"));
    CHECK(kong.world().kongLetters.size()==1);CHECK(kong.kongLetters().size()==1);CHECK(kong.kongLetters()[0].active);
    CHECK(kong.kongLetters()[0].letter=='K');CHECK(kong.kongLetters()[0].animation.frames.size()==8);CHECK(hashSprite(kong.kongLetters()[0].animation.frames[0].sprite)!=hashSprite(kong.kongLetters()[0].animation.frames[1].sprite));CHECK(kong.kongMask()==0);CHECK(kong.kongLettersCollected()==0);
    kong.takeSfx();kong.step(none,1.0f/60.0f);
    CHECK(!kong.kongLetters()[0].active);CHECK(kong.kongMask()==1u);CHECK(kong.kongLettersCollected()==1);CHECK(kong.toast()=="LETRA K");CHECK(has(kong.takeSfx(),Sfx::Coin));
    for(int i=0;i<10;i++)kong.step(none,1.0f/60.0f);
    CHECK(kong.kongLettersCollected()==1);
    Game tidalK;CHECK(tidalK.init("assets/levels/tidal-trouble/tidal-trouble.level"));CHECK(!tidalK.world().collectibles.empty());CHECK(tidalK.world().kongLetters.size()==3);CHECK(tidalK.kongLetters()[0].animation.frames.size()==8);
  }

  // ===================== v0.14.0 - Kiddy swim autentico em Tidal =====================
  {
    NativeAnimation kswim;CHECK(loadNativeAnimation("assets/levels/tidal-trouble/native/anims/kiddy_swim.nanim",kswim));
    CHECK(kswim.loop);CHECK(kswim.frames.size()==4);
    CHECK(kswim.frames[0].sprite.originX==27&&kswim.frames[0].sprite.originY==12);
    CHECK(kswim.frames[1].sprite.originX==27&&kswim.frames[1].sprite.originY==12);
    CHECK(kswim.frames[2].sprite.originX==27&&kswim.frames[2].sprite.originY==12);
    CHECK(hashSprite(kswim.frames[0].sprite)!=hashSprite(kswim.frames[1].sprite));
    CHECK(hashSprite(kswim.frames[1].sprite)!=hashSprite(kswim.frames[2].sprite));
    GamePersistentState kp;kp.activeCharacter=CharacterId::Kiddy;
    Game swim;CHECK(swim.init("assets/levels/tidal-trouble/tidal-trouble.level",&kp));
    InputState enterWater{};enterWater.right=true;enterWater.run=true;for(int i=0;i<3000&&!swim.inWater();++i){enterWater.jump=i%100<15;enterWater.attack=i%34==0;swim.step(enterWater,1.f/60);}CHECK(swim.inWater());CHECK(swim.playerAnimationState()=="swim");
    const size_t f0=swim.playerAnimationFrame();for(int i=0;i<8;i++)swim.step(none,1.0f/60.0f);CHECK(swim.playerAnimationFrame()!=f0);
  }

  // ===================== v0.15.0 - Sneek autentico em Tidal =====================
  {
    NativeAnimation sneekAnim;CHECK(loadNativeAnimation("assets/levels/tidal-trouble/native/enemies/sneek.nanim",sneekAnim));
    CHECK(sneekAnim.loop);CHECK(sneekAnim.frames.size()==1);CHECK(sneekAnim.frames[0].sprite.valid());
    CHECK(sneekAnim.frames[0].sprite.width==56&&sneekAnim.frames[0].sprite.height==24);
    CHECK(sneekAnim.frames[0].sprite.originX==0&&sneekAnim.frames[0].sprite.originY==0);
    Game tidalEnemies;CHECK(tidalEnemies.init("assets/levels/tidal-trouble/tidal-trouble.level"));
    CHECK(!tidalEnemies.enemies().empty());for(const auto& e:tidalEnemies.enemies())CHECK(e.id!="sneek_deck");
    CHECK(tidalEnemies.romSpawnRuntime().records().size()==61);

  }

  // ===================== v0.10.0 - streaming nativo =====================
  {
    Game stream;CHECK(stream.init("tests/data/streaming-test.level"));CHECK(stream.scenePageCount()==5);
    CHECK(stream.activeScenePage()==0);CHECK(stream.scenePageLoaded(0));CHECK(stream.scenePageLoaded(1));CHECK(stream.loadedScenePageCount()==2);
    InputState sr{};sr.right=true;sr.run=true;size_t maxLoaded=stream.loadedScenePageCount();
    for(int i=0;i<650;i++){stream.step(sr,1.0f/60.0f);maxLoaded=std::max(maxLoaded,stream.loadedScenePageCount());CHECK(stream.loadedScenePageCount()<=3);}
    CHECK(stream.activeScenePage()>=3);CHECK(maxLoaded<=3);CHECK(!stream.scenePageLoaded(0));
    std::vector<uint32_t> frame((size_t)256*224);stream.render(frame.data(),256,224);CHECK(hashFrame(frame.data(),frame.size())!=0);
  }
  std::cout<<"CORE_TESTS_OK initial="<<std::hex<<initialHash<<" moved="<<movedHash<<std::dec<<" camera="<<d.camera().x<<" enemies="<<g.enemies().size()<<" stomp="<<stomp.defeatedEnemies()<<" attack="<<attack.defeatedEnemies()<<" kiddyroll="<<kattack.defeatedEnemies()<<" switches="<<g.characterSwitches()<<" damage="<<dmg.damageCount()<<" lever="<<d.leverActivations()<<" checkpoints="<<d.checkpointActivations()<<" transitions="<<session.transitions()<<" tidal="<<std::hex<<tidalHash<<std::dec<<" v080=ok v090=ok v0100=ok v0110=ok v0120=ok v0130=ok v0140=ok v0150=ok v0200=ok v0210=ok\n";return 0;
}
