#include "core/Frontend.h"
#include "core/LevelSession.h"
#include "core/NativeScene.h"
#include <filesystem>
#include <fstream>
#include <iostream>
#include <vector>
#define CHECK(x) do{if(!(x)){std::cerr<<"CHECK_FAIL line="<<__LINE__<<" expr="<<#x<<"\n";return 10;}}while(0)
int main(){
  using namespace dkc3;
  const std::string dir="frontend_test_saves";std::filesystem::remove_all(dir);
  Frontend f;CHECK(f.init(dir));CHECK(f.screen()==FrontendScreen::BootPublisher);CHECK(!f.slots()[0].exists);
  std::vector<uint32_t> a(256*224),b(256*224);f.render(a.data(),256,224);const auto ha=hashFrame(a.data(),a.size());CHECK(ha!=0);
  FrontendInput none{};for(int i=0;i<80;i++)f.step(none,1.0f/60.0f);CHECK(f.screen()==FrontendScreen::BootStudio);for(int i=0;i<80;i++)f.step(none,1.0f/60.0f);CHECK(f.screen()==FrontendScreen::Title);f.render(b.data(),256,224);CHECK(hashFrame(b.data(),b.size())!=ha);
  FrontendInput ok{};ok.start=true;f.step(ok,1.0f/60.0f);CHECK(f.screen()==FrontendScreen::SaveSelect);ok.start=false;f.step(ok,1.0f/60.0f);ok.start=true;f.step(ok,1.0f/60.0f);
  FrontendLaunchRequest req;CHECK(f.takeLaunchRequest(req));CHECK(req.slot==1);CHECK(req.level=="lakeside-limbo");CHECK((req.worldMap.unlockedMask&WorldMap::stageBit("lakeside-limbo"))!=0);CHECK(f.slots()[0].exists);
  // V7 persistence stores submap state, ROM counters, lives and Lakeside bonus progress.
  GamePersistentState keep;keep.activeCharacter=CharacterId::Kiddy;keep.partnerAvailable=false;keep.coins=7;keep.bananas=13;keep.lives=9;keep.bonusCoins=2;keep.lakesideBonusMask=3;
  WorldMapState mapKeep;mapKeep.boatX=430;mapKeep.boatY=420;mapKeep.unlockedMask=WorldMap::stageBit("lakeside-limbo")|WorldMap::stageBit("doorstop")|WorldMap::stageBit("tidal-trouble");mapKeep.completedMask=WorldMap::stageBit("lakeside-limbo")|WorldMap::stageBit("doorstop");mapKeep.area=(int)WorldArea::LakeOrangatanga;mapKeep.lakeNode=2;
  CHECK(f.syncActiveSave("tidal-trouble",keep,&mapKeep));
  Frontend g;CHECK(g.init(dir));CHECK(g.slots()[0].currentLevel=="tidal-trouble");CHECK(g.slots()[0].worldMap.area==(int)WorldArea::LakeOrangatanga);CHECK(g.slots()[0].worldMap.lakeNode==2);CHECK(g.slots()[0].persistent.coins==7);CHECK(g.slots()[0].persistent.bananas==13);CHECK(g.slots()[0].persistent.lives==9);CHECK(g.slots()[0].persistent.bonusCoins==2);CHECK(g.slots()[0].persistent.lakesideBonusMask==3u);
  // Old V3 artificial Doorstop-first save migrates onto the real Lake order.
  const std::string legacy=dir+"/slot2.nsav";{std::ofstream out(legacy);out<<"DKC3_NATIVE_SAVE_V3\nlevel tidal-trouble\nunlocked 3\ncompleted 1\nworld_x 215\nworld_y 210\n";}
  Frontend h;CHECK(h.init(dir));const auto& ls=h.slots()[1];CHECK(ls.exists);CHECK(ls.currentLevel=="tidal-trouble");CHECK((ls.worldMap.unlockedMask&WorldMap::stageBit("lakeside-limbo"))!=0);CHECK((ls.worldMap.completedMask&WorldMap::stageBit("lakeside-limbo"))!=0);CHECK((ls.worldMap.completedMask&WorldMap::stageBit("doorstop"))!=0);CHECK((ls.worldMap.unlockedMask&WorldMap::stageBit("tidal-trouble"))!=0);CHECK(ls.worldMap.area==(int)WorldArea::LakeOrangatanga);CHECK(ls.worldMap.lakeNode==2);
  std::filesystem::remove_all(dir);std::cout<<"FRONTEND_V7_TESTS_OK\n";return 0;
}
