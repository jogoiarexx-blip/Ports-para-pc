#include "core/RomTerrain.h"
#include "core/RomData.h"
#include "core/Player.h"
#include <iostream>
#define CHECK(x) do{if(!(x)){std::cerr<<"TERRAIN_FAIL "<<__LINE__<<" "<<#x<<"\n";return 1;}}while(0)
int main(){using namespace dkc3;
  CHECK(romPierTerrainSample(1,1,6,0).height==31);
  CHECK(romPierTerrainSample(1,1,6,16).height==11);
  CHECK(romPierTerrainSample(0x4001,1,6,0).height==11);
  for(unsigned x=0;x<16;++x){
    CHECK(romPierTerrainSample(1,18,0,x).height==static_cast<int>(x/2));
    CHECK(romPierTerrainSample(1,0x8012,0,x).height==static_cast<int>((15-x)/2));
    CHECK(romPierTerrainSample(1,24,0,x).height==static_cast<int>(24+x/2));
    CHECK(romPierTerrainSample(1,75,0,x,32).height==(x==0?31:-1));
    CHECK(romPierTerrainSample(1,76,0,x,1).height==31);
  }
  CHECK((romPierTerrainSample(1,0x4040,0,0).attributes&0x0800)!=0);
  CHECK(!romPierTerrainSample(1,0xff,0,0).supported);
  CHECK(romPierTerrainSample(144,1,1,0).height==-1);
  std::vector<uint8_t> level{1,0},defs(576,0);defs[4]=1;defs[6]=6;
  std::vector<RomTerrainSurface> out;CHECK(buildRomPierSurfaces(level,defs,1,1,out));
  CHECK(out.size()==2&&out[0].x==0&&out[0].y==1&&out[0].width==16&&out[1].y==21);
  defs[4]=64;defs[6]=75;CHECK(!buildRomPierSurfaces(level,defs,1,1,out));CHECK(out.empty());
  CHECK(!buildRomPierSurfaces({},defs,1,1,out));
  RomLakesideLimboVisuals lake;CHECK(lake.load("rom/dkc3_ptbr.sfc"));CHECK(lake.waterSurfaceY()==408);
  bool deck=false;for(const auto&r:lake.collisionRects())if(r.x<=80&&r.x+r.width>80&&r.y==297)deck=true;
  CHECK(deck);for(const auto&r:lake.collisionRects()){CHECK(r.x>=0&&r.x+r.width<=6240);CHECK(r.y>0&&r.y<=512);}
  const auto& terrain=lake.terrain();
  CHECK(terrain.query(80,550).surfaceY()==297);
  CHECK(terrain.query(80,576).surfaceY()==297);
  CHECK(!terrain.query(6240,550).supported);
  CHECK(terrain.query(3344,550).surfaceY()==-1);
  std::vector<uint8_t> map(32,0),attrs(168,0);defs.assign(576,0);defs[4]=3;defs[6]=3;
  map[4]=1; // Partial floor in row 2, one/two rows below the query.
  RomPierTerrain synthetic;CHECK(synthetic.load(map,defs,attrs,1));
  CHECK(synthetic.query(4,289).surfaceY()==73);
  CHECK(synthetic.query(4,257).surfaceY()==73);
  CHECK(synthetic.query(4,0).surfaceY()==-1);
  Player player;RomMotionProfile kiddy;CHECK(loadRomMotionProfiles("rom/dkc3_ptbr.sfc",player.nativeMotion,kiddy));
  player.pos={4,0};player.height=10;Rect fakePlatform{0,10,32,8};InputState idle;
  for(int i=0;i<90;++i)updatePlayer(player,idle,1.0f/60.0f,nullptr,0,&fakePlatform,1,&synthetic);
  CHECK(player.grounded&&player.pos.y+player.height==73);
  CHECK(!synthetic.load({},defs,attrs,1));CHECK(!synthetic.query(4,289).supported);
  std::cout<<"NATIVE_TERRAIN_QUERY_OK neighbors, boundaries, original surface Y=297, host landing integration\n";
}
