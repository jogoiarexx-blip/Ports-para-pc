DKC3 Native PC v0.49.0 - Tidal ROM and Carry Barrels

Motor C++ nativo. ROM fornece dados e graficos; nao ha CPU/PPU/APU emulada
nova no jogo. As sondas de instrucoes originais vivem somente nos testes.

NOVIDADES
- Tidal passou do trecho de 512 pixels/3 capturas para o submapa PIER completo:
  7968x512 pixels, 61 placements e 180 superficies de piso decodificados da ROM.
- Lakeside, Tidal e as duas salas bonus de Lakeside usam o codec PIER comum.
- Spawn, respawn de checkpoint e altura da agua consultados na ROM.
- Forma de teto condicional $4D portada; 20132 consultas reais de Tidal
  comparadas com B7:CD1F. Nenhuma colisao inferida da imagem.
- DK Barrel: pegar, carregar, pular, lancar, colocar, regrab, atingir inimigos
  carregado/lancado, quebrar, restaurar parceiro SOLO e cancelar em dano/agua.
- DK Barrel registrado por SpriteID $0170 e criado dos placements nas duas fases.
- Letras KONG usam a mascara do descriptor, nao a ordem na lista de placements.
- Replays por input reproduziveis desde o spawn ate checkpoint/trigger de saida:
  Lakeside 3299 quadros; Tidal 6206 quadros. Nao injetam posicoes.
- Mantem os sprites fornecidos, excluindo Dixie DKC2 e Kremling Unused.

CONTROLES
Leia COMO-USAR-BARRIS.txt, COMO-USAR-CAVERNA.txt, COMO-USAR-AS-CORDAS.txt
ou pressione F1 no jogo. SHIFT/ombro direito permite correr sem pegar/rolar.

WINDOWS
Execute BUILD-WINDOWS.cmd (Visual Studio 2022 C++ e CMake).
O script compila 18 suites, headless, auditor, replay e o jogo; roda CTest;
monta bin e o ZIP portatil. As antigas paginas capturadas de Tidal sao
retiradas de bin. Este pacote contem fontes/assets; nao inclui EXE Windows
compilado/validado neste ambiente.

LIMITES ATUAIS
- Lakeside: 47 placements registrados, 36 PARTIAL, 11 UNKNOWN, 0 SUPPORTED.
- Tidal: 61 registrados, 20 PARTIAL, 41 UNKNOWN, 0 SUPPORTED. Peixes e varios
  inimigos ainda sem handler. Barrels de canhao aparecem visualmente, mas seus
  destinos/estados de tiro e bonus Tidal ainda nao foram portados.
- Checkpoint/saida ainda usam triggers amplos: os replays provam a rota do
  runtime atual, nao equivalencia completa com a bandeira/estados SNES.
- Os replays nao concluem Warp/Bonus 1/Bonus 2 ou 50 estrelas/15 bananas.
  Os testes de conclusao de bonus anteriores ainda usam fixtures de posicao.
- Controlador ainda tem adapters host para chao, parede, teto, agua e contatos
  de corda; escalada vertical/sliding/animações de transicao seguem parciais.
- O DK Barrel e funcional, com velocidades calibradas no host e poses comuns
  do personagem. Nao se declara traducao integral da maquina de estados SNES.
- Skidda/Murky/Belcha, mapa original e musica/SFX originais continuam pendentes.

VALIDACAO
18 executaveis passaram em Linux/GCC C++20 -O2, mais a sessao headless.
98309 comparacoes de formas de terreno, 20120 queries Lakeside e 20132 Tidal;
80000 comparacoes da borda da corda no teste C++.
Resultados: docs/VALIDACAO-v0.49.0.txt. Detalhes: docs/TIDAL-BARRELS.md.
