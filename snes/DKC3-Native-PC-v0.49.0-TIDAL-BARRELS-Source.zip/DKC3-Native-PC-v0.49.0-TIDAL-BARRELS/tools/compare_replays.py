#!/usr/bin/env python3
"""Compare aligned native CSV traces; exit 0 equal, 1 different, 2 invalid."""
import argparse,csv,sys,math
p=argparse.ArgumentParser();p.add_argument("left");p.add_argument("right");p.add_argument("--fields",help="comma-separated fields (default all)");p.add_argument("--tolerance",type=float,default=0);a=p.parse_args()
try:
 if a.tolerance<0 or not math.isfinite(a.tolerance): raise ValueError("invalid tolerance")
 with open(a.left,newline="") as f: left=list(csv.DictReader(f))
 with open(a.right,newline="") as f: right=list(csv.DictReader(f))
 if not left or not right: raise ValueError("empty trace")
 fields=a.fields.split(",") if a.fields else list(left[0])
 if any(k not in left[0] or k not in right[0] for k in fields): raise ValueError("missing column")
 for label,rows in (("left",left),("right",right)):
  if any(int(row["frame"])!=i for i,row in enumerate(rows)): raise ValueError(label+" frames must start at 0 and be consecutive")
 if len(left)!=len(right): print(f"DIFFERENT lengths {len(left)} / {len(right)}");sys.exit(1)
 for i,(l,r) in enumerate(zip(left,right)):
  for k in fields:
   same=l[k]==r[k]
   if not same and k in {"x","y","vx","vy"}:
    same=math.isfinite(float(l[k])) and math.isfinite(float(r[k])) and abs(float(l[k])-float(r[k]))<=a.tolerance
   if not same: print(f"DIFFERENT frame={i} field={k}: {l[k]} / {r[k]}");sys.exit(1)
 print(f"MATCH {len(left)} frames; {len(fields)} fields")
except (OSError,ValueError,KeyError) as e: print(f"INVALID: {e}",file=sys.stderr);sys.exit(2)
