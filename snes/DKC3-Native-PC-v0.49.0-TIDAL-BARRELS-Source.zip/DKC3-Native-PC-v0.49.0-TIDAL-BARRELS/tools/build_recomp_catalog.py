#!/usr/bin/env python3
"""Regenerate structural catalog from the pinned external upstream checkout."""
from pathlib import Path
import argparse,json,re,subprocess
p=argparse.ArgumentParser();p.add_argument("upstream_checkout");p.add_argument("output");a=p.parse_args()
up=Path(a.upstream_checkout);output=Path(a.output)
commit=subprocess.check_output(["git","-C",str(up),"rev-parse","HEAD"],text=True).strip()
if commit!="3a033f19801a2bd3abf784d4b29c4462495d19de": raise SystemExit("Unexpected upstream commit; review metadata changes before updating pin.")
items=[];dispatch=[];regions=[]
for p in sorted((up/'recomp').glob('bank*.cfg')):
 bank=int(re.search(r'bank\s*=\s*(0x[0-9a-fA-F]+|0)',p.read_text()).group(1),0)
 for line in p.read_text().splitlines():
  words=line.split()
  if not words:continue
  if words[0]=='func':
   pc=int(words[2],16);end=int(next(w[4:] for w in words if w.startswith('end:')),16)
   items.append({'name':words[1],'address':(bank<<16)+pc,'end_address':(bank<<16)+end,'entry_mx':next((w[9:] for w in words if w.startswith('entry_mx:')),None)})
  elif words[0]=='indirect_dispatch':dispatch.append({'bank':bank,'spec':line})
  elif words[0]=='data_region':regions.append({'bank':int(words[1],16),'start':int(words[2],16),'end':int(words[3],16)})
data={'upstream':'https://github.com/elliotttate/DKC3Recomp','commit':commit,'rom_sha256':'2277a2d8dddb01fe5cb0ae9a0fa225d42b3a11adccaeafa18e3c339b3794a32b','functions':items,'dispatch':dispatch,'data_regions':regions}
output.write_text(json.dumps(data,indent=2)+'\n');print('CATALOG',len(items),len(dispatch),len(regions),commit)
