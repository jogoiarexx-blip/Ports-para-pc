# Forja65 v0.3.96 — tradução de BE:D8E7 e pré-análise de B9:AB24

Forja65 importou estado real da CPU e gerou `BE:D8E7`: 14 PCs novos, 30 linhas de dispatch, duas variantes C0/CQ, sem substituir implementações anteriores. Validação contra ROM por 97 rastros de opcode (sem divergências estáticas). A função não relacionada `sub_BB8567_E0M0X0CQ` foi excluída da integração para evitar redefinições.

O ZERO compilou no Linux e executou **14.451 frames**, contra **14.420** anteriores, com prefixo de framebuffer/WRAM/PC idêntico. Novo bloqueio observado no replay: `B9:A149 → B9:AB24`, `JMP ($0042)` por ponteiro indireto em memória. Pré-análise **sem aplicar** encontrou 5 PCs novos, 10 registros potenciais e 36 PCs preservados.

Testes: `python tests/bed8e7-crossfeed-regression.py`, `node tests/cross-project-replay-v0397-regression.js`, `node tests/ingest-indexed-flow-v0396-regression.js`. Provas e logs: `reports/validation-crossfeed-0396/bed8e7-integrated`. Análise de opcode não é equivalência semântica.
