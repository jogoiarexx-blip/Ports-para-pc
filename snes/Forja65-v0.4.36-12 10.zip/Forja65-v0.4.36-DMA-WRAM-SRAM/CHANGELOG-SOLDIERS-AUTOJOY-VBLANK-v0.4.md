# Forja65 0.4.04 — correção genérica VBlank Auto-Joy (v0.4)

O caminho real `SnesRuntime::advanceCpuMasterCycles()` passa a chamar `scheduleAutoJoyRead()` na transição para a primeira linha de VBlank. O helper `beginVblank()` já fazia isso, mas não era o caminho usado durante os jogos compilados. Corrige a discrepância entre testes sintéticos e execução real: `$4218–$421F` não recebiam dados dos controles mesmo quando `$4212` indicava a janela de leitura. Não muda a duração de 4224 master cycles, não injeta entradas e não modifica a ROM.

Teste de regressão em `tests/soldiers-autojoy-vblank-v04-regression.js`, com teste funcional de relógio e latch no port Soldiers of Fortune v0.4 (`auto_joy_vblank_timeline_smoke.cpp`). A ROM e outras versões do Forja65 permanecem independentes.
