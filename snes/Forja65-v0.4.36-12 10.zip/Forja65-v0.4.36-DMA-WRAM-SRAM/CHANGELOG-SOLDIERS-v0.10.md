# Forja65 — Soldiers of Fortune crossfeed v0.10

- Ferramenta nova: `tools/advance-latest-runtime-blocker.py`.
- Lê o último erro CFG, exige observação correspondente na saída real do port,
  rejeita estados conflitantes e executa `advance-observed-target.py` com
  verificação do código contra a ROM antes de propor integração.
- Por padrão realiza preview; `--apply` necessário para alterar o projeto.
- Testes novos: `tests/advance-latest-runtime-blocker-regression.py`, 7 casos.
- Demonstração real: destino C0:D3E9 (observado a partir de C0:D38E),
  adicionado após validação de ROM sem conflitos.
- O utilitário não valida equivalência com console SNES nem garante gameplay;
  a execução e os testes continuam obrigatórios após cada integração.

Resultado do último replay após cinco rotinas: frame 5359, 81642796 instruções; próximo C0:D8B0 de C0:D863.
