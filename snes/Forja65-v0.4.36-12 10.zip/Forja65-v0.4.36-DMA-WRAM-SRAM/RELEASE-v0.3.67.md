# Forja65 v0.3.67

* Observacao de retornos `STACK-RTS/RTL` validada pela ROM e pelo log exato; recusa observacoes forjadas, erradas ou de outra ROM.
* Relatorio PPU corrige brilho zero como condicao sem imagem visivel mesmo quando forca de blank e retirada.
* CFG monotonic cache da mesma ROM v0.3.66 e compativel, sem refatorar o decodificador.
* Testes: `tests/observed-stack-return-v0367-regression.js`, `tests/ppu-timeline-brightness-v0367-regression.js` e regressao antiga v0.3.66.
* DKC3 completou 300 frames com este gerador, mas **a tela de abertura nao esta validada**; proximo erro de CFG e `B9A20F -> B9B90D`.
