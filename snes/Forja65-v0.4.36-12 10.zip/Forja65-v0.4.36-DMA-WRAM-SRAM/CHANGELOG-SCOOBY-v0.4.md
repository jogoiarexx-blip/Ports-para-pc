# Forja65 Scooby v0.4 — auditoria visual com multiplos quadros

- `FORJA65_CAPTURE_FRAMES=1050,1600,2300` captura evidencias reais de varias cenas no mesmo replay, cada uma isolada em `capture-XX/frame-<numero>/`.
- `tools/replay-converge.js --capture-frames 1050,1600,2300` valida os numeros, preserva o recurso de quadro unico e registra o pedido no relatorio JSON.
- Smoke test gerado exercita dois quadros e verifica que as capturas nao se sobrescrevem.
- O modo de captura e diagnostico, sem substituicao da PPU ou desativacao de validacoes; o port ainda exige a ROM em runtime.

- `--stall-iterations 5` e validação das capturas completados; 9/9 JS + 1/1 C++ smoke.
