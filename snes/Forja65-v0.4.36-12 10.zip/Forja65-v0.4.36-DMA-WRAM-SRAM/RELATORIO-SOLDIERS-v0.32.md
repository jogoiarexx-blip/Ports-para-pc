# Forja65 — Soldiers Crossfeed v0.32

## Progresso validado em replay controlado

- Base: v0.31, ROM fingerprint `2f095d162726b5ea`; o binário original da ROM não é redistribuído separadamente nesta atualização.
- O fluxo de reprodução foi corrigido **pela integração de blocos nativos gerados dos bytes da ROM**, sem modificar o GET READY ou a WRAM para passar artificialmente.
- Primeiro bloqueio resolvido: `C0:FC98`, visto a partir de `C0:F94B` no quadro 5796.
- Depois de aplicar seis integrações, o replay avançou até o bloqueio em `C2:0831`, vindo de `C0:4402`, no quadro 5798.
- **O jogo não entrou comprovadamente em gameplay**. Contagem GET READY, movimento e disparos continuam pendentes.

## Rotinas novas integradas

| PC alvo | Chamador | PCs novos únicos | Entradas de despacho | Resultado de replay |
|---|---|---:|---:|---|
| `$C0FC98` | `$C0F94B` | 122 | 270 | passou, revelou `$C03971` |
| `$C03971` | `$C0CBD6` | 39 | 88 | passou, revelou `$C0C118` |
| `$C0C118` | `$C0C0FE` | 20 | 42 | passou, revelou `$C0C34D` |
| `$C0C34D` | `$C0C066` | 34 | 75 | passou, revelou `$C0BCA5` |
| `$C0BCA5` | `$C0C385` | 4 | 8 | passou, revelou `$C207C2` |
| `$C207C2` | `$C043F2` | 60 | 120 | passou, revelou `$C20831` |

**Total v0.32:** 279 PCs novos e 603 entradas adicionais de despacho.

## Integridade e regressão

- `game` compilado no Linux em Debug após cada novo bloco.
- Integração observada com verificação de `proof.json`: corresponde à rotina solicitada, PCs decodificados e fingerprint da ROM.
- Testes Python: 4 testes existentes + 5 testes novos de proveniência, em ambos os projetos: **9/9** por projeto.
- CTest geral: **22 passaram, 2 falharam e 1 foi pulado**. Falhas: `native_migration_smoke` (código de saída 5) e `obj_sprite_bank_smoke` (`DMA must upload OBJ tile to alternate bank`). Esses pontos do runtime/PPU não foram alterados nesta evolução; exigem análise separada.
- O último replay termina em código 2, após alcançar `C2:0831` no quadro 5798. Não tratar isso como replay bem-sucedido.
- Não foi realizada verificação visual lado a lado com emulador do SNES original.

## Arquivos e próximo passo

- No Soldiers: seis novos `src/forja_*.cpp`, alterações de `src/dispatch.cpp` e `CMakeLists.txt`, provas em `analysis/v32-rom-backed/` e scripts `TESTAR-GET-READY-CFG-v32.*`.
- No Forja65: `tools/integrate-observed-flow.py` fortalecido com validação de prova ROM-backed e teste `tools/test_flow_proof_v32.py`.
- Próximo bloqueio observado: **`C2:0831` a partir de `C0:4402`**. Resolver sem bypass, depois revalidar GET READY e controles.
