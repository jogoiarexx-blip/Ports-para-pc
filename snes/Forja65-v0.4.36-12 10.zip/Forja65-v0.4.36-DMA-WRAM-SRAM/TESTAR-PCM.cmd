@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul || (echo [ERRO] Necessario Node.js no PATH. & exit /b 1)
where g++ >nul 2>nul || (echo [ERRO] Necessario g++ C++20 no PATH (MSYS2/MinGW). & exit /b 1)
node tests\pcm-output-v0435-regression.js
if errorlevel 1 exit /b 1
echo Testes PCM concluídos.
pause
