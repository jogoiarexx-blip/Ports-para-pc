# Forja65 v0.4.26 — sincronização SPC700/DSP por amostra

Base: Forja65 v0.4.25; melhora o runtime C++ gerado para qualquer ROM, sem incorporar o port do Tetris.

- `FORJA65_APU_DSP_INTERLEAVE=1` disponibiliza o agendamento em fatias até a próxima amostra DSP; padrão compatível/desativado, para evitar regressões em jogos não avaliados.
- `tickSpcMasterCycles` extrai o código SPC anterior sem modificá-lo.
- `tickMasterCycles` passa a intercalar CPU de áudio e síntese DSP quando a opção está ativa.
- `RUN-WINDOWS-AUDIO-INTERLEAVED.cmd` é emitido automaticamente junto de cada projeto gerado.
- Manifesto registra `dsp_spc_interleave` e `dsp_spc_interleave_slices`.
- Nova regressão `tests/audio-dsp-spc-interleave-v026-regression.js`: gera um port sintético, compila C++ e verifica escrita de registrador temporal, PCM idêntico com lotes de tamanhos diferentes e modo antigo.

Limitações: aproximação no limite da amostra, sem emulação de subciclos do barramento e sem confrontação com hardware real. Mantém todo o conversor e as melhorias prévias de áudio intactas.
