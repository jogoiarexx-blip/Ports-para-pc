# Teste da Forja65 v0.4.35 no Windows

1. Extraia o ZIP e abra `ABRIR-FORJA65.cmd`.
2. Reabra a ROM, **gere um novo projeto** e rode `BUILD-WINDOWS.cmd` nele.
   O motor mudou; um executável C++ antigo não recebe a correção sozinho.
3. Inicie `RUN-WINDOWS-AUDIO.cmd` (32000 Hz) e escute a música e os efeitos.
4. Opcional: inicie `RUN-WINDOWS-AUDIO-48KHZ.cmd` (48000 Hz para WinMM).
5. Se quiser verificar o sinal do DSP sem depender da placa de som, use
   `RUN-NATIVE-AUDIO.cmd`, que gera `forja65-native-audio.wav` **32000 Hz**.
6. Veja o arquivo `forja65-audio-report.txt` no jogo gerado. Confira
   `frames_dropped`, `pcm_buffer_wait_ms`, `gain_clipped_frames` e
   `output_rate_hz`. Em 48k `frames_queued` refere-se ao dispositivo.
7. No pacote Forja, `TESTAR-DSP-PCM.cmd` compila e roda regressões em Node.js
   + g++ C++20, incluindo um Windows simulado. Não depende de ROM comercial.

Se houver som distorcido, compare os modos legado acima. Para verificar eco
real no SPC RAM, habilite `FORJA65_ECHO_RAM_WRITES=1` **somente num teste**,
pois o layout da RAM do SPC700 ainda não é auditado em todas as ROMs.

**Importante:** o WinMM 48k é interpolação linear, não um DSP original com
frequência diferente. Sem análise diferencial de WAVs e teste em Windows
real não é possível declarar fidelidade idêntica ao SNES.
