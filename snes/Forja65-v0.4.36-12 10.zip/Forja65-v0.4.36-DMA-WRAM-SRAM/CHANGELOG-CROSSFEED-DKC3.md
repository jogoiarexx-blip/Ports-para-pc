# Forja65 v0.3.96 — importação cruzada DKC3 ZERO / Native PC

Nova ação CLI `import-replay`: usa a ROM real, `integration.json` do ZERO/Native, o catálogo `forja65.knowledge.v1`, os logs de erro FLOW/STATE e o último estado da CPU dos traces. Confronta `SHA-256 + FNV-1a64 + tamanho` da ROM com ambos os projetos, confronta os endereços/flags com erros e traces, recusa divergências, e só então emite `runtime-hints.txt` e `knowledge-pack.json` para reanálise do Forja65.

**Não:** emite callbacks equivalentes, converte as 4.724 entradas estáticas em execução observada, modifica código de gameplay do DKC3 Native PC ou comprova replay completo do ZERO.

## Como usar

Em um diretório contendo a ROM e os relatórios do ZERO, chame:

```text
node tools/forja65.js import-replay cart-data.bin --integration integration.json --knowledge forja65-knowledge.json --trace replay-after-carry/forja65-crash-trace.txt --error replay-after-carry/forja65-last-error.txt --prior-trace replay-before-bridge/forja65-crash-trace.txt --prior-error replay-before-bridge/forja65-last-error.txt --state-log replay-after-dispatch/forja65-unresolved-state.txt --out crossfeed-gerado
```

Os três hints verificados estão também em `examples/dkc3-cross-project-0396/`. Na reanálise, passe **explicitamente** `--hints` e, se desejar, `--knowledge`. Os artefatos originais do ZERO precisam ser preservados em uma pasta separada até se comparar hashes e comportamento do jogo.

## Evidência

- 3 observações importadas: `B8:A6A6/C0`, `B8:D795/C1` e `BE:C394/C0`;
- 4.724 entradas estruturais Native mantidas como candidatos estáticos;
- regressão sintética falha-fechada para ROM errada, PC divergente, flag alterado, log FLOW inconsistente e alegação de equivalência não sustentada;
- prova de gerador com ROM real (análise isolada): 3.199 endereços decodificados / 178 variantes de funções sob orçamento 4.500. Dispatcher contém os três endereços nos estados observados;
- teste de sintaxe C++ das três unidades recompiladas e dispatcher aprovado;
- **limite:** build completo cancelado por timeout do ambiente a aproximadamente 47% (não significa erro de código). Não foi executada a primeira fase usando a nova geração.

## Replay posterior e quarta observação

`import-replay` agora aceita opcionalmente `--followup-trace` e `--followup-error` como par, valida PC/fluxo/flags do trace de retorno e adiciona `BE:C3B1 → BE:C69E` (E0/M0/X0/C0) como quarta evidência ROM-bound. O ZERO integrado compilou e preservou 14.417 hashes no replay; a regeneração integral experimental continua **sem build/replay completos confirmados**. Exemplos em `examples/dkc3-cross-project-0396/` atualizados.


## BE:C69E e fluxo indexado BE:C37C (nova rodada)

- `tools/verify-generated-rom.js`: auditoria genérica que verifica os opcodes do C++ emitido contra os bytes mapeados da ROM, recusa ROM diferente e não confunde auditoria estática com equivalência de CPU. **97 instruções únicas/194 emissões** foram verificadas para BE:C69E.
- `tools/ingest-indexed-flow.js`: importa uma falha observada em `JMP (abs,X)` apenas após confrontar PC/PB, flags, índice X e tabela de ponteiros na ROM. O fluxo real `BE:C37C -> BE:C774` foi verificado com **X=6**, ponteiro em **BE:C385** e flags **E0/M0/X0/C1**.
- Duas novas regressões sintéticas, incluindo casos negativos de ROM/PC/bytes inconsistentes.
- ZERO recompilado e testado: **14.417/14.417 hashes idênticos**, novo bloqueio no mesmo frame, **nenhum frame adicional**.
- Os dados seguem vinculados ao SHA-256 da mesma ROM e são consumidos pelo Native PC apenas como evidência.

## Rodada BE:C774 / B8:9001

- Traduzido BE:C774 a partir de ROM: 56 posições de instrução, 112 emissões em duas variantes de carry, 0 divergências em auditoria estática.
- Novo utilitário **genérico** `tools/integrate-generated-cfg.py`: dry-run padrão, exige `--apply`, valida hash ROM e código, detecta rotinas duplicadas/endereços conflitantes, preserva dispatcher ordenado e atualiza CMake. Nova regressão com casos negativos aprovada.
- ZERO: nova função emitida incorporada, CMake e dispatcher atualizados; compilação Linux aprovada, CTest 22 aprovados e 1 ignorado, replay 14.417/14.417 hashes idênticos e 0 frames completos extras.
- Novo fluxo `B8:8304 -> B8:9001`, `X=0x20`, ponteiro ROM `B8:8020`, conferido pelo importador de saltos indexados. O Native reconhece o rótulo estrutural `player_interaction_10`.
- Forja já produziu C++ experimental para `B8:9001`, **não integrado nem executado no ZERO**: 38 opcodes únicos, 76 emissões conferidas; preferir análise com hint isolado quando o orçamento limitado excluir essa rotina.
- Nenhum handler de animação do DKC3 Native foi alterado. Nenhuma evidência aqui equivale à conclusão da fase.
