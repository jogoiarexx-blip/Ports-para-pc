# Forja65 v0.4.34.1 — crossfeed reunificado dos seis projetos

Data: 12/10/2026. Versão do motor/decoder preservada: `0.4.34-ppu-mode7-math`. O número `.1` refere-se à distribuição reunificada, **não** a um novo decoder. Nenhum dos seis ZIPs originais foi modificado, e os projetos de cada jogo continuam separados.

## Resultado comprovado

- **Base:** v0.4.34, incluindo os avanços do Mode 7, PPU, tempo de CPU/APU/DMA e perfis do SPC700.
- **Áudio do Biker v0.4.27:** reincorporado agendamento SPC700/DSP opcional (`FORJA65_APU_DSP_INTERLEAVE=1`), com launcher e registro de amostras/fatias no manifesto. Correção testada com runtime C++ gerado: `FORJA65_DSP_SPC_INTERLEAVE_V026_PASS`. O padrão permanece desativado.
- **Soldiers v0.38:** recuperados auditores de integração e recuperação do fluxo observado. A prova de ROM volta a rejeitar discrepância entre estados medidos E/M/X/C e variantes decodificadas. Correlação WRAM/vídeo recupera contagem de frames cobertos, transições visuais e cobertura, conservando rejeição de frames duplicados e bytes inválidos.
- **Crossfeed corrigido v0.4.31:** restaurada a procura por proprietários de handlers em `generated_NNN.cpp`, além de arquivos `forja_<PC>.cpp`. Restabelecido o reconhecimento dos erros `STATE` na seleção de destino, com o encaminhamento de `--missing-states`.
- **F-Zero v0.4.26 e 6 ramos v0.4.29:** todo o conjunto de caminhos de arquivo já estava incluído na v0.4.34; seus mecanismos mais antigos não foram usados para substituir avanços recentes.
- **Biker:** recuperados documentos históricos relevantes e a regressão original de SPC/DSP, com o fixture C++.

## Comparação de arquivos — caminho normalizado pelo diretório raiz

| Ramo | Arquivos no ZIP | Arquivos presentes nesta entrega | Ausentes |
|---|---:|---:|---:|
| Forja65-v0.4.19-SOLDIERS-CROSSFEED-v0.38(1) | 2386 | 2386 | 0 |
| Forja65-v0.4.26-PATCHES-FZERO-v0.2(1) | 2897 | 2897 | 0 |
| Forja65-v0.4.27-BIKER-CFG-GUARD-v0.8(1) | 2374 | 2374 | 0 |
| Forja65-v0.4.29-CROSSFEED-6-RAMOS(1) | 3056 | 3056 | 0 |
| Forja65-v0.4.31-CROSSFEED-CORRIGIDO(1) | 3148 | 3133 | 15 |
| Forja65-v0.4.34-PPU-MODE7-PRECISAO | 3264 | 3262 | 2 |

Perto da v0.4.34 original, esta entrega adicionou **29** arquivos e alterou **11** arquivos existentes, incluídos relatórios e manifestos regenerados. O aumento da quantidade de arquivos **não** mede velocidade, fidelidade ou percentual de jogos compatíveis. Caminhos ausentes nas versões mais antigas podem corresponder a relatórios não importados, não a recursos eliminados.

## Testes

- Os testes Python de integração do CFG: **11/11**; auditor de prova: **3/3**; recuperação de fluxo: **4/4**; seleção STATE: **3/3**; ranqueamento WRAM/vídeo: **4/4**; WRAM diff: **7/7**.
- O teste C++ de interleave SPC/DSP voltou a passar; a verificação de bank carry também passou.
- Resultados atuais dos três regressos nativos: audio-dsp-fractional-clock-v025-regression.js: PASS, ppu-mode7-math-v0434-regression.js: PASS, timing-order-v0432-regression.js: PASS.
- A base v0.4.34 fornecida registra **201/240 aprovações** (83,75%) na suíte histórica completa, com **39 falhas**. **Não se afirma 202/241 ou aprovação de toda a suíte agora**: esta execução não repetiu os 241 testes após a fusão. Cinco casos dirigidos haviam passado antes do reparo de SPC/DSP, mas essa execução foi interrompida antes do conjunto completo.
- A v0.4.34 fornecida registra também 41/41 regressões focadas de PPU/CPU/SPC. Esses resultados históricos não foram transferidos como se fossem execução fresca; nesta entrega há os três casos nativos individuais acima.

## O quanto melhorou, com números responsáveis

1. **Mais cobertura de falhas do integrador:** 8 casos existentes passaram a 11 casos, **+3 testes (+37,5%)** cobrindo prova de estado e proprietário de handlers.
2. **Modo funcional recuperado:** SPC/DSP intercalado, ausente da v0.4.34, agora gera launcher próprio e passa novamente no teste C++ de interleave; sem alegação de equivalência exata ao chip físico.
3. **Mais capacidade de diagnóstico:** dois auditores e dois testes Soldiers recuperados, métricas correlacionadas de WRAM/vídeo e seleção de estado CPU corrigida.
4. **Sem regressão funcional demonstrada nos testes direcionados listados.** Isso **não** prova que o quadro geral de compatibilidade de ROMs melhorou em percentual mensurável.
5. **Desempenho/FPS e jogos jogáveis:** não medidos, e portanto não há número de melhoria de velocidade nem de frames alcançados por esta versão.

## Pendências prioritárias

1. Rodar a suíte completa (`node tools/test.js`), que era vermelha na v0.4.34, classificar 39 falhas e corrigir uma por uma sem mascarar o erro do teste.
2. Validar novos ports com traces sincronizados do SNES original e confirmar que os scripts de integração geram e compilam C++ correto nos jogos afetados.
3. Comparar APU/DSP, PPU mosaic/Mode 7, HDMA/IRQ com um oráculo original, antes de ativar o interleave SPC/DSP globalmente.
4. Compilar e testar em Windows/MSYS2 ou MSVC, já que aqui a compilação exercitada foi no Linux.

Para Windows, execute `TESTAR-REUNIFICACAO.cmd` com Node.js, Python 3 e g++ (MSYS2) disponíveis. Para ports já gerados, regenere o projeto e recompile: os executáveis `game.exe` antigos não herdam o novo runtime.

Observação de integridade: versão do decoder/cache preservada intencionalmente. Os manifestos do pacote final foram recalculados sobre todos os arquivos, excluindo apenas os três próprios manifests, para evitar referências circulares.
