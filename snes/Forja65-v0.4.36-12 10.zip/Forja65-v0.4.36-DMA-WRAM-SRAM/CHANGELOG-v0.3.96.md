# Forja65 v0.3.96 — vetores RAM alimentados por tabelas ROM

Reconhece o padrão AND/ASL/TAX/LDA long,X/STA vetor/JSR trampoline. A origem ROM deve coincidir com a tabela após o JMP indireto, e o writer deve chamar exatamente esse trampoline. A menor rotina referenciada determina o fim da tabela; o tamanho final precisa ser par e todos os destinos devem ficar fora dos dados. A primeira rotina pode ter offset ímpar, desde que outra entrada estabeleça a fronteira válida antes dela.

Os destinos estruturais completos são preservados além do limite de 64 candidatos heurísticos. O cache de evidências considera o PC do trampoline, evitando compartilhar os destinos entre dois JMPs que usam o mesmo vetor RAM.

A resolução não prova o domínio dinâmico do índice nem descarta outros writers RAM. O uso de STA em direct page registra a hipótese D=0. Nenhuma observação falsa é salva para os destinos vizinhos.

Regressão: tabela de 84 entradas, 83 destinos distintos, âncora mínima na última entrada, mais seis padrões inválidos e um segundo trampoline com o mesmo vetor. A tabela real DKC3 B7:D07B–B7:D123 contém 84 entradas e 82 destinos distintos.

Compatibilidade do cache v95: decodificação de opcodes e emissor permanecem iguais; a nova descoberta adiciona candidatos/arestas. Cobertura anterior preservada sob fingerprint, estados e limite de variantes.

Resultados completos e limites: reports/validation-v0396/RESULTADOS.md.

Também reconhece JSR (tabela,X) com AND/ASL/TAX, instruções que preservam X, e uma continuação curta que restaura registradores e retorna antes da tabela. O limite estrutural vem dos handlers; o domínio do índice permanece não provado. A segunda tabela DKC3 B9:E042–B9:E0E8 tem 83 entradas e 59 destinos distintos. Regressão inclui execução C++ dos índices 0, 64 e 82 com restauração de X/Y e retorno pela pilha.
