# Forja65 v0.4.03 — crossfeed Tetris 2 v0.4.04

- Template C++ (`forja65-core.js`) atualizado para a ordem correta de fetch/incremento do latch de leitura VMADD em `$2139/$213A`.
- `ppuPortWrite` bloqueia writes de VRAM em HBlank e display ativo; `writeVramDataIgnored` mantém o estado de auto-incremento mesmo quando o barramento descarta dados.
- DMA/HDMA nativos passam pela mesma lógica e não podem escrever VRAM nas janelas inválidas.
- Perfil PPU agora inclui `vram_blocked_writes`.
- Novo teste `tests/tetris-vram-access-v0404-regression.js`: gera runtime a partir de ROM sintética, compila e executa regras VRAM.
- Ajustados testes legados de OBJ, CPU/PPU e raster para a regra de HBlank e pipeline.
- Validação Linux: 8/8 regressões da família Tetris aprovadas. Compilação e replay completos do Tetris verificados separadamente.
- Windows não foi compilado neste ambiente; compatibilidade com ROMs diversas e áudio não foram validados.
