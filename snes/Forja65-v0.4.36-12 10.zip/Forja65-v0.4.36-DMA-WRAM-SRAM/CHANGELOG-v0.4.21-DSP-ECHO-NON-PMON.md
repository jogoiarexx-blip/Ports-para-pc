# Forja65 v0.4.21 - Audio DSP crossfeed

- Converter multigame permanece separado do port de Tetris.
- `forja65-core.js`: geracao C++ com LFSR de ruido NON, modulação de pitch PMON, echo FIFO em SPC RAM e FIR stereo 8 taps, EON, EDL, ESA, EFB, EVOL, FLG e modo seguro de gravação de echo na RAM.
- Gerados passam a usar `FORJA65_ECHO_RAM_WRITES=1` somente para testar echo RAM: default OFF devido a layouts SPC ainda nao auditados.
- Mantidas as mudancas anteriores: ADSR/GAIN, KOFF, BRR, 32 kHz stereo WinMM/WAV, CPU, PPU, DMA, HDMA e crossfeed Soldiers.
- Regressões de gerador passadas: audio-realtime-v019, audio-dsp-enhanced-v020, audio-dsp-echo-noise-v021, tetris-apu-dsp-v0405, spc-dsp-stage1-v024 (5/5).
- Nenhuma prova de áudio bit-perfect SNES nem de funcionamento no dispositivo Windows.
