# Forja65 v0.4.24 — DSP KON/KOFF/BRR ENDX

Base preservada: Forja65 v0.4.23 (gerador SNES->C++, sem incorporar o jogo Tetris).

- O template C++ em forja65-core.js agora gera temporização de KON/KOFF de 2 amostras, início BRR após 5 amostras e publicação diferida de ENDX.
- Registros, vozes, BRR, ADSR/GAIN e eco anteriores não foram substituídos.
- FORJA65_DSP_KEYS=legacy restaura o acionamento imediato da versão anterior.
- Os próprios testes de regressão compilam o runtime C++ gerado a partir de uma ROM sintética:
  tests/audio-dsp-key-timing-v024-regression.js
  tests/fixtures/audio_dsp_key_timing_v024.cpp
- Execução em vários jogos não foi validada nesta etapa; a alteração permanece sob teste cruzado.

Referências: https://github.com/snes9xgit/snes9x/blob/master/apu/bapu/dsp/SPC_DSP.cpp e
https://snes.nesdev.org/wiki/S-DSP_registers
