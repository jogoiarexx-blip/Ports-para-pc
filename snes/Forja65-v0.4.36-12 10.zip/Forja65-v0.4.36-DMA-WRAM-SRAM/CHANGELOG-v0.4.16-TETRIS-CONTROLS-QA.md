# Forja65 v0.4.16 — QA de comandos de gameplay

O gerador agora inclui `tools/gameplay_controls_qa.py` nos projetos nativos C++ produzidos.
A ferramenta testa os comandos de um port existente por replays A/B, captura de framebuffer PPM e conferencia de ausencia de divergencia antes da entrada.
Para jogos diferentes de Tetris 2, configure `--pulse`, `--before`, `--after`, `--roi` e o replay-base adequado. Resultado visual nao prova fidelidade ao SNES ou conclusao do jogo.
Teste de geracao: `node tests/tetris-gameplay-controls-v0417-regression.js`.
As rotinas CPU, PPU, DMA/HDMA e audio NAO foram modificadas nesta versao.
