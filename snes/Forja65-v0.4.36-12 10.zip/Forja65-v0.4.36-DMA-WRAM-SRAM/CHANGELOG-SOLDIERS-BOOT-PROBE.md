# Forja65 v0.4.04 — diagnostico generico de boot / SPC700 (ramo Soldiers of Fortune)

- `forja65-core.js` emite `SnesRuntime::writeBootProbe()` nos projetos gerados e a chama na saida do executavel.
- `forja65-boot-probe.txt` documenta ultimo PC CPU, PC/SP/PSW/control SPC700, portas em ambas direcoes, estatisticas APU e NMI/blank.
- `apu_handshake_stall_suspected=YES` e uma **hipotese heuristica** de triagem; nao provoca mutacoes de port, ignora nenhum loop e nao prova completude.
- Regressoes: `node tests/generic-boot-probe-soldiers-regression.js`; deve validar resultado YES e NO e compilar o C++ gerado.
- Compatibilidade da traducao CPU e do API restante inalteradas; `C.VERSION` mantido, pois a alteracao e so diagnostica.

## Evidencia Soldiers of Fortune (USA)

ROM HiROM 12 Mbit; SHA-256 `6fe7c8d39fcfab7f0a18e837a7ee0dd162e0557d6989c6e0d10c81616d3a0b8b`.

Na primeira compilacao Linux (`Debug -O0 -g0`, trace habilitado), 300 frames completos de teste sem crash, 4.053.864 instrucoes executadas, mas imagem mantida em forced blank, nenhum NMI, `last_cpu_pc=0xc20391`, `spc_pc=0x0011`, `cpu_to_spc_0=0xc3` e `spc_to_cpu_0=0x02`. CPU esta num polling de `$2140` que requer zero.

A transfererencia SPC700 possui `spc_upload_writes=3209` (eventos de porta 0, nao um mapa exato de bytes carregados). Este ramo nao falsifica ACK para passar da tela preta. A hipotese precisa ser confrontada com traces de execucao SPC700 autentica, com a pilha e com o final da carga IPL.

## Correcao de regressao DMA

O `dma_forensics_smoke` gerado previamente escrevia VRAM em condicao
invalida, fora de forced blank / VBlank. O caso de teste sintetico agora
escreve `INIDISP=$80` antes do ensaio de VRAM DMA. Nenhuma restricao de
PPU foi relaxada. Confirmado **6/6 CTest C++ PASS** com o runtime de
Soldiers of Fortune, alem de quatro regressoes Node na base do Forja65.
