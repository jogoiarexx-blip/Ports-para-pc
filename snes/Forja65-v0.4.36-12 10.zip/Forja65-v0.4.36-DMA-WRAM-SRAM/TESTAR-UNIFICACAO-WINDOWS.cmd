@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>&1 || (echo ERRO: instale Node.js & exit /b 1)
where python >nul 2>&1 || (echo ERRO: instale Python 3 & exit /b 1)
python tests/missing-state-integrator-regression.py || exit /b 1
python tests/integrate-generated-cfg-v0396-regression.py || exit /b 1
for %%T in (tests\tetris-*-regression.js) do (node %%T || exit /b 1)
echo TESTES DA UNIFICACAO APROVADOS
