# Forja65 v0.3.95 — limpeza de capturas no Windows

Três testes mantinham arquivos de captura abertos ao apagá-los. O Windows nega a exclusão através desses handles: OBJ/pixel ownership falhavam e DMA deixava a exceção de filesystem escapar. A leitura agora usa um helper exclusivo dos testes, cujo stream é destruído antes da validação e limpeza. DMA também reporta exceções em stderr com saída 1.

A reprodução aplica no Linux a restrição de exclusão de arquivos abertos: os três testes antigos falham; os corrigidos passam, duas vezes cada. Isso verifica a causa identificada, sem afirmar execução em Windows/MSVC.

Todos os projetos gerados recebem o helper e as regressões de OBJ, DMA e pixel ownership. Os dois últimos agora são emitidos e registrados pelo próprio Forja, sem depender de cópias manuais do DKC3. Nenhum teste foi desativado ou convertido em sucesso artificial.

BUILD-WINDOWS.cmd continua falhando se CTest falhar, mas distingue falha de testes de falha de compilação e aponta LastTest.log. CPU/PPU/DMA, dispatcher e cobertura da ROM não foram alterados nesta revisão.

Resultados em reports/validation-v0395/RESULTADOS.md.
