# Forja65 v0.4.27 + correção de boot LoROM

## Problema observado

A ROM de teste de Biker Mice from Mars (mapa LoROM, 1.179.648 bytes sem cabeçalho de copiador) possui vetor RESET `$FFE0`, cujo conteúdo é uma instrução real `JML $20:8000` (`5C 00 80 20`). A proteção genérica da tabela de vetores vetava TODOS os endereços `$FFE0-$FFFF`, ignorando RESET. O gerador falhava em `reset.start` com `TypeError`.

## Alteração

`isRomResetVectorTrampoline` foi criada em `forja65-core.js`: valida somente a entrada de RESET `$FFE0-$FFE6`, opcode literal `JML`, quatro bytes contínuos, destino executável mapeado e fora da tabela de vetores. Entradas comuns e hints continuam protegidos contra decodificação de dados de vetor. O `generateProject` passa a receber o RESET real na lista de funções.

## Testes

- `node tests/reset-vector-jml-trampoline-v0428-regression.js`: 5 casos aprovados, incluindo rejeição de entradas falsas e destinos inválidos.
- `node tests/vector-table-guard-v0330-regression.js`: PASS.
- `node tests/ppu-brightness-lut-v027-regression.js`: PASS (524.288 combinações).
- Biker Mice: projeto C++ gerado, compilado em Linux; 300 frames sem falhas e captura de telas originais da ROM modificada.

Limite: o teste 65C816 não demonstra a conclusão de corrida nem equivalência com SNES real. O teste legado `tetris-hardware-v0397-regression.js` ainda falha em leitura consecutiva do VRAM `$2139` tanto no ZIP recebido quanto neste pacote; ele NÃO foi causado pela alteração do vetor RESET e NÃO foi corrigido nesta entrega.
