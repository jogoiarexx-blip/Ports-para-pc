# Forja65 Scooby crossfeed v0.6 — 2026-10-10

- Avanco por `learn-crash` nos destinos reais observados apos selecionar New Game; sem saltos inventados nem cenas reconstruidas.
- `tools/dispatch-frontier-audit.js`: auditoria generica e somente-leitura dos hints ROM-bound contra o dispatch C++ de verdade, discriminando variantes E/M/X/C e ROM divergente. Inclui modo `--strict`.
- `tests/dispatch-frontier-audit-v06-regression.js`: teste unitario para variantes compiladas, carry wildcard, hints de ROM estranha e registros invalidos.
- Port do Scooby: `AUDITAR-FRONTEIRA-CFG.cmd`, scripts de reproduzir New Game, logs e capturas continuam disponiveis.
- Os dados do replay e conclusoes finais estao em `RELATORIO-SCOOBY-v0.6.md` no ZIP do port. Nao confundir contagem do CFG com fase concluida.
