# Forja65 v0.3.67 — stack evidence & PPU brightness

* `learn-crash`: `STACK-RTL` e `STACK-RTS` observados exigem PC de origem com opcode RTL/RTS real na mesma ROM, destino mapeado e registro correspondente em `forja65-unresolved-returns.txt`. Hints não correspondentes são recusados; retornos comuns continuam com checagem do native stack.
* `tools/ppu-timeline-report.js`: a tela só é candidata à visibilidade quando forced blank está desabilitado, brilho > 0 e camadas habilitadas. Inclui `firstUnblankAfterForcedBlank`, `firstBrightnessEnabled` e `firstVisibleFrameCandidate`. O relatório não garante pixels visíveis.
* Compatibilidade de cache: é permitido migrar rotinas decodificadas pela v0.3.66 da **mesma ROM** porque as mudanças desta versão são de validação de entrada e relatório, não do decoder. Cache de outra ROM ou versão não autorizada continua rejeitado.
* Testes: `tests/observed-stack-return-v0367-regression.js`, `tests/ppu-timeline-brightness-v0367-regression.js` e regressões anteriores.

A geração C++ do DKC3 e o teste de execução real continuam necessários. Isto não garante abertura, save, mapa ou gameplay.
