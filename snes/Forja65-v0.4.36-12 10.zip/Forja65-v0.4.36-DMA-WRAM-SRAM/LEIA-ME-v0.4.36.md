# Forja65 v0.4.36 — primeiro lote crítico

Base: v0.4.35 PCM/DSP, comparada com a v0.4.34.3 SPC/DSP enviada junto.

## Correções entregues

- **DMA e HDMA / WRAM:** o acesso à porta `$2180` é bloqueado quando o lado A da transferência acessa WRAM, incluindo seus espelhos. O endereço da porta permanece intacto. No sentido inverso, a WRAM recebe o último byte observado no barramento de dados. A verificação ocorre por byte, mantendo contagem, ciclos, avanço/retrocesso/fixação do endereço e wrap dentro do banco. Os caminhos nativo e de fallback usam a mesma regra.
- **SRAM:** o save anterior não é truncado. A nova imagem é gravada em um arquivo temporário irmão, aberto exclusivamente, e só substitui o save após escrita, flush e fechamento bem-sucedidos. Falhas conservam a pendência de gravação e emitem mensagem de erro. Arquivos temporários preexistentes, incluindo links, não são reutilizados nem apagados.
- **Cache de análise:** cobertura da mesma ROM nas versões v0.4.35 e v0.4.34 pode ser reaproveitada, sempre regenerando o C++ com as correções novas. As verificações de identidade da ROM e de versões não auditadas continuam obrigatórias.
- **Validação reunificada:** 31 testes corrigidos na v0.4.34.3 foram restaurados, pois a v0.4.35 havia voltado a suas cópias antigas. Também foi restaurada a preparação correta de forced blank e leitura automática de controle no teste C++ gerado. Não foi removida nenhuma verificação funcional desses testes.

## Como aplicar

1. Extraia o ZIP em uma pasta nova e abra `ABRIR-FORJA65.cmd`.
2. Regenere o projeto do jogo usando este Forja65 e depois recompile. Executáveis ou `runtime.hpp` gerados pela versão anterior não recebem a correção apenas pela troca do aplicativo.
3. Para projetos atualizados pela linha de comando, preserve a ROM e os arquivos de análise existentes e use a operação `analyze` com `--update`, depois o comando de build habitual. Exemplo: `node tools/forja65.js analyze "jogo.sfc" --out "projeto" --update`.
4. Os saves continuam no formato `.srm` anterior e respeitam o caminho configurado por `FORJA65_SRAM_PATH`.

## Limitações práticas

- Os testes de DMA/HDMA são sintéticos e compilam o runtime C++ realmente emitido pelo gerador. Não houve replay de ROM comercial nem execução no seu Windows nesta entrega.
- O novo registro de dados guarda os bytes das operações observadas. Esta entrega não implementa todos os detalhes de open bus, acessos de busca de instrução, arbitragem DMA/HDMA ou precisão de cada ciclo do 5A22.
- Se existir `<save>.forja65-tmp`, a gravação falha com segurança. Isso pode ocorrer após um encerramento abrupto. Com o jogo fechado, preserve o save e examine o temporário antes de movê-lo para fora desse caminho e tentar novamente. Não o remova durante uma gravação em andamento.
- A substituição é atômica no mesmo sistema de arquivos. Não foi implementada uma garantia completa de durabilidade contra queda de energia em todos os sistemas de arquivos.
- Quando uma falha ocorre durante o encerramento, os dados pendentes ainda podem não chegar ao disco; o save anterior é preservado e o erro é indicado. Não há autosave periódico novo neste lote.

## Resultado da validação

243 de 246 testes passaram. As três falhas restantes também ocorrem na v0.4.35 original. Consulte `reports/validation-v0436/RESULTADOS.md`: equivalência PPU com referência antiga, retorno redirecionado de corrotinas da CPU e pipeline de leitura VRAM. Os testes novos de DMA/HDMA e SRAM passaram.

## Próximas prioridades

| Ordem | Núcleo | Trabalho ainda necessário |
|---|---|---|
| 1 | CPU, DMA, HDMA, WRAM | Arbitragem durante transferências, interrupções e contadores por evento; ampliar testes de barramento e de regiões inválidas. |
| 2 | PPU, VRAM, CGRAM, OAM | Comparar janelas de acesso, latches, flags de sprites e efeitos por linha com uma referência; confirmar equivalência entre caminhos rápidos e comuns. |
| 3 | SPC700, DSP | Ampliar equivalência de opcodes, timers e eventos de DSP com rastros de execução; medir diferenças de áudio, além da saída PCM. |
| 4 | SRAM | Considerar autosave periódico e recuperação de temporários, com política explícita de arquivos concorrentes. |

Os resultados de validação desta versão estão em `reports/validation-v0436/`.
