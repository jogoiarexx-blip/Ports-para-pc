# Crossfeed Soldiers of Fortune v0.15 (Forja65 v0.4.19)

- Base multigame v0.4.19 mantida; nenhum downgrade para v0.4.04.
- Auditoria de quadros repetidos (`tools/audit-visual-stall.py`) sem considerar CPU/NMI ativa como prova de gameplay.
- Checagem de objetos C++ desatualizados (`tools/check-native-object-freshness.py`) para evitar testes com `dispatch.cpp.o` antigo.
- Testes: `tests/audit-visual-stall-regression.py` (7/7), `tests/check-native-object-freshness-regression.py` (5/5).
- Caso de teste Soldiers: seis novas integrações ROM-autenticadas; 229 sites de instrução, 513 entradas de despacho e 21.248 entradas no total, sem conflitos de estado/endereços detectados.
- Teste 160 frames validado; replay principal chegou ao frame 5796, mas permanece sem comprovação de movimento/tiro. Próximo destino observado C0CA3F.
- Compilação incremental Linux passou; build MSVC e compilação limpa ainda não validados.

**Atenção:** verificação de estática do CFG não substitui comparação visual/temporal com o SNES original.
