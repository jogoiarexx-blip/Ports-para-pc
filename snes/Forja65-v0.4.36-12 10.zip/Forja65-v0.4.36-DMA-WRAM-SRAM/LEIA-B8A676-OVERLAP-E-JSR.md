# Integração cruzada B8:A676 — Forja65 v0.3.96 / DKC3 ZERO v0.41 / DKC3 Native PC v0.95

## Alterações comprovadas

**Forja65**
- Traduziu `B8:A676` (28 endereços distintos, 56 rastros de opcode) e conferiu todos contra a ROM SHA-256 `2277a2d8...3794a32b`.
- Novo `--preserve-existing` no integrador: mantém a propriedade dos 20 PCs já implementados (208 linhas existentes), inserindo somente **8 PCs novos (22 linhas)** sem sobrescrever código já testado. O comportamento estrito original é mantido por padrão.
- `advance-observed-target.py` aceita a opção, preserva verificação de ROM e reporta mensagens de erro com causa.
- Verificador de fluxo agora reconhece `JSR (abs,X)` opcode `FC` além de `JMP (abs,X)` opcode `7C`, separando `kind=CALL` de `kind=FLOW`. Regressões aprovadas.
- Novo alvo `B9:E124` analisado **somente em dry-run**: 3 PCs novos/6 entradas, 12 PCs já pertencentes ao dispatcher preservados. Ainda não integrado.

**DKC3 ZERO**
- Código gerado `src/forja_b8a676.cpp` incluído no build e no dispatcher, sem alterar os endereços já existentes.
- Build Linux do `game` aprovado; 22 testes CTest aprovados, 1 ignorado, nenhum falhou.
- Replay determinístico: 14.420 frames completos anteriores e **14.420 após** a alteração; **14.420 hashes sequenciais idênticos** (framebuffer, WRAM e PC). **Nenhum frame adicional** nesta rodada.
- O desvio anterior `B8:9F4D → B8:A676` foi superado, revelando novo salto `B9:E03C → B9:E124` no mesmo frame.

**DKC3 Native PC**
- Recebeu provas de ROM, novo salto `JSR` e validação do catálogo estrutural. A entrada `B8:A676` é `kong_state_0F`; `B9:E124` aparece como `CODE_B9E124`.
- Os arquivos `RomAnimationHandlers.cpp` e `RomAnimationCallbacks.cpp` continuam com hashes idênticos à versão anterior. Nenhum handler recebeu mudança de gameplay.

## Prova de fluxo novo

- Instrução em `B9:E03C`: `FC 42 E0` (`JSR ($E042,X)`).
- X observado: `0x0008`; endereço do ponteiro `B9:E04A`.
- Bytes na ROM `24 E1` → destino `B9:E124`.
- Código gerado é **evidência de tradução**, não prova de equivalência integral de CPU, PPU, DMA, HDMA ou áudio.

## Próxima intervenção

Aplicar `B9:E124` ao ZERO com `--preserve-existing`; compilar, testar e repetir o mesmo replay de 14.420 frames. Não declarar fase completa ou port sem ROM.

## Limitações

- O ZERO **ainda depende da ROM e da arquitetura SNES durante a execução**.
- A primeira fase não foi completada, nenhum novo frame completo foi conquistado nesta rodada.
- O executável Windows não foi compilado neste ambiente; validação foi Linux/CMake.
