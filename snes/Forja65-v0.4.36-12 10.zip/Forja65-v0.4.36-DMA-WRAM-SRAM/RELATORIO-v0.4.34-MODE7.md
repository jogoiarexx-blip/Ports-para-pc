# Forja65 v0.4.34 — precisão das coordenadas do Mode 7

Esta versão corrige três regras da transformação do Mode 7: arredondamento de negativos, corte individual dos produtos da origem e recorte interno da diferença entre offset e centro. Isso corrige a escolha de texels em determinadas escalas, rotações e deslocamentos.

## Erros reproduzidos

Quatro cenas sintéticas falharam na v0.4.33 antes da implementação. Com A=-1, um avanço de um pixel deve alcançar o texel -1, enquanto a divisão anterior selecionava zero. Os outros casos distinguem o corte dos produtos e diferenças positivas/negativas fora do intervalo interno.

O log mode7-math-baseline-failure.log preserva os índices de cor esperados e os incorretos. As quatro cenas passaram depois da correção.

## Implementação

- mode7Coordinates calcula as coordenadas usadas efetivamente por sampleMode7.
- O recorte conserva os dez bits baixos da diferença offset-centro, com sinal escolhido pelo bit 13.
- Cada produto da origem perde seus seis bits inferiores antes da soma. O avanço horizontal usa A e C.
- O descarte da fração de oito bits usa arredondamento para menos infinito, inclusive para negativos.
- Não se deslocam valores negativos para a esquerda. Os intermediários cabem em inteiro de 32 bits para os intervalos dos registradores e coordenadas de raster de 0 a 255.
- O projeto gerado exige C++20, que define os deslocamentos à direita usados nesse cálculo.
- O cache auditado de CFG aceita a v0.4.33 e seus predecessores; instruções e análise da CPU continuam iguais.

## Testes da precisão

O teste compila e executa o runtime gerado, com C++20, -O2, -Wall, -Wextra, -Wpedantic e -Werror.

Um oráculo separado usa restos euclidianos e operações matemáticas de floor, em vez dos operadores de bits da implementação. Os valores inteiros envolvidos são exatamente representáveis como double. Os casos dourados têm coordenadas esperadas derivadas manualmente.

- 1.364.108 comparações exatas de pares de coordenadas.
- Todos os 65.536 valores em cada um dos quatro coeficientes, com quatro pontos de raster e centros/offsets extremos.
- Todas as 16.383 diferenças offset-centro possíveis, nos dois eixos.
- 250.000 estados pseudoaleatórios, com aliases de bits, flips e configurações de repetição/preenchimento.
- 500.000 verificações de pixels dos dois backgrounds: transparência, tile zero, EXTBG, prioridade e seleção de cor direta.
- Mudança de matriz entre segmentos de imagem, conservando os pixels anteriores.
- Oito combinações de upload HDMA de matriz: nativo/fallback, direto/indireto e PPU virtual/state.

O mesmo teste foi compilado com -fsanitize=undefined e -fno-sanitize-recover=all: terminou com código zero e sem diagnóstico do sanitizador. O teste de cor direta reutiliza a função existente, delimitando a independência do oráculo à precisão das coordenadas e à seleção do texel.

Uma revisão independente examinou a alteração e os trechos relevantes do oráculo/casos dourados, sem ferramentas de sistema de arquivos. Não identificou problema crítico ou importante. Sua análise não é uma validação independente no hardware.

## Uso e relatórios

Gere novamente o projeto e recompile o port. Abra TESTAR-PPU-v0.4.34.cmd ou execute `node tools/test-ppu-v0434.js` para as 41 regressões dirigidas. Os resultados desta entrega em summary.json são extraídos da execução fresca de `node tools/test.js`, que inclui esses mesmos 41 testes.

Os logs e a comparação histórica ficam em reports/validation-v0434. A referência da comparação é a execução da v0.4.33 preservada no pacote anterior, cujo código e testes foram a base desta etapa. Não foi repetida toda a execução da versão anterior.

## Limites

Esta etapa verifica a fórmula de coordenadas para um ponto de raster fornecido. Mosaic do Mode 7, mapeamento da primeira linha visível, temporização do fetch e efeitos de escritas no pipeline real da PPU continuam fora desse escopo. Não houve gameplay de ROM comercial nem compilação no Windows. O resultado não demonstra compatibilidade de todos os jogos.

## Referência e integridade

Anomie, Register Doc, revisão 1157, seção $211F/$2120 e fórmula de precisão: https://raw.githubusercontent.com/gilligan/snesdev/master/docs/snes_registers.txt . A comparação segue a fórmula documentada; seus testes não substituem medições no console.

Fontes e manifestos da v0.4.33 estão em crossfeed-historico/v0433. Os três manifestos da raiz são renovados, excluindo apenas os próprios manifestos para evitar dependência circular.


## Resultado final

As 41 regressões dirigidas passaram dentro da suíte completa. A execução completa terminou em 201/240 testes aprovados. A versão anterior tinha 200/239 aprovados. As 39 falhas atuais já constavam no resultado preservado da base. Não apareceu falha histórica nova. A suíte inteira continua vermelha.

| Teste histórico com falha | Resultado anterior |
|---|---|
| brr-cache-version-v025-regression.js | Também falhava |
| bus-stalls-v032-regression.js | Também falhava |
| cli-trace-framework-regression.js | Também falhava |
| convergence-metadata-v0372-regression.js | Também falhava |
| convergence-pipeline-regression.js | Também falhava |
| cpu-ppu-v016-regression.js | Também falhava |
| cross-game-cpu-flow-v028-regression.js | Também falhava |
| hd-integer-scale-v032-regression.js | Também falhava |
| inline-indexed-table-v0312-regression.js | Também falhava |
| instruction-mastercycles-v031-regression.js | Também falhava |
| interrupt-stack-v039-regression.js | Também falhava |
| local-computed-jump-run-v0311-regression.js | Também falhava |
| long-controlflow-pb-v0314-regression.js | Também falhava |
| master-cycle-irq-hdma-v029-regression.js | Também falhava |
| native-dependency-audit-v0327-regression.js | Também falhava |
| native-hardware-cutover-v0329-regression.js | Também falhava |
| native-hardware-migration-v0328-regression.js | Também falhava |
| native-host-foundation-v0322-regression.js | Também falhava |
| native-oracle-v0350-regression.js | Também falhava |
| native-scene-capture-v0323-regression.js | Também falhava |
| obj-bank-v0380-regression.js | Também falhava |
| obj-oam-order-v0389-regression.js | Também falhava |
| oracle-runtime-learning-v0325-regression.js | Também falhava |
| ppu-priority-hires-v027-regression.js | Também falhava |
| ppu-sprite-row-regression.js | Também falhava |
| renderer-timing-flow-v023-regression.js | Também falhava |
| resumable-dispatch-v037-regression.js | Também falhava |
| rom-mirror-spc-state-v038-regression.js | Também falhava |
| runtime-progress-v035-regression.js | Também falhava |
| spc-port-isolation-v0313-regression.js | Também falhava |
| stack-trampoline-summary-v0310-regression.js | Também falhava |
| stackless-coroutine-regression.js | Também falhava |
| state-aware-cfg-v022-regression.js | Também falhava |
| state-summary-v036-regression.js | Também falhava |
| subscanline-raster-v030-regression.js | Também falhava |
| tail-vector-propagation-v0315-regression.js | Também falhava |
| tetris-hardware-v0397-regression.js | Também falhava |
| tetris-obj-crossfeed-v0398-regression.js | Também falhava |
| unified-cache-v026-regression.js | Também falhava |
