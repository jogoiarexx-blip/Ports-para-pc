# Forja65 SPC700 DIV — evolução v0.21 sobre Soldiers Crossfeed v0.20

## Alteração
Correção localizada da instrução $9E (DIV YA,X) no gerador forja65-core.js.
No modo corrected, DIV agora calcula os resultados do caminho normal e do caminho de overflow, incluindo X=0, atualiza H e V a partir dos operandos originais e N/Z a partir do quociente. C, P, B e I são preservados.
O modo legado continua com o comportamento anterior. A seleção de semântica permanece independente da temporização. Não houve mudança em CPU 65816, PPU, DMA ou DSP.

## Uso
A alteração chega aos ports ao gerar novamente seu runtime.hpp com este Forja.
Para ativar a semântica corrigida no port, no CMD antes de abrir o executável:

```bat
set FORJA65_SPC_SEMANTICS=corrected
```

A temporização accurate, quando já utilizada pelo projeto, continua independente:

```bat
set FORJA65_SPC_TIMING=accurate
```

## Validação
O teste novo executa o runtime C++ realmente gerado e compara a implementação por fórmula com um modelo separado de divisão por nove rodadas de rotação/subtração de 17 bits.
Cobertura: 65.536 entradas YA × 256 entradas X × 2 modos de semântica × 2 modos de temporização = 67.108.864 casos.
Valida YA, PSW completo, preservação de X, avanço de PC e ciclos (12 accurate, 2 legado).
Falha observada antes da correção: YA=0, X=0 no modo corrected produzia A=0/PSW=66; modelo esperado A=255/PSW=200.
Depois da correção: todos os casos passaram.
Teste: node tests/spc-div-v0420-regression.js.
Suíte geral: 170/208 passaram; as 38 falhas também foram reproduzidas no ZIP original. Detalhes em reports/VALIDACAO-SPC700-DIV-v0.21.md e logs associados.

## Limites
Os testes são sintéticos. Não houve comparação com hardware SNES nem reprodução de uma ROM real nesta entrega. Esta mudança não certifica o áudio completo dos jogos, o DSP ou o sincronismo por acesso ao barramento.
Arquivos antigos em reports e merge-evidence continuam como evidências históricas, sem reescrever seus runtimes arquivados.
