# Forja65 v0.4.19 — Tetris Audio Crossfeed v0.19

- Base Soldiers/Forja65 v0.4.19 v0.18 preservada, sem trazer uma versão antiga da CPU/PPU/DMA.
- Incorporado ao gerador C++ o transporte PCM da Tetris 2 v0.4.23: waveOut WinMM 32 kHz stereo em Windows, buffer limitado 12×512, escrita de WAV em streaming, controle de ganho e relatório com métricas.
- Captura em `ApuBridge.nativePcm` agora só é ativada explicitamente via `enableMemoryPcmCapture(true)` para impedir crescimento ilimitado de RAM; a síntese do DSP continua a mesma.
- No Windows o áudio ao vivo inicia na janela; execução headless continua desligada por padrão, salvo FORJA65_AUDIO_DUMP=1 ou FORJA65_AUDIO_MODE=native.
- Incluídos RUN-WINDOWS-AUDIO.cmd e RUN-NATIVE-AUDIO.cmd nos ports gerados, além dos testes de PCM e DSP→transporte.
- Não altera código de jogo Soldiers nem Tetris, nem apresenta áudio fiel ao SNES como concluído.
