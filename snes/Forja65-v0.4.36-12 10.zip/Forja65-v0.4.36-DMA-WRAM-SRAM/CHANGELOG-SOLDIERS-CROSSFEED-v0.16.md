# Soldiers Crossfeed v0.16 — Forja65 v0.4.19

Mantida a base multigame, incluindo recursos dos outros jogos; não voltar à v0.4.04.

- `tools/authorize-jsr-return.py`: autorização transacional ROM-proven de retorno direto `JSR abs`, atualizando offset e alias canônico em conjunto; preserva guard de pilha para retornos não comprovados.
- `tests/authorize-jsr-return-regression.py`: 8 cenários aprovados (origem ROM, endereços, retorno, rejeições de dados divergentes etc.).
- `tools/audit-render-liveness.py`: diferencia framebuffer estático de WRAM dinâmica usando hashes densos; não infere falsamente que a PPU é a causa.
- `tests/audit-render-liveness-regression.py`: 7 cenários aprovados.
- Port Soldiers v0.16: 7 destinos integrados, 297 pontos de instrução, 647 entradas; 21.895 no dispatcher, 17 integrações auditadas desde v0.14.
- Último destino em execução: `C0:4367 → C0:4B76` no frame 5.796. A tela GET READY — 03 ainda está visualmente parada.
- **Não** considerar isso gameplay ou áudio validado. Não modificar a VRAM ou contador artificialmente para contornar a causa.
