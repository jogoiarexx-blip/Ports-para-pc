# Forja65 v0.4.23 — envelope counter S-DSP

Aplicada no gerador `forja65-core.js` a mesma lógica testada no Tetris v0.4.28:
clock de envelope global de 30.720 ticks, rate offsets, ADSR/GAIN hardware,
GAIN bent-line e retorno `FORJA65_DSP_ENVELOPE=legacy`.

O Forja permanece um conversor multigame sem Tetris embutido.

Validação: 5/5 regressões Node selecionadas aprovadas, incluindo compilação
C++ a partir do runtime gerado no teste envelope v0.4.23. Sem avaliação
bit a bit do áudio contra S-DSP do console original.
