# Forja65 v0.4.19 — Soldiers Crossfeed v0.18

- Base multigame v0.4.19 preservada; nenhuma substituição regressiva por v0.4.04.
- Quatro destinos do port Soldiers integrados com prova de ROM, sem colisões: C061F0, C0ACA2, C0ACE6 e C048C2; o código integrado pertence ao ZIP do port.
- Ferramenta genérica `tools/gameplay-evidence-audit.py` e regressões `tools/test_gameplay_evidence_audit.py` (9/9 aprovados). Ela exige logs coerentes, rejeita contador regressivo de NMI/frames, compara somente frames comuns aos dados e não confunde rendering e recepção de controle com gameplay comprovado.
- A auditoria de vídeo existente continuou aprovada (10/10 testes).
- Resultado em Soldiers: o próximo bloqueio observado é C04380 -> C027A7, ainda no frame 5796; gameplay não validado.
- Não foram modificados os outros ports. Nenhuma equivalência com o hardware original do SNES foi reivindicada.
