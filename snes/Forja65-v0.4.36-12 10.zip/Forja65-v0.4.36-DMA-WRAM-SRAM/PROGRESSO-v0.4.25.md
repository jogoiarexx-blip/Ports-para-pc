# Checkpoint para CONTINUA / PRÓXIMA

Base de continuação: Forja65-v0.4.25-BRR-ARITHMETIC.zip.
Nunca voltar à v0.4.19–v0.4.23 como base. Esta versão deriva da v0.4.24.

Concluído: auditoria focal e inventário completo; correção numérica BRR;
50178 vetores / 1605696 amostras distintas; diagnóstico da primeira divergência;
modo FORJA65_DSP_BRR=legacy; preservação dos três switches anteriores;
cache imediato v0.4.24, metadados de versão, logs e checksums atualizados.
Suíte: 204 PASS, 38 FAIL herdadas, 0 TIMEOUT; sem regressões novas detectadas.
Build e execução sintéticos Linux; zero frames na fixture STP.
Windows e jogos reais não foram validados. Não interpretar o placar como
fidelidade sonora/compatibilidade comercial ou primeira fase completa.

Próximo alvo: criar reprodução sintética SPC700 que escreva no DSP ao longo
de uma mesma fatia; comparar slicing e localizar a primeira amostra incorreta.
ApuBridge atualmente roda SPC primeiro e DSP depois. Medir antes de mudar.
Ajustar scheduling/clock de forma reversível; validar switches atuais e
PCM/registers/time, com dump real quando legalmente disponível.
Consultar AUDITORIA-v0.4.25 e RESULTADOS-v0.4.25 para as outras pendências.
