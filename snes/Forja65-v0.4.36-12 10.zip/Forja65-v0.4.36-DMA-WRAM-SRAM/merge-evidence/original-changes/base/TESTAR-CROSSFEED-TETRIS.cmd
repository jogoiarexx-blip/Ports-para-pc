@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul || (echo ERRO: Node.js nao encontrado. & pause & exit /b 1)
where g++ >nul 2>nul || (echo ERRO: g++ nao encontrado no PATH. Execute no terminal MSYS2 MINGW64 ou instale o compilador. & pause & exit /b 1)
node tests\tetris-hardware-v0397-regression.js || goto :err
node tests\tetris-obj-crossfeed-v0398-regression.js || goto :err
node tests\tetris-obj-limits-v0399-regression.js || goto :err
node tests\tetris-hdma-v0400-regression.js || goto :err
echo OK: contratos CPU/PPU/DMA/SPC, OBJ 32/34, STAT77 e HDMA $80 preservados.
pause
exit /b 0
:err
echo Falha nos testes de regressao. Veja o erro acima.
pause
exit /b 1
