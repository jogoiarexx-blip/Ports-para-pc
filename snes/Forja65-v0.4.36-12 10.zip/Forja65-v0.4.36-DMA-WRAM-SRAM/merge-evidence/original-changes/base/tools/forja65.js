#!/usr/bin/env node
'use strict';
const fs=require('fs'),path=require('path'),cp=require('child_process');
const C=require('../forja65-core.js');
const args=process.argv.slice(2),command=args.shift(),input=args.shift();
function option(name,def=null){const i=args.indexOf('--'+name);if(i<0)return def;if(i+1>=args.length||args[i+1].startsWith('--'))throw new Error('Missing --'+name+' value');return args[i+1];}
function jsonFile(file){return JSON.parse(fs.readFileSync(file,'utf8'));}
const {writeFiles,refreshManifest,generate}=require('./project-io');
function run(exe,params,extra={}){const r=cp.spawnSync(exe,params,{stdio:'inherit',...extra});if(r.error)throw r.error;if(r.status!==0)throw new Error(exe+' failed with status '+r.status);}
function configure(project,trace=false){const params=['-S',project,'-B',path.join(project,'build'),'-DCMAKE_BUILD_TYPE=Release'];params.push('-DFORJA65_ENABLE_TRACE='+(trace?'ON':'OFF'));run('cmake',params);run('cmake',['--build',path.join(project,'build'),'--config','Release','-j','2']);}
function loadRom(file){return C.loadRom(new Uint8Array(fs.readFileSync(file)),path.basename(file));}
function issueCounts(a){const out={};for(const i of a.issues||[])out[i.kind]=(out[i.kind]||0)+(i.occurrences||1);return Object.fromEntries(Object.entries(out).sort((a,b)=>b[1]-a[1]||a[0].localeCompare(b[0])));}
try {
 if(command==='analyze'){
  if(!input)throw new Error('ROM path required');
  const out=path.resolve(option('out','forja-project'));
  const knowledge=option('knowledge')?jsonFile(option('knowledge')):null;
  const result=generate({romPath:input,out,cacheLimit:option('cache-limit')?Number(option('cache-limit')):null,max:Number(option('max',fs.existsSync(path.join(out,'analysis/generation-options.json'))?String(jsonFile(path.join(out,'analysis/generation-options.json')).max):'65536')),hints:option('hints')?fs.readFileSync(option('hints'),'utf8'):'',profile:option('profile')?jsonFile(option('profile')):undefined,trace:option('trace')?C.parseTrace(fs.readFileSync(option('trace'),'utf8')):null,knowledge,update:args.includes('--update')});
  console.log('Project: '+out+'\nDecoded addresses: '+result.a.decoded+'; knowledge seeds: '+(result.a.knowledgeSeedsImported||0)+'; changed files: '+result.changed.length+'; host conversion coverage: unmeasured.');
 }else if(command==='import-replay'){
  if(!input||!option('integration')||!option('knowledge')||!option('trace')||!option('error'))throw new Error('Usage: import-replay game.sfc --integration integration.json --knowledge native-knowledge.json --trace forja65-crash-trace.txt --error forja65-last-error.txt [--prior-trace earlier-crash-trace.txt --prior-error earlier-last-error.txt] [--state-log forja65-unresolved-state.txt] [--followup-trace new-crash-trace.txt --followup-error new-last-error.txt] --out crossfeed');
  const {makeCrossfeed}=require('./cross-project-replay');
  const result=makeCrossfeed({romBytes:fs.readFileSync(input),integration:jsonFile(option('integration')),knowledge:jsonFile(option('knowledge')),traceText:fs.readFileSync(option('trace'),'utf8'),stateText:option('state-log')?fs.readFileSync(option('state-log'),'utf8'):null,priorTraceText:option('prior-trace')?fs.readFileSync(option('prior-trace'),'utf8'):null,errorText:fs.readFileSync(option('error'),'utf8'),priorErrorText:option('prior-error')?fs.readFileSync(option('prior-error'),'utf8'):null,followupTraceText:option('followup-trace')?fs.readFileSync(option('followup-trace'),'utf8'):null,followupErrorText:option('followup-error')?fs.readFileSync(option('followup-error'),'utf8'):null});
  const out=path.resolve(option('out','forja-replay-import'));
  writeFiles(out,{'runtime-hints.txt':result.hints,'knowledge-pack.json':JSON.stringify(result.knowledge,null,2)+'\n','report.json':JSON.stringify(result.report,null,2)+'\n'});
  console.log('ROM-bound import: '+out+'; observations '+result.report.imported_runtime_observations+'; catalog '+result.report.static_catalog_entries+' static entries; no equivalence assumed.');
 }else if(command==='cross-analyze'){
  if(!input||!option('knowledge'))throw new Error('Usage: cross-analyze game.sfc --knowledge pack.json --out analysis');
  const rom=loadRom(input),hash=C.romFingerprint(rom),pack=C.normalizeKnowledgePack(jsonFile(option('knowledge')),hash),base=option('profile')?jsonFile(option('profile')):{},profile=C.mergeKnowledgeProfile(base,pack,hash),a=C.analyze(rom,Number(option('max','65536')),[],{knowledge:pack,knowledgeSeedLimit:Number(option('seed-limit','512')),summaryRounds:Number(option('summary-rounds','3'))}),map=C.buildNativeMap(rom,a,null,profile),out=path.resolve(option('out','forja-crossfeed'));
  const summary={schema:'forja65.crossfeed-analysis.v1',rom:hash,version:C.VERSION,knowledge:{entries:pack.entries.length,seedsImported:a.knowledgeSeedsImported||0,dataSeedsRejected:a.knowledgeDataSeedsRejected||0,adjacentDataStops:a.knowledgeAdjacentDataStops||0,dataRegions:pack.dataRegions.length,dispatch:pack.dispatch.length},analysis:{decoded:a.decoded,native:a.native,partial:a.partial,unsupported:a.unsupported,cfgFunctions:a.cfgFunctions,cfgFunctionVariants:a.cfgFunctionVariants,cfgCalls:a.cfgCalls,stateVariantAddressCount:a.stateVariantAddressCount,issues:issueCounts(a)},limits:['Knowledge seeds expand discovery; they do not prove runtime execution or native equivalence.','Categories/names from an external pack are labels, not inferred behavior.']};
  writeFiles(out,{'function-analysis.json':JSON.stringify(a,null,2)+'\n','native-map.json':JSON.stringify(map,null,2)+'\n','crossfeed-summary.json':JSON.stringify(summary,null,2)+'\n','merged-profile.json':JSON.stringify(profile,null,2)+'\n'});
  console.log('Cross analysis: '+out+'; seeds '+summary.knowledge.seedsImported+'/'+summary.knowledge.entries+'; decoded '+a.decoded+'; CFG functions '+a.cfgFunctions+'.');
 }else if(command==='focus-analyze'){
  if(!input||!option('knowledge')||!option('addresses'))throw new Error('Usage: focus-analyze game.sfc --knowledge pack.json --addresses B2802D,B2804B --out analysis');
  const rom=loadRom(input),pack=jsonFile(option('knowledge')),addresses=option('addresses').split(',').map(x=>x.trim()).filter(Boolean),focus=C.focusAnalyze(rom,addresses,pack,{maxPerTarget:Number(option('max-per-target','2048'))}),out=path.resolve(option('out','forja-focus'));
  const returned={schema:'forja65.knowledge-return.v1',version:C.VERSION,rom:focus.rom,entries:focus.results.map(r=>({address:r.address,name:r.name,category:r.category,category_source:r.category_source,family:r.family,direct_jump_sources:r.direct_jump_sources,evidence:['Forja65 focused static CFG/family analysis']})),dispatch:focus.results.flatMap(r=>(r.indirect_sites||[]).filter(s=>s.targets&&s.targets.length).map(s=>({site:s.pc,targets:s.targets,source:'forja65-focus-static-candidates',resolution:s.resolution}))),limits:focus.limits};
  writeFiles(out,{'focus-analysis.json':JSON.stringify(focus,null,2)+'\n','knowledge-return.json':JSON.stringify(returned,null,2)+'\n'});
  console.log('Focus analysis: '+out+'; targets '+focus.results.length+'; '+focus.results.map(r=>'$'+C.hex(r.address,6)+'='+r.category+'('+r.category_source+')').join(', '));
 }else if(command==='native-dispatch'){
  if(!input||!option('knowledge')||!option('site'))throw new Error('Usage: native-dispatch game.sfc --knowledge pack.json --site B9A157 [--proofs handler-equivalence.json] --out generated');
  const rom=loadRom(input),pack=jsonFile(option('knowledge')),proofs=option('proofs')?jsonFile(option('proofs')):null,plan=C.nativeDispatchPlan(rom,option('site'),pack,{maxPerTarget:Number(option('max-per-target','2048')),handlerMax:Number(option('handler-max','2048')),handlerProofs:proofs}),out=path.resolve(option('out','forja-native-dispatch')),ns=option('namespace','forja65_generated');
  writeFiles(out,{'native-dispatch.json':JSON.stringify(plan,null,2)+'\n','native_dispatch.generated.hpp':C.nativeDispatchCpp(plan,{namespace:ns})});
  const cov=plan.cutover.structural_script_hit_coverage||{};const impact=cov.available?('; proven '+plan.cutover.semantic_handlers_proven+'/'+plan.unique_targets+'; structural hits '+cov.native_hits+'/'+cov.total_hits+' ('+(cov.native_fraction*100).toFixed(1)+'%)'):('; proven '+plan.cutover.semantic_handlers_proven+'/'+plan.unique_targets);
  const cb=plan.callback_cutover||{};
  let cbImpact='';
  if(cb.available){
   cbImpact='; callbacks '+cb.semantic_callbacks_proven+'/'+cb.total_callbacks+'; callback hits '+cb.native_hits+'/'+cb.total_hits+' ('+(cb.native_fraction*100).toFixed(1)+'%)';if(cb.dependency_boundary_callbacks)cbImpact+='; callback boundaries '+cb.dependency_boundary_callbacks+'/'+cb.dependency_boundary_hits+' hits; native-or-boundary '+cb.native_or_boundary_hits+'/'+cb.total_hits+' ('+(cb.native_or_boundary_fraction*100).toFixed(1)+'%)';
   if(cov.available&&Number.isFinite(cov.native_plus_callback_fraction))cbImpact+='; effective static hits '+cov.native_plus_callback_hits+'/'+cov.total_hits+' ('+(cov.native_plus_callback_fraction*100).toFixed(1)+'%)';
  }
  const leaf=plan.external_leaf_cutover||{};if(leaf.available){cbImpact+='; external leaves '+leaf.semantic_leaves_proven+'/'+leaf.total_leaves+'; leaf hits '+leaf.native_hits+'/'+leaf.total_hits+' ('+(leaf.native_fraction*100).toFixed(1)+'%)';if(cov.available&&Number.isFinite(cov.native_plus_callback_plus_external_leaf_fraction))cbImpact+='; effective+leaf '+cov.native_plus_callback_plus_external_leaf_hits+'/'+cov.total_hits+' ('+(cov.native_plus_callback_plus_external_leaf_fraction*100).toFixed(1)+'%)';}
  const inv=plan.handler_inventory||{},units=inv.semantic_units||{};if(Number.isFinite(units.total))cbImpact+='; semantic units '+units.semantic_proven+'/'+units.total;
  console.log('Native dispatch plan: '+out+'; site $'+C.hex(plan.site,6)+'; entries '+plan.table_entries+'; unique targets '+plan.unique_targets+'; handler cutover '+(plan.cutover.handler_execution_ready?'ready':'fallback-required')+impact+cbImpact+'.');
 }else if(command==='import-knowledge'){
  if(!input||!option('rom'))throw new Error('Usage: import-knowledge pack.json --rom game.sfc --out game_config.json');
  const rom=loadRom(option('rom')),hash=C.romFingerprint(rom),pack=C.normalizeKnowledgePack(jsonFile(input),hash),base=option('base')?jsonFile(option('base')):{},profile=C.mergeKnowledgeProfile(base,pack,hash),out=path.resolve(option('out','game_config.json'));
  fs.mkdirSync(path.dirname(out),{recursive:true});fs.writeFileSync(out,JSON.stringify(profile,null,2)+'\n');console.log('Knowledge profile: '+out+'; '+Object.keys(profile.symbols).length+' symbols.');
 }else if(command==='export-knowledge'){
  if(!input)throw new Error('Generated project path required');const project=path.resolve(input),map=jsonFile(path.join(project,'analysis/native-map.json')),pack=C.knowledgePackFromNativeMap(map,{version:C.VERSION}),out=path.resolve(option('out',path.join(project,'analysis/knowledge-export.json')));fs.mkdirSync(path.dirname(out),{recursive:true});fs.writeFileSync(out,JSON.stringify(pack,null,2)+'\n');console.log('Knowledge export: '+out+'; '+pack.entries.length+' entries.');
 }else if(command==='learn-crash'){
  if(!input)throw new Error('Usage: learn-crash project --from diagnostic-directory [--max 8192]');
  const project=path.resolve(input),diagnostics=path.resolve(option('from',path.join(project,'build-debug-fast')));
  const romPath=path.join(project,'assets/cart-data.bin'),rom=loadRom(romPath),hash=C.romFingerprint(rom);
  const hintsPath=path.join(project,'analysis/runtime-hints.txt');
  const read=f=>fs.existsSync(f)?fs.readFileSync(f,'utf8'):'';
  const observed=C.mergeRuntimeHints(read(path.join(diagnostics,'forja65-oracle-hints.txt')),read(path.join(diagnostics,'forja65-runtime-hints.txt')));
  const incoming=C.parseRuntimeHints(observed);
  if(!incoming.length)throw new Error('No runtime hints in '+diagnostics);
  if(incoming.some(h=>h.rom!==hash))throw new Error('Refusing hints from different ROM fingerprint: '+hash);
  const stackReturnObservationsVerified=require('./observed-stack-return').verifyObservedStackReturns(rom,incoming,read(path.join(diagnostics,'forja65-unresolved-returns.txt')));
  const previous=read(hintsPath),merged=C.mergeRuntimeHints(previous,observed);
  const before=C.parseRuntimeHints(previous).length,after=C.parseRuntimeHints(merged).length;
  // Do not persist newly learned hints until ROM/CFG regeneration succeeds.
  // A rejected cache, invalid option or generated-source failure must not
  // poison the next replay with uncompiled, unverified permanent hints.
  const max=Number(option('max','8192'));
  const oldHintsExisted=fs.existsSync(hintsPath);
  let generated;
  try {
    generated=generate({romPath,out:project,max,hints:merged,update:true});
  } catch(error) {
    // Generation may have failed after its first file write. Restore the
    // original verified hints even in that partial-output scenario.
    if(oldHintsExisted)fs.writeFileSync(hintsPath,previous);
    else fs.rmSync(hintsPath,{force:true});
    throw error;
  }
  fs.mkdirSync(path.dirname(hintsPath),{recursive:true});fs.writeFileSync(hintsPath,merged+'\n');
  const report={schema:1,rom:hash,version:C.VERSION,from:diagnostics,existingHints:before,totalHints:after,importedHints:after-before,stackReturnObservationsVerified,max,decoded:generated.a.decoded,changedFiles:generated.changed.length,limit:'CFG discovery only; generated C++ not executed'};
  fs.mkdirSync(path.join(project,'reports'),{recursive:true});fs.writeFileSync(path.join(project,'reports/learn-crash.json'),JSON.stringify(report,null,2)+'\n');
  console.log('Learned '+(after-before)+' verified hint(s), CFG decoded '+generated.a.decoded+'; changed '+generated.changed.length+' files. Compile and run to prove behavior.');
 }else if(command==='converge'){
  if(!input)throw new Error('Generated project path required');const project=path.resolve(input);const result=require('./converge').converge(project,{jobs:option('jobs','4'),frames:option('frames','300'),rounds:option('rounds','32'),max:option('max'),watchdog:option('watchdog','50000000'),timeout:option('timeout-ms','120000'),replay:option('replay'),buildDir:option('build-dir'),ppuTrace:args.includes('--ppu-trace')});console.log('Convergence: '+result.status+'; report: '+path.join(project,'reports/convergence-report.json'));if(result.status!=='PASS')process.exitCode=3;
 }else if(command==='trace'){
  if(!input)throw new Error('Generated project path required');const project=path.resolve(input);configure(project,true);const build=path.join(project,'build');const candidates=[path.join(build,'Release','game.exe'),path.join(build,'game.exe'),path.join(build,'game')];const exe=candidates.find(p=>fs.existsSync(p));if(!exe)throw new Error('Game executable missing');const tracePath=path.join(project,'forja-trace.csv');run(exe,[],{cwd:build,env:{...process.env,FORJA65_TRACE:tracePath,FORJA65_TRACE_LIMIT:option('limit','250000'),FORJA65_HEADLESS:'1',FORJA65_HEADLESS_FRAMES:option('frames','120'),FORJA65_EXECUTION:option('execution','reference')}});const trace=C.parseTrace(fs.readFileSync(tracePath,'utf8'));const meta=jsonFile(path.join(project,'analysis.json'));const rom=C.loadRom(new Uint8Array(fs.readFileSync(path.join(project,'assets/cart-data.bin'))));const a=jsonFile(path.join(project,'analysis/function-analysis.json'));a.romFingerprint=a.rom;const p=jsonFile(path.join(project,'profiles/game_config.json'));const map=C.buildNativeMap(rom,a,trace,p);if(meta.rom_fingerprint!==map.rom)throw new Error('Project ROM mismatch');const updated={'analysis/native-map.json':JSON.stringify(map,null,2),'analysis/native-map.md':C.nativeMapMarkdown(map),'analysis/trace.json':C.exportTrace(trace.events,'json',trace),'analysis/trace.txt':C.exportTrace(trace.events,'txt',trace),'reports/compatibility-report.json':JSON.stringify(C.compatibilityReport(map,a),null,2),'reports/compatibility-report.md':C.nativeMapMarkdown(map)};writeFiles(project,updated);refreshManifest(project,updated);console.log('Trace: '+trace.events.length+' records; '+trace.dropped+' dropped. Native map updated.');
 }else if(command==='import-trace'){
  if(!input||!option('rom'))throw new Error('Usage: import-trace trace.csv --rom game.sfc');const rom=loadRom(option('rom')),a=C.analyze(rom,65536),trace=C.parseTrace(fs.readFileSync(input,'utf8')),profile=option('profile')?jsonFile(option('profile')):{},map=C.buildNativeMap(rom,a,trace,profile);writeFiles(path.resolve(option('out','forja-analysis')),{'native-map.json':JSON.stringify(map,null,2),'native-map.md':C.nativeMapMarkdown(map),'trace.json':C.exportTrace(trace.events,'json',trace),'trace.txt':C.exportTrace(trace.events,'txt',trace)});
 }else if(command==='compare'){
  const other=option('native');if(!input||!other)throw new Error('Usage: compare reference-hashes.txt --native native-hashes.txt');const result=C.firstDivergence(fs.readFileSync(input,'utf8'),fs.readFileSync(other,'utf8')),out=path.resolve(option('out','first-divergence.json'));fs.writeFileSync(out,JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));if(!result.equivalent)process.exitCode=3;
 }else if(command==='build-native'){
  if(!input)throw new Error('Generated project path required');configure(path.resolve(input),option('trace','off')==='on');console.log('C++ build complete. Translated/hardware fallback remains where not replaced.');
 }else {
  console.log('Forja65 '+C.VERSION+'\nnode tools/forja65.js import-replay game.sfc --integration integration.json --knowledge native-knowledge.json --trace crash-trace.txt --error last-error.txt [--prior-trace earlier-trace.txt --prior-error earlier-error.txt] [--state-log state.txt] [--followup-trace next-trace.txt --followup-error next-error.txt] --out crossfeed\nnode tools/forja65.js analyze game.sfc --out project [--cache-limit 32768] [--knowledge knowledge.json] [--profile profile.json] [--trace trace.csv]\nnode tools/forja65.js cross-analyze game.sfc --knowledge knowledge.json --out analysis [--seed-limit 512] [--summary-rounds 3]\nnode tools/forja65.js focus-analyze game.sfc --knowledge knowledge.json --addresses B2802D,B2804B --out focus\nnode tools/forja65.js import-knowledge knowledge.json --rom game.sfc --out game_config.json\nnode tools/forja65.js export-knowledge project --out knowledge.json\nnode tools/forja65.js converge project --frames 300 [--rounds 32] [--replay input.txt] [--jobs 4]\nnode tools/forja65.js trace project --frames 120 [--execution reference|native]\nnode tools/forja65.js import-trace trace.csv --rom game.sfc --out analysis\nnode tools/forja65.js native-dispatch game.sfc --knowledge pack.json --site B9A157 [--proofs handler-equivalence.json] --out generated\nnode tools/forja65.js build-native project [--trace on]');if(command)process.exitCode=2;
 }
}catch(e){console.error('Forja65: '+e.message);process.exitCode=2;}
