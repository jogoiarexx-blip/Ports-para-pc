#!/usr/bin/env python3
"""Missing states may be added only without shadowing an existing domain."""
import hashlib, importlib.util, json, tempfile
from pathlib import Path
spec=importlib.util.spec_from_file_location('cfg',Path(__file__).resolve().parents[1]/'tools/integrate-generated-cfg.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
with tempfile.TemporaryDirectory() as temp:
    r=Path(temp);p=r/'port';g=r/'gen'
    (p/'src').mkdir(parents=True);(p/'assets').mkdir();(g/'src').mkdir(parents=True)
    rom=b'test';(p/'assets/cart-data.bin').write_bytes(rom)
    old='{0x009000u,false,true,false,false,false,&sub_old,0x009000u},\n'
    (p/'src/dispatch.cpp').write_text('static const Forja65DispatchEntry kForja65Dispatch[]={\n'+old+'};\n')
    (p/'CMakeLists.txt').write_text('add_library(core src/dispatch.cpp)\n')
    cpp='#include "generated.hpp"\nvoid sub_009000_E0M0X0C0(CpuState&, SnesRuntime&, std::uint32_t) {}\n'
    (g/'src/generated_000.cpp').write_text(cpp)
    row='{0x009000u,false,false,false,true,false,&sub_009000_E0M0X0C0,0x009000u},\n'
    (g/'src/dispatch.cpp').write_text(row)
    proof=r/'proof.json';proof.write_text(json.dumps({'entry':'009000','rom_opcode_mismatches':0,'code_sha256':hashlib.sha256(cpp.encode()).hexdigest(),'rom':{'sha256':hashlib.sha256(rom).hexdigest()}}))
    try:m.integrate(p,g,'009000',proof,commit=False)
    except ValueError:pass
    else:raise AssertionError('Default must reject shared PCs')
    # Partial overlap is not subtracted from a generated carry wildcard.
    initial=(p/'src/dispatch.cpp').read_text()
    (p/'src/dispatch.cpp').write_text(initial.replace('false,true,false,false,false,&sub_old','false,false,false,true,false,&sub_old'))
    (g/'src/dispatch.cpp').write_text(row.replace('true,false,&','false,false,&'))
    try:m.integrate(p,g,'009000',proof,commit=False,missing_states=True)
    except ValueError as exc:assert 'already owned' in str(exc)
    else:raise AssertionError('Partially overlapping carry wildcard must be rejected')
    (p/'src/dispatch.cpp').write_text(initial);(g/'src/dispatch.cpp').write_text(row)
    result=m.integrate(p,g,'009000',proof,commit=True,missing_states=True)
    assert result['new_dispatch_owner_sites']==0
    assert result['new_instruction_sites']==0 and result['new_state_sites']==1 and result['state_domain_overlap']==0
    assert old in (p/'src/dispatch.cpp').read_text()
    # A wildcard partially overlapping C0 must be rejected conservatively.
    assert m.state_domains_overlap(row.strip(),row.replace('true,false,&','false,false,&').strip())
    assert not m.state_domains_overlap(row.strip(),row.replace('true,false,&','true,true,&').strip())
print('MISSING_STATE_INTEGRATOR_PASS: default rejection, disjoint widths, carry domains, preservation')
