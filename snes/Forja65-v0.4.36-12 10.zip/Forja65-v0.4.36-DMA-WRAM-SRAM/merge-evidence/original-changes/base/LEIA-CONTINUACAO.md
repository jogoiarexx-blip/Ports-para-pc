# Checkpoint reconstruído — continuação da primeira fase

Esta entrega foi reconstruída a partir de Forja65 v0.3.96 e ZERO v0.41 após a pasta da execução anterior ficar indisponível. O replay histórico de 14.809 frames não acompanha esta entrega e não é usado como sua validação.

## Resolvido e verificado nesta entrega

- BE:D8E7 integrado: 14 endereços novos, 30 entradas; fonte com o mesmo SHA256 da pré-análise preparada.
- B9:AB24 integrado após observação real: 5 endereços novos e 10 entradas.
- 00:CA45 recompilado para E0/M0/X0: 4 entradas de estado em 2 endereços existentes.
- Forja65: opção --missing-states preserva todas as linhas antigas e aceita somente domínios E/M/X/carry disjuntos. Wildcards parcialmente sobrepostos são descartados conservadoramente. Rejeições de ROM, fonte e duplicação continuam ativas.
- 158.992 linhas originais de despacho/aliases preservadas exatamente, em sua ordem original; 44 linhas novas; prova de ROM/fonte e ordenação passaram.
- 7 verificações de regressão passaram. Revisão independente não encontrou falhas críticas ou importantes.
- ZERO recompilado com g++: 80 unidades de tradução, trace desativado. O executável Linux válido, com tamanho e SHA256 verificados, está em linux/game-81fb14de022a.
- Replay determinístico: 14.457 frames completos. Todos os 14.420 hashes da referência foram preservados, sem divergência. O último replay também preservou os 14.457 hashes do replay imediatamente anterior.

## Pendente

Lakeside Limbo ainda não foi concluída. A execução encerra com código 2 ao encontrar o estado não recompilado de 80:832B (E0/M0/X0/C0), vindo de 80:CA6B. A próxima pista real normalizada está em reports/recovery-checkpoint/next-observed-hint.txt.

As correções históricas de retorno calculado/NMI não estão reconstruídas nesta entrega; consulte reports/recovery-checkpoint/HISTORICO-NAO-RECUPERADO.md. Preservação do prefixo não equivale a prova de equivalência completa da fase.

CMake/CTest não estavam disponíveis neste ambiente. A compilação foi feita diretamente com g++; não se afirma aprovação da suíte CTest, da suíte JavaScript completa nem compilação Windows desta versão.

## Reproduzir o ZERO em Linux

Na pasta DKC3-ZERO-v0.42:

```sh
python3 tools/test_recovery_checkpoint.py
python3 tools/replay_linux_checkpoint.py minha-validacao --capture 14456
```

O replay usa uma pasta nova, SRAM nova, a sequência input/first-stage-traversal-v037.trace e orçamento de 22.000 frames. Os hashes completos são publicados após o encerramento da execução. Código 2 é o bloqueio de tradução documentado; a comparação do prefixo deve passar. O orçamento não é um critério de conclusão da fase.

Para recompilar:

```sh
python3 tools/build_linux_checkpoint.py
```

No Windows, use o fluxo CMake original do projeto; ele ainda requer compilação e validação local. O binário fornecido nesta entrega é Linux.

As provas novas ficam em reports/recovery-checkpoint; as pastas validation-* mantêm o histórico dos arquivos de entrada. CONTENTS.sha256 cobre os arquivos desta entrega.
