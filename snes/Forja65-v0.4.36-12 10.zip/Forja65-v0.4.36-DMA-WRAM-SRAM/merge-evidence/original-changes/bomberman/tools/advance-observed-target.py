#!/usr/bin/env python3
"""Reproduce a single ROM-bound Forja65 CFG target and safely stage its port integration.

A focused observation avoids losing a newly observed target under an unrelated
CFG analysis budget. No semantic/runtime-equivalence claim is made here.
"""
import argparse
import hashlib
import json
import re
import subprocess
import sys
from pathlib import Path

TARGET = re.compile(r'^[0-9A-F]{6}$')
OBS = re.compile(r'^rom=([0-9a-f]{16}) target=([0-9A-F]{6})\b.*\bobserved=1(?:\s*)$', re.I)


def observation(hint: str, target: str) -> tuple[str, str]:
    lines = [line.strip() for line in hint.splitlines() if line.strip() and not line.lstrip().startswith('#')]
    if len(lines) != 1:
        raise ValueError('Require exactly one observed, ROM-bound hint for a focused run')
    match = OBS.fullmatch(lines[0])
    if not match or match.group(2).upper() != target:
        raise ValueError('Hint must identify the expected target with observed=1 and ROM fingerprint')
    return lines[0], match.group(1).lower()


def run(args, cwd=None):
    result = subprocess.run(args, check=False, cwd=cwd, text=True, capture_output=True)
    if result.returncode:
        # Keep the actual guardrail reason (overlap, ROM mismatch, etc.) visible.
        # Do not mask it behind a generic CalledProcessError with no stderr.
        detail = (result.stderr or result.stdout or '').strip()[-1200:]
        raise ValueError(f'{Path(args[0]).name} failed ({result.returncode}): {detail}')
    return result


def advance(forja, rom, project, hint_path, target, out, apply=False, max_sites=512, preserve_existing=False):
    if not TARGET.fullmatch(target) or max_sites < 1:
        raise ValueError('Invalid target or maximum instruction budget')
    raw = hint_path.read_text(encoding='utf-8')
    line, fingerprint = observation(raw, target)
    project_rom = project/'assets/cart-data.bin'
    if not project_rom.is_file() or not rom.is_file():
        raise ValueError('Missing ROM for target port or Forja65 analysis')
    if hashlib.sha256(project_rom.read_bytes()).digest() != hashlib.sha256(rom.read_bytes()).digest():
        raise ValueError('Project and analysis ROM differ')
    out.mkdir(parents=True, exist_ok=True)
    focused = out/'focused-observation.txt'
    focused.write_text(line+'\n', encoding='utf-8')
    gen = out/'generated'
    run(['node', str(forja/'tools/forja65.js'), 'analyze', str(rom),
         '--hints', str(focused), '--max', str(max_sites), '--cache-limit', '8192', '--out', str(gen)])
    candidates = [p for p in (gen/'src').glob('generated_*.cpp')
                  if f'void sub_{target}_' in p.read_text(encoding='utf-8')]
    if len(candidates) != 1:
        raise ValueError(f'Target must appear in exactly one generated shard (found {len(candidates)})')
    proof_path = out/f'{target.lower()}-rom-proof.json'
    run(['node', str(forja/'tools/verify-generated-rom.js'), str(rom), str(candidates[0]),
         target, fingerprint, str(proof_path)])
    result = json.loads(run([sys.executable, str(forja/'tools/integrate-generated-cfg.py'),
           '--project', str(project), '--generated', str(gen), '--entry', target,
           '--proof', str(proof_path)] + (['--apply'] if apply else []) + (['--preserve-existing'] if preserve_existing else [])).stdout)
    result.update({'schema': 'forja65.observed-target-integration.v1',
                   'hint': line, 'focus_max': max_sites,
                   'generated_shard': candidates[0].name,
                   'source_rom_sha256': json.loads(proof_path.read_text())['rom']['sha256'],
                   'compile_and_replay_verified': False})
    (out/'integration-report.json').write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
    return result


def main():
    a = argparse.ArgumentParser(description=__doc__)
    a.add_argument('--forja', type=Path, default=Path(__file__).resolve().parent.parent)
    for key in ('rom','project','hint','out'):
        a.add_argument('--'+key, type=Path, required=True)
    a.add_argument('--target', required=True)
    a.add_argument('--max-sites', type=int, default=512)
    a.add_argument('--apply', action='store_true')
    a.add_argument('--preserve-existing', action='store_true')
    args = a.parse_args()
    try:
        info = advance(args.forja.resolve(), args.rom.resolve(), args.project.resolve(),
                       args.hint.resolve(), args.target.upper(), args.out.resolve(),
                       args.apply, args.max_sites, args.preserve_existing)
    except (ValueError, subprocess.CalledProcessError, OSError) as e:
        a.exit(2, f'Forja65 focused target rejected: {e}\n')
    print(json.dumps(info, indent=2))

if __name__ == '__main__':
    main()
