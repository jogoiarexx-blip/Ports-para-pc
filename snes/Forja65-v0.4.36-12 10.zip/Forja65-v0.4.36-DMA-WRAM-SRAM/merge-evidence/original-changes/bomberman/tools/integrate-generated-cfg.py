#!/usr/bin/env python3
"""Safely add a ROM-generated Forja65 routine to an existing port.

Requires a prior successful tools/verify-generated-rom.js run. This performs
structural checks, not semantic equivalence. Never silently replaces existing
routines or claims the game is playable.
"""
import argparse
import hashlib
import json
import re
from pathlib import Path

ROW = re.compile(r'^\{0x([A-F0-9]{6})u,([^\n]+)\},$')
DISPATCH_MARKER = re.compile(r'(static const(?:expr)?\s+Forja65DispatchEntry\s+kForja65Dispatch\[\]\s*=\s*\{)')


def integrate(project: Path, generated: Path, entry: str, proof: Path, *, commit: bool, preserve_existing: bool=False):
    entry = entry.upper().removeprefix('0X')
    if not re.fullmatch(r'[0-9A-F]{6}', entry):
        raise ValueError('Entry must be six hexadecimal digits')
    info = json.loads(proof.read_text(encoding='utf-8'))
    source = next(iter(p for p in generated.glob('src/generated_*.cpp')
                       if f'void sub_{entry}_' in p.read_text(encoding='utf-8')), None)
    if source is None:
        raise ValueError(f'Generated routine {entry} not found')
    generated_cpp = source.read_text(encoding='utf-8')
    # A focused Forja65 analysis may emit extra CFG functions reached while
    # exploring the observed target. Importing these functions blindly creates
    # duplicate global definitions (e.g. BB8D90 from B9E124). They are not
    # owned by this integration. Keep only the requested target's bodies.
    original_generated_cpp = generated_cpp
    all_functions = list(re.finditer(r'^void (sub_[A-F0-9]{6}_[A-Za-z0-9_]+)\(CpuState&',
                                     generated_cpp, re.M))
    if not all_functions:
        raise ValueError('Generated source contains no functions')
    if generated_cpp[:all_functions[0].start()].strip() != '#include "generated.hpp"':
        raise ValueError('Unexpected generated source preamble; cannot safely isolate routine')
    chosen = []
    ignored_functions = []
    for ix, fn in enumerate(all_functions):
        end = all_functions[ix+1].start() if ix+1 < len(all_functions) else len(generated_cpp)
        if fn.group(1).startswith('sub_'+entry+'_'):
            chosen.append(generated_cpp[fn.start():end])
        else:
            ignored_functions.append(fn.group(1))
    if not chosen:
        raise ValueError('Focused source does not define its observed entry')
    generated_cpp = '#include "generated.hpp"\n' + ''.join(chosen)
    if (info.get('entry') != entry or info.get('rom_opcode_mismatches') != 0
            or info.get('code_sha256') != hashlib.sha256(original_generated_cpp.encode()).hexdigest()):
        raise ValueError('Generated source and ROM provenance report do not match')
    rompath = project / 'assets/cart-data.bin'
    if not rompath.is_file():
        raise ValueError('Project ROM assets/cart-data.bin missing')
    rombytes = rompath.read_bytes()
    if hashlib.sha256(rombytes).hexdigest() != info['rom']['sha256']:
        raise ValueError('ROM mismatch: refusing to integrate generated code')
    declarations = re.findall(r'^void (sub_'+entry+r'_[A-Za-z0-9_]+)\(CpuState&', generated_cpp, re.M)
    if not declarations or len(set(declarations)) != len(declarations):
        raise ValueError('Missing or duplicated routine declarations')
    # A repeated import is rejected before scanning other C++ definitions;
    # distinguish it from a collision with an unrelated generated shard.
    if (project / f'src/forja_{entry.lower()}.cpp').exists():
        raise ValueError('Routine already integrated: refusing duplicate insertion')
    # Dispatch ownership alone is insufficient: a previously generated shard
    # might define a function not currently exposed in the dispatcher. Catch
    # that duplicate at integration time rather than at the final link stage.
    for sibling in (project/'src').glob('*.cpp'):
        if sibling.name == 'dispatch.cpp':  # declarations, not definitions
            continue
        existing = sibling.read_text(encoding='utf-8')
        for function in declarations:
            if re.search(r'^void '+re.escape(function)+r'\(CpuState&', existing, re.M):
                raise ValueError(f'Function {function} already defined in {sibling.name}')
    generated_dispatch = (generated/'src/dispatch.cpp').read_text(encoding='utf-8')
    entries = [line for line in generated_dispatch.splitlines()
               if ROW.fullmatch(line) and any('&'+decl+',' in line for decl in declarations)]
    if not entries or f'{{0x{entry}u,' not in '\n'.join(entries):
        raise ValueError('No dispatcher entries for generated routine')
    pcs = [int(ROW.fullmatch(row)[1], 16) for row in entries]
    if pcs != sorted(pcs):
        raise ValueError('Generated dispatch rows out of order')
    target_dispatch = project / 'src/dispatch.cpp'
    target_cpp = project / f'src/forja_{entry.lower()}.cpp'
    target_cmake = project / 'CMakeLists.txt'
    if target_cpp.exists() or any(decl in target_dispatch.read_text(encoding='utf-8') for decl in declarations):
        raise ValueError('Routine already integrated: refusing duplicate insertion')
    original = target_dispatch.read_text(encoding='utf-8')
    match = DISPATCH_MARKER.search(original)
    if not match:
        raise ValueError('Target dispatcher table not found')
    start = original.index('\n', match.end()) + 1
    end = original.index('\n};', start)
    old_rows = original[start:end].splitlines(keepends=True)
    old_pcs = [int(m[1], 16) for row in old_rows if (m := ROW.fullmatch(row.rstrip('\n')))]
    if old_pcs != sorted(old_pcs):
        raise ValueError('Existing dispatcher table not ordered')
    overlap = set(old_pcs) & set(pcs)
    if overlap and not preserve_existing:
        raise ValueError('Existing dispatch address conflicts: '+', '.join(f'{p:06X}' for p in sorted(overlap)[:8]))
    # The same instruction site can be independently discovered from multiple
    # ROM entry points. Preserve the already-tested dispatcher ownership;
    # only the previously unowned sites may be added. The full generated body
    # remains available for in-function branches, but never replaces an entry.
    if overlap:
        if int(entry, 16) in overlap:
            raise ValueError('Observed entry is already owned: refusing to shadow its dispatcher')
        entries = [row for row in entries if int(ROW.fullmatch(row)[1], 16) not in overlap]
        pcs = [int(ROW.fullmatch(row)[1], 16) for row in entries]
        if not entries or int(entry,16) not in pcs:
            raise ValueError('No new observed target entries remain after preserving ownership')

    if 'src/dispatch.cpp' not in target_cmake.read_text(encoding='utf-8'):
        raise ValueError('No src/dispatch.cpp in CMakeLists.txt')
    merged = []
    i = 0
    for row in old_rows:
        m = ROW.fullmatch(row.rstrip('\n'))
        if m:
            pc = int(m[1], 16)
            while i < len(entries) and pcs[i] < pc:
                merged.append(entries[i]+'\n')
                i += 1
        merged.append(row)
    merged.extend(row+'\n' for row in entries[i:])
    declaration_block = '\n'.join(f'void {fn}(CpuState&, SnesRuntime&, std::uint32_t);' for fn in declarations)+'\n'
    new_dispatch = original[:start] + ''.join(merged) + original[end:]
    # Declarations must be visible before the dispatch table; no downstream header edits.
    marker = match.group(0)
    assert new_dispatch.count(marker) == 1
    new_dispatch = new_dispatch.replace(marker, declaration_block+marker, 1)
    cmake = target_cmake.read_text(encoding='utf-8')
    if f'src/forja_{entry.lower()}.cpp' in cmake:
        raise ValueError('Generated source already listed in CMake')
    new_cmake = cmake.replace('src/dispatch.cpp', f'src/dispatch.cpp src/forja_{entry.lower()}.cpp', 1)
    merged_pcs = [int(m[1],16) for r in merged if (m:=ROW.fullmatch(r.rstrip('\n')))]
    if merged_pcs != sorted(merged_pcs) or len(merged_pcs)!=len(old_pcs)+len(entries):
        raise ValueError('Dispatcher merge structural verification failed')
    summary = {'entry':entry,'rom_sha256':info['rom']['sha256'], 'generated_cpp_sha256':info['code_sha256'],
               'variants':declarations,'ignored_non_target_functions':ignored_functions,
               'integrated_source_sha256':hashlib.sha256(generated_cpp.encode()).hexdigest(),
               'new_dispatch_rows':len(entries),'new_instruction_sites':len(set(pcs)),
               'address_overlap':0,'preserved_existing_sites':len(overlap),
               'preserved_existing_rows':sum(1 for pc in old_pcs if pc in overlap),
               'new_dispatch_owner_sites':len(set(pcs)),
               'previous_dispatch_rows':len(old_pcs),
               'proof_level':'ROM opcode match and static dispatch integration only; runtime replay required',
               'dry_run':not commit}
    if commit:
        # All checks above must pass before writing any source file.
        target_cpp.write_text(generated_cpp, encoding='utf-8')
        target_dispatch.write_text(new_dispatch, encoding='utf-8')
        target_cmake.write_text(new_cmake, encoding='utf-8')
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--project', type=Path, required=True)
    parser.add_argument('--generated', type=Path, required=True)
    parser.add_argument('--entry', required=True)
    parser.add_argument('--proof', type=Path, required=True)
    parser.add_argument('--apply', action='store_true', help='Actually write changes; default is validation-only')
    parser.add_argument('--preserve-existing', action='store_true', help='Keep existing dispatcher ownership for shared instruction sites (never overwrite the observed entry)')
    parser.add_argument('--report', type=Path)
    args = parser.parse_args()
    result = integrate(args.project, args.generated, args.entry, args.proof, commit=args.apply, preserve_existing=args.preserve_existing)
    if args.report:
        args.report.write_text(json.dumps(result, indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result, indent=2))

if __name__ == '__main__':
    main()
