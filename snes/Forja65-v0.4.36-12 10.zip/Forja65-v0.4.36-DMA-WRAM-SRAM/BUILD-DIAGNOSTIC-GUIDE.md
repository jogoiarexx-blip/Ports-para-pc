# Forja65: reproducible generated-project build

Generated C++ translation units can be expensive to compile. Diagnose with 1-2 compiler jobs rather than oversubscribing RAM. For Linux: `cmake -S . -B build-diagnostic -G Ninja -DCMAKE_BUILD_TYPE=Debug -DCMAKE_CXX_FLAGS_DEBUG='-O0 -g0' && cmake --build build-diagnostic --target game -j 2`. On Windows use `cmake --build build-diagnostic --config Debug --target game --parallel 2`. This is a build configuration guideline, not a CFG fix.

For DKC3, `B28030 -> B28273` is emitted in generated_026.cpp, implemented in generated_012.cpp, and registered in dispatch.cpp. Runtime validation after compilation is still required.
