# Forja65 Soldiers Crossfeed v0.38

O Forja65 permanece projeto separado e não substitui o port nativo. Seu código gerador de ROM e dispatcher foi preservado.

## Melhoria estrutural

Novo `tools/audit_integrated_flow.py` (somente leitura) para confirmar prova ROM, identidade do fingerprint, presença de cada corpo C++ decodificado, inclusão no CMake e cobertura dos endereços no dispatcher de um port externo. Isso ajuda a detectar integrações incompletas quando novos destinos são incorporados.

Exemplo, estando na raiz do Forja65 e com o Soldiers disponível:

```bash
python3 tools/audit_integrated_flow.py --port /caminho/Soldiers-of-Fortune-Native-PC --evidence /caminho/Soldiers-of-Fortune-Native-PC/analysis/soldiers-crossfeed-v38 --expected-rom 2f095d162726b5ea C0803E C082F3 C08389 C0372B C08245
```

**Testes:** `python3 -m unittest discover -s tools -p 'test_audit_integrated_flow_v38.py'` (3 testes novos aprovados), e `test_integrate_observed_flow.py` (9 testes aprovados).

No Soldiers, o replay desta evolução passou de `$C0:803E` para `$C0:82F3`, depois `$C0:8389`, e então `$C0:372B` e depois `$C0:8245`; todos foram gerados e compilados. O último replay também ultrapassou `$C0:8245` e identificou `$C0:840C` vindo de `$C0:8241`. A contagem e o gameplay ainda não foram validados. Este ganho não comprova o término de GET READY nem jogabilidade.
