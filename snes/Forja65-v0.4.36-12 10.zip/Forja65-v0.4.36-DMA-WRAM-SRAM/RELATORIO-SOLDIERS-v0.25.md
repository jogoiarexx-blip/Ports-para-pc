# Soldiers v0.25 — captura automática de candidatos

- `INVESTIGAR-GET-READY-AUTO-v25.sh`: compila uma vez, compara WRAM neutral/controlada, seleciona até 24 endereços válidos, faz captura dos escritores e correlaciona vídeo.
- `tools/select-get-ready-watches.py`: restringe seleção a endereços WRAM reais, sem aceitar PCs/endereços ROM; recusa conjunto vazio ou captura insuficiente.
- Testes: 3/3 do seletor; 4/4 dos testes existentes do ranking. Bash syntax aprovada.
- Compilação integral foi tentada mas ultrapassou o tempo permitido; portanto o pipeline completo não foi executado e a validade da execução do game continua pendente.
- Ainda não há prova da sequência real 03→02→01→00, de deslocamento/tiros, nem resolução de `$C0:F923`.
- Executar no Linux: `./INVESTIGAR-GET-READY-AUTO-v25.sh` a partir da raiz do projeto (requer CMake, Ninja e toolchain).
- Importante: este script não modifica ROM, tempo do jogo, estado de entrada nem o fluxo de CFG. Os arquivos gerados ficam em `reports/v25/`.
