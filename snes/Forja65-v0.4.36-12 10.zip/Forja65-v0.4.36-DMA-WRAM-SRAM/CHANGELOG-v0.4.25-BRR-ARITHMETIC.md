# Forja65 v0.4.25 — BRR arithmetic

Base: v0.4.24-DSP-KEY-TIMING, preservada integralmente.

- Corrigido range 0 com nibble negativo ímpar: shift aritmético em vez de
  truncamento por divisão inteira (F produz -2 PCM, anteriormente 0).
- Corrigida saturação de filtros BRR: accumulator signed16, seguido por
  duplicação e wrap signed16; histórico half-PCM recebe o valor já wrapped.
- FORJA65_DSP_BRR=legacy recupera exatamente a aritmética anterior.
  Gaussiana/linear, envelope e keys legacy continuam independentes.
- C++20 evita shift à esquerda de número negativo e faz wrap explicitamente.
- Novo oracle Python independente usa histórico full-PCM. Comparação C++
  gerada percorre 50178 vetores de dois blocos / 1605696 amostras,
  ranges 0–15, filtros 0–3, nibbles 0–15, histórico e wrap de SPC RAM.
  Falhas mostram primeiro record/header/history/block/sample em JSON no stderr.
- Compatibilidade do cache CFG exclusivamente v0.4.25→v0.4.24; fingerprint
  continua obrigatório, e C++ é regenerado. Nenhum cache arbitrário liberado.
- VERSION e VERSION.txt sincronizados com a API do core.
- Auditoria, inventário SHA256 e resultados atuais estão em docs/AUDITORIA-v0.4.25.md
  e reports/validation-v0425. Nenhum port de jogo modificado.

Não é um DSP bit-perfect. Não houve execução de ROM comercial, validação
SPC/PCM de jogo real ou teste do dispositivo/EXE Windows nesta rodada.
Consultar RESULTADOS-v0.4.25.md para as falhas e limitações de execução.
