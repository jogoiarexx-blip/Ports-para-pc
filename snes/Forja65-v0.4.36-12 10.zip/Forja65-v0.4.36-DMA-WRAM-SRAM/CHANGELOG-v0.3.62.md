# Forja65 v0.3.62 — CFG verification
- New command-line verifier `node tools/verify-learned-cfg.js path/to/project`.
- Checks ROM fingerprint of every learned hint and presence of each hinted destination in generated native dispatch.
- Writes `reports/cfg-verification.json`, fails if a learned destination is missing.
- Tested against 5 DKC3 hints: all passed. This verifies dispatcher inclusion, NOT callback semantics or game execution.
