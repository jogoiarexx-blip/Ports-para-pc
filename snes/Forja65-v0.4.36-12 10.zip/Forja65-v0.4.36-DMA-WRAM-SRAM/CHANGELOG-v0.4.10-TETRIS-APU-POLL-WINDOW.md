# Forja65 v0.4.10 — crossfeed Tetris SPC CPU Poll Window

- Runtime C++ gerado agora suporta `FORJA65_APU_TRACE_READS=window` (1364 master cycles).
- Eventos Q (CPU leitura de portas de áudio) incluem PC de CPU inicial/final, preservando leitura passiva.
- Escritas em portas interrompem compressão RLE da mesma porta. Nenhum poll subsequente é descartado quando o índice RLE ficou inválido.
- Mantidos modos antigo `changes` e `all`; CSV adiciona colunas finais compatíveis com antigos leitores tolerantes a novas colunas.
- Testes `tetris-spc-cpu-poll-runs-v0410` e `tetris-spc-port-observer-v0409` ajustados; novo `tetris-spc-poll-window-v0411-regression.js` gera e compila C++ sintético.
- 15 regressões Tetris validadas (14 anteriores e 1 nova), sem troca de timing SPC padrão.
- Rastros completos no ZIP complementar Tetris v0.4.11.
- Ainda sem oracle SNES do timing CPU/APU.
