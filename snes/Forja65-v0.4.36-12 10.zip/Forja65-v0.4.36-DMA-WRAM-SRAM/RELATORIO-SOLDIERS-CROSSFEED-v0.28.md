# Crossfeed v0.28
Adicionada a ferramenta tools/inspect-f923-coverage.py e seu teste. É diagnóstico genérico de referência textual de PC de 24 bits em src/*.cpp, reutilizável nos ports produzidos pelo Forja65. NÃO altera gerador, CPU, PPU, áudio nem semântica de branches.
