# Scooby-Doo Crossfeed v0.12

- Comprovado replay completo de 5.000 quadros com a compilacao final da v0.11 (antes: 4.384 quadros experimentais).
- Novo audit generico `tools/frame-milestone-audit.js` para verificar contagem consecutiva de frames, saida da execucao, variacao grafica/memoria e identidade da ROM nas capturas.
- Novo teste `tests/frame-milestone-audit-v12-regression.js`, cobrindo rejeicao de hashes misturados/ausentes, capturas com numero errado, e replay incompleto.
- Sem alteracao na semantica CPU/PPU/DMA nesta rodada: avancou pelo reaproveitamento do CFG ja aprendido e compilado na v0.11.
- Conclusao da fase nao comprovada; a visualizacao continua em hardware SNES parcialmente virtualizado.
