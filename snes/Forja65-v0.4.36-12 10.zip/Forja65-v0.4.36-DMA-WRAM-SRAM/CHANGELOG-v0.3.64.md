# Forja65 v0.3.64 — bounded native partitions and boot priority

## Implementado no núcleo do gerador

- `partitionCompiledFunctions` limita uma função C++ gerada a aproximadamente 160 variantes de instruções, sem dividir as variantes do mesmo PC.
- Alvos conhecidos de branch condicional/incondicional que caiam em outra partição agora transitam por `hw.requestDispatch` em vez de serem considerados `unresolvedFlow`.
- Fallthrough entre partições também solicita retomada pelo dispatcher; este preserva PB, pilha CPU e flags reais.
- Ampliada a distribuição determinística de 32 para 64 shards, com o índice da partição no hash.
- RESET tem prioridade obrigatória sobre os runtime hints, impedindo que o orçamento de análise remova a entrada do jogo.
- Destinos observados no runtime têm prioridade sobre descendentes especulativos descobertos na análise.
- Atualizado version string para `0.3.64-bounded-native-partitions`.

## Evidência

- `tests/cfg-bounded-partitions-v0364-regression.js`: 249 opcodes analisados, múltiplos blocos, cross-partition branch/fallthrough válidos.
- `tests/cfg-reset-priority-v0364-regression.js`: caso de análise com pistas que saturam orçamento não elimina RESET.
- 3 regressões anteriores (`hot-call-priority`, `fallthrough`, `cfg-direct`) continuam aprovadas.
- DKC3 PT-BR recompilado no Linux com clang++ 17 (Debug, -O0), headless executado. Continua não jogável: bloqueio atual é CFG `0082CF -> 00BBA6`.

## Limites

Dividir o C++ não garante equivalência gráfica. Nem todos os frames do jogo foram alcançados. O runtime ainda contém PPU/APU e DMA/HDMA virtuais e exige dados da ROM.
