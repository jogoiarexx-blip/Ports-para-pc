Forja65 v0.3.86 — testes direcionados da nova instrumentacao
PASS tests/dma-forensics-v0386-regression.js
PASS tests/obj-slot-visibility-v0385-regression.js
PASS tests/cfg-cache-compatible-v0369-regression.js
Observacao: suite de 134 testes nao foi concluida neste ciclo; execução integral interrompida por timeout.
