@echo off
setlocal
cd /d "%~dp0"
node --check forja65-core.js || exit /b 1
node tools\test-timing-v0432.js || exit /b 1
echo TIMING v0.4.32 PASS
pause
