# Super Bomberman 2 — progresso v0.2

Encerramento do progresso atual a pedido do usuário. A primeira fase NÃO foi concluída: a ativação da saída e a entrada na fase 1-2 permanecem pendentes.

## Progresso comprovado

- Jogo iniciado no modo Normal, fase 1-1.
- Movimento, colocação de bombas, explosões e destruição de blocos funcionando nos replays testados.
- Os três inimigos da fase 1-1 foram eliminados. A captura do quadro 6040 mostra 300 pontos e três vidas.
- Replay principal: replays/stage-1-top-trap.txt. A captura de referência em evidencias/combate-6040 usa stage-1-targets.txt, cujo trecho até o quadro 6040 é o mesmo.
- replays/stage-1-exit.txt preserva uma tentativa de abrir a saída. Não constitui comprovação da passagem de fase. A última convergência aprendeu uma entrada no quadro 7299; a segunda compilação foi interrompida de forma controlada para encerrar a entrega. Essa geração final requer recompilação.
- O progresso foi obtido por entradas de controle; não foi necessário alterar a memória do jogo para eliminar os inimigos.

## Correções e validação

A leitura automática do controle consome os 16 bits seriais, preservando a assinatura que o jogo exige após a leitura. Isso corrigiu o caso em que as teclas chegavam ao runtime, mas eram rejeitadas pelo jogo.

A descoberta de chamadores JSL usa o estado observado da CPU e valida o endereço e a ROM. O cache de cobertura e as rotinas geradas incluem as descobertas feitas durante os replays de combate.

Testes específicos de leitura serial automática e descoberta JSL passaram. A suíte anterior passou em 163/163 testes. Após a inclusão do novo teste, as duas execuções complementares da suíte de 164 testes encerraram com código zero; os logs locais dessa execução foram parcialmente truncados. Os logs preservados estão em evidencias.

A auditoria de referência do quadro 6040 registrou runtime_started=PASS, frames=6040, framebuffer_hash=49c1b55763f91156 e wram_hash=b8273d4ba6d9ba1a. PASS de execução não significa fase vencida.

## Uso e limites

Este pacote contém fontes, dados do cartucho, ferramentas, replays e evidências. Recompilar antes de executar. BUILD-WINDOWS.cmd é o ponto de entrada Windows. Enter inicia; setas movem; A coloca bombas. Os replays usam a máscara do controle SNES.

A execução foi validada no Linux. Nenhum executável Windows foi compilado ou validado nesta entrega. A CPU é traduzida para C++; componentes de hardware SNES e dados do cartucho continuam sendo dependências do runtime. A migração integral para implementações host não está concluída.

O ramo Forja65 incluído deriva de 0.3.97. Para combinar com ramos mais recentes de outros trabalhos, integrar as alterações seletivamente. Não substituir todo um ramo mais recente por este pacote.
