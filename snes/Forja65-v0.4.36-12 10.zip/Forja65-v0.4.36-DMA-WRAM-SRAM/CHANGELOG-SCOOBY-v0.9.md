# Forja65 — integracao Scooby-Doo v0.9

- Recuperacao em estado de CPU 65816 da ROM durante entrada de botao A em quadro 3162 (0x81CC67).
- `tools/dialogue-input-audit.js`: compara hashes de framebuffer e WRAM entre dois replays, verificando prefixo identico, continuidades e falta de quadros.
- `tests/dialogue-input-audit-v09-regression.js`: regressao em casos de diferenca visual, so WRAM, prefixo invalido, eventos fora de ordem e log incompleto.
- A auditoria **nao** declara jogabilidade a partir de uma diferenca no framebuffer (dialogos podem mudar).
