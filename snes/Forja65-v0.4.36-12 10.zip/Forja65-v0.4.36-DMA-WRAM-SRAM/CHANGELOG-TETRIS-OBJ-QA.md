# Forja65 v0.3.97 — pacote QA extra do Tetris 2

A implementação do compositor OBJ no gerador v0.3.97 já contém banco base de 3 bits,
name-select +1, Y wrap, ordem OAM, rotação e cache de planos. Não se mudou o
`VERSION` do gerador nem o código gerado por ele nesta revisão: o avanço aqui é
**provar e manter** esse contrato ao ser integrado a ports gerados anteriormente.

- Novo teste `tests/tetris-obj-crossfeed-v0398-regression.js` gera runtime de ROM sintética, compila C++ e valida a saída OBJ incluindo DMA, VBlank e parity escalar/por linha.
- O teste corresponde a `tests/sprite_crossfeed_smoke.cpp` distribuído no Tetris v0.3.98.
- Novo `tools/compare_frame_traces.py` para localizar diferenças de vídeo, WRAM e PC por frame.
- Novo script CMD `TESTAR-CROSSFEED-TETRIS.cmd`, requer Node.js e g++ no PATH.
- Teste complementar v0.3.97 da CPU/PPU/SPC permanece preservado.

Resultado: testes de regressão do gerador Tetris v0.3.97 e OBJ v0.3.98 passaram em Linux. Uma alteração no framebuffer do Tetris após quadro 333 NÃO é evidência automática de fidelidade ao SNES; a comparação com capturas originais permanece pendente.
