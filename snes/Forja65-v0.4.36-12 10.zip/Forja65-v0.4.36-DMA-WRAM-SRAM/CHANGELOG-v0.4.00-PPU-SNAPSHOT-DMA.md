# Forja65 v0.4.00 — melhorias do Tetris 2 incorporadas ao gerador

- O runtime C++ gerado acelera a captura estática de scanlines por caches locais de BG/OBJ, sem alterar a semântica do compositor por segmento usado no jogo.
- Ativa por padrão o despacho B-bus direto de DMA (`FORJA65_DMA_MODE=auto`) para PPU/APU/WRAM, mantendo `FORJA65_DMA_MODE=virtual` para depuração e fallback de endereços não suportados.
- Teste `tests/tetris-ppu-dma-v0401-regression.js` gera um projeto de ROM sintética, compila dois executáveis C++ reais e valida paridade de pixels e DMA.
- Os mesmos patches estão copiados no Forja65 embutido dentro do Tetris 2 v0.4.01.
- Isto não equivale a retirar a PPU ou o SPC700 virtual nem comprova equivalência com capturas do SNES original.

## Validação integrada

Os testes anteriores de hardware, OBJ crossfeed, limite 32/34 e HDMA foram executados novamente e passaram, assim como a nova regressão v0.4.01. O binário Tetris 2 recompilado produziu 2.000 hashes de framebuffer/WRAM/PC iguais à v0.4.00.
