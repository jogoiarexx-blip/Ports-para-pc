# Forja65 v0.3.98 — OBJ 32/34 + STAT77

- Atualizado o template `src/runtime.hpp` emitido pelo gerador: seleção limitada a 32 sprites por scanline, processamento reverso das até 34 fatias gráficas de 8 pixels, exceção de sprite X=-256, rotação OAM e transparência.
- Incluídos bits 6 e 7 de `$213E` (STAT77 range/time overflow), reiniciados no início de cada quadro. Cronometria exata por dot segue pendente.
- Preservadas correções já existentes CPU/PPU/DMA/HDMA/SPC700/DSP da v0.3.97; não foram introduzidas novas alterações dessas rotinas neste salto.
- Novo teste `tests/tetris-obj-limits-v0399-regression.js` usa ROM sintética, gera projeto C++ e executa `tests/fixtures/tetris_sprite_limits_v0399.cpp` compilado com g++.
- Adaptado o teste v0398 para inspecionar o novo algoritmo sem exigir o cache antigo já removido.
- `TESTAR-CROSSFEED-TETRIS.cmd` executa todos os três testes.

**QA executada:** `tetris-hardware-v0397`, `tetris-obj-crossfeed-v0398`, `tetris-obj-limits-v0399`: aprovadas. Não foi executada a suíte completa histórica do Forja65 nem o compilador MSVC nesta execução.
