# Forja65 v0.4.12 — SPC700 $F1/$F2

- Corrigido DSPADDR `$F2`: readback mascara bit 7, preservando o bit escrito internamente para bloquear gravações `$F3`.
- Corrigido controle `$F1`: um temporizador reinicia apenas na transição desligado→ligado, inclusive com temporização experimental ativada. Corrige regressão de v0.4.11.
- Corrigido `forja65SpcPeek` (scheduler strict) para refletir a leitura de `$F2` e continuar livre de efeitos colaterais.
- Nova regressão `tests/tetris-spc-register-edges-v0413-regression.js` gera runtime com ROM sintética, compila fixture C++ e valida os dois modos de temporização.
- Atualizadas regressões legadas de DSP (v0.4.05) e scheduler strict (v0.4.12) que codificavam os comportamentos imprecisos.

### Validação
17 testes `tests/tetris-*regression.js` passaram (incluindo o novo), compilações C++ geradas incluídas. Testes gerais fora dessa seleção não foram repetidos integralmente, nem o executável Windows foi compilado.

Referências: https://snes.nesdev.org/wiki/S-SMP e https://snes.nesdev.org/wiki/S-DSP_registers
