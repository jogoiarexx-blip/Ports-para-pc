# Forja65 v0.4.27 — cobertura de regressao 65C816 (Biker v0.5)

- Preservadas as correcoes v0.4: vetor RESET e transporte do banco de dados em absx, absy, dp_indirect_y, stack_indirect_y.
- O gerador agora inclui em todo projeto um teste C++ `cpu_bank_cross_smoke` e registra o alvo no CTest. O teste diferencia enderecos com carry de banco dos enderecamentos direct-page, que nao devem usar carry.
- Teste rapido do gerador: `node tests/cpu-bank-carry-v0427-regression.js`, ou `TESTAR-CPU-BANK-CARRY-WINDOWS.cmd` no Windows.
- Teste de execucao: `cmake --build build --target cpu_bank_cross_smoke && ctest --test-dir build -R '^cpu_bank_cross_smoke$' --output-on-failure` num projeto gerado.
- Os replays especificos de Biker Mice ficam no pacote do jogo, nao no nucleo universal.
- Nenhuma alteracao adicional de CPU, PPU ou audio esta sendo considerada validada sem teste.
