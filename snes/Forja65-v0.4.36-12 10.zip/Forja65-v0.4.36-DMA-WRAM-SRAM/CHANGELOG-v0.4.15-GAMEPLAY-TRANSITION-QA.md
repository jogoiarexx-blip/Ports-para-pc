# Forja65 v0.4.15 — gameplay transition QA

Gerador atualizado para emitir `tools/gameplay_transition_qa.py` em todo port.
A ferramenta compara capturas de `FORJA65_CAPTURE_FRAMES` em duas sessoes
headless, com regras JSON para cenas iguais, diferentes, congeladas ou
alteradas. Sem dependencia Python externa ao standard library.

O Tetris 2 confirmou visualmente pausa e retomada por teste A/B
em 2.400 quadros; esta versao do Forja65 distribui a ferramenta generica,
nao injeta comportamento especifico do jogo nas rotinas CPU/PPU/APU.

Teste: `node tests/tetris-gameplay-transition-v0416-regression.js`.
