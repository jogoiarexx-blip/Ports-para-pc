# Forja65 — Atualização Soldiers of Fortune v0.7

- Endurecido `tools/advance-observed-target.py`: uma observação agora precisa indicar, de forma exata, fingerprint ROM, endereço de origem e destino, classe da transição, estado emulação/M/X/C e flag `observed=1`; entradas incompletas e campos injetados são rejeitados. Inclui `tools/test-observed-hint-strict.py`.
- Mantidas as proteções anteriores do integrador para rotinas particionadas, hash SHA-256 e compatibilidade com o dispatcher atual. Os três testes Python de regressão passaram.
- Integrações no projeto Soldiers (não são mudanças especiais no runtime do Forja): quatro alvos observados, 306 PCs e 783 entradas de despacho, sem colisões.
- O projeto Soldiers compilou limpo com GCC/CMake/Ninja no Linux, passou em 5 testes C++ selecionados e atingiu o próximo destino `$D0:04F7` no frame 5359.
- Sem afirmação de equivalência semântica completa, port livre de ROM ou gameplay finalizado. Compilação Windows não foi verificada.
