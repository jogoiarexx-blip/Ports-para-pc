# Forja65 v0.4.04 — crossfeed Soldiers of Fortune v0.3

- Corrigidos os registradores de leitura automatica de controle do SNES (`$4218-$421F`): o firmware le os dados latched apos a janela de 4224 master cycles do `$4212`, e nao a entrada atual do controle diretamente.
- `$4016/$4017` permanecem leitura serial independente.
- Opt-in `FORJA65_FRAME_PROGRESS_CSV` / `FORJA65_FRAME_PROGRESS_EVERY` para telemetria dos replays, sem mudar o estado da CPU/PPU.
- Teste de geracao `tests/soldiers-autojoy-latched-v0404-regression.js` PASS e teste existente `tests/soldiers-spc-hvbjoy-v0404-regression.js` PASS.
- Integrado no codigo generico `forja65-core.js`. O novo teste C++ sobre latch esta no projeto Soldiers correspondente.
- Na ROM Soldiers, as correcoes anteriores de SPC e CPU continuam presentes; a primeira fase ainda nao foi validada.
