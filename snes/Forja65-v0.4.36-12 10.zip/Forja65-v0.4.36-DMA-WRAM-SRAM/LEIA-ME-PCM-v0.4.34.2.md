# Forja65 v0.4.34.2 — PCM host aprimorado

Base: **Forja65 v0.4.34.1 CROSSFEED REUNIFICADO**. O pacote `.2` altera
**somente transporte PCM, diagnósticos e testes**. A versão do motor/decoder
(`0.4.34-ppu-mode7-math`) foi mantida para não mudar identidade do cache/CFG.

## O que foi corrigido

- **WinMM**: quando os 12 buffers de 512 frames estão ocupados, o áudio passa
  por padrão a esperar um buffer terminar, com limite de 300 tentativas de 1 ms.
  Antes, era descartado um bloco de 512 frames inteiros sem nenhuma espera.
  `FORJA65_AUDIO_SYNC=0` restaura o modo de descarte para medições de throughput.
- **Encerramento**: espera limitada a 350 tentativas de 1 ms pelo fim dos buffers
  já submetidos antes de fazer `waveOutReset()`. Sem isto a cauda audível era
  cortada na saída. `FORJA65_AUDIO_DRAIN=0` desativa esse comportamento.
- **PCM/WAV 16-bit little-endian**: gravação agora usa bytes explícitos, em vez
  da representação do processador host. O formato original 32000 Hz, 2 canais,
  16 bits permanece inalterado.
- **WAV RIFF**: gravação é limitada ao tamanho representável no cabeçalho de
  32 bits. Evita arquivo longo com tamanho declarado incorreto.
- **Diagnóstico**: `generated_frames`/pico e não-silêncio são contabilizados
  mesmo quando a saída de áudio falha ou está desligada. Acrescentados
  `gain_clipped_frames` (saturações adicionais do ganho do host),
  `pcm_buffer_wait_ms`, `pcm_drain_wait_ms`, `audio_sync` e `audio_drain`
  ao `forja65-audio-report.txt`. O ganho padrão permanece 100%.
- **Cobertura nova**: `node tests/pcm-output-v0435-regression.js` compila C++
  gerado e valida WAV, fronteira de buffer, ganho, contadores, reinicialização,
  e testa a fila WinMM por um dispositivo simulado, sem placa de som real.

## Como usar no Windows

1. Abra `ABRIR-FORJA65.cmd`, carregue a sua ROM e **gere novamente o projeto**.
2. Recompile o projeto C++ gerado com seus scripts `BUILD-WINDOWS.cmd`.
3. Execute `RUN-WINDOWS-AUDIO.cmd` no projeto gerado (ou `RUN-WINDOWS-AUDIO-INTERLEAVED.cmd`
   para experimentar a sincronização SPC/DSP opcional). Não confundir esta
   opção com `FORJA65_AUDIO_SYNC` de transporte PCM.
4. Leia `forja65-audio-report.txt` na pasta do jogo. `frames_dropped=0`
   significa nenhuma perda no envio para WinMM na execução observada; não
   garante que o jogo reproduziu som correto.
5. Para gravar sem depender da placa de som use `RUN-NATIVE-AUDIO.cmd`, que
   usa `FORJA65_AUDIO_DUMP=1` e produz `forja65-native-audio.wav`.

Se o jogo ficar lento por esperar pelo dispositivo, defina
`FORJA65_AUDIO_SYNC=0` antes de iniciar o projeto gerado; isso restaura o
comportamento anterior de baixa latência/possíveis descartes.

## Limites de fidelidade

O S-DSP do SNES usa 8 vozes com BRR, interpolação gaussiana e eco FIR. O
Forja65 implementa estes componentes, porém **não foi validado como bit-perfect**.
A opção `FORJA65_ECHO_RAM_WRITES` segue protegida por padrão; o agendamento
SPC/DSP intercalado também permanece opcional. Estas mudanças **não** afetam
cálculo de áudio original de uma ROM, execução da CPU 65C816, PPU ou flow/CFG;
melhoram a entrega do sinal já gerado. Teste WinMM com mock passou, mas **um
Windows real e placa de som ainda devem ser validados** antes de afirmar
redução de estalos/perdas audíveis em jogos comerciais.
