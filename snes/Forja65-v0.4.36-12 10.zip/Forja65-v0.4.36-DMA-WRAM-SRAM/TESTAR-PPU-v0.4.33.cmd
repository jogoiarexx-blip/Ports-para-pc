@echo off
cd /d "%~dp0"
node tools/test-ppu-v0433.js
if errorlevel 1 goto fail
echo PPU v0.4.33 PASS
pause
exit /b 0
:fail
echo PPU v0.4.33 FAIL
pause
exit /b 1
