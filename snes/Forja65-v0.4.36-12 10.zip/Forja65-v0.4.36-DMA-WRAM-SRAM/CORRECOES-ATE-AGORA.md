# Entrega acumulada — Forja65 v0.3.96 / DKC3 ZERO v0.41

Esta entrega contém os arquivos completos dos dois projetos, com as correções anteriores preservadas e os avanços desta rodada. Documentos de versões antigas são históricos; este relatório descreve o estado atual.

## Correções acumuladas

- PPU: cálculo de meia intensidade antes da saturação, preservação da tela principal quando a matemática está desabilitada, tratamento de force black e COLDATA com subscreen transparente.
- HDMA: wrap dentro do mesmo banco nos dados diretos, indiretos e ponteiros.
- OBJ: reutilização dos planos de tiles reduz leituras de 32 para 4 no trecho otimizado; equivalência com caminho escalar testada. Não há ganho de FPS medido.
- CPU: retornos nativos ligados à posição e largura reais da pilha; aposentadoria de frames redirecionados e proteção contra continuations de chamadas abandonadas.
- Forja: importação de FLOW respeita o estado observado na origem; retorno computado com PEA e trampolines RAM; propagação de estados de saída M/X/C e reanálise de chamadores indiretos; prioridades para evitar que descendentes de RESET consumam toda a descoberta.
- Build/testes: leituras de arquivos encerradas antes da remoção nos testes obj_capture_probe_smoke, dma_forensics_smoke e pixel_ownership_smoke. DMA também relata exceções. A correção está no gerador e no projeto DKC3; nenhum teste foi desativado. BUILD-WINDOWS distingue erro de compilação de erro de CTest.
- Novo nesta rodada: reconhecimento estrutural de tabelas ROM que alimentam JMP por vetor RAM e tabelas inline de JSR indexado. Destinos completos preservados além do limite heurístico de 64. Evidências de trampolines separadas por PC.
- A tabela real B7:D07B–B7:D123 contém 84 entradas/82 destinos; B9:E042–B9:E0E8 contém 83 entradas/59 destinos. Domínio dinâmico do índice ainda não provado; estas evidências não são equivalência de jogo.
- Os dois destinos dos logs da ROM anterior, 8099B3 e B9A93C, foram incorporados. Provas isoladas executaram 12 casos com retorno e pilha balanceados; isso não certifica a fase.
- Recuperação de 11 domínios de dispatch do catálogo da mesma ROM, verificando fingerprint e SHA256. Sem promoção artificial de rotinas a NATIVE, sem alterações de vidas, posição ou progresso em RAM.

## Verificação e limites

152 testes Forja: 141 passaram; 11 dependem de CMake, indisponível neste ambiente. O teste de execução da tabela inline foi repetido com PCH e passou após o limite de tempo da primeira tentativa; a evidência original e a repetição estão preservadas. 19 testes nativos C++ passaram, incluindo o bloqueio simulado de exclusão de arquivos abertos no Windows. A correção de limpeza foi reproduzida antes/depois; não houve build real com Windows/MSVC.

O primeiro replay desta revisão preservou exatamente framebuffer, WRAM e PC dos 14237 frames comuns com a versão anterior. Essa comparação é do round20, não uma afirmação de equivalência de todo o jogo. A comparação de cobertura incluída também corresponde à primeira geração da revisão.

O último replay concluído desta rodada completou os frames 0–14356 e falhou durante 14357: estado M/X/C ausente em BE:D3E2, depois do retorno de uma chamada. A propagação/reanálise de chamadores diretos está pendente de investigação e correção. O round32 foi interrompido; não é prova de execução bem-sucedida.

**A primeira fase ainda não está concluída nem certificada a 100%.** O limite de 22000 frames dos launchers não equivale a vitória. Não há prova independente de equivalência SNES, áudio completo ou ganho de FPS. equivalence_vectors permanece sem vetores independentes.

## Uso

Extraia cada ZIP em uma pasta nova. No DKC3, execute BUILD-WINDOWS.cmd; em caso de falha consulte build-win/Testing/Temporary/LastTest.log. RUN-FIRST-STAGE-v041-WINDOWS.cmd e RUN-FIRST-STAGE-v041-LINUX.sh reproduzem a entrada registrada; podem parar no bloqueio descrito acima. Não reutilize objetos ou executáveis de versões anteriores.
