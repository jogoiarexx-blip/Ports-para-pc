# Forja65 v0.3.85 — resultados de testes

- `node tools/test.js`: **133/133 aprovados**, incluindo `obj-slot-visibility-v0385-regression.js`.
- Regra CFG inalterada; novo CSV opcional `FORJA65_OBJ_SLOTS_PATH` traz pixels opacos por slot OAM, posições e limites.
- No caso DKC3, a série completa de 14.050 frames foi testada separadamente na v0.30, em Linux. O código do Forja65 continua genérico e não presume sprites de personagens.
- Não há validação do compilador Windows no presente pacote.
