# Scooby v0.13 crossfeed for Forja65
- Deterministic C++ replay completed 6,000 frames and matches previous 5,000 frame baseline exactly (framebuffer, WRAM, PC).
- Generic replay prefix verifier: `tools/replay-prefix-audit.js`, regression `tests/replay-prefix-audit-v13-regression.js`.
- A static framebuffer suffix was identified starting after frame 4952; holding LEFT after frame 5000 produces distinct images and movement.
- No changes to CPU/PPU semantics and no speculative CFG edges. See `reports/scooby-v13/RELATORIO-SCOOBY-v0.13.md`.
