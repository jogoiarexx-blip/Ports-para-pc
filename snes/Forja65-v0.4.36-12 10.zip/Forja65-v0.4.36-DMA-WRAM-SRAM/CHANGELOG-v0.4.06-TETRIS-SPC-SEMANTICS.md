# Forja65 v0.4.06 - crossfeed SPC700 do Tetris 2

- Emissao de runtime.hpp com FORJA65_SPC_SEMANTICS=corrected para operacoes memory-to-memory ADC/SBC, operandos fonte-destino e ponteiros DP de 16 bits.
- Sem alteracoes do modo legado padrao; FORJA65_SPC_TIMING=accurate permanece independente.
- Novo teste tests/tetris-spc-semantics-v0407-regression.js (fixture C++) para validar runtime recem-gerado.
- 11 testes selecionados de crossfeed Tetris passaram nesta entrega.
- O teste do Tetris recompilado passou em 19/19 casos disponiveis, 1 SKIP por ausencia dos vetores externos.
- Testes de replay de 500 quadros no Tetris estavel iguais ao Tetris v0.4.06; o modo de temporizacao ainda diverge do legado no quadro 59.

Limitacoes: o gerador NAO foi certificado contra ROMs originais de outros jogos nesta rodada. A fonte externa de equivalencia SNES e captura de PCM ainda nao foram confrontadas. Nao habilitar modo experimental universalmente por padrao.
