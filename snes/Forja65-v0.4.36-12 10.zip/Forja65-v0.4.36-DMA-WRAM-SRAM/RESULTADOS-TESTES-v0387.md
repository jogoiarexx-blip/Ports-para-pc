# Forja65 v0.3.87 — evidência de regressão

- `node tests/oam-vblank-reload-v0387-regression.js`: PASS, método presente nas duas entradas de VBlank no código C++ gerado.
- `node tests/oam-vblank-runtime-v0387-regression.js`: PASS, gerador + compilação C++ sintética com recarga e forced blank.
- `node tests/dma-forensics-v0386-regression.js`: PASS.
- `node tests/cfg-cache-compatible-v0369-regression.js`: PASS; cadeia de cache auditada por ROM.
- `python3 tests/test-ppu-vram-oam-compare-v0387.py`: 2/2 testes aprovados (memória, offsets/slots, captura ausente).
- Uso no DKC3: recompilação completa e replay 14.050 quadros; 530/530 uploads OAM com endereço inicial estável e 13.500/13.500 frames com PC/WRAM idênticos à rota conhecida.
- A comparação de capturas verifica estado bruto PPU; não substitui comparação de HDMA/timing/renderização com o SNES original.

A suíte geral de Forja65 foi interrompida antes da conclusão; somente os testes direcionados foram certificados nesta entrega.
