# Super Mario World v0.4 / Forja65 v0.4.28

A fase **Yoshi’s Island 2 abriu** em um replay iniciado com SRAM vazio. O percurso confirmado foi: titulo, Mario A vazio, um jogador, introducao com Mario e mensagem, mapa, deslocamento para a direita e entrada na fase. O teste encerrou com sucesso em 2.400 frames; a fase comecou no frame 2.191. O cronometro passou de 400 para 395. A fase nao foi concluida.

## Correcao estrutural do Forja

- O aprendizado que anteriormente falhava com 75.044 referencias e teto 65.536 agora reutiliza registros de instrucao rigorosamente identicos. Nenhuma funcao antiga e removida por essa reutilizacao. Instrucao com semantica/metadados diferentes continua distinta.
- O teto de 65.536 passa a contar **registros distintos**, e nao referencias repetidas entre raizes. O cache atual contem 97.852 referencias e 62.034 registros distintos. Esta e uma mudanca explicita na contagem do limite, nao uma promessa de reduzir todo o cache serializado ao tamanho anterior.
- Se a descoberta exceder esse teto, o gerador tenta um orcamento menor e somente aceita o resultado se os destinos pendentes estiverem decodificados. Erros de ROM/versao continuam rejeitados. A geracao recusada nao grava novos hints.
- O executor da rotina WRAM `LDA #imm8; STA abs...; RTL` agora aceita NMI/IRQ, verifica os bytes e a pilha, atende as interrupcoes nas fronteiras das instrucoes e retoma no PC exato. A rotina observada em $7F:8000 limpa as 128 posicoes de sprites. Codigo alterado durante a interrupcao e recusado. Nao foi adicionado um interpretador generico de CPU em RAM.
- O decoder de opcodes da ROM nao foi alterado. O cache v0.4.27 permanece compativel pela cadeia explicitamente auditada. As mudancas sao de cache/descoberta e execucao do padrao WRAM validado.

## Resultado do Mario

| Marco | Resultado |
|---|---|
| 180, 205 e 259 frames sem entradas | PASS; hashes de framebuffer e WRAM iguais aos marcos da v0.3 |
| Selecao de arquivos / jogador | Confirmada visualmente |
| Introducao / Mario / mensagem | Confirmada visualmente |
| Mapa e selecao Yoshi’s Island 2 | Confirmados visualmente |
| Entrada na fase | Frame 2.191, modo observado $14 |
| Replay completo | PASS, 2.400 frames, SRAM novo |

Replay: 33.152.642 instrucoes; 2.086 servicos NMI; 1.082 IRQ; forced blank=0; framebuffer `4a7a7f92e969df28`; WRAM `b6b41ec06b63f01b`. Repetido em diretorio isolado: mesmos hashes, sem arquivo de falha de CPU. A versao tem 32.312 enderecos decodificados (antes 24.921), 95 hints de runtime (antes 25), e nenhuma perda dos estados decodificados da base entregue.

## Validacao e pendencias

- Compilacao Linux com g++ C++20, objetos verificados contra as fontes e PCH do runtime; nenhum objeto divergente no teste final. CMake nao estava instalado neste ambiente; o build foi executado diretamente com g++.
- Tres novas regressoes: orcamento/cache, sufixos identicos e execucao WRAM interrompida/retomada. PASS. A ultima tambem verifica interrupcao no meio do bloco, IRQ e recusa de bytes alterados.
- Suite JS do Forja: **185 PASS / 38 falhas / 2 timeouts**, total 225. A suite geral nao esta verde. Os nomes de todas as falhas/timeouts estao em `reports/smw-v04/validation.json`. Os problemas observados na suite anterior incluem testes historicos com expectativas antigas, cache antigo recusado e testes que exigem CMake. Nao foram mascarados nem alterados para declarar sucesso.
- Testes nativos: **17 PASS / 2 falhas / 1 ignorado**. `native_migration_smoke` (codigo 5) e `obj_sprite_bank_smoke` (codigo 1) falham tambem na base original, confirmado por recompilacao separada. Equivalencia exige vetores externos e nao foi executada.
- Sem build Windows validado nesta rodada; os scripts e fontes para compilar no Windows acompanham o projeto. Nenhum `game.exe` de Windows foi inventado.
- PPU/APU virtual e dados da ROM continuam no runtime. A abertura da fase e uma prova de progresso/replay, nao de equivalencia completa com SNES nem de jogo finalizado.

Os arquivos de teste gerados, saves de QA, objetos e PCH nao acompanham os pacotes. As evidencias PNG e os resultados consolidados acompanham o Mario; o Forja recebe o resumo e as regressoes, mantendo os dois projetos separados.
