# Guia de cruzamento de ramos do Forja65

1. Em cada chat, parta do mesmo pacote Forja65 **v0.4.19-CROSSFEED-MULTIGAME** para a proxima rodada. Guarde sempre o ZIP final especifico do jogo.
2. Registre hashes das versoes de origem, os testes realizados, o numero de frames de **gameplay real** e o ultimo PC observado. Nao confunda 10.000 frames de menu com 10.000 de gameplay.
3. Ao juntar novas versoes, normalize somente a pasta raiz; compare SHA-256 de todos os caminhos. Divida em **identicos**, **adicionados**, **alteracoes independentes** e **conflitos no mesmo codigo**.
4. Faca merge de 3 vias com o **ancestral comum**, nao selecione a maior versao numerica e nao sobrescreva silenciosamente arquivos do outro jogo.
5. Para conflitos de CPU/PPU/DMA/HDMA/SPC700, preserve as implementacoes antigas em `merge-evidence` antes de adotar a solucao. Prefira comportamento generico fundamentado em testes e permita opt-in para semanticas ainda experimentais.
6. Rode os testes relevantes do projeto que originou cada melhoria, alem do conjunto global. Compile C++ do gerador e valide regressao de DKC3, Tetris, Bomberman, Scooby-Doo, Soldiers, Mario e Space Invaders com as respectivas ROMs quando disponiveis.
7. Nunca interprete teste sintetico como comprovacao de primeira fase completa ou ausencia de fallbacks. Valide execucao Windows real antes de declarar jogo 100% nativo.
8. Integre antecipadamente bugs genericos graves; use **3.000 frames** como checkpoint leve e **10.000 frames** como integracao maior, alem de marcos funcionais (entrada no jogo, primeira fase, chefe, fim).

**Trilhas de verificacao:** `merge-evidence/inputs-file-hashes.json`, `integration-decisions.json`, `original-byte-coverage.json`, `original-changes/`, `core-revisions/`, `targeted-test-results.json`.
