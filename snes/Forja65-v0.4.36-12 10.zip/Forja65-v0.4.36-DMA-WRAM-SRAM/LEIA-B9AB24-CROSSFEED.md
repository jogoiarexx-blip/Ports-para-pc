# Forja65 v0.3.96 — B9:AB24 integrado ao ZERO

O Forja65 já produziu análise ROM-bound de `B9:AB24` em `reports/validation-crossfeed-0396/bed8e7-integrated/`. Esta rodada aplicou o código gerado ao ZERO sem substituir rotinas anteriores.

Provas da aplicação em `reports/validation-crossfeed-0396/b9ab24-applied/`: 5 PCs novos, 10 linhas de dispatcher, 36 PCs anteriores preservados, 41 opcodes únicos, sem divergências estáticas. Novo teste `tests/b9ab24-applied-regression.py` impede atribuir falsamente equivalência de jogo a essa prova estrutural.

O salto observado `B9:A149 -> B9:AB24` utiliza `JMP ($0042)` e um ponteiro da RAM em runtime; não se pode inferir o destino apenas dos três bytes de instrução da ROM.

O Forja65 mantém os guardrails genéricos de ROM, dispatcher e preservação do código existente. Não foi modificado o motor genérico nesta rodada, além de novas evidências e testes.

## Replay e novo diagnóstico
O ZERO compilou e avançou de **14.451 para 14.457 frames**, mantendo o prefixo de hashes sem diferenças. A execução parou em `00:CA45` com estado `E0/M0/X0/C0` durante serviço de NMI; o endereço já tinha duas variantes para `M=1`, não `M=0`.

Novo analisador reutilizável: `tools/audit-observed-state-variants.py`. Ele confirma o fingerprint da ROM, lê o estado observado e identifica se falta o PC inteiro, uma variante E/M/X/C ou se a entrada deveria estar coberta. `tests/observed-state-variants-regression.py` cobre os casos. Não gera código nem afirma equivalência semântica.

Resultados disponíveis em `reports/validation-crossfeed-0396/b9ab24-applied/`.
