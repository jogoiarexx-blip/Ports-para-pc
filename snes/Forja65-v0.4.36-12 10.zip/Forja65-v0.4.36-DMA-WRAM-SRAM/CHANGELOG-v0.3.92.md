# Forja65 v0.3.92 — PPU, HDMA e cache de CPU

Mudanças reutilizáveis em qualquer ROM traduzida:

- RGB5: soma e metade antes de saturar; mistura desativada por janela não escurece a cor principal; clipping desativa metade; backdrop do subscreen usa COLDATA.
- HDMA direto/indireto conserva o banco durante incremento em FFFF; leitura do ponteiro indireto também respeita o limite de banco.
- Linhas OBJ reutilizam quatro bytes de planos para oito pixels: 32 → 4 leituras no tile completo. Cache local ao segmento, sem estado persistente que esconda mudanças de VRAM/OAM/CGRAM.
- Compatibilidade auditada do cache CFG: v0.3.92 → v0.3.91 → v0.3.90 → v0.3.89. Fingerprint da ROM, estados e limite de variantes continuam obrigatórios. Decodificação e emissão de CPU não foram alteradas por esta revisão do motor.
- Todo projeto C++ gerado inclui testes de RGB5, janelas, backdrop, wrap HDMA e equivalência OBJ.
- Testes de render antigos foram separados das regras corrigidas: referência BG histórica sem OBJ/color math; referência escalar sem cache com regras de cores validadas por vetores. As referências históricas continuam disponíveis.
- Metadados de versão e rótulo da interface sincronizados.

Use `node tools/test.js` para a suíte. CMake é necessário nos testes de build completo. Novos projetos registram os probes adicionais no CTest.

O DKC3 associado recebeu recompilação a partir de observações reais de CPU. Isso é aprendizado específico da ROM pelo mecanismo genérico já existente, não prova de primeira fase completa nem comparação independente com o SNES.

Resultados, falhas ambientais e evidências ficam em `reports/validation-v0392/RESULTADOS.md`.
