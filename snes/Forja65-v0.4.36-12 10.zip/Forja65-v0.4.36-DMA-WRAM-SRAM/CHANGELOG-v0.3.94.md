# Forja65 v0.3.94 — estado e continuação de callbacks

Observações FLOW agora ligam o ponto de salto indireto ao destino observado somente nos estados E/M/X/C compatíveis. Isso permite propagar os estados de saída do callback ao chamador. Observações de retorno ou de outra ROM não viram arestas de chamada; os destinos continuam sendo lidos da ROM/RAM em execução, sem fechar artificialmente o domínio do dispatcher.

Um PEA decodificado imediatamente antes de JMP indireto, contendo o endereço da instrução seguinte menos um, reconhece a continuação da chamada computada. O RTS do callback consome os dois bytes PEA no modelo da pilha, permitindo que PHP/PLP restaure o estado salvo anterior. A descoberta anterior de tabelas PEA indexadas foi mantida.

O cache revisita o chamador real de um destino pendente, preserva essa prioridade frente às cadeias descendentes de RESET e aceita metadados novos para cobertura de instruções idêntica. O cache v0.3.93 mantém seu conjunto parcial de decodificações porque os opcodes e o emissor não mudaram; os chamadores revisados e todo C++ são regenerados. Fingerprint de ROM, variantes de estado e teto de cobertura continuam verificados.

Consulte reports/validation-v0394/RESULTADOS.md para testes e o replay real no DKC3 ZERO v0.39. A primeira fase continua em validação.
