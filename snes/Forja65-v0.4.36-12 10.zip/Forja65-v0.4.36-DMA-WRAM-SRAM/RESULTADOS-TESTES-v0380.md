# Forja65 v0.3.80 — execução de validação

Suite Node original: **127 testes**, executados sequencialmente. Na primeira passagem: 123 aprovados, 4 falhas associadas à migração para a regra SNES de OBSEL (três expectativas de PPU anteriores) e ao novo predecessor do cache CFG. Após atualização mínima das quatro expectativas, cada teste reexecutado individualmente com êxito:

- `cfg-cache-compatible-v0369-regression.js`: PASS
- `ppu-bg-tile-regression.js`: PASS
- `ppu-priority-hires-v027-regression.js`: PASS (inclui geração e compilação do game sintético)
- `ppu-sprite-row-regression.js`: PASS

Novo `obj-bank-v0380-regression.js`: PASS; compilou e executou um teste C++ do **runtime gerado** para OBSEL, DMA VRAM/OAM, Y-wrap e entrada de controles (`$4219`) com press/release. `tests/smoke.js`: PASS. Assim, o conjunto de 128 casos ficou **128/128 validado pela passagem principal e pelas reexecuções direcionadas**, não por uma segunda passagem integral depois das mudanças nas expectativas.

O DKC3 com runtime 0.3.80 foi recompilado em Linux e seus CTests: **10 aprovados, 1 ignorado (vetores equivalência ausentes), 0 falhas**. Replay original da v0.24 com entrada controlada: 13.500 frames, PC=0 diferenças, WRAM=0 diferenças, framebuffer=8.531 diferenças atribuíveis ao renderizador (ainda não comprova perfeita apresentação dos Kongs).

Testes no Windows e controle físico: **não executados aqui**.
