@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul || (echo Node.js necessario. & exit /b 1)
where g++ >nul 2>nul || (echo g++ necessario. & exit /b 1)
node "tests\tetris-apu-dsp-v0405-regression.js" || goto :fail
node "tests\tetris-dma-vram-v0403-regression.js" || goto :fail
node "tests\tetris-gameplay-input-v0414-regression.js" || goto :fail
node "tests\tetris-hardware-v0397-regression.js" || goto :fail
node "tests\tetris-hdma-v0400-regression.js" || goto :fail
node "tests\tetris-obj-crossfeed-v0398-regression.js" || goto :fail
node "tests\tetris-obj-limits-v0399-regression.js" || goto :fail
node "tests\tetris-ppu-dma-v0401-regression.js" || goto :fail
node "tests\tetris-ppu-raster-v0402-regression.js" || goto :fail
node "tests\tetris-spc-cpu-poll-runs-v0410-regression.js" || goto :fail
node "tests\tetris-spc-cycles-v0406-regression.js" || goto :fail
node "tests\tetris-spc-ipl-v0408-regression.js" || goto :fail
node "tests\tetris-spc-poll-window-v0411-regression.js" || goto :fail
node "tests\tetris-spc-port-observer-v0409-regression.js" || goto :fail
node "tests\tetris-spc-register-edges-v0413-regression.js" || goto :fail
node "tests\tetris-spc-semantics-v0407-regression.js" || goto :fail
node "tests\tetris-spc-strict-v0412-regression.js" || goto :fail
node "tests\tetris-vram-access-v0404-regression.js" || goto :fail
node "tests\tetris-gameplay-wall-lock-v0418-regression.js" || goto :fail
echo 19 REGRESSOES TETRIS APROVADAS
exit /b 0
:fail
echo FALHA EM REGRESSAO.
exit /b 1
