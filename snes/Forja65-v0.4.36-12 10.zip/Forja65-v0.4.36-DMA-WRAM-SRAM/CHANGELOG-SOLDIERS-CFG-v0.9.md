# Forja65 v0.4.04 — Soldiers of Fortune v0.9 crossfeed

- Novo `tools/check-incremental-abi.py`: bloqueia reuso de objetos da tradução C++ quando a macro `FORJA65_ENABLE_TRACE`, o estado `NDEBUG`, o padrão C++ ou os bytes dos fontes/cabeçalhos reutilizados são diferentes. A execução é uma verificação necessária, não uma prova completa de ABI.
- Novo `tests/check-incremental-abi-smoke.py`: seis casos testados; inclui a divergência de macro de trace que alterava o boot de Soldiers mesmo com build/link bem-sucedidos.
- Fluxo focado existente `tools/advance-observed-target.py` foi aplicado com prova SHA256 para quatro destinos observados. Nenhum atalho da ROM foi criado no core.
- Os replays são comparados por frame e a compilação incremental usa o mesmo conjunto de defines do build de referência. A comparação determinística deve sempre preceder a validação do progresso após o alvo novo.
- PPU, DMA e áudio ainda podem permanecer virtualizados em vários projetos: integração de rotina de CPU não prova port nativo sem emulação.
