# Forja65 v0.4.20 — DSP crossfeed

- Base: Forja65 v0.4.19 Soldiers + PCM realtime v0.19.
- Alteração comum apenas no `forja65-core.js`: síntese de 8 vozes BRR com histórico de filtro corrigido, interpolação linear, ADSR/Gain dinâmicos, KOFF com liberação progressiva e ENVX atualizado.
- O gerador preserva transporte PCM WinMM/WAV, CPU, PPU, DMA, HDMA, SPC700, autojoy, tabelas de flow e crossfeeds anteriores.
- Mudança no script gerado de áudio ao vivo: host gain 100% padrão em vez de 200%, evitando amplificação inicial que pode distorcer.
- Melhorias são aplicadas apenas nos futuros projetos **gerados por este Forja**. O Tetris 2 v0.4.25 modificado diretamente vem em ZIP autônomo separado.
- Regressões: audio-realtime-crossfeed v0.19, Tetris APU/DSP v0.4.05, DSP stage1, multigame generation e nova síntese ADSR v0.20 passaram (5/5).
- Pendente: dispositivo de áudio Windows, eco, gaussiana, ruído e modulação DSP completos.
