# Forja65 v0.4.19 - CROSSFEED MULTIGAME

Este pacote compara **seis ZIPs enviados** e reune codigo e ferramentas para SNES → C++.

## Integracao funcional

- **Tetris v0.4.18**: nucleo mais recente, melhorias de SPC700/DSP, auditorias de controle, gameplay, scene timeline e trampoline indireto.
- **Scooby-Doo v0.13**: ferramentas de reproducoes, auditoria de frames, input e dispatcher; fallback comprovado por bytes de rotinas WRAM `[MVN/MVP, destino, origem, RTL]` foi reunido com o tratamento `JMP [abs]` da linha Tetris.
- **Soldiers v0.10**: diagnostico SPC circular, auto-joy de VBlank com busy + latch, comprovacao CFG multi-shard, auditorias auxiliares e relatórios; preservada semantica opt-in do Tetris nas divergencias SPC.
- **Bomberman v0.2**: leitura automatica consumindo 16 clocks seriais, seeds adicionais de caller JSL, tratamento de interrupcao de convergencia, ferramentas de checkpoint e testes.
- **Checkpoint v0.3.98**: arquivos exclusivos e todas as versoes de origem preservadas; alteracoes anteriores que conflitam com o nucleo mais novo permanecem disponiveis para auditoria.
- **Base v0.4.04-UNIFICADO-0397**: dados, scripts, exemplos, testes e relatorios historicos.

## Integridade de conteudo

- 6 ZIPs cruzados; 2.189 caminhos originais distintos (normalizada a pasta raiz).
- TODOS os conteudos originais diferentes sao verificaveis por SHA-256 e permanecem no pacote, como arquivo ativo ou historico em `merge-evidence`.
- Arquivos ativos resultam da fusao; manter historico nao significa que todos os comportamentos antigos sejam simultaneamente executados.
- As divergencias de semantica de SPC entre Soldiers e Tetris permanecem arquivadas, com preferencia pelo modo Tetris validado. Nao e corretto declarar resolvida a equivalencia ao console sem traces.

## Validacao realizada neste ambiente Linux

- `node --check` do nucleo unificado: **OK**.
- Compilacao sintatica de C++ gerado (`tests/crossfeed-multigame-generation-smoke.js`): **OK**.
- 27 testes direcionados verificados: **27 PASS** depois de adaptar 1 assercao textual antiga dos Soldiers. O teste antigo foi preservado em `merge-evidence/original-tests`.
- Um teste de serial do Bomberman foi ajustado ao latch atrasado, preservando o teste original.
- **Nao** foi validada toda a suite de mais de 200 testes, nem compilacao Windows, nem jogo SNES real ate o fim da primeira fase. Ha testes demorados (CFG/ABI) ainda nao concluidos.

## Uso

1. Extraia o ZIP para pasta com caminho curto e sem caracteres especiais, se possivel.
2. Para testar a fusao: `TESTAR-CRUZAMENTO-MULTIGAME.cmd` no Windows com Node.js, Python quando exigido por teste e g++/MSYS2.
3. Para gerar ports, use os scripts existentes, apontando para sua ROM obtida legalmente. Este e **codigo-fonte do Forja65**, nao um pacote `game.exe` final.
4. Para cruzar versoes futuras, siga `COMO-CRUZAR-PROXIMAS-VERSOES.md`.

Os ZIPs originais nao foram modificados.
