# Forja65 v0.4.19 — Soldiers of Fortune v0.11 (crossfeed)

**Base preservada:** arquivo original `Forja65-v0.4.19-CROSSFEED-MULTIGAME(1).zip` (SHA-256 `52fe7b233685f1e64a3b80d9aab43e5e01c7342fec81f572fee09184385a0c40`).

O port Soldiers v0.10 foi preservado. Destinos observados e validados contra a ROM: `C0:D8B0` (73 sites, 146 linhas de despacho), `C0:C031` (12 sites, 24 linhas), `C0:C077` (70 sites, 151 linhas). Total: **155 sites, 321 linhas de despacho**, nenhum conflito. A inclusão dos destinos não comprova gameplay.

## Reparo do integrador genérico

`tools/integrate-generated-cfg.py` recebeu opção `--source-unit` para importar novas variantes M/X/C sob filename adicional `src/forja_<entry>_<source_unit>.cpp`, sem sobrescrever a rotina existente. Sufixos são validados e funções duplicadas são recusadas. `tools/advance-observed-target.py` encaminha essa opção com o mesmo bloqueio de segurança. Resolve incompatibilidade detectada pelo teste já incluído na base v0.4.19 (`tests/missing-state-integrator-regression.py`).

Regressões verificadas: missing-state-integrator, integrate-generated-cfg, advance-observed-target, crossfeed-multigame-generation-smoke, rom-executable-hints, cfg-direct, observed-callback-state, handler-equivalence. No runtime, os 160 frames de referência coincidiram com a v0.10. Compilação de game Linux validada de forma incremental com hashes de fontes inalteradas; compilação limpa completa e MSVC ainda pendentes.

O objetivo permanece executar o World 1 integralmente e migrar, progressivamente, PPU/DMA/SPC700 e ROM runtime para fluxos nativos do PC.
