# Forja65 — Scooby-Doo Crossfeed v0.2 (2026-10-10)

- Preservado o crossfeed de execucao em RAM verificada pelo runtime e o bloqueio de hints nao-ROM.
- Adicionada ferramenta generica `tools/replay-converge.js`: executa replay deterministico, contabiliza frames e hashes, aprende apenas hints observados pelo runtime, recompila e repete ate limite explicito. Nao substitui instrucoes dinamicas por stubs.
- Novo teste `tests/replay-converge-regression.js` para estatisticas, configuracao e validacoes.
- Corrigido `tests/cfg-cache-compatible-v0369-regression.js` para testar REJEICAO estrita de uma cadeia de versoes nao auditada (0.4.04 unificado vs 0.3.97). Proibida compatibilidade artificial de caches antigos.
- Regressao da versao: 7/7 testes direcionados PASS. O codigo SNES 65816 nao foi relaxado para simular a primeira fase.
- Uso: `node tools/replay-converge.js --project CAMINHO_JOGO --build CAMINHO_BUILD --input TRACE --frames 1500 --iterations 5 --max 16384`
- Aviso: recompilacao de projetos SNES grandes e demorada; a ferramenta tem timeout configuravel (`--timeout` em milissegundos) e so marca `FRAMES_REACHED` quando o limite de frames e confirmado.
