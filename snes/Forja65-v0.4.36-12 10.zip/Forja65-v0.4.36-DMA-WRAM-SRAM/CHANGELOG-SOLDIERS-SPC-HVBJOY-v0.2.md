# Atualizacao de compatibilidade do Forja65 — Soldiers of Fortune

O Forja65 v0.4.04 UNIFICADO (0397) recebeu melhorias de uso generico, sem substituir outros ramos de desenvolvimento:

- Correcoes de semantica SPC700 em seis operacoes de ADC/SBC com destino de memoria, flags e decodificacao de operandos, mais AND1 invertido.
- Bounded SPC700 instruction history (512 entradas opt-in); snapshot de boot e falha.
- Trampolim de interrupcao 65C816 JMP [abs] que encaminha alvos dinamicos ao dispatcher AOT.
- Registro HVBJOY $4212 auto joypad busy durante uma janela de 4224 master cycles. O tempo de inicio foi fixado em aproximadamente 300 master cycles no inicio do VBlank, e ainda requer confronto com a variacao real de fase do SNES.
- Aprendizado de CFG real dos estados de NMI e rotinas do jogo; aprendizado pode ser repetido para outros ROMs usando o comando learn-crash.

Verificar com os testes em `tests/soldiers-spc-hvbjoy-v0404-regression.js` e nos pacotes de conversao gerados. Avanco verificado ate o menu de modo de jogo; nao interpretar como execucao integral do jogo.

Fontes de referencia de hardware: https://snes.nesdev.org/wiki/MMIO_registers e https://wiki.superfamicom.org/timing
