# Forja65 v0.3.73

Acrescenta `FORJA65_FAST_SHARDS`, opcao de CMake para compilar apenas um ou mais shards `generated_NNN.cpp` com menor otimizacao enquanto o restante permanece otimizado. O codigo traduzido e as verificacoes de pilha/CFG nao mudam. A opcao e desativada por padrao. Testes: ver TESTS-v0373.md.
