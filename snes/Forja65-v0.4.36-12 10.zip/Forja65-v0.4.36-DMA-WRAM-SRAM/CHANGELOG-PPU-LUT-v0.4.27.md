# Forja65 v0.4.27 - conversao de cor da PPU

Atualizacao do template C++ gerado pela funcao `runtimeHpp()`. A LUT 16x32 aplica a mesma escala RGB555/brightness do caminho anterior, eliminando divisoes repetidas na composicao de pixels.

Teste: `node tests/ppu-brightness-lut-v027-regression.js`.

Nada alterado nos codecs CPU/CFG, SPC700, DSP, DMA, Soldiers nem no jogo Tetris independente.
