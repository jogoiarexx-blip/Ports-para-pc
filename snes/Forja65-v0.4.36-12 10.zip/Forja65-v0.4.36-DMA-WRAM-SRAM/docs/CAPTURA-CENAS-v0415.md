# Captura de multiplas cenas nativas — Forja65 v0.4.14

Defina `FORJA65_HEADLESS=1`, `FORJA65_INPUT_REPLAY=...`, `FORJA65_CAPTURE_FRAMES=425,485,1200,1750` e `FORJA65_CAPTURE_DIR=...`. Execute uma unica vez o jogo; cada quadro programado tera pasta `frame-N/`, com `preview.ppm`, `capture-manifest.txt`, VRAM, OAM, CGRAM e arquivos de camadas. `FORJA65_CAPTURE_STOP=1` para apos a ultima captura.

A lista deve ser decimal, positiva, crescente, sem duplicatas e com no maximo 32 quadros; entradas invalidas interrompem com erro. O comando antigo `FORJA65_CAPTURE_FRAME=N` permanece compativel, mas nao use os dois juntos.

Essa ferramenta coleta evidencias de imagem e estado da PPU; **nao** afirma que uma fase foi vencida ou que os pixels estao identicos a um SNES original.
