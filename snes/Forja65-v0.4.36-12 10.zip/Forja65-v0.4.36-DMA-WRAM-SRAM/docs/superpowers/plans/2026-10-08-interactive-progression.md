# Interactive progression plan

Goal: advance the original DKC3 ROM from title through save selection, map and first level.
Architecture: ROM-bound CFG regeneration and deterministic controller replay; preserve cached translation and stack-return validation. No state or screen injection.
Tech stack: JavaScript Forja65, generated C++20, CMake/GCC, ROM and real scene exports.
Spec: DKC3 ZERO README-v019.md and user direction of 2026-10-08.

- [x] Read current reports and reproduce unincorporated 80A177 hint.
- [x] Add failing bounded-budget regression showing cached hints starving the new target.
- [x] Prioritize uncovered observed CPU states; preserve predecessor cache and all previous instruction variants.
- [x] Build port, run Start replay, learn real observed hints and inspect save/name scenes.
- [x] Extend input replay through save slot selection and DIXIE name confirmation.
- [ ] Validate map and first level entry with original ROM execution.
- [x] Run full Forja65 suite (124/124) and generated-port CTest (9 PASS, 1 SKIP), preserve ROM/hooks/input semantics.
- [x] Repeat generated-port verification after final learned CFG update: complete build, 193/193 static hints, 9 PASS / 1 SKIP CTest with inherited tracing.
- [x] Document actual milestones and remaining blocker (B4BC16 -> B4CB2E at frame 3465), package updated versions.

Review focus: widths/carry at a cached address; unknown carry versus known carry; RESET retention; fingerprint/version mismatch fail-closed; computed returns require actual matching stack evidence.

- [x] Fix PPU stream ownership, run isolation and inherited CTest tracing.
- [x] Preserve Windows executable and assets before CTest, including quality build.

Delivery requested explicitly by user (termina). Map and first level remain unverified; record the final replay blocker without fabricating closure.
