# Ledger — pending-flow-peer-frontier

Workspace: isolated archive extraction in this conversation; no repository branch is involved.
Authorization: user said “proxima”; continue implementation without a plan approval pause.
Evidence: B9E375 observation predicts 11 peers but C.analyze(...,8192) visits none before descendant chains exhaust the budget.
RED: pending-flow-peer-budget-v0377-regression.js fails on missing sibling 008320.
Scope: scheduler ordering only. No CPU/PPU opcode, emission, ROM, native hook or stack authorization changes.

GREEN: new regression passes; removing cached-peer promotion fails the promotion scenario. Independent reviewer found an equal-priority CACHED-CALL prefix defect. Added discoverySeeds regression: RED then GREEN with distinct peer priority. Final read-only reviewer approves code scope; seven focused regressions pass.
Real isolated table: unchanged inference predicts11 candidates; v0.3.76 visits zero literal alternative entries under8192, v0.3.77 visits all ten alternatives. The eleventh inference is outside the literal eleven-entry table; no semantic/execution claim is made.
Full suite first attempt exposed a hard-coded predecessor in convergence-metadata test. Updated immediate predecessor expectation; restart after final scheduling fix.

Final-core generation/build: all C++ targets compiled on Linux/GCC. Guarded learning accepted8 new hint keys (205->213). Runtime replay from RESET reaches3526, then unresolved STACK-RTL BBB8EB->B68061 E0M0X0C0; final evidence remains pending. Static state-aware dispatch audit213/213 PASS.
CTest9 PASS/1 SKIP/0 FAIL; vectors skip: no supplied oracle vectors. Title1400 hashdb6735d05cfb3359 preserved. Post-save test3466 PASS, save3350 hash74af7db43797c0a6 preserved.
Extended hash log is incomplete; separate final-core3489-frame PASS replay logs all3489 and matches all3488 v0.21 pre-blocker framebuffer/WRAM/PC hashes. No full-game equivalence or map claim.

Final full suite125/125 PASS, exit0. Synchronous execution record is authoritative; raw stdout transcript is incomplete. Reconstructed result list is explicitly labeled.
