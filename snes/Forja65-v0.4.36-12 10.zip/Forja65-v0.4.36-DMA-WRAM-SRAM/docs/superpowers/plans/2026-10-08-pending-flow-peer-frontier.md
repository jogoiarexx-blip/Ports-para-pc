# Pending FLOW peer frontier implementation plan

> **For agentic workers:** Use superpowers:executing-plans for this authorized continuation; apply TDD and one independent final review.

**Goal:** Resolve B9E349 -> B9E395 and prevent long call descendants from starving plausible siblings of the same newly observed ROM table.
**Architecture:** Prioritize RESET, uncovered observations, then FLOW peers tied to those observations. Promote a peer already queued by a cached hint. Keep cached peers behind reachable calls. The ROM decoder, emitter, stack evidence guard, and monotonic cache remain unchanged.
**Tech Stack:** Node.js analyzer and generated C++20 runtime.
**Spec:** Current reproduced trace at frame 3488; `reports/evidence/v021/final` in the DKC3 package.

## Global constraints
- Analyze real ROM bytes; do not inject state or framebuffer.
- Preserve every previously decoded address/state and exact ROM fingerprint binding.
- Keep RESET and actually observed destinations ahead of speculative peers.
- Preserve repeated-filler and stack-return guards.
- Use the submitted branch (Forja65 0.3.76 + DKC3 ZERO 0.21), not another conversation's packages.

## Review focus
- Peer queued by an older covered hint must be promoted when the same table is live again.
- A pending observation must retain priority over a speculative peer.
- Cached peers must not starve newly reachable direct calls.
- CPU width/carry variants must remain distinct.
- Speculative candidates must never be reported as executed or semantically proven.

### Task 1: Discovery scheduling
**Files:** `forja65-core.js`, `tools/project-io.js` (version compatibility only), `tests/pending-flow-peer-budget-v0377-regression.js`, `tests/cfg-cache-compatible-v0369-regression.js`.
- [x] Write real analyzer/generation regression with a hand-authored five-entry ROM table and long descendant.
- [x] RED: run regression; fails because sibling 008320 is not discovered.
- [x] Tag/preserve priority of pending FLOW peers and insert descendants after this frontier.
- [x] Run new regression and existing priority/cache/stack regressions; full suite must exit 0.
- [x] Validate real ROM table and replay from RESET; retain fresh failure evidence if progression stops.
- [x] Independent whole-change review; resolve substantive findings with regression evidence.

### Task 2: Delivery
- [x] Build all C++ targets and run CTest, title/save regressions and deterministic prefix comparison.
- [ ] Document actual progression and pending blocker; refresh manifests and validate archives.
- [ ] Save updated compiler and game packages preserving their identities.
