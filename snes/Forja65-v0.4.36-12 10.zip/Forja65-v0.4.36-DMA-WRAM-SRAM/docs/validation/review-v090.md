# v090 read-only review

Compared dkc389 → dkc390 and forja357 → forja358, concentrating on the four new callbacks, original ROM workbench spans, proof guards, and cursor evidence.

## Important: B9B3D2 caches values across aliasing writes

`src/core/RomAnimationCallbacks.cpp:105–112` snapshots `$7E` and `$72` before writing `owner+$08`. Original B8E198 rereads `$7E`, reloads `$72` before its second store, and B7D7FB rereads `$7E` for display selection. The accepted contract permits low-WRAM owners whose writes overlap these globals.

Confirmed against the fresh `builds/dkc-v090/libdkc3_animation_oracle.so`: command0 at cursor `$2000`, sprite base `$0878`, zero sprite, `$72=$0076`, `$7E=$023C`, `$7C=1`, descriptor pointer `$FF0000`. Original and native both accept without ROM guard rejection. First descriptor write replaces `$7E` with `$7499`; original second descriptor writes `$C4C0` at `$0080`, native writes `$76BB`. Display differences occur at `$0484/$0485/$0488/$04A7/$04A9/$04AD/$04B1`. This is an actual semantic mismatch, not merely missing coverage.

Fix by preserving original read/write order and rereading live globals for each helper and display selection; alternatively explicitly reject all affected aliases transactionally. Add original comparison fixtures for `$72=$0076` (animal), `$006A` (owner), `$0062` (descriptor pointer), and `$0074` (selection flag). Initial fixtures only exercised ordinary/shared/sprite/window-edge owners and missed these aliases. Parent was notified immediately. The subsequent source fix now reads each descriptor before fetching its live owner, rereads animal/selection inputs between the two helper stores, rereads animal after the byte store at $0473, and preserves the second helper owner as Y residue. This matches the reviewed original helper order. Expanded original fixtures cover all four aliases and independently reproduced a red mismatch before this fix. Fresh rebuilt proof verification remains with the parent task.

## Checks and remaining limits

- RNG callbacks match reviewed B6B4/B6DC byte semantics, including saved cursor +3 wrap and second-ASL carry into the multiply ADC. Accepted original branch-PC counters are stronger than fixture labels alone.
- B08A preserves the workbench's sequential position/flag writes and continuation choice; no additional mismatch found in inspected alias ordering.
- FD tables are ROM-backed, with whole-bank FD fingerprints; indirect descriptor reads remain FF-only in C++ and the oracle's B7/F7 pointer guard. No FD-bank broadening of indirect descriptors found.
- The new Forja cursor partition validates unique effects, positive integer counts, exact effect-set agreement, original dependency execution, and total-case agreement. `node tests/cursor-effects-v0358-regression.js` passes. The parent subsequently added a malformed-evidence and accepted-evidence regression through the specialization path; the targeted test passed. The full Forja rerun is recorded separately.
- BA29 remains absent from the translated callback switch. Do not promote command0: complete target-domain equivalence remains unproven, preserving the requested 22/25 boundary.

Assessment: the source fix resolves the identified read-order defect on inspection; rerun the fresh composed original proof before delivery. Other builds, regenerated proof artifacts, integration tests, and version checks are owned by the parent task and were not duplicated by this review.

Parent verification after recompilation: full original proof generator exited0, preserving22 handlers and validating113 original callbacks with31,383 accepted comparisons, including the new alias corpus. Native release-suite evidence is packaged separately.
