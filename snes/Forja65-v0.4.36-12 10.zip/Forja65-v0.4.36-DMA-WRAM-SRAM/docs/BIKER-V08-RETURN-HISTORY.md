# Biker v0.8: evitar contaminacao historica dos retornos

**Reproducao:** no frame 6126, `learn-crash` rejeitou `STACK-RTS $83:A12E -> $83:A25C` como sem prova. O registro ja estava incorporado e provado em uma rodada anterior, mas o runtime acumulou `forja65-runtime-hints.txt` entre os replays, enquanto o arquivo de retornos atuais era limpo.

**Corrigido:** (1) a verificacao de pilha compara a tupla ROM/origem/destino/tipo/estado com hints persistidos anteriormente; apenas retornos *novos* exigem uma observacao de pilha na rodada corrente; enderecos e opcodes sao checados mesmo nos registros historicos; (2) o runner limpa ambos os arquivos temporarios de hints e retornos antes de cada nova tentativa, **depois** do prelearn; (3) cada replay preserva seus proprios dados brutos no relatorio.

Seguranca: nenhum retorno novo e aceito sem a prova de pilha e a checagem de opcode. Nao existe fallback interpretado oculto nem bypass de guardas.

Teste: `node tests/observed-stack-return-v0367-regression.js`; `node tests/replay-converge-regression.js`.
