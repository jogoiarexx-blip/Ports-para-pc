# Forja65 v0.3.44 — dependency-closed semantic cutover

The cross-project path now validates more than the handler span. A handler may depend on native semantic ABIs outside the dispatch table; those dependencies must carry their own PASS, ROM-bound proof before the handler can become `equivalence_proven`.

For the current DKC3 `$B9A157` plan: 27 routes, 25 unique handlers, 20 translation candidates, 5 CFG fallback handlers and **2 equivalence-proven handlers**. `$B9A589` is the first dependency-composed cutover: it depends on a separately proven `$BB8591` sprite teardown ABI.
