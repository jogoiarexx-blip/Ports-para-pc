# Forja65 v0.3.49 — Callback Family Equivalence

- `native-dispatch` aceita provas semanticas `scope: callback-abi` vinculadas ao fingerprint da ROM e ao fingerprint do span exato do callback.
- `dispatch.contexts[].resolution.target_hits` preserva impacto estatico por target dentro de cada raiz contextual.
- O plano gera `callback_cutover` com total de callbacks, provas aprovadas, hits estruturais nativos e cobertura por contexto.
- O C++ gerado inclui `NativeCallbackStatus` por target; callback nao provado permanece em fallback mesmo quando o wrapper/CFG do comando ja esta fechado.
- Provas de callback reutilizam as salvaguardas de continuacao e shared-state: RAM correta com retorno incorreto, ou shared-state incompleto, nao autoriza cutover.
- A cobertura estrutural do dispatcher ganhou `native_plus_callback_hits/fraction`, evitando contar todo o comando 3/4 como nativo quando apenas parte dos callbacks foi comprovada.
- No crossfeed DKC3 atual: **14/118 callbacks**, **470/1.490 hits de callback** e **5.842/7.709 hits estaticos efetivamente nativos** quando combinados com os 15 handlers inteiros equivalentes.

As contagens de hits sao ocorrencias no corpus estatico auditado, nao frequencia de execucao em runtime e nao porcentagem do jogo inteiro.
