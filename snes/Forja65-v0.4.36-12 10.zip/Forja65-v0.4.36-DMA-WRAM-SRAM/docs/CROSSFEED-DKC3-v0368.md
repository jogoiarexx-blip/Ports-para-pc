# DKC3 — Cruzamento auditado Native v0.93 × ZERO v0.12

**ROM:** SHA256 `2277a2d8dddb01fe5cb0ae9a0fa225d42b3a11adccaeafa18e3c339b3794a32b`; fingerprint Forja `3a574807afbad761`. Os arquivos são byte a byte equivalentes.

## Resultados

- O pacote Native informa 22/25 handlers completos, 126 destinos originais sob guards e 48 dependências sem prova; essas métricas pertencem ao domínio da animação, não ao FPS ou à execução do ZERO.
- O DKC3 ZERO v0.12 comprovou 300 frames headless, mas não a abertura visual. Seu relatório de 600 frames parou em `B9A20F → B9B90D`.
- O destino `B9B90D` está no conjunto dos **111 callbacks do comando 3** do corpus da ROM e no domínio de despacho `B9A20F` do Native.
- **Prova semântica específica de `B9B90D`:** status `equivalent`, escopo `callback-abi`, **12 casos**. A prova exclui resíduos de flags/registradores no retorno RTS e partes externas à ABI declarada. Não usar como equivalência de CPU completa.
- Há **63 registros** de hints na v0.12, com **63 destinos distintos**. O último erro ainda não está nessa lista.
- **Estado E/M/X/C do último erro não aparece em `v012-test600.log`.** Não criar hint dinâmico artificial até obter esse estado do runtime.

## Cruzamento dos bloqueios anteriores do chat

- `B28030 → B28273`: conhecimento nativo=True; prova semântica própria=False
- `B28036 → B282FD`: conhecimento nativo=True; prova semântica própria=False
- `B28033 → B282E5`: conhecimento nativo=True; prova semântica própria=False
- `B28046 → B2847E`: conhecimento nativo=True; prova semântica própria=False
- `0082CF → 00BBA6`: conhecimento nativo=False; prova semântica própria=False

## Transferência segura

1. Usar `forja65-knowledge.json` e `animation-callback-domain.json` como **conhecimento estático** vinculado à ROM.
2. Usar `animation-handler-equivalence.json` apenas em `native-dispatch`, obedecendo dependências, fingerprints e `required_runtime_guards`.
3. No ZERO, manter a execução via RESET e registrar o estado da CPU no próximo crash para liberar `B9B90D` com evidência de execução.
4. Medir VRAM/CGRAM/OAM, brilho e camadas entre frames 130 e 300; os frames capturados continuam quase pretos.
5. Evitar copiar o menu C++ do Native como prova de execução do menu original da ROM; ele pode ser útil em um modo separado de testes visuais.

## Distinções importantes

- **22/25 handlers**: provas da máquina de comandos de animação do Native, não são 22/25 instruções 65C816.
- **126 callbacks**: destinos validados sob seus guardas; não há garantia de execução incondicional.
- **7.703 endereços**: cobertura decodificada pelo ZERO; não equivale a 7.703 callbacks validados.
- **300 frames**: teste headless encerrado normalmente; não significa 300 quadros com imagem útil.
- **BA29** pendente no Native não foi automaticamente corrigido pelos retornos observados no ZERO; exigiria comparação de pilha, ABI e pós-condições.

Nenhuma alteração de comportamento do jogo é afirmada neste relatório; é uma transferência de evidência auditada.
