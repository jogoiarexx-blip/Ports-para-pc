# Status v0.3.49

Esta versao move o crossfeed de callbacks de apenas **dominio estrutural conhecido** para **cutover semantico seletivo por target**.

No DKC3 de referencia:

- dominio estrutural dos comandos 3/4: 118 callbacks (111 cmd3, 7 cmd4), 1.490 hits estaticos;
- callbacks com `callback-abi` comprovado: **14/118**;
- hits seletivamente nativos dentro de cmd3/4: **470/1.490 = 31,54%**;
- handlers inteiros equivalentes permanecem **15/25**, cobrindo 5.372/7.709 hits;
- cobertura estatica efetivamente nativa combinada: **5.842/7.709 = 75,78%**;
- cobertura estrutural candidata permanece 7.205/7.709 = 93,46%.

Comandos 3/4 nao sao declarados inteiramente equivalentes: cada callback nao provado continua no fallback.

## Regressao focal

Foram aprovadas 9 regressões focais cobrindo callback-family equivalence, contextual callback domain, shared-state, multi-exit, batch impact, handler/dependency equivalence, native dispatch, script-domain e focused crossfeed. O `bundle-core` foi regenerado e a regressao v0.3.49 foi repetida apos a geracao.
