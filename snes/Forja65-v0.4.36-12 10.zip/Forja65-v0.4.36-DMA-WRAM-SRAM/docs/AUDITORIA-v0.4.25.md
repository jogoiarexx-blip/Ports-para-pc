# Auditoria e decisão técnica — Forja65 v0.4.25

Data: 2026-10-12. Base exclusiva: Forja65-v0.4.24-DSP-KEY-TIMING.zip.
Inventário completo de bytes e SHA256: reports/validation-v0425/base-inventory.json.
A leitura aprofundada concentrou-se no gerador, runtime APU/DSP, ferramentas de
convergência, transporte PCM e testes; não equivale a uma revisão linha a linha
independente de todos os arquivos e projetos históricos.

## Arquitetura existente

- forja65-core.js: biblioteca JS/VM/browser, carregamento e mapeamento de ROM,
  análise 65816 com estados E/M/X/C, CFG e inferência de tabelas/retornos;
  gerador de C++ com runtime de hardware e shards estáveis de tradução.
- analysis/native-map.js e native/templates.js: análise de evidências e templates
  incorporados no bundle do core; não são uma segunda implementação do DSP.
- tools/forja65.js e project-io.js: geração/atualização de projetos, caches de CFG,
  hints vinculados à ROM, convergência e diagnóstico. tools/test.js executa
  somente os .js diretamente em tests, omitindo Python e tests/tools.
- Forja65-Portable.html carrega o core por script externo. Interface Edge no
  Windows. Nenhum frontend de emulador externo foi acrescentado.
- C++ gerado: dispatch por endereço/estado, fallback/oráculo de diagnóstico,
  runtime PPU, DMA/HDMA, APU com interpretador SPC700 e hook de código SPC AOT.
- PPU: composição BG/OBJ, modes 0–7, janelas/color math, raster por segmentos,
  captura de frames/OAM/proveniência e comparação; cobertura sintética existente
  não comprova fidelidade de todos os jogos.
- Dependências: Node CLI, Python para ferramentas, C++20/GCC ou MSVC e CMake
  nos scripts de build. Win32/WinMM/XInput no Windows; PCM 32 kHz stereo,
  12 blocos de 512 frames, ganho e WAV em streaming. Navegador para interface.

## Histórico v0.4.19–v0.4.24 lido

19: transporte PCM WinMM/WAV, captura em memória opt-in.
20: BRR/histórico, interpolação linear, envelopes ADSR/GAIN e release KOFF.
21: NON, PMON, eco/FIR e gate para escrita de echo RAM.
22: gaussiana de 512 coeficientes e retorno linear.
23: counter global de envelopes, offsets e retorno legacy.
24: KON/KOFF de duas amostras, início de cinco amostras, ENDX diferido e legacy.
Todos esses caminhos são preservados nesta rodada.
VERSION e VERSION.txt ainda anunciavam v0.4.22: agora coincidem com o core.

## Gargalo comprovado corrigido

BRR range 0/nibble F/histórico zero: primeiro PCM esperado -2, observado 0.
A divisão inteira C++ truncava um número negativo ímpar para zero.
Com range 12/filter 1/nibble 7 e histórico PCM 32766/32766: o accumulator
atinge 29695. O resultado após duplicação e wrap é -6146; a saturação prematura
em 15 bits da base resulta em 32766. Esse histórico errado contamina amostras
subsequentes. Os filtros em si são preservados com sua representação half-PCM.
A correção é genérica e não modifica nenhum port individual.

## Referências e decisão de integração

SPC_DSP.cpp de Snes9x/snes_spc (Shay Green, LGPL-2.1-or-later), consultado em:
https://github.com/snes9xgit/snes9x/blob/master/apu/bapu/dsp/SPC_DSP.cpp
O estágio BRR confirma shift aritmético, saturação de 16 bits, duplicação e wrap.
Foi implementada uma mudança local e um modelo numérico Python independente;
nenhum arquivo ou função externa foi incorporado ou ligado ao produto.
Isso não é execução diferencial do emulador de referência inteiro.
Tentativas de acesso ao BRR do ares e à documentação nesdev não forneceram
conteúdo útil nesta execução; não são tratadas como validação.
Proveniência da gaussiana anterior permanece em DSP-GAUSSIAN-PROVENANCE.txt.

Ferramentas estudadas por documentação primária, sem integrar código:
- SNESRecomp (sp00nznet): CPU nativa, dispatch de funções e hardware/APU
  separado. O princípio de separar código recompilado e hardware já existe
  no Forja; trocar o backend nesta rodada seria uma alteração arquitetural.
  https://github.com/sp00nznet/snesrecomp/blob/main/README.md
- DiztinGUIsh: trace/CDL e estados dinâmicos ajudam a separar código/dados e
  evitar desync por M/X. Já existem hints/knowledge packs no Forja; a próxima
  integração deve importar evidência vinculada à ROM. GPL-3.0, sem cópia.
  https://github.com/DizTools/DiztinGUIsh
- ghidra-snes: loader, especificação 65816, MMIO e bancos canônicos; potencial
  exportador de símbolos/entradas para knowledge packs. MIT, sem cópia.
  https://github.com/joshleaves/ghidra-snes
Estas observações são estudo documental, não benchmarks ou integração executada.

## Limitações existentes e próximos gargalos

ApuBridge executa o orçamento SPC inteiro antes de sintetizar o bloco DSP do
mesmo tickMasterCycles: escritas DSP dentro do intervalo podem ser observadas
com ordem temporal dependente do tamanho do tick. Primeiro alvo da próxima
rodada: reproduzir uma sequência SPC→DSP em fatias diferentes e intercalar
amostras no instante correto, preservando os modos de diagnóstico.
O clock DSP usa 671 master cycles por sample, não o racional SPC/32; a próxima
correção de scheduling deve medir também essa deriva.
SPC accurate timing, corrected semantics, strict scheduling e rational clock
continuam opt-in; a simples presença dos 256 cases não comprova semântica.
Noise ainda usa counter privado; mixer/echo têm aproximações de ganho,
arredondamento e pipeline. BRR é decodificado em blocos inteiros, não no
pipeline de quatro amostras do console. A correção numérica não resolve isso.
Não ajustar todos esses sistemas sem reproduções e regressões separadas.

## Dados reais e multigame

O inventário contém duas ROMs sintéticas e projetos/hints/relatórios históricos,
mas nenhum .spc, .smc ou ROM comercial .sfc disponível para novo replay real.
Tetris, Bomberman 2, Soldiers, Scooby e DKC3: evidências históricas permanecem;
nenhum gameplay, fase concluída ou PCM comercial foi revalidado nesta rodada.
Testes com nomes de jogos usam fixtures e não substituem execução do jogo.
Código/dados em examples, profiles e merge-evidence não devem ser alterados.

## Plano executado

1. Inventariar ZIP, ler changelogs e núcleo e reproduzir o primeiro PCM incorreto.
2. Criar oracle full-PCM independente e teste C++ gerado que falha na base.
3. Corrigir aritmética BRR e preservar FORJA65_DSP_BRR=legacy;
   manter KEY/ENVELOPE/INTERPOLATION legacy existentes.
4. Permitir cache CFG da predecessora imediata v0.4.24, pois esta alteração
   não muda análise CPU/CFG; C++ sempre regenerado. Não liberar caches mais
   antigos sem auditar todas as transições.
5. Comparar suítes em extrações isoladas, documentar falhas antigas e novas,
   preservar os ports/históricos, recalcular manifests e verificar ZIP.
