# Status v0.3.52

O Forja65 fecha seletivamente folhas externas atrás de uma `dependency-boundary` sem misturar roteamento com equivalência semântica. O ranking externo é validado contra a rota callback/accumulator já provada e contra o próprio proof `external-leaf-abi`.

No DKC3 atual existem 97 folhas B5/B6 auditadas, 368 hits estruturais e 340 sites únicos. O primeiro lote autoriza 27 folhas e 110 hits (29,9% da boundary); 70 folhas / 258 hits permanecem fallback.
