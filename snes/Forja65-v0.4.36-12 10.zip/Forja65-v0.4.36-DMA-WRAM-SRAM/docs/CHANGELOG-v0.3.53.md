# Forja65 v0.3.53 — External Leaf Family Inventory

- adiciona `handler_inventory` com contagem separada de command handlers, callback handlers e external-leaf handlers;
- adiciona `external_leaf_cutover.family_summary`, agrupando folhas, hits nativos e fallback por familia;
- mostra `semantic units` no resumo do CLI sem confundir essa soma com handlers unicos do dispatcher;
- adiciona regressao de inventario/familia;
- valida o segundo lote do DKC3: 37/97 folhas e 127/368 hits nativos.
