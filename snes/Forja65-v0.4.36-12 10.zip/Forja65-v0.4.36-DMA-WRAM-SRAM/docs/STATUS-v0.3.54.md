# Status v0.3.54

O `native-dispatch` agora transforma o ranking de folhas externas em fila de trabalho direta: `external_leaf_cutover.next_unproven_leaves` ordena os alvos ainda sem equivalencia por hits estruturais, sem misturar prioridade com permissao de cutover.

No DKC3 atual:
- handlers de comando: 15/25 semanticamente provados;
- callbacks: 35/118 semanticamente provados, com 2 boundaries externas;
- folhas externas B5/B6: 39/97 semanticamente provadas;
- unidades semanticas: 89/240 provadas;
- boundary externa: 162/368 hits nativos (44,0%), 206 hits ainda fallback;
- cobertura estatica efetiva: 6.082/7.709 hits (78,9%).

A fila restante comeca por `$B6:F9EF` (42 hits), seguida por `$B6:FA7E` (20), `$B6:FA90` (12), `$B6:F8CB` e `$B6:FACD` (10 cada).

## Validacao desta revisao

- `external-leaf-impact-v0352-regression.js`: PASS.
- `external-leaf-family-inventory-v0353-regression.js`: PASS.
- `native-dispatch-plan-v0342-regression.js`: PASS.
- `smoke.js`: PASS.
- A agregacao completa `node tools/test.js` nao termina neste ambiente: apos os cinco primeiros testes PASS, `busy-loop-interrupt-regression.js` permanece executando e foi encerrado por timeout. Este teste nao foi alterado pelo cutover de folhas externas.
