# Forja65 v0.3.50 — Dependency Postcondition Equivalence

- `forja65.handler-equivalence.v1` agora aceita `contract.postconditions` e exige correspondência exata em `verification.postconditions` para provas `equivalent`.
- Dependências podem declarar `required_postconditions`; `dependency_closure_proven` só fecha quando a dependência equivalente possui essas pós-condições ROM-bound verificadas.
- O plano `native-dispatch` preserva `postconditions`, `postconditions_verified` e o resultado da validação por dependência.
- Isso permite composição segura de callbacks que dependem de registradores preservados/retornados, sem inferir ABI apenas a partir de efeitos de memória.
- Crossfeed DKC3 de referência: **35/118 callbacks**, **548/1.490 hits de callback**, **5.920/7.709 hits estáticos combinados = 76,79%**.

Os hits continuam sendo ocorrências no corpus estático auditado; não representam frequência de runtime nem porcentagem do jogo inteiro.
