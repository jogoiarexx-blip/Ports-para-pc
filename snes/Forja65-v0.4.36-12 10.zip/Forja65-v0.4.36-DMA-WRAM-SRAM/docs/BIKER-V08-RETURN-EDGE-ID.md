# Biker v0.8: discriminacao de retornos em convergencia

**Falha encontrada:** replay-converge.js deduzia o erro de retorno apenas pela mensagem C++ generica. Dois STACK-RTS diferentes no mesmo frame tinham a mesma chave `RETURN:retorno 65C816...`, podendo interromper a descoberta como falsa estagnacao.

**Correcao:** a chave agora contem `RETURN:<kind>:<source>:<target>` obtida de `forja65-unresolved-returns.txt` do *mesmo* replay. O arquivo anterior e removido somente antes do replay novo, depois da etapa de prelearn, mantendo as evidencias da tentativa atual para `learn-crash`. Se faltar evidência, retorna `RETURN:UNKNOWN`, sem autorizar novo codigo.

**Seguranca:** sem bypass de CPU ou de stack guards; continuamos exigindo verificacao ROM e pilha antes de incorporar destinos ao C++ gerado.

**Teste:** `node tests/replay-converge-regression.js`.
