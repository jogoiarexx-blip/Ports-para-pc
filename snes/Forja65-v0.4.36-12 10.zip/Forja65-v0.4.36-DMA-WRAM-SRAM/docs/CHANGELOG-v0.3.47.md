# Forja65 v0.3.47 — Shared-State Equivalence

- Handler-equivalence proofs may declare `contract.shared_state`.
- PASS verification must report the exact same normalized set in `verification.shared_state`; mismatch fails closed.
- Native-dispatch plans preserve `shared_state` and `shared_state_verified` per handler.
- This closes false-positive cutovers where local sprite/RAM state matched but linked-sprite or global WRAM side effects were omitted.
- DKC3 crossfeed validation promotes commands 21-24 only after both multi-exit and shared-state ABIs validate.
