# Forja65 v0.3.68 — integração de duas linhas

Base: v0.3.67 (CFG monotônico, RESET, shards de C++, RTS/RTL observado, PPU com brilho).  
Portado da ramificação v0.3.60 GUARDED: prova de destinos indiretos inlined, rejeições atômicas dos guards, propagação transitiva de `required_runtime_guards`, fronteiras de dependência e proibição de promoção irrestrita de handler.  

**Não** foi substituído o gerador atual pelo mais antigo. Os blocos de prova foram transpostos seletivamente; regressões do CFG e PPU foram preservadas. A compatibilidade do cache aceita a antecessora exata 0.3.67 somente porque o parser do CFG não foi alterado por esses blocos de prova.

Validação: `node tests/guarded-inline-domain-v0360-regression.js` mais testes específicos 0359/0355/0348/0364/0363/0365/0367. Plano `native-dispatch` gerado com as provas e conhecimento da ROM v0.93, mantendo 22/25 handlers equivalentes.

Limitação: **não houve reteste do binário DKC3 ZERO v0.12 com este núcleo combinado**, nem validação nova de imagem de abertura. Provas guardadas em Native não autorizam seus equivalentes para estados sem guard. Não misturar contagens de provas nativas com contagem CFG.
