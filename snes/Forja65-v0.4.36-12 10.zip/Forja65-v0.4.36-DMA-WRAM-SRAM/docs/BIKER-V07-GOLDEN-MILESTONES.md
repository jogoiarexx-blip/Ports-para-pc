# Reproducible CFG regression guard (Biker crossfeed v0.7)

`tools/replay-converge.js` now accepts `--baseline-milestones PATH`, a ROM-bound JSON file with `schema: forja65.milestones.v1`, `rom` equal to the project's ROM fingerprint, and `milestones` indexed by completed frame count. Each milestone requires `framebuffer` and `wram` hash strings.

After **every** replay attempt, including attempts stopped by new CFG edges, the converter verifies any milestones reached before learning more paths. It stops with `REGRESSION_MILESTONE_MISMATCH` on divergence and records actual/expected hashes. Unreached future milestones remain pending. No frames are fabricated or skipped; the checks are read-only and do not modify CPU or PPU behavior.

This guard does not prove the GO prompt, control responsiveness or SNES video equivalence; it catches regressions against the already-proven native replay.

## Capacity control after verified cache ceiling

Long SNES games may exceed a project's explicit CFG variant ceiling. `tools/forja65.js learn-crash ... --cache-limit 131072` and `tools/replay-converge.js ... --cache-limit 131072` now accept an **explicit validated override** (1..1,000,000), persisted only by the successful source regeneration. Without this flag the previous hard ceiling and fail-closed behavior remain intact. A cache overflow never silently evicts decoded instructions.
