# Forja65 v0.3.54 — External Leaf Priority Queue

- adiciona `external_leaf_cutover.next_unproven_leaves`;
- ordena folhas nao provadas por impacto estrutural e rank, preservando rota callback/accumulator e sites;
- mantem `family_summary` e `handler_inventory` introduzidos na v0.3.53;
- crossfeed DKC3 validado em 39/97 folhas externas, 162/368 hits e 89/240 unidades semanticas provadas;
- prioridade continua sendo evidencia de engenharia, nunca autorizacao sem proof ROM-bound.
