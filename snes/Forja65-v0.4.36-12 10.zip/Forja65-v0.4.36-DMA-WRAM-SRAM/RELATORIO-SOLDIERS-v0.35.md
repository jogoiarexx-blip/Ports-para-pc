# Forja65 Soldiers Crossfeed — v0.35

A ferramenta compartilhada `tools/integrate-observed-flow.py` agora aceita a opção **`--allow-verified-overlap`** para integrar um destino ROM-backed cujo CFG cruza instruções já recompiladas. A mescla preserva os handlers antigos, rejeita divergência de estado de CPU ou mnemônico, exige prova e fingerprint da ROM, e só adiciona PCs ausentes. Modo estrito segue padrão.

A base Soldiers v0.35 aplicou o mecanismo ao endereço `$C0:9DA6` (154 PCs preservados e 239 adicionados), e ultrapassou mais sete destinos de execução reais, totalizando 631 PCs novos e 1.355 entradas novas no dispatcher do jogo. O Forja65 permanece separado: não contém o jogo modificado, mas sim o integrador de uso geral e regressões.

**Validação:** testes integrador 8/8 no Forja65 e 8/8 no Soldiers; compilação Linux Release do jogo aprovada; CTest 24 PASS, 1 SKIP, 0 FAIL. Replay do jogo parou em `$C2:0776` no quadro 5.798, ainda sem confirmação da contagem, controles ou primeira fase jogável.
