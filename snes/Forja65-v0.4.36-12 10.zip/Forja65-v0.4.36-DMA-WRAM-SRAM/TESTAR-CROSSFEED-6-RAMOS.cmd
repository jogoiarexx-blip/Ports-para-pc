@echo off
setlocal
cd /d "%~dp0"
node --check forja65-core.js || exit /b 1
node tests\cpu-bank-carry-v0427-regression.js || exit /b 1
node tests\reset-vector-jml-trampoline-v0428-regression.js || exit /b 1
node tests\ppu-brightness-lut-v027-regression.js || exit /b 1
node tests\smw-wram-executable-mapping-regression.js || exit /b 1
node tests\wram-stores-interrupt-resume-regression.js || exit /b 1
echo CROSSFEED PASS
pause
