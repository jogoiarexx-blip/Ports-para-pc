# Forja65 v0.4.27 — descobridor de tabelas indiretas SNES

Ferramentas novas **aditivas**, usadas para investigar Super Mario World sem alterar CPU/PPU/APU de projetos já estáveis:

- `tools/rom-pointer-table-seeds.js`: detecta sequências contíguas de ponteiros de 24 bits LoROM no banco informado. Para um local com `JML [$dp]` validado na ROM, exporta sementes especulativas e relações `knowledge.dispatch`.
- `tools/rom-word-table-seeds.js`: importa intervalos **explícitos** de ponteiros de 16 bits, ligados ao banco esperado; valida intervalo, mapeamento LoROM e fonte `JML [$dp]`.
- `tools/test-rom-pointer-table-seeds.js` e `tools/test-rom-word-table-seeds.js`: testes de alinhamento, deduplicação, rejeição de endereços inválidos e limites.

**Importante:** jamais modificar `runtime-hints.txt` em resposta à descoberta estática; uma entrada da tabela não significa que o runtime a executou. O Forja mantém o dispatcher dinâmico e protege o cache de instruções. Ampliar `cacheLimit` exige decisão explícita quando o teto seguro é atingido; evitar eliminar CFG antigo.

A análise de Super Mario World gerou 590 ponteiros de 24 bits/144 destinos únicos e 93 ponteiros de 16 bits/59 destinos únicos; o port verificou 205 frames, sem concluir o título e sem teste Windows.
