@echo off
setlocal
cd /d "%~dp0"
node --check forja65-core.js || exit /b 1
node tools\test-spc-v0431.js || exit /b 1
echo SPC v0.4.31 PASS
pause
