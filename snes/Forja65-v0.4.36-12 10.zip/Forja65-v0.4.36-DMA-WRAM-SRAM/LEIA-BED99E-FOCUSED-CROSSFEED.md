# Forja65 v0.3.96 — B E:D99E (rodada de integração)

Alvo observado no replay do ZERO: `BE:D415 → BE:D99E`, CPU E0/M0/X0/C0, `JSR $D99E`. A ROM foi conferida por SHA-256 (`2277a2d8dddb01fe5cb0ae9a0fa225d42b3a11adccaeafa18e3c339b3794a32b`).

A ferramenta existente `tools/advance-observed-target.py` gerou a análise focalizada, verificou a origem dos opcodes e executou `--apply` no ZERO. Resultado da integração: 11 PCs novos, 22 entradas de dispatcher, 0 sobreposições com donos anteriores, variantes C0 e CQ. C++ foi compilado e ligado em Linux na mesma rodada. Essas contagens medem código de CPU convertido para C++, **não** sistemas independentes do hardware SNES.

Evidências: `reports/validation-crossfeed-0396/bed99e-integrated/` e teste `tests/bed99e-focused-crossfeed-regression.py`. O `compile_and_replay_verified: false` no relatório gerado é intencional: o relatório atesta somente a análise estática, e não deve ser modificado com dados inferidos de execução. Resultados de execução ficam no projeto ZERO.

Testes: `python3 tests/bed99e-focused-crossfeed-regression.py` e suíte de integração existente. A validação dos opcodes isoladamente não significa fidelidade da lógica de jogo; o replay determinístico continua necessário.

## Resultado posterior de execução / próximo alvo

Replay do ZERO compilado com a rotina gerada: 14.420/14.420 frames iguais, 0 novos frames. Novo alvo **observado** `BE:D418 → BE:DB3B` (`JSR $DB3B`, E0/M0/X0/C0). A origem foi conferida byte a byte com a ROM e está em `reports/validation-crossfeed-0396/bedb3b-preview/bedb3b-caller.json`. O próximo destino possui pré-análise, apenas `dry_run` (8 PCs, 24 linhas candidatas). Não declarar esse próximo destino integrado até compilar e testar.
