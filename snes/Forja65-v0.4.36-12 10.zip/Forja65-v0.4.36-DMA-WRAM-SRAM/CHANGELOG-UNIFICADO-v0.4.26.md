# Forja65 v0.4.26 — unificado SPC/DSP/Soldiers

Base BRR v0.4.25 + clock fracionário + DIV corrigida + WRAM/Soldiers. Cache somente entre predecessores auditados, fingerprint obrigatório. Modos legacy independentes preservados. API e metadados sincronizados. Consulte ../RELATORIO-UNIFICACAO-v0.4.26.md para testes atuais e falhas herdadas.
