# RELATÓRIO — Forja65 Soldiers/Tetris Audio Crossfeed v0.19

## Fontes preservadas
- Base principal: Forja65 v0.4.19 Soldiers crossfeed v0.18 (`sha256: b33399cbf9c1d9bda2ed0a073508498f9317f9210cf93f9924b3b841b4398b7b`).
- Fonte de PCM: Tetris 2 v0.4.23 Audio Realtime (`sha256: e9d36104690542319e5a916a15c111b26af0f9e578ba506c263a341d84ac2460`).
- A base multigame v0.4.19 mantém a própria CPU 65C816, PPU, DMA, HDMA, SPC700, DSP e lógica de crossfeed Soldiers. O código da Tetris 2 *não* substituiu os componentes comuns do Forja.

## Integração concluída
- O gerador `forja65-core.js` gera `PcmAudioOutput` integrado no header `src/runtime.hpp`, autossuficiente para regressões antigas que compilam somente esse header.
- O gerador também emite `src/pcm_audio_output.hpp` independente, com WinMM (`waveOut`) no Windows, estéreo 16-bit/32kHz, FIFO 12×512, WAV por streaming, contador de blocos perdidos, pico, volume de host `FORJA65_AUDIO_GAIN=0..400`.
- Saída ao vivo habilitada automaticamente no modo janela interativa (salvo `FORJA65_AUDIO_MODE=off`), mantendo o headless sem áudio por padrão se não for pedido áudio/captura.
- `RUN-WINDOWS-AUDIO.cmd`, `RUN-NATIVE-AUDIO.cmd` e `docs/AUDIO-REALTIME-CROSSFEED.txt` fornecidos nos projetos C++ gerados.
- `ApuBridge` preserva a DSP/temporização existente; envio PCM não modifica a lógica da CPU ou PPU. Captura de PCM em vetor `nativePcm` passa a opt-in (`enableMemoryPcmCapture(true)`) para evitar crescimento de RAM durante sessões normais.
- `forja65-audio-report.txt` identifica `live_requested`, `live_ready`, `wav_opened`, `generated_frames`, `nonzero_frames`, `peak`, `frames_queued`, `frames_dropped`, `backend_error`.
- Macro `NOMINMAX` protegida antes de incluir `windows.h` no transporte, para reduzir conflitos da API Win32 com `std::min/max`.

## Prova de não substituição regressiva
- Port sintético gerado antes: 74 arquivos; após: 79 arquivos.
- Alterações nos arquivos anteriormente gerados: `CMakeLists.txt`, `RUN-NATIVE-AUDIO.cmd`, `src/runtime.hpp`, `forja65-build-manifest.txt`.
- Adicionados: `src/pcm_audio_output.hpp`, `RUN-WINDOWS-AUDIO.cmd`, `docs/AUDIO-REALTIME-CROSSFEED.txt`, `tests/pcm_audio_output_smoke.cpp`, `tests/audio_dsp_transport_smoke.cpp`.
- Nenhum arquivo anteriormente gerado foi removido; os demais arquivos comparados conservaram hash.

## Testes executados nesta sessão Linux
- Build sintético por CMake/GCC de `game`, `pcm_audio_output_smoke`, `audio_dsp_transport_smoke`, `runtime_smoke` e `framework_smoke`: APROVADO.
- CTest 4/4 APROVADOS (PCM/WAV, DSP→PCM/uso de RAM, runtime e framework).
- JavaScript: **12/16** regressões selecionadas APROVADAS; testes Soldiers/SPC prioritários entre os aprovados.
- Auditoria de gameplay Soldiers: 9/9 APROVADOS.
- 4 falhas de testes antigos também reproduzidas na versão original sem esta integração, portanto anteriores ao crossfeed: master-cycle-irq-hdma-v029-regression.js, cross-game-cpu-flow-v028-regression.js, ppu-sprite-row-regression.js, ppu-priority-hires-v027-regression.js.

## Limitações e próximos passos
- Não foi possível ouvir áudio em Windows nesta sessão nem compilar em MSVC; WinMM/driver/latência precisam de teste real no PC.
- A síntese DSP existente continua preliminar (ADSR, gaussiana, eco etc. ainda não validados); o transporte PCM por si só não garante som fiel ao SNES.
- Este ZIP contém o **gerador Forja65**, não substitui os ports C++ já gerados de Soldiers ou Tetris. Para receber a nova saída em um port existente, precisa gerar uma nova build C++ a partir da mesma ROM e conhecimento desse port, preservando as correções próprias dele.
- O bloqueio Soldiers `C04380 -> C027A7` no frame 5796, citado no relatório da fonte, não é resolvido pela atualização de áudio.
