# v0.27 — Forja65

Adicionado verificador compartilhado da completude da captura real de WRAM e vídeo. O relatório não infere execução correta a partir de testes sintéticos.
