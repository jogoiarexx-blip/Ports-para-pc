# Forja65 v0.4.07 — Crossfeed de temporizacao e IPL do Tetris 2

- O gerador de runtime C++ agora inclui log opt-in dos canais CPU↔SPC por `FORJA65_APU_IPL_TRACE=1`, incluindo arquivo de trace na captura SPC.
- Preserva o scheduler anterior por padrao; adiciona clock fracionario NTSC somente sob `FORJA65_SPC_TIMING=accurate` e `FORJA65_SPC_CLOCK=ntsc`.
- A classe `ApuBridge` adiciona metodo `savePortTrace`, com limite de eventos e relatorio de truncamento.
- Novo crossfeed `tests/tetris-spc-ipl-v0408-regression.js`, gera runtime a partir de ROM sintetica, compila e executa o teste real de boot/transferencia IPL.
- 12/12 testes de integracao selecionados aprovados no Linux.
- Nao afirma equivalencia de audio com hardware real nem ativa o novo clock por padrao.
