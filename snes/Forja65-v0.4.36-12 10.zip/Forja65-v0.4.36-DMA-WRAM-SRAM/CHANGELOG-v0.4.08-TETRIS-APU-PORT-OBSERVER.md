# Forja65 v0.4.08 — trace observavel de CPU/APU

- O gerador agora inclui no `runtime.hpp` uma opcao para registrar leituras da CPU aos latches APU nos registradores `$2140-$2143` (`Q` em `apu-ports.csv`).
- Nova opcao `FORJA65_APU_TRACE_READS=changes` (requer `FORJA65_APU_IPL_TRACE=1`) e contadores `# cpu_reads=`. Captura opcional, comportamento desativado por padrao, sem chamar ou sincronizar SPC700 adicionalmente.
- Prova automatizada `node tests/tetris-spc-port-observer-v0409-regression.js`: gera codigo de ROM sintetica, compila o C++ gerado e testa a separacao de portas bidirecionais e compressao de polls.
- Suite Tetris/Forja65 desta entrega: 13/13 testes selecionados passaram. O Tetris comparou 500 quadros do modo estavel com hashes identicos aos da versao anterior.

Limite: captura em fronteiras de instrucao, nao em ciclos do barramento; ainda nao comprova fidelidade com uma execucao instrumentada do SNES.
