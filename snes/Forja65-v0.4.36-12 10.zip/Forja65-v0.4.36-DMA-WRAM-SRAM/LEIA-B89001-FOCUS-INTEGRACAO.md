# Forja65 v0.3.96 — foco em observação B8:9001

**Base:** `Forja65-v0.3.96-BEC774-TRADUCAO-E-INTEGRADOR.zip`.

Foi acrescentado `tools/advance-observed-target.py`, uma ferramenta **genérica**, destinada a reproduzir uma análise focalizada, conferir os opcodes contra a ROM e executar uma pré-verificação de integração segura. Ela evita que um novo alvo observado fique fora de um orçamento CFG saturado por hints antigos.

O procedimento valida que há uma única observação ROM-bound, exige o mesmo SHA-256 de ROM no projeto e no analisador, executa `analyze` com hint isolado, verifica o hash do arquivo C++ e usa `integrate-generated-cfg.py` para bloquear duplicações, colisões e ROM errada. Sem `--apply`, nenhuma fonte do port é alterada. Mesmo com `--apply`, compilação e replay devem ser executados separadamente.

## Exemplo (pré-validação, sem alterações)
```sh
python3 tools/advance-observed-target.py \
  --rom /caminho/dkc3/assets/cart-data.bin \
  --project /caminho/DKC3-ZERO-v0.41 \
  --hint examples/dkc3-cross-project-0396/b89001-focused-hint.txt \
  --target B89001 --out /tmp/forja-b89001
```

O teste de CLI realizado neste ciclo produziu o mesmo SHA-256 do arquivo C++ da análise anterior: `0538df6185c7606aa82f665b3df173abe1632c08f826ffc40f703f0b8a389148`; 38 posições / 76 traços sem incompatibilidade. Testes `advance-observed-target-regression.py` e `integrate-generated-cfg-v0396-regression.py` aprovados.

O DKC3 ZERO integrado completou **14.420 frames** (+3, prefixo de 14.417 idêntico), e revelou `B8:9F4D → B8:A676`. O fluxo foi conferido contra o ponteiro da ROM; o Forja65 recebe a observação para a rodada seguinte.

**Limite:** comparação de bytes não prova equivalência semântica das instruções, DMA, PPU ou jogo completo. O Forja65 continua ferramenta intermediária de análise e tradução, não deve relatar 100% de cobertura pelo sucesso de um endereço.
