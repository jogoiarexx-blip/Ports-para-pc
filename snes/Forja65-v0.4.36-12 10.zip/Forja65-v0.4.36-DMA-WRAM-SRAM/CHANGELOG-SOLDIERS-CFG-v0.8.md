# Forja65 v0.4.04 — Soldiers of Fortune v0.8 crossfeed

## Generic quality addition

Added `tools/compare-frame-traces.py` to strictly compare deterministic frame progress CSV traces across versions of a port. The comparison uses the exact frame clock and a configurable selection of PC, joypads, auto-joy, instruction counts, NMI, and frame hash. It refuses incomplete, malformed, non-monotonic, or missing checkpoints, and returns failure on divergence. `tests/compare-frame-traces-smoke.py` covers match, mismatch, missing frames, truncation, and non-monotonic frames (5 cases passed).

## SNES code conversion observations

The Soldiers of Fortune v0.8 port contains seven additionally ROM-verified focused CFG handlers for `$D0:04F7`, `$D0:0474`, `$D0:0404`, `$D0:0A1C`, `$D0:0A3F`, `$D0:04BC`, and `$D0:052E`, integrated with the existing `advance-observed-target.py` tool. The Forja65 core is not modified for these ROM-specific discovered addresses; those changes belong to the game's generated project. The existing focused and multi-shard integrator tests passed.

No claim of fully native SNES graphics/audio or finished gameplay. The converter and the port remain separate, preserving selective crossfeed practices used for the other SNES games.

After seven verified imports, the last Soldiers replay ends at 5359 frames with a new missing CPU target at `$C0:D932`, called from `$C0:4300`. This address is intentionally *not* incorporated into the generic converter; it is an observed game-specific code discovery for the next focused import. The clean Linux full build was attempted but ran into the execution time budget; the port's new handlers and dispatcher were separately compiled and linked to unchanged v0.7 objects with matching -O0 flags.
