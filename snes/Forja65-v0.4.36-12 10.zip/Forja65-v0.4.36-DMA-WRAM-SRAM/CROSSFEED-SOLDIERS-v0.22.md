v0.22: ferramenta de correlacao observacional WRAM/video importada do Soldiers, com 2 testes unitarios. Nenhum opcode ou semantica de runtime foi modificado.
