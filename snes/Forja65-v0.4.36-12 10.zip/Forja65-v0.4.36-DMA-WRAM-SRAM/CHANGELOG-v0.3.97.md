# Forja65 v0.3.97 — correções genéricas da camada de runtime do Tetris 2

Base: Forja65 v0.3.96. O gerador passa a emitir CPU 65C816 decimal ADC/SBC, block move com índice de 16 bits, PPU VRAM buffered read corrigido, SPC700 timer I/O compartilhado por backend, retorno de zero em timer $FD-$FF e reset na transição de enable, amostragem estéreo sem alocação por sample, decoding BRR sem shifts indefinidos, e ROM native pack com busca binária ordenada. Mantidas correções preexistentes de DMA/HDMA de v0.3.96, inclusive read16BankWrap. Não alterados o domínio de CFG, a seleção de handlers nem proveniência da ROM.

Regressão específica: `node tests/tetris-hardware-v0397-regression.js`. Suite geral: `node tools/test.js`.

Ainda não é tradução totalmente independente do hardware SNES. Dependências do motor runtime e provas de equivalência continuam explícitas.

Ajustados os testes de compatibilidade de cache v0.3.97 e a regressão histórica SNES9x v0.2.6: o teste antigo de VMADD agora configura explicitamente VMAIN bit7 para incremento após $213A, conforme a semântica da PPU. Os testes específicos são executáveis separadamente.
