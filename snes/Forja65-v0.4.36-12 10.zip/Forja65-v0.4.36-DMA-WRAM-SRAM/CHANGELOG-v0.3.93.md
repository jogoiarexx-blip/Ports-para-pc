# Forja65 v0.3.93 — ciclo de vida dos retornos

A ROM pode alterar o retorno real de JSR/JSL e seguir um destino RTS/RTL autorizado. Antes, esse caminho retirava bytes da pilha do 65C816, mas deixava o registro auxiliar C++ da chamada pendurado. Um teste com mil chamadas acumulava mil registros.

Agora as chamadas geradas registram a posição física S e um identificador de chamada. O C++ só continua depois do dispatcher quando o retorno normal encerrou aquela chamada específica; retornos não locais abandonam as continuações consumidas pela pilha. O retorno redirecionado autorizado retira o registro do frame efetivamente consumido. Um trampolim PEA abaixo de uma chamada externa preserva o frame externo. Correspondência de retorno e entrada em native hook verificam a posição da pilha para não usar registros de outra chamada.

A pilha real, os destinos e a política de autorização de retornos continuam sendo os da ROM. Não foi acrescentado fallback que aceite qualquer PC. A API anterior de hooks permanece disponível para as integrações existentes; todo código de chamada gerado usa o registro com posição S.

Testes executam código C++ gerado de ROMs sintéticas: RTS/RTL em emulação/nativo, mil redirecionamentos por combinação; retorno não local que abandona duas continuações; chamadas aninhadas, PEA e wrap do stack pointer. O novo probe de posição também acompanha os projetos gerados e é registrado no CTest.

Cache v0.3.92 reutilizado somente porque a decodificação e o CFG armazenados são os mesmos. Todo C++ é regenerado pelo emissor corrigido; não é reaproveitado código C++ antigo.

Consulte reports/validation-v0393/RESULTADOS.md para testes, replay e bloqueios remanescentes. Esta revisão não certifica conclusão da primeira fase nem melhora de FPS.
