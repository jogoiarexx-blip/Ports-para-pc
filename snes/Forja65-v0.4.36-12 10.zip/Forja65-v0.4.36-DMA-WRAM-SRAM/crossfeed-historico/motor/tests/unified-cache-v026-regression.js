"use strict";
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const F=require('../forja65-core'),IO=require('../tools/project-io');
assert.match(F.VERSION,/^(0\.4\.26-unified-spc-dsp|0\.4\.27-unified-wram-video)$/);
for(const v of ['0.4.25-brr-arithmetic','0.4.24-audio-key-timing','0.4.19-crossfeed-multigame'])assert.ok(IO.isAuditedCacheVersion(v),v);
for(const v of ['0.4.23-unknown','0.4.25-arbitrary','0.3.97-tetris-hardware'])assert.equal(IO.isAuditedCacheVersion(v),false,v);
const rom=F.loadRom(F.makeSyntheticRom(),'cache-unified.sfc'),a=F.analyze(rom,384),hash=F.romFingerprint(rom);
for(const v of ['0.4.25-brr-arithmetic','0.4.24-audio-key-timing','0.4.19-crossfeed-multigame']){
 const cache={...IO.makeCfgCache(a,hash),version:v};
 IO.mergeCfgCoverage(F.analyze(rom,384),cache,hash);
 assert.throws(()=>IO.mergeCfgCoverage(F.analyze(rom,384),{...cache,rom:'wrong-rom'},hash),/cache incompatible/);
}
for(const name of ['VERSION','VERSION.txt'])assert.equal(fs.readFileSync(path.join(__dirname,'..',name),'utf8').trim(),F.VERSION);
console.log('UNIFIED_CACHE_V026_PASS audited_predecessors=3 wrong_rom=rejected');
