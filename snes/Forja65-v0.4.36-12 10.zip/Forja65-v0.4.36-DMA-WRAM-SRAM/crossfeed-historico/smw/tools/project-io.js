'use strict';
const fs=require('fs'),path=require('path'),C=require('../forja65-core');
function hintKey(h){return [h.rom,h.target,h.from,h.kind,h.state.emulation,h.state.m8,h.state.x8,h.state.carry].join('|');}
function readOptional(file){return fs.existsSync(file)?fs.readFileSync(file,'utf8'):'';}
function writeFiles(out,files){fs.mkdirSync(out,{recursive:true});const changed=[];for(const [n,v]of Object.entries(files)){const p=path.join(out,n),bytes=typeof v==='string'?Buffer.from(v):Buffer.from(v);if(fs.existsSync(p)&&fs.readFileSync(p).equals(bytes))continue;fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,bytes);changed.push(n);}return changed;}
function refreshManifest(project,changed){const file=path.join(project,'forja65-build-manifest.txt'),lines=fs.readFileSync(file,'utf8').trimEnd().split('\n');for(const [name,value]of Object.entries(changed)){const bytes=typeof value==='string'?Buffer.from(value):Buffer.from(value),line='file='+name+' size='+bytes.length+' fnv1a64='+C.fnv1a64Bytes(bytes),i=lines.findIndex(l=>l.startsWith('file='+name+' size='));if(i>=0)lines[i]=line;else lines.push(line);}writeFiles(project,{'forja65-build-manifest.txt':lines.join('\n')+'\n'});}
// Same-ROM, same-version monotonic CFG cache. Every retained routine was
// decoded independently from real ROM bytes by this exact Forja65 version.
// Never invent edges, return targets, or CPU states to make a missing label pass.
const CACHE_SCHEMA='forja65.cfg-coverage-cache.v1';
// v0.3.66 changes output instrumentation only, not the decoder/CFG algorithm.
// Permit only the audited immediate predecessor's decoded ROM functions.
const OUTPUT_ONLY_COMPATIBLE_PREDECESSORS=Object.freeze({
 // ROM opcode decoding is unchanged; WRAM store execution and cache budgeting only.
 '0.4.28-smw-wram-resume':'0.4.27-unified-wram-video',
 // Opt-in WRAM instrumentation only; CPU/CFG decoder and emission unchanged.
 '0.4.27-unified-wram-video':'0.4.26-unified-spc-dsp',
 // Unified output-only merge; CPU/CFG source compared between all supplied branches.
 '0.4.26-unified-spc-dsp':'0.4.25-brr-arithmetic',
 '0.4.24-audio-key-timing':'0.4.19-crossfeed-multigame',
 // v0.4.25 changes DSP BRR arithmetic only. Reuse v0.4.24 decoded CPU/CFG,
 // but always regenerate C++ so cached projects receive the corrected DSP.
 '0.4.25-brr-arithmetic':'0.4.24-audio-key-timing',
 // v97 changes runtime CPU arithmetic, PPU/SPC/DSP and ROM lookup only; opcode/CFG decoding and cached edges are unchanged.
 '0.3.97-tetris-hardware':'0.3.96-rom-indexed-vector-writers',
 // v96 adds ROM-backed candidate edges; prior opcode/state coverage remains valid.
 '0.3.96-rom-indexed-vector-writers':'0.3.95-windows-capture-cleanup',
 // v95 changes diagnostic test file lifetimes and build output only; CPU coverage is unchanged.
 '0.3.95-windows-capture-cleanup':'0.3.94-observed-callback-state',
 // v94 enriches observed edges/PEA continuations. Individual opcode decoding and emitter
 // are unchanged; v93 coverage remains a guarded partial set, with callers reanalyzed.
 '0.3.94-observed-callback-state':'0.3.93-stack-return-lifetime',
 // v93 retains decoded ROM/CFG entries; all C++ is regenerated with stack-lifetime tracking.
 '0.3.93-stack-return-lifetime':'0.3.92-ppu-color-hdma-obj-fastpath',
 '0.3.92-ppu-color-hdma-obj-fastpath':'0.3.91-bg-obj-raster-provenance',
 '0.3.91-bg-obj-raster-provenance':'0.3.90-scanline-raster-provenance',
 '0.3.90-scanline-raster-provenance':'0.3.89-oam-order-pixel-provenance',

 // v0.3.86 adds read-only DMA transfer provenance; decoder and CPU CFG unchanged.
 '0.3.89-oam-order-pixel-provenance':'0.3.88-obj-assembly-diagnostics',
 '0.3.88-obj-assembly-diagnostics':'0.3.87-oam-vblank-reload',
 '0.3.87-oam-vblank-reload':'0.3.86-dma-provenance',
 '0.3.86-dma-provenance':'0.3.85-obj-slot-evidence',
 // v0.3.85 adds opt-in OBJ slot telemetry only; CPU decoding and C++ CFG emission unchanged.
 '0.3.85-obj-slot-evidence':'0.3.84-rom-tiny-indirect-leaves',
 // v0.3.84 only adds ROM-guarded speculative decode seeds; cached opcodes/state and emitter are unchanged.
 '0.3.84-rom-tiny-indirect-leaves':'0.3.83-transactional-crash-learning',
 // v0.3.83 changes crash-learning transaction semantics only; CPU CFG is identical.
 '0.3.83-transactional-crash-learning':'0.3.82-isolated-replay-sram',
 // v0.3.82 changes SRAM path selection only; CPU decoder and CFG unchanged.
 '0.3.82-isolated-replay-sram':'0.3.81-obj-input-probe',
 // v0.3.81 changes the OBJ capture exporter, diagnostics and tests only; CFG is unchanged.
 '0.3.81-obj-input-probe':'0.3.80-obj-bank-renderer',
 // v0.3.80 changes OBJ renderer and test code only; CPU CFG is unchanged.
 '0.3.80-obj-bank-renderer':'0.3.79-replay-input-ownership',
 // v0.3.79 changes host polling ownership only; ROM decoding/CFG unchanged.
 '0.3.79-replay-input-ownership':'0.3.78-bounded-flow-peer-budget',
 // v0.3.78 bounds speculative discovery priority; decoding/emission unchanged.
 '0.3.78-bounded-flow-peer-budget':'0.3.77-pending-flow-peer-frontier',
 // v0.3.77 only reorders discovery; cached instruction decoding/emission is unchanged.
 '0.3.77-pending-flow-peer-frontier':'0.3.76-uncovered-runtime-priority',
 '0.3.68-guarded-cfg-ppu-crossfeed':'0.3.67-stack-evidence-ppu-brightness',
 // 0.3.69 alters headless termination and diagnostics; 65C816 CFG analysis is unchanged.
 '0.3.69-guarded-cfg-ppu-headless':'0.3.68-guarded-cfg-ppu-crossfeed',
 '0.3.70-guarded-cfg-ppu-compact':'0.3.69-guarded-cfg-ppu-headless',
 // 0.3.71 guards convergence's acceptance of computed returns, but the CFG decoder is unchanged.
 '0.3.71-stack-converge-guard':'0.3.70-guarded-cfg-ppu-compact',
 // v0.3.72 changes the convergence runner and its PPU audit, not ROM decoding.
 '0.3.72-incremental-convergence-ppu-audit':'0.3.71-stack-converge-guard',
 // v0.3.73 only adds opt-in C++ compilation flags; ROM decoder unchanged.
 '0.3.73-selective-shard-compile':'0.3.72-incremental-convergence-ppu-audit',
 // v0.3.74 only changes generated Windows build scripts; ROM decoding is unchanged.
 '0.3.74-ctest-target-completeness':'0.3.73-selective-shard-compile',
 // v0.3.75 reorders discovery seeds but does not change how already-decoded functions are emitted.
 '0.3.75-prioritized-flow-table-seeds':'0.3.74-ctest-target-completeness',
 // v0.3.76 reorders observed seeds using CPU-compatible cached coverage; decoder unchanged.
 '0.3.76-uncovered-runtime-priority':'0.3.75-prioritized-flow-table-seeds'
});
// A cache may be shared across a chain of versions only if *every* edge
// has been explicitly audited to leave CPU decoding and CFG emission intact.
// Avoid accepting arbitrary older caches or silently bypassing ROM fingerprints.
function isAuditedCacheVersion(candidate,current=C.VERSION){
 if(candidate===current)return true;
 const seen=new Set([current]);let version=current;
 while(OUTPUT_ONLY_COMPATIBLE_PREDECESSORS[version]){
  version=OUTPUT_ONLY_COMPATIBLE_PREDECESSORS[version];
  // Older than v0.3.68: changes to the CPU/CFG are not audited for reuse.
  if(version==='0.3.67-stack-evidence-ppu-brightness'||seen.has(version))return false;
  if(version===candidate)return true;
  seen.add(version);
 }
 return false;
}
function makeCfgCache(a,hash){return {schema:CACHE_SCHEMA,rom:hash,version:C.VERSION,functions:a.functions,staticReturnTargets:a.staticReturnTargets||[],syntheticReturnTargets:a.syntheticReturnTargets||[]};}
function mergeCfgCoverage(a,cache,hash,limit=32768){
 if(!cache){const variants=new Set(a.functions.flatMap(f=>f.instructions.map(i=>JSON.stringify(i)))).size;a.cfgCacheUniqueInstructionVariants=variants;if(variants>limit)throw new Error('CFG cache variant ceiling ('+variants+' > '+limit+'); refuse to write coverage above the configured limit');return {a,retained:0};}
 if(cache.schema!==CACHE_SCHEMA||cache.rom!==hash||!isAuditedCacheVersion(cache.version)||!Array.isArray(cache.functions))throw new Error('CFG coverage cache incompatible with ROM/version; refusing stale compilation coverage');
 const byKey=new Map(),runtimePriority=[];
 // A previous LoROM mapping bug admitted SNES WRAM banks $7E/$7F as ROM.
 // Old same-version caches may contain bogus AOT instructions for these banks.
 // Keep legitimate ROM discoveries but discard these provably non-ROM functions;
 // their RAM contents must be validated at runtime, never decoded from cartridge bytes.
 let rejectedWram=0;
 const isWramBank=pc=>(((pc>>>16)&255)===0x7E)||(((pc>>>16)&255)===0x7F);
 for(const f of cache.functions){
  if(!f.functionKey||!Array.isArray(f.instructions)||!f.entryState)throw new Error('Invalid cached CFG function');
  if(isWramBank(f.start)||f.instructions.some(i=>isWramBank(i.pc))){rejectedWram++;continue;}
  byKey.set(f.functionKey,f);
 }
 a.cfgCacheWramFunctionsRejected=rejectedWram;
 const retainedKeys=new Set(byKey.keys());
 const identicalCached=new Set();
 for(const f of byKey.values())for(const i of f.instructions)identicalCached.add(JSON.stringify(i));
 let reused=0;
 for(const discovered of a.functions){
  let f=discovered;
  if(!retainedKeys.has(f.functionKey)){
   // Only byte-for-byte identical decoded records can reuse an old handler.
   // Branches leaving this sparse suffix resume through the normal dispatcher.
   // Existing functions, their CPU states and their order remain untouched.
   const instructions=f.instructions.filter(i=>!identicalCached.has(JSON.stringify(i)));
   reused+=f.instructions.length-instructions.length;
   if(!instructions.length)continue;
   f={...f,instructions};
  }
  const old=byKey.get(f.functionKey),keys=new Set(f.instructions.map(i=>i.stateKey));
  // Equal instruction coverage can still contain new call edges/return summaries.
  // Replace only if every cached decode variant is present; never trade one branch for another.
  const sameCoverage=old&&f.instructions.length===old.instructions.length&&old.instructions.every(i=>i.stateKey&&keys.has(i.stateKey));
  if(!old||f.instructions.length>old.instructions.length||sameCoverage){byKey.set(f.functionKey,f);if(!retainedKeys.has(f.functionKey))runtimePriority.push(f.functionKey);}
 }
 const functions=[...byKey.values()];
 a.cfgCacheIdenticalInstructionsReused=reused;
 const variants=functions.reduce((sum,f)=>sum+f.instructions.length,0);
 // The ceiling bounds distinct decoded records, not repeated references to
 // an identical suffix from several retained roots. Different semantics or
 // CPU-state metadata still count separately; no cached function is evicted.
 const distinct=new Set(functions.flatMap(f=>f.instructions.map(i=>JSON.stringify(i)))).size;
 a.cfgCacheUniqueInstructionVariants=distinct;
 if(distinct>limit)throw new Error('CFG cache variant ceiling ('+distinct+' > '+limit+'); refuse to evict previously decoded routines silently');
 const oldCount=a.functions.length;
 a.functions=functions;
 const unique=new Map();
 for(const f of functions)for(const i of f.instructions){const pc=i.pc&0xFFFFFF;if(!unique.has(pc))unique.set(pc,i);}
 a.instructions=[...unique.values()].sort((x,y)=>x.pc-y.pc);
 a.decoded=a.instructions.length;
 a.native=a.instructions.filter(i=>i.status==='native').length;
 a.partial=a.instructions.filter(i=>i.status==='partial').length;
 a.unsupported=a.decoded-a.native-a.partial;
 a.instructionVariants=variants;
 a.cfgFunctionVariants=functions.length;
 a.cfgFunctions=new Set(functions.map(f=>f.start)).size;
 a.cfgBlocks=functions.reduce((n,f)=>n+(f.blockCount||0),0);
 a.cfgEdges=functions.reduce((n,f)=>n+(f.edges?.length||0),0);
 a.cfgCalls=functions.reduce((n,f)=>n+(f.calls?.length||0),0);
 a.staticReturnTargets=[...new Set([...(a.staticReturnTargets||[]),...(cache.staticReturnTargets||[]).filter(t=>!isWramBank(t))])].sort((x,y)=>x-y);
 a.syntheticReturnTargets=[...new Set([...(a.syntheticReturnTargets||[]),...(cache.syntheticReturnTargets||[]).filter(t=>!isWramBank(t))])].sort((x,y)=>x-y);
 a.cfgCacheRetained=functions.length-oldCount;
 return {a,retained:a.cfgCacheRetained};
}
// analyzeOnce prepends observed seeds. Put pending observations last so
// already-cached routines cannot consume the discovery budget before them.
// Coverage includes CPU widths and carry, not merely an instruction address.
function prioritizeUncoveredHints(hints,cache){
 const coverage=new Map();
 for(const f of cache?.functions||[])for(const i of f.instructions||[]){
  const states=coverage.get(i.pc)||[];states.push(i.stateIn);coverage.set(i.pc,states);
 }
 const covered=h=> (coverage.get(h.target)||[]).some(st=>st&&
  st.emulation===h.state.emulation&&st.m8===h.state.m8&&st.x8===h.state.x8&&
  (st.carry===null||st.carry===h.state.carry));
 return [...hints.filter(covered).map(h=>({...h,cachedCoverage:true})),...hints.filter(h=>!covered(h)).map(h=>({...h,cachedCoverage:false}))];
}
// Revisit direct calls already decoded in the actual caller of a pending flow.
// These are static discovery candidates, not additional observed runtime hints.
function cachedCallerSeeds(hints,cache,rom=null){
 const sites=new Set(hints.filter(h=>!h.cachedCoverage&&h.from!==null).map(h=>h.from)),seeds=new Map();
 const hash=rom?C.romFingerprint(rom):null;
 // A literal JSL preserves E/M/X/C. Its observed destination therefore also
 // proves the CPU widths at the callsite, even when an earlier callback made
 // the cached caller state obsolete. Revisit that suffix in the actual state.
 if(rom)for(const h of hints){
  if(h.cachedCoverage||h.from===null||!['FLOW','STATE'].includes(h.kind)||h.rom!==hash)continue;
  let i;try{i=C.decodeOne(rom,h.from,{...h.state});}catch{continue;}
  if(i&&i.mnemonic==='JSL'&&i.operand===h.target)
   seeds.set(h.from+'|'+JSON.stringify(h.state),{start:h.from,state:{...h.state},entryName:'CACHED-CALLER'});
 }
 for(const f of cache?.functions||[])if(f.instructions.some(i=>sites.has(i.pc))){
  const indirect=f.instructions.some(i=>sites.has(i.pc)&&['JMP','JSR'].includes(i.mnemonic)&&['AbsoluteIndirect','AbsoluteIndirectLong','AbsoluteIndexedIndirectX'].includes(i.mode));
  if(indirect&&f.entryState)seeds.set(f.start+'|'+JSON.stringify(f.entryState),{start:f.start,state:f.entryState,entryName:'CACHED-CALLER'});
  for(const c of f.calls||[])if(c.state)seeds.set(c.target+'|'+JSON.stringify(c.state),{start:c.target,state:c.state,entryName:'CACHED-CALL'});
 }
 return [...seeds.values()];
}
// Retry discovery with a smaller budget; never raise the ceiling or evict cache.
// A retry is accepted only if every pending observation is actually decoded.
function analyzeWithinCacheLimit(rom,max,hints,opts,cache,hash,limit){
 const pending=prioritizeUncoveredHints(hints,cache).filter(h=>!h.cachedCoverage);
 const attempts=[];let budget=max,lastError,upper=max+1,lower=0;
 while(budget>=1){
  const fresh=C.analyze(rom,budget,hints,opts);
  try{
   const result=mergeCfgCoverage(fresh,cache,hash,limit);
   if(cache&&prioritizeUncoveredHints(pending,result.a).some(h=>!h.cachedCoverage))
    throw new Error('CFG pending observation not decoded within the cache ceiling');
   attempts.push({budget,variants:result.a.instructionVariants,distinctVariants:result.a.cfgCacheUniqueInstructionVariants,accepted:true});
   return {...result,attempts,budget};
  }catch(error){
   const ceiling=error.message.startsWith('CFG cache variant ceiling');
   const missing=error.message.startsWith('CFG pending observation');
   if(!cache||(!ceiling&&!missing))throw error;
   lastError=error;attempts.push({budget,accepted:false,reason:error.message});
   if(ceiling)upper=budget;else lower=budget;
   if(upper-lower<=1)break;
   budget=Math.max(1,Math.floor((upper+lower)/2));
  }
 }
 throw lastError;
}
function generate({romPath,out,max=65536,hints='',profile,trace=null,knowledge=null,update=false,cacheLimit=null}){
 const rom=C.loadRom(new Uint8Array(fs.readFileSync(romPath)),path.basename(romPath)),hash=C.romFingerprint(rom),existing=fs.existsSync(out)&&fs.readdirSync(out).length>0;
 if(existing&&!update)throw new Error('Output already exists; choose another --out or use --update.');
 if(existing){for(const n of ['analysis.json','analysis/generation-options.json','profiles/game_config.json']){const file=path.join(out,n);if(fs.existsSync(file)){const meta=JSON.parse(fs.readFileSync(file,'utf8')),identity=meta.rom_fingerprint||meta.rom;if(identity&&identity!==hash)throw new Error('Existing project belongs to another ROM; choose a new output directory.');}}}
 const savedProfile=path.join(out,'profiles/game_config.json');profile=profile||(existing&&fs.existsSync(savedProfile)?JSON.parse(fs.readFileSync(savedProfile,'utf8')):{});
 const savedKnowledge=path.join(out,'analysis/knowledge-pack.json');if(!knowledge&&existing&&fs.existsSync(savedKnowledge))knowledge=JSON.parse(fs.readFileSync(savedKnowledge,'utf8'));if(knowledge){knowledge=C.normalizeKnowledgePack(knowledge,hash);profile=C.mergeKnowledgeProfile(profile,knowledge,hash);}
 const texts=[hints];if(existing)for(const n of ['analysis/runtime-hints.txt','forja65-runtime-hints.txt','forja65-oracle-hints.txt'])texts.push(readOptional(path.join(out,n)));
 const byKey=new Map();for(const text of texts)for(const h of C.parseRuntimeHints(text)){const key=hintKey(h),prev=byKey.get(key);if(!prev||h.observed>prev.observed)byKey.set(key,h);}const bound=[...byKey.values()];if(bound.some(h=>h.rom&&h.rom!==hash))throw new Error('Runtime hints belong to another ROM.');for(const h of bound)h.rom=hash;
 const savedHints=C.formatRuntimeHints(bound);
 const cachePath=path.join(out,'analysis/cfg-coverage-cache.json');
 const previous=existing&&fs.existsSync(cachePath)?JSON.parse(fs.readFileSync(cachePath,'utf8')):null;
 const optionsPath=path.join(out,'analysis/generation-options.json');
 if(cacheLimit===null)cacheLimit=existing&&fs.existsSync(optionsPath)?(JSON.parse(fs.readFileSync(optionsPath,'utf8')).cacheLimit??32768):32768;
 if(!Number.isSafeInteger(cacheLimit)||cacheLimit<1||cacheLimit>1000000)throw new Error('cacheLimit must be an integer between 1 and 1000000');
 const ordered=prioritizeUncoveredHints(bound,previous);
 const bounded=analyzeWithinCacheLimit(rom,max,ordered,{knowledge,discoverySeeds:cachedCallerSeeds(ordered,previous,rom)},previous,hash,cacheLimit);
 const {a}=bounded;
 const files=C.generateProject(rom,a,{profile,trace});
 files['analysis/cfg-coverage-cache.json']=JSON.stringify(makeCfgCache(a,hash))+'\n';
 if(knowledge)files['analysis/knowledge-pack.json']=JSON.stringify(knowledge,null,2)+'\n';
 files['analysis/runtime-hints.txt']=savedHints+'\n';
 files['analysis/generation-options.json']=JSON.stringify({schema:1,rom:hash,max,cacheLimit},null,2)+'\n';
 files['reports/cfg-discovery-budget.json']=JSON.stringify({schema:1,requested:max,accepted:bounded.budget,cacheLimit,attempts:bounded.attempts},null,2)+'\n';
 const preserved={};if(existing)for(const n of ['src/native_hooks.cpp','tests/equivalence-cases.txt']){const p=path.join(out,n);if(fs.existsSync(p))files[n]=fs.readFileSync(p,'utf8');}
 const changed=writeFiles(out,files);for(const n of ['analysis/runtime-hints.txt','analysis/generation-options.json','src/native_hooks.cpp','tests/equivalence-cases.txt'])preserved[n]=files[n];refreshManifest(out,preserved);
 return {rom,a,hints:savedHints,changed};
}
module.exports={writeFiles,refreshManifest,generate,readOptional,hintKey,makeCfgCache,mergeCfgCoverage,prioritizeUncoveredHints,cachedCallerSeeds,isAuditedCacheVersion,analyzeWithinCacheLimit};
