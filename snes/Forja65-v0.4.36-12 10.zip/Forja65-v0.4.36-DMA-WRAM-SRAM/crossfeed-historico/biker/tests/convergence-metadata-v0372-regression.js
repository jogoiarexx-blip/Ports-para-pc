'use strict';
const fs=require('fs'),path=require('path'),os=require('os'),cp=require('child_process'),assert=require('node:assert/strict');
const C=require('../forja65-core'),IO=require('../tools/project-io'),{converge,cmakeConfigureArgs}=require('../tools/converge');
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'forja-converge-v0372-'));
try{
 const project=path.join(dir,'project');fs.mkdirSync(path.join(project,'analysis'),{recursive:true});
 fs.writeFileSync(path.join(project,'analysis/generation-options.json'),JSON.stringify({max:8192}));
 assert.throws(()=>converge(project,{jobs:0}),/jobs must be/);
 assert.throws(()=>converge(project,{jobs:33}),/jobs must be/);
 assert.throws(()=>converge(project,{frames:0,rounds:1}),/frames must be/);
 assert.throws(()=>converge(project,{frames:1,rounds:0}),/rounds must be/);
 assert.throws(()=>converge(project,{frames:1,rounds:1,max:'garbage'}),/max must be/);
 const build=path.join(project,'build-fast');
 assert(cmakeConfigureArgs(project,build).includes('-DCMAKE_BUILD_TYPE=Release'));
 fs.mkdirSync(build);fs.writeFileSync(path.join(build,'CMakeCache.txt'),'CMAKE_BUILD_TYPE:STRING=MinSizeRel\n');
 const options=cmakeConfigureArgs(project,build);
 assert.deepEqual(options,['-S',project,'-B',build],'existing build configuration must not be silently overwritten');
 // Cross-version caches are allowed only along explicitly audited output-only edges.
 const rom=C.loadRom(C.makeSyntheticRom(),'synthetic.sfc'),hash=C.romFingerprint(rom);
 const expected=C.VERSION==='0.3.96-rom-indexed-vector-writers'?'0.3.95-windows-capture-cleanup':C.VERSION==='0.3.95-windows-capture-cleanup'?'0.3.94-observed-callback-state':C.VERSION==='0.3.94-observed-callback-state'?'0.3.93-stack-return-lifetime':C.VERSION==='0.3.93-stack-return-lifetime'?'0.3.92-ppu-color-hdma-obj-fastpath':C.VERSION==='0.3.92-ppu-color-hdma-obj-fastpath'?'0.3.91-bg-obj-raster-provenance':C.VERSION==='0.3.82-isolated-replay-sram'?'0.3.81-obj-input-probe':C.VERSION==='0.3.81-obj-input-probe'?'0.3.80-obj-bank-renderer':C.VERSION==='0.3.80-obj-bank-renderer'?'0.3.79-replay-input-ownership':C.VERSION==='0.3.79-replay-input-ownership'?'0.3.78-bounded-flow-peer-budget':C.VERSION==='0.3.78-bounded-flow-peer-budget'?'0.3.77-pending-flow-peer-frontier':C.VERSION==='0.3.77-pending-flow-peer-frontier'?'0.3.76-uncovered-runtime-priority':C.VERSION==='0.3.76-uncovered-runtime-priority'?'0.3.75-prioritized-flow-table-seeds':C.VERSION==='0.3.75-prioritized-flow-table-seeds'?'0.3.74-ctest-target-completeness':'0.3.73-selective-shard-compile';
 const sample={schema:'forja65.cfg-coverage-cache.v1',rom:hash,version:IO.isAuditedCacheVersion(expected)?expected:C.VERSION,functions:[],staticReturnTargets:[]};
 assert(IO.isAuditedCacheVersion(C.VERSION),'current project cache version must be accepted');
 assert.equal(IO.mergeCfgCoverage({functions:[],instructions:[],staticReturnTargets:[],syntheticReturnTargets:[]},sample,hash).retained,0);
 assert.throws(()=>IO.mergeCfgCoverage({functions:[],instructions:[]},{...sample,version:'0.3.67-stack-evidence-ppu-brightness'},hash),/cache incompatible/);
 assert.throws(()=>IO.mergeCfgCoverage({functions:[],instructions:[]},{...sample,version:'0.3.60-unknown'},hash),/cache incompatible/);
 assert.throws(()=>IO.mergeCfgCoverage({functions:[],instructions:[]},{...sample,rom:'bad'},hash),/cache incompatible/);
 console.log('CONVERGENCE_METADATA_V0372=PASS');
}finally{fs.rmSync(dir,{recursive:true,force:true});}
