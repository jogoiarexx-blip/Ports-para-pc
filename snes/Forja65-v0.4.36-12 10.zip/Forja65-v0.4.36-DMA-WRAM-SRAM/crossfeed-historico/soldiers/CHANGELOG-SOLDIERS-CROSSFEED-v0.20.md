# Forja65 v0.4.19 — Soldiers crossfeed v0.20

Mantida a base principal v0.4.19, sem rollback de PPU, DMA, CPU, SPC700 ou outras melhorias multigame.

- Nova ferramenta de diagnostico **WRAM diff por endereco/frame**, opt-in, na saida gerada por `forja65-core.js`.
- Parser `tools/wram-diff-analyze.py` com comparacao entre replays e limite de evidencia; teste de 6 casos em `tests/test_wram_diff.py`.
- Teste C++ incluido automaticamente em novos ports: `wram_diff_smoke`, a partir de `tests/wram_diff_smoke.cpp` gerado no novo CMakeLists.
- Geracao real e compilacao do smoke: aprovadas em Linux.
- Nenhum contador de jogo forçado. Nenhuma alegacao de que o gameplay esteja funcionando.
- Para uso na port Soldiers, tres rotinas reconstituidas a partir da v0.19, verificadas separadamente contra a ROM.
