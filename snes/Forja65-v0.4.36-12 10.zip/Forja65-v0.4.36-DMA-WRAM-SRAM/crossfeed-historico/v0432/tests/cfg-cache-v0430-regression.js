'use strict';
const assert=require('node:assert/strict'),C=require('../forja65-core'),old=require('../crossfeed-historico/v0429/forja65-core'),IO=require('../tools/project-io');
assert(['0.4.30-cfg-wram','0.4.31-spc-profile','0.4.32-cpu-dma-order'].includes(C.VERSION));
assert.equal(old.VERSION,'0.4.29-crossfeed-6-branches');
assert(IO.isAuditedCacheVersion(old.VERSION),'audited v0.4.29 CFG coverage must remain reusable');
for(const code of [[0x18,0xFB,0xC2,0x30,0xA9,0x34,0x12,0x60],[0x22,0x00,0x81,0x00,0xDB],[0x5C,0x00,0x81,0x00]]){
 const bytes=C.makeSyntheticRom();bytes.set(code);bytes.set([0xA9,0x17,0x6B],0x100);
 const rom=C.loadRom(bytes),prior=old.analyze(old.loadRom(bytes),512),current=C.analyze(rom,512),hash=C.romFingerprint(rom);
 assert.deepEqual(current.functions,prior.functions,'cache migration must follow unchanged ROM decoding/CFG');
 const cache={...IO.makeCfgCache(prior,hash),version:old.VERSION};
 const merged=IO.mergeCfgCoverage(C.analyze(rom,64),cache,hash).a;
 const pcs=new Set(merged.functions.flatMap(f=>f.instructions.map(i=>i.pc)));
 for(const f of prior.functions)for(const i of f.instructions)assert(pcs.has(i.pc));
 assert(C.generateProject(rom,merged)['src/dispatch.cpp'].includes('forja65_try_wram_transfer'));
 assert.throws(()=>IO.mergeCfgCoverage(current,cache,'wrong-rom'),/incompatible/);
 assert.throws(()=>IO.mergeCfgCoverage(current,{...cache,version:'FAKE_VERSION'},hash),/incompatible/);
}
assert.equal(IO.isAuditedCacheVersion('0.3.97-tetris-hardware'),false);
console.log('CFG_CACHE_V0430_PASS exact_predecessor=0429 decoding=unchanged wrong_rom=reject unaudited=reject regenerated_dispatch=0430');
