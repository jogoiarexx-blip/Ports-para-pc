# Forja65 v0.4.02 — crossfeed Tetris 2 v0.4.03

- `forja65-core.js` passa a gerar a mesma otimização de DMA/VRAM em blank e latch de CGRAM da versão atual do Tetris.
- Os eventos de raster próprios do gerador continuam preservados (`recordRasterWrite` e `appendPpuTimeline`).
- Nova regressão `tests/tetris-dma-vram-v0403-regression.js` gera um runtime C++ por ROM sintética, o compila e compara os estados dos modos DMA e a composição de CGRAM.
- Atualizado teste antigo de PPU para refletir o novo ramo de escrita PPU sem perder suas verificações.
- Testadas 7 regressões Tetris: hardware, OBJ, limites, HDMA, PPU/DMA, raster e DMA VRAM, todas passaram em Linux.
- Não significa compatibilidade completa nem port 100% nativo de todas as ROMs.
