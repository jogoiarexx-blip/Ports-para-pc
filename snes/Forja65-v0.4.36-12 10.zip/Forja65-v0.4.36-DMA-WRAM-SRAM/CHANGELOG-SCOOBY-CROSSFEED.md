# Scooby-Doo Mystery (USA) — Relatorio de conversao Forja65

Data: 2026-10-10
Engine base: `Forja65 0.4.04-spc-dsp-merged-v0397` (com crossfeed generico de WRAM)
ROM: `SCOOBY DOO`, LoROM, 2.097.152 bytes
SHA-256 ROM: `7fb5236d10852125f0f37c2188b907d636647400a57bccbdb2f63098ffae8b2d`
Fingerprint Forja65 (FNV): `278768332a4ffc4a`

## Resultado reproduzido

- Geracao com `--max 16384`: **9.451 enderecos decodificados**; cobertura nativa nao aferida.
- Projeto C++ gerado e compilado com g++ 14 (Linux, Debug, `-O0`). NAO foi compilado executavel Windows neste ambiente.
- Execucao `FORJA65_HEADLESS=1 FORJA65_HEADLESS_FRAMES=240`: encerra com status **2**, depois de **90** registros de quadro (0 a 89).
- Proximo erro: `estado M/X/C nao recompilado em pc=8423896` (`$80:89D8`).
- Hash framebuffer unico nos 90 quadros: **1** (`24298b2db6200383`). Portanto nenhum progresso visual/introducao foi comprovado; os quadros podem estar pretos ou identicos.
- Testes Forja: guard de hints ROM vs RAM PASS, Tetris v0397 PASS, project regeneration PASS, nonlocal continuation PASS, stable shards PASS, stack-position guard PASS.
- Suite historica `cfg-cache-compatible-v0369-regression.js` FALHA: lista de predecessores do teste nao contempla o identificador atual `0.4.04-spc-dsp-merged-v0397`. Nao foi desabilitada nem adulterada a politica estrita de cache apenas para obter PASS.

## Descoberta concreta de CPU

A rotina ROM `$82:FA6A` chama `JSL $00:003E`. No runtime, os quatro bytes de WRAM naquele endereco sao `54 7F 7F 6B`, interpretados como `MVN $7F,$7F` seguido de `RTL`.

Isso nao e codigo estatico da ROM. Um aprendizado de CFG que registre `$00003E` como endereco ROM nunca resolvera corretamente a execucao.

## Correcoes genericas adicionadas ao Forja65

1. Registrar em `forja65-nonrom-execution-targets.txt` origem, destino, espaco de memoria e ate 64 bytes de WRAM no momento do bloqueio, sem alterar o jogo.
2. Impedir que `appendRuntimeHint` grave destinos fora de ROM como se fossem sementes de CFG ROM.
3. Filtrar no `learn-crash` todos os destinos sem mapeamento ROM; emitir `reports/nonrom-execution-targets.json`, evitando ciclos falsos de 0 novas instrucoes.
4. Tratar exclusivamente o padrao dinamico comprovado por bytes `MVN/MVP dst src RTL`, quando destino e WRAM e a chamada vem de JSL, com controle de pilha/RTL. Fora desse padrao, manter o bloqueio explicito; **nao** implementar um interpretador generico de CPU na RAM.
5. A ponte de bloco exige estado E=0, X=0 e nao representa validacao ciclo-a-ciclo de hardware, CPU ou PPU contra console original.

## Limites e proximas prioridades

- Resolver a variante `$80:89D8` por evidencia de estado antes de aumentar escopo cegamente.
- Repetir headless + hashes + captura visual comparada ao SNES original.
- Construir infraestrutura de interpretacao/compilacao do codigo RAM se aparecerem outros padroes alem do bloco MVN/MVP+RTL.
- Validar progresso completo: logos, intro, menu, inicio, primeira fase, checkpoint e final da fase.
- Auditar PPU/DMA/HDMA/SPC/DSP apos CPU deixar de bloquear. Nenhuma dessas equivalencias e considerada 100%.

## Comandos no Windows

Com Node.js, CMake e Visual Studio C++ instalados, extrair ambos os ZIPs e no terminal, a partir da pasta do Forja65:

```bat
node tools\forja65.js analyze "CAMINHO\Scooby-Doo Mystery (USA).sfc" --out "CAMINHO\Scooby-Native-PC" --max 16384 --update
```

Na pasta gerada de Scooby-Doo, execute `BUILD-WINDOWS.cmd`. O `RUN-HEADLESS.cmd` permite diagnosticar a inicializacao. O executavel Windows nao esta precompilado neste pacote.

Para validar sem alterar codigo, a fonte deste pacote ja inclui a ROM fornecida em `assets/cart-data.bin`, os arquivos C++ e as dicas de CFG vinculadas ao fingerprint acima.

Logs do teste Linux estao na pasta `QA-SCOOBY/` do pacote do jogo. Este e um port **experimental com ROM em runtime**, nao um jogo concluido ou port totalmente independente do hardware SNES.
