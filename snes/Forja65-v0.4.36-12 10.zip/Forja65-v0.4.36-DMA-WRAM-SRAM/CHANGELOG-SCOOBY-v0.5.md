# Forja65 — Scooby-Doo crossfeed v0.5 (2026-10-10)
- 158 candidatos ROM-bound de callbacks `LDA #imm16; STA $02,X` no banco 81 em ferramenta generica opt-in, sem declarar observacao em runtime.
- 14.973 enderecos CPU decodificados apos incluir candidatos e destinos realmente observados $818A32, $818FED.
- Corrige falso positivo de estagnacao de replay quando frametime e hashes sao iguais mas `blocked_edge` mudou; preserva comportamento antigo para hashes equivalentes sem diagnostico.
- Suite dirigida: 10/10 JS, 3/3 CTest nativos. New Game ainda bloqueado no quadro 2.384 em $818151 -> $81856E.
- O trabalho nao comprova primeira fase jogavel, equivalencia SNES nem build Windows.
