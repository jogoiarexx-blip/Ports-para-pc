# Forja65 v0.3.96 — entrega focalizada BE:DB3B

Reaproveitado `tools/advance-observed-target.py` com evidência observada ROM-vinculada (`BE:D418 → BE:DB3B`). Integrador aplicou **8 endereços** e **24 registros** sem sobreposição no DKC3 ZERO. Fonte gerada vinculada ao SHA-256 da ROM, com **16 verificações de opcodes sem divergências**.

Incluído `tests/bedb3b-focused-crossfeed-regression.py`, com teste de integridade do C++ gerado, origem da chamada e níveis de evidência. A suíte existente de proteção de alvos, ROM errada, símbolos duplicados e overmapping foi executada sem falhas.

Replay no ZERO: **14420 frames**, prefixo idêntico **14420/14420**, adicionais **0**. Novo bloqueio registrado: `BED42E -> BED8E7`. 

Evidências: `reports/validation-crossfeed-0396/bedb3b-integrated/`. O relatório do integrador mantém `compile_and_replay_verified=false` corretamente: a evidência de compilação/replay é independente e está em `bedb3b-replay-summary.json`.

## Próximo destino observado

`BE:D42E → BE:D8E7` (`JSR $D8E7`, bytes `20 E7 D8`) confirmado nos bytes da ROM e no rastro da CPU. O Forja65 fez **pré-análise dry-run** de `BE:D8E7`: 14 PCs inéditos potenciais, 30 registros potenciais, com um símbolo externo ignorado para evitar conflito. **Não aplicado no ZERO, não compilado e não executado nesta rodada.**
