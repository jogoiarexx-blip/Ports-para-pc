# Forja65 v0.4.27 — correcao generic CPU 65C816 bank carry

O gerador C++ usava `(DB<<16)|((base+index)&0xffff)` para modos absolutos X/Y e indiretos Y. O indice do 65C816 pode atravessar de `$7E:FFFF` para `$7F:0000`; o carry deve ser calculado antes da mascara de 24 bits.

Mudanca apenas em `forja65-core.js`, sem alterar as versoes anteriores, o RESET fix ou outros subsistemas. A troca propaga a regra aos proximos ports, mas os ports gerados anteriormente precisam ser recompilados/gerados para incorpora-la.

Prova red-green: o teste C++ `tests/cpu_bank_cross_smoke.cpp` do pacote Biker Mice v0.4 detecta o erro na v0.3 e passa no runtime corrigido. O teste de integridade JS `tests/biker_bank_carry_source_test.js` verifica o template; `node --check forja65-core.js` verifica a sintaxe.

Atencao: Biker Mice ainda mostra forced blank no frame 4700 apos a correção. Correcao do bug de CPU NAO significa que a corrida esteja jogavel.
