# Forja65 v0.4.35 — PCM e DSP (reunificado)

Base: `Forja65-v0.4.34.2-PCM-CROSSFEED-REUNIFICADO.zip`.
As alterações são na implementação de DSP emitida por `forja65-core.js`, no
transporte de PCM emitido por `native/pcm_audio_output.hpp`, documentação e
testes. Os diretórios de ROM/projetos e a árvore `crossfeed-historico` foram
preservados; **os projetos já gerados precisam ser regenerados e recompilados**.

## Alterações

- O DSP gerado usa agora `hardwareEchoFir`: eco estéreo com amostra SPC RAM de
  15 bits (signed `>>1`), FIR0 mais antigo e FIR7 mais recente, produtos com
  deslocamento aritmético de 6 bits, wrap signed 16 nos taps 0..6 e
  saturação após o tap 7; saída com bit 0 zerado. Preservado caminho legado
  para comparação.
- `hardwareNoiseTiming`: LFSR do ruído usa o contador compartilhado de
  envelopes de 30.720 posições, respeitando offsets e divisores por rate;
  mantém a LFSR original e suas transições.
- `hardwareVolumeScaling`: DSP usa escala de volume por divisor 128 em vez
  de 127 (volumes de voz, MVOL e EVOL), mantendo o caminho antigo opt-in.
- O WinMM continua **32 kHz por padrão**; `FORJA65_AUDIO_DEVICE_RATE=48000`
  abre dispositivo de 48 kHz e converte a saída de 32 kHz com interpolação
  linear contínua 3:2, preservando o estado entre blocos. O dump WAV continua
  em 32 kHz sem conversão. Relatório adiciona `output_rate_hz`; nesse modo,
  `frames_queued` e `frames_dropped` estão em frames do dispositivo (48 kHz).
- Projeto gerado inclui `RUN-WINDOWS-AUDIO-48KHZ.cmd` e guia
  `docs/PCM-DSP-v0435.txt`.
- Testes novos cobrindo a ordem FIR, clipping/wrap, estéreo e ruído, e WinMM
  48 kHz com dispositivo simulado, WAV 32 kHz sem alteração.

## Compatibilidade / flags

Por padrão, os executáveis **regenerados** usam FIR, clock de ruído e volumes
novos. Os objetos `SpcDsp` instanciados diretamente por testes antigos
conservam compatibilidade com fixtures v0.4.26. Para usar os cálculos
anteriores em portas C++ regeneradas:

```
set FORJA65_DSP_ECHO_FIR=legacy
set FORJA65_DSP_NOISE_CLOCK=legacy
set FORJA65_DSP_VOLUMES=legacy
```

A escrita na RAM do eco **continua opt-in** (`FORJA65_ECHO_RAM_WRITES=1`),
pois pode afetar rotinas SPC que reutilizam a mesma memória. O
agendamento SPC/DSP intercalado continua opcional. Esta versão não altera
os tempos do 65C816 ou os componentes visuais.

## Limitações

Os cálculos corrigidos seguem as operações documentadas para a etapa FIR,
mas a temporização completa de 32 ciclos do S-DSP, todos os estados de
KON/KOFF e a equivalência de PCM amostra-a-amostra contra um SNES
original **não foram demonstrados**. 48 kHz é uma opção de compatibilidade de
DAC, **não aumenta a fidelidade do sinal original**; seu interpolador
linear tem resposta em frequência diferente de um resampler sinc.
Reprodução em Windows físico e jogos reais ainda precisam de validação.
