# Forja65 v0.4.01 — PPU raster, registro de acessos, Tetris 2

- A geração de `src/runtime.hpp` aplica sincronização raster seletiva: ignora as escritas apenas nos latches `$2115/$2116/$2117/$2121`, mas conserva sincronização em portas de dados e OAM.
- O novo perfil por registrador (`FORJA65_PPU_REGISTER_PROFILE=1`) permite auditar o uso real sem confundir os milhares de acessos DMA com execução de PPU plenamente nativa.
- O gerador C++ chama `writePpuRegisterProfile()` no encerramento normal de cada jogo gerado, criando o CSV quando ativado.
- `tests/tetris-ppu-raster-v0402-regression.js` gera runtime novo de uma ROM sintética e compila/roda teste de fidelidade à execução anterior.
- As regressões anteriores do Tetris (hardware, sprites, limites OAM, HDMA, snapshot e DMA) continuam passando.
- Nenhuma alegação de PPU 100% nativa ou validação completa de jogos.
