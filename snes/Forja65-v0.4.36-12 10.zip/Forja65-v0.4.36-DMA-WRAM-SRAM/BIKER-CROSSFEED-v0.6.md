# Biker Mice x Forja65 — convergencia comprovada v0.6

Base: Forja65 v0.4.27 BIKER CFG REGRESSAO v0.5. Nesta rodada **nao foi alterado o nucleo generico do Forja65**. A evolucao de CFG pertence ao projeto do jogo, derivada de evidencias vinculadas ao fingerprint ROM `5df32d6de53b7971`.

## Ganhos reais

- Port v0.5: 21.628 enderecos decodificados; nova analise 25.186 (incremento +3.558).
- Cinco observacoes adicionais apos o frame 6049 foram incorporadas na traducao: novos caminhos de fluxo e um retorno de pilha `STACK-RTS` verificado pelo stack trace.
- `tools/verify-learned-cfg.js`: 92/92 observacoes aprendidas cobertas pelo dispatcher (ver relatorio correspondente no ZIP do jogo).
- `tests/dispatch-runtime-evidence-v07-regression.js`: PASS.
- `tests/monotonic-cfg-cache-v0365-regression.js`: PASS.
- O frame 6040 preserva o hash anterior do framebuffer `7d6ab2edeecda662` e WRAM `bafda2ade527ac08` nas reproducoes observadas.

## Limites

- As observacoes de CFG sao especificas a ROM modificada. **Nao importar para outras ROMs**.
- Estar coberto pelo dispatcher nao demonstra execucao correta de todas as ramificacoes.
- Nao declarar GO, aceleracao, direcao ou corrida finalizada antes dos testes visuais e A/B.
- O ultimo resultado do replay esta documentado no projeto Biker Native PC v0.6.

Para a proxima rodada, usar os scripts ja existentes `tools/replay-converge.js`, `tools/replay-prefix-audit.js`, `tools/input-differential-probe.js` com o fingerprint validado e a trilha `tests/biker-enter-track.trace` do jogo.

## Ultima pendencia do replay

Apos 6.049 frames completos, foi observado outro salto ainda nao incorporado: `$83:9FF0 -> $83:A128` (FLOW, E0/M0/X0/C0). Ele foi preservado no ZIP do jogo em `analysis/last-blocker-v06-hints.txt`. O proximo ciclo deve primeiro validar e incorporar essa evidencia; nenhum novo CFG esta sendo atribuido ao nucleo sem teste.
