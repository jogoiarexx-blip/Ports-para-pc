# Forja65 v0.4.14 — captura multipla por frames

- Gerador C++ agora suporta `FORJA65_CAPTURE_FRAMES=N,M,...` com no maximo 32 quadros, em ordem crescente e sem duplicata.
- Grava `frame-N/` isoladamente: dados PPU, imagem preview.ppm, manifestos com hashes e indice de capturas.
- `RUN-CAPTURE-TIMELINE.cmd` incluido nos novos ports.
- Opcao anterior `FORJA65_CAPTURE_FRAME` preservada. Opcoes simultaneas ou listas invalidas geram falha explicita.
- Regressoes de geracao e compilacao do runtime novo passaram.
- Estudo de caso Tetris 2: quatro quadros em uma so sessao, idênticos byte a byte às capturas individuais.
- Nao altera comportamento de CPU, PPU, DMA, SPC700 ou gameplay.
