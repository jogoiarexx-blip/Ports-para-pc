# Forja65 v0.3.80 — OBJ address correctness

Correção genérica no runtime/gerador de ports SNES, sem regras de jogo:
- OBSEL $2101: endereço base dos tiles OBJ bits 0-2, segunda página a `(name_select + 1) * 8192` bytes da base (em vez de `name_select * 8192`).
- Única função `PpuState::objNameBase` alimenta ambos os renderizadores de sprites e a captura OAM, evitando novas divergências.
- Wrapping vertical de coordenadas OBJ módulo 256 também no rasterizador, antes presente apenas no exportador de cenas.
- `obj_sprite_bank_smoke` gerado em cada projeto e registrado no CTest cobre transferência DMA e decodificação dos sprites.
- `tests/obj-bank-v0380-regression.js` valida o header realmente gerado e compila/executa o C++ de teste.

Sem mudanças na tradução CPU/CFG, controle de replays v0.3.79, ROM ou formatos das capturas. Limites: teste sintético não substitui replay de jogos reais.

- Regression references: original v0.3.4 pixel reference preserved separately; v0.3.80 reference accepts the verified SNES OBJ address change. Legacy v0.2.7 OBSEL assertion now checks the correct second bank at 0x4000 for name-select=1.
- Generic input replay smoke: verifies holding and releasing SNES Right through $4219 without mutating any game input trace.

Validação: 128 casos Node confirmados (123 na primeira passagem; 4 corrigidos e reexecutados; 1 novo smoke), DKC3 10 testes C++ passando, 1 ignorado, 13.500 frames de replay preservando PC e WRAM. Detalhes em `RESULTADOS-TESTES-v0380.md`.
