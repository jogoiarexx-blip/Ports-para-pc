# Soldiers of Fortune crossfeed v0.17 — Forja65 v0.4.19

A versão principal permanece **v0.4.19 CROSSFEED-MULTIGAME**. O gerador `forja65-core.js` recebeu um diagnóstico genérico opt-in `FORJA65_VIDEO_STATE_CSV`, com janela `FORJA65_VIDEO_STATE_START`, `FORJA65_VIDEO_STATE_END`, `FORJA65_VIDEO_STATE_STEP`. A cada amostra elegível, os campos incluem hashes somente-leitura de framebuffer, WRAM, VRAM, CGRAM, OAM; os contadores acumulados de escritas PPU, DMA, HDMA e VRAM bloqueada; e os registradores de composição INIDISP, BGMODE, TM, TS.

A coleta é opcional e não força estados de jogo, retornos, pixels, entradas ou relógio do SNES. Ferramentas novas: `tools/video_state_audit.py` e `tools/test_video_state_audit.py`. O analisador reporta classes de observação, nunca conclui automaticamente causalidade ou equivalência com hardware SNES.

Verificação: `node --check forja65-core.js`, geração de projeto temporário via `forja65.js analyze` e compilação sintática C++ do `runtime.hpp` gerado, mais dez testes unitários do analisador Python. O port Soldiers v0.17 possui teste C++ da própria instrumentação.

Bloqueio do jogo: integração ROM-bound em `$C0:4B76` (+36 sites / +105 rows). A conclusão da primeira fase continua pendente de replay e comparação com referência SNES.
