# Forja65 v0.3.96 — passagem BE:C774 (integração DKC3)

A rotina `BE:C774` foi gerada pelo analisador Forja65 sem adicionar instruções específicas do DKC3 ao motor genérico. Foram encontradas **56 posições únicas de instrução** em **112 registros emitidos**, considerando as variantes E0/M0/X0/C1 e carry desconhecido. A checagem de proveniência de opcode contra a ROM teve **0 incompatibilidades**, SHA-256 da ROM `2277a2d8dddb01fe5cb0ae9a0fa225d42b3a11adccaeafa18e3c339b3794a32b`.

## Melhoria reutilizável

`tools/integrate-generated-cfg.py` integra uma rotina gerada em um port C++ *sem sobrescrever módulos existentes*: verifica o hash da ROM e do código, recusa colisões por endereço, preserva a ordenação dos 112 mil+ registros do dispatcher e mantém o CMake atualizado. Por padrão opera **sem alterar arquivos**; exige `--apply`. Esse recurso é genérico e pode ser reutilizado em outros ports Forja65 quando a estrutura do projeto for compatível. Testes: `python tests/integrate-generated-cfg-v0396-regression.py`.

## Reproduzir

Use a mesma ROM, Node.js e Python 3.9+:

```bash
node tools/forja65.js analyze cart-data.bin --hints examples/dkc3-cross-project-0396/runtime-hints.txt --max 512 --cache-limit 8192 --out trabalho-c774
node tools/verify-generated-rom.js cart-data.bin trabalho-c774/src/generated_015.cpp BEC774 3a574807afbad761
python tools/integrate-generated-cfg.py --project /CAMINHO/DKC3-ZERO-v0.41 --generated trabalho-c774 --entry BEC774 --proof reports/validation-crossfeed-0396/be-c774-rom-proof.json
# Somente após conferir o resultado: repita com --apply.
```

**Importante:** o número do shard `generated_015.cpp` pode variar em outras análises; procure pela definição `void sub_BEC774_`. Há uma cópia da função gerada em `examples/dkc3-cross-project-0396/forja_bec774.cpp` e evidências verificáveis em `reports/validation-crossfeed-0396/`.

A validade de opcode não demonstra equivalência semântica de CPU, pilha, PPU ou gameplay. O Native PC mantém seus handlers atuais, sem receber essas funções de CPU.

## Próximo destino (preparado, não integrado): B8:9001

O replay da nova rotina confirmou `B8:8304 → B8:9001` com `X=0x20` e carry zero. O ponteiro na ROM fica em `B8:8020`, comprovado por `tools/ingest-indexed-flow.js`. O Native identifica esse endereço pelo rótulo estrutural `player_interaction_10`.

**Observação sobre orçamento de análise:** com todos os hints anteriores e `--max 512`, a geração não priorizou a nova função. Usando um hint isolado, vinculado à mesma ROM (`target=B89001 from=B88304 kind=FLOW e=0 m=0 x=0 c=0`), o Forja65 emitiu `sub_B89001...`; **38 posições únicas / 76 traços de opcode** foram auditados com 0 divergência. A tradução experimental está em `examples/dkc3-cross-project-0396/forja_b89001_NEXT_ONLY.cpp` e o relatório em `reports/validation-crossfeed-0396/b89001-next-static-proof.json`. **Não foi adicionada ao jogo neste pacote**, pois ainda falta compilar e executar o replay da próxima rodada.
