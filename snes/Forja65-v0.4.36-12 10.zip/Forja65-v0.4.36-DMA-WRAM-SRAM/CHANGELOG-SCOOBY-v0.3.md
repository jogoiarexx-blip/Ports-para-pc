# Forja65 — Scooby crossfeed v0.3 (2026-10-10)

- Preservadas todas as melhorias dos pacotes unificados e a v0.2 (incluindo suporte ROM-bound a WRAM MVN/RTL, cache estrito e replay-converge).
- Melhoria generica: `tools/indirect-site-audit.js` audita destinos de saltos indiretos com comprovacao por fingerprint da ROM e opcao `--site`, filtrando alvos nao-ROM e outras ROMs. Nao considera candidatos estaticos como destinos observados.
- Novo teste independente `tests/indirect-site-audit-regression.js` valida mapeamento, estados M/X/C, rejeicao de alvos nao-ROM e de outras ROMs.
- `tools/replay-converge.js` agora grava checkpoints de progresso apos executar, aprender e compilar para reduzir perda de diagnosticos se o processo for interrompido.
- O Scooby usa chamadas `$81:8151` (`JSR ($0002,X)`) com destinos dinamicos na RAM; o Forja aprende apenas os observados durante a execucao, sem substituir handlers por comportamentos inventados.
- Ferramentas: `node tools/indirect-site-audit.js --project CAMINHO --site 818151 --out RELATORIO.json` e `node tools/replay-converge.js --project CAMINHO --build CAMINHO_BUILD --input TRACE --frames 4000 --iterations 12 --max 22000`.
