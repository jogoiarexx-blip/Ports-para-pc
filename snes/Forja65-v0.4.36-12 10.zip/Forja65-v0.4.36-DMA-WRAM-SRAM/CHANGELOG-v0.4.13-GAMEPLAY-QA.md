# Forja65 v0.4.13 — confiabilidade do replay para todos os ports

- Gerador atualizado com parser estrito de replay do controle por quadro.
- Arquivo ausente, chaves incompletas ou duplicadas, valores inválidos e frames fora de ordem interrompem a execução com diagnóstico.
- Os scripts de gravar/reproduzir input no Windows convertem caminhos em absolutos antes de entrar na pasta bin.
- Nova regressão `tests/tetris-gameplay-input-v0414-regression.js` gera runtime de ROM sintética, compila fixture C++ e valida rejeições e eventos válidos.
- `TESTAR-TETRIS-REGRESSOES.cmd` atualizado para 18 testes atuais em vez de apenas 10 regressões históricas.

**Validação:** 18/18 regressões específicas do Tetris aprovadas em Linux, incluindo recompilação de runtimes gerados. Demais regressões gerais do Forja65 não executadas nesta rodada. Windows/MSVC não compilado.

O objetivo desta versão é confiabilidade da prova de gameplay, não nova instrução CPU/PPU ou nova funcionalidade SPC700/DSP.
