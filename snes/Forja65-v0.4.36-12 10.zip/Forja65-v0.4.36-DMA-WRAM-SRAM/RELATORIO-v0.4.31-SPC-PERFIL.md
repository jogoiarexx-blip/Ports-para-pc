# Forja65 v0.4.31 — SPC700: perfil e página direta

Base: v0.4.30 CFG + WRAM. Primeiro incremento da prioridade SPC700.

## Mudanças
- Corrigidos MOV (X)+,A ($AF) e MOV A,(X)+ ($BF): no modo corrigido, o bit P seleciona a página $0000/$0100 antes do acesso, e X incrementa com wrap de 8 bits. O modo legado conserva o endereçamento anterior.
- Perfil único `FORJA65_SPC_PROFILE=reference`: semântica corrigida, tabela de ciclos por opcode, scheduler estrito e relógio racional NTSC. Nenhuma escrita é publicada antes do orçamento completo da instrução.
- Perfil `FORJA65_SPC_PROFILE=legacy`: quatro controles desligados. Perfis explícitos são presets completos e têm precedência sobre switches individuais herdados.
- Sem perfil, os switches individuais antigos mantêm o comportamento anterior. Perfil desconhecido produz erro visível, em vez de escolher outro modo silenciosamente.
- Relatórios de áudio e upload SPC registram o modo efetivo, a temporização, o scheduler, o relógio e se o backend é intérprete ou hook vinculado. Combinações manuais são identificadas como custom.
- Ports gerados incluem RUN-WINDOWS-SPC-REFERENCE.cmd e RUN-WINDOWS-SPC-LEGACY.cmd. BUILD-WINDOWS.cmd copia ambos e RUN-WINDOWS-AUDIO.cmd para bin, junto do executável.
- Cache CPU/CFG da v0.4.30 continua auditado para regeneração; a cadeia preserva também v0.4.29. Decoder e CFG ROM não foram alterados.

## Como usar
1. Abra o Forja65 desta versão e gere novamente o projeto do jogo.
2. Compile o projeto com BUILD-WINDOWS.cmd.
3. No projeto gerado ou em bin, execute RUN-WINDOWS-SPC-REFERENCE.cmd para testar a combinação corrigida com áudio.
4. Para comparar o caminho anterior, execute RUN-WINDOWS-SPC-LEGACY.cmd usando o mesmo jogo, replay e save.
No Linux/headless, defina FORJA65_SPC_PROFILE=reference no processo do port. O ganho deste incremento está no intérprete SPC700 do runtime.

## Verificação
`node tools/test-spc-v0431.js` executa 29 regressões dirigidas. Resultados e logs em reports/validation-v0431/summary.json.
- $AF/$BF: 499.712 vetores nas páginas 0/1, ambos os modos, wrap de X, flags e isolamento dos ports quando P=1.
- ADC/SBC: 262.144 vetores, conferidos com fórmulas independentes de NZVHC e preservação de P/B/I.
- Flags F-Zero: fixture de BRK, AND1, ADDW, SUBW, POP A/X/Y, MUL e SBC.
- Predictor no perfil reference: 256 opcodes × 6 combinações de flags, sem limpar timers durante previsão, com custo conferido contra execução.
- Scheduler: MOV $F4,#$CC só publica a escrita no 105º master clock, para orçamento de cinco ciclos SPC na razão NTSC.
- Um segundo NTSC nominal: 1.024.000 ciclos SPC e 32.000 contabilizações de amostras DSP; estado de timers e CPU equivalente com lotes irregulares de clocks.
- Incluídos testes existentes de IPL/upload, registradores, polling, timers, predictor estrito, DIV exaustivo, relógio DSP e BRR, além das regressões CFG/WRAM da etapa anterior.
Os dois casos novos foram reproduzidos em falha na base antes da implementação. Os testes novos compilam C++20 com -Wall -Wextra -Wpedantic -Werror.

## Limites
O perfil reference é opt-in: não houve gameplay comercial comparado com um SNES/emulador-oráculo. O padrão continua legado até essa comparação.
O teste de um segundo demonstra consistência de clocks/estado, não equivalência sonora. DSP/mixer permanecem aproximados; interleave SPC/DSP não foi ativado.
Relógio rational deste perfil é NTSC. Este incremento não implementa razão PAL nem acessos internos por ciclo.
Se o port vincular spc700_native.cpp por hook, o perfil do intérprete não reescreve sua semântica/relógio; o diagnóstico informa linked_hook.
Não houve build de game.exe no Windows. A geração e cópia dos launchers foram verificadas por teste; execução WinMM precisa do PC Windows.
Não foi executada a suíte histórica inteira. As 29 regressões listadas são o escopo desta validação.
A revisão independente foi limitada aos trechos de implementação fornecidos; os testes finais compilam e executam a fonte entregue.

## Integridade
Fontes anteriores e manifestos permanecem em crossfeed-historico/v0430 e v0429. Manifestos de raiz são renovados, excluindo somente os próprios manifestos.
