# Forja65 v0.4.04 — crossfeed SPC700/DSP do Tetris 2

A `forja65-core.js` gera agora `src/runtime.hpp` com:
- F2 com bit 7 inibindo a escrita em F3, mantendo leitura e sombra dos registradores correta;
- mute global e soft-reset simplificado de FLG;
- detecção de final e loop BRR antes da decodificação do bloco seguinte;
- sinalização e limpeza de ENDX por fim de amostra, registro $7C e KON;
- cabeçalho BRR reiniciado em cada KON.

Nova regressão `tests/tetris-apu-dsp-v0405-regression.js`: gera runtime C++ via ROM sintética, compila e executa teste dedicado de APU/DSP. Os demais 8 testes da família Tetris também foram executados e aprovados.

Validação: 9/9 regressões do gerador em Linux; replay, compilação integral e suíte CTest executados no pacote do Tetris. Windows não compilado. SPC700/DSP ainda usa modelagem simplificada de timing, envelope, interpolação e eco.
