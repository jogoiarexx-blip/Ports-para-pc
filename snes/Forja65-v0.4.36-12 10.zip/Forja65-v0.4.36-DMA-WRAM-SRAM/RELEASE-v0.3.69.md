# Forja65 v0.3.69

- Exact headless frame budget at endVblank, propagated across wait/dispatch.
- Added headless_budget_smoke to generated CMake.
- Previous 0.3.68 CFG cache accepted only with exact ROM fingerprint and audited output-only version transition.
- Added generic inspect-scene.js for real VRAM/CGRAM/OAM/PPM analysis.
- Existing semantic guarded-proof behavior retained; no extra callbacks authorized automatically.
- See RELATORIO-v0369.md for tests and limitations.
