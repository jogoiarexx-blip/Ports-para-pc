@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul || (echo [ERRO] Instale Node.js. & exit /b 1)
where g++ >nul 2>nul || (echo [ERRO] Instale g++ C++20. & exit /b 1)
node tests\audio-dsp-fir-noise-v0435-regression.js || exit /b 1
node tests\pcm-output-v0435-regression.js || exit /b 1
node tests\audio-dsp-echo-noise-v021-regression.js || exit /b 1
node tests\audio-dsp-gaussian-v022-regression.js || exit /b 1
node tests\audio-dsp-envelope-clock-v023-regression.js || exit /b 1
node tests\audio-dsp-key-timing-v024-regression.js || exit /b 1
node tests\audio-dsp-brr-v025-regression.js || exit /b 1
node tests\audio-dsp-fractional-clock-v025-regression.js || exit /b 1
echo [OK] Todos os testes de audio selecionados passaram.
pause
