# Forja65 Soldiers Crossfeed v0.37

- Adicionado `tools/recover-observed-flow.py` para reconstruir provas de fluxo ausentes a partir da última instrução e flags **observadas**, com origem e destino validados e fingerprint único da ROM.
- Adicionado `tools/test_recover_observed_flow_v37.py` com casos de aceitação e rejeição de ambiguidade.
- Essa melhoria é **diagnóstica e genérica**: não injeta a lógica específica do Soldiers no motor do Forja65, nem modifica seus sistemas de CPU/PPU/DMA/SPC700.
- Correções CFG v0.37 do Soldiers permanecem no pacote separado do port.
