# Forja65 v0.4.19 CROSSFEED-MULTIGAME — Soldiers v0.14

- Base multigame v0.4.19 preservada; não foram mesclados arquivos obsoletos de versões v0.4.04.
- Quatro destinos de CFG 65C816 do port Soldiers of Fortune, originados do runtime, foram autenticados contra a ROM: C0BDD5, C2085F, C0FE36, C0EDD1.
- **475 instruções localizadas + 952 entradas** integradas no port; os relatórios ROM-bound e a auditoria acumulada confirmam ausência de sobreposições e **20.735 entradas de dispatcher**.
- Adicionado `tools/audit-native-calls.py` e `tests/audit-native-calls-regression.py`: uma verificação genérica de chamadas JSR/JSL/JMP/JML diretas geradas, com seis testes de regressão aprovados. O auditor detectou C0EDD1 como próximo alvo estaticamente antes da confirmação do replay. A ferramenta não infere execução ou gameplay e não importa código sem evidência da ROM.
- Boot e menus reproduzidos; captura da floresta e HUD no frame 5390. Replay do ultimo handler alcancou frame 5796 e parou em C0432B -> C20054; a tela continua em GET READY 03. Gameplay após GET READY permanece em verificação e **ainda não equivale a uma primeira fase concluída**.
- Compilação Linux passou; Windows não validado. Consulte o relatório completo no pacote Soldiers v0.14.
