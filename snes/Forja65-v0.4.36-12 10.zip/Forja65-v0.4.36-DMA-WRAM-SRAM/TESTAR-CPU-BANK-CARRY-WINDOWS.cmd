@echo off
setlocal EnableExtensions
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo ERRO: Node.js nao encontrado. Instale Node.js LTS para executar este teste.
  exit /b 2
)
node tests\cpu-bank-carry-v0427-regression.js
if errorlevel 1 exit /b 1
echo Teste do gerador concluido. Para exercitar a CPU C++ execute o CTest cpu_bank_cross_smoke do jogo gerado.
exit /b 0
