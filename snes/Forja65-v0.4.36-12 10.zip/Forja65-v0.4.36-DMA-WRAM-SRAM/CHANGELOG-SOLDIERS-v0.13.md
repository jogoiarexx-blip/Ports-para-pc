# Soldiers of Fortune native v0.13 — Forja65 v0.4.19 crossfeed

- The converter remains on the v0.4.19 multigame branch. All prior changes remain intact.
- Four ROM-authenticated generated CFG handlers were added to the native port, without dispatch overwrites: `C0CCD1`, `C0C144`, `C0C225`, `C0BD3A`.
- New reusable `tools/audit-cfg-integration-chain.py`: checks cumulative source SHA-256, ROM identity, ordered dispatcher growth and rejects modified/preview records. Regression tests in `tests/audit-cfg-integration-chain-regression.py`.
- CPU execution is still experimental, not equivalent to a completed World 1 game. See accompanying port `RELATORIO-SOLDIERS-v0.13.md` for replay status.

- Full final replay: frame 5363, 81695199 instructions; next missing C0:BDD5. Six selected C++ tests passed; clean and Windows builds unverified.
