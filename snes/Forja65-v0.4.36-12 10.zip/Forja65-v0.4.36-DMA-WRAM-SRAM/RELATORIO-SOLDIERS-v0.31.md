# Soldiers of Fortune Native PC + Forja65 — v0.31 — avanço de execução real

## Diagnóstico baseado na execução

Após as versões de instrumentação v0.20–v0.30, foi possível **compilar e executar o jogo completo no Linux em modo Debug**. O replay neutro terminou **6.150 quadros**, mas a floresta/GET READY continuou sem comprovação da transição `03 → 02 → 01 → 00`. Entre os quadros 5.600 e 6.149, as alterações de WRAM concentram-se em `7E0066`, `7E0067` e `7E01ED`; nenhum dos três, isoladamente, prova ser o temporizador mostrado na tela.

A sondagem do registrador de status `$4212` durante VBlank mostrou a alternância da leitura automática dos controles. **Não há evidência para forçar bits de `$4212` ou os valores da WRAM.** A sondagem provisória de `$4212` foi retirada dos fontes após a medição.

No replay com `tests/soldiers-gameplay-v14.trace`, a primeira falha da CPU ocorreu no **quadro 5.796**, em `$C0:F923`. A reprodução real, seguida de integração de rotinas extraídas dos bytes da ROM, revelou os bloqueios em cadeia:

| Origem do salto | Destino | Estado da CPU observado | Situação |
|---|---|---|---|
| `$C0F5BC` | `$C0F923` | `E0 M0 X0 C0` | Integrado + compilado |
| `$C0F943` | `$C0F994` | `E0 M1 X0 C0` | Integrado + compilado |
| `$C0F9CC` | `$C0F9F7` | `E0 M0 X0 C0` | Integrado + compilado |
| `$C0FA1F` | `$C0FB13` | `E0 M0 X0 C0` | Integrado + compilado |
| `$C0FB37` | `$C0F577` | `E0 M0 X0 C0` | Integrado + compilado |
| `$C0F577` | `$C0F51C` | `E0 M0 X0 C0` | Integrado + compilado |
| `$C0F94B` | `$C0FC98` | `E0 M1 X0 C0` | Próximo bloqueio |

**Seis rotinas nativas integradas:** `C0F923, C0F994, C0F9F7, C0FB13, C0F577, C0F51C`. Total de **221 PCs únicos de instrução** e **458 linhas de despacho** na tabela para as novas variantes, geradas da ROM correspondente ao fingerprint `2f095d162726b5ea`. A rotina `$C0:F577` contém `JMP ($0032)` e usa o destino obtido dinamicamente da memória; o replay revelou `$C0:F51C`, sem fixar esse endereço artificialmente.

Após compilar as seis correções, o **próximo bloqueio real observado** foi `$C0:FC98`, chamado a partir de `$C0:F94B`, ainda no quadro 5.796; portanto **não afirmar** que o jogo iniciou a jogabilidade.

## Alterações estruturais

- `src/dispatch.cpp`: linhas adicionadas e mantidas em ordem de endereços.
- `src/forja_c0f923.cpp`, `forja_c0f994.cpp`, `forja_c0f9f7.cpp`, `forja_c0fb13.cpp`, `forja_c0f577.cpp`, `forja_c0f51c.cpp`: novos blocos nativos derivados da ROM; preservados os demais blocos.
- `CMakeLists.txt`: inclui as seis novas unidades na biblioteca `forja65_generated`.
- `tools/generate-observed-flow.js` e `tools/integrate-observed-flow.py` replicados no projeto Forja65: seleção de um alvo *realmente observado* e integração protegida, com checagem de conflito no dispatcher.
- `analysis/v31-rom-backed/`: provas JSON de decodificação e `real-execution-evidence.json`.
- `TESTAR-GET-READY-CFG-v31.sh` e `.cmd`: replay com limite de quadros, saída isolada e propagação de código de erro; a versão `.cmd` **não foi executada no Windows**.

## Testes

- Compilação completa no Linux **aprovada** em Debug; recompilações incrementais após cada integração **aprovadas**.
- CTest nativo `runtime_smoke`, `ppu_timeline_smoke`, `auto_joy_latch_smoke`: **3/3 aprovados**.
- Testes Python de integração da ferramenta: **4/4 no Soldiers** e **4/4 no Forja65**.
- Testes extras de cobertura do dispatcher e do salto indireto: **2/2 aprovados**.
- A reprodução controlada **não foi concluída**; o erro subsequente é `$C0:FC98`.

## Pendências / regra de aprovação

A etapa seguinte de maior impacto é integrar `C0FC98` a partir do estado real registrado e repetir o replay até ultrapassar 5.796 quadros; apenas depois investigar a contagem visível, o movimento e os disparos com evidências de quadros. Comparação *lado a lado* com o SNES original não foi realizada. **O GET READY não foi desbloqueado comprovadamente e a primeira fase ainda não está validada como jogável.**

Para reproduzir no Linux: `./TESTAR-GET-READY-CFG-v31.sh` (defina `OUT` para um diretório novo em cada execução). No Windows: `TESTAR-GET-READY-CFG-v31.cmd` (exige ferramentas de compilação e não fornece um `game.exe` compilado neste ZIP).
