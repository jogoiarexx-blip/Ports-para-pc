# Forja65 v0.4.05 — SPC700 cycles / timers

- Gerador produz tabela de 256 custos de instrução SPC700 em ciclos nominais de 1,024 MHz.
- Desvios condicionais levam penalidade de 2 ciclos quando executados. BRA continua com custo fixo.
- Os prescalers T0/T1 (128 ciclos) e T2 (16 ciclos) continuam rodando com timers desativados; apenas contador intermediario e saida ficam bloqueados.
- A escrita F1 que habilita um timer reinicia fase intermediaria e saida, nao o prescaler global.
- Scheduler CPU-APU passa a acumular divida assinada de ciclos, com 21 master clocks nominais por ciclo SPC700.
- Acrescentado `tests/tetris-spc-cycles-v0406-regression.js` e fixture em C++.

Limites: a temporizacao nao e ainda cycle-exact no instante de cada acesso de barramento; drift de clocks do APU real nao e reproduzido. A rota de SPC700 compilado por codigo nativo separado nao foi alterada. DSP completo, equivalencia sonora PCM e gameplay integral continuam pendentes.

NOTA DE COMPATIBILIDADE: O modo padrao preserva os passos/ciclos v0.4.04. Novo algoritmo ativa apenas com `FORJA65_SPC_TIMING=accurate` ou `1` para comparacao.
