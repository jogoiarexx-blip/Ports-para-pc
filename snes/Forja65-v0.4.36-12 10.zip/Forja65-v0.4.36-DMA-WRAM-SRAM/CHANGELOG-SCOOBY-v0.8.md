# Forja65 Scooby v0.8

- CPU 65816 convergiu ate 3200 quadros e 19.139 enderecos, preservando a v0.7.
- `ppu-transition-audit.js`: evidencias PPU de brilho zero e brilho 15 com PPM e nscene.
- `input-differential-probe.js`: criterio separado para diferencas de imagem e de WRAM na resposta ao gamepad.
- Regressões de auditoria PPU e de entrada deterministica.
- Rom e arquivos originais preservados; sem alegacao de gameplay homologado.
