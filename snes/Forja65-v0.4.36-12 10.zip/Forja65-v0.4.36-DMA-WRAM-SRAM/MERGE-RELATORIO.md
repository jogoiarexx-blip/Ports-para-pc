# Integração Forja65 0.3.97 RECUPERADO + 0.4.04 SPC/DSP

Base: **v0.4.04** (todos os avanços do gerador em PPU/OBJ, HDMA/DMA, VRAM e SPC/DSP preservados).

Recuperado da **v0.3.97**:
- `--missing-states` em `tools/integrate-generated-cfg.py`, inclusive rejeição de domínios com carry parcialmente sobreposto;
- encaminhamento da opção no `tools/advance-observed-target.py`;
- `tests/missing-state-integrator-regression.py` (prova de preservação);
- evidências e logs da recuperação anterior, sem substituir relatórios novos.

Conflitos analisados: apenas os arquivos de integração haviam perdido funcionalidade no caminho mais recente. O `forja65-core.js` moderno é mantido, sem substituição pelo antigo.

**Limites:** testes sintéticos de PPU/APU/CPU não comprovam replay de jogos completos; nem um port nativo sem ROM. O ZERO recebe duas correções pequenas do runtime, mas **não** sofre uma regeneração destrutiva do motor.
