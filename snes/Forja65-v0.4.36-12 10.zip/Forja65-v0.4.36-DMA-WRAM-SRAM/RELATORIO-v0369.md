# DKC3 ZERO v0.14 × Forja65 v0.3.69 — Testes e limitações

## Bases cruzadas
- DKC3 Native v0.93: conhecimento de callbacks, provas de equivalência sob guards, sistema visual nativo independente.
- DKC3 ZERO v0.13: execução da ROM desde RESET; Forja65 v0.3.68: CFG/retornos/PPU e guards integrados.
- ROM PT-BR: fingerprint Forja65 `3a574807afbad761` (o mesmo dos pacotes anteriores).

## Melhorias desta rodada
1. `B9A20F → B9B90D`: o arquivo `forja65-runtime-hints.txt` antigo já continha E=0/M=0/X=0/C=0. Importado do runtime, recompilado e executado. Próximo destino observado: `B9B914`.
2. `B9A20F → B9B914`: importado, recompilado e executado. Próximo destino observado: `B9B84C`.
3. `B9B84C`: importado para o CFG/dispatcher; **a última geração não foi novamente executada**. Continua pendente validação dinâmica.
4. Forja65 passou a encerrar headless no limite exato durante `endVblank`, inclusive em chamadas aninhadas e em `forja65_wait`. Não captura erros de CFG como sucesso.
5. Teste CTest `headless_budget_smoke`: 2 frames encerrados exatamente; teste `ppu_timeline_smoke` também aprovado (2/2).
6. Auditoria real do estado de vídeo no frame 280 (`tools/inspect-scene.js`).

## Resultado de execução
- Um executável nativo Linux intermediário (antes da correção do orçamento de frames) foi recompilado e testado: ao ultrapassar `B9B90D`, terminou por CFG em `B9B914`; após acrescentar `B9B914`, terminou por CFG em `B9B84C`. Na segunda execução ampliada, o erro apareceu por volta do **frame 343**. Não há recorde de frames maior que o anteriormente observado ~636.
- O projeto final regenerado com `B9B84C` e a correção de orçamento **ainda não teve o executável principal recompilado por completo**. Portanto, não afirmar que `B9B84C` foi ultrapassado.
- O verificador do dispatcher confirmou **66/66 hints e variantes E/M/X/C presentes estaticamente**. Isso não é prova de equivalência semântica.

## Vídeo real no frame 280
- `BGMODE=7`, `TM=16` (OBJ apenas, sem BG no main screen), `TS=0`, brightness=15.
- `VRAM`: 26.109 bytes não zero de 65.536; `CGRAM`: 314 de 512; `OAM`: 328 de 544.
- 82/128 entradas de OAM seguem o padrão repetido `(x=0,y=0,tile=255,attr=240)`; 46 não seguem esse padrão. Isso não mede sprites efetivamente desenhados.
- `preview.ppm`: **392 pixels não pretos** de 57.344.
- Logo, a imagem quase preta não é evidência de que o Mode 7 inteiro esteja quebrado: no instante capturado nenhuma camada BG está habilitada. A abertura, menus, saves e mapa seguem sem comprovação visual.

## Como testar
- Windows: extraia o ZIP do DKC3, execute `TESTAR-DKC3-v014-WINDOWS.cmd` (VS Build Tools 2022 C++ e CMake necessários).
- Linux: `bash TESTAR-DKC3-v014-LINUX.sh 300` (CMake, Ninja, C++20 e Node para auditoria de cena).
- Para repetir a auditoria: `node tools/inspect-scene.js <diretorio_de_captura> <saida.json>`.
- Não habilitar atalhos nativos de menu como prova de fluxo original. Não liberar callback sem guard pelo simples fato de constar no Native.

## Pendências técnicas
- Executar após `B9B84C` e capturar o próximo estado de CPU.
- Comparar os buffers/estado OBJ e DMA no instante em que a apresentação deveria compor a primeira imagem.
- Completar compilação do projeto regenerado para Windows e avaliar abertura, seleção de save e mapa com dados da ROM.
