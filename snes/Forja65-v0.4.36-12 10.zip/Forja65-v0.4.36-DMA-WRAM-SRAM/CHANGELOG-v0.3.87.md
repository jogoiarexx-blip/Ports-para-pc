# Forja65 v0.3.87 — recarga da OAM no VBlank e comparação de capturas

- Corrige um defeito geral da PPU: o cursor de endereço da OAM agora é restaurado a partir de `$2102/$2103` na entrada do VBlank, exceto durante forced blank. Não reescreve os sprites; ajusta apenas o endereço interno usado no próximo upload `$2104`.
- O comportamento foi testado com runtime sintético gerado pelo Forja65 e também com o port do DKC3.
- Ferramenta reutilizável `ppu-vram-oam-compare.py`: compara capturas brutas de VRAM (64 KiB), OAM (544 bytes) e CGRAM (512 bytes); detalha slots OBJ, bancos VRAM e paletas que diferem. Exige o mesmo frame lógico. Não afirma, sozinha, equivalência de renderização, HDMA ou precisão de ciclos.
- Compatibilidade do cache CFG acrescenta a cadeia explícita `0.3.87-oam-vblank-reload → 0.3.86-dma-provenance`, mantendo validação por fingerprint de ROM.
- Não há promessa de mudança automática no gameplay de qualquer título; regressões específicas precisam ser executadas para cada port.

Referência de hardware: https://snes.nesdev.org/wiki/PPU_registers e https://sneslab.net/wiki/PPU_Registers
