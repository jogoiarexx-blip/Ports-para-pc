# Soldiers v0.26 — diagnóstico GET READY em dois canais

A seleção v0.25 dependia de divergência entre entradas. Um temporizador independente dos controles podia ficar invisível. A v0.26 seleciona também mudanças autônomas observadas na execução neutra, priorizando decrementos; combina essa lista com as divergências dos controles e registra a origem de cada candidato em `reports/v26/dual-watch-provenance.json`.

Testes unitários das ferramentas GET READY: 10 aprovados no Soldiers; 3 no Forja65. Compilação e execução integral do jogo não validadas. Nem o temporizador real, nem `$C0:F923`, nem movimento/disparos estão comprovados. Não há comparação com ROM SNES original. Próximo passo: rodar `INVESTIGAR-GET-READY-AUTO-v26.sh`, ler `writers.csv`, `video.csv` e confrontar com SNES original.
