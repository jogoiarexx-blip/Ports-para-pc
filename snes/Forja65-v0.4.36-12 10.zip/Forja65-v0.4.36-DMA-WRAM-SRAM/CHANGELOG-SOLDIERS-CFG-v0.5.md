# Forja65 — Soldiers of Fortune v0.5 — fluxo de entrada na partida

- O alvo original `C0:B8D1` foi observado na execução da ROM em `$C0:B314` com `E0 M0 X0 C0` após a contratação dos mercenários.
- O foco de 512 instruções não encontrou esse destino; a análise delimitada com 8192 conseguiu localizar a rotina e integrar o código sem conflitos.
- O utilitário `tools/advance-observed-target.py` agora usa 8192 como orçamento padrão, com cache dimensionado ao orçamento, e aceita `--cache-limit` explícito. Os limites são validados antecipadamente; não relaxa verificações da ROM ou do código.
- Corrigida a mensagem de diagnóstico ao esgotar o orçamento antes de localizar o destino.
- Adicionadas asserções de regressão de orçamento e limites do cache.
- Descobertas posteriores de Soldiers: `C0:B8FC` e `C0:C63A`. Resultados e rastreamentos completos no ZIP separado do port.
- Nenhuma afirmação de equivalência de gameplay: os destinos são descobertas e integrações estáticas verificadas contra a ROM, seguidas por testes reais de execução do jogo.

## Correção adicional descoberta na regressão do gerador

- O template JS do método `writeFrameProgress()` escrevia `\n` sem escape duplo na string C++ gerada. Durante a compilação de um novo projeto, isso produzia aspas e caracteres C++ não terminados. O template foi corrigido para emitir os escapes `\\n` nos dois pontos afetados; o `tests/generic-boot-probe-soldiers-regression.js` passou após a correção (falhava antes).
- `D0:0000` não foi integrado nesta versão: o foco gerou a rotina em múltiplos shards (`part0` e `part1`) e o integrador conservador a rejeitou, corretamente, por ainda não possuir suporte seguro a imports multipartidos. Esse é o próximo gargalo do Forja65.
