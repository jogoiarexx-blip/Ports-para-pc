#!/usr/bin/env python3
"""Check that WRAM and writer/video timelines are coherent; no timer/gameplay claims."""
import argparse
import csv
import json
from pathlib import Path

SPECS = {
    'neutral-wram.csv': {'frame', 'kind', 'wram_address'},
    'controlled-wram.csv': {'frame', 'kind', 'wram_address'},
    'writers.csv': {'frame', 'address', 'writer_pc'},
    'video.csv': {'frame'},
}

def examine(path, required):
    if not path.is_file() or not path.stat().st_size:
        return {'status': 'missing', 'rows': 0}
    try:
        with path.open(newline='', encoding='utf-8') as stream:
            reader = csv.DictReader(stream)
            missing = required - set(reader.fieldnames or [])
            if missing:
                return {'status': 'invalid_columns', 'missing': sorted(missing), 'rows': 0}
            count, lo, hi, distinct = 0, None, None, set()
            for row in reader:
                frame = int(row['frame'])
                if frame < 0: raise ValueError('negative frame')
                lo = frame if lo is None else min(lo, frame)
                hi = frame if hi is None else max(hi, frame)
                distinct.add(frame)
                count += 1
            return {'status': 'ok' if count else 'empty', 'rows': count,
                    'min_frame': lo, 'max_frame': hi, 'distinct_frames': len(distinct), 'frames': sorted(distinct)}
    except (ValueError, OSError, UnicodeError, csv.Error) as error:
        return {'status': 'invalid', 'error': str(error), 'rows': 0}

def analyze(folder):
    items = {name: examine(folder / name, columns) for name, columns in SPECS.items()}
    valid = all(item['status'] == 'ok' for item in items.values())
    overlap = False
    if valid:
        writer, video = items['writers.csv'], items['video.csv']
        overlap = bool(set(writer['frames']) & set(video['frames']))
    return {'schema':'forja65.get-ready-capture-integrity.v1',
            'capture_valid': bool(valid and overlap), 'writer_video_frame_overlap': overlap, 'writer_video_shared_frames': len(set(items['writers.csv'].get('frames', [])) & set(items['video.csv'].get('frames', []))),
            'files':items, 'timer_verified':False, 'gameplay_verified':False,
            'limitations': 'Exact shared frame IDs are necessary, not proof of pixel changes, timer identity or gameplay.'}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('folder', type=Path)
    parser.add_argument('--out', type=Path)
    args = parser.parse_args()
    result = analyze(args.folder)
    payload = json.dumps(result, indent=2) + '\n'
    if args.out:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(payload, encoding='utf-8')
    print(payload, end='')
    return 0 if result['capture_valid'] else 2

if __name__ == '__main__':
    raise SystemExit(main())
