# v0.30 — crossfeed de integridade temporal
O validador agora exige intersecao real de indices de quadros, evitando falso positivo entre intervalos que apenas se sobrepoem. Teste de regressao incluido. Nenhum opcode do motor alterado.
