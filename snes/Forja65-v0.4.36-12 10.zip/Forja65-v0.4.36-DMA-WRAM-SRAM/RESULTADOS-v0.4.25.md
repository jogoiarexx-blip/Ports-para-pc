# Resultados verificáveis — v0.4.25

Ambiente: Linux, GCC C++20 e Node. Nenhum compilador ou dispositivo Windows
executado. CMake indisponível no ambiente. Fontes comerciais/SPC reais ausentes.

| Execução | Aprovados | Falhas | Timeout |
|---|---:|---:|---:|
| Base v0.4.24 intacta: tests/*.js e tests/*.py | 202 | 38 | 0 |
| v0.4.25: mesmos scripts + dois novos | 204 | 38 | 0 |

As 38 falhas são as mesmas; **zero novas falhas entre os testes que passavam
na base**. Isso não significa que a base ou a release tenham suíte totalmente
verde. Tampouco mede porcentagem de compatibilidade de jogos.
Cada script é uma unidade da tabela; subtests internos não foram somados.
Suíte Node da base: 212 scripts; Python da base: 28. Nova versão acrescenta
BRR e cache-version, totalizando 242 scripts. Limite de 180 s por processo,
dois workers, raízes separadas. Logs e estados individuais em
reports/validation-v0425/suite-results.json, suite-summary.json e suite-logs/.

## Áudio e correção

As sete regressões audio-* passaram: realtime v019, enhanced v020, echo/noise
v021, gaussian v022, envelope v023, key timing v024 e BRR v025. Também passaram
SPC/DSP stage1 e tetris-apu-dsp-v0405; nomes de jogos não representam ROM real.

BRR v025 compila o runtime emitido pelo conversor e compara **50178 vetores
de 32 amostras = 1605696 amostras distintas** com um modelo numérico Python
independente. Range 0–15, filtro 0–3, nibble 0–15, 49 pares de histórico,
encadeamento de blocos, histórico para gaussiana e wrap de RAM incluídos.
Foi executado com UBSan/fail-fast em Linux. O teste verifica configuração
real dos switches do port, combina os modos legados existentes e testa os
dois comportamentos BRR antigos (0 e 32766 nos witnesses).
Uma expectativa propositalmente corrompida deve retornar status 1 e JSON
com record/header/history/block/sample/expected/actual da primeira divergência.
As duas discrepâncias mínimas da base estão em base-minimal-brr-witness.json:
- range 0/F: esperado -2, base 0;
- range 12/filter 1/7/histórico 32766: esperado -6146, base 32766.

O modelo independente foi comparado numericamente ao código gerado; não foi
executado o DSP inteiro de Snes9x/ares/bsnes como oráculo PCM. Não há alegação
de áudio bit-perfect. Nenhuma música de jogo ou saída WinMM real foi ouvida.

## CPU, build e preservação

Duas ROMs sintéticas: análise CPU/CFG idêntica salvo version; 25 e 26 unidades
de CPU/dispatch/hooks geradas idênticas em bytes. cpu-cfg-parity.json documenta.
Build completo do port bootable-rom (4 fontes C++) por g++ e execução Linux
aprovados. A fixture executa STP e encerra com **frames=0**, mesmo com limite
solicitado de 3: não são três frames executados. O WAV tem apenas 44 bytes
(cabeçalho), sem PCM. native-smoke.json e logs registram esses limites.

examples/, profiles/, merge-evidence/ e relatórios históricos foram preservados
por SHA256; nenhum código individual de jogo foi editado. O bundle JS continua
consumido pela interface portátil. Os manifests foram atualizados para a
release. Conferir com: python3 tools/verify-release-v025.py.

## Não executados / bloqueados

- EXE Windows, MSVC/MinGW, dispositivo WinMM, latência/underruns reais.
- ROMs Tetris, Bomberman 2, Soldiers, Scooby, DKC3 e outros: não há ROMs
  comerciais neste ZIP para replay novo; evidências históricas não foram
  reutilizadas como se fossem execuções desta rodada.
- Comparação de registradores/PCM real contra bsnes/ares/Snes9x.
- tests/tools/test_native_oracle_build.py: tentativa extra bloqueada em
  setUpClass por CMake ausente; **zero métodos executados**, fora do total 242.
- Outros scripts históricos fora de tests/ não foram todos reexecutados.

## Falhas herdadas

Há guards que só aceitam 0.3.x/versões antigas, expectativas ligadas a nomes
internos como cachedTile e falhas reais de comparação PPU/DMA. Não foram
removidos asserts nem relaxadas expectativas para obter um placar verde.
A ausência de CMake também bloqueia alguns testes de build. Seguem as primeiras
mensagens; os logs completos distinguem a etapa exata de cada falha.

| Script (falha na base e na nova) | Primeira mensagem |
|---|---|
| tests/cli-trace-framework-regression.js | Error: Command failed: /opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node /workspace/scratch/6cd0b193dd80/work/Forja65-v0.4.25-BRR-ARITHMETIC/tools/forja65.js trace /tmp/fo |
| tests/convergence-metadata-v0372-regression.js | Error: CFG coverage cache incompatible with ROM/version; refusing stale compilation coverage |
| tests/convergence-pipeline-regression.js | AssertionError [ERR_ASSERTION]: Convergence 1/4: generate/build/run 3 frames. |
| tests/cpu-ppu-v016-regression.js | ppu_test: /tmp/forja65-v016-gEjYXh/ppu_test.cpp:7: int main(): Assertion hw.ppu.vram[2]==0xAA&&hw.ppu.vram[3]==0x55' failed. |
| tests/cross-game-cpu-flow-v028-regression.js | Error: familia v0.2+/v0.3.x ausente |
| tests/dma-forensics-v0386-regression.js | AssertionError [ERR_ASSERTION]: VRAM DMA inconsistent |
| tests/hd-integer-scale-v032-regression.js | Error: versao inesperada 0.4.25-brr-arithmetic |
| tests/inline-indexed-table-v0312-regression.js | Error: familia v0.3.x esperada: 0.4.25-brr-arithmetic |
| tests/instruction-mastercycles-v031-regression.js | Error: familia v0.3.x esperada: 0.4.25-brr-arithmetic |
| tests/interrupt-stack-v039-regression.js | Error: familia v0.3.x esperada: 0.4.25-brr-arithmetic |
| tests/local-computed-jump-run-v0311-regression.js | Error: familia v0.3.x esperada: 0.4.25-brr-arithmetic |
| tests/long-controlflow-pb-v0314-regression.js | Error: versao inesperada: 0.4.25-brr-arithmetic |
| tests/master-cycle-irq-hdma-v029-regression.js | Error: base master-cycle ausente |
| tests/native-dependency-audit-v0327-regression.js | AssertionError [ERR_ASSERTION]: 0.4.25-brr-arithmetic |
| tests/native-hardware-cutover-v0329-regression.js | AssertionError [ERR_ASSERTION]: 0.4.25-brr-arithmetic |
| tests/native-hardware-migration-v0328-regression.js | AssertionError [ERR_ASSERTION]: 0.4.25-brr-arithmetic |
| tests/native-host-foundation-v0322-regression.js | AssertionError [ERR_ASSERTION]: The expression evaluated to a falsy value: |
| tests/native-oracle-v0350-regression.js | AssertionError [ERR_ASSERTION]: E |
| tests/native-scene-capture-v0323-regression.js | AssertionError [ERR_ASSERTION]: The expression evaluated to a falsy value: |
| tests/obj-bank-v0380-regression.js | AssertionError [ERR_ASSERTION]: renderer must use shared OBJ address resolver |
| tests/obj-oam-order-v0389-regression.js | AssertionError [ERR_ASSERTION]: The expression evaluated to a falsy value: |
| tests/oracle-runtime-learning-v0325-regression.js | AssertionError [ERR_ASSERTION]: The expression evaluated to a falsy value: |
| tests/ppu-priority-hires-v027-regression.js | Error: familia v0.2+/v0.3.x ausente |
| tests/ppu-sprite-row-regression.js | probe: probe.cpp:21: int main(): Assertion x==y' failed. |
| tests/renderer-timing-flow-v023-regression.js | ver log completo |
| tests/resumable-dispatch-v037-regression.js | Error: familia v0.3.x esperada: 0.4.25-brr-arithmetic |
| tests/rom-mirror-spc-state-v038-regression.js | Error: familia v0.3.x esperada: 0.4.25-brr-arithmetic |
| tests/runtime-progress-v035-regression.js | Error: familia v0.3.x esperada: 0.4.25-brr-arithmetic |
| tests/snes9x-reference-v026-regression.js | Error: familia v0.2+/v0.3.x ausente |
| tests/spc-port-isolation-v0313-regression.js | Error: familia v0.3.x esperada: 0.4.25-brr-arithmetic |
| tests/stack-trampoline-summary-v0310-regression.js | Error: familia v0.3.x esperada: 0.4.25-brr-arithmetic |
| tests/stackless-coroutine-regression.js | AssertionError [ERR_ASSERTION]: Native redirected RTS must retire consumed hardware call frames |
| tests/state-aware-cfg-v022-regression.js | ver log completo |
| tests/state-summary-v036-regression.js | ver log completo |
| tests/subscanline-raster-v030-regression.js | Error: familia v0.3.x ausente |
| tests/tail-vector-propagation-v0315-regression.js | Error: versao inesperada 0.4.25-brr-arithmetic |
| tests/tetris-hardware-v0397-regression.js | hw: /tmp/forja-v0397-hw-aLJFtO/hw.cpp:6: int main(): Assertion p.read(0x2139)==0x34' failed. |
| tests/tetris-obj-crossfeed-v0398-regression.js | Error: Generated runtime lost PPU OBJ contract: cachedTile |

## Próxima correção prioritária

Reproduzir e corrigir ordem SPC700→DSP dentro de tickMasterCycles, comparando
fatias grandes/pequenas e primeira escrita/amostra divergente. Em seguida medir
clock racional SPC/32 e quantização do mixer/echo. Manter todos os switches
atuais. Corrigir separadamente os testes antigos e investigar as divergências
PPU/DMA que persistem na base; não mascará-las como correções de áudio.
