@echo off
setlocal
cd /d "%~dp0"
node --check forja65-core.js || exit /b 1
node tools\test-ppu-v0434.js || exit /b 1
echo PPU v0.4.34 PASS
pause
