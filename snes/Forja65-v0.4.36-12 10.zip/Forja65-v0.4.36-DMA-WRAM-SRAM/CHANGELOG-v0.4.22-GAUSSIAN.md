# Forja65 v0.4.22 — DSP Gaussian em ports gerados

- Adicionada interpolação gaussiana S-DSP de 512 coeficientes a `runtimeHpp()` em `forja65-core.js`, com áudio gaussiano como padrão nos executáveis gerados.
- `FORJA65_DSP_INTERPOLATION=linear` retorna ao mixer linear anterior para diagnosticar regressões.
- A implementação está no conversor *genérico* e será aplicada a jogos novos sem incorporar o código específico do Tetris.
- Os testes de conversor geram e compilam um port sintético isolado e verificam a tabela, a mistura e as transições de blocos BRR.
- Não elimina limitações SPC700/DSP anteriores nem representa equivalência comprovada ao SNES original.
