@echo off
setlocal EnableExtensions
cd /d "%~dp0"
echo =====================================================
echo FORJA65 0.4.34.1 - TESTES DE REUNIFICACAO
echo =====================================================
where node >nul 2>nul || (echo ERRO: instale Node.js & exit /b 2)
where python >nul 2>nul || (echo ERRO: instale Python 3 & exit /b 2)
where g++ >nul 2>nul || (echo ERRO: instale g++ MSYS2 ou configure CXX & exit /b 2)
python -m unittest discover -s tools -p "test_integrate_observed_flow.py" || exit /b 1
python -m unittest discover -s tools -p "test_audit_integrated_flow_v38.py" || exit /b 1
python -m unittest discover -s tools -p "test_recover_observed_flow_v37.py" || exit /b 1
python tests\latest-runtime-state-regression.py || exit /b 1
python test_get_ready_candidate_rank.py || exit /b 1
python tests\test_wram_diff.py || exit /b 1
node tests\audio-dsp-spc-interleave-v026-regression.js || exit /b 1
node tests\timing-order-v0432-regression.js || exit /b 1
node tests\audio-dsp-fractional-clock-v025-regression.js || exit /b 1
node tests\ppu-mode7-math-v0434-regression.js || exit /b 1
node tests\cpu-bank-carry-v0427-regression.js || exit /b 1
echo TESTES DIRECIONADOS APROVADOS
pause
