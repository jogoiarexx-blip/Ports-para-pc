# Forja65 v0.3.96 — ciclo BB:AB29 / pré-análise BE:D99E

## Alterações reais

1. A observação `B6:80D1 → BB:AB29` com E0/M0/X0/C1 foi importada usando a ROM de SHA-256 `2277a2d8dddb01fe5cb0ae9a0fa225d42b3a11adccaeafa18e3c339b3794a32b`.
2. Foram geradas duas variantes de código C++ para `BB:AB29`. A prova **estática** valida 2 instruções e 4 rastros de opcode, sem divergências. Integração no ZERO: 2 novos PCs e 6 entradas do dispatcher.
3. Novo analisador genérico `tools/audit-direct-call-dependencies.py`: lê bytes da ROM HiROM/LoROM, decodifica `JSR abs` e `JSL long`, checa endereço de continuação e se o destino está coberto pelo dispatcher. Não interpreta execução nem certifica equivalência. Em BB:AB29, identifica `JSR BB:AB2D` e continuação `BB:AB2C`, ambas com entradas de dispatcher.
4. Corrigido o teste `tests/integrate-generated-cfg-v0396-regression.py` para reproduzir o cabeçalho C++ que o gerador realmente produz; o integrador também distingue importação repetida de conflito com outro arquivo C++.
5. Observação nova após o replay do ZERO: `BE:D415 → BE:D99E` E0/M0/X0/C0, bytes `20 9E D9` (JSR). Pré-análise de `BE:D99E`: 11 endereços novos e 22 linhas de dispatcher **somente no dry-run**. Não foi integrada nesta versão.

## Testes executados

- `tests/integrate-generated-cfg-v0396-regression.py`: aprovado.
- `tools/test-focused-integrator.py`: aprovado.
- `tests/advance-observed-target-regression.py`: aprovado.
- `tests/audit-direct-call-dependencies-regression.py`: aprovado.
- `tests/generated-rom-provenance-v0396-regression.js`: aprovado.
- `tests/rom-indexed-vector-writer-v0396-regression.js`: aprovado.
- Compilação Linux do DKC3 ZERO e CTest: 22 aprovados, 1 ignorado.
- Replay do ZERO: 14.420/14.420 frames com hashes idênticos; nenhum frame adicional, próximo bloqueio BE:D99E.

## Limites

A tradução ainda é da CPU SNES para C++ e o DKC3 ZERO ainda utiliza ROM em execução. O teste de opcode é estático; o replay confirma somente os frames executados, não a conclusão da fase. Nenhum executável Windows foi validado. Os handlers de animação do DKC3 Native PC não foram alterados.

Artefatos principais: `reports/validation-crossfeed-0396/bbab29-integrated/`, `reports/validation-crossfeed-0396/bed99e-preview/` e `examples/dkc3-cross-project-0396/bed99e-focused-hint.txt`.
