# Forja65 v0.4.29 - CROSSFEED 6 RAMOS

## Origem
Base: SMW v0.4.28 (CFG/WRAM). Cruzados: PPU LUT 0.4.27, Biker CFG 0.4.27, Motor independente 0.4.27, Soldiers v0.35 (Forja 0.4.19), F-Zero patches (Forja 0.4.26).

## Correcões ativas do motor
1. CPU 65C816: adição indexada 24 bits com carry de banco em abs,X / abs,Y / (dp),Y / (sr,S),Y. Incluído teste smoke compilável em cada port gerado.
2. CFG/reset: aceita somente JML verdadeiro e delimitado na região de vetor de RESET. Não libera a tabela inteira para especulação.
3. PPU: LUT matemática equivalente no brilho 5-bits (16 x 32 entradas); evita divisões por canal por pixel.
4. SPC700: cruzadas as correções de flags BRK, AND1, ADDW, SUBW, POP e MUL no modo opcional FORJA65_SPC_SEMANTICS=corrected; modo legacy inalterado.
5. SMW: preservados CFG incremental, validação de bancos WRAM e retomada após interrupções nos stores de WRAM.
6. Motor independente: mantidas sondas de WRAM, rastreamento e logs.
7. Soldiers: ferramentas de observação/get-ready/flow integradas sem habilitar rotas específicas de um jogo para outros jogos.

## Decisões de risco
- Não ativamos globalmente o interleave SPC/DSP experimental do Biker, pois alteraria o relógio do áudio para todos os jogos sem validação multi-jogo. Código histórico está em crossfeed-historico/biker/forja65-core.js.
- F-Zero tinha alterações de testes e tratamento SPC; as melhorias SPC só operam com FORJA65_SPC_SEMANTICS=corrected, preservando legacy.
- Não copiamos cegamente arquivos conflitantes. Todas as variantes divergentes foram guardadas em crossfeed-historico e são identificáveis em MERGE-MANIFEST.json.
- O núcleo-base pode exigir ROM para os testes end-to-end. Não anexamos ROM comercial.
- Este ZIP inclui ferramentas/código-fonte, NÃO game.exe compilado do Windows.

## Validar
- node --check forja65-core.js
- node tests/cpu-bank-carry-v0427-regression.js
- node tests/reset-vector-jml-trampoline-v0428-regression.js
- node tests/ppu-brightness-lut-v027-regression.js
- node tests/smw-wram-executable-mapping-regression.js
- node tests/wram-stores-interrupt-resume-regression.js
- Para testar o C++ dos ports gerados: gerar projeto com um ROM legalmente disponível, cmake -S . -B build && cmake --build build && ctest --test-dir build --output-on-failure.

## Validação adicional
- Regressão Biker CPU bank carry: PASS; C++ gerado: PASS.
- Regressão vetor RESET JML: PASS (5 casos).
- PPU LUT: PASS 524288 casos e benchmark isolado; o benchmark mede apenas conversão de brilho, não FPS de jogos.
- CFG SMW WRAM e retorno após interrupção: PASS.
- Teste F-Zero SPC flags: PASS em C++ gerado após fusão da semântica de SBC dp,#imm.
- Regressões legadas de versão precisam atualizar a lista reconhecida; não autorizam cache antigo silenciosamente.
- Interleave SPC/DSP experimental não foi integrado; teste e código anteriores arquivados.

## Status final de regressão desta integração
- CPU bank carry: JS PASS + executável de smoke C++ PASS.
- RESET-vector JML: PASS em cinco cenários.
- PPU brightness LUT: PASS em 524.288 casos sintéticos; referência antiga e LUT conferem no teste.
- SMW CFG WRAM mapping, interrupt resume, cache budget e suffix reuse: PASS.
- Soldiers AUTOJOY latch e VBlank: PASS.
- Tetris SPC semantics e APU/DSP: PASS nos testes dirigidos.
- BRR/cache e Snes9x PPU reference: PASS após ajustar expectativas de versionamento, sem habilitar cache incompatível.
- SPC700 DIV: PASS em 67.108.864 casos com quatro combinações legacy/corrected/timing.
- SPC700 F-Zero flags: PASS em C++ gerado.
- HDMA Tetris teste demorado: INCONCLUSIVO por limite de tempo; não marca aprovação.
- Integração de gameplay real de ROMs dos seis jogos e compilação final de game.exe no Windows: NÃO VERIFICADOS NESTA ENTREGA.

## Integridade e cópias
- Os bytes distintos de todos os arquivos presentes nos seis ZIPs de origem estão preservados no pacote ativo ou em crossfeed-historico/.
- A prova é dada por crossfeed-historico/ORIGINAIS-SHA256.json e o checksum atualizado do pacote.
- Arquivos divergentes que não podem ser ativados simultaneamente ficam no histórico; preservação não é garantia de comportamento ativo equivalente.
