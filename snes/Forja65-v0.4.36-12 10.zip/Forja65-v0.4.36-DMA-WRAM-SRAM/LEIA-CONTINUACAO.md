# Continuação verificada — checkpoint

BE:D8E7 está integrado. ZERO recompilado com 747 unidades de tradução. O replay water-v050-normal-replay terminou com 27000 quadros completos; os 14.420 quadros de referência e todo o prefixo do replay anterior permanecem idênticos.

Entrega encerrada neste checkpoint a pedido do usuário, para teste manual. A primeira fase Lakeside Limbo permanece pendente. Instruções de jogo no Windows e coleta de crash: LEIA-TESTE-MANUAL.md, na pasta do ZERO.

Último estado verificado:

`Nenhum bloqueio de tradução; confirmar a travessia real da fase.`

Após a indisponibilidade do ambiente, recuperamos os pacotes salvos da versão 5 e reproduzimos exatamente seus 14.842 quadros. Os arquivos da execução antiga de 14.995 quadros não foram recuperados: este checkpoint contém novas execuções verificadas, sem usar os arquivos ausentes como evidência.

Nesta retomada foram integrados os bloqueios BB860C, BED68B, BED6AE, BBAA53, B9AAEE, BB85B2, B9EC62, B9EC72, B9EC59, B68081, B69F87, BB85A3, BBD24E, BEC716, B89FED, B8B086, B89C5C, BB85FD, BB85FA, B9BA23, B9ADAA e B89302 (três partes geradas, com a ligação B893DB → B893E7 corrigida após a integração do destino). BE:DC07 também reutiliza a tradução estática existente e recebeu um alias de retorno verificado. B8E32D reutiliza código existente, com prova de ROM e autorização de um retorno efetivamente registrado. Os lotes estáticos acrescentaram 22 rotinas carregáveis, 15 de criação de objetos, 62 auxiliares e 75 entradas do catálogo do banco B6 e 86 entradas adicionais do banco B8 e 13 entradas da tabela BB85/BB86. Todos foram compilados e o prefixo completo anterior foi preservado; isso não comprova execução de cada rotina ou ramo.

O teste observed_b893db_branch reproduziu o erro antes da correção e passou depois: caminhos tomado e alternativo preservam flags e executam uma instrução. A prova da ligação registra bytes da ROM, hashes antes/depois e o replay que observou o erro.

As 158.992 entradas originais de despacho/aliases permanecem exatamente preservadas. Há 14019 entradas novas. A identidade da ROM e os hashes dos fontes integrados foram verificados. O runtime continua com o mesmo hash do checkpoint recuperado.

O observador somente de leitura foi executado novamente em 15.269 quadros, reproduzindo todos os hashes e o mesmo bloqueio. WRAM[0x657] = 0x11: o bit 0x02 permanece desligado, portanto a fase segue pendente.

Os testes nmi_computed_return_phase1, final_state_probe_smoke e observed_b893db_branch foram executados novamente com a compilação de 747 unidades e passaram.

As provas anteriores de NMI/retorno calculado, 21 verificações do runtime, observador somente de leitura e critério de conclusão foram preservadas. Nesta retomada foram executados os guardas de origem e os replays documentados; não se afirma uma nova execução de todas as suítes, CTest ou compilação Windows.

Para confirmar a primeira fase, é necessário observar WRAM[0x657] com bit 0x02 passando de zero para um e corroborar a saída real da fase. O orçamento de quadros não é um critério de conclusão. A derivação na ROM está em reports/recovery-checkpoint/first-stage-completion-criterion.json.

A sequência original v037 chegou a 22.000 quadros, sem bloqueio de tradução, mas a fase permaneceu pendente. O cenário water-v050 acrescenta controles somente a partir do quadro 22.000; chegou a 27.000 quadros e reproduziu integralmente o prefixo original de 22.000. O observador coincidiu em todos os 27.000 hashes e confirmou que o bit 0x02 continua desligado. A captura mostra Kiddy na água.

Na pasta do ZERO, o comando abaixo reproduz a sequência original v037 (22.000 quadros):

```sh
python3 tools/test_recovery_checkpoint.py
python3 tools/replay_linux_checkpoint.py minha-validacao --capture 21999
```

O executável fornecido é Linux, TRACE=0, SRAM nova por replay, sequência input/first-stage-traversal-water-v050.trace, orçamento de 27000 quadros. O código 2 indica bloqueio de tradução; o código 0 indica apenas que o orçamento terminou. A conclusão da fase exige a prova específica de saída. O helper de compilação pode reconstruir os intermediários excluídos do pacote. As provas e os hashes completos estão em reports/recovery-checkpoint. CONTENTS.sha256 cobre os arquivos desta entrega.
