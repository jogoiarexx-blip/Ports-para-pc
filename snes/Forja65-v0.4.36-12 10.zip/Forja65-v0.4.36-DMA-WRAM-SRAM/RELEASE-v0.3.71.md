# Forja65 v0.3.71 — Guarded convergence

- `tools/converge.js` now verifies every newly discovered `STACK-RTS`/`STACK-RTL` with the current ROM opcode, valid ROM address and an **exact matching** `forja65-unresolved-returns.txt` record from the **same isolated run** before persisting runtime hints.
- On failure, reports `UNVERIFIED_STACK_RETURN`, records `stackEvidenceError`, and leaves accumulated hints unchanged. Does not bypass return stack.
- No changes to native callback/handler semantics, PPU mode or game screens. Compilation and actual framebuffer checks remain required.
