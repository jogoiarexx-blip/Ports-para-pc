# Forja65 v0.3.84 — decodificação preventiva e limitada de folhas indiretas

O Forja65 pode pré-traduzir até oito pequenas rotinas vizinhas `LDA #imm16; RTS` quando um destino foi **realmente observado** por um `JMP (abs)` indireto. Ele exige banco igual, assinatura de ROM exata, CPU com acumulador de 16 bits, e família delimitada de 3 a 8 elementos; nenhum candidato vira hint de execução.

Mudança genérica do tradutor: consulte `CHANGELOG-v0.3.84.md` e `tests/rom-tiny-indirect-leaves-v0384-regression.js`.

Comandos de testes: `node tests/rom-tiny-indirect-leaves-v0384-regression.js` e `node tools/test.js`. Para a recuperação de CFG, use `node tools/forja65.js learn-crash <projeto> --from <diagnosticos> --max 65536` e execute novamente build, CTest e replay do jogo.

**Limite:** predecodificação ROM não é equivalência semântica, observação dinâmica ou prova de que os Kongs se movem.
