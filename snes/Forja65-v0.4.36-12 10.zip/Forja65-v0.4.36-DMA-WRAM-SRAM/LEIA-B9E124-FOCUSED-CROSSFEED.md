# Integração B9:E124 — DKC3 ZERO + Forja65 + Native PC

## Resultado realmente medido

- ROM SHA-256: `2277a2d8dddb01fe5cb0ae9a0fa225d42b3a11adccaeafa18e3c339b3794a32b` (mesma fonte nos três pacotes).
- `B9:E124` traduzido e integrado no ZERO: **3 PCs inéditos e 6 registros no dispatcher**, mantendo **12 PCs já existentes** (24 registros) em seus antigos donos.
- Verificação do código gerado completo: **102 endereços de opcode** e **117 registros** comparados aos bytes da ROM; **0 divergências**. Verificação estática, não equivalência funcional completa.
- Problema adicional encontrado e corrigido: o CFG incluiu indevidamente `sub_BB8D90_E0M0X0CQ`, já definida em `generated_030.cpp`. O link falhou na primeira tentativa; o importador agora preserva apenas as variantes do alvo e rejeita símbolos globais repetidos antes do build. Link Linux voltou a passar.
- `game` compilado e linkado no Linux; **22 testes CTest aprovados, 1 ignorado** (23 cadastrados, 0 falhas).
- Replay determinístico com o mesmo input: **14.420 de 14.420 frames idênticos** (framebuffer, WRAM e PC), **0 frames adicionais**. O jogo ainda para com exit 2 (fluxo CFG não resolvido).
- Próximo bloqueio visto no replay: `B6:80D1 → BB:AB29`, opcode `22 29 AB BB` (`JSL BB:AB29`). O catálogo do Native PC registra `CODE_BBAB29`.
- Forja65 executou **análise preliminar (dry-run)** do próximo alvo: **2 novos PCs e 6 entradas** possíveis, ainda sem compilação nem replay.

## Limites da evidência

- Uma rotina **traduzida** não significa um sistema C++ reconstituído e independente do SNES.
- O ZERO ainda utiliza `cart-data.bin`, estado da CPU 65816 e outros componentes legados; não é port 100% nativo sem ROM.
- A compilação foi feita em Linux. Não houve teste ou geração do executável Windows nesta rodada.
- O Native PC recebeu apenas resultados de análise/testes; não houve mudança nos handlers de animação ou na lógica jogável.
- Não houve fechamento de fase nem avanço de frame completo neste ciclo.

## Como reproduzir

No Forja65, com a ROM existente no diretório do ZERO, a ferramenta `tools/advance-observed-target.py` importa o `b9e124-focused-hint.txt` observado, com `--target B9E124 --preserve-existing --apply`. A verificação de ROM ocorre antes de alterar qualquer arquivo.

O novo teste de regressão `python3 tools/test-focused-integrator.py` cobre inclusão somente das funções desejadas, preservação de entradas existentes, duplicação de símbolos e importação repetida.

O replay de regressão utiliza `input/first-stage-traversal-v037.trace`, `FORJA65_HEADLESS_FRAMES=16000`, e é comparado pelo script já existente `tools/check_replay_prefix.py`.

## Próxima etapa

Traduzir `BB:AB29` com a análise já preparada, integrar ao ZERO sem substituir código atual, recompilar e repetir o replay. As regras especiais permanecem do Native PC, que não precisa copiar esse código CPU.
