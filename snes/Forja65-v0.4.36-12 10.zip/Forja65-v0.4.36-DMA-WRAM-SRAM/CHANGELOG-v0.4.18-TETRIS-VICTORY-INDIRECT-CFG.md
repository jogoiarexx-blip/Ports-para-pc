# Forja65 v0.4.18 — Auditoria de trampolins indiretos SNES

O Tetris 2 produziu `unresolved-flow` na vitória: `$82:937A -> $82:CE65`.
O trampoline `PEA $937C; JMP ($9386,X)` usa uma tabela de 13 destinos, seguida pelo retorno `$82:937D`.

- Ferramenta reutilizável: `tools/analyze-indexed-jmp-trampoline.py`, somente leitura.
- Verifica hash SHA256 opcional, opcode de JMP indexado (`7C`), `PEA` anterior (`F4`), alvo de retorno, limites LoROM, tabela com quantidade explícita e cobertura do dispatcher.
- Regressão sintética: `tests/indexed-jmp-trampoline-v0418-regression.py`.
- Não habilita fallback cego nem altera a tradução do gerador; os resultados orientam a integração ROM-verificada por `advance-observed-target.py` e `integrate-generated-cfg.py`.

Exemplo (com uma ROM e um port Tetris 2 legalmente disponíveis):

`python tools/analyze-indexed-jmp-trampoline.py --rom cart-data.bin --source 82937A --count 13 --dispatch-cpp dispatch.cpp --out victory-coverage.json`

O Tetris v0.4.19 incorpora os 13 destinos e a continuidade. A fidelidade da vitória ainda requer replay real.
