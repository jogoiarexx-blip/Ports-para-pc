# Forja65 v0.3.84 — descoberta limitada de folhas de salto indireto

## Melhoria genérica

A análise CFG detecta famílias pequenas e contíguas na ROM, somente após um `FLOW` observado na mesma ROM apontar para uma rotina `LDA #imm16; RTS` alcançada por `JMP (abs)` — um salto indireto pela RAM. Os vizinhos precisam ter a mesma assinatura de quatro bytes, permanecer no mesmo banco, ser endereços de código válidos e formar uma família de 3 a 8 entradas. A descoberta fica desabilitada se a CPU estiver em emulação ou com M=8.

Vizinhos são **somente candidatos estáticos à decodificação**, não observações de execução. Não entram em `analysis/runtime-hints.txt` como FLOW e não autorizam equivalência de comportamento nem alteração da PPU. A prioridade de decodificação continua limitada, e o RESET conserva precedência. Quando há mais de oito entradas, o algoritmo não extrapola a família.

O cache da v0.3.83, vinculado à mesma ROM e à cadeia auditada, continua aproveitável porque não mudaram as regras de decodificação de instruções nem o emissor de C++: a nova regra altera apenas as sementes a serem examinadas.

## Testes

`node tests/rom-tiny-indirect-leaves-v0384-regression.js` cobre a inclusão de vizinhos, a não promoção a evidência dinâmica, a recusa de instrução de origem incompatível, M=8 e famílias grandes. `node tools/test.js` executa a suíte inteira.

## Limite

O ganho esperado é reduzir ciclos iterativos de compilação para pequenas famílias ROM comprovadas. A jogabilidade dos Kongs é verificada separadamente pelo replay do DKC3.
