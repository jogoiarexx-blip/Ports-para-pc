# Forja65 0.4.17 — OAM collision / piece-handoff crossfeed

O gerador agora inclui `tools/gameplay_wall_qa.py` e `tools/gameplay_lock_qa.py` em futuros ports. As ferramentas usam rastros determinísticos + capturas OAM/PPM, sem substituir o hardware emulado nem alterar o gerador 65C816.

**Atenção:** os valores de tile, limites X, regiões da imagem e quadros padrão vêm do roteiro do Tetris 2, portanto NÃO podem ser usados como prova para outros jogos sem configurá-los.

Executar `node tests/tetris-gameplay-wall-lock-v0418-regression.js` para verificar gerador e os validadores. O teste gera um projeto sintético e executa testes positivos e negativos. Não comprova a execução de jogos SNES reais.
