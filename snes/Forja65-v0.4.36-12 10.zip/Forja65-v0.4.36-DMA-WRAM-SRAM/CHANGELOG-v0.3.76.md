# Forja65 v0.3.76

- Prioriza destinos observados ainda ausentes por endereço e estado E/M/X/C compatível, antes de rotinas já compiladas.
- Chamadas diretas desses destinos e vizinhos plausíveis de tabelas FLOW/STACK-RTL são analisados antes das sementes cobertas pelo cache. RESET e destinos realmente observados mantêm prioridade maior que os candidatos de tabela.
- Um peer especulativo de tabela é promovido quando aparece como destino realmente observado. Não se torna prova de execução por previsão estática.
- Cache v0.3.75 aceito: decoder e emitter de instruções preservados; o runtime muda somente no ownership do diagnóstico PPU. Nenhuma instrução 65C816 ou regra de validação de pilha foi alterada.
- `analyze --cache-limit N` configura o limite explícito de variantes acumuladas e o persiste em `analysis/generation-options.json`. O padrão continua 32768; a configuração aceita inteiros de 1 a 1000000. O limite é verificado também na primeira geração. Estouro aborta antes da escrita, sem descartar cobertura anterior. Atualizações e convergência reutilizam a configuração do projeto.
- `converge --jobs N` limita os processos de compilação (1 a 32; padrão 4) e registra o valor no relatório. Este projeto foi validado com 1 processo no ambiente Linux.
- DKC3 ZERO configura 131072 variantes para continuar o caminho interativo sem descartar as rotinas de boot.
- Regressão nova cobre destino abaixo do endereço de um hint antigo, E/M/X, descendentes de chamada, promoção de peers, preservação de cobertura, limite persistente e orçamento de descoberta de peers STACK-RTL diante de rotinas já cobertas.
- Corrigidos testes legados: smoke de RESET termina com STP, sem RTS sem chamador; expectativas de 64 shards e build padrão de todos os alvos atualizadas.

Validação detalhada em `reports/validation-v0376.json`. Compilação Windows não executada neste ambiente.

## Diagnóstico PPU e CTest

- Cada SnesRuntime mantém seu próprio stream CSV, aberto uma vez e fechado por RAII ao destruir a instância. Instâncias adicionais recebem sufixos exclusivos no mesmo processo.
- Uma nova execução abre o CSV com truncamento; não concatena eventos de execuções anteriores.
- O teste PPU usa ppu-timeline-smoke.csv e lê o resultado após o encerramento do runtime, sem excluir arquivo aberto.
- Todos os demais testes CTest recebem FORJA65_PPU_TRACE=0 e caminho vazio; apenas ppu_timeline_smoke habilita a captura, mesmo com rastreamento herdado do ambiente.
- Os builds Windows padrão e de qualidade exportam game.exe e assets antes do CTest. O teste de contrato exige essa ordem.
- Regressão compilada verifica duas instâncias, fechamento, ausência de mistura e truncamento em execuções sucessivas. CTest do DKC validado em paralelo com FORJA65_PPU_TRACE=1 herdado: 9 PASS, 1 SKIP, 0 FAIL. Windows não foi executado neste ambiente.
