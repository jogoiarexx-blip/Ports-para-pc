# Forja65 v0.3.96 — validação BE:C69E / DKC3

O compilador já traduz a rotina `BE:C69E` quando recebe o hint de execução registrado pelo DKC3 ZERO. A descoberta foi reproduzida a partir da ROM original de 4 MiB (`FNV-1a64=3a574807afbad761`, `SHA-256=2277a2d8dddb01fe5cb0ae9a0fa225d42b3a11adccaeafa18e3c339b3794a32b`).

## Reprodução

1. Use Node.js e a ROM **correspondente ao hash acima**. Não misture versões da ROM.
2. `node tools/forja65.js analyze cart-data.bin --hints examples/dkc3-cross-project-0396/runtime-hints.txt --max 512 --cache-limit 8192 --out experimento-c69e` (diretório novo).
3. Procure `sub_BEC69E_E0M0X0C0` e `sub_BEC69E_E0M0X0CQ` nos C++ gerados. O `max` é orçamento de exploração, não número de frames do jogo.
4. `node tools/verify-generated-rom.js cart-data.bin experimento-c69e/src/generated_052.cpp BEC69E 3a574807afbad761` (o número do shard pode variar com outras opções; identifique pela assinatura da rotina).
5. Execute `node tests/generated-rom-provenance-v0396-regression.js` e `node tests/ingest-indexed-flow-v0396-regression.js`.

## Achados verificados

- 97 posições de instrução únicas emitidas em duas variantes C0/C? = 194 traços de opcode concordantes com a ROM.
- O DKC3 ZERO recompilado executou a nova tradução e chegou ao próximo salto indexado `BE:C37C → BE:C774`, com `X=6`, `E=0/M=0/X8=0/C=1`.
- O importador genérico `tools/ingest-indexed-flow.js` confirma o opcode `7C` e lê o ponteiro em `BE:C385`, que codifica `C774`. Também rejeita PC, ROM, flags e alvo inconsistentes.
- Replay do ZERO: 14.417 hashes anteriores idênticos; 0 frames completos adicionais; próximo bloqueio ocorre dentro do frame 14.417.

Os arquivos `reports/validation-crossfeed-0396/` incluem a prova ROM-bound e o novo fluxo. O catálogo do Native PC apenas confirma nomes e limites estruturais; não prova equivalência de seus handlers.
