# Forja65 0.3.91 — BG versus OBJ per-segment provenance

- `PixelOwnership` now includes `background`, a BG-only competing layer obtained by calling the **same** compositing path with OBJ excluded. Main-screen PPU behavior is unchanged.
- `raster-pixels.csv` adds `bg_source`, `bg_depth`, `bg_rgb`, `occlusion_cause` at the **end** of each record, without altering the previous 34-column prefix.
- The `occlusion_cause` values are `obj_disabled`, `obj_windowed`, `obj_wins`, `bg_priority`, `backdrop_or_other` (the native compositor's internal decision).
- Captures remain optional, disabled by default. No priority override, sprite displacement, HDMA timing change or pixel rewrite.
- Regression: `node tests/raster-provenance-v0391-regression.js` compiles and runs a generated C++ runtime with the new columns; old Forja65 tests are preserved.

Note: A native BG/OBJ explanation does not by itself establish original-SNES fidelity. An independent, synchronized emulator capture must be compared. `bg_priority` is not equivalent to 'hardware proven correct'.

Known pre-existing regression: `tests/ppu-bg-tile-regression.js` fails at renderer/reference pixel-array equivalence on v0.3.90 and 0.3.91; this remains open.
