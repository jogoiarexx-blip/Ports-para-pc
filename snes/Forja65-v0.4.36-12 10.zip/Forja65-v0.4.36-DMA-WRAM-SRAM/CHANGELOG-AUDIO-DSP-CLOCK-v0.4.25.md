# Forja65 v0.4.25 — relógio de amostras DSP fracionário

Base: Forja65 v0.4.24 multigame com correções de Soldiers e os recursos DSP de v0.4.20–0.4.24.

## Novo no gerador

- `src/runtime.hpp`, emitido pelo `forja65-core.js`, usa um acumulador exato em inteiros para a razão nominal `21.477.272 master ticks : 32.000 quadros estéreo`.
- O número de amostras deixa de ser arredondado de modo permanente para um intervalo fixo de 671 clocks mestres.
- Reproduções legadas continuam disponíveis com `FORJA65_DSP_CLOCK=legacy`.
- O port gerado inclui `RUN-WINDOWS-AUDIO-LEGACY-CLOCK.cmd` para comparação.
- O manifest do DSP identifica o modo `fractional_32000` ou `legacy_671`.

## Validação

- 7 regressões selecionadas passaram: v0.19 transporte PCM, v0.20 envelopes/BRR, v0.21 eco/ruído, v0.22 gaussiana, v0.23 temporização ADSR/GAIN, v0.24 KON/KOFF e v0.25 novo relógio.
- A regressão v0.25 gera o runtime C++ e compara 32.000 amostras exatas em 1 segundo entre vários esquemas de blocos, com onda PCM não silenciosa.
- O Tetris 2 usa o mesmo núcleo de DSP, mas não é embutido no Forja: os projetos seguem separados.

## Limitação

A frequência é nominal e o restante da emulação SPC700/DSP ainda não foi comprovado bit a bit contra SNES original. Hardware Windows e outros ports exigem validação em máquina real.
