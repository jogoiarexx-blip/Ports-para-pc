# Soldiers of Fortune v0.12 crossfeed — Forja65 v0.4.19

- Forja65 v0.4.19 remains the base. No old v0.4.04 files copied over it.
- New generic tool `tools/audit-cfg-progress.py` and 6 regression cases (`tests/audit-cfg-progress-regression.py`). The audit marks more instructions in the same frame as CPU coverage, **not** playable level progress; fails closed on incomplete/invalid CPU failure records.
- Four additional verified CFG targets and one missing CPU-state variant integrated into a **separate Soldiers native PC port**, not hardcoded into the Forja65 general generator:
  - C0:C04F (19 instruction sites, 51 dispatch rows)
  - C0:BFC1 (47 instruction sites, 95 dispatch rows)
  - C0:46EC (172 instruction sites, 345 dispatch rows)
  - C0:3860 (45 instruction sites, 103 dispatch rows)
  - C0:395E [CPU state] (0 instruction sites, 3 dispatch rows)

- No generic CPU/PPU/DMA/SPC700 semantic correction is claimed in this update. New coverage is in the Soldiers project; the new Forja65 functionality is audit and test tooling.
- Native Linux game incremental build passed. Runtime last failure: `$C04711 -> $C0CCD1`.
