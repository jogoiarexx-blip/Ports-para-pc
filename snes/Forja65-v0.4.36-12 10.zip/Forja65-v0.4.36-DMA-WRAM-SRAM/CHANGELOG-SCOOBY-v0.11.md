# Scooby Crossfeed v0.11

- Added ROM-bound OAM same-frame movement audit with 6 assertions.
- Added input trace prefix audit with 5 assertions to prevent invalid A/B comparisons.
- Proved left input (OAM x 53 -> 33, hflip=1); direction reversal (x 33 -> 82); maintained intact SNES execution and control inputs.
- Captured new CFG destinations past v0.10 and regenerated native C++ as applicable.
- Shared v0.11 evidence is under reports/scooby-v11, along with run-to-run hash and position comparisons.
- Collision and first stage completion not verified. Experimental native code, not a standalone Windows executable.
