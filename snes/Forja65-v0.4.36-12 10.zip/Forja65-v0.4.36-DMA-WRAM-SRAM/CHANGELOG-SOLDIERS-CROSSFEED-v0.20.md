# Forja65 v0.4.19 CROSSFEED-MULTIGAME — evolução Soldiers v0.20

A base multigame original e as correções de todos os ramos anteriores foram preservadas.

- Novo instrumento genérico de deltas de WRAM em fim de frame, somente leitura e totalmente desativado sem `FORJA65_WRAM_DELTA_CSV`.
- Janela e quantidade limitada por ambiente: `FORJA65_WRAM_DELTA_START`, `END`, `STEP`, `LIMIT`.
- Novo `tools/wram-delta-audit.py`: agrupa endereços, detecta truncamento, compara alterações entre replays e não confunde variação de WRAM com jogabilidade.
- Testes `tests/wram-delta-audit-regression.py` e `tests/wram-delta-generation-regression.js` passaram.
- O port de Soldiers recebeu quatro novos destinos de CFG; o motor genérico não embute hacks específicos para a ROM e mantém o gerador C++ intacto fora da instrumentação opcional.

**Limitações:** não foi feita comparação com um emulador SNES instrumentado nem reprodução completa no jogo nesta etapa. A origem do contador GET READY não foi determinada e nenhuma variável foi forçada.
