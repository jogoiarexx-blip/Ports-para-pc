# Forja65 v0.4.30 — CFG + WRAM

Base: v0.4.29 CROSSFEED 6 RAMOS. Primeiro incremento da prioridade 1.

## Mudanças
- Dispatcher reconhece cinco instruções de transferência em WRAM: JMP absoluto, JML, JMP (abs), JMP [abs] e JMP (abs,X).
- Saltos respeitam o banco de programa e o wrap de ponteiros. Somente operandos contíguos em WRAM e ponteiros/destinos mapeados em WRAM/ROM são aceitos. Overlays de SRAM e DSP de cartucho são rejeitados antes da leitura.
- A autorização de retorno de JSL é independente da elegibilidade de hooks nativos; sobrevive a saltos encadeados e à retomada por RTI, vinculada ao token e à profundidade de pilha da chamada. É retirada ao consumir ou redirecionar o retorno.
- Preenchimentos reconhecidos: LDA imediato opcional, de 1 a 256 stores absolutos STA/STZ, RTL; acumulador de 8 ou 16 bits; destinos WRAM válidos no banco de dados atual, sem exigir stride uniforme.
- O programa inteiro é validado antes dos efeitos. Stores que atingiriam I/O, o próprio código ou os três bytes do retorno são rejeitados. Código atravessando o fim do banco ou do espelho baixo de WRAM também é rejeitado.
- Retomada dos preenchimentos exige bytes, largura do acumulador, banco de dados e pilha compatíveis. NMI/IRQ continuam atendidas nas fronteiras de instrução.
- Contabilização dos stores inclui os acessos de dados e a largura de 16 bits. O vetor sintético LDA16 + STA16 + STZ16 + STA16 + RTL verifica 188 master clocks sem stalls externos.
- Cache CFG da v0.4.29 é aceito como predecessor auditado: decoder e análise ROM não mudaram. O C++ deve ser regenerado; outra ROM ou versão não auditada continua rejeitada.

## Validação
Execute `node tools/test-cfg-wram-v0430.js` ou `TESTAR-CFG-WRAM-v0.4.30.cmd`.
As 17 regressões dirigidas e os logs estão em reports/validation-v0430/summary.json.
Os novos testes compilam C++20 com -Wall -Wextra -Wpedantic -Werror.
Cobrem transfers encadeados, bancos/espelhos, wrap de ponteiros, overlays, preenchimentos 8/16 bits, flags, mudanças de código/estado, proteção de stack e interrupções antes do salto.
Os dois caminhos novos falharam por ausência de suporte na base antes da implementação. Os casos de cache e de autorização de tail jump também foram verificados primeiro em falha.

## Como usar
Abra o Forja65 desta pasta e gere novamente o projeto do jogo. Depois recompile o port com BUILD-WINDOWS.cmd no projeto gerado.
Projetos/executáveis já gerados não recebem este runtime automaticamente. Ao atualizar um projeto existente, preserve os hints/replays e faça backup do projeto; o cache somente da v0.4.29 é auditado para este salto de versão.
CLI de geração nova: `node tools/forja65.js analyze "jogo.sfc" --out "port-v0430"`.

## Limites
Isto não é recompilação genérica de qualquer programa em RAM. Outros opcodes, chamadas curtas/RTS nos fills, rotinas em modo de emulação, programas com mais de 256 stores e código automodificável continuam fora destes reconhecedores e precisam de tradução adicional.
O algoritmo estático de descoberta de tabelas/destinos ROM permanece o da base; este incremento amplia a execução validada em WRAM e a continuidade do cache CFG.
A ordem de acessos ao barramento continua na granularidade de instrução; este trabalho não implementa precisão por ciclo nem altera o motor PPU/APU/DMA/DSP.
Não foi executado gameplay de ROM comercial nem compilação de game.exe no Windows. Aprovação sintética não demonstra compatibilidade completa de um jogo.
A suíte histórica inteira não foi executada. Restrições antigas de versão permanecem nos testes históricos; em particular, master-cycle-irq-hdma-v029-regression.js rejeita a família 0.4 antes de testar o runtime.

## Integridade
A fonte e os manifestos da v0.4.29 ficam em crossfeed-historico/v0429. As variantes históricas anteriores permanecem no pacote.
Os três manifestos de checksum da raiz são renovados para esta versão, excluindo os próprios manifestos para evitar dependências circulares.
