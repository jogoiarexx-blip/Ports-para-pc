# Forja65 Crossfeed Scooby v0.7

- Auditoria da fronteira CFG estendida para evidencias de runtime com `--from BUILD_DIR`, sem mudar fluxo nem criar instrucoes.
- Hints recentes nao aprendidos e variantes ausentes agora sao identificados mesmo que a auditoria historica passe.
- Enderecos curtos de WRAM reportados no passado sao classificados separadamente, nao tratados como ROM.
- Convergidor mede `duration_ms` e `frames_per_second` por tentativa, com `--prelearn 1` para incorporar evidencias anteriores antes do replay.
- Regressoes especificas de runtime, CFG e preflight adicionadas. Port atualizado, testes e relatorio em ZIP independente.
