# Forja65 v0.3.99 — sincronização HDMA com Tetris 2 v0.4.00

- `forja65-core.js`: runtime C++ gerado distingue `$80` (128 linhas sem repetição) de `$81-$FF` (repetição por linha).
- `$420C` no meio de quadro não reinicializa indevidamente `A2A/NTRL`; somente inicialização de quadro prepara os canais.
- Novo gerador regression `tests/tetris-hdma-v0400-regression.js` compila/roda `tests/fixtures/tetris_hdma_v0400.cpp` sobre runtime emitido a partir de ROM sintética.
- Script Windows `TESTAR-CROSSFEED-TETRIS.cmd` agora inclui o novo teste.
- Regressões de Tetris anteriores (CPU/PPU/DMA/SPC e OBJ) passaram.
- Não se executou a suíte histórica completa do Forja65, nem build Windows, nem comparação com SNES físico nesta rodada.
