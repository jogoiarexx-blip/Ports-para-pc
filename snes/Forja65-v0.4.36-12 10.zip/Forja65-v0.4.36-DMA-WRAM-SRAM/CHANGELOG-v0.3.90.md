# Forja65 0.3.90 — rastreamento real de raster

- Novo `FORJA65_RASTER_TRACE_FRAME=N`: registro opcional do quadro com o mesmo ID pós-incremento de `FORJA65_CAPTURE_FRAME`.
- `raster-segments.csv`: limites x0/x1 por linha e estado de PPU, janelas, scroll, brilho, HDMA.
- `raster-writes.csv`: eventos reais de escrita PPU com ciclo, linha, PC e origem CPU/HDMA.
- `raster-pixels.csv`: propriedade da camada no instante em que cada segmento é renderizado, limitado a saída 256px não entrelaçada.
- `raster-summary.txt`: mismatches entre recomposição instrumentada e cor do framebuffer dentro do MESMO instante.
- Não há mudança de pixels, regras de prioridade, timing da CPU ou HDMA, nem leitura adicional dos registradores de hardware. O diagnóstico é desligado por padrão.
- Teste `node tests/raster-provenance-v0390-regression.js`: compila runtime gerado e confere OBJ/registradores e arquivos.

**Limitação:** o traço só verifica a lógica interna do runtime. Para comparar com o SNES é preciso um frame sincronizado e capturado independentemente.
