@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul || (echo ERRO: instale Node.js. & exit /b 1)
where g++ >nul 2>nul || (echo ERRO: instale g++ C++20 via MSYS2/MinGW. & exit /b 1)
for %%T in (
  tetris-spc-semantics-v0407-regression.js
  tetris-spc-strict-v0412-regression.js
  tetris-apu-dsp-v0405-regression.js
  tetris-scene-timeline-v0415-regression.js
  soldiers-spc-hvbjoy-v0404-regression.js
  soldiers-autojoy-latched-v0404-regression.js
  soldiers-autojoy-vblank-v04-regression.js
  auto-joy-serial-signature-regression.js
  replay-converge-regression.js
  observed-jsl-caller-regression.js
  crossfeed-multigame-generation-smoke.js
) do (
  echo [TESTE] %%T
  node "tests\%%T" || goto :fail
)
echo =========================================
echo CRUZAMENTO MULTIGAME: TESTES SELECIONADOS OK
exit /b 0
:fail
echo FALHA: cruze o codigo somente apos investigar.
exit /b 1
