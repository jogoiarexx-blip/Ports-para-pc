# v0.33 — C2:0831 e regressões de DMA/controles

## Mudanças verificadas
- O destino real `C2:0831`, observado no replay v0.32 vindo de `C0:4402` no quadro 5798, foi gerado dos bytes da ROM de fingerprint `2f095d162726b5ea` e integrado ao dispatcher nativo.
- Foram acrescentados 23 endereços únicos de instrução, 46 entradas de dispatcher, duas variantes de CPU e 23 aliases de ROM; o novo `src/forja_c20831.cpp` compila no Linux.
- Corrigidos dois **testes de regressão**, não o motor: `native_migration_smoke` e `obj_sprite_bank_smoke` faziam DMA em VRAM sem forced blank durante a janela visível, contrariando o comportamento já modelado. A segunda asserção do teste OBJ lia `$4219` antes da conclusão da leitura automática; agora ativa autojoy e aguarda a janela de 4224 ciclos.
- CTest: 24 aprovados, 1 pulado (`equivalence_vectors`); 0 falhas. Antes eram 22 aprovados, 2 falhas, 1 pulado.
- Prova da geração em `analysis/soldiers-crossfeed-v33/C20831-proof.json`; testes Python de integridade de cobertura incluídos nos dois projetos.
- `TESTAR-GET-READY-CFG-v33.sh` e `.cmd` preservam relatórios de cada execução, coletam progresso por quadros e não alteram o estado do jogo.

## Limites da comprovação
- A compilação da rotina nova e a suíte geral foram concluídas.
- A reprodução longa do jogo **não foi concluída nesta execução**; uma captura parcial em Debug alcançou o quadro 3000, portanto ainda não se confirmou no runtime que o novo alvo `C2:0831` foi ultrapassado.
- O contador GET READY `03→02→01→00`, movimento, disparos e início jogável da floresta continuam sem validação. Não declarar gameplay funcional.
- Não houve comparação visual com execução SNES original nesta evolução.

## Próxima prioridade
- Concluir reprodução com progresso até pelo menos o quadro 5798 (sem tempo limite insuficiente) e registrar o próximo PC não resolvido, ou evidências reais da transição do GET READY.
- Se o replay estagnar, isolar custo ou loop no trecho `C2:0831` antes de gerar novas rotinas.
