# Forja65 v0.4.31 — edição crossfeed corrigida

Comparação com v0.4.29.2 identificou duas regressões: o integrador recente buscava handlers apenas em forja_PC.cpp, perdendo generated_NNN.cpp; e advance-latest-runtime-blocker.py perdera seleção de falha STATE e encaminhamento --missing-states. Restaurados os dois caminhos e suas regressões a partir da base anterior.

Mantidos núcleo v0.4.31, perfis SPC, alterações CFG/WRAM v0.4.30 e compatibilidade de cache. VERSION do decoder não mudou, pois o decoder não foi modificado. Logs em reports/validation-crossfeed-20261012 e reports/validation-v0431. Quatro suites Python e 29 regressões dirigidas JS passaram; suite histórica completa não foi executada.

Comparação estática e transferência validada para ZERO/Native não comprovam conclusão de primeira fase.
