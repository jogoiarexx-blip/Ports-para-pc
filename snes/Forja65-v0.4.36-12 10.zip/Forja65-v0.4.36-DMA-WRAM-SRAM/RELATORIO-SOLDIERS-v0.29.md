# v0.29 — integridade da captura GET READY

## Falha encontrada
O script v0.27 reutilizava reports/v27 e podia aceitar artefatos produzidos por execuções anteriores. Sem correspondência temporal mínima entre writers.csv e video.csv, um ranking poderia atribuir causalidade indevida à WRAM.

## Correção
- INVESTIGAR-GET-READY-AUTO-v29.sh exige diretório de saída novo (OUT configurável) para não mesclar evidências.
- get-ready-capture-integrity.py valida cabeçalhos, quadros inteiros não negativos, dados não vazios e interseção dos intervalos de writers e video.
- Novos testes: ausência de dados, períodos não coincidentes, períodos coincidentes e quadros negativos.
- O verificador não afirma que o temporizador nem o gameplay estão resolvidos.

## Validação
- 13 testes Python relacionados a GET READY aprovados no Soldiers.
- 4 testes do novo verificador aprovados no Forja65.
- Bash syntax check aprovado.
- reports/v27 incompleto rejeitado como esperado.
- Sem recompilação integral, nova captura real ou prova de 03→00 nesta sessão.

## Próxima ação
Compilar game, executar INVESTIGAR-GET-READY-AUTO-v29.sh em saída inédita, inspecionar candidatos reais e correlacionar CPU / WRAM / vídeo. C0:F923 permanece sem trace real.
