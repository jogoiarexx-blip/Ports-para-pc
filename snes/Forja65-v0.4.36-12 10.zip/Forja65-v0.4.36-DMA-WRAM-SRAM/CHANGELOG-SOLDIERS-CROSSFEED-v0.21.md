# Forja65 Soldiers Crossfeed v0.21
No gerador ativo `forja65-core.js`, novo rastreador opt-in `FORJA65_WRAM_WRITE_CSV`, `FORJA65_WRAM_WRITE_ADDRS`, `FORJA65_WRAM_WRITE_START/END/MAX`. Captura o escritor em acessos normais de WRAM e pela porta 2180; sem alterar valores. Scripts históricos e snapshots em merge-evidence permanecem intactos. A geração e a execução completas ainda exigem validação.
