# Forja65 Crossfeed v0.23

Adicionado `get-ready-candidate-rank.py` (análise externa e não invasiva de traces WRAM/vídeo) e teste sintético correspondente. Nenhum patch especulativo em C0:F923 nem alterações em CPU, SPC700 ou PPU. Próximas provas exigem traces reais e referência SNES.
