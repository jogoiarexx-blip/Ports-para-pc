# Forja65 Soldiers Crossfeed v0.36

Esta versão preserva o motor v0.35 e fortalece a validação do integrador genérico de fluxos ROM-backed.

- `tools/integrate-observed-flow.py`: exige concordância de E/M/X/C entre observação de runtime e estado decodificado quando esses campos aparecem no proof.json; antes da gravação no port.
- `tools/test_integrate_observed_flow.py`: teste novo para rejeitar estado observado incompatível; **9/9 testes aprovados**.
- Provas e integrações específicas dos 5 destinos de Soldiers estão no pacote Soldiers Native PC v0.36; Forja65 mantém a ferramenta genérica compartilhada.
- Identidade da ROM utilizada no Soldiers: `2f095d162726b5ea`.
- Foram integrados no Soldiers: `$C2:0776`, `$C0:3687`, `$C0:A95C`, `$C0:A40D`, `$C0:84E0`, total de **394 PCs** e **808 entradas**.
- Próximo CFG encontrado em replay: `$C0:7704`, vindo de `$C0:A417`, quadro 5.800.
- Não foi comprovado que o GET READY termina ou que a fase esteja jogável.

O CTest (24 passados, 1 pulado) e a compilação Clang referem-se ao pacote Soldiers; o Forja65 genérico não foi recompilado integralmente nesta rodada.
