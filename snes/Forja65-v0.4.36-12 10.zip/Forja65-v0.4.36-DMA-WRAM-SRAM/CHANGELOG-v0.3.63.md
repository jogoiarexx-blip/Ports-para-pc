# Forja65 v0.3.63 — Hot CFG Call Priority

- Analyzer now puts statically discovered call targets ahead of speculative seeds and unrelated interrupt-vector scans.
- Deduplicates call-site seeds within each CFG function (without conflating distinct CPU decoding states).
- Keeps ROM fingerprint check, runtime-hints, and hardware behavior unchanged.
- New regression test tests call-priority under a restricted global budget.
- Runtime proof remains mandatory: CFG inclusion alone does not establish gameplay.

- **CFG edge safety**: generated code now re-enters the dispatcher when a valid fallthrough is beyond the generated function, instead of silently `return`ing. Includes branch fallthrough, call continuation and ordinary instruction continuation.
- Missing continuation must produce an explicit ROM-bound runtime FLOW hint; no fake 'headless success'.
- Optional `FORJA65_USE_PCH=ON` CMake build flag precompiles the runtime header once for large generated projects.
