# Forja65 v0.3.84 — resultados

- Suite completa `node tools/test.js`: **132/132 PASS**, nenhuma falha. Ver `forja65-tests-v0384.log`.
- Teste dedicado `node tests/rom-tiny-indirect-leaves-v0384-regression.js`: **PASS**. Comprova descoberta de candidatos limitada, sem promover a observação, rejeitando origem inadequada, M=8 e familia acima do limite.
- Teste de cache compatível `node tests/cfg-cache-compatible-v0369-regression.js`: **PASS**. A nova cadeia reusa o cache da mesma ROM sem desabilitar checagens de fingerprint e versão.
- No DKC3, as oito rotinas candidatas ROM geraram labels e dispatcher; apenas três tinham hints de FLOW historicamente observados.
- Limite: essas verificações não comprovam animação ou movimento visual dos Kongs, nem compilação Windows neste ambiente.
