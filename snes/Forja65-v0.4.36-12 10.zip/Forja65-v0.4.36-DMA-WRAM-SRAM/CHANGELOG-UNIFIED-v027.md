# Melhorias acumuladas — v0.4.27

Esta versão compara o pacote unificado v0.4.26 com Soldiers Crossfeed v0.23 e Checkpoint v0.3.98. Forja65 e Tetris continuam em pastas independentes.

| Área | Resultado |
|---|---|
| Novo: escritores WRAM | Registra endereço, valor anterior/novo, PC do escritor, frame, canal de escrita, entrada e NMI. Cobre barramento normal, porta CPU $2180 e porta B-bus $2180. Exige filtro de endereços e permite limitar frames/eventos. |
| Novo: diferenças WRAM | Baseline e diferenças por amostra, intervalo configurável, limites por frame e globais, com resumo e truncamento explícito. Preserva o WRAM_DELTA anterior. |
| Novo: análise | Compara execuções neutras/controladas, correlaciona escritas com vídeo e ordena candidatos ligados à transição GET READY. Ranking fornece pistas; não confirma sozinho o timer ou a causa. |
| Correções da integração | Corrigida geração de strings C++, localização dos testes, repetição dos testes e tratamento passivo de caminhos inválidos. CSVs rejeitam bytes inválidos e amostras duplicadas; escritas múltiplas no mesmo frame continuam válidas. |
| SPC700 preservado | DIV YA,X corrigido no modo corrected, mantendo modo legacy. Verificação anterior percorreu 67.108.864 combinações e vetores fixos. |
| DSP preservado | BRR, interpolação gaussiana, envelopes e KON/KOFF/ENDX, echo, noise, PMON e relógio fracionário de áudio. Saída WinMM/WAV e ferramentas de replay mantidas. |
| Conversor preservado | Validação estrita de hints, identificação da ROM, compatibilidade auditada de caches e integração de múltiplos shards. |

## Decisão sobre Checkpoint
Não identifiquei melhoria adicional exclusiva útil para copiar. Seu núcleo interno é uma base anterior e substituir partes atuais perderia avanços de validação, integração e emulação. Nenhum código desse Checkpoint foi incorporado.

## Validação desta rodada
- Suíte Node: 183/221 aprovados. As 38 falhas coincidem exatamente com as falhas da v0.4.26; nenhuma falha nova. Não se trata de uma suíte integralmente aprovada.
- Validação focada: 15/15 arquivos de teste aprovados; os três novos analisadores têm 13 testes Python aprovados após as correções finais.
- C++ realmente gerado: compilado e executado duas vezes; verificados três canais, PC, limites, janelas, truncamento, relógio e caminhos inválidos.
- Revisão independente identificou o problema de repetição dos testes e fragilidades de CSV; corrigidos e verificados.
- Tetris-2: todos os arquivos idênticos aos da v0.4.26. Os logs/WAVs de 1200 frames e o build Linux nele incluídos são evidência da rodada anterior, não uma nova execução nesta rodada.

Os observadores são desligados por padrão. Esta rodada amplia diagnóstico; não adiciona correção de CPU/PPU nem prova precisão completa do SNES. O pacote contém fontes e scripts de build, sem game.exe Windows pronto.

## Usar os novos diagnósticos
Recompile um port gerado pelo Forja65 desta versão. No cmd do Windows, antes de executá-lo:

```bat
set FORJA65_WRAM_WRITE_CSV=writers.csv
set FORJA65_WRAM_WRITE_ADDRS=7E0010,7E0011
set FORJA65_WRAM_WRITE_START=0
set FORJA65_WRAM_WRITE_END=1200
set FORJA65_WRAM_WRITE_MAX=20000
set FORJA65_WRAM_DIFF_CSV=diff.csv
set FORJA65_WRAM_DIFF_STEP=1
set FORJA65_WRAM_DIFF_MAX_EVENTS=20000
set FORJA65_WRAM_DIFF_MAX_PER_FRAME=256
```

Escolha endereços realmente pertinentes ao jogo. Use nomes de CSV novos para cada execução; os arquivos recebem append. As ferramentas Python ficam em Forja65/tools:

```text
python tools/wram-diff-analyze.py neutral.csv controlled.csv --out comparison.json
python tools/wram-video-correlate.py writers.csv video.csv --out correlation.json
python tools/get-ready-candidate-rank.py writers.csv video.csv --out candidates.json
```

O relatório v0.4.26 e suas evidências permanecem no pacote como histórico. Logs desta rodada: docs/validacao/*v027* e next-*. Integridade: python Forja65/tools/verify-release-v027.py.
