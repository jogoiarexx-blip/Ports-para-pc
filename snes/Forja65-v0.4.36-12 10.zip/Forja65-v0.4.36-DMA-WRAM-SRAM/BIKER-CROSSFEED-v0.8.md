# Forja65 Biker v0.8 — suporte seguro de convergencia

- `tools/replay-converge.js`: distingue retornos STACK-RTS/RTL reais por tipo, PC de origem e destino; evita falsa estagnacao quando ocorre mais de um retorno no mesmo quadro.
- `tools/observed-stack-return.js` e `tools/forja65.js`: retornos ja verificados e persistidos para a mesma ROM e estado CPU nao exigem novo testemunho, mas qualquer destino novo continua exigindo comprovacao exata da pilha e verificacao do opcode da ROM.
- `tools/replay-converge.js`: limpa dados temporarios antes de cada nova tentativa (apos prelearn) e armazena evidencia por rodada, evitando mistura de historicos.
- Testes `replay-converge-regression.js`, `observed-stack-return-v0367-regression.js`, `replay-converge-capture-v04-regression.js` aprovados.

Replays reais de Biker Mice alcancaram 6200 frames e demonstraram GO, aceleracao e mudanca de direcao. O conversor e o game continuam em ZIPs separados.
