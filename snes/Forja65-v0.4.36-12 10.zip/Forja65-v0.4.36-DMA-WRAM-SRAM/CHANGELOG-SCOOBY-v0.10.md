# Scooby-Doo / Forja65 v0.10

- Replay observacional com pulsos de A e teste direcional apos o fim do dialogo.
- `tools/frame-region-diff.js`: comparador de pixels dos arquivos P6 exportados pelo proprio Forja65; emite grade de diferencas e bounding-box, sem prometer controle livre.
- `tools/input-differential-probe.js`: novo estado `INCOMPLETE_REPLAY` e retorno de falha se um replay truncar, travar ou retornar erro de CFG; evita falso positivo de controle.
- Testes: `frame-region-diff-v10-regression.js` e `input-differential-completeness-v10-regression.js`.
- Novos tracers Windows no Scooby para comparar direcional mantendo identicos todos os comandos A anteriores.

Nenhum atalho manual de gameplay nem mudanca arbitraria nas regras da ROM.

## Evidencia real de movimento (Scooby)

Dois replays de 4.350 quadros iguais ate 4.250. O direcional Direito produziu imagem diferente no quadro 4.254. No quadro 4.300, a captura sem Direita mostra Shaggy e Scooby parados, enquanto a captura com Direita mostra ambos caminhando; o sprite OAM slot 0 desloca x=53 -> 80. Isso valida **movimento horizontal**, sem validar colisoes ou conclusao da fase.
