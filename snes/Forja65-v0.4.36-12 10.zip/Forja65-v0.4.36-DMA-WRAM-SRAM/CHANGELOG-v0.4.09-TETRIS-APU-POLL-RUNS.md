# Forja65 v0.4.09 — Tetris CPU/APU poll-run crossfeed
- Novo CSV Q run-length, `polls` e `last_master_cycles`, no runtime C++ que Forja65 gera.
- Mantidas quatro portas CPU/APU com latches separados; preserva modo estável e modos experimentais opt-in.
- Teste `tests/tetris-spc-cpu-poll-runs-v0410-regression.js` gera runtime e compila teste C++.
- Testes Tetris JS selecionados: 14/14 aprovados no Linux. Teste do IPL legado ajustado ao cabeçalho CSV estendido.
- Consulte o pacote Tetris v0.4.10 para captures do quadro 59, limites de timing e replay de 500 quadros.
