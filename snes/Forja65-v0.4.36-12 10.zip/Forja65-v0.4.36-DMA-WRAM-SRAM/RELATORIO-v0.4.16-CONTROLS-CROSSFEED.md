# Forja65 v0.4.16 — Validador de controles incluido na geracao

`forja65-core.js` gera tambem `tools/gameplay_controls_qa.py` em ports C++ novos. O validador usa `FORJA65_INPUT_REPLAY`, capturas PPM e compara baselines com impulsos de controle, rejeitando capturas ausentes, comandos sem efeito e mudancas antes do evento.

**A/B testado com Tetris 2**. Para outros jogos, fornecer trace que leve ao gameplay e configurar as coordenadas ROI apropriadas. O codigo CPU/PPU/DMA/SPC/DSP nao foi alterado nesta revisao. Testes selecionados: 6/6 aprovados, incluindo o codigo gerado por ROM sintetica, PPU/DMA e registradores do SPC700.
