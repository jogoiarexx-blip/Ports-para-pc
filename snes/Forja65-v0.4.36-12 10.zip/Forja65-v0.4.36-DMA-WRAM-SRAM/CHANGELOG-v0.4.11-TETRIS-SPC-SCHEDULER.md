# Forja65 v0.4.11 — Crossfeed Tetris SPC scheduler

- O C++ gerado contém `FORJA65_SPC_SCHEDULER=strict` opcional, com avaliação do custo completo das instruções SPC700, incluindo penalidade de desvios.
- Ao escrever novamente bits de temporizadores já habilitados no `$F1`, o modo `accurate` reinicia estágio 2 e saída; o modo legado preserva comportamento anterior.
- Teste: `node tests/tetris-spc-strict-v0412-regression.js` gera um projeto a partir de ROM sintética, compila em C++ e valida 256 opcodes × 6 estados e o handshake da porta `$F4`.
- Regressões anteriores de PPU, DMA, HDMA, OBJ, SPC700 e APU permaneceram aprovadas.
- **Sem mudança no comportamento padrão**, dependência de hardware virtual permanece; comparação com SNES real é pendente.
