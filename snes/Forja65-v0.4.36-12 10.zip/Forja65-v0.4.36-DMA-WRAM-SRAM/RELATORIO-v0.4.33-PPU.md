# Forja65 v0.4.33 — latches de deslocamento do Mode 7

A correção separa os valores de deslocamento do Mode 7 dos valores normais de BG1. Escritas intercaladas em matrizes, centros e deslocamentos de outros backgrounds passam a produzir o valor esperado para o Mode 7.

## Problema reproduzido

Na v0.4.32, escrever 5 em M7A ($211B), depois 0 em $210D, deixa BG1HOFS em 0. Entretanto M7HOFS deve receber 5, do latch compartilhado com M7A. O renderer usava BG1HOFS e mostrava o texel errado: índice de cor 1 em vez de 6 na cena sintética do teste.

O teste compilou e falhou nesse comportamento antes da correção. O log está em reports/validation-v0433/mode7-baseline-failure.log.

## Mudanças

- m7Hofs e m7Vofs guardam os deslocamentos independentes do Mode 7.
- $210D/$210E atualizam simultaneamente BG1 e Mode 7 com seus respectivos latches anteriores; só depois atualizam os latches.
- Matriz/centro ($211B-$2120) compartilham m7Byte. Os deslocamentos de BG2-BG4 atualizam somente bgOfsByte.
- sampleMode7 usa os novos valores com sinal de 13 bits. A montagem dos valores ocorre independentemente do modo de vídeo selecionado na escrita.
- A cadeia auditada de cache aceita a v0.4.32 e seus predecessores auditados. O decoder e o CFG não mudaram.

## Validação

O teste novo compila o runtime C++ gerado com C++20, -O2, -Wall, -Wextra, -Wpedantic e -Werror. Verifica:

- 50.000 escritas pseudoaleatórias com um modelo independente dos dois latches, dos oito offsets de BG e dos seis registradores de matriz/centro; confere também pixels de uma transformação identidade.
- Dependências de matriz para scroll e de scroll para centro; escritas intercaladas de BG2; deslocamentos com sinal; mudanças de modo; wrap; flips; EXTBG e cor direta.
- Atualização entre segmentos de raster mantendo intactos os pixels já produzidos.
- CPU, DMA e HDMA pelos caminhos nativo/fallback e pelos dois modos de PPU.

A preparação de ppu-bg-tile-regression.js e ppu-sprite-row-regression.js agora também preenche os offsets independentes quando compara a otimização com referências antigas que inicializavam os campos diretamente. As referências históricas não foram alteradas. O teste de tiles continua cobrindo 128 cenas, cinco linhas, dois campos e mutações entre segmentos. O teste de sprite já falhava na base; o relatório da suíte histórica registra esse resultado, sem declarar equivalência inexistente.

A revisão independente examinou o trecho de alteração e a lógica dos latches, sem acesso ao sistema de arquivos. Não encontrou problema crítico ou importante. Não existe serializer de estado da PPU nesta base; os novos campos têm inicialização zero como os demais offsets.

Resultado dirigido: **40/40 regressões passaram**. Esse resultado não significa que todos os testes históricos ou todos os jogos sejam compatíveis.

## Uso

Gere novamente o projeto com esta versão e recompile o port para receber a correção. Execute TESTAR-PPU-v0.4.33.cmd ou `node tools/test-ppu-v0433.js` para o conjunto dirigido. Os resultados estão em reports/validation-v0433/summary.json. A execução da suíte histórica completa e a comparação com a base ficam em historical-comparison.json e nos logs correspondentes.

## Limites

Esta etapa corrige a montagem e seleção dos offsets. A precisão da transformação afim ainda precisa de uma etapa própria: divisão de negativos, truncamento dos produtos e clipping interno não foram corrigidos aqui. Timing de acesso, mosaic do Mode 7 e equivalência com hardware não estão demonstrados por estes testes. Não houve gameplay de ROM comercial nem compilação no Windows.

## Referência

SNESdev, PPU registers, seções M7HOFS, M7VOFS, matrizes e centros: https://snes.nesdev.org/wiki/PPU_registers . A referência descreve a montagem de cada registrador com o byte anterior de mode7_latch e sua interação com BG1.

## Integridade

Fontes e manifestos anteriores estão preservados em crossfeed-historico/v0432. Os três manifestos da raiz são recalculados, excluindo apenas eles próprios para evitar dependência circular.


## Resultado da suíte histórica completa

A v0.4.33 aprovou 200/239 testes. A base v0.4.32 aprovou 199/238. As 39 falhas desta versão também foram reproduzidas na base. Não surgiu falha nova entre os testes históricos. A suíte inteira permanece vermelha; o conjunto dirigido de 40 testes passou.

| Teste histórico com falha | Base v0.4.32 |
|---|---|
| brr-cache-version-v025-regression.js | Falha reproduzida |
| bus-stalls-v032-regression.js | Falha reproduzida |
| cli-trace-framework-regression.js | Falha reproduzida |
| convergence-metadata-v0372-regression.js | Falha reproduzida |
| convergence-pipeline-regression.js | Falha reproduzida |
| cpu-ppu-v016-regression.js | Falha reproduzida |
| cross-game-cpu-flow-v028-regression.js | Falha reproduzida |
| hd-integer-scale-v032-regression.js | Falha reproduzida |
| inline-indexed-table-v0312-regression.js | Falha reproduzida |
| instruction-mastercycles-v031-regression.js | Falha reproduzida |
| interrupt-stack-v039-regression.js | Falha reproduzida |
| local-computed-jump-run-v0311-regression.js | Falha reproduzida |
| long-controlflow-pb-v0314-regression.js | Falha reproduzida |
| master-cycle-irq-hdma-v029-regression.js | Falha reproduzida |
| native-dependency-audit-v0327-regression.js | Falha reproduzida |
| native-hardware-cutover-v0329-regression.js | Falha reproduzida |
| native-hardware-migration-v0328-regression.js | Falha reproduzida |
| native-host-foundation-v0322-regression.js | Falha reproduzida |
| native-oracle-v0350-regression.js | Falha reproduzida |
| native-scene-capture-v0323-regression.js | Falha reproduzida |
| obj-bank-v0380-regression.js | Falha reproduzida |
| obj-oam-order-v0389-regression.js | Falha reproduzida |
| oracle-runtime-learning-v0325-regression.js | Falha reproduzida |
| ppu-priority-hires-v027-regression.js | Falha reproduzida |
| ppu-sprite-row-regression.js | Falha reproduzida |
| renderer-timing-flow-v023-regression.js | Falha reproduzida |
| resumable-dispatch-v037-regression.js | Falha reproduzida |
| rom-mirror-spc-state-v038-regression.js | Falha reproduzida |
| runtime-progress-v035-regression.js | Falha reproduzida |
| spc-port-isolation-v0313-regression.js | Falha reproduzida |
| stack-trampoline-summary-v0310-regression.js | Falha reproduzida |
| stackless-coroutine-regression.js | Falha reproduzida |
| state-aware-cfg-v022-regression.js | Falha reproduzida |
| state-summary-v036-regression.js | Falha reproduzida |
| subscanline-raster-v030-regression.js | Falha reproduzida |
| tail-vector-propagation-v0315-regression.js | Falha reproduzida |
| tetris-hardware-v0397-regression.js | Falha reproduzida |
| tetris-obj-crossfeed-v0398-regression.js | Falha reproduzida |
| unified-cache-v026-regression.js | Falha reproduzida |
