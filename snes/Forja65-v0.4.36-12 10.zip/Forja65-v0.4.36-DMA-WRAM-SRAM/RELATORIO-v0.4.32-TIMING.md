# Forja65 v0.4.32 — ordem temporal CPU/APU/DMA

Base: v0.4.31 SPC PERFIL. Primeiro incremento da prioridade temporização.

## Problema reproduzido
O runtime avançava CPU e APU por todo o orçamento solicitado antes de processar eventos de vídeo/HDMA que ocorriam no meio desse orçamento. Com isso, um comando enviado pelo HDMA ao SPC700 chegava depois de o SPC já ter executado clocks que deveriam acontecer após o comando.
No teste de eco de portas APU, avanço em lote e avanço em clocks individuais produziam estados diferentes na base. O teste de custo DMA também falhou antes da implementação.

## Mudanças
- advanceCpuMasterCycles avança CPU/APU até a próxima fronteira de evento, processa o evento e seus stalls recursivos, e só então continua o orçamento restante.
- Os contadores cpuMasterClock, lastInstructionMasterCycles e apu.masterObserved incluem o mesmo tempo transcorrido. Clocks de refresh/HDMA continuam contabilizados uma única vez.
- DMA com máscara não nula cobra oito master clocks comuns antes de executar canais. Continuam oito clocks por canal e oito por byte. Máscara zero não cobra setup.
- Nenhuma instrução, flag, rotina CFG ou padrão de transferência DMA/HDMA foi substituído.
- A cadeia auditada do cache aceita v0.4.31, v0.4.30 e v0.4.29, regenerando o C++ da versão atual.

## Casos novos verificados
- HDMA envia $CC a $2140 enquanto o SPC faz eco do port. Um lote de 1.600 clocks, 1.600 avanços unitários e lotes irregulares chegam ao mesmo estado CPU/APU/HDMA.
- O envio do comando é registrado em 1.124 master clocks, dentro do modelo HDMA existente (evento 1.106 + setup 18), antes de processar o restante do lote.
- CPU totaliza 1.666 clocks nesse caso: orçamento 1.600 + refresh 40 + HDMA 26. Caminhos native e fallback conferem.
- Avanços de 400.000 clocks e lotes de 997 clocks conferem após cruzar linhas e um quadro.
- DMA de 200 bytes atravessando o evento HDMA conserva o timestamp de 1.124 clocks e totaliza 1.682 clocks (DMA 1.616 + refresh 40 + HDMA 26).
- DMA de quatro bytes para APU publica as escritas nos clocks 16, 24, 32 e 40; termina no clock 48.
- Máscaras de 0, 1, 2 e 8 canais conferem custos, contadores e consumo dos tamanhos, em native/fallback.

## Manutenção de teste
O teste histórico dma-forensics-v0386-regression.js esperava escrita em VRAM durante imagem ativa. Essa falha foi reproduzida também na base v0.4.31. Sua preparação agora força blanking antes de testar OAM/VRAM, condição válida para esse teste de observadores.
A preparação corrigida passa na base e na v0.4.32. A proteção de escrita em VRAM durante imagem ativa permanece intacta e é verificada separadamente.
Os resultados registram a falha inicial e a revalidação após corrigir somente a preparação do teste.

## Como usar
Abra o Forja65 desta pasta, gere novamente o projeto e recompile o port. Executáveis anteriores não recebem a alteração automaticamente.
Os launchers reference/legacy do SPC700 da v0.4.31 permanecem disponíveis nos projetos gerados.
Execute TESTAR-TIMING-v0.4.32.cmd ou `node tools/test-timing-v0432.js` para as 38 regressões dirigidas. Os scripts exigem Node e compilador C++ disponíveis.
Logs e relatório: reports/validation-v0432/summary.json. Os testes novos compilam o runtime gerado com C++20 -O2 -Wall -Wextra -Wpedantic -Werror.

## Limites
Este incremento corrige ordem de eventos e um custo DMA conhecido; não implementa todos os ciclos internos do hardware.
Permanecem pendentes alinhamento DMA ao barramento, ciclo adicional após STA $420B, custos completos de descritores/ponteiros HDMA e arbitragem de canais compartilhados em todas as situações.
Multiplicação/divisão da CPU ainda disponibilizam o resultado imediatamente. Delays e resultados intermediários dessa ALU precisam de uma etapa própria.
Acesso da CPU ainda é agrupado por instrução. Interleave SPC/DSP e equivalência sonora não foram implementados; os testes de consistência usam o estado do SPC e contadores, sem demonstrar invariância de PCM.
Não foi executado gameplay de ROM comercial nem build Windows. A suíte histórica inteira não foi executada; o escopo é o conjunto dirigido de 38 testes e as revalidações registradas.
A revisão independente cobriu o trecho de alteração e sua lógica de ordem/contabilização, não equivalência completa com hardware.

## Referências de timing
Anomie, SNES Timing Doc: https://github.com/naffnuff/SnesEmulator/blob/master/doc/Anomie%27s%20SNES%20Timing%20Doc
O custo comum DMA de 8 clocks foi separado do custo por canal/byte. Não se inferiu, com isso, que o alinhamento e todos os custos restantes estejam implementados.

## Integridade
Fontes e manifestos da base estão preservados em crossfeed-historico/v0431. Os manifestos da raiz são renovados excluindo somente os próprios manifestos.
