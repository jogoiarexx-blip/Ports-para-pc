Forja65 0.3.43.1-pea-cleanup-dispatch - TETRIS 2

Projeto C++ para migracao incremental. CPU 65C816 recompilada = TRANSLATED. PPU state-only, DMA/HDMA B-bus, SPC700/DSP virtual e packs ROM continuam dependencias de hardware/dados. Apenas substituicoes host validadas contam como NATIVE. O native score permanece nao medido.

Edite src/native_hooks.cpp para registrar implementacoes host nas entradas de rotina descobertas. FORJA65_EXECUTION=reference ignora os hooks. Retorne os master clocks originais do corpo + RTS/RTL; o dispatcher cuida da pilha de retorno. Hooks sao aplicados a JSR/JSL, nunca automaticamente a interrupcoes, jumps locais ou labels de retomada.

O trace precisa de cmake -DFORJA65_ENABLE_TRACE=ON e FORJA65_TRACE=forja-trace.csv. Limite padrao 250000 eventos; o rodape registra descartes e finalizacao. Importe o CSV na interface Forja65 ou no CLI para atualizar native-map.json. Trace limitado ou interrompido nao prova cobertura completa.

analysis/function-analysis.json preserva o CFG gerado; analysis/native-map.json registra dependencias observadas por rotina e chamadas. profiles/game_config.json vincula nomes/aliases e heuristicas ao fingerprint da ROM. reports/compatibility-report.json distingue traducao e fallback. ForjaIR/ForjaRenderer sao uma base de palette/scroll host; composicao completa ainda nao esta implementada.

BUILD-WINDOWS.cmd compila o port. O runtime pode precisar de assets/cart-data.bin ou native ROM pack: remover o arquivo ROM nao elimina automaticamente sua representacao de dados.
