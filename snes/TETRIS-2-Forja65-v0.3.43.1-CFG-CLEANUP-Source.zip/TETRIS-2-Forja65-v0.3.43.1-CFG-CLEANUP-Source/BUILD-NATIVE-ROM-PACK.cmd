@echo off
setlocal
cd /d "%~dp0"
if not exist forja65-rom-read-ranges.txt (echo Rode RUN-ROM-PROFILE.cmd primeiro.& pause & exit /b 2)
set TOOL=build\Release\rom_pack_builder.exe
if not exist "%TOOL%" set TOOL=build\rom_pack_builder.exe
if not exist "%TOOL%" (echo Compile primeiro com BUILD-WINDOWS.cmd.& pause & exit /b 3)
"%TOOL%" assets\cart-data.bin forja65-rom-read-ranges.txt assets\native-rom-data.bin
if errorlevel 1 (pause & exit /b 4)
echo Criado assets\native-rom-data.bin
pause
