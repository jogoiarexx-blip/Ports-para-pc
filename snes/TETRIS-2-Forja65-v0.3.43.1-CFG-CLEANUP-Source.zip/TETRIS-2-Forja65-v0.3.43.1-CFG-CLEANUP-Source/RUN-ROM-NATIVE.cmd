@echo off
setlocal
cd /d "%~dp0"
if not exist assets\native-rom-data.bin (echo Crie o pack com BUILD-NATIVE-ROM-PACK.cmd.& pause & exit /b 2)
set FORJA65_ROM_MODE=native
set FORJA65_PPU_MODE=state
set FORJA65_DMA_MODE=native
set FORJA65_AUDIO_MODE=native
set FORJA65_NATIVE_AUDIT=1
set FORJA65_HEADLESS=1
set FORJA65_HEADLESS_FRAMES=%~1
if "%FORJA65_HEADLESS_FRAMES%"=="" set FORJA65_HEADLESS_FRAMES=600
call RUN-WINDOWS.cmd
pause
