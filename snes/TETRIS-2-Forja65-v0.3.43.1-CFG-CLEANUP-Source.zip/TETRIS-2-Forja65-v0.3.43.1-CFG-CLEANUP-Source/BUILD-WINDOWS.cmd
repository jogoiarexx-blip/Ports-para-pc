@echo off
setlocal
cd /d "%~dp0"
where cmake >nul 2>nul || (echo ERRO: CMake nao encontrado no PATH. & pause & exit /b 1)
cmake -S . -B build-win -G "Visual Studio 17 2022" -A x64 || goto :err
cmake --build build-win --config Release --target game runtime_smoke scene_capture_smoke oracle_learning_smoke deterministic_input_smoke native_dependency_smoke native_migration_smoke rom_pack_builder equivalence_runner framework_smoke || goto :err
ctest --test-dir build-win -C Release --output-on-failure || goto :err
if not exist bin mkdir bin
copy /Y build-win\Release\game.exe bin\game.exe >nul
xcopy /E /I /Y assets bin\assets >nul
copy /Y RUN-WINDOWS.cmd bin\RUN-WINDOWS.cmd >nul
copy /Y RUN-ORACLE.cmd bin\RUN-ORACLE.cmd >nul
copy /Y RUN-HEADLESS.cmd bin\RUN-HEADLESS.cmd >nul
copy /Y RUN-INPUT-RECORD.cmd bin\RUN-INPUT-RECORD.cmd >nul
copy /Y RUN-INPUT-REPLAY.cmd bin\RUN-INPUT-REPLAY.cmd >nul
copy /Y forja65-build-manifest.txt bin\forja65-build-manifest.txt >nul
echo.
echo OK: bin\game.exe
pause
exit /b 0
:err
echo.
echo FALHA NO BUILD NATIVO. Veja as mensagens acima.
pause
exit /b 1
