@echo off
setlocal
cd /d "%~dp0"
set TRACE=%~1
if "%TRACE%"=="" set TRACE=forja65-input.trace
if not exist "%TRACE%" (echo Trace nao encontrado: %TRACE% & pause & exit /b 2)
set FORJA65_INPUT_REPLAY=%TRACE%
set FORJA65_FRAME_HASHES=1
if exist game.exe goto run
if exist bin\game.exe (cd bin & goto run)
echo Execute BUILD-WINDOWS.cmd primeiro.
pause
exit /b 1
:run
game.exe
exit /b %ERRORLEVEL%
