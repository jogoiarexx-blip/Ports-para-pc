@echo off
setlocal
cd /d "%~dp0"
set FRAME=%~1
if "%FRAME%"=="" set FRAME=1
set FORJA65_HEADLESS=1
set FORJA65_HEADLESS_FRAMES=%FRAME%
set FORJA65_CAPTURE_FRAME=%FRAME%
set FORJA65_CAPTURE_DIR=scene-capture
set FORJA65_CAPTURE_STOP=1
if exist game.exe goto run
if exist bin\game.exe (cd bin & goto run)
if exist build-win\Release\game.exe (cd build-win\Release & goto run)
echo Execute BUILD-WINDOWS.cmd primeiro.
pause
exit /b 1
:run
game.exe
set CODE=%ERRORLEVEL%
echo.
if exist forja65-scene-capture.txt type forja65-scene-capture.txt
if not "%CODE%"=="0" (if exist forja65-last-error.txt type forja65-last-error.txt & pause)
exit /b %CODE%
