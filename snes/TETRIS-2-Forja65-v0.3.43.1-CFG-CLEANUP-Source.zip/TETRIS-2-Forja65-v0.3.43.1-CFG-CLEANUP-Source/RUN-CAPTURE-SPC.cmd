@echo off
setlocal
cd /d "%~dp0"
set FRAME=%~1
if "%FRAME%"=="" set FRAME=300
set /a LIMIT=FRAME+2
set FORJA65_CAPTURE_SPC_FRAME=%FRAME%
set FORJA65_CAPTURE_SPC_STOP=1
set FORJA65_HEADLESS=1
set FORJA65_HEADLESS_FRAMES=%LIMIT%
call RUN-WINDOWS.cmd
echo Captura: forja65-spc-capture\spc-ram.bin + spc-capture.txt
pause
