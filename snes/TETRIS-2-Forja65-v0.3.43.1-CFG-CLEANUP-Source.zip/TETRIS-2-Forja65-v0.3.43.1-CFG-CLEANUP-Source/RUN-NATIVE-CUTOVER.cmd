@echo off
setlocal
cd /d "%~dp0"
set FORJA65_PPU_MODE=state
set FORJA65_DMA_MODE=native
set FORJA65_AUDIO_MODE=native
set FORJA65_ROM_MODE=hybrid
set FORJA65_NATIVE_AUDIT=1
set FORJA65_AUDIO_DUMP=1
set FORJA65_HEADLESS=1
set FORJA65_HEADLESS_FRAMES=%~1
if "%FORJA65_HEADLESS_FRAMES%"=="" set FORJA65_HEADLESS_FRAMES=1200
if exist forja65-native-dependency.csv del /q forja65-native-dependency.csv
if exist forja65-native-dependency-report.txt del /q forja65-native-dependency-report.txt
call RUN-WINDOWS.cmd
echo.
echo CUTOVER concluido. Verifique PPU_VIRTUAL_HW, APU_VIRTUAL_HW, DSP_VIRTUAL_HW, DMA fallback e ROM fallback no relatorio.
pause
