@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set FRAMES=%~1
if "%FRAMES%"=="" set FRAMES=1200
set GAME=bin\game.exe
if not exist "%GAME%" set GAME=build-win\Release\game.exe
if not exist "%GAME%" (echo Execute BUILD-WINDOWS.cmd primeiro.& pause & exit /b 2)
set FORJA65_HEADLESS=1
set FORJA65_HEADLESS_FRAMES=%FRAMES%
set FORJA65_ROM_MODE=cart
set FORJA65_ROM_PROFILE=1
if exist forja65-rom-read-ranges.txt del /q forja65-rom-read-ranges.txt
"%GAME%" || (echo Falha durante profile.& pause & exit /b 3)
set TOOL=build-win\Release\rom_pack_builder.exe
if not exist "%TOOL%" set TOOL=build\Release\rom_pack_builder.exe
if not exist "%TOOL%" set TOOL=build\rom_pack_builder.exe
if not exist "%TOOL%" (echo rom_pack_builder nao encontrado. Recompile.& pause & exit /b 4)
"%TOOL%" assets\cart-data.bin forja65-rom-read-ranges.txt assets\native-rom-data.bin || (pause & exit /b 5)
set FORJA65_ROM_PROFILE=
set FORJA65_ROM_MODE=native
set FORJA65_PPU_MODE=state
set FORJA65_DMA_MODE=native
set FORJA65_AUDIO_MODE=native
set FORJA65_NATIVE_AUDIT=1
"%GAME%" || (echo Pack ainda incompleto. Veja forja65-native-rom-missing.txt.& pause & exit /b 6)
echo ROM convergence PASS para %FRAMES% frames.
pause
