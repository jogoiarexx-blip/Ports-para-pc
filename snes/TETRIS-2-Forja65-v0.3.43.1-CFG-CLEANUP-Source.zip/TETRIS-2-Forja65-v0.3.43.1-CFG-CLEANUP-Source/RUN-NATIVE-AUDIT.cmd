@echo off
setlocal
cd /d "%~dp0"
set FORJA65_HEADLESS=1
set FORJA65_HEADLESS_FRAMES=%~1
if "%FORJA65_HEADLESS_FRAMES%"=="" set FORJA65_HEADLESS_FRAMES=600
set FORJA65_NATIVE_AUDIT=1
if exist forja65-native-dependency.csv del /q forja65-native-dependency.csv
if exist forja65-native-dependency-report.txt del /q forja65-native-dependency-report.txt
call RUN-WINDOWS.cmd
echo.
echo Auditoria: forja65-native-dependency.csv e forja65-native-dependency-report.txt
pause
