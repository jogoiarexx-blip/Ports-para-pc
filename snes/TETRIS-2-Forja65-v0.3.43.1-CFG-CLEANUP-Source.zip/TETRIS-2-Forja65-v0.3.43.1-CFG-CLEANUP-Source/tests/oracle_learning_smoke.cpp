#include "runtime.hpp"
#include <filesystem>
#include <fstream>
#include <iostream>
#include <string>
int main(){namespace fs=std::filesystem;try{fs::remove("forja65-oracle-hints.txt");fs::remove("forja65-runtime-hints.txt");fs::remove("forja65-oracle-observations.log");SnesRuntime hw("assets/cart-data.bin",MapperKind::LoROM,0u,10u,0u,CartChip::None,"oracle-smoke.srm",1u,true);CpuState cpu;cpu.e=false;cpu.m8=false;cpu.x8=true;cpu.c=true;cpu.pb=0x80;hw.appendRuntimeHint(0x808000u,0x808123u,cpu,"FLOW");hw.appendRuntimeHint(0x808000u,0x808123u,cpu,"FLOW");std::ifstream in("forja65-oracle-hints.txt");std::string line,only;unsigned lines=0;while(std::getline(in,line))if(!line.empty()){lines++;only=line;}if(lines!=1)return 4;if(only.find("rom="+hw.cartHashHex()+" ")!=0)return 6;if(!fs::exists("forja65-oracle-observations.log")||fs::file_size("forja65-oracle-observations.log")==0)return 5;std::cout<<"FORJA65_ORACLE_LEARNING_SMOKE_OK unique="<<lines<<" rom="<<hw.cartHashHex()<<"\n";return 0;}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 2;}}
