#include "runtime.hpp"
#include <iostream>
int main(){try{SnesRuntime hw("assets/cart-data.bin",MapperKind::LoROM,0u,10u,0u,CartChip::None,"runtime-smoke.srm",1u,true);if(hw.cart.empty()||hw.framebuffer.empty())return 3;if(hw.cartHashHex()!="8c0b44eecc03e2e1"){std::cerr<<"ROM fingerprint mismatch "<<hw.cartHashHex()<<" expected 8c0b44eecc03e2e1\n";return 4;}std::cout<<"FORJA65_RUNTIME_SMOKE_OK cart="<<hw.cart.size()<<" refresh="<<hw.hostRefreshHz()<<" rom=8c0b44eecc03e2e1\n";return 0;}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 2;}}
