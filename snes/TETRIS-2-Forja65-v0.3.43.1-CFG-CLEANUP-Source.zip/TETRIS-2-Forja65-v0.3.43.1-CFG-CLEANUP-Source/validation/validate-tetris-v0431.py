from pathlib import Path
import subprocess,os,shutil,json
r=Path.cwd();p=r/'tetris-v0431';v=p/'validation';results=[]
cases=[('normal',12000,'input-normal.txt',v/'baseline-normal-12000-complete'),
       ('pause-retry',6200,'input-pause-retry.txt',r/'tetris-v043/validation/pause-retry-v043-6200'),
       ('versus-com',3200,'input-versus-com.txt',r/'tetris-v043/validation/versus-com-3200')]
for name,frames,replay,baseline in cases:
 d=v/f'{name}-v0431-{frames}'
 if name!='normal':
  d.mkdir();shutil.copytree(p/'assets',d/'assets')
 e=dict(os.environ,FORJA65_HEADLESS='1',FORJA65_HEADLESS_FRAMES=str(frames),FORJA65_ROM_MODE='cart',FORJA65_INPUT_REPLAY=str(v/replay),FORJA65_WATCHDOG_INSTRUCTIONS='300000000',FORJA65_FRAME_HASHES='1')
 if name!='normal':
  q=subprocess.run([str(p/'build/game')],cwd=d,env=e,capture_output=True,text=True,timeout=240);(d/'run.log').write_text(q.stdout+q.stderr);assert q.returncode==0,q.stdout+q.stderr
 qa=dict(x.split('=',1) for x in (d/'forja65-qa-status.txt').read_text().splitlines() if '=' in x)
 assert qa['frames']==str(frames) and qa['new_oracle_hints']=='NO' and qa['ppu_forced_blank']=='0'
 hashes=(d/'forja65-frame-hashes.txt').read_bytes();assert len(hashes.splitlines())==frames
 oldhashes=(baseline/'forja65-frame-hashes.txt').read_bytes();assert len(oldhashes.splitlines())==frames,name+' incomplete baseline'
 assert hashes==oldhashes,name+' divergence'
 oldqa=dict(x.split('=',1) for x in (baseline/'forja65-qa-status.txt').read_text().splitlines() if '=' in x);assert qa==oldqa,name+' QA divergence'
 results.append({'scenario':name,'frames':frames,'hashes':'IDENTICAL','all_qa_fields':'IDENTICAL','qa':qa})
 print(name,'PASS',frames,'all hashes and QA identical',flush=True)
(v/'comparison.json').write_text(json.dumps(results,indent=2)+'\n')
print('PASS total 21400 frames, three replays, no new hints',flush=True)
