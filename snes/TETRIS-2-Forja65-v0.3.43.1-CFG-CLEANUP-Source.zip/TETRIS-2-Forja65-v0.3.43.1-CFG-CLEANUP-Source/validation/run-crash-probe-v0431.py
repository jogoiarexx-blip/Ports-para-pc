from pathlib import Path
import subprocess,os,shutil,sys
r=Path.cwd();version=sys.argv[1];p=r/('tetris-v043' if version=='baseline' else 'tetris-v0431');v=r/'tetris-v0431/validation';d=v/('crash-probe-'+version+'-verified');d.mkdir();shutil.copytree(p/'assets',d/'assets')
objects=sorted((p/'build/CMakeFiles/forja65_generated.dir/src').glob('*.o'));assert objects
# Match the object library's trace layout; leave assertions enabled in the probe.
c=subprocess.run(['g++','-std=c++20','-O1','-DFORJA65_ENABLE_TRACE=0','-Wall','-Wextra','-Werror','-I'+str(p/'src'),str(v/'crash-jump-probe.cpp'),*[str(x) for x in objects],'-o',str(d/'probe')],capture_output=True,text=True);(d/'build.log').write_text(c.stdout+c.stderr);assert c.returncode==0,c.stderr
q=subprocess.run([str(d/'probe')],cwd=d,env=dict(os.environ,FORJA65_HEADLESS='1'),capture_output=True,text=True,timeout=30);(d/'run.log').write_text(q.stdout+q.stderr)
print(version,'exit',q.returncode);print(q.stdout+q.stderr)
if version=='baseline':
 assert q.returncode==2 and '8577371' in q.stderr
 assert 'target=82e15b from=82e0f6' in (d/'forja65-runtime-hints.txt').read_text()
else:
 assert q.returncode==0 and 'PASS 82E0F6' in q.stdout
 assert not (d/'forja65-runtime-hints.txt').exists() or not (d/'forja65-runtime-hints.txt').read_text().strip()
