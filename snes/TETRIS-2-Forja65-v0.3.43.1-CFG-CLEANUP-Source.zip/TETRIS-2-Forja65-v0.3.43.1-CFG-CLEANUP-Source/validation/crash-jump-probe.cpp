#include "generated.hpp"
#include <cassert>
#include <iostream>
// Isolated reconstruction of the CPU state at the reported indirect jump.
// WRAM/PPU are controlled fixtures, not a complete snapshot of frame 9222.
int main(){
  SnesRuntime hw("assets/cart-data.bin",MapperKind::LoROM);CpuState cpu;
  cpu.e=false;cpu.m8=false;cpu.x8=false;cpu.c=false;cpu.z=false;cpu.n=false;
  cpu.a=4;cpu.x=4;cpu.y=0x1f8;cpu.d=0;cpu.pb=0x82;cpu.db=0x7e;cpu.s=0x1fcb;
  cpu.push16Value(hw,0xbeee);cpu.push8Value(hw,0x80);cpu.push16Value(hw,0xe0f8);
  hw.pushNativeReturn(0x82beef,false);
  hw.ram[0x61]=0x20; // cleanup restores X from DP $61
  // Keep the handler's controlled data separate from the control variables.
  hw.ram[0x67]=0;hw.ram[0x68]=0x40;
  // Handler sees zeros at $7E4000+Y and traverses Y down to -2.
  try{forja65_dispatch(cpu,hw,0x82e0f6,0x82e0f3);}
  catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 2;}
  std::cerr<<std::hex<<"X="<<cpu.x<<" Y="<<cpu.y<<" DB="<<unsigned(cpu.db)<<" S="<<cpu.s<<"\n";
  assert(cpu.x==0x20&&cpu.y==0xfffe&&cpu.db==0x80&&cpu.s==0x1fcb);
  assert(hw.ram[0x2fc]==0xff&&hw.ram[0x2fd]==0xff&&hw.nativeReturns.empty());
  assert(!hw.dispatchPending);
  std::cout<<"PASS 82E0F6 X=4 -> 82E15B, handler loop, synthetic return, cleanup and outer return\n";
}
