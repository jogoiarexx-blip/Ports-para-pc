@echo off
setlocal
cd /d "%~dp0"
set "HTML=%CD%\Forja65-Portable.html"
set "EDGE="
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" set "EDGE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if not defined EDGE if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" set "EDGE=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
if not defined EDGE if exist "%LocalAppData%\Microsoft\Edge\Application\msedge.exe" set "EDGE=%LocalAppData%\Microsoft\Edge\Application\msedge.exe"
for /f "usebackq delims=" %%U in (`powershell -NoProfile -ExecutionPolicy Bypass -Command "$p=(Resolve-Path -LiteralPath '%HTML%').Path; [Uri]::new($p).AbsoluteUri"`) do set "URL=%%U"
if defined EDGE (
  start "Forja65" "%EDGE%" --app="%URL%" --start-maximized --no-first-run
  exit /b 0
)
echo Microsoft Edge nao encontrado. Abrindo o HTML no navegador padrao como fallback.
start "" "%HTML%"
