// BEGIN FORJA65 GENERATED FRAMEWORK BUNDLE
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;root.Forja65Analysis=api;})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';
const fields=['seq','frame','routine','pc','kind','space','address','value','source'];
const categories=new Set('PLAYER ENEMY OBJECT PHYSICS COLLISION CAMERA LEVEL MAP UI HUD MENU SAVE AUDIO RENDER TRANSITION SCRIPT UNKNOWN'.split(' '));
function addr(v){if(typeof v==='number'&&Number.isInteger(v)&&v>=0&&v<=0xffffff)return v;if(typeof v==='string'&&/^(?:0x|\$)?[0-9a-fA-F]{1,6}$/.test(v)){const n=parseInt(v.replace(/^(0x|\$)/,''),16);if(n<=0xffffff)return n;}throw new Error('Invalid SNES address: '+v);}
function hx(v){return v.toString(16).toUpperCase().padStart(6,'0');}
function normalizeProfile(p={},rom){if(p.schema!==undefined&&p.schema!==1)throw new Error('Unsupported profile schema');if(Object.keys(p).length&&!p.rom)throw new Error('Profile requires ROM fingerprint');if(p.rom&&p.rom!==rom)throw new Error('Profile ROM fingerprint mismatch');const symbols={};for(const [k,v]of Object.entries(p.symbols||{})){const n=addr(k);const s=typeof v==='string'?{name:v}:v;if(!s||typeof s.name!=='string'||!s.name.trim())throw new Error('Symbol requires name');if(s.category&&!categories.has(s.category))throw new Error('Invalid category: '+s.category);symbols[hx(n)]={name:s.name,aliases:Array.isArray(s.aliases)?s.aliases.map(String):[],category:s.category||'UNKNOWN'};}return {schema:1,rom,symbols,heuristics:{render:true,audio:true,save:true,...p.heuristics}};}
function validateEvent(e){for(const k of ['seq','frame','routine','pc','address','value'])if(!Number.isSafeInteger(e[k])||e[k]<0)throw new Error('Invalid trace field '+k);for(const k of ['routine','pc','address'])if(e[k]>0xffffff)throw new Error('Trace address outside SNES range');for(const k of ['kind','space','source'])if(typeof e[k]!=='string'||!/^[A-Za-z0-9_]+$/.test(e[k]))throw new Error('Invalid trace field '+k);return e;}
function parseTrace(input){if(input&&typeof input==='object'){if(input.schema!==undefined&&input.schema!==1)throw new Error('Unsupported trace schema');if(!Array.isArray(input.events))throw new Error('Trace events missing');return {schema:1,rom:input.rom||'',dropped:input.dropped||0,complete:input.complete===true,events:input.events.map(e=>validateEvent({...e}))};}const text=String(input||'').trim();if(text.startsWith('{'))return parseTrace(JSON.parse(text));let rom='',dropped=0,complete=false,header=null;const events=[];for(const l of text.split(/\r?\n/)){if(!l.trim())continue;if(l.startsWith('#')){const r=l.match(/\brom=([0-9a-f]+)\b/i),d=l.match(/\bdropped=(\d+)/);if(r)rom=r[1];if(d)dropped=Number(d[1]);if(l.includes('# written=')||/\bcomplete=1\b/.test(l))complete=true;continue;}const row=l.split(',');if(!header){header=row;if(header.join(',')!==fields.join(','))throw new Error('Invalid ForjaTrace CSV header');continue;}if(row.length!==fields.length)throw new Error('Invalid ForjaTrace CSV row');const e={};fields.forEach((k,i)=>{e[k]=i<4||i===6||i===7?Number(row[i]):row[i];});events.push(validateEvent(e));}return {schema:1,rom,dropped,complete,events};}
function exportTrace(events,format='json',meta={}){const t=parseTrace({schema:1,complete:true,...meta,events});if(format==='json')return JSON.stringify(t,null,2)+'\n';if(format==='csv')return '# FORJA_TRACE 1 rom='+t.rom+' dropped='+t.dropped+' complete='+(t.complete?1:0)+'\n'+fields.join(',')+'\n'+t.events.map(e=>fields.map(k=>e[k]).join(',')).join('\n')+'\n';if(format==='txt')return '# FORJA_TRACE 1 rom='+t.rom+' dropped='+t.dropped+' complete='+(t.complete?1:0)+'\n'+t.events.map(e=>`frame=${e.frame} fn_${hx(e.routine)} pc=$${hx(e.pc)} ${e.kind} ${e.space} $${hx(e.address)} value=${e.value} source=${e.source}`).join('\n')+'\n';throw new Error('Trace format must be json, csv or txt');}
function buildNativeMap(rom,a,input=null,p={}){const hash=a.romFingerprint||rom.fingerprint;if(!hash)throw new Error('Analysis ROM fingerprint missing');const profile=normalizeProfile(p,hash),trace=input?parseTrace(input):{events:[],rom:'',dropped:0};if(input&&trace.rom!==hash)throw new Error('Trace ROM fingerprint mismatch');const nodes=new Map();function get(pc){pc=addr(pc);if(!nodes.has(pc)){const s=profile.symbols[hx(pc)];nodes.set(pc,{address:hx(pc),name:s?s.name:'fn_'+hx(pc),aliases:s?s.aliases:[],category:s?s.category:'UNKNOWN',categorySource:s?'PROFILE':'UNKNOWN',confidence:null,implementation:'TRANSLATED',stateVariants:[],instructions:[],calledBy:[],calls:[],staticCandidates:[],observed:{instructions:0,hostCalls:0,reads:{},writes:{},dmaEvents:0,hdmaEvents:0,calls:[],calledBy:[]},evidence:[]});}return nodes.get(pc);}
 for(const f of a.functions||[]){const n=get(f.start);if(!n.stateVariants.includes(f.stateSig||f.functionKey))n.stateVariants.push(f.stateSig||f.functionKey);for(const i of f.instructions){if(!n.instructions.includes(i.pc))n.instructions.push(i.pc);if(['Absolute','AbsoluteLong'].includes(i.mode)&&/^(LD|ST|ADC|SBC|CMP|CPX|CPY|AND|ORA|EOR|BIT|INC|DEC|ASL|LSR|ROL|ROR|TRB|TSB)/.test(i.mnemonic))n.staticCandidates.push({pc:hx(i.pc),operand:hx(i.operand),mode:i.mode,note:i.mode==='Absolute'?'Data bank/state required; not a proven address':'Long address; execution not proven'});}for(const c of f.calls||[]){const target=c.target??c.to;if(target===null||target===undefined)continue;const dst=get(target);if(!n.calls.includes(dst.address))n.calls.push(dst.address);if(!dst.calledBy.includes(n.address))dst.calledBy.push(n.address);}}
 let romReads=0,translatedInstructions=0,hostReplacementEvents=0;const frames=new Set();for(const e of trace.events){frames.add(e.frame);const n=get(e.routine);if(e.kind==='entry'&&e.value){const caller=get(e.value);if(!n.observed.calledBy.includes(caller.address))n.observed.calledBy.push(caller.address);if(!caller.observed.calls.includes(n.address))caller.observed.calls.push(n.address);}if(e.kind==='instruction'){n.observed.instructions++;translatedInstructions++;}if(e.kind==='native_hook'){n.observed.hostCalls++;hostReplacementEvents++;}if(e.kind==='read'||e.kind==='write'){const d=n.observed[e.kind==='read'?'reads':'writes'];if(!d[e.space])d[e.space]=new Set();d[e.space].add(e.address);if(e.kind==='read'&&e.space==='ROM')romReads++;if(e.source==='DMA')n.observed.dmaEvents++;if(e.source==='HDMA')n.observed.hdmaEvents++;}}
 for(const n of nodes.values()){for(const k of ['reads','writes'])for(const [space,set]of Object.entries(n.observed[k]))n.observed[k][space]=[...set].sort((x,y)=>x-y);if(n.observed.hostCalls)n.implementation=n.observed.instructions?'MIXED':'NATIVE_OBSERVED';if(n.categorySource!=='PROFILE'){const w=n.observed.writes,r=n.observed.reads;if(profile.heuristics.audio&&(w.APU||r.APU)){n.category='AUDIO';n.categorySource='HEURISTIC';n.confidence=0.6;n.evidence.push('Observed APU port access; may be a generic transfer helper');}else if(profile.heuristics.render&&['PPU','VRAM','CGRAM','OAM'].some(k=>w[k])){n.category='RENDER';n.categorySource='HEURISTIC';n.confidence=0.6;n.evidence.push('Observed display port access; gameplay role remains unproven');}else if(profile.heuristics.save&&w.SRAM){n.category='SAVE';n.categorySource='HEURISTIC';n.confidence=0.5;n.evidence.push('Observed SRAM writes; save semantics unproven');}}n.instructions.sort((x,y)=>x-y);n.calls.sort();n.calledBy.sort();n.staticCandidates=[...new Map(n.staticCandidates.map(x=>[JSON.stringify(x),x])).values()];}
 return {schema:1,rom:hash,mapping:a.mapping,profile,trace:{provided:!!input,recordedEvents:trace.events.length,droppedEvents:trace.dropped,complete:!!input&&trace.complete&&trace.dropped===0},metrics:{decodedInstructions:a.decoded,translatedEligibleInstructions:a.native,translationCoverageScope:'reachable decoded instruction addresses; not whole ROM or whole game',cpuNativeScore:null,nativeScore:null,translatedInstructionsObserved:translatedInstructions,hostReplacementEvents,romRuntimeReads:input?romReads:null,romReadsPerObservedFrame:input&&frames.size?romReads/frames.size:null,observedFrames:frames.size,scope:trace.dropped?'TRUNCATED_TRACE':input&&!trace.complete?'INCOMPLETE_TRACE':'OBSERVED_TRACE_ONLY'},routines:[...nodes.values()].sort((x,y)=>parseInt(x.address,16)-parseInt(y.address,16)),limits:['No automatic gameplay reconstruction','Heuristic confidence is a ranking weight, not a calibrated probability','Trace counts do not establish whole-game coverage','State-only PPU, DMA register replay, SPC/DSP simulation and ROM packs remain hardware/data dependencies']};}
function nativeMapMarkdown(m){return '# ROM Trace → Native Map\n\nROM: `'+m.rom+'` — '+m.mapping+'\n\nTrace events: '+m.trace.recordedEvents+'; dropped: '+m.trace.droppedEvents+'. Native score: unmeasured.\n\n| Address | Symbol | Level observed | Category | Evidence | Instructions | Host calls |\n|---|---|---|---|---|---:|---:|\n'+m.routines.map(n=>`| ${n.address} | ${n.name.replace(/[|\r\n]/g,' ')} | ${n.implementation} | ${n.category} | ${n.categorySource} | ${n.observed.instructions} | ${n.observed.hostCalls} |`).join('\n')+'\n\n'+m.limits.map(x=>'- '+x).join('\n')+'\n';}
function compatibilityReport(m,a){return {schema:1,rom:m.rom,systems:{cpu:'TRANSLATED',ppu:'EMULATED',dma:'EMULATED',hdma:'EMULATED',audio:'EMULATED',entities:'UNMEASURED'},nativeScore:null,metrics:m.metrics,unsupportedHardware:a.coprocessor&&a.coprocessor!=='NONE'?[a.coprocessor]:[],observedNativeHooks:m.metrics.hostReplacementEvents,limits:m.limits};}


function normalizeKnowledgePack(pack={},rom){
 if(!pack||typeof pack!=='object')throw new Error('Knowledge pack must be an object');
 if(pack.schema!=='forja65.knowledge.v1')throw new Error('Unsupported knowledge pack schema');
 const ids=pack.rom&&typeof pack.rom==='object'?pack.rom:{};
 const expected=String(rom||'').toLowerCase();
 if(ids.fnv1a64&&String(ids.fnv1a64).toLowerCase()!==expected)throw new Error('Knowledge pack ROM fingerprint mismatch');
 const byAddress=new Map();
 for(const raw of pack.entries||[]){
  if(!raw||typeof raw!=='object')throw new Error('Knowledge entry must be an object');
  const address=addr(raw.address),state=raw.state||{};
  const normalizedState={emulation:state.emulation===undefined?false:!!state.emulation,m8:state.m8===undefined?false:!!state.m8,x8:state.x8===undefined?false:!!state.x8,carry:state.carry===null||state.carry===undefined?null:!!state.carry};
  const category=raw.category||'UNKNOWN';if(!categories.has(category))throw new Error('Invalid knowledge category: '+category);
  let span=null;if(raw.span&&typeof raw.span==='object'){const start=addr(raw.span.start),end=addr(raw.span.end);if(end<=start)throw new Error('Invalid knowledge span bounds');span={start,end,name:String(raw.span.name||raw.name||('fn_'+hx(start)))};if(!(start<=address&&address<end))throw new Error('Knowledge entry address outside span');}
  const e={address,name:String(raw.name||('fn_'+hx(address))),aliases:Array.isArray(raw.aliases)?raw.aliases.map(String):[],category,state:normalizedState,priority:Number.isFinite(raw.priority)?Number(raw.priority):0,source:String(raw.source||'external'),evidence:Array.isArray(raw.evidence)?raw.evidence.map(String):[],span};
  const key=hx(address)+'|'+[+e.state.emulation,+e.state.m8,+e.state.x8,e.state.carry===null?'?':+e.state.carry].join('');
  const old=byAddress.get(key);if(!old||e.priority>old.priority)byAddress.set(key,e);
 }
 const entries=[...byAddress.values()].sort((a,b)=>b.priority-a.priority||a.address-b.address);
 const dataRegions=(pack.dataRegions||[]).map(r=>{if(!r||typeof r!=='object')throw new Error('Invalid data region');const start=addr(r.start),end=addr(r.end);if(end<start)throw new Error('Invalid data region bounds');return {start,end,source:String(r.source||'external')};});
 const dispatch=(pack.dispatch||[]).map(d=>({site:addr(d.site),targets:[...new Set((d.targets||[]).map(addr))],source:String(d.source||'external'),...(d.resolution&&typeof d.resolution==='object'?{resolution:JSON.parse(JSON.stringify(d.resolution))}:{})}));
 return {schema:'forja65.knowledge.v1',rom:{fnv1a64:expected||String(ids.fnv1a64||''),sha256:ids.sha256?String(ids.sha256).toLowerCase():null},producer:pack.producer||null,entries,dataRegions,dispatch,limits:Array.isArray(pack.limits)?pack.limits.map(String):[]};
}
function mergeKnowledgeProfile(profile={},pack,rom){
 const k=normalizeKnowledgePack(pack,rom),base=Object.keys(profile||{}).length?normalizeProfile(profile,rom):{schema:1,rom,symbols:{},heuristics:{render:true,audio:true,save:true}};
 const symbols={...base.symbols};
 for(const e of k.entries){const key=hx(e.address),old=symbols[key];if(!old){symbols[key]={name:e.name,aliases:e.aliases,category:e.category};continue;}const aliases=[...(old.aliases||[])];for(const a of [e.name,...e.aliases])if(a&&a!==old.name&&!aliases.includes(a))aliases.push(a);symbols[key]={name:old.name||e.name,aliases,category:old.category&&old.category!=='UNKNOWN'?old.category:e.category};}
 return {schema:1,rom,symbols,heuristics:{render:true,audio:true,save:true,...base.heuristics}};
}
function knowledgePackFromNativeMap(map,extra={}){
 if(!map||typeof map!=='object'||!map.rom)throw new Error('Native map with ROM fingerprint required');
 const entries=(map.routines||[]).map(r=>({address:addr(r.address),name:r.name||('fn_'+r.address),aliases:r.aliases||[],category:categories.has(r.category)?r.category:'UNKNOWN',state:{emulation:false,m8:false,x8:false,carry:null},priority:r.categorySource==='PROFILE'?80:40,source:'forja65-native-map',evidence:[r.categorySource||'UNKNOWN',r.implementation||'TRANSLATED']}));
 return {schema:'forja65.knowledge.v1',rom:{fnv1a64:map.rom,sha256:extra.sha256||null},producer:{tool:'Forja65',version:extra.version||null},entries,dataRegions:[],dispatch:[],limits:['Exported routine labels/states are analysis leads, not proof of whole-game execution']};
}

function frameHashes(text){const map=new Map();for(const line of String(text).split(/\r?\n/)){if(!line.trim()||line.startsWith('#'))continue;const f={};for(const token of line.trim().split(/\s+/)){const i=token.indexOf('=');if(i>=0)f[token.slice(0,i)]=token.slice(i+1);}if(f.frame===undefined)throw new Error('Frame number missing');const n=Number(f.frame);if(!Number.isSafeInteger(n)||n<0)throw new Error('Invalid frame');if(map.has(n))throw new Error('Duplicate frame');map.set(n,f);}if(!map.size)throw new Error('Empty frame hash trace');return map;}
function firstDivergence(reference,native){const r=frameHashes(reference),n=frameHashes(native);for(const frame of [...new Set([...r.keys(),...n.keys()])].sort((a,b)=>a-b)){if(!r.has(frame)||!n.has(frame))return {equivalent:false,frame,reason:'MISSING_FRAME',missing:r.has(frame)?'native':'reference',differences:[]};const a=r.get(frame),b=n.get(frame),differences=[];for(const field of ['framebuffer','wram','pc']){if(a[field]!==b[field])differences.push({field,reference:a[field]??null,native:b[field]??null});}if(!['framebuffer','wram','pc'].some(k=>a[k]!==undefined&&b[k]!==undefined))throw new Error('No comparable state fields');if(differences.length)return {equivalent:false,frame,reason:'STATE_HASH_MISMATCH',differences,note:'Hash-level difference; exact RAM/objects need separate snapshots'};}return {equivalent:true,comparedFrames:r.size,scope:'recorded frame hashes only'};}

return {normalizeProfile,normalizeKnowledgePack,mergeKnowledgeProfile,knowledgePackFromNativeMap,parseTrace,exportTrace,buildNativeMap,nativeMapMarkdown,compatibilityReport,firstDivergence};
});

(function(r){const t={"src/forja_trace.hpp":"#ifndef FORJA_TRACE_HPP\n#define FORJA_TRACE_HPP\n#include <cstdint>\n#include <cstdlib>\n#include <fstream>\n#include <string>\n#include <stdexcept>\n#ifndef FORJA65_ENABLE_TRACE\n#define FORJA65_ENABLE_TRACE 1\n#endif\n// No observer performs a bus read. Disabled builds perform no file or event work.\nstruct ForjaTrace {\n#if FORJA65_ENABLE_TRACE\n  std::ofstream out;\n  std::uint64_t sequence{},written{},dropped{},limit{250000};\n  bool enabled{};\n  void start(const std::string&path,const std::string&rom,std::uint64_t cap=250000){close();out.open(path,std::ios::trunc);if(!out)throw std::runtime_error(\"Cannot open ForjaTrace: \"+path);sequence=written=dropped=0;limit=cap;enabled=true;out<<\"# FORJA_TRACE 1 rom=\"<<rom<<\"\\nseq,frame,routine,pc,kind,space,address,value,source\\n\";}\n  void initialize(const std::string&rom){const char*p=std::getenv(\"FORJA65_TRACE\");if(!p||!*p||std::string(p)==\"0\")return;std::uint64_t cap=250000;if(const char*c=std::getenv(\"FORJA65_TRACE_LIMIT\")){try{cap=std::stoull(c);}catch(...){throw std::runtime_error(\"Invalid FORJA65_TRACE_LIMIT\");}}start(std::string(p)==\"1\"?\"forja-trace.csv\":p,rom,cap);}\n  void emit(std::uint64_t frame,std::uint32_t routine,std::uint32_t pc,const char*kind,const char*space,std::uint32_t address,std::uint64_t value,const char*source=\"CPU\"){if(!enabled)return;const auto seq=sequence++;if(written>=limit){dropped++;return;}out<<seq<<','<<frame<<','<<routine<<','<<pc<<','<<kind<<','<<space<<','<<address<<','<<value<<','<<source<<'\\n';if(!out)throw std::runtime_error(\"ForjaTrace write failed\");written++;}\n  void close(){if(out.is_open()){out<<\"# written=\"<<written<<\" dropped=\"<<dropped<<'\\n';out.close();}enabled=false;}\n#else\n  static constexpr bool enabled=false;\n  void start(const std::string&,const std::string&,std::uint64_t=250000){}\n  void initialize(const std::string&){}\n  void emit(std::uint64_t,std::uint32_t,std::uint32_t,const char*,const char*,std::uint32_t,std::uint64_t,const char* = \"CPU\"){}\n  void close(){}\n#endif\n  ~ForjaTrace(){close();}\n};\nstruct ForjaTraceContext {\n  std::uint32_t&routine;const char*&source;std::uint32_t oldRoutine;const char*oldSource;\n  ForjaTraceContext(std::uint32_t&r,const char*&s,std::uint32_t next,const char*origin):routine(r),source(s),oldRoutine(r),oldSource(s){routine=next;source=origin;}\n  ~ForjaTraceContext(){routine=oldRoutine;source=oldSource;}\n};\n\n#endif\n","src/forja_ir.hpp":"#ifndef FORJA_IR_HPP\n#define FORJA_IR_HPP\n#include <array>\n#include <cstdint>\n#include <stdexcept>\n#include <vector>\n#include <utility>\n// Host representation: no PPU registers, SNES DMA engine or ROM bus.\nstruct ForjaRenderer {\n  std::array<std::uint16_t,256> palette{};\n  struct Scroll {int x{},y{};};std::array<Scroll,4> layers{};\n  std::uint64_t paletteUploads{},scrollUpdates{};\n  void uploadPalette(unsigned first,const std::vector<std::uint16_t>&colors){if(first>256||colors.size()>256-first)throw std::out_of_range(\"Palette range\");for(auto c:colors)if(c>0x7fff)throw std::out_of_range(\"Palette color\");for(std::size_t i=0;i<colors.size();i++)palette[first+i]=colors[i];paletteUploads++;}\n  void setLayerScroll(unsigned layer,int x,int y){if(layer>=layers.size())throw std::out_of_range(\"Layer\");layers[layer]={x,y};scrollUpdates++;}\n};\nstruct ForjaIR {\n  enum class Op {SetPalette,SetScroll};\n  Op op{};unsigned index{};int x{},y{};std::vector<std::uint16_t> colors;\n  static ForjaIR setPalette(unsigned first,std::vector<std::uint16_t> colors){return {Op::SetPalette,first,0,0,std::move(colors)};}\n  static ForjaIR setScroll(unsigned layer,int x,int y){return {Op::SetScroll,layer,x,y,{}};}\n  void apply(ForjaRenderer&host)const{if(op==Op::SetPalette)host.uploadPalette(index,colors);else if(op==Op::SetScroll)host.setLayerScroll(index,x,y);else throw std::invalid_argument(\"Unknown ForjaIR op\");}\n};\n\n#endif\n","tests/framework_smoke.cpp":"#include \"runtime.hpp\"\n#include <iostream>\nstatic unsigned hostBody(CpuState&c,SnesRuntime&h){c.setA(7,8);h.ram[0x10]=7;return 20;}\nint main(){try{\n  SnesRuntime hw;hw.cart.resize(0x8000);hw.romLogicalSize=hw.cart.size();CpuState cpu;\n  hw.registerNativeHook({0x8020,hostBody,nullptr,1,1,1});cpu.push16Value(hw,0x8002);hw.pushNativeReturn(0x8003,false);cpu.pb=0;\n  if(!hw.runNativeHook(0x8020,cpu)||cpu.s!=0x1ff||cpu.a!=7||hw.ram[0x10]!=7||!hw.nativeReturns.empty())return 3;\n  ForjaIR::setPalette(0,{0x1f,0x3e0}).apply(hw.hostRenderer);ForjaIR::setScroll(1,5,-7).apply(hw.hostRenderer);\n  if(hw.hostRenderer.palette[0]!=0x1f||hw.hostRenderer.layers[1].y!=-7)return 4;\n  bool rejected=false;try{ForjaIR::setPalette(255,{1,2}).apply(hw.hostRenderer);}catch(const std::out_of_range&){rejected=true;}if(!rejected)return 5;\n  hw.io.nmiPending=true;if(hw.read(0x4210)!=0x80||hw.io.nmiPending)return 6;\n  std::cout<<\"FORJA65_FRAMEWORK_SMOKE_PASS\\n\";return 0;\n}catch(const std::exception&e){std::cerr<<e.what()<<'\\n';return 2;}}\n"};if(typeof module==='object'&&module.exports)module.exports=t;r.Forja65Templates=t;})(typeof globalThis!=='undefined'?globalThis:this);

// END FORJA65 GENERATED FRAMEWORK BUNDLE
(function(root,factory){
  const api=factory();
  if(typeof module==='object'&&module.exports) module.exports=api;
  root.Forja65Core=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';

const VERSION='0.3.43.1-pea-cleanup-dispatch';
const Framework=globalThis.Forja65Analysis;
const FrameworkTemplates=globalThis.Forja65Templates;
const MAP={UNKNOWN:'Unknown',LOROM:'LoROM',HIROM:'HiROM',EXHIROM:'ExHiROM'};

function hex(v,n=2){return (v>>>0).toString(16).toUpperCase().padStart(n,'0');}
function fnv1a64Bytes(data){let h=1469598103934665603n;for(const b of data){h^=BigInt(b&255);h=BigInt.asUintN(64,h*1099511628211n);}return h.toString(16).padStart(16,'0');}
function fnv1a64Text(text){const enc=typeof TextEncoder!=='undefined'?new TextEncoder().encode(String(text)):Uint8Array.from(Buffer.from(String(text),'utf8'));return fnv1a64Bytes(enc);}
function romFingerprint(rom){return fnv1a64Bytes(rom&&rom.data?rom.data:[]);}
function normalizeRomHash(v){return String(v||'').trim().replace(/^0x/i,'').toLowerCase();}
function read16(d,o){if(o+1>=d.length) throw new Error('Leitura 16-bit fora da ROM'); return d[o]|(d[o+1]<<8);}
function read24(d,o){if(o+2>=d.length) throw new Error('Leitura 24-bit fora da ROM'); return d[o]|(d[o+1]<<8)|(d[o+2]<<16);}
function cleanTitle(d,o){let s=''; if(o+21>d.length) return ''; for(let i=0;i<21;i++){const c=d[o+i];s+=(c>=32&&c<=126)?String.fromCharCode(c):' ';}return s.replace(/\s+$/,'');}
function detectCartCoprocessor(h){
  const t=h.romType&0xFF,low=t&0x0F,high=t&0xF0;if(!(low>=3&&low<=6))return 'NONE';
  // Mesma classificacao de familia usada pelo Snes9x/NSRT para DSP1-4.
  if(t===0x03){return h.mapMode===0x30?'DSP4':'DSP1';}
  if(t===0x05){if(h.mapMode===0x20)return 'DSP2';if(h.mapMode===0x30&&h.developerId===0xB2)return 'DSP3';return 'DSP1';}
  if(high===0x10)return 'GSU/SUPERFX';if(high===0x20)return 'OBC1';if(high===0x30)return 'SA1';if(high===0x40)return 'SDD1';if(high===0x50)return 'SRTC';
  if(high===0xF0){if(h.chipSubtype===0x00)return 'SPC7110';if(h.chipSubtype===0x01)return 'ST010/ST011';if(h.chipSubtype===0x02)return 'ST018';if(h.chipSubtype===0x03)return 'CX4';return 'CUSTOM';}
  return 'COPROCESSOR';
}
function scoreHeader(d,off,mapping){
  if(off+0x40>d.length) return {mapping,headerOffset:off,score:-999,title:''};
  const h={mapping,headerOffset:off,title:cleanTitle(d,off),mapMode:d[off+0x15],romType:d[off+0x16],romSize:d[off+0x17],sramSize:d[off+0x18],region:d[off+0x19],developerId:d[off+0x1A],romVersion:d[off+0x1B],chipSubtype:off>0?d[off-1]:0,checksumComplement:read16(d,off+0x1C),checksum:read16(d,off+0x1E),resetVector:read16(d,off+0x3C),score:0};
  h.sramBytes=h.sramSize?(1024*Math.pow(2,Math.min(h.sramSize,15))):0;
  const low=h.romType&0x0F;h.hasBattery=low===2||low===5||low===6;h.hasCoprocessor=low>=3&&low<=6;
  h.coprocessor=detectCartCoprocessor(h);
  if(((h.checksum^h.checksumComplement)&0xFFFF)===0xFFFF)h.score+=4;
  if(h.resetVector>=0x8000)h.score+=3;
  const mode=h.mapMode&0x2F;
  if(mapping===MAP.LOROM&&(mode===0x20||mode===0x22))h.score+=4;
  if((mapping===MAP.HIROM||mapping===MAP.EXHIROM)&&(mode===0x21||mode===0x25))h.score+=4;
  if(h.title.replace(/[^\x20-\x7E]/g,'').length>=8)h.score+=2;
  if(h.romSize<=0x0D)h.score+=1;
  return h;
}
function loadRom(input,name='rom.sfc'){
  let raw=input instanceof Uint8Array?input:new Uint8Array(input);
  if(raw.length<0x8000)throw new Error('Arquivo pequeno demais para uma ROM SNES valida');
  let copierHeader=false;
  if(raw.length%0x8000===512){copierHeader=true;raw=raw.slice(512);}
  const c=[];
  if(raw.length>=0x7FC0+0x40)c.push(scoreHeader(raw,0x7FC0,MAP.LOROM));
  if(raw.length>=0xFFC0+0x40)c.push(scoreHeader(raw,0xFFC0,MAP.HIROM));
  if(raw.length>=0x40FFC0+0x40)c.push(scoreHeader(raw,0x40FFC0,MAP.EXHIROM));
  if(!c.length)throw new Error('ROM sem area de cabecalho SNES detectavel');
  c.sort((a,b)=>b.score-a.score);
  const header=c[0];
  if(header.score<3) throw new Error('Cabecalho SNES muito inconsistente; arquivo pode nao ser uma ROM SNES valida');
  return {name,data:raw,copierHeader,header,candidates:c};
}
function mirrorOffset(size,off){
  if(size<=0)return null;
  if(off<size)return off;
  // Espelhamento de ROM no mesmo modelo usado por Snes9x/bsnes.
  // Isto importa especialmente para cartuchos de tamanho nao potencia de dois.
  let mask=0x80000000;
  while(mask && !(off&mask))mask>>>=1;
  if(!mask)return 0;
  if(size<=(off&mask))return mirrorOffset(size,off-mask);
  return mask+mirrorOffset(size-mask,off-mask);
}
function snesToRom(rom,a){
  const bank=(a>>>16)&0xFF, addr=a&0xFFFF; let off;
  switch(rom.header.mapping){
    case MAP.LOROM:{
      const lowMirror=(bank>=0x40&&bank<=0x7D)||(bank>=0xC0);
      // Bancos 00-3F/80-BF abaixo de $8000 sao WRAM/I/O, nao ROM.
      if(addr<0x8000&&!lowMirror)return null;
      off=((bank&0x7F)<<15)|(addr&0x7FFF);
      break;
    }
    case MAP.HIROM:{
      const full=(bank>=0x40&&bank<=0x7D)||(bank>=0xC0);
      if(addr<0x8000&&!full)return null;
      off=((bank&0x3F)<<16)|addr; break;
    }
    case MAP.EXHIROM:{
      const full=(bank>=0x40&&bank<=0x7D)||(bank>=0xC0);
      if(addr<0x8000&&!full)return null;
      off=((bank&0x7F)<<16)|addr; if((bank&0x40)===0)off+=0x400000; break;
    }
    default:return null;
  }
  return mirrorOffset(rom.data.length,off);
}
function isRomAddress(rom,a){return snesToRom(rom,a)!==null;}
function resetAddress(rom){return rom.header.resetVector&0xFFFF;}


// 65C816 base CPU-cycle counts. The generated runtime converts these to
// SNES master clocks with the 6/8/12-clock bus-speed map and MEMSEL.
const CPU_BASE_CYCLES=[7,6,7,4,5,3,5,6,3,2,2,4,6,4,6,5,2,5,5,7,5,4,6,6,2,4,2,2,6,4,7,5,6,6,8,4,3,3,5,6,4,2,2,5,4,4,6,5,2,5,5,7,4,4,6,6,2,4,2,2,4,4,7,5,6,6,2,4,7,3,5,6,3,2,2,3,3,4,6,5,2,5,5,7,7,4,6,6,2,4,3,2,4,4,7,5,6,6,6,4,3,3,5,6,4,2,2,6,5,4,6,5,2,5,5,7,4,4,6,6,2,4,4,2,6,4,7,5,3,6,4,4,3,3,3,6,2,2,2,3,4,4,4,5,2,6,5,7,4,4,4,6,2,5,2,2,4,5,5,5,2,6,2,4,3,3,3,6,2,2,2,4,4,4,4,5,2,5,5,7,4,4,4,6,2,4,2,2,4,4,4,5,2,6,3,4,3,3,5,6,2,2,2,3,4,4,6,5,2,5,5,7,6,4,6,6,2,4,3,3,6,4,7,5,2,6,3,4,3,3,5,6,2,2,2,3,4,4,6,5,2,5,5,7,5,4,6,6,2,4,4,2,8,4,7,5];
const M_WIDTH_1=new Set(['LDA','STA','ADC','SBC','AND','ORA','EOR','CMP','BIT','STZ']);
const M_WIDTH_2=new Set(['ASL','LSR','ROL','ROR','INC','DEC','TSB','TRB']);
const X_WIDTH_1=new Set(['LDX','LDY','STX','STY','CPX','CPY']);
const INDEX_READ_MNEMONICS=new Set(['LDA','LDX','LDY','ADC','SBC','AND','ORA','EOR','CMP','BIT']);
function timingWidthExtra(i){
  const m=i.mnemonic;
  if(M_WIDTH_1.has(m)&&!i.stateIn.m8)return 1;
  if(M_WIDTH_2.has(m)&&i.mode!=='Accumulator'&&!i.stateIn.m8)return 2;
  if(X_WIDTH_1.has(m)&&!i.stateIn.x8)return 1;
  if((m==='PHA'||m==='PLA')&&!i.stateIn.m8)return 1;
  if(['PHX','PLX','PHY','PLY'].includes(m)&&!i.stateIn.x8)return 1;
  if((m==='BRK'||m==='COP'||m==='RTI')&&!i.stateIn.emulation)return 1;
  return 0;
}
function timingDirectPageExpr(i){
  return i.mode.startsWith('Direct')?' + ((cpu.d & 0xFFu)!=0u ? 1u : 0u)':'';
}
function timingIndexPenaltyExpr(i){
  if(!INDEX_READ_MNEMONICS.has(i.mnemonic))return '';
  if(!(i.mode==='AbsoluteX'||i.mode==='AbsoluteY'||i.mode==='DirectIndirectY'))return '';
  if(!i.stateIn.x8)return ' + 1u';
  if(i.mode==='AbsoluteX')return ` + ((((0x${hex(i.operand&0xFFFF,4)}u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u)`;
  if(i.mode==='AbsoluteY')return ` + ((((0x${hex(i.operand&0xFFFF,4)}u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u)`;
  return '';
}
function timingCpuCyclesExpr(i){
  const base=CPU_BASE_CYCLES[i.opcode]+timingWidthExtra(i);
  return String(base)+'u'+timingDirectPageExpr(i)+timingIndexPenaltyExpr(i);
}
function timingBranchPageCross(i){
  if(i.flowTarget===null||i.flowTarget===undefined)return false;
  const n=nextPc(i)&0xFFFF,t=i.flowTarget&0xFFFF;return (n&0xFF00)!==(t&0xFF00);
}
function timingSimpleAddrExpr(i){
  const op='0x'+hex(i.operand>>>0,Math.max(2,(i.size-1)*2))+'u';
  if(i.mode==='Direct')return `cpu.address("dp", ${op})`;
  if(i.mode==='DirectX')return `cpu.address("dpx", ${op})`;
  if(i.mode==='DirectY')return `cpu.address("dpy", ${op})`;
  if(i.mode==='Absolute')return `cpu.address("abs", ${op})`;
  if(i.mode==='AbsoluteX')return `cpu.address("absx", ${op})`;
  if(i.mode==='AbsoluteY')return `cpu.address("absy", ${op})`;
  if(i.mode==='AbsoluteLong')return op;
  if(i.mode==='AbsoluteLongX')return `((${op} + cpu.x) & 0xFFFFFFu)`;
  if(i.mode==='StackRelative')return `cpu.addressStack(${op})`;
  return 'SnesRuntime::NO_TIMING_ADDR';
}
function timingDataAccessesExpr(i){
  const m=i.mnemonic;
  if(timingSimpleAddrExpr(i)==='SnesRuntime::NO_TIMING_ADDR')return '0u';
  let bytes=0;
  if(['LDA','ADC','SBC','AND','ORA','EOR','CMP','BIT'].includes(m))bytes=i.stateIn.m8?1:2;
  else if(['LDX','LDY','CPX','CPY'].includes(m))bytes=i.stateIn.x8?1:2;
  else if(['STA','STZ'].includes(m))bytes=i.stateIn.m8?1:2;
  else if(['STX','STY'].includes(m))bytes=i.stateIn.x8?1:2;
  else if(['INC','DEC','ASL','LSR','ROL','ROR','TSB','TRB'].includes(m)&&i.mode!=='Accumulator')bytes=(i.stateIn.m8?1:2)*2;
  return String(bytes)+'u';
}
function timingAux(i){
  const op='0x'+hex(i.operand>>>0,Math.max(2,(i.size-1)*2))+'u';
  if(i.mode==='DirectIndexedIndirectX')return [`((cpu.d + ${op} + cpu.x) & 0xFFFFu)`,'2u'];
  if(i.mode==='DirectIndirect'||i.mode==='DirectIndirectY')return [`((cpu.d + ${op}) & 0xFFFFu)`,'2u'];
  if(i.mode==='DirectIndirectLong'||i.mode==='DirectIndirectLongY')return [`((cpu.d + ${op}) & 0xFFFFu)`,'3u'];
  if(i.mode==='StackRelativeIndirectY')return [`((cpu.s + ${op}) & 0xFFFFu)`,'2u'];
  if(i.mode==='AbsoluteIndirect')return [op,'2u'];
  if(i.mode==='AbsoluteIndirectLong')return [op,'3u'];
  if(i.mode==='AbsoluteIndexedIndirectX')return [`((std::uint32_t(cpu.pb)<<16) | ((${op} + cpu.x) & 0xFFFFu))`,'2u'];
  return ['SnesRuntime::NO_TIMING_ADDR','0u'];
}
function timingStackAccessesExpr(i){
  const m=i.mnemonic;
  if(m==='PHA'||m==='PLA')return i.stateIn.m8?'1u':'2u';
  if(['PHX','PLX','PHY','PLY'].includes(m))return i.stateIn.x8?'1u':'2u';
  if(['PHP','PLP','PHB','PLB','PHK'].includes(m))return '1u';
  if(['PHD','PLD','PEA','PEI','PER'].includes(m))return '2u';
  if(m==='JSR')return '2u';
  if(m==='JSL')return '3u';
  if(m==='RTS')return '2u';
  if(m==='RTL')return '3u';
  if(m==='RTI')return i.stateIn.emulation?'3u':'4u';
  if(m==='BRK'||m==='COP')return i.stateIn.emulation?'3u':'4u';
  return '0u';
}
function emitInstructionTiming(i){
  if(i.mnemonic==='MVN'||i.mnemonic==='MVP')
    return `    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0x${hex(i.pc&0xFFFF,4)}u, (std::uint32_t(cpu.a)+1u), 0x${hex((i.operand>>>8)&255,2)}u, 0x${hex(i.operand&255,2)}u);\n`;
  const aux=timingAux(i);
  return `    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x${hex(i.pc&0xFFFF,4)}u, ${timingCpuCyclesExpr(i)}, ${i.size}u, ${timingSimpleAddrExpr(i)}, ${timingDataAccessesExpr(i)}, ${aux[0]}, ${aux[1]}, ${timingStackAccessesExpr(i)});\n`;
}

const META={
  0xA9:['LDA','ImmA','native'],0xAD:['LDA','Absolute','native'],0xA5:['LDA','Direct','native'],0xAF:['LDA','AbsoluteLong','native'],0xBD:['LDA','AbsoluteX','native'],
  0x8D:['STA','Absolute','native'],0x99:['STA','AbsoluteY','native'],0x85:['STA','Direct','native'],0x8F:['STA','AbsoluteLong','native'],0x9F:['STA','AbsoluteLongX','native'],0x9D:['STA','AbsoluteX','native'],0x91:['STA','DirectIndirectY','native'],0x87:['STA','DirectIndirectLong','native'],0x97:['STA','DirectIndirectLongY','native'],
  0x64:['STZ','Direct','native'],0x74:['STZ','DirectX','native'],0x9C:['STZ','Absolute','native'],0x9E:['STZ','AbsoluteX','native'],
  0xA2:['LDX','ImmX','native'],0xA0:['LDY','ImmX','native'],0xA4:['LDY','Direct','native'],0xAE:['LDX','Absolute','native'],0x8E:['STX','Absolute','native'],0x8C:['STY','Absolute','native'],0x86:['STX','Direct','native'],0x84:['STY','Direct','native'],0x96:['STX','DirectY','native'],
  0x69:['ADC','ImmA','native'],0x6F:['ADC','AbsoluteLong','native'],0xE9:['SBC','ImmA','native'],0x29:['AND','ImmA','native'],0x37:['AND','DirectIndirectLongY','native'],0x09:['ORA','ImmA','native'],0x0D:['ORA','Absolute','native'],0x0F:['ORA','AbsoluteLong','native'],0x49:['EOR','ImmA','native'],
  0x18:['CLC','Implied','native'],0x38:['SEC','Implied','native'],0x58:['CLI','Implied','native'],0x78:['SEI','Implied','native'],0xD8:['CLD','Implied','native'],0xF8:['SED','Implied','native'],0xB8:['CLV','Implied','native'],
  0xC2:['REP','Imm8','native'],0xE2:['SEP','Imm8','native'],0xFB:['XCE','Implied','native'],
  0xE8:['INX','Implied','native'],0xCA:['DEX','Implied','native'],0xC8:['INY','Implied','native'],0x88:['DEY','Implied','native'],0x1A:['INC','Accumulator','native'],0x3A:['DEC','Accumulator','native'],
  0xE6:['INC','Direct','native'],0xEE:['INC','Absolute','native'],0xCE:['DEC','Absolute','native'],0x2A:['ROL','Accumulator','native'],0x0A:['ASL','Accumulator','native'],
  0xAA:['TAX','Implied','native'],0x8A:['TXA','Implied','native'],0xA8:['TAY','Implied','native'],0x98:['TYA','Implied','native'],0x9B:['TXY','Implied','native'],0xBB:['TYX','Implied','native'],0xBA:['TSX','Implied','native'],0x9A:['TXS','Implied','native'],0x5B:['TCD','Implied','native'],0x1B:['TCS','Implied','native'],0xEB:['XBA','Implied','native'],
  0x48:['PHA','Implied','native'],0x68:['PLA','Implied','native'],0xDA:['PHX','Implied','native'],0xFA:['PLX','Implied','native'],0x5A:['PHY','Implied','native'],0x7A:['PLY','Implied','native'],0x08:['PHP','Implied','native'],0x28:['PLP','Implied','native'],
  0x80:['BRA','Relative8','native'],0x82:['BRL','Relative16','native'],0xF0:['BEQ','Relative8','native'],0xD0:['BNE','Relative8','native'],0x90:['BCC','Relative8','native'],0xB0:['BCS','Relative8','native'],0x30:['BMI','Relative8','native'],0x10:['BPL','Relative8','native'],0x50:['BVC','Relative8','native'],0x70:['BVS','Relative8','native'],
  0x4C:['JMP','Absolute','native'],0x5C:['JML','AbsoluteLong','native'],0x20:['JSR','Absolute','native'],0x22:['JSL','AbsoluteLong','native'],0x60:['RTS','Implied','native'],0x6B:['RTL','Implied','native'],
  0xCD:['CMP','Absolute','native'],0xD1:['CMP','DirectIndirectY','native'],0xE0:['CPX','ImmX','native'],0xB7:['LDA','DirectIndirectLongY','native'],0xDC:['JMP','AbsoluteIndirectLong','native'],0x40:['RTI','Implied','native'],0xEA:['NOP','Implied','native'],0x00:['BRK','Imm8','native'],0x02:['COP','Imm8','native'],0xCB:['WAI','Implied','native'],0xDB:['STP','Implied','native'],
  0x8B:['PHB','Implied','native'],0x4B:['PHK','Implied','native'],0xAB:['PLB','Implied','native'],
  0x4A:['LSR','Accumulator','native'],0x46:['LSR','Direct','native'],0x4E:['LSR','Absolute','native'],0x56:['LSR','DirectX','native'],0x5E:['LSR','AbsoluteX','native'],
  0xC9:['CMP','ImmA','native'],0xC0:['CPY','ImmX','native'],0xCC:['CPY','Absolute','native'],0xEC:['CPX','Absolute','native'],
  0x6D:['ADC','Absolute','native'],0x65:['ADC','Direct','native'],0x79:['ADC','AbsoluteY','native'],0xED:['SBC','Absolute','native'],
  0x2C:['BIT','Absolute','native'],0x24:['BIT','Direct','native'],0x89:['BIT','ImmA','native'],
  0x4D:['EOR','Absolute','native'],0x2D:['AND','Absolute','native'],0x1D:['ORA','AbsoluteX','native'],
  0x26:['ROL','Direct','native'],0x2E:['ROL','Absolute','native'],0x36:['ROL','DirectX','native'],0x3E:['ROL','AbsoluteX','native'],
  0xB9:['LDA','AbsoluteY','native'],0xBF:['LDA','AbsoluteLongX','native'],0xBE:['LDX','AbsoluteY','native'],0xBC:['LDY','AbsoluteX','native'],0xAC:['LDY','Absolute','native']
};
const SYNTAX=[['BRK','Imm8'],['ORA','DirectIndexedIndirectX'],['COP','Imm8'],['ORA','StackRelative'],['TSB','Direct'],['ORA','Direct'],['ASL','Direct'],['ORA','DirectIndirectLong'],['PHP','Implied'],['ORA','ImmA'],['ASL','Accumulator'],['PHD','Implied'],['TSB','Absolute'],['ORA','Absolute'],['ASL','Absolute'],['ORA','AbsoluteLong'],['BPL','Relative8'],['ORA','DirectIndirectY'],['ORA','DirectIndirect'],['ORA','StackRelativeIndirectY'],['TRB','Direct'],['ORA','DirectX'],['ASL','DirectX'],['ORA','DirectIndirectLongY'],['CLC','Implied'],['ORA','AbsoluteY'],['INC','Accumulator'],['TCS','Implied'],['TRB','Absolute'],['ORA','AbsoluteX'],['ASL','AbsoluteX'],['ORA','AbsoluteLongX'],['JSR','Absolute'],['AND','DirectIndexedIndirectX'],['JSL','AbsoluteLong'],['AND','StackRelative'],['BIT','Direct'],['AND','Direct'],['ROL','Direct'],['AND','DirectIndirectLong'],['PLP','Implied'],['AND','ImmA'],['ROL','Accumulator'],['PLD','Implied'],['BIT','Absolute'],['AND','Absolute'],['ROL','Absolute'],['AND','AbsoluteLong'],['BMI','Relative8'],['AND','DirectIndirectY'],['AND','DirectIndirect'],['AND','StackRelativeIndirectY'],['BIT','DirectX'],['AND','DirectX'],['ROL','DirectX'],['AND','DirectIndirectLongY'],['SEC','Implied'],['AND','AbsoluteY'],['DEC','Accumulator'],['TSC','Implied'],['BIT','AbsoluteX'],['AND','AbsoluteX'],['ROL','AbsoluteX'],['AND','AbsoluteLongX'],['RTI','Implied'],['EOR','DirectIndexedIndirectX'],['WDM','Imm8'],['EOR','StackRelative'],['MVP','BlockMove'],['EOR','Direct'],['LSR','Direct'],['EOR','DirectIndirectLong'],['PHA','Implied'],['EOR','ImmA'],['LSR','Accumulator'],['PHK','Implied'],['JMP','Absolute'],['EOR','Absolute'],['LSR','Absolute'],['EOR','AbsoluteLong'],['BVC','Relative8'],['EOR','DirectIndirectY'],['EOR','DirectIndirect'],['EOR','StackRelativeIndirectY'],['MVN','BlockMove'],['EOR','DirectX'],['LSR','DirectX'],['EOR','DirectIndirectLongY'],['CLI','Implied'],['EOR','AbsoluteY'],['PHY','Implied'],['TCD','Implied'],['JML','AbsoluteLong'],['EOR','AbsoluteX'],['LSR','AbsoluteX'],['EOR','AbsoluteLongX'],['RTS','Implied'],['ADC','DirectIndexedIndirectX'],['PER','Relative16'],['ADC','StackRelative'],['STZ','Direct'],['ADC','Direct'],['ROR','Direct'],['ADC','DirectIndirectLong'],['PLA','Implied'],['ADC','ImmA'],['ROR','Accumulator'],['RTL','Implied'],['JMP','AbsoluteIndirect'],['ADC','Absolute'],['ROR','Absolute'],['ADC','AbsoluteLong'],['BVS','Relative8'],['ADC','DirectIndirectY'],['ADC','DirectIndirect'],['ADC','StackRelativeIndirectY'],['STZ','DirectX'],['ADC','DirectX'],['ROR','DirectX'],['ADC','DirectIndirectLongY'],['SEI','Implied'],['ADC','AbsoluteY'],['PLY','Implied'],['TDC','Implied'],['JMP','AbsoluteIndexedIndirectX'],['ADC','AbsoluteX'],['ROR','AbsoluteX'],['ADC','AbsoluteLongX'],['BRA','Relative8'],['STA','DirectIndexedIndirectX'],['BRL','Relative16'],['STA','StackRelative'],['STY','Direct'],['STA','Direct'],['STX','Direct'],['STA','DirectIndirectLong'],['DEY','Implied'],['BIT','ImmA'],['TXA','Implied'],['PHB','Implied'],['STY','Absolute'],['STA','Absolute'],['STX','Absolute'],['STA','AbsoluteLong'],['BCC','Relative8'],['STA','DirectIndirectY'],['STA','DirectIndirect'],['STA','StackRelativeIndirectY'],['STY','DirectX'],['STA','DirectX'],['STX','DirectY'],['STA','DirectIndirectLongY'],['TYA','Implied'],['STA','AbsoluteY'],['TXS','Implied'],['TXY','Implied'],['STZ','Absolute'],['STA','AbsoluteX'],['STZ','AbsoluteX'],['STA','AbsoluteLongX'],['LDY','ImmX'],['LDA','DirectIndexedIndirectX'],['LDX','ImmX'],['LDA','StackRelative'],['LDY','Direct'],['LDA','Direct'],['LDX','Direct'],['LDA','DirectIndirectLong'],['TAY','Implied'],['LDA','ImmA'],['TAX','Implied'],['PLB','Implied'],['LDY','Absolute'],['LDA','Absolute'],['LDX','Absolute'],['LDA','AbsoluteLong'],['BCS','Relative8'],['LDA','DirectIndirectY'],['LDA','DirectIndirect'],['LDA','StackRelativeIndirectY'],['LDY','DirectX'],['LDA','DirectX'],['LDX','DirectY'],['LDA','DirectIndirectLongY'],['CLV','Implied'],['LDA','AbsoluteY'],['TSX','Implied'],['TYX','Implied'],['LDY','AbsoluteX'],['LDA','AbsoluteX'],['LDX','AbsoluteY'],['LDA','AbsoluteLongX'],['CPY','ImmX'],['CMP','DirectIndexedIndirectX'],['REP','Imm8'],['CMP','StackRelative'],['CPY','Direct'],['CMP','Direct'],['DEC','Direct'],['CMP','DirectIndirectLong'],['INY','Implied'],['CMP','ImmA'],['DEX','Implied'],['WAI','Implied'],['CPY','Absolute'],['CMP','Absolute'],['DEC','Absolute'],['CMP','AbsoluteLong'],['BNE','Relative8'],['CMP','DirectIndirectY'],['CMP','DirectIndirect'],['CMP','StackRelativeIndirectY'],['PEI','Direct'],['CMP','DirectX'],['DEC','DirectX'],['CMP','DirectIndirectLongY'],['CLD','Implied'],['CMP','AbsoluteY'],['PHX','Implied'],['STP','Implied'],['JML','AbsoluteIndirectLong'],['CMP','AbsoluteX'],['DEC','AbsoluteX'],['CMP','AbsoluteLongX'],['CPX','ImmX'],['SBC','DirectIndexedIndirectX'],['SEP','Imm8'],['SBC','StackRelative'],['CPX','Direct'],['SBC','Direct'],['INC','Direct'],['SBC','DirectIndirectLong'],['INX','Implied'],['SBC','ImmA'],['NOP','Implied'],['XBA','Implied'],['CPX','Absolute'],['SBC','Absolute'],['INC','Absolute'],['SBC','AbsoluteLong'],['BEQ','Relative8'],['SBC','DirectIndirectY'],['SBC','DirectIndirect'],['SBC','StackRelativeIndirectY'],['PEA','Absolute'],['SBC','DirectX'],['INC','DirectX'],['SBC','DirectIndirectLongY'],['SED','Implied'],['SBC','AbsoluteY'],['PLX','Implied'],['XCE','Implied'],['JSR','AbsoluteIndexedIndirectX'],['SBC','AbsoluteX'],['INC','AbsoluteX'],['SBC','AbsoluteLongX']];
const GENERIC_NATIVE_MNEMONICS=new Set([
  'BRK','COP','RTI','RTS','RTL','NOP','WAI','STP','WDM',
  'LDA','LDX','LDY','STA','STX','STY','STZ',
  'ADC','SBC','AND','ORA','EOR','CMP','CPX','CPY','BIT','TSB','TRB',
  'INC','DEC','ASL','LSR','ROL','ROR',
  'CLC','SEC','CLI','SEI','CLD','SED','CLV','REP','SEP','XCE',
  'INX','DEX','INY','DEY','TAX','TXA','TAY','TYA','TXY','TYX','TSX','TXS','TCD','TCS','TSC','TDC','XBA',
  'PHA','PLA','PHX','PLX','PHY','PLY','PHP','PLP','PHB','PLB','PHK','PHD','PLD',
  'BRA','BRL','BEQ','BNE','BCC','BCS','BMI','BPL','BVC','BVS',
  'JMP','JML','JSR','JSL','PEA','PEI','PER','MVN','MVP'
]);
function syntaxMeta(op){const q=SYNTAX[op];if(!q)return['???','Implied','unsupported'];return[q[0],q[1],GENERIC_NATIVE_MNEMONICS.has(q[0])?'native':'unsupported'];}
function operandBytes(mode,s){switch(mode){case'ImmA':return s.m8?1:2;case'ImmX':return s.x8?1:2;case'Imm8':case'Direct':case'DirectX':case'DirectY':case'DirectIndexedIndirectX':case'DirectIndirect':case'DirectIndirectY':case'DirectIndirectLong':case'DirectIndirectLongY':case'StackRelative':case'StackRelativeIndirectY':case'Relative8':return 1;case'Absolute':case'AbsoluteX':case'AbsoluteY':case'AbsoluteIndirect':case'AbsoluteIndexedIndirectX':case'AbsoluteIndirectLong':case'Relative16':case'BlockMove':return 2;case'AbsoluteLong':case'AbsoluteLongX':return 3;default:return 0;}}
const CARRY_WRITERS=new Set(['ADC','SBC','CMP','CPX','CPY','ASL','LSR','ROL','ROR','PLP','RTI']);
function decodeOne(rom,pc,state){
  const off=snesToRom(rom,pc); if(off===null)throw new Error('Endereco SNES sem mapeamento de ROM: $'+hex(pc,6));
  const opcode=rom.data[off], m=META[opcode]||syntaxMeta(opcode); const n=operandBytes(m[1],state); if(off+n>=rom.data.length)throw new Error('Instrucao truncada no fim da ROM em $'+hex(pc,6));
  let operand=0,raw=[opcode];for(let k=0;k<n;k++){const b=rom.data[off+1+k];raw.push(b);operand|=b<<(8*k);}
  const i={pc,opcode,mnemonic:m[0],mode:m[1],status:m[2],supported:m[2]!=='unsupported',operand,size:1+n,raw};
  if(CARRY_WRITERS.has(m[0]))state.carry=null; // ADC/SBC/CMP/shifts/PLP alteram C: o valor conhecido anterior ficou obsoleto
  if(opcode===0x18)state.carry=false;if(opcode===0x38)state.carry=true;
  if(opcode===0xC2){if(operand&0x01)state.carry=false;if(operand&0x20)state.m8=false;if(operand&0x10)state.x8=false;}
  if(opcode===0xE2){if(operand&0x01)state.carry=true;if(operand&0x20)state.m8=true;if(operand&0x10)state.x8=true;}
  if(opcode===0xFB){if(state.carry!==null){const old=state.emulation;state.emulation=state.carry;state.carry=old;if(state.emulation){state.m8=true;state.x8=true;}}else{state.m8=true;state.x8=true;}}
  return i;
}
function decodeLinear(rom,start,max=256){
  const state={emulation:true,m8:true,x8:true,carry:null},out=[];let pc=start&0xFFFFFF;
  for(let n=0;n<max;n++){
    let i;try{i=decodeOne(rom,pc,state);}catch(e){out.error=e.message;break;} out.push(i);pc=(pc+i.size)&0xFFFFFF;
    if(['RTS','RTL','RTI','JMP','JML','BRK','COP','STP'].includes(i.mnemonic))break;
  }
  return out;
}
function formatInstruction(i){
  const bytes=i.raw.map(b=>hex(b,2)).join(' ').padEnd(11,' ');let op='';
  if(['ImmA','ImmX','Imm8'].includes(i.mode))op=' #$'+hex(i.operand,(i.size-1)*2);
  else if(i.mode==='Direct')op=' $'+hex(i.operand,2);else if(i.mode==='DirectX')op=' $'+hex(i.operand,2)+',X';else if(i.mode==='DirectY')op=' $'+hex(i.operand,2)+',Y';
  else if(i.mode==='Absolute')op=' $'+hex(i.operand,4);else if(i.mode==='AbsoluteX')op=' $'+hex(i.operand,4)+',X';else if(i.mode==='AbsoluteY')op=' $'+hex(i.operand,4)+',Y';
  else if(i.mode==='AbsoluteLong')op=' $'+hex(i.operand,6);else if(i.mode==='AbsoluteLongX')op=' $'+hex(i.operand,6)+',X';
  else if(i.mode==='DirectIndexedIndirectX')op=' ($'+hex(i.operand,2)+',X)';else if(i.mode==='DirectIndirect')op=' ($'+hex(i.operand,2)+')';else if(i.mode==='DirectIndirectY')op=' ($'+hex(i.operand,2)+'),Y';
  else if(i.mode==='DirectIndirectLong')op=' [$'+hex(i.operand,2)+']';else if(i.mode==='DirectIndirectLongY')op=' [$'+hex(i.operand,2)+'],Y';else if(i.mode==='StackRelative')op=' $'+hex(i.operand,2)+',S';else if(i.mode==='StackRelativeIndirectY')op=' ($'+hex(i.operand,2)+',S),Y';
  else if(i.mode==='AbsoluteIndirect')op=' ($'+hex(i.operand,4)+')';else if(i.mode==='AbsoluteIndexedIndirectX')op=' ($'+hex(i.operand,4)+',X)';else if(i.mode==='AbsoluteIndirectLong')op=' [$'+hex(i.operand,4)+']';
  else if(i.mode==='BlockMove')op=' $'+hex(i.operand&255,2)+',$'+hex((i.operand>>>8)&255,2);else if(i.mode==='Relative8')op=' rel8';else if(i.mode==='Relative16')op=' rel16';
  const tag=i.status==='unsupported'?'  ; UNSUPPORTED':i.status==='partial'?'  ; PARTIAL':'';
  return hex(i.pc,6)+'  '+bytes+i.mnemonic+op+tag;
}
function hardwareIssue(i){
  if(!['STA','STX','STY','STZ','LDA','LDX','LDY'].includes(i.mnemonic)||i.mode!=='Absolute')return null;
  const a=i.operand&0xFFFF;
  const ppuNative=new Set([0x2100,0x2101,0x2102,0x2103,0x2104,0x2105,0x2106,0x2107,0x2108,0x2109,0x210A,0x210B,0x210C,0x210D,0x210E,0x210F,0x2110,0x2111,0x2112,0x2113,0x2114,0x2115,0x2116,0x2117,0x2118,0x2119,0x211A,0x211B,0x211C,0x211D,0x211E,0x211F,0x2120,0x2121,0x2122,0x2123,0x2124,0x2125,0x2126,0x2127,0x2128,0x2129,0x212A,0x212B,0x212C,0x212D,0x212E,0x212F,0x2130,0x2131,0x2132,0x2133,0x2134,0x2135,0x2136,0x2137,0x2138,0x2139,0x213A,0x213B,0x213C,0x213D,0x213E,0x213F]);
  if(a>=0x2100&&a<=0x213F){
    if(ppuNative.has(a))return {kind:'HW-NATIVE',pc:i.pc,detail:'PPU $'+hex(a,4)+' traduzido para estado/memoria PPU C++'};
    return {kind:'PPU',pc:i.pc,detail:'registrador PPU $'+hex(a,4)+' ainda sem traducao especifica'};
  }
  if(a>=0x2140&&a<=0x2143)return {kind:'HW-NATIVE',pc:i.pc,detail:'porta APU $'+hex(a,4)+' ligada ao runtime SPC700 de 256 opcodes + DSP/BRR C++'};
  if(a===0x4200)return {kind:'HW-NATIVE',pc:i.pc,detail:'CPU I/O $4200 NMITIMEN traduzido para estado C++ de NMI/IRQ/joypad'};
  if(a===0x4201||a===0x4213)return {kind:'HW-NATIVE',pc:i.pc,detail:'CPU I/O $'+hex(a,4)+' WRIO/RDIO preservado no runtime nativo'};
  if(a===0x420B)return {kind:'HW-NATIVE',pc:i.pc,detail:'CPU I/O $420B MDMAEN traduzido para executor DMA C++'};
  if([0x4202,0x4203,0x4204,0x4205,0x4206,0x420D,0x4214,0x4215,0x4216,0x4217,0x2180,0x2181,0x2182,0x2183,0x4016,0x4017].includes(a))return {kind:'HW-NATIVE',pc:i.pc,detail:'CPU I/O $'+hex(a,4)+' traduzido para hardware de boot nativo C++'};
  if([0x4207,0x4208,0x4209,0x420A].includes(a))return {kind:'HW-NATIVE',pc:i.pc,detail:'CPU I/O $'+hex(a,4)+' H/V IRQ ligado ao scheduler de master-cycle (1364/linha) com HTime em dot e trigger calibrado'};
  if(a===0x420C)return {kind:'HW-NATIVE',pc:i.pc,detail:'CPU I/O $420C HDMAEN ligado ao evento HDMA de HBlank em master-cycle 1106, com mascara mid-frame e canais encerrados preservados'};
  if([0x4210,0x4211,0x4212,0x4218,0x4219,0x421A,0x421B,0x421C,0x421D,0x421E,0x421F].includes(a))return {kind:'HW-NATIVE',pc:i.pc,detail:'CPU I/O $'+hex(a,4)+' traduzido para scheduler/joypad nativo C++'};
  if(a>=0x4300&&a<=0x437F)return {kind:'HW-NATIVE',pc:i.pc,detail:'registrador DMA $'+hex(a,4)+' traduzido para estrutura de canal C++'};
  if(a>=0x4200&&a<=0x421F)return {kind:'CPU-IO',pc:i.pc,detail:'registrador CPU I/O $'+hex(a,4)+' ainda sem semantica especifica'};
  return null;
}
function cloneDecodeState(s){return {emulation:!!s.emulation,m8:!!s.m8,x8:!!s.x8,carry:s.carry===null?null:!!s.carry};}
function s8(v){v&=0xFF;return(v&0x80)?v-0x100:v;}
function s16(v){v&=0xFFFF;return(v&0x8000)?v-0x10000:v;}
function nextPc(i){return(i.pc+i.size)&0xFFFFFF;}
function flowTarget(i){
  const n=nextPc(i);
  if(i.mode==='Relative8')return (n&0xFF0000)|((n+s8(i.operand))&0xFFFF);
  if(i.mode==='Relative16')return (n&0xFF0000)|((n+s16(i.operand))&0xFFFF);
  if((i.mnemonic==='JSR'||i.mnemonic==='JMP')&&i.mode==='Absolute')return (i.pc&0xFF0000)|(i.operand&0xFFFF);
  if((i.mnemonic==='JSL'||i.mnemonic==='JML')&&i.mode==='AbsoluteLong')return i.operand&0xFFFFFF;
  return null;
}
function interruptVector(rom,i,state){
  if(i.mnemonic!=='BRK'&&i.mnemonic!=='COP')return null;
  const emu=!!state.emulation;
  const va=i.mnemonic==='BRK'?(emu?0xFFFE:0xFFE6):(emu?0xFFF4:0xFFE4);
  const off=snesToRom(rom,va);
  if(off===null||off+1>=rom.data.length)return null;
  const target=read16(rom.data,off);
  return target>=0x8000&&isExecutableEntryTarget(rom,target)?target:null;
}
function isVectorTableWindow(a){const lo=a&0xFFFF;return lo>=0xFFE0&&lo<=0xFFFF;}
function isExecutableEntryTarget(rom,a){a&=0xFFFFFF;return isRomAddress(rom,a)&&!isVectorTableWindow(a);}
function readVectorTarget(rom,vectorAddr){
  const off=snesToRom(rom,vectorAddr);
  if(off===null||off+1>=rom.data.length)return null;
  const target=read16(rom.data,off)&0xFFFF;
  if(target<0x8000)return null;
  return isExecutableEntryTarget(rom,target)?target:null;
}
function systemEntryPoints(rom){
  const nativeStates=[];for(const m8 of [true,false])for(const x8 of [true,false])nativeStates.push({emulation:false,m8,x8,carry:null});
  const specs=[['RESET',0xFFFC,{emulation:true,m8:true,x8:true,carry:null}]];
  for(const st of nativeStates){specs.push(['NMI-NATIVE-M'+(st.m8?8:16)+'X'+(st.x8?8:16),0xFFEA,st]);specs.push(['IRQ-NATIVE-M'+(st.m8?8:16)+'X'+(st.x8?8:16),0xFFEE,st]);}
  specs.push(['NMI-EMU',0xFFFA,{emulation:true,m8:true,x8:true,carry:null}],['IRQ-BRK-EMU',0xFFFE,{emulation:true,m8:true,x8:true,carry:null}]);
  const out=[];
  for(const [name,va,state] of specs){const target=readVectorTarget(rom,va);if(target!==null)out.push({name,vector:va,target,state});}
  const seen=new Set();return out.filter(e=>{const k=e.target+'|'+stateKeySig(e.state);if(seen.has(k))return false;seen.add(k);return true;});
}
function isCondBranch(m){return ['BEQ','BNE','BCC','BCS','BMI','BPL','BVC','BVS'].includes(m);}
function isUncondBranch(m){return m==='BRA'||m==='BRL';}
function isDirectCall(i){return (i.mnemonic==='JSR'&&i.mode==='Absolute')||(i.mnemonic==='JSL'&&i.mode==='AbsoluteLong');}
function isDirectJump(i){return (i.mnemonic==='JMP'&&i.mode==='Absolute')||(i.mnemonic==='JML'&&i.mode==='AbsoluteLong');}
function isReturn(i){return i.mnemonic==='RTS'||i.mnemonic==='RTL'||i.mnemonic==='RTI';}
function stateKeySig(s){return `${s.emulation?1:0}${s.m8?1:0}${s.x8?1:0}${s.carry===null?'Q':s.carry?1:0}`;}
function normEntryState(s){s=s||{};return {emulation:!!s.emulation,m8:!!s.m8,x8:!!s.x8,carry:typeof s.carry==='boolean'?s.carry:null};}
function stateSig(s){return `${s.emulation?1:0}${s.m8?1:0}${s.x8?1:0}${s.carry===null?'?':s.carry?1:0}`;}
function stateNodeKey(pc,s){return hex(pc&0xFFFFFF,6)+'|'+stateKeySig(s);}
function fnStateKey(pc,s){return (pc&0xFFFFFF)+'|'+stateKeySig(s);}

function plausibleIndirectTarget(rom,target,state){
  if(!isRomAddress(rom,target))return false;
  try{const st=cloneDecodeState(state),i=decodeOne(rom,target,st);return !['BRK','COP','STP','WDM'].includes(i.mnemonic);}catch(_){return false;}
}
function discoverPeaIndexedDispatch(rom,i,state,maxEntries=96){
  if(i.mnemonic!=='JMP'||i.mode!=='AbsoluteIndexedIndirectX')return null;
  const bank=i.pc&0xFF0000,base=i.operand&0xFFFF,d=rom.data;
  const byteAt=delta=>{const off=snesToRom(rom,bank|((i.pc+delta)&0xFFFF));return off===null||off>=d.length?null:d[off];};
  const returnPc=bank|((i.pc+3)&0xFFFF);
  // PEA return-1; JMP (vectors,X); straight-line cleanup; RTS; vectors.
  // Decode a small continuation, rather than scanning raw bytes for an RTS.
  // The anchor and table extent only discover candidates: runtime dispatch and
  // index-domain / semantic-proof requirements remain unchanged.
  if(byteAt(-3)!==0xF4||byteAt(-2)===null||byteAt(-1)===null||(byteAt(-2)|byteAt(-1)<<8)!==((returnPc-1)&0xFFFF))return null;
  const continuationBytes=(base-(returnPc&0xFFFF))&0xFFFF;
  if(continuationBytes<1||continuationBytes>32)return null;
  const continuationState=cloneDecodeState(state);let used=0,hasRts=false;
  while(used<continuationBytes){
    const continuationPc=bank|((returnPc+used)&0xFFFF);
    let q;try{q=decodeOne(rom,continuationPc,continuationState);}catch(_){return null;}
    // decodeOne currently fetches operands contiguously; do not let bytes from
    // the next mapped ROM bank establish a false structural continuation.
    if((continuationPc&0xFFFF)+q.size>0x10000)return null;
    if(used+q.size>continuationBytes||!q.supported)return null;
    used+=q.size;
    if(q.mnemonic==='RTS'){hasRts=used===continuationBytes;break;}
    if(['Relative8','Relative16'].includes(q.mode)||['JMP','JML','JSR','JSL','BRK','COP','STP','WAI','RTL','RTI','PLP','XCE'].includes(q.mnemonic))return null;
  }
  if(!hasRts)return null;
  const firstOff=snesToRom(rom,bank|base);if(firstOff===null||firstOff+1>=d.length)return null;
  let end=d[firstOff]|d[firstOff+1]<<8;
  if(end<=base||(end-base)%2||end-base>maxEntries*2)return null;
  const targets=[];
  for(let at=base;at<end;at+=2){
    const p=snesToRom(rom,bank|at);if(p===null||p+1>=d.length)return null;
    const low=d[p]|d[p+1]<<8,target=bank|low;
    if(low<=base||(low<end&&(low-base)%2!==0)||!plausibleIndirectTarget(rom,target,state))return null;
    if(low<end)end=low;
    targets.push(target);
  }
  if(targets.length!==(end-base)/2||targets.some(t=>(t&0xFFFF)<end))return null;
  return {targets:[...new Set(targets)],returnPc};
}
function discoverInlineIndexedDispatch(rom,i,state,maxEntries=128){
  if(i.mnemonic!=='JMP'||i.mode!=='AbsoluteIndexedIndirectX')return null;
  const bank=i.pc&0xFF0000,base=i.operand&0xFFFF,next=nextPc(i)&0xFFFF,d=rom.data,joff=snesToRom(rom,i.pc);
  // Common SNES dispatcher: ... ASL ; TAX ; JMP (table,X) ; table immediately follows.
  // The first/minimum handler address bounds the table itself. This discovers the closed
  // structural target set without pretending that the runtime X range is proven.
  if(joff===null||base!==next||joff<2||d[joff-1]!==0xAA)return null;
  let p=joff-2,scale=0;while(p>=0&&d[p]===0x0A&&scale<8){scale++;p--;}if(!scale)return null;
  const firstOff=snesToRom(rom,bank|base);if(firstOff===null||firstOff+1>=d.length)return null;
  let end=d[firstOff]|(d[firstOff+1]<<8);
  if(end<=base||(end-base)%2||((end-base)/2)>maxEntries)return null;
  const targets=[];
  for(let at=base;at<end;at+=2){
    const po=snesToRom(rom,bank|at);if(po===null||po+1>=d.length)return null;
    const low=d[po]|(d[po+1]<<8),target=bank|low;
    if(low<=at+1||!plausibleIndirectTarget(rom,target,state))return null;
    if(low<end){if((low-base)%2)return null;end=low;}
    targets.push(target);
  }
  if(targets.length!==(end-base)/2||targets.some(t=>(t&0xFFFF)<end))return null;
  return {targets:[...new Set(targets)],tableStart:bank|base,tableEnd:bank|end,scale,indexBoundsProven:false};
}
function discoverIndexedIndirectTargets(rom,i,state,maxEntries=128){
  if(i.mode!=='AbsoluteIndexedIndirectX')return [];
  const structural=discoverInlineIndexedDispatch(rom,i,state,maxEntries);if(structural)return structural.targets;
  const inline=discoverPeaIndexedDispatch(rom,i,state,maxEntries);if(inline)return inline.targets;
  const joff=snesToRom(rom,i.pc);if(joff===null)return [];
  const d=rom.data,bank=i.pc&0xFF0000,base=i.operand&0xFFFF;
  const readTable=(maxX)=>{const out=[];for(let x=0;x<=maxX&&out.length<maxEntries;x+=2){const po=snesToRom(rom,bank|((base+x)&0xFFFF));if(po===null||po+1>=d.length)break;const t=bank|(d[po]|(d[po+1]<<8));if(!plausibleIndirectTarget(rom,t,state))break;if(!out.includes(t))out.push(t);}return out;};
  // Forma 1: CMP #min ; ... ; EOR #max ; ASL [ASL...] ; TAX ; JMP (table,X).
  // Muito usada quando a tabela fica imediatamente depois do JMP: X vira um indice par de ponteiros 16-bit.
  // A faixa e demonstrada por (max-min), portanto nao precisamos adivinhar quantas entradas existem.
  let p=joff-1;if(p>=0&&d[p]===0xAA){
    let q=p-1,left=0;while(q>=0&&d[q]===0x0A&&left<8){left++;q--;}
    const immBytes=state.m8?1:2, eorOp=0x49, cmpOp=0xC9;
    if(left>0){
      let maxv=null,eorAt=-1;if(immBytes===2&&q>=2&&d[q-2]===eorOp){maxv=d[q-1]|(d[q]<<8);eorAt=q-2;}else if(immBytes===1&&q>=1&&d[q-1]===eorOp){maxv=d[q];eorAt=q-1;}
      if(maxv!==null){
        const lo=Math.max(0,eorAt-0x18);let minv=null;for(let at=eorAt-1;at>=lo;at--){if(d[at]!==cmpOp)continue;if(immBytes===2&&at+2<eorAt){minv=d[at+1]|(d[at+2]<<8);break;}if(immBytes===1&&at+1<eorAt){minv=d[at+1];break;}}
        if(minv!==null&&maxv>=minv){const count=(maxv-minv)+1,maxX=(count-1)<<left;if(count>=2&&count<=maxEntries&&maxX<=0x400){const out=readTable(maxX);if(out.length>=Math.min(2,count))return out;}}
      }
    }
  }
  // Forma 1b: LDA dp ; ASL ; TAX ; JMP (table,X). O limite pode estar nas escritas da
  // variavel de estado, e nao ao lado do salto. Coletamos apenas constantes 16-bit pequenas
  // gravadas diretamente nesse mesmo DP e exigimos evidencia de zero + pelo menos outro valor.
  if(!state.m8&&joff>=4&&d[joff-1]===0xAA&&d[joff-2]===0x0A&&d[joff-4]===0xA5){
    const dp=d[joff-3],vals=new Set(),limit=31;let sawZero=false;
    for(let at=0;at+4<d.length;at++){
      if(d[at]===0x64&&d[at+1]===dp){vals.add(0);sawZero=true;}
      if(d[at]===0xA9&&d[at+2]===0x00&&d[at+3]===0x85&&d[at+4]===dp&&d[at+1]<=limit)vals.add(d[at+1]);
    }
    if(sawZero&&vals.size>=2){const maxv=Math.max(...vals);if(maxv>=1&&maxv<=limit){const out=readTable(maxv*2);if(out.length===maxv+1)return out;}}
  }
  // Forma 2: AND #mask ; LSR A... ; [PHX] ; TAX ; JMP (table,X).
  // Assim evitamos varrer bytes arbitrarios da ROM como ponteiros quando X nao tem limite demonstravel.
  p=joff-1;if(p<0||d[p]!==0xAA)return [];p--;if(p>=0&&d[p]===0xDA)p--;
  let shifts=0;while(p>=0&&d[p]===0x4A&&shifts<15){shifts++;p--;}
  if(!shifts)return [];
  let mask=null;if(!state.m8&&p>=2&&d[p-2]===0x29){mask=d[p-1]|(d[p]<<8);}else if(state.m8&&p>=1&&d[p-1]===0x29){mask=d[p];}
  if(mask===null)return [];
  const maxX=(mask>>>shifts)&0xFFFF;if(maxX>0x400||maxX+1>maxEntries*2)return [];
  return readTable(maxX);
}
function tailRoutineStoresLongVector(rom,start,ptr,state){
  let pc=start&0xFFFFFF,st=cloneDecodeState(state),haveLow=false,haveBank=false;
  const matches=(ins,dest)=>((ins.mode==='Direct'&&(ins.operand&0xFF)===(dest&0xFF))||(ins.mode==='Absolute'&&(ins.operand&0xFFFF)===(dest&0xFFFF)));
  for(let step=0;step<20;step++){
    const before=cloneDecodeState(st);let ins;try{ins=decodeOne(rom,pc,st);}catch(_){return false;}
    const jt=isDirectJump(ins)?flowTarget(ins):null;
    // Segue pequenos trampolins JMP/JML antes dos stores, sem inventar fluxo dinamico.
    if(!haveLow&&!haveBank&&jt!==null){pc=jt&0xFFFFFF;continue;}
    if(ins.mnemonic==='STA'&&matches(ins,ptr)&&!before.m8)haveLow=true;
    if((ins.mnemonic==='STX'||ins.mnemonic==='STY')&&matches(ins,(ptr+2)&0xFFFF)&&!before.x8)haveBank=true;
    if(haveLow&&haveBank)return true;
    if(isReturn(ins)||ins.mnemonic==='STP'||ins.mnemonic==='WAI'||isDirectJump(ins))break;
    pc=nextPc(ins);
  }
  return false;
}
function discoverTailSeededLongVectorTargets(rom,ptr,state){
  // Padrao de engine: LDA #addr16 ; LDX/LDY #bank ; JML trampoline.
  // O trampoline (as vezes via JMP adicional) grava A em ptr e X/Y em ptr+2.
  // Propagamos os imediatos atraves desse tail-call para descobrir o alvo do futuro JMP [ptr].
  if(state.m8||state.x8)return [];
  const d=rom.data,out=new Map();
  const tryCandidate=(at,aFirst)=>{
    const opR=aFirst?d[at+3]:d[at], opA=aFirst?d[at]:d[at+3];
    if(opA!==0xA9||(opR!==0xA2&&opR!==0xA0)||d[at+6]!==0x5C)return;
    const low=aFirst?(d[at+1]|(d[at+2]<<8)):(d[at+4]|(d[at+5]<<8));
    const rv=aFirst?(d[at+4]|(d[at+5]<<8)):(d[at+1]|(d[at+2]<<8));
    const tramp=(d[at+7]|(d[at+8]<<8)|(d[at+9]<<16))&0xFFFFFF;
    if(!isRomAddress(rom,tramp)||!tailRoutineStoresLongVector(rom,tramp,ptr,state))return;
    const t=((rv&0xFF)<<16)|(low&0xFFFF);if(!plausibleIndirectTarget(rom,t,state))return;
    out.set(t,(out.get(t)||0)+20);
  };
  for(let at=0;at+9<d.length;at++){tryCandidate(at,true);tryCandidate(at,false);}
  return [...out].sort((a,b)=>b[1]-a[1]).slice(0,32).map(([t])=>t);
}
function discoverRamLongVectorTargets(rom,i,state){
  if(i.mode!=='AbsoluteIndirectLong')return [];
  const ptr=i.operand&0xFFFF,joff=snesToRom(rom,i.pc);if(joff===null)return [];
  const sameChunk=joff>>>16,d=rom.data,lows=[],banks=[],scores=new Map(),window=18;
  const regs=[[0xA9,0x85,0x8D],[0xA2,0x86,0x8E],[0xA0,0x84,0x8C]];
  const nearStores=(at,dpOp,absOp,dest)=>{const out=[];for(let p=at+3;p<Math.min(d.length-2,at+3+window);p++){if(dest<0x100&&d[p]===dpOp&&d[p+1]===(dest&0xFF))out.push(p);if(d[p]===absOp&&d[p+1]===(dest&0xFF)&&d[p+2]===((dest>>8)&0xFF))out.push(p);}return out;};
  for(let at=0;at+6<d.length;at++)for(const spec of regs){if(d[at]!==spec[0])continue;const imm=d[at+1]|(d[at+2]<<8);for(const st of nearStores(at,spec[1],spec[2],ptr))lows.push({at,st,imm});const bp=(ptr+2)&0xFFFF;for(const st of nearStores(at,spec[1],spec[2],bp))banks.push({at,st,bank:imm&0xFF});}
  for(const lo of lows)for(const bk of banks){if(Math.abs(lo.st-bk.st)>32||Math.abs(lo.at-bk.at)>32)continue;const t=((bk.bank&0xFF)<<16)|(lo.imm&0xFFFF);if(!plausibleIndirectTarget(rom,t,state))continue;let sc=3;if((lo.at>>>16)===sameChunk||(bk.at>>>16)===sameChunk)sc+=5;if(Math.abs(lo.at-joff)<0x200||Math.abs(bk.at-joff)<0x200)sc+=4;scores.set(t,(scores.get(t)||0)+sc);}
  for(const t of discoverTailSeededLongVectorTargets(rom,ptr,state))scores.set(t,Math.max(scores.get(t)||0,20));
  return [...scores].filter(([,sc])=>sc>=5).sort((a,b)=>b[1]-a[1]).slice(0,32).map(([t])=>t);
}
const ramVectorEvidenceCache=new WeakMap();
function mappedBankUnit(rom,off){return off>>>(rom.header.mapping===MAP.LOROM?15:16);}
function offsetInProgramBank(rom,off,bank){
  if(rom.header.mapping===MAP.LOROM)return ((bank&0xFF)<<16)|(0x8000|(off&0x7FFF));
  return ((bank&0xFF)<<16)|(off&0xFFFF);
}
function discoverRamVectorEvidence(rom,i,state){
  if(i.mode!=='AbsoluteIndirect')return {targets:[],resolution:null};
  const ptr=i.operand&0xFFFF,bank=i.pc&0xFF0000,joff=snesToRom(rom,i.pc);if(joff===null)return {targets:[],resolution:null};
  let cache=ramVectorEvidenceCache.get(rom);if(!cache){cache=new Map();ramVectorEvidenceCache.set(rom,cache);}const ck=[bank,ptr,state.m8?1:0,state.x8?1:0].join('|');if(cache.has(ck))return cache.get(ck);
  const sameUnit=mappedBankUnit(rom,joff),scores=new Map(),d=rom.data,immediateWriters=[],recordTables=[],rawDirectStores=[];
  const add=(at,imm,weight=1)=>{const t=bank|(imm&0xFFFF);if(!plausibleIndirectTarget(rom,t,state))return null;let sc=weight;if(mappedBankUnit(rom,at)===sameUnit)sc+=4;scores.set(t,Math.max(scores.get(t)||0,sc));return t;};
  // Track raw absolute STA patterns in the same mapped program bank. This is not a proof
  // against indirect/aliased writers, but lets us prove coverage of every direct STA $ptr byte pattern.
  for(let at=0;at+2<d.length;at++)if(mappedBankUnit(rom,at)===sameUnit&&d[at]===0x8D&&d[at+1]===(ptr&0xFF)&&d[at+2]===((ptr>>>8)&0xFF))rawDirectStores.push(offsetInProgramBank(rom,at,(i.pc>>>16)&0xFF));
  // LDA/LDX/LDY #imm16 followed immediately by STA/STX/STY in DP/ABS.
  for(let at=0;at+6<d.length;at++){
    const op=d[at];if(op!==0xA9&&op!==0xA2&&op!==0xA0)continue;if((op===0xA9&&state.m8)||((op===0xA2||op===0xA0)&&state.x8))continue;
    const imm=d[at+1]|(d[at+2]<<8),st=op===0xA9?0x85:op===0xA2?0x86:0x84,sta=op===0xA9?0x8D:op===0xA2?0x8E:0x8C;
    let storeAt=null;if(ptr<0x100&&d[at+3]===st&&d[at+4]===(ptr&0xFF))storeAt=at+3;if(d[at+3]===sta&&d[at+4]===(ptr&0xFF)&&d[at+5]===(ptr>>8))storeAt=at+3;
    if(storeAt===null)continue;const t=add(at,imm,1);if(t!==null&&mappedBankUnit(rom,at)===sameUnit)immediateWriters.push({pc:offsetInProgramBank(rom,storeAt,(i.pc>>>16)&0xFF),target:t,kind:'immediate-store'});
  }
  // Record-table writer: ASL... ; TAY/TAX ; companion-load table-2,index ; LDA table,index ; STA ptr.
  // This pattern is common in SNES engines that select a behavior function and companion data
  // from fixed-width records. We require DB=PB evidence (PHB/PHK/PLB nearby), a power-of-two
  // stride proven by ASL, a companion ROM pointer, executable handler words, and a zero/invalid
  // terminator. This is deliberately stricter than a blind pointer-table scan.
  if(!state.m8){for(const storeOff of rawDirectStores.map(pc=>snesToRom(rom,pc)).filter(x=>x!==null)){
    const at=storeOff;if(at<9)continue;const loadOp=d[at-3],loadAbs=d[at-2]|(d[at-1]<<8);let transfer=0,companionOp=0;
    if(loadOp===0xB9){transfer=0xA8;companionOp=0xBE;} // LDA abs,Y ; companion LDX abs,Y
    else if(loadOp===0xBD){transfer=0xAA;companionOp=0xBC;} // LDA abs,X ; companion LDY abs,X
    else continue;
    if(d[at-6]!==companionOp)continue;const companionAbs=d[at-5]|(d[at-4]<<8);if(((companionAbs+2)&0xFFFF)!==loadAbs)continue;
    if(d[at-7]!==transfer)continue;let p=at-8,scale=0;while(p>=0&&d[p]===0x0A&&scale<5){scale++;p--;}if(!scale)continue;const stride=1<<scale;if(stride<4||stride>32)continue;
    let dbEqualsPb=false;for(let q=Math.max(0,p-24);q+2<=p;q++)if(d[q]===0x8B&&d[q+1]===0x4B&&d[q+2]===0xAB){dbEqualsPb=true;break;}if(!dbEqualsPb)continue;
    const tableStart=bank|loadAbs,companionStart=bank|companionAbs,targets=[],records=[];let terminated=false,terminator=null;
    for(let n=0;n<128;n++){
      const ha=(loadAbs+n*stride)&0xFFFF,ca=(companionAbs+n*stride)&0xFFFF,ho=snesToRom(rom,bank|ha),co=snesToRom(rom,bank|ca);if(ho===null||co===null||ho+1>=d.length||co+1>=d.length)break;
      const handler=d[ho]|(d[ho+1]<<8),comp=d[co]|(d[co+1]<<8),target=bank|handler,compAddr=bank|comp;
      if(handler===0||comp===0||!plausibleIndirectTarget(rom,target,state)||!isRomAddress(rom,compAddr)){terminated=true;terminator={index:n,handler,companion:comp};break;}
      targets.push(target);records.push({index:n,companion:compAddr,target});
    }
    if(targets.length<2||!terminated)continue;for(const t of targets)scores.set(t,Math.max(scores.get(t)||0,20));recordTables.push({writer_pc:offsetInProgramBank(rom,at,(i.pc>>>16)&0xFF),table_start:tableStart,companion_start:companionStart,stride,entries:targets.length,unique_targets:[...new Set(targets)].length,targets:[...new Set(targets)].sort((a,b)=>a-b),terminator});
  }}
  // Computed local entry: ADC #base16 ; STA ptr ; ... ; JMP (ptr).
  if(!state.m8){
    const lo=Math.max(0,joff-0x60),hi=Math.min(joff,d.length-5);
    for(let at=lo;at<=hi;at++){
      if(d[at]!==0x69)continue;const imm=d[at+1]|(d[at+2]<<8);let store=false;
      if(ptr<0x100&&d[at+3]===0x85&&d[at+4]===(ptr&0xFF))store=true;if(d[at+3]===0x8D&&d[at+4]===(ptr&0xFF)&&d[at+5]===((ptr>>8)&0xFF))store=true;if(!store)continue;
      const base=bank|imm,bo=snesToRom(rom,base);if(bo===null)continue;let first;try{first=decodeOne(rom,base,cloneDecodeState(state));}catch(_){continue;}if(first.size!==1||isReturn(first)||first.mnemonic==='STP'||first.mnemonic==='WAI')continue;
      const op0=d[bo],targets=[];for(let k=0;k<32&&bo+k<d.length;k++){if(d[bo+k]!==op0)break;const t=(base+k)&0xFFFFFF;if(!plausibleIndirectTarget(rom,t,state))break;targets.push(t);}if(targets.length<4)continue;for(const t of targets)scores.set(t,Math.max(scores.get(t)||0,12));
    }
  }
  const targets=[...scores].filter(([,sc])=>sc>=4).sort((a,b)=>b[1]-a[1]).slice(0,64).map(([t])=>t).sort((a,b)=>a-b),explained=new Set([...immediateWriters.map(x=>x.pc),...recordTables.map(x=>x.writer_pc)]),directCovered=rawDirectStores.length>0&&rawDirectStores.every(x=>explained.has(x));
  const result={targets,resolution:{kind:recordTables.length?'ram-vector-writer-domain':'ram-vector-candidates',index_bounds_proven:false,direct_absolute_sta_sites:rawDirectStores.length,direct_absolute_sta_covered:explained.size,direct_absolute_writer_closure:directCovered,writer_scope:'direct absolute STA byte patterns in the mapped program bank only; indirect/aliased WRAM writes are not disproven',immediate_writers:immediateWriters,record_tables:recordTables}};cache.set(ck,result);return result;
}
function discoverRamVectorTargets(rom,i,state){return discoverRamVectorEvidence(rom,i,state).targets;}
function discoverIndirectTargets(rom,i,state){
  if(i.mode==='AbsoluteIndirectLong')return discoverRamLongVectorTargets(rom,i,state);
  if(i.mode==='AbsoluteIndexedIndirectX')return discoverIndexedIndirectTargets(rom,i,state);
  if(i.mode==='AbsoluteIndirect')return discoverRamVectorTargets(rom,i,state);
  return [];
}
function discoverPeaStackBootstrapTargets(rom,fn,maxTargets=32){
  const ins=(fn.instructions||[]).slice().sort((a,b)=>a.pc-b.pc),out=new Map();
  for(let n=0;n<ins.length;n++){
    const txs=ins[n];if(txs.mnemonic!=='TXS')continue;
    const peas=[];
    for(let j=n+1;j<ins.length&&j<=n+10;j++){
      const q=ins[j];if(((q.pc-txs.pc)&0xFFFF)>0x28)break;
      if(q.mnemonic==='PEA')peas.push(q);
      // Uma mudanca posterior explicita da stack invalida a ancora. Pushes PEA/PHA etc. fazem parte do padrao.
      if(j>n+1&&['TXS','TCS'].includes(q.mnemonic))break;
    }
    // TXS + duas PEA e um bootstrap classico de pilha de retornos; uma unica PEA so e aceita se vier imediatamente apos TXS.
    if(!peas.length|| (peas.length===1&&((peas[0].pc-txs.pc)&0xFFFF)>4))continue;
    for(const pea of peas){
      const st=normEntryState(pea.stateIn||fn.entryState),bank=pea.pc&0xFF0000,target=bank|(((pea.operand&0xFFFF)+1)&0xFFFF);
      if(!plausibleIndirectTarget(rom,target,st))continue;
      const k=target+'|'+stateKeySig(st);if(!out.has(k))out.set(k,{target,state:st,from:pea.pc,kind:'STACK-PEA-BOOTSTRAP'});if(out.size>=maxTargets)return [...out.values()];
    }
  }
  return [...out.values()];
}
function discoverStackRtsTrampolineTargets(rom,fn,maxTargets=64){
  const out=new Map(),ins=fn.instructions||[];
  const sameBank=(a,b)=>((a^b)&0xFF0000)===0;
  const before=(pc,span=0x90)=>ins.filter(x=>x.pc<pc&&sameBank(x.pc,pc)&&((pc-x.pc)&0xFFFF)<=span).sort((a,b)=>a.pc-b.pc);
  for(const rts of ins){
    if(rts.mnemonic!=='RTS')continue;
    const prev=before(rts.pc,8).filter(x=>x.mnemonic==='PEI'&&x.mode==='Direct'&&nextPc(x)===rts.pc);
    for(const pei of prev){
      const ptr=pei.operand&0xFF,seq=before(pei.pc,0xA0);
      const lowStores=seq.filter(x=>x.mnemonic==='STA'&&x.mode==='Direct'&&(x.operand&0xFF)===ptr&&x.stateIn&&x.stateIn.m8);
      if(!lowStores.length)continue;const lowStore=lowStores[lowStores.length-1];
      const wordStores=seq.filter(x=>x.pc<lowStore.pc&&x.mnemonic==='STA'&&x.mode==='Direct'&&(x.operand&0xFF)===ptr&&x.stateIn&&!x.stateIn.m8);
      // Caso 1: ponteiro de 16 bits semeado estaticamente e depois apenas o byte baixo e recalculado.
      // Caso 2: jogos como DKC3 mantem o byte alto do ponteiro em DP e calculam apenas o baixo
      // (LDA/AND/ASL/ADC/STA + PEI + RTS). Nesse caso inferimos a pagina ROM procurando uma
      // ilha densa de stubs JMP/JML coerente com todos os baixos possiveis.
      if(!wordStores.length){
        const expr=seq.filter(x=>x.pc<lowStore.pc&&((lowStore.pc-x.pc)&0xFFFF)<=0x18);
        const ands=expr.filter(x=>x.mnemonic==='AND'&&x.mode==='ImmA'&&x.stateIn&&x.stateIn.m8);
        if(!ands.length)continue;const ai=ands[ands.length-1],ops=expr.filter(x=>x.pc>=ai.pc&&x.pc<lowStore.pc);
        const allowed=new Set(['AND','ASL','LSR','ADC','ORA','CLC','SEC','NOP']);if(ops.some(x=>!allowed.has(x.mnemonic)))continue;
        const vals=new Set();
        for(let seed=0;seed<256;seed++)for(let cin=0;cin<2;cin++){
          let v=seed&0xFF,c=cin,valid=true;
          for(const x of ops){
            if(x.mnemonic==='AND')v&=x.operand&0xFF;
            else if(x.mnemonic==='ASL'&&x.mode==='Accumulator'){c=(v>>7)&1;v=(v<<1)&0xFF;}
            else if(x.mnemonic==='LSR'&&x.mode==='Accumulator'){c=v&1;v>>>=1;}
            else if(x.mnemonic==='ADC'&&x.mode==='ImmA'){const z=v+(x.operand&0xFF)+c;c=z>0xFF?1:0;v=z&0xFF;}
            else if(x.mnemonic==='ORA'&&x.mode==='ImmA')v|=x.operand&0xFF;
            else if(x.mnemonic==='CLC')c=0;else if(x.mnemonic==='SEC')c=1;else if(x.mnemonic==='NOP'){}else{valid=false;break;}
          }
          if(valid)vals.add(v&0xFF);
        }
        const lows=[...vals];if(!lows.length||lows.length>32)continue;const st=normEntryState(rts.stateOut||rts.stateIn),bank=rts.pc&0xFF0000;
        const stubScore=t=>{const o=snesToRom(rom,t);if(o===null)return 0;const b=rom.data[o],b1=o+1<rom.data.length?rom.data[o+1]:0;if(b===0x4C||b===0x5C)return 4;if(b===0xEA&&(b1===0x4C||b1===0x5C))return 3;if(b===0x80||b===0x82)return 2;return 0;};
        let bestHi=-1,bestStrong=-1,bestScore=-1;for(let hi=0;hi<256;hi++){let strong=0,score=0;for(const lo of lows){const raw=((hi<<8)|lo)&0xFFFF,t=bank|((raw+1)&0xFFFF),sc=stubScore(t);if(sc>=3)strong++;score+=sc;}if(strong>bestStrong||(strong===bestStrong&&score>bestScore)){bestHi=hi;bestStrong=strong;bestScore=score;}}
        const need=Math.max(3,Math.ceil(lows.length/2));if(bestStrong<need)continue;
        for(const lo of lows){const raw=((bestHi<<8)|lo)&0xFFFF,t=bank|((raw+1)&0xFFFF);if(!plausibleIndirectTarget(rom,t,st))continue;const k=t+'|'+stateKeySig(st);if(!out.has(k))out.set(k,{target:t,state:st,from:rts.pc,kind:'STACK-RTS-LOWBYTE-TABLE'});if(out.size>=maxTargets)return [...out.values()];}
        continue;
      }
      const wordStore=wordStores[wordStores.length-1];
      const seedSeq=seq.filter(x=>x.pc<wordStore.pc&&((wordStore.pc-x.pc)&0xFFFF)<=0x20);
      const seeds=seedSeq.filter(x=>x.mnemonic==='LDA'&&x.mode==='ImmA'&&x.stateIn&&!x.stateIn.m8);
      if(!seeds.length)continue;const seed=seeds[seeds.length-1],base=seed.operand&0xFFFF;
      const expr=seq.filter(x=>x.pc>wordStore.pc&&x.pc<lowStore.pc);
      const ands=expr.filter(x=>x.mnemonic==='AND'&&x.mode==='ImmA'&&x.stateIn&&x.stateIn.m8);
      let lows=[];
      if(ands.length){
        const ai=ands[ands.length-1];let shifts=0,ok=true;
        for(const x of expr.filter(q=>q.pc>ai.pc)){
          if(x.mnemonic==='LSR'&&x.mode==='Accumulator')shifts++;
          else if(x.pc===lowStore.pc)break;
          else if(['STA','INY','INX','DEY','DEX','NOP'].includes(x.mnemonic))continue;
          else if(['LDA','ADC','SBC','ORA','EOR','ASL','ROL','ROR','INC','DEC','TAX','TAY','TXA','TYA'].includes(x.mnemonic)){ok=false;break;}
        }
        if(ok&&shifts<=7){const mask=ai.operand&0xFF,set=new Set();for(let v=0;v<256;v++)set.add(((v&mask)>>>shifts)&0xFF);lows=[...set];}
      }
      if(!lows.length){
        const imm=expr.filter(x=>x.mnemonic==='LDA'&&x.mode==='ImmA'&&x.stateIn&&x.stateIn.m8);
        if(imm.length)lows=[imm[imm.length-1].operand&0xFF];
      }
      if(!lows.length||lows.length>32)continue;
      const st=normEntryState(rts.stateOut||rts.stateIn),bank=rts.pc&0xFF0000;
      for(const lo of lows){const raw=(base&0xFF00)|(lo&0xFF),t=bank|((raw+1)&0xFFFF);if(!plausibleIndirectTarget(rom,t,st))continue;const k=t+'|'+stateKeySig(st);if(!out.has(k))out.set(k,{target:t,state:st,from:rts.pc,kind:'STACK-RTS-PEI'});if(out.size>=maxTargets)return [...out.values()];}
    }
  }
  return [...out.values()];
}
function decodeCfgFunction(rom,start,max=1024,initialState={emulation:true,m8:true,x8:true,carry:null},summaries=null,dispatchHints=null){
  const byKey=new Map(),work=[{pc:start&0xFFFFFF,state:cloneDecodeState(initialState),stack:[]}],calls=[],edges=[],issues=[],exits=new Map(),returnSiteKeys=new Set();
  // Estados do return-site: se o chamador ja conhece o estado de saida (M/X/E) do callee, usa-o; senao assume o estado da chamada.
  const returnStates=(targets,after)=>{const out=new Map();for(const t of targets){const ex=summaries&&summaries.get(fnStateKey(t,after));if(ex)for(const e of ex.values())out.set(stateKeySig(e),cloneDecodeState(e));}if(!out.size)out.set(stateKeySig(after),cloneDecodeState(after));return [...out.values()];};
  const hintedTargets=pc=>{const raw=dispatchHints&&dispatchHints.get(pc&0xFFFFFF);return Array.isArray(raw)?raw.filter(t=>plausibleIndirectTarget(rom,t,initialState)):[];};
  const mergeTargets=(a,b)=>[...new Set([...(a||[]),...(b||[])])].sort((x,y)=>x-y);
  let activeStack=[];
  const stackKey=stack=>stack.map(v=>v===null?'B':stateKeySig(v)).join(',');
  const nodeKey=(pc,st,stack)=>stateNodeKey(pc,st)+'|S:'+stackKey(stack);
  const enqueueReturnSite=(n,states,source,flow)=>{for(const st of states){if(enqueue(n,st,source,flow))returnSiteKeys.add(nodeKey(n,st,activeStack));}};
  const enqueue=(q,st,source,flow)=>{
    if(q===null||q===undefined)return false;
    q&=0xFFFFFF;
    if(!isRomAddress(rom,q)){
      issues.push({kind:'CFG-NONROM-TARGET',pc:source,detail:(flow||'fluxo')+' aponta para $'+hex(q,6)+' que nao pertence a ROM '+rom.header.mapping+'; destino nao seguido'});
      return false;
    }
    const key=nodeKey(q,st,activeStack);if(!byKey.has(key))work.push({pc:q,state:cloneDecodeState(st),stack:activeStack.slice()});return true;
  };
  while(work.length&&byKey.size<max){
    const cur=work.pop(),pc=cur.pc&0xFFFFFF,key=nodeKey(pc,cur.state,cur.stack);
    if(byKey.has(key))continue;
    activeStack=cur.stack.slice();
    const before=cloneDecodeState(cur.state),after=cloneDecodeState(cur.state); let i;
    try{i=decodeOne(rom,pc,after);}catch(e){issues.push({kind:'DECODE',pc,detail:e.message});continue;}
    i.stateIn=before;i.stateOut=cloneDecodeState(after);i.stateKey=key;i.stateSig=stateSig(before);i.flowTarget=(i.mnemonic==='BRK'||i.mnemonic==='COP')?interruptVector(rom,i,before):flowTarget(i);byKey.set(key,i);
    // Bounded byte-level status stack. Data pushes cannot be mistaken for PHP;
    // branch merges retain distinct saved statuses. Reset/relative stack writes invalidate it.
    const pushBytes=n=>{for(let k=0;k<n;k++)activeStack.push(null);if(activeStack.length>32)activeStack=activeStack.slice(-32);};
    const popBytes=n=>{for(let k=0;k<n;k++)activeStack.pop();};
    if(i.mnemonic==='PHP'){activeStack.push(cloneDecodeState(before));if(activeStack.length>32)activeStack=activeStack.slice(-32);}
    else if(i.mnemonic==='PLP'){
      const saved=activeStack.pop();if(saved){after.carry=saved.carry;if(!after.emulation){after.m8=saved.m8;after.x8=saved.x8;}}
      else if(!after.emulation){
        // A status loaded from memory is unknown: compile all legal widths instead of guessing.
        i.stateOut=cloneDecodeState(after);byKey.set(key,i);
        for(const m8 of [true,false])for(const x8 of [true,false])enqueueReturnSite(nextPc(i),[{...after,m8,x8}],pc,'PLP-unknown');
        continue;
      }
    }else if(i.mnemonic==='PHA')pushBytes(before.m8?1:2);
    else if(i.mnemonic==='PHX'||i.mnemonic==='PHY')pushBytes(before.x8?1:2);
    else if(['PHB','PHK'].includes(i.mnemonic))pushBytes(1);
    else if(['PHD','PEA','PEI','PER'].includes(i.mnemonic))pushBytes(2);
    else if(i.mnemonic==='PLA')popBytes(before.m8?1:2);
    else if(i.mnemonic==='PLX'||i.mnemonic==='PLY')popBytes(before.x8?1:2);
    else if(i.mnemonic==='PLB')popBytes(1);
    else if(i.mnemonic==='PLD')popBytes(2);
    else if(['TXS','TCS'].includes(i.mnemonic)||(/^(ST|INC|DEC|ASL|LSR|ROL|ROR|TSB|TRB)/.test(i.mnemonic)&&i.mode.startsWith('StackRelative')))activeStack=[];
    i.stateOut=cloneDecodeState(after);
    const n=nextPc(i);
    if(i.mnemonic==='PLP'){enqueueReturnSite(n,[after],pc,'PLP-resume');continue;}
    if(i.mnemonic==='XCE'&&before.carry===null){for(const carry of [false,true]){const state={...before,carry};decodeOne(rom,pc,state);enqueueReturnSite(n,[state],pc,'XCE-unknown');}continue;}
    if(isCondBranch(i.mnemonic)&&i.flowTarget!==null){
      edges.push({from:pc,to:i.flowTarget,type:'branch-taken',fromState:i.stateSig,toState:stateSig(after)});edges.push({from:pc,to:n,type:'fallthrough',fromState:i.stateSig,toState:stateSig(after)});
      enqueue(i.flowTarget,after,pc,i.mnemonic);enqueue(n,after,pc,'fallthrough');continue;
    }
    if(isUncondBranch(i.mnemonic)&&i.flowTarget!==null){edges.push({from:pc,to:i.flowTarget,type:'branch',fromState:i.stateSig,toState:stateSig(after)});enqueue(i.flowTarget,after,pc,i.mnemonic);continue;}
    if(isDirectCall(i)&&i.flowTarget!==null){
      if(isRomAddress(rom,i.flowTarget)){calls.push({from:pc,target:i.flowTarget,state:cloneDecodeState(after),stateSig:stateSig(after),kind:i.mnemonic});edges.push({from:pc,to:i.flowTarget,type:'call',fromState:i.stateSig,toState:stateSig(after)});}else issues.push({kind:'CFG-NONROM-TARGET',pc,detail:i.mnemonic+' -> $'+hex(i.flowTarget,6)+' nao aponta para ROM; possivel estado M/X/fluxo incorreto'});
      edges.push({from:pc,to:n,type:'return-site',fromState:i.stateSig,toState:stateSig(after)});enqueueReturnSite(n,isRomAddress(rom,i.flowTarget)?returnStates([i.flowTarget],after):[after],pc,'return-site');continue;
    }
    if(isDirectJump(i)&&i.flowTarget!==null){edges.push({from:pc,to:i.flowTarget,type:'jump',fromState:i.stateSig,toState:stateSig(after)});enqueue(i.flowTarget,after,pc,i.mnemonic);continue;}
    if((i.mnemonic==='BRK'||i.mnemonic==='COP')&&i.flowTarget!==null){
      if(isRomAddress(rom,i.flowTarget)){calls.push({from:pc,target:i.flowTarget,state:cloneDecodeState(after),stateSig:stateSig(after),kind:i.mnemonic});edges.push({from:pc,to:i.flowTarget,type:'interrupt',fromState:i.stateSig,toState:stateSig(after)});}
      edges.push({from:pc,to:n,type:'interrupt-return',fromState:i.stateSig,toState:stateSig(after)});enqueue(n,after,pc,'interrupt-return');continue;
    }
    if((i.mnemonic==='BRK'||i.mnemonic==='COP')&&i.flowTarget===null){issues.push({kind:'VECTOR',pc,detail:i.mnemonic+' sem vetor ROM resolvido'});continue;}
    if(i.mnemonic==='RTS'||i.mnemonic==='RTL'){exits.set(stateKeySig(before),cloneDecodeState(before));}
    if(isReturn(i)||i.mnemonic==='STP')continue;
    if(i.mnemonic==='WAI'){edges.push({from:pc,to:n,type:'wait-resume',fromState:i.stateSig,toState:stateSig(after)});enqueue(n,after,pc,'WAI-resume');continue;}
    if(i.mnemonic==='JMP'&&i.mode==='AbsoluteIndirectLong'){
      const inferred=discoverIndirectTargets(rom,i,after),hinted=hintedTargets(pc),ts=mergeTargets(inferred,hinted);i.indirectTargets=ts.slice();i.indirectHintTargets=hinted.slice();for(const t of ts){calls.push({from:pc,target:t,state:cloneDecodeState(after),stateSig:stateSig(after),kind:'JML-RAM-VECTOR'});edges.push({from:pc,to:t,type:'indirect-long-candidate',fromState:i.stateSig,toState:stateSig(after)});}
      issues.push({kind:ts.length?'CFG-RESOLVED-INDIRECT':'CFG-DYNAMIC',pc,detail:ts.length?('JMP [abs]: '+ts.length+' alvo(s) de vetor RAM descobertos'+(hinted.length?' com knowledge dispatch':' por dataflow simples')+'; dispatcher runtime preservado'):'JMP [abs] indireto recompilado para dispatcher C++; destino vem de ponteiro de 24 bits em RAM'});continue;
    }
    if(i.mnemonic==='JSR'&&i.mode==='AbsoluteIndexedIndirectX'){
      const inferred=discoverIndirectTargets(rom,i,after),hinted=hintedTargets(pc),ts=mergeTargets(inferred,hinted);i.indirectTargets=ts.slice();i.indirectHintTargets=hinted.slice();for(const t of ts){calls.push({from:pc,target:t,state:cloneDecodeState(after),stateSig:stateSig(after),kind:'JSR-TABLE'});edges.push({from:pc,to:t,type:'indirect-table-call',fromState:i.stateSig,toState:stateSig(after)});}
      issues.push({kind:ts.length?'CFG-RESOLVED-INDIRECT':'CFG-DYNAMIC',pc,detail:ts.length?('JSR (abs,X): '+ts.length+' alvo(s) de tabela ROM descobertos'+(hinted.length?' + knowledge dispatch':'')+'; dispatcher runtime preservado'):'JSR (abs,X) recompilado para dispatcher C++ dinamico; CFG preserva o return-site'});
      edges.push({from:pc,to:n,type:'dynamic-return-site',fromState:i.stateSig,toState:stateSig(after)});enqueueReturnSite(n,returnStates(ts,after),pc,'JSR-indirect-return');continue;
    }
    if(i.mnemonic==='JMP'&&(i.mode==='AbsoluteIndirect'||i.mode==='AbsoluteIndexedIndirectX')){
      const ramEvidence=i.mode==='AbsoluteIndirect'?discoverRamVectorEvidence(rom,i,after):null,inferred=ramEvidence?ramEvidence.targets:discoverIndirectTargets(rom,i,after),hinted=hintedTargets(pc),ts=mergeTargets(inferred,hinted);i.indirectTargets=ts.slice();i.indirectHintTargets=hinted.slice();if(ramEvidence)i.indirectResolution=ramEvidence.resolution;for(const t of ts){calls.push({from:pc,target:t,state:cloneDecodeState(after),stateSig:stateSig(after),kind:'JMP-TABLE'});edges.push({from:pc,to:t,type:'indirect-table-jump',fromState:i.stateSig,toState:stateSig(after)});}
      const inline=discoverPeaIndexedDispatch(rom,i,after);
      if(inline){calls.push({from:pc,target:inline.returnPc,state:cloneDecodeState(after),stateSig:stateSig(after),kind:'PEA-JUMP-RETURN'});enqueueReturnSite(inline.returnPc,returnStates(ts,after),pc,'PEA-jump-return');}
      const structural=i.mode==='AbsoluteIndexedIndirectX'?discoverInlineIndexedDispatch(rom,i,after):null;issues.push({kind:ts.length?'CFG-RESOLVED-INDIRECT':'CFG-DYNAMIC',pc,detail:ts.length?('JMP '+i.mode+': '+ts.length+' alvo(s) candidatos descobertos estaticamente'+(structural?' por tabela inline estrutural; limite dinamico do indice nao e assumido':'')+(hinted.length?' + knowledge dispatch':'')+'; dispatcher runtime preservado'):('JMP '+i.mode+' recompilado para dispatcher C++ dinamico')});continue;
    }
    if((i.mnemonic==='JMP'||i.mnemonic==='JML'||i.mnemonic==='JSR'||i.mnemonic==='JSL')&&i.flowTarget===null){issues.push({kind:'CFG-INDIRECT',pc,detail:i.mnemonic+' indireto ainda nao pode ter destino resolvido estaticamente'});continue;}
    edges.push({from:pc,to:n,type:'fallthrough',fromState:i.stateSig,toState:stateSig(after)});enqueue(n,after,pc,'fallthrough');
  }
  if(work.length)issues.push({kind:'CFG-LIMIT',pc:start,detail:'limite de variantes/instrucoes desta rotina atingido; aumente a analise para continuar'});
  for(const k of returnSiteKeys){const ri=byKey.get(k);if(ri)ri.returnSite=true;}
  const instructions=[...byKey.values()].sort((a,b)=>a.pc-b.pc||a.stateSig.localeCompare(b.stateSig));
  const pcCounts=new Map();for(const i of instructions)pcCounts.set(i.pc,(pcCounts.get(i.pc)||0)+1);
  const stateVariantAddresses=[...pcCounts].filter(([,n])=>n>1).map(([pc,n])=>({pc,count:n}));
  const blockStarts=new Set([start]);for(const e of edges){blockStarts.add(e.to);if(e.type!=='fallthrough')blockStarts.add(e.from);}
  return {start,exits,entryState:cloneDecodeState(initialState),entryStateSig:stateSig(initialState),instructions,calls,edges,issues,stateVariantAddresses,blockCount:[...blockStarts].filter(x=>instructions.some(i=>i.pc===x)).length};
}
function runtimeHintKey(h){const st=normEntryState(h&&h.state||{});return [normalizeRomHash(h&&h.rom||''),(h&&h.target||0)&0xFFFFFF,h&&h.from!==null&&h&&h.from!==undefined?((h.from>>>0)&0xFFFFFF):'?',String(h&&h.kind||'RUNTIME').toUpperCase(),st.emulation?1:0,st.m8?1:0,st.x8?1:0,st.carry===null?'?':st.carry?1:0].join('|');}
function parseRuntimeHints(text){
  const byKey=new Map(),num=v=>{const z=String(v||'').trim();if(!z)return NaN;if(/^0x/i.test(z))return parseInt(z,16);if(/^\$/.test(z))return parseInt(z.slice(1),16);return parseInt(z,16);};
  for(const raw of String(text||'').split(/\r?\n/)){
    const line=raw.trim();if(!line||line.startsWith('#')||line.startsWith(';'))continue;const q={};
    for(const part of line.split(/\s+/)){const mm=part.match(/^([^=]+)=(.+)$/);if(mm)q[mm[1].toLowerCase()]=mm[2];}
    if(!q.target)continue;const target=num(q.target);if(!Number.isFinite(target))continue;const from=q.from?num(q.from):null;
    const h={rom:normalizeRomHash(q.rom||q.romhash||q.cart||''),target:target&0xFFFFFF,from:Number.isFinite(from)?from&0xFFFFFF:null,kind:q.kind||'RUNTIME',state:{emulation:q.e==='1',m8:q.m==='1',x8:q.x==='1',carry:q.c==='1'?true:q.c==='0'?false:null},observed:Math.max(1,parseInt(q.observed||q.count||'1',10)||1)};
    const k=runtimeHintKey(h),prev=byKey.get(k);if(prev)prev.observed+=h.observed;else byKey.set(k,h);
  }
  return [...byKey.values()].sort((a,b)=>(b.observed||1)-(a.observed||1)||a.target-b.target||((a.from??0)-(b.from??0)));
}
function formatRuntimeHints(hints){return (Array.isArray(hints)?hints:parseRuntimeHints(hints)).map(h=>{const st=normEntryState(h.state||{}),rh=normalizeRomHash(h.rom||'');return (rh?'rom='+rh+' ':'')+'target='+hex(h.target,6)+' '+(h.from===null||h.from===undefined?'':'from='+hex(h.from,6)+' ')+'kind='+(h.kind||'RUNTIME')+' e='+(st.emulation?1:0)+' m='+(st.m8?1:0)+' x='+(st.x8?1:0)+' c='+(st.carry===null?'?':st.carry?1:0)+' observed='+(h.observed||1);}).join('\n');}
function mergeRuntimeHints(...texts){return formatRuntimeHints(parseRuntimeHints(texts.filter(Boolean).join('\n')));}
function effectiveFunctionExits(fn,previousSummaries){
  const out=new Map(),trampolineReturns=new Set((fn.stackReturnTargets||[]).map(c=>c.from&0xFFFFFF));
  // RTS/RTL usados por PEI/PER/PHA como computed-goto nao encerram a chamada que trouxe o CPU ate esta rotina.
  // So retornos reais entram diretamente no resumo.
  for(const i of (fn.instructions||[])){
    if(i.mnemonic!=='RTS'&&i.mnemonic!=='RTL')continue;
    if(trampolineReturns.has(i.pc&0xFFFFFF))continue;
    const st=cloneDecodeState(i.stateIn||i.stateOut||fn.entryState);out.set(stateKeySig(st),st);
  }
  // Um trampoline preserva o frame de JSR/JSL original. Portanto o estado observado pelo caller vem
  // das saidas do(s) destino(s) computados, e nao do primeiro RTS usado como salto. O ponto fixo
  // propaga isso por cadeias com varios trampolins. Enquanto o destino ainda nao tem resumo, mantemos
  // o estado do salto como fallback conservador para nunca perder uma variante valida.
  for(const c of (fn.stackReturnTargets||[])){
    const ex=previousSummaries&&previousSummaries.get(fnStateKey(c.target,c.state));
    if(ex&&ex.size){for(const e of ex.values()){const st=cloneDecodeState(e);out.set(stateKeySig(st),st);}}
    else{const st=cloneDecodeState(c.state);out.set(stateKeySig(st),st);}
  }
  // Rotinas normais sem trampoline continuam usando o resumo bruto calculado pelo CFG.
  if(!out.size&&(!fn.stackReturnTargets||!fn.stackReturnTargets.length)&&fn.exits){for(const e of fn.exits.values()){const st=cloneDecodeState(e);out.set(stateKeySig(st),st);}}
  return out;
}
function analyze(rom,max=65536,hints=[],opts={}){
  if(typeof hints==='string')hints=parseRuntimeHints(hints);
  const romHash=romFingerprint(rom),allHints=Array.isArray(hints)?hints:[],rejected=allHints.filter(h=>h.rom&&normalizeRomHash(h.rom)!==romHash).length;
  hints=allHints.filter(h=>!h.rom||normalizeRomHash(h.rom)===romHash);
  const knowledge=opts.knowledge?Framework.normalizeKnowledgePack(opts.knowledge,romHash):null;
  const knowledgeSeedLimit=opts.knowledgeSeedLimit===undefined?1024:Math.max(0,Math.min(8192,Number(opts.knowledgeSeedLimit)||0));
  // Ponto fixo interprocedural: o estado M/X/E depois de um JSR/JSL e o estado de saida efetiva do callee.
  // Trampolins PEI/RTS sao tratados como computed-goto e seguem os resumos de seus destinos.
  let summaries=new Map(),a=null;const rounds=opts.summaryRounds===undefined?8:opts.summaryRounds;
  for(let r=0;r<=rounds;r++){a=analyzeOnce(rom,max,hints,summaries,knowledge,knowledgeSeedLimit);const next=new Map();for(const f of a.functions){const ex=effectiveFunctionExits(f,summaries);if(ex.size)next.set(f.functionKey,ex);}
    const same=next.size===summaries.size&&[...next].every(([k,v])=>{const o=summaries.get(k);return o&&o.size===v.size&&[...v.keys()].every(x=>o.has(x));});
    a.summaryRounds=r;if(same)break;summaries=next;}
  a.romFingerprint=romHash;a.runtimeHintsRejected=rejected;a.runtimeHints=hints.map(h=>({...h,rom:romHash}));a.knowledgePack=knowledge?{schema:knowledge.schema,producer:knowledge.producer,entries:knowledge.entries.length,dataRegions:knowledge.dataRegions.length,dispatch:knowledge.dispatch.length,seedsImported:a.knowledgeSeedsImported||0}:null;
  return a;
}
function directJumpTarget(i){
  if(i.mnemonic==='JMP'&&i.mode==='Absolute')return ((i.pc&0xFF0000)|(i.operand&0xFFFF))>>>0;
  if(i.mnemonic==='JML'&&i.mode==='AbsoluteLong')return i.operand&0xFFFFFF;
  return null;
}
function focusAnalyze(rom,addresses,knowledge,opts={}){
  const hash=romFingerprint(rom),pack=Framework.normalizeKnowledgePack(knowledge,hash),maxPerTarget=Math.max(64,Math.min(8192,Number(opts.maxPerTarget||2048))),targets=[...new Set((addresses||[]).map(a=>(typeof a==='string'?parseInt(String(a).replace(/^(0x|\$)/i,''),16):Number(a))&0xFFFFFF))];
  const tinySources=[];
  for(const e of pack.entries){
    if(e.category==='UNKNOWN')continue;
    const span=e.span||{start:e.address,end:e.address+1,name:e.name};
    if(span.end<=span.start||span.end-span.start>64)continue;
    let pc=span.start,state={...e.state},guard=0;
    const jumps=[];
    while(pc<span.end&&guard++<64){let i;try{i=decodeOne(rom,pc,state);}catch(_){break;}const t=directJumpTarget(i);if(t!==null)jumps.push({site:pc,target:t,kind:i.mnemonic});pc=(pc+i.size)&0xFFFFFF;if(pc<=span.start)break;}
    if(jumps.length)tinySources.push({entry:e,span,jumps});
  }
  const dispatchHints=new Map(),dispatchResolution=new Map();for(const d of pack.dispatch||[]){const site=d.site&0xFFFFFF,prev=dispatchHints.get(site)||[];dispatchHints.set(site,[...new Set([...prev,...(d.targets||[])])]);if(d.resolution)dispatchResolution.set(site,JSON.parse(JSON.stringify(d.resolution)));}
  const results=[];
  for(const address of targets){
    const exact=pack.entries.filter(e=>e.address===address).sort((a,b)=>b.priority-a.priority)[0]||null;
    const containing=pack.entries.filter(e=>e.span&&e.span.start<=address&&address<e.span.end).sort((a,b)=>(a.span.end-a.span.start)-(b.span.end-b.span.start)||b.priority-a.priority);
    const family=(exact&&exact.span&&exact.span.start!==address)?exact.span:(containing[0]&&containing[0].span&&containing[0].span.start!==address?containing[0].span:null);
    const sources=[];
    for(const src of tinySources)for(const j of src.jumps)if(j.target===address)sources.push({address:src.entry.address,name:src.entry.name,category:src.entry.category,priority:src.entry.priority,site:j.site,kind:j.kind,span:src.span});
    sources.sort((a,b)=>b.priority-a.priority||a.address-b.address);
    let category=exact?exact.category:'UNKNOWN',categorySource=exact&&exact.category!=='UNKNOWN'?'knowledge-exact':'unknown';
    if(category==='UNKNOWN'&&sources.length){category=sources[0].category;categorySource='direct-jump-family';}
    const state=exact?{...exact.state}:{emulation:false,m8:false,x8:false,carry:null};
    let fn;try{fn=decodeCfgFunction(rom,address,maxPerTarget,state,null,dispatchHints);}catch(e){fn={instructions:[],calls:[],issues:[{kind:'FOCUS-DECODE',pc:address,detail:e.message}],stateVariantAddresses:[],blockCount:0};}
    const indirectSites=(fn.instructions||[]).filter(x=>Array.isArray(x.indirectTargets)&&x.indirectTargets.length).map(x=>{
      const structural=x.mode==='AbsoluteIndexedIndirectX'?discoverInlineIndexedDispatch(rom,x,x.stateOut||x.stateIn):null;let resolution=x.indirectResolution?JSON.parse(JSON.stringify(x.indirectResolution)):(structural?{kind:'inline-structural-table',table_start:structural.tableStart,table_end:structural.tableEnd,entries:(structural.tableEnd-structural.tableStart)/2,unique_targets:structural.targets.length,index_bounds_proven:false}:{kind:x.mode==='AbsoluteIndirect'?'ram-vector-candidates':'static-candidates',index_bounds_proven:false});
      if(structural){const exactRegion=pack.dataRegions.find(r=>r.start===structural.tableStart&&r.end===structural.tableEnd);resolution.table_extent_proven=!!exactRegion;if(exactRegion)resolution.table_extent_source=exactRegion.source;const jo=snesToRom(rom,x.pc),d=rom.data;if(jo!==null&&jo>=5&&d[jo-1]===0xAA){let p=jo-2,shifts=0;while(p>=0&&d[p]===0x0A&&shifts<8){shifts++;p--;}if(shifts&&p>=2&&d[p-2]===0x29){const mask=d[p-1]|(d[p]<<8),maxEntry=mask,resEntries=(structural.tableEnd-structural.tableStart)/2;resolution.index_domain={source:'local-AND-ASL-TAX',mask,scale_bytes:1<<shifts,theoretical_entry_min:0,theoretical_entry_max:maxEntry};resolution.index_bounds_proven=maxEntry<resEntries;resolution.index_domain_fits_table=maxEntry<resEntries;}}}
      const external=dispatchResolution.get(x.pc&0xFFFFFF);if(external&&external.script_domain){const sd=JSON.parse(JSON.stringify(external.script_domain));resolution.script_domain=sd;const ids=(sd.observed_ids_in_closed_entries||[]).map(Number).filter(Number.isInteger),entries=Number(resolution.entries||sd.table_entries||0),maxId=ids.length?Math.max(...ids):-1;resolution.script_domain_observed_ids=[...new Set(ids)].sort((a,b)=>a-b);resolution.script_domain_complete=sd.complete===true;resolution.script_domain_closed_entries=Number(sd.closed_entries||0);resolution.script_domain_invalid_entries=Number(sd.invalid_entries||0);if(sd.complete===true&&sd.index_bounds_proven===true&&entries>0&&maxId>=0&&maxId<entries){if(resolution.index_domain&&resolution.index_domain.source!=='external-bytecode-script-domain-proof')resolution.local_index_domain=JSON.parse(JSON.stringify(resolution.index_domain));resolution.index_bounds_proven=true;resolution.index_domain_fits_table=true;resolution.index_domain={source:'external-bytecode-script-domain-proof',observed_ids:resolution.script_domain_observed_ids,theoretical_entry_min:Math.min(...ids),theoretical_entry_max:maxId};}}
      return {pc:x.pc,mnemonic:x.mnemonic,mode:x.mode,targets:[...new Set(x.indirectTargets)].sort((a,b)=>a-b),knowledge_targets:[...new Set(x.indirectHintTargets||[])].sort((a,b)=>a-b),resolution};});
    for(const site of indirectSites){
      if(site.resolution&&site.resolution.script_domain_complete===true&&site.resolution.index_bounds_proven===true&&site.resolution.index_domain_fits_table===true){
        fn.issues=fn.issues.filter(i=>!((i.kind==='CFG-INDEX-DOMAIN-UNPROVEN'||i.kind==='CFG-SCRIPT-DOMAIN-PARTIAL')&&i.pc===site.pc));
        const resolved=fn.issues.find(i=>i.kind==='CFG-RESOLVED-INDIRECT'&&i.pc===site.pc);
        if(resolved)resolved.detail='JMP '+site.mode+': '+site.targets.length+' alvo(s) estruturais; dominio do indice provado por auditoria externa de bytecode ROM-bound + knowledge dispatch; dispatcher runtime preservado';
      }
      if(site.resolution&&site.resolution.table_extent_proven&&site.resolution.index_domain&&site.resolution.index_domain_fits_table===false&&!fn.issues.some(i=>i.kind==='CFG-INDEX-DOMAIN-UNPROVEN'&&i.pc===site.pc))fn.issues.push({kind:'CFG-INDEX-DOMAIN-UNPROVEN',pc:site.pc,detail:'Tabela indireta estrutural tem extensao conhecida, mas o dominio teorico local do indice excede a tabela; runtime/dataflow adicional e necessario antes de fechar o dispatcher.'});
      if(site.resolution&&site.resolution.script_domain&&site.resolution.script_domain.complete!==true&&!fn.issues.some(i=>i.kind==='CFG-SCRIPT-DOMAIN-PARTIAL'&&i.pc===site.pc))fn.issues.push({kind:'CFG-SCRIPT-DOMAIN-PARTIAL',pc:site.pc,detail:'Auditoria externa de bytecode cobre '+Number(site.resolution.script_domain.closed_entries||0)+' entradas, mas preserva '+Number(site.resolution.script_domain.invalid_entries||0)+' entradas invalidas/nao resolvidas; dominio runtime nao promovido.'});
    }
    results.push({address,name:exact?exact.name:'fn_'+hex(address,6),category,category_source:categorySource,family:family?{start:family.start,end:family.end,name:family.name}:null,direct_jump_sources:sources.map(x=>({address:x.address,name:x.name,category:x.category,site:x.site,kind:x.kind})),entry_state:state,instructions:fn.instructions.length,calls:fn.calls.length,blocks:fn.blockCount||0,issues:fn.issues||[],indirect_sites:indirectSites,state_variant_addresses:(fn.stateVariantAddresses||[]).map(x=>({pc:x.pc,count:x.count}))});
  }
  return {schema:'forja65.focus-analysis.v1',version:VERSION,rom:hash,knowledge:{entries:pack.entries.length,dataRegions:pack.dataRegions.length,dispatch:pack.dispatch.length},results,limits:['Focused CFG is static evidence only; it does not prove runtime execution.','Category inheritance is limited to direct JMP/JML targets from already-classified tiny spans (<=64 bytes).','Inline ASL/TAX/JMP tables expose structural target candidates; local mask/scale bounds and exact knowledge data-region extents are reported separately from runtime-domain proof.','RAM-vector writer-domain closure covers direct absolute STA patterns in the mapped bank; aliased/indirect WRAM writes require runtime or stronger dataflow evidence.','External bytecode script-domain evidence is accepted only as ROM-bound proof metadata; partial audits never close an index domain.']};
}

function handlerProofMap(rom,site,proofPack){
  const out=new Map();if(!proofPack)return out;
  if(proofPack.schema!=='forja65.handler-equivalence.v1')throw new Error('Invalid handler equivalence proof schema');
  const hash=romFingerprint(rom),proofHash=normalizeRomHash(typeof proofPack.rom==='object'?(proofPack.rom.fnv1a64||proofPack.rom.hash):proofPack.rom);
  if(proofHash!==hash)throw new Error('Handler equivalence proof ROM mismatch');
  if(proofPack.dispatcher_site!==undefined&&((Number(proofPack.dispatcher_site)&0xFFFFFF)!==(site&0xFFFFFF)))throw new Error('Handler equivalence proof dispatcher mismatch');
  for(const raw of proofPack.proofs||[]){
    const target=(Number(raw.target)||0)&0xFFFFFF;if(!target)continue;
    const status=String(raw.status||'').toLowerCase(),scope=String(raw.scope||'');
    if(!['equivalent','dependency-boundary','unproven'].includes(status))throw new Error('Unknown handler proof status for $'+hex(target,6));
    const verification=raw.verification||{},verified=String(verification.result||'').toUpperCase()==='PASS';
    let spanVerified=false,spanFingerprint=null;
    if(raw.span&&Number.isInteger(Number(raw.span.start))&&Number.isInteger(Number(raw.span.end))&&Number(raw.span.end)>Number(raw.span.start)){
      const start=Number(raw.span.start)&0xFFFFFF,end=Number(raw.span.end)&0xFFFFFF;
      const bytes=[];let ok=true;for(let a=start;a<end;a++){const o=snesToRom(rom,a&0xFFFFFF);if(o===null||o>=rom.data.length){ok=false;break;}bytes.push(rom.data[o]);}
      if(ok){spanFingerprint=fnv1a64Bytes(bytes);spanVerified=!raw.span_fingerprint||normalizeRomHash(raw.span_fingerprint)===spanFingerprint;}
      if(raw.span_fingerprint&&!spanVerified)throw new Error('Handler proof span fingerprint mismatch for $'+hex(target,6));
    }
    if(status==='equivalent'&&(!verified||scope!=='handler-abi'||!spanVerified))throw new Error('Equivalent handler proof lacks PASS handler-abi ROM-bound span verification for $'+hex(target,6));
    out.set(target,{...raw,target,status,scope,verified,span_verified:spanVerified,span_fingerprint_actual:spanFingerprint});
  }
  return out;
}

function nativeDispatchPlan(rom,siteAddress,knowledge,opts={}){
  const site=(typeof siteAddress==='string'?parseInt(String(siteAddress).replace(/^(0x|\$)/i,''),16):Number(siteAddress))&0xFFFFFF;
  const focus=focusAnalyze(rom,[site],knowledge,{maxPerTarget:Number(opts.maxPerTarget||2048)}),root=focus.results[0];
  if(!root)throw new Error('Native dispatch site not analyzed');
  const dispatch=(root.indirect_sites||[]).find(x=>x.pc===site);
  if(!dispatch)throw new Error('No resolved indirect dispatch at $'+hex(site,6));
  const r=dispatch.resolution||{};
  if(r.kind!=='inline-structural-table'||!Number.isInteger(r.table_start)||!Number.isInteger(r.entries)||r.entries<=0)throw new Error('Dispatch is not an inline structural table');
  if(r.table_extent_proven!==true)throw new Error('Dispatch table extent is not proven');
  if(r.index_bounds_proven!==true||r.index_domain_fits_table!==true)throw new Error('Dispatch index domain is not proven');
  const tableStart=r.table_start&0xFFFFFF,bank=tableStart&0xFF0000,entries=[];
  for(let i=0;i<r.entries;i++){const a=(tableStart+i*2)&0xFFFFFF,o=snesToRom(rom,a);if(o===null||o+1>=rom.data.length)throw new Error('Dispatch table leaves ROM at entry '+i);const lo=rom.data[o],hi=rom.data[o+1],target=bank|(lo|(hi<<8));if(!isRomAddress(rom,target))throw new Error('Dispatch target is not ROM: $'+hex(target,6));entries.push({index:i,target});}
  const observed=new Set((((r.index_domain||{}).observed_ids)||((r.script_domain||{}).observed_ids_in_closed_entries)||[]).map(Number).filter(Number.isInteger));
  for(const e of entries)e.observed=observed.size?observed.has(e.index):true;
  const targets=[...new Set(entries.map(e=>e.target))],handlerFocus=focusAnalyze(rom,targets,knowledge,{maxPerTarget:Number(opts.handlerMax||2048)});
  const proofs=handlerProofMap(rom,site,opts.handlerProofs||null);
  const handlers=handlerFocus.results.map(h=>{const dynamic=(h.issues||[]).filter(i=>i.kind==='CFG-DYNAMIC'||i.kind==='FOCUS-DECODE'),proof=proofs.get(h.address)||null,eq=!!(proof&&proof.status==='equivalent'&&proof.verified&&proof.scope==='handler-abi'&&proof.span_verified),boundary=!!(proof&&proof.status==='dependency-boundary'&&proof.verified&&proof.span_verified);return {target:h.address,name:h.name,category:h.category,instructions:h.instructions,calls:h.calls,blocks:h.blocks,issues:h.issues||[],translation_candidate:dynamic.length===0,native_body_ready:eq||boundary,equivalence_proven:eq,proof:proof?{status:proof.status,scope:proof.scope,native_symbol:proof.native_symbol||null,verification:proof.verification||null,dependencies:proof.dependencies||[],span:proof.span||null,span_fingerprint:proof.span_fingerprint||null}:null};});
  const targetIndex=new Map();handlers.forEach((h,i)=>targetIndex.set(h.target,i));for(const e of entries)e.handler_index=targetIndex.get(e.target);
  const duplicateGroups=[];const byTarget=new Map();for(const e of entries){const a=byTarget.get(e.target)||[];a.push(e.index);byTarget.set(e.target,a);}for(const [target,indices] of byTarget)if(indices.length>1)duplicateGroups.push({target,indices});
  const provenHandlers=handlers.filter(h=>h.equivalence_proven).length,boundaryHandlers=handlers.filter(h=>h.proof&&h.proof.status==='dependency-boundary').length;
  return {schema:'forja65.native-dispatch-plan.v1',version:VERSION,rom:romFingerprint(rom),site,table_start:tableStart,table_entries:r.entries,unique_targets:targets.length,index_bounds_proven:true,index_domain:r.index_domain||null,script_domain:r.script_domain||null,entries,handlers,duplicate_groups:duplicateGroups,cutover:{route_generation_ready:true,partial_handler_execution_ready:provenHandlers>0,handler_execution_ready:provenHandlers===handlers.length,semantic_handlers_proven:provenHandlers,dependency_boundary_handlers:boundaryHandlers,reason:provenHandlers===handlers.length?'All unique handlers carry ROM-bound handler-ABI equivalence proofs.':(provenHandlers?'Selective handler cutover is permitted only for equivalence-proven targets; remaining handlers stay on fallback.':'Routing is proven by ROM table/domain evidence; handler semantic equivalence remains independent and must be validated before replacing 65C816 execution.')},limits:['Generated routing is ROM-bound structural evidence; per-handler cutover additionally requires an imported PASS handler-ABI equivalence proof bound to the same ROM/span.','translation_candidate only means focused CFG had no unresolved dynamic/decode issue; it is not permission to remove fallback.','dependency-boundary records a reviewed native prefix/external-call boundary and never sets equivalence_proven by itself.']};
}
function nativeDispatchCpp(plan,opts={}){
  if(!plan||plan.schema!=='forja65.native-dispatch-plan.v1')throw new Error('Invalid native dispatch plan');
  const ns=String(opts.namespace||'forja65_generated').replace(/[^A-Za-z0-9_]/g,'_')||'forja65_generated';
  const rows=plan.entries.map(e=>`  NativeDispatchEntry{${e.index}u,0x${hex(e.target,6)}u,${e.observed?'true':'false'},${e.handler_index}u}`).join(',\n');
  const handlers=plan.handlers.map(h=>`  NativeHandlerStatus{0x${hex(h.target,6)}u,${h.translation_candidate?'true':'false'},${h.native_body_ready?'true':'false'},${h.equivalence_proven?'true':'false'},${Number(h.instructions||0)}u,${Number(h.calls||0)}u}`).join(',\n');
  return `#pragma once\n#include <array>\n#include <cstddef>\n#include <cstdint>\nnamespace ${ns} {\nstruct NativeDispatchEntry { std::uint8_t index; std::uint32_t target; bool observed; std::uint8_t handler_index; };\nstruct NativeHandlerStatus { std::uint32_t target; bool translation_candidate; bool native_body_ready; bool equivalence_proven; std::uint16_t instructions; std::uint16_t calls; };\ninline constexpr std::uint32_t kDispatchSite=0x${hex(plan.site,6)}u;\ninline constexpr std::uint32_t kDispatchTable=0x${hex(plan.table_start,6)}u;\ninline constexpr std::array<NativeDispatchEntry,${plan.entries.length}> kDispatchEntries{{\n${rows}\n}};\ninline constexpr std::array<NativeHandlerStatus,${plan.handlers.length}> kDispatchHandlers{{\n${handlers}\n}};\ninline constexpr std::uint32_t resolveDispatchTarget(std::uint8_t index){return index<kDispatchEntries.size()?kDispatchEntries[index].target:0u;}\ninline constexpr bool dispatchIndexObserved(std::uint8_t index){return index<kDispatchEntries.size()&&kDispatchEntries[index].observed;}\ninline constexpr const NativeHandlerStatus* dispatchHandler(std::uint8_t index){return index<kDispatchEntries.size()&&kDispatchEntries[index].handler_index<kDispatchHandlers.size()?&kDispatchHandlers[kDispatchEntries[index].handler_index]:nullptr;}\n}\n`;
}

function runtimeReturnTableHintInfo(rom,h){
  const kind=String(h&&h.kind||'').toUpperCase();
  if(!kind.includes('STACK-RTL'))return null;
  const target=(h.target>>>0)&0xFFFFFF,raw=((target&0xFFFF)-1)&0xFFFF,bank=(target>>>16)&0xFF,d=rom.data,st=normEntryState(h.state||{}),matches=[];
  for(let at=0;at+2<d.length;at++)if(d[at]===(raw&0xFF)&&d[at+1]===((raw>>>8)&0xFF)&&d[at+2]===bank)matches.push(at);
  if(!matches.length)return null;
  const recTarget=at=>{if(at<0||at+2>=d.length)return null;const r=d[at]|(d[at+1]<<8),b=d[at+2],t=((b&0xFF)<<16)|((r+1)&0xFFFF);return isRomAddress(rom,t)&&plausibleIndirectTarget(rom,t,st)?t:null;};
  let best=null;
  for(const anchor of matches){
    for(const stride of [4,3]){
      const valid=at=>{const t=recTarget(at);if(t===null)return false;if(stride===4&&(at+3>=d.length||d[at+3]>3))return false;return true;};
      if(!valid(anchor))continue;
      let lo=anchor,hi=anchor;while(valid(lo-stride))lo-=stride;while(valid(hi+stride))hi+=stride;
      const count=((hi-lo)/stride|0)+1;if(count<4)continue;
      const score=count+(stride===4?8:0);if(!best||score>best.score)best={lo,hi,stride,count,score,anchor};
    }
  }
  if(!best)return null;
  const all=[];for(let at=best.lo;at<=best.hi;at+=best.stride){const t=recTarget(at);if(t!==null&&!all.includes(t))all.push(t);}
  const anchorIndex=Math.max(0,Math.min(all.length-1,all.indexOf(target)>=0?all.indexOf(target):Math.floor((best.anchor-best.lo)/best.stride)));
  return {key:best.lo+':'+best.hi+':'+best.stride,lo:best.lo,hi:best.hi,stride:best.stride,count:best.count,target,anchorIndex,all};
}
function expandRuntimeReturnTableHint(rom,h,maxTargets=12){
  const info=runtimeReturnTableHintInfo(rom,h);if(!info)return [];
  const ordered=[];
  for(let radius=0;radius<info.all.length&&ordered.length<maxTargets;radius++)for(const idx of radius===0?[info.anchorIndex]:[info.anchorIndex-radius,info.anchorIndex+radius])if(idx>=0&&idx<info.all.length&&!ordered.includes(info.all[idx]))ordered.push(info.all[idx]);
  return ordered.slice(0,maxTargets);
}
function expandRuntimeFlowTableHint(rom,h,maxTargets=24){
  if(!h||h.from===null||h.from===undefined||!String(h.kind||'').toUpperCase().includes('FLOW'))return [];
  const st=normEntryState(h.state||{});let ins;try{ins=decodeOne(rom,h.from&0xFFFFFF,cloneDecodeState(st));}catch(_){return [];}
  if(ins.mode!=='AbsoluteIndexedIndirectX'||(ins.mnemonic!=='JMP'&&ins.mnemonic!=='JSR'))return [];
  const bank=ins.pc&0xFF0000,base=ins.operand&0xFFFF,target=h.target&0xFFFFFF,d=rom.data,matches=[];
  const entryAt=x=>{if(x<0||x>0x7FE)return null;const po=snesToRom(rom,bank|((base+x)&0xFFFF));if(po===null||po+1>=d.length)return null;const t=bank|(d[po]|(d[po+1]<<8));return plausibleIndirectTarget(rom,t,st)?t:null;};
  for(let x=0;x<=0x7FE;x+=2){const po=snesToRom(rom,bank|((base+x)&0xFFFF));if(po===null||po+1>=d.length)continue;const t=bank|(d[po]|(d[po+1]<<8));if(t===target)matches.push(x);}
  if(!matches.length)return [];
  // Oracle conservador: um alvo observado prova a posicao na tabela. A partir dele so aceitamos
  // entradas CONTIGUAS plausiveis; o primeiro ponteiro invalido encerra aquela direcao. Isso evita
  // atravessar o fim da tabela e reinterpretar dados arbitrarios como codigo.
  const scored=new Map();for(const anchor of matches){for(const dir of [-2,2])for(let step=1;step<=maxTargets;step++){const x=anchor+dir*step,t=entryAt(x);if(t===null)break;if(t!==target)scored.set(t,Math.max(scored.get(t)||0,100-step));if(scored.size>=maxTargets)break;}if(scored.size>=maxTargets)break;}
  return [...scored].sort((a,b)=>b[1]-a[1]).map(([t])=>t).slice(0,maxTargets);
}
function analyzeOnce(rom,max,hints,summaries,knowledge=null,knowledgeSeedLimit=1024){
  const reset=resetAddress(rom),entries=systemEntryPoints(rom),queue=entries.map(e=>({start:e.target,state:e.state,entryName:e.name})),functions=[],seenFn=new Set(),cfgIssues=[],syntheticReturnTargets=new Set();let remaining=max,returnAdjacentSeeds=0,knowledgeSeedsImported=0,knowledgeDataSeedsRejected=0,knowledgeAdjacentDataStops=0;const maxReturnAdjacentSeeds=64;
  const knowledgeRegions=knowledge&&Array.isArray(knowledge.dataRegions)?knowledge.dataRegions:[];const knownDataAddress=a=>knowledgeRegions.some(r=>a>=r.start&&a<=r.end);
  const dispatchHints=new Map();if(knowledge&&Array.isArray(knowledge.dispatch))for(const d of knowledge.dispatch){const site=d.site&0xFFFFFF,prev=dispatchHints.get(site)||[];dispatchHints.set(site,[...new Set([...prev,...(d.targets||[])])]);}
  if(knowledge&&knowledge.entries){for(const e of knowledge.entries.slice(0,knowledgeSeedLimit)){if(knownDataAddress(e.address)){knowledgeDataSeedsRejected++;continue;}if(!isExecutableEntryTarget(rom,e.address))continue;queue.push({start:e.address,state:normEntryState(e.state||{}),entryName:'KNOWLEDGE:'+String(e.name||'external')});knowledgeSeedsImported++;}if(knowledge.entries.length>knowledgeSeedLimit)cfgIssues.push({kind:'KNOWLEDGE-LIMIT',pc:null,detail:'knowledge pack tem '+knowledge.entries.length+' entradas; '+knowledgeSeedLimit+' sementes prioritarias foram consideradas nesta analise'});if(knowledgeSeedsImported)cfgIssues.push({kind:'KNOWLEDGE-SEED',pc:null,detail:knowledgeSeedsImported+' entradas externas revisadas adicionadas como sementes CFG; continuam sujeitas a validacao de estado/execucao'});if(knowledgeDataSeedsRejected)cfgIssues.push({kind:'KNOWLEDGE-DATA-GUARD',pc:null,detail:knowledgeDataSeedsRejected+' semente(s) externa(s) rejeitada(s) por cair em regiao de dados conhecida'});}
  if(!queue.some(q=>q.start===reset)){if(isExecutableEntryTarget(rom,reset))queue.unshift({start:reset,state:{emulation:true,m8:true,x8:true,carry:null},entryName:'RESET'});else cfgIssues.push({kind:'VECTOR',pc:0x00FFFC,detail:'RESET aponta para $'+hex(reset,6)+' dentro/fora da area executavel; entrada nao decodificada'});}
  const runtimeHintSeen=new Set(),runtimeTableSeen=new Map();
  for(const h of (Array.isArray(hints)?hints:[])){
    if(!isExecutableEntryTarget(rom,h.target)){cfgIssues.push({kind:'RUNTIME-HINT-INVALID',pc:h.from,detail:'hint runtime $'+hex(h.target,6)+' ignorado porque nao pertence a ROM'});continue;}
    const hs=normEntryState(h.state),hk=fnStateKey(h.target,hs);
    if(!runtimeHintSeen.has(hk)){runtimeHintSeen.add(hk);queue.unshift({start:h.target,state:hs,entryName:'RUNTIME-HINT'});cfgIssues.push({kind:'RUNTIME-HINT',pc:h.from,detail:'alvo runtime $'+hex(h.target,6)+' importado em '+stateSig(h.state)+' ('+h.kind+')'});}
    // Carry is a runtime value, not an opcode width. Compile an unknown-C sibling
    // of an observed state to avoid learning the same E/M/X twice. XCE explicitly forks it.
    if(hs.carry!==null){const generic={...hs,carry:null},gk=fnStateKey(h.target,generic);if(!runtimeHintSeen.has(gk)){runtimeHintSeen.add(gk);queue.unshift({start:h.target,state:generic,entryName:'RUNTIME-HINT-CARRY-GENERIC'});}}
    if(String(h.kind).toUpperCase().includes('RTS')||String(h.kind).toUpperCase().includes('RTL')||String(h.kind).toUpperCase().includes('RETURN'))syntheticReturnTargets.add(h.target);
    const info=runtimeReturnTableHintInfo(rom,h);
    if(info){
      let rec=runtimeTableSeen.get(info.key);if(!rec){rec={targets:new Set(),hints:0};runtimeTableSeen.set(info.key,rec);}rec.hints++;
      const peerBudget=rec.hints===1?12:4,peers=expandRuntimeReturnTableHint(rom,h,peerBudget);let added=0;
      for(const t of peers){if(t===h.target||rec.targets.has(t))continue;const tk=fnStateKey(t,hs);if(runtimeHintSeen.has(tk))continue;rec.targets.add(t);runtimeHintSeen.add(tk);queue.push({start:t,state:cloneDecodeState(hs),entryName:'RUNTIME-HINT-TABLE'});syntheticReturnTargets.add(t);added++;}
      cfgIssues.push({kind:'RUNTIME-HINT-TABLE',pc:h.from,detail:'STACK-RTL reconheceu tabela ROM ('+info.count+' registros); hint $'+hex(h.target,6)+' adicionou '+added+' vizinho(s) priorizados sem duplicar a tabela inteira'});
    }
    const flowPeers=expandRuntimeFlowTableHint(rom,h,24);let flowAdded=0;
    for(const t of flowPeers){const tk=fnStateKey(t,hs);if(runtimeHintSeen.has(tk))continue;runtimeHintSeen.add(tk);queue.push({start:t,state:cloneDecodeState(hs),entryName:'ORACLE-FLOW-TABLE'});flowAdded++;}
    if(flowAdded)cfgIssues.push({kind:'ORACLE-FLOW-TABLE',pc:h.from,detail:'Oracle runtime expandiu o destino observado $'+hex(h.target,6)+' para '+flowAdded+' vizinho(s) plausiveis da mesma tabela JMP/JSR (abs,X)'});
  }
  while(queue.length&&remaining>0){
    const q=queue.shift(),fk=fnStateKey(q.start,q.state);if(seenFn.has(fk))continue;seenFn.add(fk);
    q.state=normEntryState(q.state);const fn=decodeCfgFunction(rom,q.start,Math.min(remaining,6144),q.state,summaries,dispatchHints);fn.entryName=q.entryName||null;fn.functionKey=fk;functions.push(fn);remaining-=fn.instructions.length;cfgIssues.push(...fn.issues);
    const stackTargets=discoverStackRtsTrampolineTargets(rom,fn);fn.stackReturnTargets=stackTargets;for(const c of stackTargets){fn.calls.push({from:c.from,target:c.target,state:cloneDecodeState(c.state),stateSig:stateSig(c.state),kind:c.kind});fn.edges.push({from:c.from,to:c.target,type:'stack-rts-candidate',fromState:stateSig(c.state),toState:stateSig(c.state)});syntheticReturnTargets.add(c.target);cfgIssues.push({kind:'CFG-RESOLVED-STACK',pc:c.from,detail:'trampolim PEI+RTS -> $'+hex(c.target,6)+' descoberto por dataflow local'});}
    const peaTargets=discoverPeaStackBootstrapTargets(rom,fn);fn.stackBootstrapTargets=peaTargets;for(const c of peaTargets){fn.calls.push({from:c.from,target:c.target,state:cloneDecodeState(c.state),stateSig:stateSig(c.state),kind:c.kind});fn.edges.push({from:c.from,to:c.target,type:'stack-pea-bootstrap',fromState:stateSig(c.state),toState:stateSig(c.state)});syntheticReturnTargets.add(c.target);cfgIssues.push({kind:'CFG-RESOLVED-STACK-BOOTSTRAP',pc:c.from,detail:'TXS+PEA semeia retorno sintetico -> $'+hex(c.target,6)+' descoberto estaticamente'});}
    for(const c of fn.calls){const ck=fnStateKey(c.target,c.state);if(!seenFn.has(ck)&&isExecutableEntryTarget(rom,c.target))queue.push({start:c.target,state:normEntryState(c.state),entryName:c.kind});}
    // Linear-sweep conservador entre rotinas: jogos comerciais frequentemente colocam a proxima rotina logo apos RTS/RTL.
    // Isso tambem cobre trampolins que preparam a stack e retornam para um endereco que nao aparece como call-site estatico.
    if(rom.data.length>=0x80000&&returnAdjacentSeeds<maxReturnAdjacentSeeds){for(const i of fn.instructions){if(returnAdjacentSeeds>=maxReturnAdjacentSeeds)break;if(i.mnemonic!=='RTS'&&i.mnemonic!=='RTL')continue;const t=nextPc(i);if(!isExecutableEntryTarget(rom,t))continue;if(knownDataAddress(t)){knowledgeAdjacentDataStops++;continue;}const st=normEntryState(i.stateOut||i.stateIn),ck=fnStateKey(t,st);if(seenFn.has(ck)||queue.some(q=>fnStateKey(q.start,q.state)===ck))continue;queue.push({start:t,state:st,entryName:'RETURN-ADJACENT'});returnAdjacentSeeds++;}}
  }
  if(knowledgeAdjacentDataStops)cfgIssues.push({kind:'KNOWLEDGE-DATA-BOUNDARY',pc:null,detail:knowledgeAdjacentDataStops+' seed(s) lineares apos RTS/RTL foram bloqueados por regioes de dados externas conhecidas'});
  if(queue.length)cfgIssues.push({kind:'CFG-LIMIT',pc:null,detail:'limite global de '+max+' variantes/instrucoes atingido; ainda existem rotinas/estados por analisar'});
  const unique=new Map();for(const fn of functions)for(const i of fn.instructions)if(!unique.has(i.pc))unique.set(i.pc,i);
  const ins=[...unique.values()].sort((a,b)=>a.pc-b.pc);const variants=functions.flatMap(f=>f.instructions);let native=0,partial=0,unsupported=0;const issues=[];
  for(const i of ins){if(i.status==='native')native++;else if(i.status==='partial')partial++;else unsupported++;const h=hardwareIssue(i);if(h)issues.push(h);if(i.status==='unsupported')issues.push({kind:'OPCODE',pc:i.pc,detail:'opcode $'+hex(i.opcode)+' ('+i.mnemonic+') ainda sem semantica C++'});if(i.status==='partial')issues.push({kind:'PARTIAL',pc:i.pc,detail:i.mnemonic+' reconhecido, mas ainda depende de runtime'});}
  issues.push(...cfgIssues);
  if(rom.header.coprocessor&&rom.header.coprocessor!=='NONE')issues.push({kind:'CART-COPROCESSOR',pc:null,detail:'cartucho usa '+rom.header.coprocessor+'; interface detectada, implementacao funcional do coprocessador ainda pendente'});
  const issueMap=new Map();for(const q of issues){const key=String(q.kind)+'|'+String(q.pc)+'|'+String(q.detail);const old=issueMap.get(key);if(old)old.occurrences=(old.occurrences||1)+1;else issueMap.set(key,{...q,occurrences:1});}issues.length=0;issues.push(...issueMap.values());
  const decoded=ins.length,ratio=decoded?native*100/decoded:0,recognized=decoded?(native+partial)*100/decoded:0;
  const hardwareBlocked=issues.some(x=>['PPU','APU','HDMA','CPU-IO','IRQ-TIMING','DECODE','VECTOR','CFG-INDIRECT','CFG-DYNAMIC','CFG-LIMIT','CFG-NONROM-TARGET','CART-COPROCESSOR'].includes(x.kind));
  const status=(unsupported||partial||hardwareBlocked)?'PORT_AINDA_NAO_JOGAVEL':'CFG_DIRETO_RECOMPILAVEL';
  const hardwareNative=issues.filter(x=>x.kind==='HW-NATIVE').length,hardwarePending=issues.filter(x=>['PPU','APU','HDMA','CPU-IO','IRQ-TIMING','CART-COPROCESSOR'].includes(x.kind)).length;
  const uniqueRoutineStarts=new Set(functions.map(f=>f.start));
  const stateVariantAddresses=new Map();for(const i of variants){const k=i.pc;stateVariantAddresses.set(k,(stateVariantAddresses.get(k)||new Set()).add(i.stateSig));}
  const variantAddressCount=[...stateVariantAddresses.values()].filter(v=>v.size>1).length;
  const staticReturnTargets=new Set();for(const i of variants)if(i.returnSite)staticReturnTargets.add(i.pc&0xFFFFFF);
  return {version:VERSION,title:rom.header.title||rom.name.replace(/\.[^.]+$/,''),mapping:rom.header.mapping,runtimeHintsImported:runtimeHintSeen.size,knowledgeSeedsImported,knowledgeDataSeedsRejected,knowledgeAdjacentDataStops,romSize:rom.data.length,copierHeader:rom.copierHeader,resetPc:reset,romType:rom.header.romType,sramBytes:rom.header.sramBytes,hasBattery:rom.header.hasBattery,coprocessor:rom.header.coprocessor,region:rom.header.region,decoded,native,partial,unsupported,nativeRatio:ratio,recognizedRatio:recognized,instructions:ins,instructionVariants:variants.length,stateVariantAddressCount:variantAddressCount,issues,header:rom.header,status,functions,cfgFunctions:uniqueRoutineStarts.size,cfgFunctionVariants:functions.length,cfgBlocks:functions.reduce((n,f)=>n+f.blockCount,0),cfgEdges:functions.reduce((n,f)=>n+f.edges.length,0),cfgCalls:functions.reduce((n,f)=>n+f.calls.length,0),hardwareNative,hardwarePending,renderer:'MODE0_1_2_3_4_5_6_7_BG_OAM_WINDOWS_COLORMATH_SUBSCANLINE_INSTRCLOCK_HD_INTEGER_SCALE_PPU_LATCH_VRAM_REMAP_PRIORITY_DIRECTCOLOR_EXTBG_HIRES_INTERLACE',hdma:'MASTER_CYCLE_HBLANK_1106_MIDFRAME_MASK_SUBSCANLINE',apuBridge:'SPC700_IPL_256_OPCODE_RUNTIME_DSP_BRR',bootHardware:'MATH_WRAM_JOYSERIAL_MASTERIRQ_INSTRCLOCK_HDOUTPUT',entryPoints:entries.map(e=>({name:e.name,vector:e.vector,target:e.target,stateSig:stateSig(e.state)})),cfgEntryPoints:entries.length,returnAdjacentSeeds,staticReturnTargets:[...staticReturnTargets].sort((a,b)=>a-b),syntheticReturnTargets:[...syntheticReturnTargets].sort((a,b)=>a-b)};
}
function cppHex(v){return '0x'+hex(v>>>0,1)+'u';}
function emitInstruction(i){const pc='0x'+hex(i.pc,6)+'u',op=i.operand>>>0,w=(i.size>1?(i.size-1)*8:0);let s='  // $'+hex(i.pc,6)+' '+i.mnemonic+'\n';
  if(i.status==='unsupported')return s+'  hw.unsupported('+pc+', 0x'+hex(i.opcode,2)+'u); return;\n';
  if(i.status==='partial')return s+'  hw.partial('+pc+', "'+i.mnemonic+'"); return;\n';
  const m=i.mnemonic;
  const modeExpr=()=>{
    if(i.mode==='Direct')return 'cpu.address("dp", '+cppHex(op)+')';
    if(i.mode==='DirectX')return 'cpu.address("dpx", '+cppHex(op)+')';
    if(i.mode==='DirectY')return 'cpu.address("dpy", '+cppHex(op)+')';
    if(i.mode==='DirectIndexedIndirectX')return 'cpu.addressDpIndirectX(hw, '+cppHex(op)+')';
    if(i.mode==='DirectIndirect')return 'cpu.addressDpIndirect(hw, '+cppHex(op)+')';
    if(i.mode==='DirectIndirectY')return 'cpu.addressDpIndirectY(hw, '+cppHex(op)+')';
    if(i.mode==='DirectIndirectLong')return 'cpu.addressDpLong(hw, '+cppHex(op)+')';
    if(i.mode==='DirectIndirectLongY')return 'cpu.addressDpLongY(hw, '+cppHex(op)+')';
    if(i.mode==='StackRelative')return 'cpu.addressStack('+cppHex(op)+')';
    if(i.mode==='StackRelativeIndirectY')return 'cpu.addressStackIndirectY(hw, '+cppHex(op)+')';
    if(i.mode==='Absolute')return 'cpu.address("abs", '+cppHex(op)+')';
    if(i.mode==='AbsoluteX')return 'cpu.address("absx", '+cppHex(op)+')';
    if(i.mode==='AbsoluteY')return 'cpu.address("absy", '+cppHex(op)+')';
    if(i.mode==='AbsoluteLong')return cppHex(op);
    if(i.mode==='AbsoluteLongX')return '(('+cppHex(op)+' + cpu.x) & 0xFFFFFFu)';
    return 'cpu.address("abs", '+cppHex(op)+')';
  };
  const aValue=()=>i.mode==='ImmA'?cppHex(op):'hw.readW('+modeExpr()+', cpu.m8?8:16)';
  if(m==='LDA'&&i.mode==='ImmA')s+='  cpu.setA('+cppHex(op)+', '+w+');\n';
  else if(m==='LDX'&&i.mode==='ImmX')s+='  cpu.setX('+cppHex(op)+', '+w+');\n';else if(m==='LDY'&&i.mode==='ImmX')s+='  cpu.setY('+cppHex(op)+', '+w+');\n';
  else if(m==='LDA')s+='  cpu.loadA(hw.readW('+modeExpr()+', cpu.m8?8:16), cpu.m8?8:16);\n';
  else if(m==='LDX')s+='  cpu.setX(hw.readW('+modeExpr()+', cpu.x8?8:16), cpu.x8?8:16);\n';
  else if(m==='LDY')s+='  cpu.setY(hw.readW('+modeExpr()+', cpu.x8?8:16), cpu.x8?8:16);\n';
  else if(m==='STA')s+='  hw.write('+modeExpr()+', cpu.a, cpu.m8?8:16);\n';
  else if(m==='STX')s+='  hw.write('+modeExpr()+', cpu.x, cpu.x8?8:16);\n';
  else if(m==='STY')s+='  hw.write('+modeExpr()+', cpu.y, cpu.x8?8:16);\n';
  else if(m==='STZ')s+='  hw.write('+modeExpr()+', 0, cpu.m8?8:16);\n';
  else if(m==='ADC')s+='  cpu.adc('+aValue()+');\n';else if(m==='SBC')s+='  cpu.sbc('+aValue()+');\n';else if(m==='AND')s+='  cpu.logicAnd('+aValue()+');\n';else if(m==='ORA')s+='  cpu.logicOr('+aValue()+');\n';else if(m==='EOR')s+='  cpu.logicXor('+aValue()+');\n';
  else if(m==='CMP')s+='  cpu.compareA('+aValue()+');\n';
  else if(m==='CPX')s+='  cpu.compareX('+(i.mode==='ImmX'?cppHex(op):'hw.readW('+modeExpr()+', cpu.x8?8:16)')+');\n';
  else if(m==='CPY')s+='  cpu.compareY('+(i.mode==='ImmX'?cppHex(op):'hw.readW('+modeExpr()+', cpu.x8?8:16)')+');\n';
  else if(m==='BIT')s+='  cpu.bit('+(i.mode==='ImmA'?cppHex(op):'hw.readW('+modeExpr()+', cpu.m8?8:16)')+', '+(i.mode==='ImmA'?'true':'false')+');\n';
  else if(['CLC','CLI','CLD','CLV'].includes(m))s+="  cpu.setFlag('"+m[2]+"', false);\n";else if(['SEC','SEI','SED'].includes(m))s+="  cpu.setFlag('"+m[2]+"', true);\n";
  else if(m==='REP')s+='  cpu.rep('+cppHex(op)+');\n';else if(m==='SEP')s+='  cpu.sep('+cppHex(op)+');\n';else if(m==='XCE')s+='  cpu.xce();\n';
  else if(m==='INX')s+="  cpu.inc('X');\n";else if(m==='DEX')s+="  cpu.decReg('X');\n";else if(m==='INY')s+="  cpu.inc('Y');\n";else if(m==='DEY')s+="  cpu.decReg('Y');\n";
  else if(m==='INC'&&i.mode==='Accumulator')s+="  cpu.inc('A');\n";else if(m==='INC')s+='  cpu.incMem(hw, '+modeExpr()+', cpu.m8?8:16);\n';
  else if(m==='DEC'&&i.mode==='Accumulator')s+="  cpu.decReg('A');\n";else if(m==='DEC')s+='  cpu.decMem(hw, '+modeExpr()+', cpu.m8?8:16);\n';
  else if(['TAX','TXA','TAY','TYA','TXY','TYX','TSX','TXS'].includes(m))s+='  cpu.transfer("'+m+'");\n';
  else if(m==='TCD')s+='  cpu.tcd();\n';else if(m==='TCS')s+='  cpu.tcs();\n';else if(m==='TDC')s+='  cpu.tdc();\n';else if(m==='TSC')s+='  cpu.tsc();\n';else if(m==='XBA')s+='  cpu.xba();\n';
  else if(m==='ROL'&&i.mode==='Accumulator')s+='  cpu.rolA();\n';else if(m==='ROL')s+='  cpu.rolMem(hw, '+modeExpr()+', cpu.m8?8:16);\n';
  else if(m==='ROR'&&i.mode==='Accumulator')s+='  cpu.rorA();\n';else if(m==='ROR')s+='  cpu.rorMem(hw, '+modeExpr()+', cpu.m8?8:16);\n';
  else if(m==='ASL'&&i.mode==='Accumulator')s+='  cpu.aslA();\n';else if(m==='ASL')s+='  cpu.aslMem(hw, '+modeExpr()+', cpu.m8?8:16);\n';
  else if(m==='LSR'&&i.mode==='Accumulator')s+='  cpu.lsrA();\n';else if(m==='LSR')s+='  cpu.lsrMem(hw, '+modeExpr()+', cpu.m8?8:16);\n';
  else if(m==='TSB')s+='  cpu.tsb(hw, '+modeExpr()+', cpu.m8?8:16);\n';else if(m==='TRB')s+='  cpu.trb(hw, '+modeExpr()+', cpu.m8?8:16);\n';
  else if(['PHA','PHX','PHY','PHP','PHB','PHK','PHD'].includes(m))s+='  cpu.push("'+m+'", hw);\n';
  else if(['PLA','PLX','PLY','PLP','PLB','PLD'].includes(m))s+='  cpu.pop("'+m+'", hw);\n';
  else if(m==='PEA')s+='  cpu.push16Value(hw, '+cppHex(op)+');\n';
  else if(m==='PEI')s+='  cpu.push16Value(hw, hw.readW(cpu.address("dp", '+cppHex(op)+'),16));\n';
  else if(m==='PER')s+='  cpu.push16Value(hw, '+cppHex((i.pc+i.size+s16(op))&0xFFFF)+');\n';
  else if(m==='MVN'||m==='MVP')s+='  cpu.blockMove(hw, 0x'+hex(op&255,2)+'u, 0x'+hex((op>>>8)&255,2)+'u, '+(m==='MVP'?'true':'false')+');\n';
  else if(m==='WDM')s+='  ;\n';
  else if(m==='RTS'||m==='RTL')s+='  return;\n';
  else if(m==='WAI')s+=`  forja65_wait(cpu, hw, (std::uint32_t(cpu.pb)<<16)|0x${hex(nextPc(i)&0xFFFF,4)}u); if(hw.stopped||hw.dispatchPending) return;\n`;
  else if(m==='STP')s+='  hw.stopped=true; return;\n';
  else if(m==='NOP')s+='  ;\n';
  else s+='  hw.partial('+pc+', "'+m+'"); return;\n';
  return s;
}
function runtimeHpp(){return `#pragma once
#include <cstdint>
#include <cstddef>
#include <stdexcept>
#include <string>
#include <vector>
#include <array>
#include <fstream>
#include <algorithm>
#include <chrono>
#include <thread>
#include <iterator>
#include <cstdlib>
#include <filesystem>
#include <sstream>
#include <iomanip>
#ifdef _WIN32
#define NOMINMAX
#include <windows.h>
#include <xinput.h>
#endif
${FrameworkTemplates['src/forja_trace.hpp']}
${FrameworkTemplates['src/forja_ir.hpp']}
struct SnesRuntime;
struct CpuState {
  std::uint16_t a{},x{},y{},s{0x1FF},d{}; std::uint8_t db{},pb{}; bool c{},z{},i{1},decimalMode{},v{},n{},e{1},m8{1},x8{1};
  void nz(std::uint16_t q,int w){std::uint16_t mask=w==8?0xFF:0xFFFF;q&=mask;z=q==0;n=(q&(w==8?0x80:0x8000))!=0;}
  void setA(std::uint32_t q,int w){a=(w==8)?((a&0xFF00)|(q&0xFF)):(q&0xFFFF);nz(a,w);} void setX(std::uint32_t q,int w){x=q&(w==8?0xFF:0xFFFF);nz(x,w);} void setY(std::uint32_t q,int w){y=q&(w==8?0xFF:0xFFFF);nz(y,w);} void loadA(std::uint32_t q,int w){setA(q,w);}
  std::uint32_t address(const std::string& mode,std::uint32_t q)const{if(mode=="dp")return(d+q)&0xFFFF;if(mode=="dpx")return(d+q+x)&0xFFFF;if(mode=="dpy")return(d+q+y)&0xFFFF;if(mode=="abs")return((std::uint32_t)db<<16)|(q&0xFFFF);if(mode=="absx")return((std::uint32_t)db<<16)|((q+x)&0xFFFF);if(mode=="absy")return((std::uint32_t)db<<16)|((q+y)&0xFFFF);return q&0xFFFFFF;}
  std::uint32_t addressDpIndirectX(SnesRuntime&,std::uint32_t q)const; std::uint32_t addressDpIndirect(SnesRuntime&,std::uint32_t q)const; std::uint32_t addressDpIndirectY(SnesRuntime&,std::uint32_t q)const; std::uint32_t addressDpLong(SnesRuntime&,std::uint32_t q)const; std::uint32_t addressDpLongY(SnesRuntime&,std::uint32_t q)const; std::uint32_t addressStack(std::uint32_t q)const{return(s+q)&0xFFFFu;} std::uint32_t addressStackIndirectY(SnesRuntime&,std::uint32_t q)const;
  void adc(std::uint32_t q){int w=m8?8:16;std::uint32_t mask=w==8?0xFF:0xFFFF,aa=a&mask,r=aa+(q&mask)+(c?1:0);c=r>mask;std::uint32_t rr=r&mask;v=((~(aa^q)&(aa^rr))&(w==8?0x80:0x8000))!=0;setA(rr,w);} void sbc(std::uint32_t q){adc((~q)&(m8?0xFF:0xFFFF));}
  void logicAnd(std::uint32_t q){setA(a&q,m8?8:16);} void logicOr(std::uint32_t q){setA(a|q,m8?8:16);} void logicXor(std::uint32_t q){setA(a^q,m8?8:16);}
  void compare(std::uint32_t lhs,std::uint32_t rhs,int w){std::uint32_t mask=w==8?0xFF:0xFFFF,l=lhs&mask,r=rhs&mask,res=(l-r)&mask;c=l>=r;z=res==0;n=(res&(w==8?0x80:0x8000))!=0;} void compareA(std::uint32_t q){compare(a,q,m8?8:16);} void compareX(std::uint32_t q){compare(x,q,x8?8:16);} void compareY(std::uint32_t q){compare(y,q,x8?8:16);}
  void bit(std::uint32_t q,bool immediate){int w=m8?8:16;std::uint32_t mask=w==8?0xFF:0xFFFF,sign=w==8?0x80:0x8000,ov=w==8?0x40:0x4000,vv=q&mask;z=((a&mask)&vv)==0;if(!immediate){n=(vv&sign)!=0;v=(vv&ov)!=0;}}
  void setFlag(char f,bool q){if(f=='C')c=q;else if(f=='I')i=q;else if(f=='D')decimalMode=q;else if(f=='V')v=q;}
  void enforceEmulation(){if(e){m8=true;x8=true;x&=0x00FFu;y&=0x00FFu;s=(std::uint16_t)(0x0100u|(s&0x00FFu));}}
  void rep(std::uint32_t q){if(!e){if(q&0x20)m8=false;if(q&0x10)x8=false;}if(q&1)c=false;if(q&2)z=false;if(q&4)i=false;if(q&8)decimalMode=false;if(q&0x40)v=false;if(q&0x80)n=false;enforceEmulation();}
  void sep(std::uint32_t q){if(q&0x20)m8=true;if(q&0x10){x8=true;x&=0x00FFu;y&=0x00FFu;}if(q&1)c=true;if(q&2)z=true;if(q&4)i=true;if(q&8)decimalMode=true;if(q&0x40)v=true;if(q&0x80)n=true;enforceEmulation();}
  void xce(){bool olde=e;e=c;c=olde;enforceEmulation();} void inc(char r){if(r=='A')setA(a+1,m8?8:16);else if(r=='X')setX(x+1,x8?8:16);else setY(y+1,x8?8:16);} void decReg(char r){if(r=='A')setA(a-1,m8?8:16);else if(r=='X')setX(x-1,x8?8:16);else setY(y-1,x8?8:16);}
  void transfer(const std::string&t){if(t=="TAX")setX(a,x8?8:16);else if(t=="TXA")setA(x,m8?8:16);else if(t=="TAY")setY(a,x8?8:16);else if(t=="TYA")setA(y,m8?8:16);else if(t=="TXY")setY(x,x8?8:16);else if(t=="TYX")setX(y,x8?8:16);else if(t=="TSX")setX(s,x8?8:16);else if(t=="TXS")s=e?(std::uint16_t)(0x0100u|(x&0x00FFu)):x;}
  void tcd(){d=a;nz(d,16);} void tcs(){s=e?(std::uint16_t)(0x0100u|(a&0x00FFu)):a;} void tdc(){a=d;nz(a,16);} void tsc(){a=s;nz(a,16);} void xba(){a=(std::uint16_t)((a<<8)|(a>>8));nz(a&0xFF,8);} void rolA(){int w=m8?8:16;std::uint32_t mask=w==8?0xFF:0xFFFF,sign=w==8?0x80:0x8000,old=a&mask,r=((old<<1)|(c?1:0))&mask;c=(old&sign)!=0;setA(r,w);} void rorA(){int w=m8?8:16;std::uint32_t mask=w==8?0xFF:0xFFFF,sign=w==8?0x80:0x8000,old=a&mask,r=((old>>1)|(c?sign:0))&mask;c=(old&1u)!=0;setA(r,w);} void aslA(){int w=m8?8:16;std::uint32_t mask=w==8?0xFF:0xFFFF,sign=w==8?0x80:0x8000,old=a&mask;c=(old&sign)!=0;setA((old<<1)&mask,w);} void lsrA(){int w=m8?8:16;std::uint32_t mask=w==8?0xFF:0xFFFF,old=a&mask;c=(old&1u)!=0;setA((old>>1)&mask,w);}
  std::uint8_t packP()const{return(std::uint8_t)((n?0x80:0)|(v?0x40:0)|(m8?0x20:0)|(x8?0x10:0)|(decimalMode?0x08:0)|(i?0x04:0)|(z?0x02:0)|(c?0x01:0));} void unpackP(std::uint8_t p){n=p&0x80;v=p&0x40;m8=p&0x20;x8=p&0x10;decimalMode=p&8;i=p&4;z=p&2;c=p&1;if(x8){x&=0x00FFu;y&=0x00FFu;}enforceEmulation();}
  void push(const std::string&,SnesRuntime&); void pop(const std::string&,SnesRuntime&); void push8Value(SnesRuntime&,std::uint8_t); std::uint8_t pop8Value(SnesRuntime&); std::uint8_t peekStack8(SnesRuntime&,unsigned=1)const; void push16Value(SnesRuntime&,std::uint16_t); std::uint16_t pop16Value(SnesRuntime&); std::uint16_t peekStack16(SnesRuntime&)const; void enterInterrupt(SnesRuntime&,std::uint32_t,bool=false); std::uint32_t returnInterrupt(SnesRuntime&); void incMem(SnesRuntime&,std::uint32_t,int); void decMem(SnesRuntime&,std::uint32_t,int); void aslMem(SnesRuntime&,std::uint32_t,int); void lsrMem(SnesRuntime&,std::uint32_t,int); void rolMem(SnesRuntime&,std::uint32_t,int); void rorMem(SnesRuntime&,std::uint32_t,int); void tsb(SnesRuntime&,std::uint32_t,int); void trb(SnesRuntime&,std::uint32_t,int); void blockMove(SnesRuntime&,std::uint8_t,std::uint8_t,bool);
};
struct PpuState {
  std::uint8_t regs[0x40]{}; std::vector<std::uint8_t> vram=std::vector<std::uint8_t>(0x10000); std::vector<std::uint8_t> cgram=std::vector<std::uint8_t>(512); std::vector<std::uint8_t> oam=std::vector<std::uint8_t>(544);
  std::uint8_t inidisp{},obsel{},bgmode{},mosaic{},vmain{},tm{},ts{},tmw{},tsw{},setini{},bgsc[4]{},bgnba[4]{};
  std::uint8_t m7sel{},w12sel{},w34sel{},wobjsel{},wh[4]{},wbglog{},wobjlog{},cgwsel{},cgadsub{},coldata{};
  std::uint8_t fixedR{},fixedG{},fixedB{}; std::uint16_t m7[6]{}; std::uint8_t m7Latch[6]{}; bool m7High[6]{};
  bool forceBlank{}; std::uint8_t brightness{}; std::uint16_t vmadd{},oamAddr{},vramReadBuffer{},oamWriteRegister{};
  std::uint8_t bgOfsByte{},m7Byte{},cgAddr{},cgSavedByte{}; bool oamFlip{},oamReadFlip{},cgHigh{},cgReadHigh{};
  std::uint16_t scrollX[4]{},scrollY[4]{},hCounter{},vCounter{}; bool hCounterHigh{},vCounterHigh{};
  std::uint16_t vramStep()const{switch(vmain&3){case 0:return 1;case 1:return 32;default:return 128;}}
  std::uint16_t vramMappedWord()const{unsigned mode=(vmain>>2)&3u;if(!mode)return vmadd;static const unsigned count[4]={0,32,64,128},shift[4]={0,5,6,7};unsigned c=count[mode],mask=c*8u-1u,rem=vmadd&mask;return(std::uint16_t)((vmadd&~mask)+(rem>>shift[mode])+((rem&(c-1u))<<3));}
  std::uint16_t vramByteAddress(bool high)const{return(std::uint16_t)(((std::uint32_t)vramMappedWord()*2u+(high?1u:0u))&0xFFFFu);}
  void updateVramReadBuffer(){auto p=vramByteAddress(false);vramReadBuffer=(std::uint16_t)(vram[p]|(vram[(p+1)&0xFFFFu]<<8));}
  void incVram(bool highPort){bool afterHigh=(vmain&0x80)!=0;if(afterHigh==highPort)vmadd=(std::uint16_t)(vmadd+vramStep());}
  void writeScroll(unsigned i,std::uint8_t v){if(i>=8)return;unsigned bg=i>>1;if((i&1u)==0)scrollX[bg]=(std::uint16_t)(((std::uint16_t)v<<8)|(bgOfsByte&~7u)|((scrollX[bg]>>8)&7u));else scrollY[bg]=(std::uint16_t)(((std::uint16_t)v<<8)|bgOfsByte);bgOfsByte=v;if(i<2)m7Byte=v;}
  void writeM7(unsigned i,std::uint8_t v){if(i>=6)return;m7[i]=(std::uint16_t)(m7Byte|((std::uint16_t)v<<8));m7Byte=v;}
  void writeOam(std::uint8_t v){if(!oamFlip)oamWriteRegister=(std::uint16_t)((oamWriteRegister&0xFF00u)|v);if(oamAddr&0x100u){unsigned a=((oamAddr&0x10Fu)<<1)+(oamFlip?1u:0u);if(a<oam.size())oam[a]=v;}else if(oamFlip){oamWriteRegister=(std::uint16_t)((oamWriteRegister&0x00FFu)|((std::uint16_t)v<<8));unsigned a=(oamAddr&0xFFu)<<1;if(a+1<oam.size()){oam[a]=(std::uint8_t)oamWriteRegister;oam[a+1]=(std::uint8_t)(oamWriteRegister>>8);}}oamFlip=!oamFlip;if(!oamFlip)oamAddr=(std::uint16_t)((oamAddr+1)&0x1FFu);}
  std::uint8_t readOam(){unsigned a=(oamAddr&0x100u)?(((oamAddr&0x10Fu)<<1)+(oamReadFlip?1u:0u)):(((oamAddr&0xFFu)<<1)+(oamReadFlip?1u:0u));std::uint8_t v=a<oam.size()?oam[a]:0;oamReadFlip=!oamReadFlip;if(!oamReadFlip)oamAddr=(std::uint16_t)((oamAddr+1)&0x1FFu);return v;}
  void writeCgram(std::uint8_t v){if(!cgHigh)cgSavedByte=v;else{unsigned a=(unsigned)cgAddr*2u;cgram[a&0x1FFu]=cgSavedByte;cgram[(a+1u)&0x1FFu]=v&0x7Fu;cgAddr++;}cgHigh=!cgHigh;}
  std::uint8_t readCgram(){unsigned a=(unsigned)cgAddr*2u;std::uint8_t v=!cgReadHigh?cgram[a&0x1FFu]:(cgram[(a+1u)&0x1FFu]&0x7Fu);if(cgReadHigh)cgAddr++;cgReadHigh=!cgReadHigh;return v;}
  void writeFixedColor(std::uint8_t v){coldata=v;std::uint8_t q=v&31u;if(v&0x20)fixedR=q;if(v&0x40)fixedG=q;if(v&0x80)fixedB=q;}
  void write(std::uint16_t a,std::uint8_t v){if(a>=0x2100&&a<=0x213F)regs[a-0x2100]=v;switch(a){
    case 0x2100:inidisp=v;forceBlank=(v&0x80)!=0;brightness=v&0x0F;break;case 0x2101:obsel=v;break;
    case 0x2102:oamAddr=(std::uint16_t)(((regs[3]&1u)<<8)|v);oamFlip=oamReadFlip=false;break;case 0x2103:oamAddr=(std::uint16_t)(((v&1u)<<8)|regs[2]);oamFlip=oamReadFlip=false;break;case 0x2104:writeOam(v);break;case 0x2105:bgmode=v;break;case 0x2106:mosaic=v;break;
    case 0x2107:case 0x2108:case 0x2109:case 0x210A:bgsc[a-0x2107]=v;break;
    case 0x210B:bgnba[0]=v&0x0F;bgnba[1]=(v>>4)&0x0F;break;case 0x210C:bgnba[2]=v&0x0F;bgnba[3]=(v>>4)&0x0F;break;
    case 0x210D:case 0x210E:case 0x210F:case 0x2110:case 0x2111:case 0x2112:case 0x2113:case 0x2114:writeScroll(a-0x210D,v);break;
    case 0x2115:vmain=v;break;case 0x2116:vmadd=(vmadd&0xFF00)|v;updateVramReadBuffer();break;case 0x2117:vmadd=(vmadd&0x00FF)|((std::uint16_t)v<<8);updateVramReadBuffer();break;
    case 0x2118:vram[vramByteAddress(false)]=v;incVram(false);break;case 0x2119:vram[vramByteAddress(true)]=v;incVram(true);break;
    case 0x211A:m7sel=v;break;case 0x211B:case 0x211C:case 0x211D:case 0x211E:case 0x211F:case 0x2120:writeM7(a-0x211B,v);break;
    case 0x2121:cgAddr=v;cgHigh=cgReadHigh=false;break;case 0x2122:writeCgram(v);break;
    case 0x2123:w12sel=v;break;case 0x2124:w34sel=v;break;case 0x2125:wobjsel=v;break;case 0x2126:case 0x2127:case 0x2128:case 0x2129:wh[a-0x2126]=v;break;case 0x212A:wbglog=v;break;case 0x212B:wobjlog=v;break;
    case 0x212C:tm=v;break;case 0x212D:ts=v;break;case 0x212E:tmw=v;break;case 0x212F:tsw=v;break;case 0x2130:cgwsel=v;break;case 0x2131:cgadsub=v;break;case 0x2132:writeFixedColor(v);break;case 0x2133:setini=v;break;default:break;}}
  std::uint8_t read(std::uint16_t a){switch(a){
    case 0x2134:case 0x2135:case 0x2136:{std::int32_t r=(std::int32_t)(std::int16_t)m7[0]*(std::int32_t)(std::int8_t)(m7[1]>>8);return(std::uint8_t)((r>>((a-0x2134)*8))&0xFF);}
    case 0x2137:hCounterHigh=vCounterHigh=false;return 0;
    case 0x2138:return readOam();
    case 0x2139:{std::uint8_t v=(std::uint8_t)vramReadBuffer;if(!(vmain&0x80u)){updateVramReadBuffer();vmadd=(std::uint16_t)(vmadd+vramStep());}return v;}
    case 0x213A:{std::uint8_t v=(std::uint8_t)(vramReadBuffer>>8);if(vmain&0x80u){updateVramReadBuffer();vmadd=(std::uint16_t)(vmadd+vramStep());}return v;}
    case 0x213B:return readCgram();
    case 0x213C:{std::uint8_t v=!hCounterHigh?(std::uint8_t)hCounter:(std::uint8_t)((hCounter>>8)&1u);hCounterHigh=!hCounterHigh;return v;}
    case 0x213D:{std::uint8_t v=!vCounterHigh?(std::uint8_t)vCounter:(std::uint8_t)((vCounter>>8)&1u);vCounterHigh=!vCounterHigh;return v;}
    case 0x213E:return 0x01u;
    case 0x213F:hCounterHigh=vCounterHigh=false;return 0x03u;
    default:return(a>=0x2100&&a<=0x213F)?regs[a-0x2100]:0;}}
  std::uint32_t color(unsigned idx)const{idx&=0xFF;std::uint16_t c=(std::uint16_t)(cgram[(idx*2)&0x1FF]|((cgram[(idx*2+1)&0x1FF]&0x7F)<<8));return rgba15(c);}
  unsigned tilePixel2(std::uint32_t base,unsigned tile,unsigned x,unsigned y)const{std::uint32_t p=(base+tile*16u+(y&7u)*2u)&0xFFFFu;unsigned bit=7-(x&7u);return ((vram[p]>>bit)&1u)|(((vram[(p+1)&0xFFFFu]>>bit)&1u)<<1);}
  unsigned tilePixel4(std::uint32_t base,unsigned tile,unsigned x,unsigned y)const{std::uint32_t p=(base+tile*32u+(y&7u)*2u)&0xFFFFu;unsigned bit=7-(x&7u);return ((vram[p]>>bit)&1u)|(((vram[(p+1)&0xFFFFu]>>bit)&1u)<<1)|(((vram[(p+16)&0xFFFFu]>>bit)&1u)<<2)|(((vram[(p+17)&0xFFFFu]>>bit)&1u)<<3);}
  unsigned tilePixel8(std::uint32_t base,unsigned tile,unsigned x,unsigned y)const{std::uint32_t p=(base+tile*64u+(y&7u)*2u)&0xFFFFu;unsigned bit=7-(x&7u),q=0;for(unsigned plane=0;plane<8;plane++){unsigned a=(p+(plane>>1)*16u+(plane&1u))&0xFFFFu;q|=((vram[a]>>bit)&1u)<<plane;}return q;}
  struct LayerPixel { std::uint16_t c15{}; std::uint8_t source{5},objPal{},priority{1},oamIndex{255}; bool valid{true}; };
  static int sign13(std::uint16_t q){q&=0x1FFFu;return(q&0x1000u)?(int)q-0x2000:(int)q;}
  static int sign16(std::uint16_t q){return (int)(std::int16_t)q;}
  std::uint16_t palette15(unsigned idx)const{idx&=0xFFu;return(std::uint16_t)(cgram[(idx*2u)&0x1FFu]|((cgram[(idx*2u+1u)&0x1FFu]&0x7Fu)<<8));}
  std::uint16_t directColor15(unsigned pal,unsigned c)const{unsigned r=((c&0x07u)<<2)|((pal&0x01u)<<1),g=((c&0x38u)>>1)|(pal&0x02u),b=((c&0xC0u)>>3)|(pal&0x04u);return(std::uint16_t)((r&31u)|((g&31u)<<5)|((b&31u)<<10));}
  std::uint16_t fixed15()const{return(std::uint16_t)((fixedR&31u)|((fixedG&31u)<<5)|((fixedB&31u)<<10));}
  std::uint32_t rgba15(std::uint16_t c)const{unsigned r=(c&31u)*255u/31u,g=((c>>5)&31u)*255u/31u,b=((c>>10)&31u)*255u/31u,br=brightness;r=r*br/15u;g=g*br/15u;b=b*br/15u;return 0xFF000000u|(r<<16)|(g<<8)|b;}
  static std::uint16_t blend15(std::uint16_t a,std::uint16_t b,bool sub,bool half){int ar=a&31,ag=(a>>5)&31,ab=(a>>10)&31,br=b&31,bg=(b>>5)&31,bb=(b>>10)&31;auto f=[&](int x,int y){int q=sub?x-y:x+y;if(q<0)q=0;if(q>31)q=31;if(half)q>>=1;return q;};return(std::uint16_t)(f(ar,br)|(f(ag,bg)<<5)|(f(ab,bb)<<10));}
  bool pseudoHires()const{return(setini&0x08u)!=0;} bool interlace()const{return(setini&0x01u)!=0;} bool extbg()const{return(setini&0x40u)!=0;}
  unsigned visibleHeight()const{return(setini&0x04u)?239u:224u;} unsigned outputWidth()const{unsigned m=bgmode&7u;return(m==5||m==6||pseudoHires())?512u:256u;} unsigned outputHeight()const{return visibleHeight()*(interlace()?2u:1u);}
  bool insideWin(unsigned n,int x)const{unsigned l=wh[(n&1u)*2u],r=wh[(n&1u)*2u+1u];return l<=r&&x>=(int)l&&x<=(int)r;}
  bool combineWin(std::uint8_t sel,unsigned shift,unsigned logic,int x)const{bool e1=(sel&(1u<<(shift+1)))!=0,i1=(sel&(1u<<shift))!=0,e2=(sel&(1u<<(shift+3)))!=0,i2=(sel&(1u<<(shift+2)))!=0;if(!e1&&!e2)return false;bool w1=insideWin(0,x);if(i1)w1=!w1;bool w2=insideWin(1,x);if(i2)w2=!w2;if(!e1)return w2;if(!e2)return w1;switch(logic&3u){case 0:return w1||w2;case 1:return w1&&w2;case 2:return w1!=w2;default:return w1==w2;}}
  bool layerWindow(unsigned layer,int x)const{if(layer<2)return combineWin(w12sel,layer?4u:0u,(wbglog>>(layer*2u))&3u,x);if(layer<4)return combineWin(w34sel,(layer-2u)?4u:0u,(wbglog>>(layer*2u))&3u,x);if(layer==4)return combineWin(wobjsel,0u,wobjlog&3u,x);return combineWin(wobjsel,4u,(wobjlog>>2)&3u,x);}
  bool hiddenByWindow(unsigned layer,int x,bool sub)const{std::uint8_t mask=sub?tsw:tmw;if(layer>4||!(mask&(1u<<layer)))return false;return layerWindow(layer,x);}
  static bool regionMatch(unsigned mode,bool inside){switch(mode&3u){case 0:return false;case 1:return !inside;case 2:return inside;default:return true;}}
  std::pair<unsigned,unsigned> bgDepth(unsigned bg)const{unsigned m=bgmode&7u;if(m==0){static const unsigned lo[4]={11,10,3,2},hi[4]={15,14,7,6};return{lo[bg&3],hi[bg&3]};}if(m==1){if(bg==0)return{11,15};if(bg==1)return{10,14};if(bg==2)return{3,(bgmode&0x08u)?17u:7u};}if(m>=2&&m<=6){if(bg==0)return{7,15};if(bg==1)return{3,11};}if(m==7){if(bg==0)return{7,7};if(bg==1)return{3,11};}return{1,1};}
  struct BgTileCache { unsigned tileX{},worldY{};bool valid{};std::array<LayerPixel,8> pixels{}; };
  using BgTileRows=std::array<BgTileCache,4>;
  LayerPixel sampleBg(unsigned bg,int sx,int sy,unsigned bpp,unsigned paletteBase=0,bool hires=false,bool allowDirect=false,BgTileCache*cache=nullptr)const{
    LayerPixel p{};p.valid=false;p.source=(std::uint8_t)bg;if(bg>=4)return p;
    unsigned mos=((mosaic>>4)&15u)+1u;if((mosaic&(1u<<bg))&&mos>1u){sx-=sx%(int)mos;sy-=sy%(int)mos;}
    std::uint32_t mapBase=((std::uint32_t)(bgsc[bg]&0xFCu)<<9)&0xFFFFu,charBase=((std::uint32_t)(bgnba[bg]&7u)*0x2000u)&0xFFFFu;
    unsigned sc=bgsc[bg]&3u,mapWTiles=(sc&1u)?64u:32u,mapHTiles=(sc&2u)?64u:32u;bool big=((bgmode>>(4u+bg))&1u)!=0;
    unsigned tileW=(big&&!hires)?16u:8u,tileH=big?16u:8u,mapW=mapWTiles*tileW,mapH=mapHTiles*tileH,wx=(unsigned)(sx+(int)scrollX[bg])&(mapW-1u),wy=(unsigned)(sy+(int)scrollY[bg])&(mapH-1u),tx=wx/tileW,ty=wy/tileH;
    if(cache&&cache->valid&&cache->tileX==(wx>>3)&&cache->worldY==wy)return cache->pixels[wx&7u];
    unsigned screenX=tx>>5,screenY=ty>>5,screen=screenX+screenY*((mapWTiles+31u)>>5),localX=tx&31u,localY=ty&31u;std::uint32_t ep=(mapBase+screen*0x800u+((localY*32u+localX)*2u))&0xFFFFu;
    std::uint16_t e=(std::uint16_t)(vram[ep]|(vram[(ep+1)&0xFFFFu]<<8));unsigned tile=e&0x3FFu,pal=(e>>10)&7u;bool pri=(e&0x2000u)!=0,hf=e&0x4000u,vf=e&0x8000u;
    unsigned px=wx&(tileW-1u),py=wy&(tileH-1u);if(hf)px=tileW-1u-px;if(vf)py=tileH-1u-py;if(big){if(tileW>8u)tile=(tile+(px>>3))&0x3FFu;if(tileH>8u)tile=(tile+((py>>3)<<4))&0x3FFu;}px&=7u;py&=7u;
    if(cache){
      // Decode plane bytes once for this eight-pixel tile row. The cache lives
      // only for a synchronized render segment; VRAM/palette/register writes
      // are therefore visible immediately in the next segment.
      std::array<unsigned,8> planes{};std::uint32_t base=(charBase+tile*(bpp*8u)+py*2u)&0xFFFFu;
      for(unsigned plane=0;plane<bpp;plane++)planes[plane]=vram[(base+(plane>>1)*16u+(plane&1u))&0xFFFFu];
      auto depth=bgDepth(bg);for(unsigned x=0;x<8;x++){
        LayerPixel q{};q.valid=false;q.source=(std::uint8_t)bg;unsigned bit=hf?x:7u-x,ci=0;
        for(unsigned plane=0;plane<bpp;plane++)ci|=((planes[plane]>>bit)&1u)<<plane;
        if(ci){if(bpp==8&&allowDirect&&(cgwsel&1u))q.c15=directColor15(pal,ci);else if(bpp==8)q.c15=palette15(ci);else q.c15=palette15(paletteBase+pal*(bpp==4?16u:4u)+ci);
          q.priority=(std::uint8_t)(pri?depth.second:depth.first);q.valid=true;}
        cache->pixels[x]=q;
      }cache->tileX=wx>>3;cache->worldY=wy;cache->valid=true;return cache->pixels[wx&7u];
    }
    unsigned ci=bpp==8?tilePixel8(charBase,tile,px,py):(bpp==4?tilePixel4(charBase,tile,px,py):tilePixel2(charBase,tile,px,py));if(!ci)return p;
    if(bpp==8&&allowDirect&&(cgwsel&1u))p.c15=directColor15(pal,ci);else if(bpp==8)p.c15=palette15(ci);else if(bpp==4)p.c15=palette15(paletteBase+pal*16u+ci);else p.c15=palette15(paletteBase+pal*4u+ci);
    auto d=bgDepth(bg);p.priority=(std::uint8_t)(pri?d.second:d.first);p.valid=true;return p;
  }
  LayerPixel sampleMode7(unsigned bg,int sx,int sy)const{
    LayerPixel p{};p.valid=false;p.source=(std::uint8_t)bg;int x=(m7sel&1u)?(255-sx):sx,y=(m7sel&2u)?(255-sy):sy;int A=sign16(m7[0]),B=sign16(m7[1]),C=sign16(m7[2]),D=sign16(m7[3]),cx=sign13(m7[4]),cy=sign13(m7[5]),hofs=sign13(scrollX[0]),vofs=sign13(scrollY[0]);
    long dx=(long)x+hofs-cx,dy=(long)y+vofs-cy;long tx=((long)A*dx+(long)B*dy)/256+cx,ty=((long)C*dx+(long)D*dy)/256+cy;bool outside=tx<0||ty<0||tx>1023||ty>1023;unsigned ux,uy,tile;
    if(!(m7sel&0x80u)){ux=(unsigned)tx&1023u;uy=(unsigned)ty&1023u;std::uint32_t mp=(((uy>>3)*128u+(ux>>3))*2u)&0xFFFFu;tile=vram[mp];}else if(outside){if(!(m7sel&0x40u))return p;ux=(unsigned)tx&7u;uy=(unsigned)ty&7u;tile=0;}else{ux=(unsigned)tx;uy=(unsigned)ty;std::uint32_t mp=(((uy>>3)*128u+(ux>>3))*2u)&0xFFFFu;tile=vram[mp];}
    std::uint32_t pp=(((tile*64u)+((uy&7u)*8u)+(ux&7u))*2u+1u)&0xFFFFu;unsigned ci=vram[pp];
    if(bg==1){if(!extbg())return p;bool pri=(ci&0x80u)!=0;ci&=0x7Fu;if(!ci)return p;p.c15=palette15(ci);p.priority=(std::uint8_t)(pri?11u:3u);}
    else{if(!ci)return p;p.c15=(cgwsel&1u)?directColor15(0,ci):palette15(ci);p.priority=7;}
    p.valid=true;return p;
  }
  std::pair<unsigned,unsigned> objDims(bool large)const{unsigned mode=(obsel>>5)&7u;static const unsigned sw[8]={8,8,8,16,16,32,16,16},sh[8]={8,8,8,16,16,32,32,32},lw[8]={16,32,64,32,64,64,32,32},lh[8]={16,32,64,32,64,64,64,32};return large?std::pair<unsigned,unsigned>{lw[mode],lh[mode]}:std::pair<unsigned,unsigned>{sw[mode],sh[mode]};}
  LayerPixel sampleSprites(int sx,int sy)const{
    LayerPixel best{};best.valid=false;best.source=4;std::uint32_t nameBase=(std::uint32_t)(obsel&3u)<<14,nameSelect=(std::uint32_t)((obsel>>3)&3u)<<13;
    for(int si=127;si>=0;--si){unsigned i=(unsigned)si,o=i*4u,hb=oam[512u+(i>>2)],pair=(hb>>((i&3u)*2u))&3u;int x=(int)oam[o]|((pair&1u)?256:0);if(x>=256)x-=512;int y=(int)oam[o+1];unsigned at=oam[o+3],pal=(at>>1)&7u,pri=(at>>4)&3u;auto dim=objDims((pair&2u)!=0);unsigned w=dim.first,h=dim.second;int px=sx-x,py=sy-y;if(px<0||py<0||px>=(int)w||py>=(int)h)continue;
      unsigned qx=(at&0x40u)?(w-1u-(unsigned)px):(unsigned)px,qy=(at&0x80u)?(h-1u-(unsigned)py):(unsigned)py,name=(unsigned)oam[o+2]|((at&1u)<<8),tile=(name&0x100u)|((((name&0xF0u)+((qy>>3)<<4))&0xF0u))|((name+(qx>>3))&0x0Fu),base=nameBase+((tile&0x100u)?nameSelect:0u),ci=tilePixel4(base,tile&0xFFu,qx&7u,qy&7u);std::uint8_t depth=(std::uint8_t)(4u+pri*4u);
      if(ci&&(!best.valid||depth>best.priority||(depth==best.priority&&i<best.oamIndex))){best.c15=palette15(128u+pal*16u+ci);best.objPal=(std::uint8_t)pal;best.priority=depth;best.oamIndex=(std::uint8_t)i;best.valid=true;}}
    return best;
  }
  using SpriteRow=std::array<LayerPixel,256>;
  SpriteRow buildSpriteRow(int sy)const{
    SpriteRow row{};for(auto&q:row){q.valid=false;q.source=4;}
    const std::uint32_t nameBase=(std::uint32_t)(obsel&3u)<<14,nameSelect=(std::uint32_t)((obsel>>3)&3u)<<13;
    for(int si=127;si>=0;--si){unsigned i=(unsigned)si,o=i*4u,hb=oam[512u+(i>>2)],pair=(hb>>((i&3u)*2u))&3u;
      int x=(int)oam[o]|((pair&1u)?256:0);if(x>=256)x-=512;int py=sy-(int)oam[o+1];auto dim=objDims((pair&2u)!=0);unsigned w=dim.first,h=dim.second;
      if(py<0||py>=(int)h){continue;}int left=std::max(0,x),right=std::min(256,x+(int)w);if(left>=right)continue;
      unsigned at=oam[o+3],pal=(at>>1)&7u,pri=(at>>4)&3u,qy=(at&0x80u)?(h-1u-(unsigned)py):(unsigned)py,name=(unsigned)oam[o+2]|((at&1u)<<8);
      const std::uint8_t depth=(std::uint8_t)(4u+pri*4u);
      for(int sx=left;sx<right;sx++){unsigned px=(unsigned)(sx-x),qx=(at&0x40u)?(w-1u-px):px;
        unsigned tile=(name&0x100u)|((((name&0xF0u)+((qy>>3)<<4))&0xF0u))|((name+(qx>>3))&0x0Fu),base=nameBase+((tile&0x100u)?nameSelect:0u),ci=tilePixel4(base,tile&0xFFu,qx&7u,qy&7u);auto&best=row[(unsigned)sx];
        if(ci&&(!best.valid||depth>best.priority||(depth==best.priority&&i<best.oamIndex))){best.c15=palette15(128u+pal*16u+ci);best.objPal=(std::uint8_t)pal;best.priority=depth;best.oamIndex=(std::uint8_t)i;best.valid=true;}
      }
    }return row;
  }
  LayerPixel compose(int x,int y,bool sub,bool hires=false,const SpriteRow*sprites=nullptr,BgTileRows*bgTiles=nullptr)const{
    LayerPixel out{palette15(0),5,0,1,255,true};std::uint8_t en=sub?ts:tm;unsigned mode=bgmode&7u;int wx=hires?(x>>1):x;
    auto take=[&](LayerPixel q){if(q.valid&&q.priority>out.priority)out=q;};
    auto bg=[&](unsigned n,unsigned bpp,unsigned palBase=0,bool dc=false){if(!(en&(1u<<n))||hiddenByWindow(n,wx,sub))return;take(sampleBg(n,x,y,bpp,palBase,hires,dc,bgTiles?&(*bgTiles)[n]:nullptr));};
    switch(mode){
      case 0:bg(3,2,96);bg(2,2,64);bg(1,2,32);bg(0,2,0);break;
      case 1:bg(2,2);bg(1,4);bg(0,4);break;
      case 2:bg(1,4);bg(0,4);break;
      case 3:bg(1,4);bg(0,8,0,true);break;
      case 4:bg(1,2);bg(0,8,0,true);break;
      case 5:bg(1,2);bg(0,4);break;
      case 6:bg(0,4);break;
      case 7:if((en&1u)&&!hiddenByWindow(0,wx,sub))take(sampleMode7(0,x,y));if((en&2u)&&!hiddenByWindow(1,wx,sub))take(sampleMode7(1,x,y));break;
    }
    if((en&0x10u)&&!hiddenByWindow(4,wx,sub)){int ox=hires?(x>>1):x;take(sprites&&ox>=0&&ox<256?(*sprites)[(unsigned)ox]:sampleSprites(ox,y));}return out;
  }
  std::uint16_t finalMain15(int x,int y,bool hires=false,const SpriteRow*sprites=nullptr,BgTileRows*bgTiles=nullptr)const{
    int wx=hires?(x>>1):x;bool cw=layerWindow(5,wx);auto main=compose(x,y,false,hires,sprites,bgTiles);if(regionMatch((cgwsel>>6)&3u,cw))main.c15=0;
    bool math=false;if(main.source<=3)math=(cgadsub&(1u<<main.source))!=0;else if(main.source==4)math=(cgadsub&0x10u)&&main.objPal>=4;else math=(cgadsub&0x20u)!=0;std::uint16_t result=main.c15;
    if(math){bool masked=regionMatch((cgwsel>>4)&3u,cw);LayerPixel subPixel{};if(cgwsel&0x02u)subPixel=compose(x,y,true,hires,sprites,bgTiles);std::uint16_t add=0;if(!masked)add=(cgwsel&0x02u)?subPixel.c15:fixed15();bool half=(cgadsub&0x40u)!=0;if((cgwsel&0x02u)&&subPixel.source==5)half=false;result=blend15(result,add,(cgadsub&0x80u)!=0,half);}return result;
  }
  void renderScanline(std::vector<std::uint32_t>&fb,int y,int w=256)const{if(y<0)return;if(fb.size()<(std::size_t)w*(y+1))fb.resize((std::size_t)w*(y+1),0xFF000000u);for(int x=0;x<w;x++){if(forceBlank||brightness==0){fb[(std::size_t)y*w+x]=0xFF000000u;continue;}fb[(std::size_t)y*w+x]=rgba15(finalMain15(x,y,false));}}
  void renderOutputSegment(std::vector<std::uint32_t>&fb,int y,unsigned x0,unsigned x1,unsigned field=0)const{
    if(y<0||(unsigned)y>=visibleHeight()){return;}unsigned ow=outputWidth(),oh=outputHeight(),row=interlace()?((unsigned)y*2u+(field&1u)):(unsigned)y;if(fb.size()<(std::size_t)ow*oh)fb.resize((std::size_t)ow*oh,0xFF000000u);x0=std::min(x0,ow);x1=std::min(x1,ow);if(x1<=x0)return;
    if(forceBlank||brightness==0){for(unsigned x=x0;x<x1;x++)fb[(std::size_t)row*ow+x]=0xFF000000u;return;}
    unsigned mode=bgmode&7u;int sy=((mode==5||mode==6)&&interlace())?((int)y*2+(int)(field&1u)):y;
    BgTileRows bgTiles{};
    // Segment-local row: rebuilt after every synchronized PPU mutation.
    SpriteRow spriteRow;const SpriteRow*sprites=nullptr;if((tm|ts)&0x10u){spriteRow=buildSpriteRow(sy);sprites=&spriteRow;}
    if(mode==5||mode==6){for(unsigned x=x0;x<x1;x++)fb[(std::size_t)row*ow+x]=rgba15(finalMain15((int)x,sy,true,sprites,&bgTiles));return;}
    if(pseudoHires()){for(unsigned ox=x0;ox<x1;ox++){unsigned lx=ox>>1;if((ox&1u)==0){auto sub=compose((int)lx,y,true,false,sprites,&bgTiles);fb[(std::size_t)row*ow+ox]=rgba15(sub.c15);}else fb[(std::size_t)row*ow+ox]=rgba15(finalMain15((int)lx,y,false,sprites,&bgTiles));}return;}
    for(unsigned x=x0;x<x1;x++)fb[(std::size_t)row*ow+x]=rgba15(finalMain15((int)x,y,false,sprites,&bgTiles));
  }
  void renderOutputScanline(std::vector<std::uint32_t>&fb,int y,unsigned field=0)const{renderOutputSegment(fb,y,0,outputWidth(),field);}
  std::vector<std::uint32_t> renderFrame(int w=256,int h=224)const{std::vector<std::uint32_t>fb((std::size_t)w*h,0xFF000000u);for(int y=0;y<h;y++)renderScanline(fb,y,w);return fb;}
  std::vector<std::uint32_t> renderNativeFrame(unsigned field=0)const{std::vector<std::uint32_t>fb((std::size_t)outputWidth()*outputHeight(),0xFF000000u);for(unsigned y=0;y<visibleHeight();y++)renderOutputScanline(fb,(int)y,field);return fb;}
  bool savePpm(const std::string&path,int w=256,int h=224)const{auto fb=renderFrame(w,h);std::ofstream f(path,std::ios::binary);if(!f)return false;f<<"P6\\n"<<w<<" "<<h<<"\\n255\\n";for(auto p:fb){char q[3]={(char)((p>>16)&255),(char)((p>>8)&255),(char)(p&255)};f.write(q,3);}return(bool)f;}

};
struct CpuIoState {
  std::uint8_t nmitimen{},wrio{0xFF},mdmaen{},hdmaen{},memsel{},wrmpya{},wrmpyb{},wrdivb{};
  std::uint16_t wrdiv{},quotient{},remainder{},product{},htime{},vtime{}; std::uint32_t wramPortAddr{};
  bool nmiEnable{},vIrqEnable{},hIrqEnable{},autoJoypad{},nmiPending{},irqPending{},vblank{},hblank{},joyStrobe{};
  std::uint16_t joy[4]{},joyShift[2]{};
  void setNmitimen(std::uint8_t v){nmitimen=v;nmiEnable=v&0x80;vIrqEnable=v&0x20;hIrqEnable=v&0x10;autoJoypad=v&1;}
  void multiply(std::uint8_t v){wrmpyb=v;product=(std::uint16_t)(std::uint16_t(wrmpya)*std::uint16_t(wrmpyb));remainder=product;}
  void divide(std::uint8_t v){wrdivb=v;if(v==0){quotient=0xFFFF;remainder=wrdiv;}else{quotient=(std::uint16_t)(wrdiv/v);remainder=(std::uint16_t)(wrdiv%v);}}
  void latchJoy(){joyShift[0]=joy[0];joyShift[1]=joy[1];}
  void setJoyStrobe(bool v){if(v||joyStrobe)latchJoy();joyStrobe=v;}
  std::uint8_t readJoySerial(unsigned p){p&=1;if(joyStrobe)latchJoy();std::uint8_t bit=(joyShift[p]&0x8000u)?1u:0u;if(!joyStrobe)joyShift[p]=(std::uint16_t)((joyShift[p]<<1)|1u);return bit;}
};
struct SpcDsp {
  struct Voice { bool active{}; std::uint16_t addr{},loop{}; std::uint8_t blockPos{16},header{}; std::int16_t hist1{},hist2{}; std::int16_t decoded[16]{}; std::uint32_t phase{}; };
  std::uint8_t regs[128]{}; Voice voice[8]{};
  static std::int16_t clamp16(int v){if(v>32767)return 32767;if(v<-32768)return -32768;return (std::int16_t)v;}
  void writeReg(std::uint8_t a,std::uint8_t v,std::vector<std::uint8_t>&ram){a&=0x7F;regs[a]=v;if(a==0x4C){for(unsigned i=0;i<8;i++)if(v&(1u<<i))keyOn(i,ram);}else if(a==0x5C){for(unsigned i=0;i<8;i++)if(v&(1u<<i))voice[i].active=false;}}
  std::uint8_t readReg(std::uint8_t a)const{return regs[a&0x7F];}
  void keyOn(unsigned i,std::vector<std::uint8_t>&ram){auto&v=voice[i&7u];unsigned base=(unsigned)regs[0x5D]*0x100u+(unsigned)regs[(i<<4)|4]*4u;v.addr=(std::uint16_t)(ram[base&0xFFFFu]|(ram[(base+1)&0xFFFFu]<<8));v.loop=(std::uint16_t)(ram[(base+2)&0xFFFFu]|(ram[(base+3)&0xFFFFu]<<8));v.blockPos=16;v.hist1=v.hist2=0;v.phase=0;v.active=true;}
  void decodeBlock(Voice&v,std::vector<std::uint8_t>&ram){v.header=ram[v.addr];unsigned range=v.header>>4,filter=(v.header>>2)&3;for(unsigned n=0;n<16;n++){std::uint8_t b=ram[(v.addr+1+(n>>1))&0xFFFFu];int nib=(n&1)?(b&0x0F):(b>>4);if(nib&8)nib-=16;int s=(range<=12)?((nib<<range)>>1):(nib<0?-2048:0);if(filter==1)s+=v.hist1+((-v.hist1)>>4);else if(filter==2)s+=(v.hist1<<1)+((-3*v.hist1)>>5)-v.hist2+(v.hist2>>4);else if(filter==3)s+=(v.hist1<<1)+((-13*v.hist1)>>6)-v.hist2+((3*v.hist2)>>4);s=clamp16(s);v.decoded[n]=clamp16(s<<1);v.hist2=v.hist1;v.hist1=v.decoded[n];}v.addr=(std::uint16_t)(v.addr+9);v.blockPos=0;}
  std::int16_t nextSample(unsigned i,std::vector<std::uint8_t>&ram){auto&v=voice[i&7u];if(!v.active)return 0;unsigned pitch=(unsigned)regs[(i<<4)|2]|(((unsigned)regs[(i<<4)|3]&0x3F)<<8);v.phase+=pitch;while(v.phase>=0x1000u){v.phase-=0x1000u;if(v.blockPos>=16){bool end=v.header&1u,looping=v.header&2u;if(end){if(looping){v.addr=v.loop;v.blockPos=16;}else{v.active=false;return 0;}}decodeBlock(v,ram);}else v.blockPos++;}if(v.blockPos>=16)decodeBlock(v,ram);unsigned idx=v.blockPos<16?v.blockPos:15;int env=0x7FF;std::uint8_t adsr1=regs[(i<<4)|5],gain=regs[(i<<4)|7];if(!(adsr1&0x80)&&!(gain&0x80))env=(gain&0x7F)<<4;int s=(int)v.decoded[idx]*env/0x7FF;regs[(i<<4)|9]=(std::uint8_t)(s>>8);return clamp16(s);}
  std::vector<std::int16_t> render(std::vector<std::uint8_t>&ram,unsigned frames){std::vector<std::int16_t>out;out.reserve((std::size_t)frames*2);int mvl=(std::int8_t)regs[0x0C],mvr=(std::int8_t)regs[0x1C];for(unsigned n=0;n<frames;n++){int l=0,r=0;for(unsigned i=0;i<8;i++){int s=nextSample(i,ram);l+=s*(std::int8_t)regs[(i<<4)|0]/127;r+=s*(std::int8_t)regs[(i<<4)|1]/127;}l=l*mvl/127;r=r*mvr/127;out.push_back(clamp16(l));out.push_back(clamp16(r));}return out;}
  static bool saveWav(const std::string&path,const std::vector<std::int16_t>&pcm,unsigned rate=32000){if(pcm.empty())return false;std::ofstream f(path,std::ios::binary);if(!f)return false;auto w16=[&](std::uint16_t v){char b[2]={(char)v,(char)(v>>8)};f.write(b,2);};auto w32=[&](std::uint32_t v){char b[4]={(char)v,(char)(v>>8),(char)(v>>16),(char)(v>>24)};f.write(b,4);};std::uint32_t data=(std::uint32_t)(pcm.size()*2);f.write("RIFF",4);w32(36+data);f.write("WAVEfmt ",8);w32(16);w16(1);w16(2);w32(rate);w32(rate*4);w16(4);w16(16);f.write("data",4);w32(data);f.write((const char*)pcm.data(),data);return(bool)f;}
};
inline constexpr std::uint8_t kForja65Ipl[64] = {
  0xCD,0xEF,0xBD,0xE8,0x00,0xC6,0x1D,0xD0,0xFC,0x8F,0xAA,0xF4,0x8F,0xBB,0xF5,0x78,
  0xCC,0xF4,0xD0,0xFB,0x2F,0x19,0xEB,0xF4,0xD0,0xFC,0x7E,0xF4,0xD0,0x0B,0xE4,0xF5,
  0xCB,0xF4,0xD7,0x00,0xFC,0xD0,0xF3,0xAB,0x01,0x10,0xEF,0x7E,0xF4,0x10,0xEB,0xBA,
  0xF6,0xDA,0x00,0xBA,0xF4,0xC4,0xF4,0xDD,0x5D,0xD0,0xDB,0x1F,0x00,0x00,0xC0,0xFF};
struct SpcStateRuntime {
  std::vector<std::uint8_t> ram=std::vector<std::uint8_t>(65536); std::uint8_t dsp[128]{};
  std::uint16_t pc{0xFFC0},ya{}; std::uint8_t x{},sp{0xEF},psw{},control{0x80},dspAddr{};
  std::uint8_t portIn[4]{},portOut[4]{},timerOut[3]{},timerTarget[3]{}; int timerDiv[3]{},timerStage[3]{}; bool timersOn[3]{};
  std::uint8_t a()const{return(std::uint8_t)(ya&0xFFu);} std::uint8_t y()const{return(std::uint8_t)(ya>>8);}
  void setA(std::uint8_t v){ya=(std::uint16_t)((ya&0xFF00u)|v);} void setY(std::uint8_t v){ya=(std::uint16_t)((ya&0x00FFu)|(std::uint16_t(v)<<8));}
};
struct ApuBridge {
  using NativeStepHook=void(*)(ApuBridge&,unsigned);
  SpcStateRuntime spc; SpcDsp dsp; bool dirty[4]{}; NativeStepHook nativeStepHook{};
  bool transferStarted{},nativeDspEnabled{}; std::uint16_t uploadBase{},lastPorts23{},entryCandidate{}; std::size_t uploadCount{}; std::uint8_t lastCounter{},keyOn{},keyOff{}; std::uint64_t spcMasterRemainder{},nativeMasterCycles{},fallbackMasterCycles{},dspMasterRemainder{},dspNativeSamples{},dspFallbackSamples{}; std::vector<std::int16_t> nativePcm;
  static constexpr unsigned DSP_SAMPLE_MASTER_CYCLES=671u;
  void setNativeStepHook(NativeStepHook fn){nativeStepHook=fn;} bool nativeBackendReady()const{return nativeStepHook!=nullptr;} bool nativeDspReady()const{return nativeDspEnabled;}
  void setNativeDsp(bool on){nativeDspEnabled=on;}
  void tickDspMasterCycles(unsigned masterCycles){dspMasterRemainder+=masterCycles;while(dspMasterRemainder>=DSP_SAMPLE_MASTER_CYCLES){dspMasterRemainder-=DSP_SAMPLE_MASTER_CYCLES;if(!nativeDspEnabled){dspFallbackSamples++;continue;}auto q=dsp.render(spc.ram,1);if(q.size()==2){nativePcm.push_back(q[0]);nativePcm.push_back(q[1]);dspNativeSamples++;}}}
  bool saveNativeAudioWav(const std::string&path)const{return SpcDsp::saveWav(path,nativePcm,32000);}
  void write(unsigned i,std::uint8_t v){if(i>=4)return;spc.portIn[i]=v;dirty[i]=true;if(i==2||i==3)lastPorts23=(std::uint16_t)(spc.portIn[2]|(spc.portIn[3]<<8));if(i==0){if(!transferStarted){transferStarted=true;uploadBase=lastPorts23;uploadCount=0;}if(v!=lastCounter||uploadCount==0){uploadCount++;if(spc.portIn[1]==0)entryCandidate=lastPorts23;}lastCounter=v;}}
  std::uint8_t read(unsigned i)const{return i<4?spc.portOut[i]:0;}
  std::uint8_t spcRead(std::uint16_t a){if(a>=0xFFC0u&&(spc.control&0x80u))return kForja65Ipl[a-0xFFC0u];if(a==0xF2)return spc.dspAddr;if(a==0xF3)return dsp.readReg(spc.dspAddr);if(a>=0xF4&&a<=0xF7)return spc.portIn[a-0xF4];return spc.ram[a];}
  void spcWrite(std::uint16_t a,std::uint8_t v){if(a==0xF1){if(v&0x10){spc.portIn[0]=spc.portIn[1]=0;}if(v&0x20){spc.portIn[2]=spc.portIn[3]=0;}spc.control=v;for(int i=0;i<3;i++)spc.timersOn[i]=(v&(1u<<i))!=0;return;}if(a==0xF2){spc.dspAddr=v;return;}if(a==0xF3){spc.dsp[spc.dspAddr&0x7Fu]=v;dsp.writeReg(spc.dspAddr,v,spc.ram);return;}if(a>=0xF4&&a<=0xF7){spc.portOut[a-0xF4]=v;spc.ram[a]=v;return;}if(a>=0xFA&&a<=0xFC){spc.timerTarget[a-0xFA]=v;return;}spc.ram[a]=v;}
  void tickMasterCycles(unsigned masterCycles);
  bool saveDump(const std::string&path)const{if(!uploadCount)return false;std::ofstream f(path,std::ios::binary);if(!f)return false;f.write((const char*)spc.ram.data(),(std::streamsize)spc.ram.size());return(bool)f;}
  bool saveSnapshot(const std::string&binPath,const std::string&manifestPath)const{std::ofstream b(binPath,std::ios::binary|std::ios::trunc);if(!b)return false;b.write((const char*)spc.ram.data(),(std::streamsize)spc.ram.size());b.close();std::ofstream f(manifestPath,std::ios::trunc);if(!f)return false;f<<"entry=0x"<<std::hex<<spc.pc<<"\\n"<<"pc=0x"<<spc.pc<<"\\n"<<"a=0x"<<(unsigned)spc.a()<<"\\n"<<"x=0x"<<(unsigned)spc.x<<"\\n"<<"y=0x"<<(unsigned)spc.y()<<"\\n"<<"sp=0x"<<(unsigned)spc.sp<<"\\n"<<"psw=0x"<<(unsigned)spc.psw<<"\\n"<<"upload_base=0x"<<uploadBase<<"\\n"<<"upload_count="<<std::dec<<uploadCount<<"\\n"<<"entry_candidate=0x"<<std::hex<<entryCandidate<<"\\n"<<"native_backend_ready="<<(nativeBackendReady()?1:0)<<"\\n";return(bool)f;}
  bool saveManifest(const std::string&path)const{if(!uploadCount)return false;std::ofstream f(path);if(!f)return false;f<<"upload_base=0x"<<std::hex<<uploadBase<<"\\n"<<"upload_count="<<std::dec<<uploadCount<<"\\n"<<"entry_candidate=0x"<<std::hex<<entryCandidate<<"\\n"<<"dsp_backend=BRR_BASIC_8VOICE\\n"<<"dsp_native_clock="<<(nativeDspReady()?1:0)<<"\\n"<<"dsp_native_samples="<<dspNativeSamples<<"\\n"<<"spc700_runtime=FULL_INTERPRETER_256_OPCODES\\n"<<"native_hook_ready="<<(nativeBackendReady()?1:0)<<"\\n"<<"cpu_port_shadow_write=DISABLED_HARDWARE_CORRECT\\n";return(bool)f;}
};

static constexpr std::uint8_t CN=0x80,CV=0x40,CP=0x20,CB=0x10,CH=0x08,CI=0x04,CZ=0x02,CC=0x01;
static std::uint8_t sa(const ApuBridge& s) { return s.spc.a(); }
static void sZN(ApuBridge& s, std::uint8_t v) { s.spc.psw = (s.spc.psw & ~(CN | CZ)) | (v & CN) | (v ? 0 : CZ); }
static std::uint16_t sdp(const ApuBridge& s) { return (s.spc.psw & CP) ? 0x100 : 0; }

static std::uint8_t sr(ApuBridge& s, std::uint16_t a) {
    if (a >= 0xFFC0 && (s.spc.control & 0x80)) return kForja65Ipl[a - 0xFFC0];
    if (a >= 0xF0 && a <= 0xFF) {
        switch (a) {
        case 0xF2: return s.spc.dspAddr;
        case 0xF3: return s.dsp.readReg(s.spc.dspAddr);
        case 0xF4: case 0xF5: case 0xF6: case 0xF7: return s.spc.portIn[a - 0xF4];
        case 0xFD: case 0xFE: case 0xFF: {
            int i = a - 0xFD;
            if ((s.spc.timerOut[i] & 0x0F) == 0) s.spc.timerOut[i] = 1;
            std::uint8_t v = s.spc.timerOut[i] & 0x0F; s.spc.timerOut[i] = 0; return v;
        }
        default: return s.spc.ram[a];
        }
    }
    return s.spc.ram[a];
}
static void sw(ApuBridge& s, std::uint16_t a, std::uint8_t v) {
    if (a >= 0xF0 && a <= 0xFF) {
        switch (a) {
        case 0xF1:
            if (v & 0x10) { s.spc.portIn[0] = s.spc.portIn[1] = 0; }
            if (v & 0x20) { s.spc.portIn[2] = s.spc.portIn[3] = 0; }
            s.spc.control = v;
            for (int i = 0; i < 3; i++) s.spc.timersOn[i] = (v & (1 << i)) != 0;
            return;
        case 0xF2: s.spc.dspAddr = v; return;
        case 0xF3:
            s.spc.dsp[s.spc.dspAddr & 0x7F] = v; s.dsp.writeReg(s.spc.dspAddr, v, s.spc.ram);
            if ((s.spc.dspAddr & 0x7F) == 0x4C) s.keyOn = v;
            if ((s.spc.dspAddr & 0x7F) == 0x5C) s.keyOff = v;
            return;
        case 0xF4: case 0xF5: case 0xF6: case 0xF7: s.spc.portOut[a - 0xF4] = v; s.spc.ram[a] = v; return;
        case 0xFA: case 0xFB: case 0xFC: s.spc.timerTarget[a - 0xFA] = v; return;
        default: break;
        }
    }
    s.spc.ram[a] = v;
}
static std::uint16_t sr16(ApuBridge& s, std::uint16_t a) { return sr(s, a) | (std::uint16_t(sr(s, std::uint16_t(a + 1))) << 8); }
static void sw16(ApuBridge& s, std::uint16_t a, std::uint16_t v) { sw(s, a, v & 0xFF); sw(s, std::uint16_t(a + 1), v >> 8); }
static std::uint8_t sf(ApuBridge& s) { return sr(s, s.spc.pc++); }
static std::uint16_t sf16(ApuBridge& s) { std::uint8_t l = sf(s); return l | (std::uint16_t(sf(s)) << 8); }
static void spush(ApuBridge& s, std::uint8_t v) { sw(s, 0x100 | s.spc.sp, v); s.spc.sp--; }
static std::uint8_t spull(ApuBridge& s) { s.spc.sp++; return sr(s, 0x100 | s.spc.sp); }
static std::uint16_t ya(const ApuBridge& s) { return s.spc.ya; }
static void setYa(ApuBridge& s, std::uint16_t v) { s.spc.ya = v; }

static void adc(ApuBridge& s, std::uint8_t v) {
    int c = (s.spc.psw & CC) ? 1 : 0, a = sa(s), sum = a + v + c;
    s.spc.psw = (s.spc.psw & ~CH) | (((a & 15) + (v & 15) + c > 15) ? CH : 0);
    s.spc.psw = (s.spc.psw & ~CV) | ((~(a ^ v) & (a ^ sum) & 0x80) ? CV : 0);
    s.spc.psw = (s.spc.psw & ~CC) | (sum > 255 ? CC : 0);
    s.spc.setA(sum & 255); sZN(s, s.spc.a());
}
static void sbc(ApuBridge& s, std::uint8_t v) {
    int c = (s.spc.psw & CC) ? 1 : 0, a = sa(s), sum = a - v - (1 - c);
    s.spc.psw = (s.spc.psw & ~CH) | (((a & 15) - (v & 15) - (1 - c) < 0) ? 0 : CH);
    s.spc.psw = (s.spc.psw & ~CV) | (((a ^ v) & (a ^ sum) & 0x80) ? CV : 0);
    s.spc.psw = (s.spc.psw & ~CC) | (sum >= 0 ? CC : 0);
    s.spc.setA(sum & 255); sZN(s, s.spc.a());
}
static void cmp(ApuBridge& s, std::uint8_t a, std::uint8_t b) { s.spc.psw = (s.spc.psw & ~CC) | (a >= b ? CC : 0); sZN(s, std::uint8_t(a - b)); }
static void logicMem(ApuBridge& s, std::uint16_t addr, std::uint8_t b, int kind) {
    std::uint8_t m = sr(s, addr), r = kind == 0 ? (m | b) : kind == 1 ? (m & b) : kind == 2 ? (m ^ b) : std::uint8_t(m - b);
    if (kind == 3) cmp(s, m, b); else { sw(s, addr, r); sZN(s, r); }
}

inline int forja65SpcStep(ApuBridge& s) {
    std::uint8_t op = sf(s);
    auto dp = [&]() { return std::uint16_t(sdp(s) + sf(s)); };
    auto dpx = [&]() { return std::uint16_t(sdp(s) + std::uint8_t(sf(s) + s.spc.x)); };
    auto dpy = [&]() { return std::uint16_t(sdp(s) + std::uint8_t(sf(s) + s.spc.y())); };
    auto absx = [&]() { return std::uint16_t(sf16(s) + s.spc.x); };
    auto absy = [&]() { return std::uint16_t(sf16(s) + s.spc.y()); };
    auto ix = [&]() { return std::uint16_t(s.spc.x); };
    auto idpx = [&]() { return sr16(s, std::uint16_t(sdp(s) + std::uint8_t(sf(s) + s.spc.x))); };
    auto idpy = [&]() { return std::uint16_t(sr16(s, dp()) + s.spc.y()); };
    auto bitAddr = [&]() { std::uint16_t a = sf16(s); return std::pair<std::uint16_t, int>(a & 0x1FFF, a >> 13); };
    switch (op) {
    case 0x00: break;
    case 0x01: case 0x11: case 0x21: case 0x31: case 0x41: case 0x51: case 0x61: case 0x71:
    case 0x81: case 0x91: case 0xA1: case 0xB1: case 0xC1: case 0xD1: case 0xE1: case 0xF1: {
        int n = op >> 4; spush(s, s.spc.pc >> 8); spush(s, s.spc.pc & 0xFF);
        s.spc.pc = sr16(s, 0xFFDE - n * 2); break; }
    case 0x02: case 0x22: case 0x42: case 0x62: case 0x82: case 0xA2: case 0xC2: case 0xE2: { std::uint16_t a = dp(); sw(s, a, sr(s, a) | (1 << (op >> 5))); break; }
    case 0x12: case 0x32: case 0x52: case 0x72: case 0x92: case 0xB2: case 0xD2: case 0xF2: { std::uint16_t a = dp(); sw(s, a, sr(s, a) & ~(1 << ((op >> 5) & 7))); break; }
    case 0x03: case 0x23: case 0x43: case 0x63: case 0x83: case 0xA3: case 0xC3: case 0xE3: { std::uint16_t a = dp(); std::int8_t r = sf(s); if (sr(s, a) & (1 << (op >> 5))) s.spc.pc += r; break; }
    case 0x13: case 0x33: case 0x53: case 0x73: case 0x93: case 0xB3: case 0xD3: case 0xF3: { std::uint16_t a = dp(); std::int8_t r = sf(s); if (!(sr(s, a) & (1 << ((op >> 5) & 7)))) s.spc.pc += r; break; }
    case 0x04: s.spc.setA(sa(s) | sr(s, dp())); sZN(s, sa(s)); break;
    case 0x05: s.spc.setA(sa(s) | sr(s, sf16(s))); sZN(s, sa(s)); break;
    case 0x06: s.spc.setA(sa(s) | sr(s, ix())); sZN(s, sa(s)); break;
    case 0x07: s.spc.setA(sa(s) | sr(s, idpx())); sZN(s, sa(s)); break;
    case 0x08: s.spc.setA(sa(s) | sf(s)); sZN(s, sa(s)); break;
    case 0x09: { std::uint16_t d = dp(), src = dp(); logicMem(s, d, sr(s, src), 0); break; }
    case 0x0A: { auto [a, b] = bitAddr(); if (sr(s, a) & (1 << b)) s.spc.psw |= CC; break; }
    case 0x0B: { std::uint16_t a = dp(); std::uint8_t v = sr(s, a); s.spc.psw = (s.spc.psw & ~CC) | (v >> 7); v <<= 1; sw(s, a, v); sZN(s, v); break; }
    case 0x0C: { std::uint16_t a = sf16(s); std::uint8_t v = sr(s, a); s.spc.psw = (s.spc.psw & ~CC) | (v >> 7); v <<= 1; sw(s, a, v); sZN(s, v); break; }
    case 0x0D: spush(s, s.spc.psw); break;
    case 0x0E: { std::uint16_t a = sf16(s); std::uint8_t m = sr(s, a); sZN(s, sa(s) & m); sw(s, a, m | sa(s)); break; }
    case 0x0F: spush(s, s.spc.pc >> 8); spush(s, s.spc.pc & 0xFF); spush(s, s.spc.psw); s.spc.psw |= CI | CB; s.spc.pc = sr16(s, 0xFFDE); break;
    case 0x10: { std::int8_t r = sf(s); if (!(s.spc.psw & CN)) s.spc.pc += r; break; }
    case 0x14: s.spc.setA(sa(s) | sr(s, dpx())); sZN(s, sa(s)); break;
    case 0x15: s.spc.setA(sa(s) | sr(s, absx())); sZN(s, sa(s)); break;
    case 0x16: s.spc.setA(sa(s) | sr(s, absy())); sZN(s, sa(s)); break;
    case 0x17: s.spc.setA(sa(s) | sr(s, idpy())); sZN(s, sa(s)); break;
    case 0x18: { std::uint8_t imm = sf(s); std::uint16_t a = dp(); std::uint8_t v = sr(s, a) | imm; sw(s, a, v); sZN(s, v); break; }
    case 0x19: { std::uint8_t v = sr(s, s.spc.x) | sr(s, s.spc.y()); sw(s, s.spc.x, v); sZN(s, v); break; }
    case 0x1A: { std::uint16_t a = dp(); std::uint16_t v = sr16(s, a) - 1; sw16(s, a, v); sZN(s, v >> 8); s.spc.psw = (s.spc.psw & ~CZ) | (v ? 0 : CZ); break; }
    case 0x1B: { std::uint16_t a = dpx(); std::uint8_t v = sr(s, a); s.spc.psw = (s.spc.psw & ~CC) | (v >> 7); v <<= 1; sw(s, a, v); sZN(s, v); break; }
    case 0x1C: { std::uint8_t v = sa(s); s.spc.psw = (s.spc.psw & ~CC) | (v >> 7); s.spc.setA(v << 1); sZN(s, sa(s)); break; }
    case 0x1D: s.spc.x--; sZN(s, s.spc.x); break;
    case 0x1E: cmp(s, s.spc.x, sr(s, sf16(s))); break;
    case 0x1F: s.spc.pc = sr16(s, std::uint16_t(sf16(s) + s.spc.x)); break;
    case 0x20: s.spc.psw &= ~CP; break;
    case 0x24: s.spc.setA(sa(s) & sr(s, dp())); sZN(s, sa(s)); break;
    case 0x25: s.spc.setA(sa(s) & sr(s, sf16(s))); sZN(s, sa(s)); break;
    case 0x26: s.spc.setA(sa(s) & sr(s, ix())); sZN(s, sa(s)); break;
    case 0x27: s.spc.setA(sa(s) & sr(s, idpx())); sZN(s, sa(s)); break;
    case 0x28: s.spc.setA(sa(s) & sf(s)); sZN(s, sa(s)); break;
    case 0x29: { std::uint16_t d = dp(), src = dp(); logicMem(s, d, sr(s, src), 1); break; }
    case 0x2A: { auto [a, b] = bitAddr(); if (!(sr(s, a) & (1 << b))) s.spc.psw |= CC; break; }
    case 0x2B: { std::uint16_t a = dp(); std::uint8_t v = sr(s, a); int c = s.spc.psw & CC ? 1 : 0; s.spc.psw = (s.spc.psw & ~CC) | (v >> 7); v = (v << 1) | c; sw(s, a, v); sZN(s, v); break; }
    case 0x2C: { std::uint16_t a = sf16(s); std::uint8_t v = sr(s, a); int c = s.spc.psw & CC ? 1 : 0; s.spc.psw = (s.spc.psw & ~CC) | (v >> 7); v = (v << 1) | c; sw(s, a, v); sZN(s, v); break; }
    case 0x2D: spush(s, sa(s)); break;
    case 0x2E: { std::uint16_t a = dp(); std::int8_t r = sf(s); if (sr(s, a) != sa(s)) s.spc.pc += r; break; }
    case 0x2F: { std::int8_t r = sf(s); s.spc.pc += r; break; }
    case 0x30: { std::int8_t r = sf(s); if (s.spc.psw & CN) s.spc.pc += r; break; }
    case 0x34: s.spc.setA(sa(s) & sr(s, dpx())); sZN(s, sa(s)); break;
    case 0x35: s.spc.setA(sa(s) & sr(s, absx())); sZN(s, sa(s)); break;
    case 0x36: s.spc.setA(sa(s) & sr(s, absy())); sZN(s, sa(s)); break;
    case 0x37: s.spc.setA(sa(s) & sr(s, idpy())); sZN(s, sa(s)); break;
    case 0x38: { std::uint8_t imm = sf(s); std::uint16_t a = dp(); std::uint8_t v = sr(s, a) & imm; sw(s, a, v); sZN(s, v); break; }
    case 0x39: { std::uint8_t v = sr(s, s.spc.x) & sr(s, s.spc.y()); sw(s, s.spc.x, v); sZN(s, v); break; }
    case 0x3A: { std::uint16_t a = dp(); std::uint16_t v = sr16(s, a) + 1; sw16(s, a, v); s.spc.psw = (s.spc.psw & ~(CN | CZ)) | ((v >> 8) & CN) | (v ? 0 : CZ); break; }
    case 0x3B: { std::uint16_t a = dpx(); std::uint8_t v = sr(s, a); int c = s.spc.psw & CC ? 1 : 0; s.spc.psw = (s.spc.psw & ~CC) | (v >> 7); v = (v << 1) | c; sw(s, a, v); sZN(s, v); break; }
    case 0x3C: { std::uint8_t v = sa(s); int c = s.spc.psw & CC ? 1 : 0; s.spc.psw = (s.spc.psw & ~CC) | (v >> 7); s.spc.setA((v << 1) | c); sZN(s, sa(s)); break; }
    case 0x3D: s.spc.x++; sZN(s, s.spc.x); break;
    case 0x3E: cmp(s, s.spc.x, sr(s, dp())); break;
    case 0x3F: { std::uint16_t t = sf16(s); spush(s, s.spc.pc >> 8); spush(s, s.spc.pc & 0xFF); s.spc.pc = t; break; }
    case 0x40: s.spc.psw |= CP; break;
    case 0x44: s.spc.setA(sa(s) ^ sr(s, dp())); sZN(s, sa(s)); break;
    case 0x45: s.spc.setA(sa(s) ^ sr(s, sf16(s))); sZN(s, sa(s)); break;
    case 0x46: s.spc.setA(sa(s) ^ sr(s, ix())); sZN(s, sa(s)); break;
    case 0x47: s.spc.setA(sa(s) ^ sr(s, idpx())); sZN(s, sa(s)); break;
    case 0x48: s.spc.setA(sa(s) ^ sf(s)); sZN(s, sa(s)); break;
    case 0x49: { std::uint16_t d = dp(), src = dp(); logicMem(s, d, sr(s, src), 2); break; }
    case 0x4A: { auto [a, b] = bitAddr(); if (!(sr(s, a) & (1 << b))) s.spc.psw &= ~CC; break; }
    case 0x4B: { std::uint16_t a = dp(); std::uint8_t v = sr(s, a); s.spc.psw = (s.spc.psw & ~CC) | (v & 1); v >>= 1; sw(s, a, v); sZN(s, v); break; }
    case 0x4C: { std::uint16_t a = sf16(s); std::uint8_t v = sr(s, a); s.spc.psw = (s.spc.psw & ~CC) | (v & 1); v >>= 1; sw(s, a, v); sZN(s, v); break; }
    case 0x4D: spush(s, s.spc.x); break;
    case 0x4E: { std::uint16_t a = sf16(s); std::uint8_t m = sr(s, a); sZN(s, sa(s) & m); sw(s, a, m & ~sa(s)); break; }
    case 0x4F: { std::uint8_t n = sf(s); spush(s, s.spc.pc >> 8); spush(s, s.spc.pc & 0xFF); s.spc.pc = 0xFF00 | n; break; }
    case 0x50: { std::int8_t r = sf(s); if (!(s.spc.psw & CV)) s.spc.pc += r; break; }
    case 0x54: s.spc.setA(sa(s) ^ sr(s, dpx())); sZN(s, sa(s)); break;
    case 0x55: s.spc.setA(sa(s) ^ sr(s, absx())); sZN(s, sa(s)); break;
    case 0x56: s.spc.setA(sa(s) ^ sr(s, absy())); sZN(s, sa(s)); break;
    case 0x57: s.spc.setA(sa(s) ^ sr(s, idpy())); sZN(s, sa(s)); break;
    case 0x58: { std::uint8_t imm = sf(s); std::uint16_t a = dp(); std::uint8_t v = sr(s, a) ^ imm; sw(s, a, v); sZN(s, v); break; }
    case 0x59: { std::uint8_t v = sr(s, s.spc.x) ^ sr(s, s.spc.y()); sw(s, s.spc.x, v); sZN(s, v); break; }
    case 0x5A: { std::uint16_t a = dp(); std::uint16_t m = sr16(s, a); s.spc.psw = (s.spc.psw & ~CC) | (ya(s) >= m ? CC : 0); std::uint16_t r = ya(s) - m; s.spc.psw = (s.spc.psw & ~(CN | CZ)) | ((r >> 8) & CN) | (r ? 0 : CZ); break; }
    case 0x5B: { std::uint16_t a = dpx(); std::uint8_t v = sr(s, a); s.spc.psw = (s.spc.psw & ~CC) | (v & 1); v >>= 1; sw(s, a, v); sZN(s, v); break; }
    case 0x5C: { std::uint8_t v = sa(s); s.spc.psw = (s.spc.psw & ~CC) | (v & 1); s.spc.setA(v >> 1); sZN(s, sa(s)); break; }
    case 0x5D: s.spc.x = sa(s); sZN(s, s.spc.x); break;
    case 0x5E: cmp(s, s.spc.y(), sr(s, sf16(s))); break;
    case 0x5F: s.spc.pc = sf16(s); break;
    case 0x60: s.spc.psw &= ~CC; break;
    case 0x64: cmp(s, sa(s), sr(s, dp())); break;
    case 0x65: cmp(s, sa(s), sr(s, sf16(s))); break;
    case 0x66: cmp(s, sa(s), sr(s, ix())); break;
    case 0x67: cmp(s, sa(s), sr(s, idpx())); break;
    case 0x68: cmp(s, sa(s), sf(s)); break;
    case 0x69: { std::uint16_t d = dp(); cmp(s, sr(s, d), sr(s, dp())); break; }
    case 0x6A: { auto [a, b] = bitAddr(); if (sr(s, a) & (1 << b)) {} else s.spc.psw &= ~CC; break; }
    case 0x6B: { std::uint16_t a = dp(); std::uint8_t v = sr(s, a); int c = s.spc.psw & CC ? 1 : 0; s.spc.psw = (s.spc.psw & ~CC) | (v & 1); v = (v >> 1) | (c << 7); sw(s, a, v); sZN(s, v); break; }
    case 0x6C: { std::uint16_t a = sf16(s); std::uint8_t v = sr(s, a); int c = s.spc.psw & CC ? 1 : 0; s.spc.psw = (s.spc.psw & ~CC) | (v & 1); v = (v >> 1) | (c << 7); sw(s, a, v); sZN(s, v); break; }
    case 0x6D: spush(s, s.spc.y()); break;
    case 0x6E: { std::uint16_t a = dp(); std::int8_t r = sf(s); std::uint8_t v = sr(s, a) - 1; sw(s, a, v); if (v) s.spc.pc += r; break; }
    case 0x6F: { std::uint8_t l = spull(s); s.spc.pc = l | (std::uint16_t(spull(s)) << 8); break; }
    case 0x70: { std::int8_t r = sf(s); if (s.spc.psw & CV) s.spc.pc += r; break; }
    case 0x74: cmp(s, sa(s), sr(s, dpx())); break;
    case 0x75: cmp(s, sa(s), sr(s, absx())); break;
    case 0x76: cmp(s, sa(s), sr(s, absy())); break;
    case 0x77: cmp(s, sa(s), sr(s, idpy())); break;
    case 0x78: { std::uint8_t imm = sf(s); std::uint16_t a = dp(); cmp(s, sr(s, a), imm); break; }
    case 0x79: cmp(s, sr(s, s.spc.x), sr(s, s.spc.y())); break;
    case 0x7A: { std::uint16_t a = dp(); uint32_t r = ya(s) + sr16(s, a); s.spc.psw = (s.spc.psw & ~CC) | (r > 0xFFFF ? CC : 0); s.spc.psw = (s.spc.psw & ~CV) | (((~(ya(s) ^ sr16(s, a)) & (ya(s) ^ r) & 0x8000)) ? CV : 0); setYa(s, r & 0xFFFF); s.spc.psw = (s.spc.psw & ~(CN | CZ)) | ((r >> 8) & CN) | (r & 0xFFFF ? 0 : CZ); break; }
    case 0x7B: { std::uint16_t a = dpx(); std::uint8_t v = sr(s, a); int c = s.spc.psw & CC ? 1 : 0; s.spc.psw = (s.spc.psw & ~CC) | (v & 1); v = (v >> 1) | (c << 7); sw(s, a, v); sZN(s, v); break; }
    case 0x7C: { std::uint8_t v = sa(s); int c = s.spc.psw & CC ? 1 : 0; s.spc.psw = (s.spc.psw & ~CC) | (v & 1); s.spc.setA((v >> 1) | (c << 7)); sZN(s, sa(s)); break; }
    case 0x7D: s.spc.setA(s.spc.x); sZN(s, sa(s)); break;
    case 0x7E: cmp(s, s.spc.y(), sr(s, dp())); break;
    case 0x7F: { s.spc.psw = spull(s); std::uint8_t l = spull(s); s.spc.pc = l | (std::uint16_t(spull(s)) << 8); break; }
    case 0x80: s.spc.psw |= CC; break;
    case 0x84: adc(s, sr(s, dp())); break;
    case 0x85: adc(s, sr(s, sf16(s))); break;
    case 0x86: adc(s, sr(s, ix())); break;
    case 0x87: adc(s, sr(s, idpx())); break;
    case 0x88: adc(s, sf(s)); break;
    case 0x89: { std::uint8_t imm = sf(s); std::uint16_t a = dp(); std::uint8_t m = sr(s, a); int sum = m + imm; sw(s, a, sum & 255); sZN(s, sum & 255); break; }
    case 0x8A: { auto [a, b] = bitAddr(); bool bit = sr(s, a) & (1 << b); bool c = s.spc.psw & CC; s.spc.psw = (s.spc.psw & ~CC) | ((c ^ bit) ? CC : 0); break; }
    case 0x8B: { std::uint16_t a = dp(); std::uint8_t v = sr(s, a) - 1; sw(s, a, v); sZN(s, v); break; }
    case 0x8C: { std::uint16_t a = sf16(s); std::uint8_t v = sr(s, a) - 1; sw(s, a, v); sZN(s, v); break; }
    case 0x8D: s.spc.setY(sf(s)); sZN(s, s.spc.y()); break;
    case 0x8E: s.spc.psw = spull(s); break;
    case 0x8F: { std::uint8_t v = sf(s); sw(s, dp(), v); break; }
    case 0x90: { std::int8_t r = sf(s); if (!(s.spc.psw & CC)) s.spc.pc += r; break; }
    case 0x94: adc(s, sr(s, dpx())); break;
    case 0x95: adc(s, sr(s, absx())); break;
    case 0x96: adc(s, sr(s, absy())); break;
    case 0x97: adc(s, sr(s, idpy())); break;
    case 0x98: { std::uint16_t d = dp(); adc(s, sr(s, dp())); (void)d; break; }
    case 0x99: adc(s, sr(s, s.spc.y())); sw(s, s.spc.x, sa(s)); break;
    case 0x9A: { std::uint16_t a = dp(); std::uint16_t m = sr16(s, a); int r = ya(s) - m; s.spc.psw = (s.spc.psw & ~CC) | (ya(s) >= m ? CC : 0); setYa(s, r & 0xFFFF); s.spc.psw = (s.spc.psw & ~(CN | CZ)) | ((r >> 8) & CN) | ((r & 0xFFFF) ? 0 : CZ); break; }
    case 0x9B: { std::uint16_t a = dpx(); std::uint8_t v = sr(s, a) - 1; sw(s, a, v); sZN(s, v); break; }
    case 0x9C: s.spc.setA(sa(s) - 1); sZN(s, sa(s)); break;
    case 0x9D: s.spc.x = s.spc.sp; sZN(s, s.spc.x); break;
    case 0x9E: { uint32_t yv = ya(s); std::uint8_t x = s.spc.x ? s.spc.x : 1; s.spc.setA(yv / x); s.spc.setY(yv % x); sZN(s, sa(s)); s.spc.psw = (s.spc.psw & ~CV) | (s.spc.x == 0 ? CV : 0); break; }
    case 0x9F: { std::uint8_t v = sa(s); v = (v << 4) | (v >> 4); s.spc.setA(v); sZN(s, v); break; }
    case 0xA0: s.spc.psw |= CI; break;
    case 0xA4: sbc(s, sr(s, dp())); break;
    case 0xA5: sbc(s, sr(s, sf16(s))); break;
    case 0xA6: sbc(s, sr(s, ix())); break;
    case 0xA7: sbc(s, sr(s, idpx())); break;
    case 0xA8: sbc(s, sf(s)); break;
    case 0xA9: { std::uint16_t d = dp(), src = dp(); std::uint8_t m = sr(s, d); sbc(s, sr(s, src)); sw(s, d, sa(s)); s.spc.setA(m); break; }
    case 0xAA: { auto [a, b] = bitAddr(); s.spc.psw = (s.spc.psw & ~CC) | ((sr(s, a) & (1 << b)) ? CC : 0); break; }
    case 0xAB: { std::uint16_t a = dp(); std::uint8_t v = sr(s, a) + 1; sw(s, a, v); sZN(s, v); break; }
    case 0xAC: { std::uint16_t a = sf16(s); std::uint8_t v = sr(s, a) + 1; sw(s, a, v); sZN(s, v); break; }
    case 0xAD: cmp(s, s.spc.y(), sf(s)); break;
    case 0xAE: s.spc.setA(spull(s)); sZN(s, sa(s)); break;
    case 0xAF: sw(s, s.spc.x++, sa(s)); break;
    case 0xB0: { std::int8_t r = sf(s); if (s.spc.psw & CC) s.spc.pc += r; break; }
    case 0xB4: sbc(s, sr(s, dpx())); break;
    case 0xB5: sbc(s, sr(s, absx())); break;
    case 0xB6: sbc(s, sr(s, absy())); break;
    case 0xB7: sbc(s, sr(s, idpy())); break;
    case 0xB8: { std::uint8_t imm = sf(s); std::uint16_t a = dp(); std::uint8_t m = sr(s, a); int c = s.spc.psw & CC ? 1 : 0; int sum = m - imm - (1 - c); sw(s, a, sum & 255); s.spc.psw = (s.spc.psw & ~CC) | (sum >= 0 ? CC : 0); sZN(s, sum & 255); break; }
    case 0xB9: sbc(s, sr(s, s.spc.y())); sw(s, s.spc.x, sa(s)); break;
    case 0xBA: { std::uint16_t a = dp(); setYa(s, sr16(s, a)); s.spc.psw = (s.spc.psw & ~(CN | CZ)) | ((ya(s) >> 8) & CN) | (ya(s) ? 0 : CZ); break; }
    case 0xBB: { std::uint16_t a = dpx(); std::uint8_t v = sr(s, a) + 1; sw(s, a, v); sZN(s, v); break; }
    case 0xBC: s.spc.setA(sa(s) + 1); sZN(s, sa(s)); break;
    case 0xBD: s.spc.sp = s.spc.x; break;
    case 0xBE: { int a = sa(s); if (!(s.spc.psw & CC) || a > 0x99) { a -= 0x60; s.spc.psw &= ~CC; } else s.spc.psw |= CC; if (!(s.spc.psw & CH) || (a & 15) > 9) a -= 6; s.spc.setA(a & 255); sZN(s, sa(s)); break; }
    case 0xBF: s.spc.setA(sr(s, s.spc.x++)); sZN(s, sa(s)); break;
    case 0xC0: s.spc.psw &= ~CI; break;
    case 0xC4: sw(s, dp(), sa(s)); break;
    case 0xC5: sw(s, sf16(s), sa(s)); break;
    case 0xC6: sw(s, s.spc.x, sa(s)); break;
    case 0xC7: sw(s, idpx(), sa(s)); break;
    case 0xC8: cmp(s, s.spc.x, sf(s)); break;
    case 0xC9: sw(s, sf16(s), s.spc.x); break;
    case 0xCA: { auto [a, b] = bitAddr(); std::uint8_t m = sr(s, a); if (s.spc.psw & CC) m |= 1 << b; else m &= ~(1 << b); sw(s, a, m); break; }
    case 0xCB: sw(s, dp(), s.spc.y()); break;
    case 0xCC: sw(s, sf16(s), s.spc.y()); break;
    case 0xCD: s.spc.x = sf(s); sZN(s, s.spc.x); break;
    case 0xCE: s.spc.x = spull(s); sZN(s, s.spc.x); break;
    case 0xCF: setYa(s, std::uint16_t(s.spc.y()) * sa(s)); s.spc.psw = (s.spc.psw & ~(CN | CZ)) | ((ya(s) >> 8) & CN) | (ya(s) ? 0 : CZ); break;
    case 0xD0: { std::int8_t r = sf(s); if (!(s.spc.psw & CZ)) s.spc.pc += r; break; }
    case 0xD4: sw(s, dpx(), sa(s)); break;
    case 0xD5: sw(s, absx(), sa(s)); break;
    case 0xD6: sw(s, absy(), sa(s)); break;
    case 0xD7: sw(s, idpy(), sa(s)); break;
    case 0xD8: sw(s, dp(), s.spc.x); break;
    case 0xD9: sw(s, dpy(), s.spc.x); break;
    case 0xDA: sw16(s, dp(), ya(s)); break;
    case 0xDB: sw(s, dpx(), s.spc.y()); break;
    case 0xDC: s.spc.setY(s.spc.y() - 1); sZN(s, s.spc.y()); break;
    case 0xDD: s.spc.setA(s.spc.y()); sZN(s, sa(s)); break;
    case 0xDE: { std::uint16_t a = dpx(); std::int8_t r = sf(s); if (sr(s, a) != sa(s)) s.spc.pc += r; break; }
    case 0xDF: { std::uint8_t v = sa(s); if (s.spc.psw & CC || v > 0x99) { v += 0x60; s.spc.psw |= CC; } if (s.spc.psw & CH || (v & 15) > 9) v += 6; s.spc.setA(v); sZN(s, v); break; }
    case 0xE0: s.spc.psw &= ~(CV | CH); break;
    case 0xE4: s.spc.setA(sr(s, dp())); sZN(s, sa(s)); break;
    case 0xE5: s.spc.setA(sr(s, sf16(s))); sZN(s, sa(s)); break;
    case 0xE6: s.spc.setA(sr(s, s.spc.x)); sZN(s, sa(s)); break;
    case 0xE7: s.spc.setA(sr(s, idpx())); sZN(s, sa(s)); break;
    case 0xE8: s.spc.setA(sf(s)); sZN(s, sa(s)); break;
    case 0xE9: s.spc.x = sr(s, sf16(s)); sZN(s, s.spc.x); break;
    case 0xEA: { auto [a, b] = bitAddr(); sw(s, a, sr(s, a) ^ (1 << b)); break; }
    case 0xEB: s.spc.setY(sr(s, dp())); sZN(s, s.spc.y()); break;
    case 0xEC: s.spc.setY(sr(s, sf16(s))); sZN(s, s.spc.y()); break;
    case 0xED: s.spc.psw ^= CC; break;
    case 0xEE: s.spc.setY(spull(s)); sZN(s, s.spc.y()); break;
    case 0xEF: s.spc.pc--; break;
    case 0xF0: { std::int8_t r = sf(s); if (s.spc.psw & CZ) s.spc.pc += r; break; }
    case 0xF4: s.spc.setA(sr(s, dpx())); sZN(s, sa(s)); break;
    case 0xF5: s.spc.setA(sr(s, absx())); sZN(s, sa(s)); break;
    case 0xF6: s.spc.setA(sr(s, absy())); sZN(s, sa(s)); break;
    case 0xF7: s.spc.setA(sr(s, idpy())); sZN(s, sa(s)); break;
    case 0xF8: s.spc.x = sr(s, dp()); sZN(s, s.spc.x); break;
    case 0xF9: s.spc.x = sr(s, dpy()); sZN(s, s.spc.x); break;
    case 0xFA: { std::uint16_t d = dp(); sw(s, dp(), sr(s, d)); break; }
    case 0xFB: s.spc.setY(sr(s, dpx())); sZN(s, s.spc.y()); break;
    case 0xFC: s.spc.setY(s.spc.y() + 1); sZN(s, s.spc.y()); break;
    case 0xFD: s.spc.setY(sa(s)); sZN(s, s.spc.y()); break;
    case 0xFE: { std::int8_t r = sf(s); s.spc.setY(s.spc.y() - 1); if (s.spc.y()) s.spc.pc += r; break; }
    case 0xFF: s.spc.pc--; break;
    default: break;
    }
    for (int i = 0; i < 3; i++) if (s.spc.timersOn[i]) {
        s.spc.timerDiv[i] += 4;
        int period = i == 2 ? 16 : 128;
        while (s.spc.timerDiv[i] >= period) {
            s.spc.timerDiv[i] -= period;
            s.spc.timerStage[i]++;
            int tgt = s.spc.timerTarget[i] ? s.spc.timerTarget[i] : 256;
            if (s.spc.timerStage[i] >= tgt) { s.spc.timerStage[i] = 0; s.spc.timerOut[i] = (s.spc.timerOut[i] + 1) & 0x0F; }
        }
    }
    return 2;
}

inline void ApuBridge::tickMasterCycles(unsigned masterCycles){if(nativeStepHook){nativeMasterCycles+=masterCycles;nativeStepHook(*this,masterCycles);}else{fallbackMasterCycles+=masterCycles;spcMasterRemainder+=masterCycles;while(spcMasterRemainder>=42u){spcMasterRemainder-=42u;forja65SpcStep(*this);}}tickDspMasterCycles(masterCycles);}
struct DmaChannel { std::uint8_t dmap{},bbad{},a1b{},dasb{}; std::uint16_t a1t{},das{},a2a{}; std::uint8_t ntrl{}; };
struct NativeReturnFrame { std::uint32_t target{}; bool longCall{}; };
struct CpuTraceEntry { std::uint32_t pc{}; std::uint16_t a{},x{},y{},s{},d{}; std::uint8_t db{},pb{},p{}; bool e{},m8{},x8{},c{}; };
struct HardwareUsage { std::uint64_t romReads{},romNativeReads{},romFallbackReads{},wramReads{},wramWrites{},sramReads{},sramWrites{},ppuReads{},ppuWrites{},ppuNativeReads{},ppuNativeWrites{},ppuFallbackReads{},ppuFallbackWrites{},apuReads{},apuWrites{},ioReads{},ioWrites{},dmaBytes{},dmaNativeBytes{},dmaFallbackBytes{},hdmaBytes{},hdmaNativeBytes{},hdmaFallbackBytes{},cartChipReads{},cartChipWrites{}; };
enum class MapperKind { LoROM, HiROM, ExHiROM };
enum class RomRuntimeMode { Cart, Hybrid, NativeOnly };
enum class PpuRuntimeMode { VirtualRegisters, StateOnlyNativeScanout };
struct NativeRomRegion { std::uint32_t off{}; std::vector<std::uint8_t> data; };
struct NativeRomStore {
  std::uint32_t logicalSize{}; std::uint64_t sourceHash{}; std::vector<NativeRomRegion> regions;
  bool empty()const{return regions.empty();}
  std::uint64_t coverageBytes()const{std::uint64_t n=0;for(const auto&r:regions)n+=r.data.size();return n;}
  double coveragePercent()const{return logicalSize?100.0*(double)coverageBytes()/(double)logicalSize:0.0;}
  bool read(std::size_t off,std::uint8_t&out)const{for(const auto&r:regions)if(off>=r.off&&off<(std::size_t)r.off+r.data.size()){out=r.data[off-r.off];return true;}return false;}
  bool load(const std::string&path){std::ifstream f(path,std::ios::binary);if(!f)return false;char m[4]{};f.read(m,4);if(std::string(m,4)!="F65R")return false;auto r32=[&](){std::uint32_t v{};f.read((char*)&v,4);return v;};auto r64=[&](){std::uint64_t v{};f.read((char*)&v,8);return v;};auto ver=r32();if(ver!=1)return false;logicalSize=r32();sourceHash=r64();auto n=r32();regions.clear();regions.reserve(n);for(std::uint32_t i=0;i<n;i++){NativeRomRegion r;r.off=r32();auto len=r32();r.data.resize(len);if(len)f.read((char*)r.data.data(),len);if(!f)return false;regions.push_back(std::move(r));}std::sort(regions.begin(),regions.end(),[](const auto&a,const auto&b){return a.off<b.off;});return true;}
};
enum class CartChip { None, DSP1, DSP2, DSP3, DSP4, GSU, OBC1, SA1, SDD1, SRTC, SPC7110, ST010_011, ST018, CX4, Custom, Other };
struct ForjaNativeHook {
  std::uint32_t pc{};unsigned(*body)(CpuState&,SnesRuntime&){};
  bool(*guard)(const CpuState&,const SnesRuntime&){};
  int e{-1},m{-1},x{-1};
};
struct SnesRuntime {
  ForjaTrace trace;ForjaRenderer hostRenderer;std::vector<ForjaNativeHook> nativeHooks;
  std::uint32_t traceRoutine{};const char*traceSource{"CPU"};bool nativeCallPending{},nativeReference{},cpuInstructionTraced{};
  std::uint64_t nativeHookCalls{},nativeHookMasterCycles{};
  void registerNativeHook(ForjaNativeHook hook){if(!hook.body||hook.pc>0xFFFFFFu)throw std::invalid_argument("Invalid native hook");for(const auto&h:nativeHooks)if(h.pc==hook.pc&&h.e==hook.e&&h.m==hook.m&&h.x==hook.x)throw std::invalid_argument("Duplicate native hook");nativeHooks.push_back(hook);}
  bool runNativeHook(std::uint32_t pc,CpuState&cpu){if(nativeReference||nativeReturns.empty())return false;
    for(const auto&h:nativeHooks){if((h.pc!=pc&&((h.pc&0xFFFFu)!=(pc&0xFFFFu)||romOffset(h.pc)==(std::size_t)-1||romOffset(h.pc)!=romOffset(pc)))||(h.e>=0&&cpu.e!=bool(h.e))||(h.m>=0&&cpu.m8!=bool(h.m))||(h.x>=0&&cpu.x8!=bool(h.x)))continue;if(h.guard&&!h.guard(cpu,*this))continue;
      const auto stack=cpu.s;const bool emu=cpu.e;const auto depth=nativeReturns.size();const auto ret=nativeReturns.back();
      const auto raw=cpu.peekStack16(*this);const auto bank=ret.longCall?cpu.peekStack8(*this,3u):cpu.pb;
      const auto destination=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu);
      if(destination!=ret.target)throw std::runtime_error("Native hook return-frame mismatch");
      ForjaTraceContext hookContext(traceRoutine,traceSource,pc,"HOST");const auto clocks=h.body(cpu,*this);
      if(cpu.s!=stack||cpu.e!=emu||nativeReturns.size()!=depth||nativeReturns.back().target!=ret.target||nativeReturns.back().longCall!=ret.longCall||dispatchPending||nativeCallPending)throw std::runtime_error("Native hook violated stack/dispatch ABI");
      if(cpu.peekStack16(*this)!=raw||(ret.longCall&&cpu.peekStack8(*this,3u)!=bank))throw std::runtime_error("Native hook modified real return frame");
      cpu.pop16Value(*this);if(ret.longCall)cpu.pop8Value(*this);cpu.pb=bank;popNativeReturn();
      nativeHookCalls++;nativeHookMasterCycles+=clocks;advanceCpuMasterCycles(clocks);
      trace.emit(frameCounter,pc,lastInstructionPc,"native_hook","HOST",pc,clocks,"HOST");return true;
    }return false;
  }
  const char* traceSpace(std::uint32_t address)const{address&=0xFFFFFFu;const auto lo=address&0xFFFFu;if(wramOffset(address)!=(std::size_t)-1)return "WRAM";if(sramOffset(address)!=(std::size_t)-1)return "SRAM";if(cartChipAddress(address))return "CHIP";if(ioBank(address)){if(lo==0x2118||lo==0x2119||lo==0x2139||lo==0x213A)return "VRAM";if(lo==0x2122||lo==0x213B)return "CGRAM";if(lo==0x2104||lo==0x2138)return "OAM";if(lo>=0x2100&&lo<=0x213F)return "PPU";if(lo>=0x2140&&lo<=0x2143)return "APU";if(lo==0x4016||lo==0x4017||(lo>=0x4218&&lo<=0x421F))return "INPUT";if(lo==0x2180)return "WRAM_PORT";if(lo>=0x4300&&lo<=0x437F)return "DMA_REG";if(lo>=0x4200&&lo<=0x421F)return "IO";}return romOffset(address)!=(std::size_t)-1?"ROM":"UNKNOWN";}
  void observeBus(const char*kind,std::uint32_t address,std::uint32_t value){if(!trace.enabled)return;trace.emit(frameCounter,traceRoutine,lastInstructionPc,kind,traceSpace(address),address&0xFFFFFFu,value,traceSource);}
  std::vector<std::uint8_t> ram=std::vector<std::uint8_t>(0x20000); std::vector<std::uint8_t> cart; std::vector<std::uint8_t> sram; std::string sramPath{"save.srm"}; bool sramDirty{}; unsigned romSizeCode{},sramSizeCode{},regionCode{}; CartChip cartChip{CartChip::None}; PpuState ppu; CpuIoState io; ApuBridge apu; DmaChannel dma[8]{}; NativeRomStore nativeRom; std::size_t romLogicalSize{}; RomRuntimeMode romMode{RomRuntimeMode::Cart}; PpuRuntimeMode ppuMode{PpuRuntimeMode::VirtualRegisters}; bool nativeDmaEnabled{},spcCaptureDone{}; std::vector<std::uint8_t> romTouched; std::vector<NativeReturnFrame> nativeReturns; std::array<CpuTraceEntry,256> cpuTrace{}; std::size_t cpuTracePos{},cpuTraceCount{}; bool dispatchPending{},hostFrameReady{}; std::uint32_t dispatchTarget{},dispatchFrom{}; std::uint8_t hdmaActive{},hdmaEnded{}; bool hdmaTransfer[8]{},hdmaEveryLine[8]{},hdmaInitialized[8]{}; std::uint16_t hdmaLines[8]{}; MapperKind mapper{MapperKind::LoROM}; bool stopped{},windowClosed{},irqFiredThisLine{},frameTimingActive{},headless{},framePacingStarted{},cpuNmiInterruptPending{},cpuIrqInterruptPending{},hdmaExecutedThisLine{}; std::uint64_t instructionWatchdogLimit{readInstructionWatchdogLimit()}; std::uint64_t frameCounter{},cpuMasterClock{},cpuInstructionCount{},timingOverflowMasterCycles{},nmiServiceCount{},irqServiceCount{}; unsigned currentScanline{},currentMasterCycle{},fbWidth{256},fbHeight{224},rasterCursorX{},lastInstructionMasterCycles{}; std::uint32_t lastInstructionPc{}; bool interlaceField{},wramRefreshAppliedThisLine{},sceneCaptureDone{}; std::uint64_t dmaStallMasterCycles{},hdmaStallMasterCycles{},wramRefreshStallMasterCycles{},interruptEntryMasterCycles{}; std::vector<std::uint32_t> framebuffer=std::vector<std::uint32_t>(256u*224u,0xFF000000u); HardwareUsage hwUsage{},hwFrameBase{}; std::uint32_t firstRomPc{0xFFFFFFFFu},firstPpuPc{0xFFFFFFFFu},firstApuPc{0xFFFFFFFFu},firstDmaPc{0xFFFFFFFFu},firstHdmaPc{0xFFFFFFFFu}; struct InputFrame{std::uint64_t frame{};std::uint16_t joy1{},joy2{};}; std::vector<InputFrame> inputReplay; std::size_t inputReplayPos{}; std::string inputRecordPath{}; bool replayActive{}; std::chrono::steady_clock::time_point nextPresent{};
#ifdef _WIN32
  HWND hwnd{}; HINSTANCE hinst{};
#endif
  static std::uint64_t readInstructionWatchdogLimit(){const char*w=std::getenv("FORJA65_WATCHDOG_INSTRUCTIONS");return(w&&*w)?std::strtoull(w,nullptr,10):0u;}
  static bool envFlag(const char*name){const char*v=std::getenv(name);return v&&*v&&std::string(v)!="0";}
  static std::string envText(const char*name){const char*v=std::getenv(name);return v?std::string(v):std::string();}
  static bool isPalRegion(unsigned r){return r>=2u&&r<=12u;}
  double hostRefreshHz()const{return isPalRegion(regionCode)?50.0:60.0;}
  void initMigrationModes(const std::string&cartPath){auto rm=envText("FORJA65_ROM_MODE");if(rm=="native")romMode=RomRuntimeMode::NativeOnly;else if(rm=="hybrid")romMode=RomRuntimeMode::Hybrid;else romMode=RomRuntimeMode::Cart;auto pm=envText("FORJA65_PPU_MODE");ppuMode=(pm=="state"||pm=="native"||pm=="strict")?PpuRuntimeMode::StateOnlyNativeScanout:PpuRuntimeMode::VirtualRegisters;auto dm=envText("FORJA65_DMA_MODE");nativeDmaEnabled=(dm=="native"||dm=="auto");auto am=envText("FORJA65_AUDIO_MODE");apu.setNativeDsp(am=="native"||am=="auto");const std::string pack=envText("FORJA65_NATIVE_ROM_PACK").empty()?"assets/native-rom-data.bin":envText("FORJA65_NATIVE_ROM_PACK");if(romMode!=RomRuntimeMode::NativeOnly)loadCart(cartPath);if(romMode!=RomRuntimeMode::Cart){if(!nativeRom.load(pack)&&romMode==RomRuntimeMode::NativeOnly)throw std::runtime_error("native-rom-data.bin nao encontrado/valido: "+pack);if(nativeRom.logicalSize)romLogicalSize=nativeRom.logicalSize;}if(!romLogicalSize)romLogicalSize=cart.size();if(envFlag("FORJA65_ROM_PROFILE"))romTouched.assign(romLogicalSize,0);}
  SnesRuntime()=default; explicit SnesRuntime(const std::string&path,MapperKind m,std::size_t sramBytes=0,unsigned romCode=0,unsigned sramCode=0,CartChip chip=CartChip::None,const std::string&savePath="save.srm",unsigned region=1u,bool forceHeadless=false):sramPath(savePath),romSizeCode(romCode),sramSizeCode(sramCode),regionCode(region),cartChip(chip),mapper(m),headless(forceHeadless||envFlag("FORJA65_HEADLESS")){initMigrationModes(path);initSram(sramBytes);trace.initialize(cartHashHex());nativeReference=envText("FORJA65_EXECUTION")=="reference";initInputTraceFromEnv();if(!headless)initWindow();}
  ~SnesRuntime(){saveSram();saveRomReadProfile();apu.saveDump("forja65-spc-upload.bin");apu.saveManifest("forja65-spc-upload.txt");if(envFlag("FORJA65_AUDIO_DUMP")&&apu.nativeDspReady())apu.saveNativeAudioWav("forja65-native-audio.wav");shutdownWindow();}
  void loadCart(const std::string&path){std::ifstream f(path,std::ios::binary);if(!f)throw std::runtime_error("cart-data.bin nao encontrado: "+path);cart.assign(std::istreambuf_iterator<char>(f),{});if(cart.empty())throw std::runtime_error("cart-data.bin vazio");romLogicalSize=cart.size();}
  void initSram(std::size_t bytes){if(!bytes)return;sram.assign(bytes,0xFFu);std::ifstream f(sramPath,std::ios::binary);if(f)f.read((char*)sram.data(),(std::streamsize)sram.size());}
  void saveSram(){if(sram.empty()||!sramDirty)return;std::ofstream f(sramPath,std::ios::binary|std::ios::trunc);if(f)f.write((const char*)sram.data(),(std::streamsize)sram.size());sramDirty=false;}
  static std::uint64_t hashBytes(const std::uint8_t*p,std::size_t n){std::uint64_t h=1469598103934665603ull;for(std::size_t i=0;i<n;i++){h^=p[i];h*=1099511628211ull;}return h;}
  std::uint64_t cartHashValue()const{return!cart.empty()?hashBytes(cart.data(),cart.size()):nativeRom.sourceHash;}
  std::string cartHashHex()const{std::ostringstream ss;ss<<std::hex<<std::setfill('0')<<std::setw(16)<<cartHashValue();return ss.str();}
  std::uint64_t ramHash()const{return hashBytes(ram.data(),ram.size());}
  void markRomRead(std::size_t off){if(off<romTouched.size())romTouched[off]=1;}
  void saveRomReadProfile(const std::string&path="forja65-rom-read-ranges.txt")const{if(romTouched.empty())return;std::ofstream o(path,std::ios::trunc);if(!o)return;o<<"FORJA65_ROM_READ_RANGES 1\\nrom="<<cartHashHex()<<"\\nlogical_size="<<romLogicalSize<<"\\n";std::size_t i=0,count=0;while(i<romTouched.size()){while(i<romTouched.size()&&!romTouched[i])i++;if(i>=romTouched.size())break;std::size_t b=i;while(i<romTouched.size()&&romTouched[i])i++;std::size_t e=i;o<<"range=0x"<<std::hex<<b<<" length=0x"<<(e-b)<<std::dec<<"\\n";count++;}o<<"ranges="<<count<<"\\n";}
  bool loadInputReplay(const std::string&path){inputReplay.clear();inputReplayPos=0;std::ifstream in(path);if(!in)return false;std::string line;while(std::getline(in,line)){if(line.empty()||line[0]=='#'||line[0]==';')continue;std::istringstream ss(line);std::string part;InputFrame q{};bool hf=false;while(ss>>part){auto p=part.find('=');if(p==std::string::npos)continue;auto k=part.substr(0,p),v=part.substr(p+1);try{if(k=="frame"){q.frame=std::stoull(v,nullptr,10);hf=true;}else if(k=="joy1")q.joy1=(std::uint16_t)std::stoul(v,nullptr,16);else if(k=="joy2")q.joy2=(std::uint16_t)std::stoul(v,nullptr,16);}catch(...){}}if(hf)inputReplay.push_back(q);}std::sort(inputReplay.begin(),inputReplay.end(),[](const auto&a,const auto&b){return a.frame<b.frame;});replayActive=!inputReplay.empty();return replayActive;}
  void setInputRecordPath(const std::string&path,bool reset=true){inputRecordPath=path;if(reset&&!path.empty()){std::ofstream out(path,std::ios::trunc);if(out)out<<"# FORJA65_INPUT_TRACE 1 rom="<<cartHashHex()<<"\\n";}}
  void initInputTraceFromEnv(){if(const char*p=std::getenv("FORJA65_INPUT_REPLAY"))if(*p)loadInputReplay(p);if(const char*p=std::getenv("FORJA65_INPUT_RECORD"))if(*p)setInputRecordPath(p,true);}
  bool applyReplayInput(){if(!replayActive)return false;while(inputReplayPos<inputReplay.size()&&inputReplay[inputReplayPos].frame<frameCounter)inputReplayPos++;if(inputReplayPos>=inputReplay.size()||inputReplay[inputReplayPos].frame!=frameCounter)return true;const auto&q=inputReplay[inputReplayPos++];setJoy1(q.joy1);setJoy2(q.joy2);return true;}
  void recordInputFrame(){if(inputRecordPath.empty())return;std::ofstream out(inputRecordPath,std::ios::app);if(out)out<<"frame="<<frameCounter<<" joy1="<<std::hex<<std::setfill('0')<<std::setw(4)<<(unsigned)io.joy[0]<<" joy2="<<std::setw(4)<<(unsigned)io.joy[1]<<std::dec<<"\\n";}
  static HardwareUsage usageDelta(const HardwareUsage&a,const HardwareUsage&b){HardwareUsage d;d.romReads=a.romReads-b.romReads;d.romNativeReads=a.romNativeReads-b.romNativeReads;d.romFallbackReads=a.romFallbackReads-b.romFallbackReads;d.wramReads=a.wramReads-b.wramReads;d.wramWrites=a.wramWrites-b.wramWrites;d.sramReads=a.sramReads-b.sramReads;d.sramWrites=a.sramWrites-b.sramWrites;d.ppuReads=a.ppuReads-b.ppuReads;d.ppuWrites=a.ppuWrites-b.ppuWrites;d.ppuNativeReads=a.ppuNativeReads-b.ppuNativeReads;d.ppuNativeWrites=a.ppuNativeWrites-b.ppuNativeWrites;d.ppuFallbackReads=a.ppuFallbackReads-b.ppuFallbackReads;d.ppuFallbackWrites=a.ppuFallbackWrites-b.ppuFallbackWrites;d.apuReads=a.apuReads-b.apuReads;d.apuWrites=a.apuWrites-b.apuWrites;d.ioReads=a.ioReads-b.ioReads;d.ioWrites=a.ioWrites-b.ioWrites;d.dmaBytes=a.dmaBytes-b.dmaBytes;d.dmaNativeBytes=a.dmaNativeBytes-b.dmaNativeBytes;d.dmaFallbackBytes=a.dmaFallbackBytes-b.dmaFallbackBytes;d.hdmaBytes=a.hdmaBytes-b.hdmaBytes;d.hdmaNativeBytes=a.hdmaNativeBytes-b.hdmaNativeBytes;d.hdmaFallbackBytes=a.hdmaFallbackBytes-b.hdmaFallbackBytes;d.cartChipReads=a.cartChipReads-b.cartChipReads;d.cartChipWrites=a.cartChipWrites-b.cartChipWrites;return d;}
  static void rememberFirst(std::uint32_t&slot,std::uint32_t pc){if(slot==0xFFFFFFFFu)slot=pc&0xFFFFFFu;}
  void appendFrameHash(){if(!envFlag("FORJA65_FRAME_HASHES"))return;std::ofstream out("forja65-frame-hashes.txt",std::ios::app);if(out)out<<"frame="<<frameCounter<<" framebuffer="<<std::hex<<framebufferHash()<<" wram="<<ramHash()<<" pc="<<lastInstructionPc<<std::dec<<"\\n";}
  void appendNativeAuditFrame(){if(!envFlag("FORJA65_NATIVE_AUDIT"))return;const bool fresh=!std::filesystem::exists("forja65-native-dependency.csv");std::ofstream out("forja65-native-dependency.csv",std::ios::app);if(!out)return;if(fresh)out<<"frame,rom_reads,rom_native,rom_fallback,wram_reads,wram_writes,sram_reads,sram_writes,ppu_reads,ppu_writes,ppu_native_reads,ppu_native_writes,ppu_fallback_reads,ppu_fallback_writes,apu_reads,apu_writes,io_reads,io_writes,dma_bytes,dma_native,dma_fallback,hdma_bytes,hdma_native,hdma_fallback,cartchip_reads,cartchip_writes,framebuffer_hash,wram_hash,last_pc\\n";auto d=usageDelta(hwUsage,hwFrameBase);out<<frameCounter<<','<<d.romReads<<','<<d.romNativeReads<<','<<d.romFallbackReads<<','<<d.wramReads<<','<<d.wramWrites<<','<<d.sramReads<<','<<d.sramWrites<<','<<d.ppuReads<<','<<d.ppuWrites<<','<<d.ppuNativeReads<<','<<d.ppuNativeWrites<<','<<d.ppuFallbackReads<<','<<d.ppuFallbackWrites<<','<<d.apuReads<<','<<d.apuWrites<<','<<d.ioReads<<','<<d.ioWrites<<','<<d.dmaBytes<<','<<d.dmaNativeBytes<<','<<d.dmaFallbackBytes<<','<<d.hdmaBytes<<','<<d.hdmaNativeBytes<<','<<d.hdmaFallbackBytes<<','<<d.cartChipReads<<','<<d.cartChipWrites<<','<<std::hex<<framebufferHash()<<','<<ramHash()<<','<<lastInstructionPc<<std::dec<<"\\n";hwFrameBase=hwUsage;}
  void writeNativeDependencyReport(const std::string&path="forja65-native-dependency-report.txt")const{std::ofstream o(path,std::ios::trunc);if(!o)return;auto pc=[&](std::uint32_t v){std::ostringstream q;if(v==0xFFFFFFFFu)q<<"none";else q<<"0x"<<std::hex<<std::setfill('0')<<std::setw(6)<<v;return q.str();};auto romNativeOnly=hwUsage.romReads&&hwUsage.romFallbackReads==0;auto ppuNativeOnly=ppuMode==PpuRuntimeMode::StateOnlyNativeScanout&&hwUsage.ppuFallbackReads==0&&hwUsage.ppuFallbackWrites==0;auto dmaNativeOnly=(hwUsage.dmaBytes+hwUsage.hdmaBytes)>0&&(hwUsage.dmaFallbackBytes+hwUsage.hdmaFallbackBytes)==0;auto apuNative=apu.nativeBackendReady();auto dspNative=apu.nativeDspReady();auto apuFullyNative=apuNative&&apu.fallbackMasterCycles==0&&dspNative;o<<"FORJA65_NATIVE_DEPENDENCY_AUDIT 1\\nschema=3\\nrom="<<cartHashHex()<<"\\nframes="<<frameCounter<<"\\ninstructions="<<cpuInstructionCount<<"\\nnmi_services="<<nmiServiceCount<<"\\nirq_services="<<irqServiceCount<<"\\nCPU_AOT=YES\\nPPU_STATE_ONLY_NATIVE_SCANOUT="<<(ppuMode==PpuRuntimeMode::StateOnlyNativeScanout?"YES":"NO")<<"\\nPPU_NATIVE_ONLY="<<(ppuNativeOnly?"YES":"NO")<<"\\nPPU_VIRTUAL_HW="<<((hwUsage.ppuFallbackReads||hwUsage.ppuFallbackWrites)?"YES":"NO")<<"\\nDMA_NATIVE_FASTPATH="<<(dmaNativeOnly?"YES":"NO")<<"\\nAPU_NATIVE_BACKEND="<<(apuNative?"YES":"NO")<<"\\nDSP_NATIVE_BACKEND="<<(dspNative?"YES":"NO")<<"\\nAPU_FULLY_NATIVE="<<(apuFullyNative?"YES":"NO")<<"\\nAPU_VIRTUAL_HW="<<(apu.fallbackMasterCycles?"YES":"NO")<<"\\nDSP_VIRTUAL_HW="<<(!dspNative?"YES":"NO")<<"\\nROM_NATIVE_PACK_ONLY="<<(romNativeOnly?"YES":"NO")<<"\\nROM_NATIVE_READY="<<((!nativeRom.empty()&&hwUsage.romFallbackReads==0)?"YES":"NO")<<"\\nROM_RUNTIME_DATA="<<(hwUsage.romFallbackReads?"YES":"NO")<<"\\nCARTCHIP_RUNTIME="<<((hwUsage.cartChipReads||hwUsage.cartChipWrites)?"YES":"NO")<<"\\nrom_reads="<<hwUsage.romReads<<"\\nrom_native_reads="<<hwUsage.romNativeReads<<"\\nrom_fallback_reads="<<hwUsage.romFallbackReads<<"\\nnative_rom_pack_bytes="<<nativeRom.coverageBytes()<<"\\nnative_rom_pack_coverage_percent="<<std::fixed<<std::setprecision(4)<<nativeRom.coveragePercent()<<std::defaultfloat<<"\\nwram_reads="<<hwUsage.wramReads<<"\\nwram_writes="<<hwUsage.wramWrites<<"\\nppu_reads="<<hwUsage.ppuReads<<"\\nppu_writes="<<hwUsage.ppuWrites<<"\\nppu_native_reads="<<hwUsage.ppuNativeReads<<"\\nppu_native_writes="<<hwUsage.ppuNativeWrites<<"\\nppu_fallback_reads="<<hwUsage.ppuFallbackReads<<"\\nppu_fallback_writes="<<hwUsage.ppuFallbackWrites<<"\\napu_reads="<<hwUsage.apuReads<<"\\napu_writes="<<hwUsage.apuWrites<<"\\napu_native_master_cycles="<<apu.nativeMasterCycles<<"\\napu_fallback_master_cycles="<<apu.fallbackMasterCycles<<"\\ndsp_native_samples="<<apu.dspNativeSamples<<"\\ndsp_fallback_samples="<<apu.dspFallbackSamples<<"\\ndma_bytes="<<hwUsage.dmaBytes<<"\\ndma_native_bytes="<<hwUsage.dmaNativeBytes<<"\\ndma_fallback_bytes="<<hwUsage.dmaFallbackBytes<<"\\nhdma_bytes="<<hwUsage.hdmaBytes<<"\\nhdma_native_bytes="<<hwUsage.hdmaNativeBytes<<"\\nhdma_fallback_bytes="<<hwUsage.hdmaFallbackBytes<<"\\nfirst_rom_pc="<<pc(firstRomPc)<<"\\nfirst_ppu_pc="<<pc(firstPpuPc)<<"\\nfirst_apu_pc="<<pc(firstApuPc)<<"\\nfirst_dma_pc="<<pc(firstDmaPc)<<"\\nfirst_hdma_pc="<<pc(firstHdmaPc)<<"\\n";}
  static void put16(std::ofstream&o,std::uint16_t v){char b[2]={(char)(v&255u),(char)((v>>8)&255u)};o.write(b,2);} static void put32(std::ofstream&o,std::uint32_t v){char b[4]={(char)(v&255u),(char)((v>>8)&255u),(char)((v>>16)&255u),(char)((v>>24)&255u)};o.write(b,4);}
  static std::uint64_t fileHash(const std::filesystem::path&p){std::ifstream f(p,std::ios::binary);if(!f)return 0;std::uint64_t h=1469598103934665603ull;char buf[4096];while(f){f.read(buf,sizeof buf);auto n=f.gcount();for(std::streamsize i=0;i<n;i++){h^=(std::uint8_t)buf[i];h*=1099511628211ull;}}return h;}
  std::uint64_t framebufferHash()const{std::uint64_t h=1469598103934665603ull;for(auto v:framebuffer){std::uint8_t q[4]={(std::uint8_t)((v>>16)&255u),(std::uint8_t)((v>>8)&255u),(std::uint8_t)(v&255u),(std::uint8_t)((v>>24)&255u)};for(auto b:q){h^=b;h*=1099511628211ull;}}return h;}
  std::uint16_t fixedColor15()const{return(std::uint16_t)((ppu.fixedR&31u)|((ppu.fixedG&31u)<<5)|((ppu.fixedB&31u)<<10));}
  int captureBgBpp(unsigned bg)const{unsigned m=ppu.bgmode&7u;if(m==0)return bg<4?2:0;if(m==1)return bg<2?4:(bg==2?2:0);if(m==2)return bg<2?4:0;if(m==3)return bg==0?8:(bg==1?4:0);if(m==4)return bg==0?8:(bg==1?2:0);if(m==5)return bg==0?4:(bg==1?2:0);if(m==6)return bg==0?4:0;return 0;}
  void captureBgInfo(unsigned bg,std::uint16_t&mapBase,std::uint16_t&charBase,int&bpp,int&mw,int&mh,int&tileSize)const{mapBase=(std::uint16_t)((ppu.bgsc[bg]&0xFCu)<<8);charBase=(std::uint16_t)((ppu.bgnba[bg]&7u)<<12);bpp=captureBgBpp(bg);int sc=ppu.bgsc[bg]&3u;mw=(sc&1)?64:32;mh=(sc&2)?64:32;tileSize=(ppu.bgmode&(0x10u<<bg))?16:8;}
  std::uint16_t vramWord(std::uint16_t wa)const{std::uint32_t b=((std::uint32_t)wa*2u)&0xFFFFu;return(std::uint16_t)(ppu.vram[b]|(ppu.vram[(b+1u)&0xFFFFu]<<8));}
  std::uint8_t captureTilePixel(std::uint32_t a,int y,int x,int bpp)const{std::uint8_t mask=(std::uint8_t)(0x80u>>x);auto pair=[&](std::uint32_t off,int sh){std::uint8_t p0=ppu.vram[(a+y*2u+off)&0xFFFFu],p1=ppu.vram[(a+y*2u+off+1u)&0xFFFFu];return((p0&mask)?(1u<<sh):0u)|((p1&mask)?(2u<<sh):0u);};unsigned v=pair(0,0);if(bpp>=4)v|=pair(16,2);if(bpp>=8){v|=pair(32,4);v|=pair(48,6);}return(std::uint8_t)v;}
  bool writeNativePalette(const std::filesystem::path&p)const{std::ofstream o(p,std::ios::binary|std::ios::trunc);if(!o)return false;o.write("NPAL",4);put16(o,1);put16(o,256);o.write((const char*)ppu.cgram.data(),(std::streamsize)ppu.cgram.size());return(bool)o;}
  bool writeNativeTiles(const std::filesystem::path&p,std::uint16_t charBase,int bpp)const{if(bpp!=2&&bpp!=4&&bpp!=8)return false;std::ofstream o(p,std::ios::binary|std::ios::trunc);if(!o)return false;o.write("NTIL",4);put16(o,1);put16(o,(std::uint16_t)bpp);put32(o,1024);put32(o,8);put32(o,8);put32(o,charBase);std::uint32_t bpt=(std::uint32_t)bpp*8u;std::uint8_t q[64]{};for(std::uint32_t t=0;t<1024;t++){std::uint32_t base=((std::uint32_t)charBase*2u+t*bpt)&0xFFFFu;for(int y=0;y<8;y++)for(int x=0;x<8;x++)q[y*8+x]=captureTilePixel(base,y,x,bpp);o.write((const char*)q,64);}return(bool)o;}
  bool writeNativeMap(const std::filesystem::path&p,std::uint16_t base,int mw,int mh)const{std::ofstream o(p,std::ios::binary|std::ios::trunc);if(!o)return false;o.write("NMAP",4);put16(o,1);put16(o,0);put32(o,(std::uint32_t)mw);put32(o,(std::uint32_t)mh);put32(o,base);for(int y=0;y<mh;y++)for(int x=0;x<mw;x++){int page=0;if(mw==64&&x>=32)page++;if(mh==64&&y>=32)page+=(mw==64?2:1);auto e=vramWord((std::uint16_t)(base+page*0x400+(y&31)*32+(x&31)));put16(o,e);}return(bool)o;}
  bool writeFramePpm(const std::filesystem::path&p)const{std::ofstream o(p,std::ios::binary|std::ios::trunc);if(!o)return false;o<<"P6\\n"<<fbWidth<<" "<<fbHeight<<"\\n255\\n";for(auto v:framebuffer){char b[3]={(char)((v>>16)&255u),(char)((v>>8)&255u),(char)(v&255u)};o.write(b,3);}return(bool)o;}
  std::uint32_t cgramArgb(unsigned index)const{index&=255u;unsigned a=index*2u;std::uint16_t c=(std::uint16_t)(ppu.cgram[a]|(ppu.cgram[(a+1u)&0x1FFu]<<8));auto cv=[](unsigned v){return(std::uint8_t)((v<<3)|(v>>2));};return 0xFF000000u|((std::uint32_t)cv(c&31u)<<16)|((std::uint32_t)cv((c>>5)&31u)<<8)|cv((c>>10)&31u);}
  void objSizes(int&smallSize,int&largeSize)const{static const int S[8]={8,8,8,16,16,32,16,16},L[8]={16,32,64,32,64,64,32,32};unsigned m=(ppu.obsel>>5)&7u;smallSize=S[m];largeSize=L[m];}
  std::uint8_t objPixel4(std::uint32_t a,int y,int x)const{return captureTilePixel(a,y,x,4);}
  bool writeNativeOamLayer(const std::filesystem::path&p,const std::filesystem::path&indexPath)const{const int W=256,H=(int)std::min<unsigned>(239u,visibleLines());std::vector<std::uint32_t>px((std::size_t)W*H,0u);std::ofstream idx(indexPath,std::ios::trunc);if(!idx)return false;idx<<"FORJA65_OAM_SPRITES 1\\nobsel="<<(unsigned)ppu.obsel<<"\\n";int sm=8,lg=16;objSizes(sm,lg);unsigned drawn=0;for(int sl=127;sl>=0;--sl){int o=sl*4,x=ppu.oam[o],y=ppu.oam[o+1],t=ppu.oam[o+2],at=ppu.oam[o+3],hi=ppu.oam[512+sl/4],sh=(sl&3)*2;x|=((hi>>sh)&1)<<8;if(x>=256)x-=512;int z=((hi>>(sh+1))&1)?lg:sm;bool hf=(at&0x40)!=0,vf=(at&0x80)!=0;int pal=(at>>1)&7;std::uint32_t b1=(ppu.obsel&7u)<<14,b2=b1+(std::uint32_t((ppu.obsel&0x18u)+8u)*0x400u),name=(at&1)?b2:b1;bool any=false;for(int dy=0;dy<z;dy++)for(int dx=0;dx<z;dx++){int sx=hf?z-1-dx:dx,sy=vf?z-1-dy:dy,ut=((((t>>4)+(sy>>3))<<4)|(((t&15)+(sx>>3))&15))&255;int pi=objPixel4((name+(std::uint32_t)ut*32u)&0xFFFFu,sy&7,sx&7);if(!pi)continue;int xx=x+dx,yy=(y+dy)&255;if((unsigned)xx<(unsigned)W&&(unsigned)yy<(unsigned)H){px[(std::size_t)yy*W+xx]=cgramArgb(128u+(unsigned)pal*16u+(unsigned)pi);any=true;}}if(any){idx<<"slot="<<sl<<" x="<<x<<" y="<<y<<" size="<<z<<" tile="<<t<<" attr="<<at<<" hflip="<<(hf?1:0)<<" vflip="<<(vf?1:0)<<"\\n";drawn++;}}idx<<"visible_slots="<<drawn<<"\\n";idx.close();std::ofstream o(p,std::ios::binary|std::ios::trunc);if(!o)return false;o.write("NSPR",4);put16(o,1);put16(o,0);put16(o,(std::uint16_t)W);put16(o,(std::uint16_t)H);put16(o,0);put16(o,0);put32(o,(std::uint32_t)px.size());for(auto v:px)put32(o,v);return(bool)o;}
  bool captureNativeScene(const std::string&dir,const std::string&name="scene")const{namespace fs=std::filesystem;fs::path out=dir.empty()?fs::path("forja65-scene-capture"):fs::path(dir);std::error_code ec;fs::create_directories(out,ec);if(ec)return false;auto raw=[&](const fs::path&p,const std::vector<std::uint8_t>&v){std::ofstream o(p,std::ios::binary|std::ios::trunc);if(!o)return false;o.write((const char*)v.data(),(std::streamsize)v.size());return(bool)o;};if(!raw(out/"vram.bin",ppu.vram)||!raw(out/"cgram.bin",ppu.cgram)||!raw(out/"oam.bin",ppu.oam)||!writeNativePalette(out/"palette.npal")||!writeFramePpm(out/"preview.ppm")||!writeNativeOamLayer(out/"oam-layer.nspr",out/"oam-sprites.txt"))return false;std::ofstream meta(out/(name+".nscene"),std::ios::trunc);if(!meta)return false;meta<<"NATIVE_SCENE 1\\nmode "<<(unsigned)(ppu.bgmode&7u)<<"\\nbg3_priority "<<((ppu.bgmode&8u)?1:0)<<"\\ntm "<<(unsigned)ppu.tm<<"\\nts "<<(unsigned)ppu.ts<<"\\ncgwsel "<<(unsigned)ppu.cgwsel<<"\\ncgadsub "<<(unsigned)ppu.cgadsub<<"\\nfixed_color "<<fixedColor15()<<"\\nbrightness "<<(unsigned)ppu.brightness<<"\\nbackdrop 0\\nviewport "<<fbWidth<<" "<<fbHeight<<"\\npalette palette.npal\\n";unsigned layers=0;for(unsigned bg=0;bg<4;bg++){std::uint16_t mb=0,cb=0;int bpp=0,mw=0,mh=0,tileSize=8;captureBgInfo(bg,mb,cb,bpp,mw,mh,tileSize);if(!bpp)continue;std::string n="bg"+std::to_string(bg+1),tf=n+".ntiles",mf=n+".nmap";if(!writeNativeTiles(out/tf,cb,bpp)||!writeNativeMap(out/mf,mb,mw,mh))return false;int enabled=((ppu.tm|ppu.ts)&(1u<<bg))?1:0;meta<<"layer "<<n<<" "<<bpp<<" "<<mw<<" "<<mh<<" "<<ppu.scrollX[bg]<<" "<<ppu.scrollY[bg]<<" "<<enabled<<" "<<tf<<" "<<mf<<"\\n";meta<<"layer_tile_size "<<n<<" "<<tileSize<<"\\n";layers++;}if((ppu.bgmode&7u)==7u)meta<<"mode7_raw 1\\n";meta<<"sprites oam-layer.nspr oam-sprites.txt\\n";meta<<"source_frame "<<frameCounter<<"\\nframebuffer_hash_fnv1a64 "<<std::hex<<framebufferHash()<<std::dec<<"\\ncart_hash_fnv1a64 "<<std::hex<<cartHashValue()<<std::dec<<"\\n";meta.close();if(!meta)return false;std::vector<fs::path> files={out/"vram.bin",out/"cgram.bin",out/"oam.bin",out/"palette.npal",out/"preview.ppm",out/"oam-layer.nspr",out/"oam-sprites.txt",out/(name+".nscene")};for(unsigned bg=0;bg<4;bg++){if(!captureBgBpp(bg))continue;files.push_back(out/("bg"+std::to_string(bg+1)+".ntiles"));files.push_back(out/("bg"+std::to_string(bg+1)+".nmap"));}std::ofstream man(out/"capture-manifest.txt",std::ios::trunc);if(!man)return false;man<<"FORJA65_SCENE_CAPTURE 1\\nsource_frame="<<frameCounter<<"\\nppu_mode="<<(unsigned)(ppu.bgmode&7u)<<"\\nwidth="<<fbWidth<<"\\nheight="<<fbHeight<<"\\nlayers="<<layers<<"\\nframebuffer_hash_fnv1a64="<<std::hex<<framebufferHash()<<"\\ncart_hash_fnv1a64="<<cartHashValue()<<std::dec<<"\\n";for(const auto&f:files)man<<"file="<<f.filename().string()<<" size="<<fs::file_size(f,ec)<<" hash_fnv1a64="<<std::hex<<fileHash(f)<<std::dec<<"\\n";return(bool)man;}
  bool maybeCaptureNativeScene(){if(sceneCaptureDone)return false;const char*e=std::getenv("FORJA65_CAPTURE_FRAME");if(!e||!*e)return false;std::uint64_t target=std::strtoull(e,nullptr,10);if(frameCounter<target)return false;const char*d=std::getenv("FORJA65_CAPTURE_DIR"),*n=std::getenv("FORJA65_CAPTURE_NAME");std::string dir=(d&&*d)?d:"forja65-scene-capture",name=(n&&*n)?n:("frame-"+std::to_string(frameCounter));if(!captureNativeScene(dir,name))throw std::runtime_error("falha ao exportar captura de cena para "+dir);sceneCaptureDone=true;std::ofstream log("forja65-scene-capture.txt",std::ios::trunc);if(log)log<<"frame="<<frameCounter<<"\\ndir="<<dir<<"\\nname="<<name<<"\\nframebuffer_hash_fnv1a64="<<std::hex<<framebufferHash()<<"\\n";if(envFlag("FORJA65_CAPTURE_STOP"))stopped=true;return true;}
  bool maybeCaptureSpcSnapshot(){if(spcCaptureDone)return false;const char*e=std::getenv("FORJA65_CAPTURE_SPC_FRAME");if(!e||!*e)return false;std::uint64_t target=std::strtoull(e,nullptr,10);if(frameCounter<target)return false;const char*d=std::getenv("FORJA65_CAPTURE_SPC_DIR");std::string dir=(d&&*d)?d:"forja65-spc-capture";std::error_code ec;std::filesystem::create_directories(dir,ec);if(ec)throw std::runtime_error("falha ao criar diretorio SPC: "+dir);if(!apu.saveSnapshot((std::filesystem::path(dir)/"spc-ram.bin").string(),(std::filesystem::path(dir)/"spc-capture.txt").string()))throw std::runtime_error("falha ao capturar SPC700");spcCaptureDone=true;std::ofstream log("forja65-spc-capture.log",std::ios::trunc);if(log)log<<"frame="<<frameCounter<<"\\ndir="<<dir<<"\\nentry=0x"<<std::hex<<apu.spc.pc<<"\\n";if(envFlag("FORJA65_CAPTURE_SPC_STOP"))stopped=true;return true;}
  static std::size_t mirrorOffset(std::size_t size,std::size_t off){if(!size)return(std::size_t)-1;if(off<size)return off;std::size_t mask=(std::size_t)1<<(sizeof(std::size_t)*8-1);while(mask&&!(off&mask))mask>>=1;if(!mask)return 0;if(size<=(off&mask))return mirrorOffset(size,off-mask);return mask+mirrorOffset(size-mask,off-mask);}
  std::size_t romOffset(std::uint32_t a)const{unsigned bank=(a>>16)&255,addr=a&0xFFFF;std::size_t off=0;bool full=(bank>=0x40&&bank<=0x7D)||bank>=0xC0;if(mapper==MapperKind::LoROM){if(addr<0x8000&&!full)return(std::size_t)-1;off=((bank&0x7F)<<15)|(addr&0x7FFF);}else if(mapper==MapperKind::HiROM){if(addr<0x8000&&!full)return(std::size_t)-1;off=((bank&0x3F)<<16)|addr;}else{if(addr<0x8000&&!full)return(std::size_t)-1;off=((bank&0x7F)<<16)|addr;if((bank&0x40)==0)off+=0x400000;}return mirrorOffset(romLogicalSize?romLogicalSize:cart.size(),off);}
  bool ioBank(std::uint32_t a)const{unsigned b=(a>>16)&255;return b<=0x3F||(b>=0x80&&b<=0xBF);}
  std::size_t wramOffset(std::uint32_t a)const{unsigned b=(a>>16)&255,lo=a&0xFFFF;if(b==0x7E)return lo;if(b==0x7F)return 0x10000u+lo;if(ioBank(a)&&lo<0x2000)return lo;return(std::size_t)-1;}
  std::size_t sramOffset(std::uint32_t a)const{if(sram.empty())return(std::size_t)-1;unsigned b=(a>>16)&255,lo=a&0xFFFF;if(mapper==MapperKind::LoROM){bool mapped=(b>=0x70&&b<=0x7D)||(b>=0xF0);unsigned hi=(romSizeCode>11u||sramSizeCode>5u)?0x7FFFu:0xFFFFu;if(!mapped||lo>hi)return(std::size_t)-1;std::size_t u=(((a&0xFF0000u)>>1)|(a&0x7FFFu));return u&(sram.size()-1u);}if(mapper==MapperKind::HiROM||mapper==MapperKind::ExHiROM){if(((b>=0x20&&b<=0x3F)||(b>=0xA0&&b<=0xBF))&&lo>=0x6000&&lo<=0x7FFF){std::size_t u=(lo&0x7FFFu)-0x6000u+((a&0x0F0000u)>>3);return u&(sram.size()-1u);}}return(std::size_t)-1;}
  bool cartChipAddress(std::uint32_t a)const{if(cartChip!=CartChip::DSP1)return false;unsigned b=(a>>16)&255,lo=a&0xFFFF;if(mapper==MapperKind::HiROM||mapper==MapperKind::ExHiROM)return((b<=0x1F)||(b>=0x80&&b<=0x9F))&&lo>=0x6000&&lo<=0x7FFF;if(mapper==MapperKind::LoROM){if(romLogicalSize>0x100000u)return((b>=0x60&&b<=0x6F)||(b>=0xE0&&b<=0xEF))&&lo<=0x7FFF;return((b>=0x20&&b<=0x3F)||(b>=0xA0&&b<=0xBF))&&lo>=0x8000;}return false;}
  [[noreturn]] std::uint8_t unresolvedCartChipRead(std::uint32_t a){std::ofstream f("forja65-unresolved-cartchip.txt",std::ios::app);if(f)f<<std::hex<<a<<" read\\n";throw std::runtime_error("acesso a coprocessador de cartucho ainda nao recompilado: "+std::to_string(a));}
  [[noreturn]] void unresolvedCartChipWrite(std::uint32_t a,std::uint8_t v){std::ofstream f("forja65-unresolved-cartchip.txt",std::ios::app);if(f)f<<std::hex<<a<<" write="<<(unsigned)v<<"\\n";throw std::runtime_error("escrita em coprocessador de cartucho ainda nao recompilada: "+std::to_string(a));}
  void setJoy1(std::uint16_t v){io.joy[0]=v;} void setJoy2(std::uint16_t v){io.joy[1]=v;}
  static constexpr unsigned MASTER_CYCLES_PER_SCANLINE=1364u;
  static constexpr unsigned HBLANK_START_MC=1096u;
  static constexpr unsigned HDMA_START_MC=1106u;
  static constexpr unsigned HBLANK_END_MC=4u;
  static constexpr unsigned RENDER_EVENT_MC=512u; // mantido como referencia/compatibilidade; v0.3.0 rasteriza por segmentos.
  static constexpr unsigned IRQ_TRIGGER_DELAY_MC=14u;
  static constexpr unsigned NMI_TRIGGER_MC=12u;
  static constexpr unsigned WRAM_REFRESH_MC=538u;
  static constexpr unsigned WRAM_REFRESH_CYCLES=40u;
  static constexpr unsigned DMA_SYNC_MC=18u;
  static constexpr std::uint32_t NO_TIMING_ADDR=0xFFFFFFFFu;
  void configureFramebuffer(){fbWidth=ppu.outputWidth();fbHeight=ppu.outputHeight();std::size_t need=(std::size_t)fbWidth*fbHeight;if(framebuffer.size()!=need)framebuffer.assign(need,0xFF000000u);} unsigned visibleLines()const{return ppu.visibleHeight();}
  unsigned busMasterCycles(std::uint32_t a)const{
    a&=0xFFFFFFu;unsigned bank=(a>>16)&0xFFu,lo=a&0xFFFFu;
    if((bank<=0x3Fu)||(bank>=0x80u&&bank<=0xBFu)){
      if(lo<0x2000u)return 8u;
      if(lo<0x4000u)return 6u;
      if(lo<0x4200u)return 12u;
      if(lo<0x6000u)return 6u;
      if(lo<0x8000u)return 8u;
      return(bank>=0x80u&&(io.memsel&1u))?6u:8u;
    }
    if(bank>=0x7Eu&&bank<=0x7Fu)return 8u;
    if(bank>=0xC0u)return(io.memsel&1u)?6u:8u;
    return 8u;
  }
  void setMasterCycle(unsigned mc){currentMasterCycle=mc<MASTER_CYCLES_PER_SCANLINE?mc:MASTER_CYCLES_PER_SCANLINE-1u;ppu.hCounter=(std::uint16_t)((currentMasterCycle/4u)&0x1FFu);io.hblank=(currentMasterCycle<HBLANK_END_MC)||(currentMasterCycle>=HBLANK_START_MC);}
  void advanceCpuMasterCycles(unsigned mc){
    if(!mc)return;
    cpuMasterClock+=mc;lastInstructionMasterCycles+=mc;apu.tickMasterCycles(mc);
    if(!frameTimingActive)beginFrame();
    unsigned remaining=mc;
    while(remaining){
      const unsigned vis=visibleLines(),before=currentMasterCycle;
      const int irqev=irqEventMasterCycle(currentScanline);
      unsigned step=std::min(remaining,MASTER_CYCLES_PER_SCANLINE-before);
      auto clip=[&](unsigned event){if(before<event&&before+step>event)step=event-before;};
      if(!wramRefreshAppliedThisLine)clip(WRAM_REFRESH_MC);
      if(currentScanline<vis){clip(HBLANK_START_MC);if(!hdmaExecutedThisLine)clip(HDMA_START_MC);}
      if(irqev>=0&&!irqFiredThisLine)clip((unsigned)irqev);
      if(currentScanline==vis)clip(NMI_TRIGGER_MC);
      const unsigned target=before+step;remaining-=step;
      if(currentScanline==vis&&before<NMI_TRIGGER_MC&&target>=NMI_TRIGGER_MC){io.nmiPending=true;if(io.nmiEnable)cpuNmiInterruptPending=true;}
      if(currentScanline<vis&&before<HBLANK_START_MC&&target>=HBLANK_START_MC)finishVisibleLine(currentScanline);
      if(target<MASTER_CYCLES_PER_SCANLINE)setMasterCycle(target);else currentMasterCycle=target;
      if(irqev>=0&&!irqFiredThisLine&&before<=(unsigned)irqev&&target>=(unsigned)irqev){io.irqPending=true;cpuIrqInterruptPending=true;irqFiredThisLine=true;}
      if(!wramRefreshAppliedThisLine&&target==WRAM_REFRESH_MC){wramRefreshAppliedThisLine=true;wramRefreshStallMasterCycles+=WRAM_REFRESH_CYCLES;advanceCpuMasterCycles(WRAM_REFRESH_CYCLES);continue;}
      if(currentScanline<vis&&!hdmaExecutedThisLine&&target==HDMA_START_MC){hdmaExecutedThisLine=true;if(hdmaActive)executeHdmaLine();continue;}
      if(target<MASTER_CYCLES_PER_SCANLINE)continue;
      currentScanline++;currentMasterCycle=0;rasterCursorX=0;wramRefreshAppliedThisLine=false;hdmaExecutedThisLine=false;irqFiredThisLine=false;ppu.vCounter=(std::uint16_t)(currentScanline&0x1FFu);setMasterCycle(0);
      if(currentScanline==vis){io.vblank=true;if(io.autoJoypad)pollInput();}
      if(currentScanline>=(isPalRegion(regionCode)?312u:262u)){endVblank();beginFrame();}
    }
  }
  bool cpuEventPending(const CpuState&cpu)const{return cpuNmiInterruptPending||(cpuIrqInterruptPending&&!cpu.i);}
  bool serviceCpuEvents(CpuState&cpu,std::uint32_t resumePc){
    if(cpuNmiInterruptPending){cpuNmiInterruptPending=false;nmiServiceCount++;cpu.enterInterrupt(*this,resumePc,false);addCpuInternalCycles(7u);interruptEntryMasterCycles+=42u;std::uint16_t va=cpu.e?0xFFFAu:0xFFEAu;std::uint16_t dst=(std::uint16_t)(read(va)|(read((va+1u)&0xFFFFu)<<8));requestDispatch((std::uint32_t)dst,0xFFFFF5u);return true;}
    if(cpuIrqInterruptPending&&!cpu.i){irqServiceCount++;cpu.enterInterrupt(*this,resumePc,false);addCpuInternalCycles(7u);interruptEntryMasterCycles+=42u;std::uint16_t va=cpu.e?0xFFFEu:0xFFEEu;std::uint16_t dst=(std::uint16_t)(read(va)|(read((va+1u)&0xFFFFu)<<8));requestDispatch((std::uint32_t)dst,0xFFFFF6u);return true;}
    return false;
  }
  void addCpuInternalCycles(unsigned cycles){advanceCpuMasterCycles(cycles*6u);}
  void advanceCpuInstruction(std::uint32_t pc,unsigned cpuCycles,unsigned fetchBytes,std::uint32_t dataAddr,unsigned dataAccesses,std::uint32_t auxAddr,unsigned auxAccesses,unsigned stackAccesses){
    if(!cpuInstructionTraced||lastInstructionPc!=pc){cpuInstructionCount++;}cpuInstructionTraced=false;lastInstructionPc=pc;lastInstructionMasterCycles=0;
    unsigned mc=cpuCycles*6u,codeSpeed=busMasterCycles(pc);if(codeSpeed>6u)mc+=fetchBytes*(codeSpeed-6u);
    if(dataAddr!=NO_TIMING_ADDR&&dataAccesses){unsigned q=busMasterCycles(dataAddr);if(q>6u)mc+=dataAccesses*(q-6u);}
    if(auxAddr!=NO_TIMING_ADDR&&auxAccesses){unsigned q=busMasterCycles(auxAddr);if(q>6u)mc+=auxAccesses*(q-6u);}
    if(stackAccesses){unsigned q=busMasterCycles(0x000100u);if(q>6u)mc+=stackAccesses*(q-6u);}
    advanceCpuMasterCycles(mc);
  }
  void advanceCpuBlockMove(std::uint32_t pc,std::uint32_t bytes,std::uint8_t srcBank,std::uint8_t dstBank){
    if(!cpuInstructionTraced||lastInstructionPc!=pc){cpuInstructionCount++;}cpuInstructionTraced=false;lastInstructionPc=pc;lastInstructionMasterCycles=0;if(!bytes)bytes=0x10000u;
    unsigned codeSpeed=busMasterCycles(pc),srcSpeed=busMasterCycles(std::uint32_t(srcBank)<<16),dstSpeed=busMasterCycles(std::uint32_t(dstBank)<<16);
    std::uint64_t per=42u+(codeSpeed>6u?codeSpeed-6u:0u)+(srcSpeed>6u?srcSpeed-6u:0u)+(dstSpeed>6u?dstSpeed-6u:0u),total=per*bytes;
    while(total){unsigned q=(unsigned)std::min<std::uint64_t>(total,0xFFFFFFFFu);advanceCpuMasterCycles(q);total-=q;}
  }
  void syncPpuBeforeMutation(){if(frameTimingActive&&currentScanline<visibleLines()&&currentMasterCycle<HBLANK_START_MC)renderVisibleUntilMasterCycle(currentScanline,currentMasterCycle);}
  unsigned irqHMasterCycle()const{unsigned h=io.htime&0x1FFu;unsigned mc=h*4u+IRQ_TRIGGER_DELAY_MC;if(h==0u)mc-=4u;if(h>322u)mc+=2u;if(h>326u)mc+=2u;return mc<MASTER_CYCLES_PER_SCANLINE?mc:MASTER_CYCLES_PER_SCANLINE-1u;}
  int irqEventMasterCycle(unsigned line)const{unsigned v=line&0x1FFu;if(io.hIrqEnable&&io.vIrqEnable)return v==(io.vtime&0x1FFu)?(int)irqHMasterCycle():-1;if(io.hIrqEnable)return(int)irqHMasterCycle();if(io.vIrqEnable)return v==(io.vtime&0x1FFu)?(int)IRQ_TRIGGER_DELAY_MC:-1;return-1;}
  unsigned rasterLogicalXFromMasterCycle(unsigned mc)const{if(mc<=IRQ_TRIGGER_DELAY_MC)return 0u;unsigned x=(mc-IRQ_TRIGGER_DELAY_MC)/4u;return std::min(x,256u);}
  unsigned rasterOutputXFromMasterCycle(unsigned mc)const{unsigned x=rasterLogicalXFromMasterCycle(mc);return fbWidth>=512u?std::min(x*2u,fbWidth):std::min(x,fbWidth);}
  void beginScanline(unsigned line){currentScanline=line;irqFiredThisLine=false;rasterCursorX=0;wramRefreshAppliedThisLine=false;hdmaExecutedThisLine=false;ppu.vCounter=(std::uint16_t)(line&0x1FFu);setMasterCycle(0);setMasterCycle(HBLANK_END_MC);}
  bool fireIrqAt(unsigned line,unsigned mc){if(irqFiredThisLine)return false;int ev=irqEventMasterCycle(line);if(ev<0||mc<(unsigned)ev)return false;currentScanline=line;setMasterCycle((unsigned)ev);irqFiredThisLine=true;io.irqPending=true;cpuIrqInterruptPending=true;return true;}
  bool irqAtScanline(unsigned line){beginScanline(line);int ev=irqEventMasterCycle(line);return ev>=0?fireIrqAt(line,(unsigned)ev):false;}
  void beginFrame(){frameTimingActive=true;io.vblank=false;io.nmiPending=false;io.hblank=true;currentScanline=0;currentMasterCycle=0;wramRefreshAppliedThisLine=false;hdmaExecutedThisLine=false;configureFramebuffer();startHdmaFrame(io.hdmaen);const bool replay=applyReplayInput();if(!replay&&io.autoJoypad)pollInput();recordInputFrame();trace.emit(frameCounter,traceRoutine,lastInstructionPc,"input","INPUT",0,io.joy[0],"INPUT");trace.emit(frameCounter,traceRoutine,lastInstructionPc,"input","INPUT",1,io.joy[1],"INPUT");}
  void renderVisibleUntilMasterCycle(unsigned line,unsigned mc){if(line>=visibleLines())return;currentScanline=line;ppu.vCounter=(std::uint16_t)(line&0x1FFu);unsigned end=rasterOutputXFromMasterCycle(mc);if(end>rasterCursorX){ppu.renderOutputSegment(framebuffer,(int)line,rasterCursorX,end,interlaceField?1u:0u);rasterCursorX=end;}setMasterCycle(mc);}
  void finishVisibleLine(unsigned line){if(line>=visibleLines())return;unsigned end=fbWidth;if(end>rasterCursorX){ppu.renderOutputSegment(framebuffer,(int)line,rasterCursorX,end,interlaceField?1u:0u);rasterCursorX=end;}setMasterCycle(HBLANK_START_MC);}
  void renderVisibleLine(unsigned line){beginScanline(line);finishVisibleLine(line);}
  void beginHblank(){setMasterCycle(HBLANK_START_MC);} void endHblank(){setMasterCycle(HBLANK_END_MC);}
  void beginVblank(unsigned line){io.vblank=true;currentScanline=line;beginScanline(line);setMasterCycle(NMI_TRIGGER_MC);io.nmiPending=true;if(io.nmiEnable)cpuNmiInterruptPending=true;if(io.autoJoypad)pollInput();}
  void beginVblank(){beginVblank(visibleLines());}
  void endVblank(){io.vblank=false;frameTimingActive=false;appendFrameHash();appendNativeAuditFrame();frameCounter++;maybeCaptureSpcSnapshot();maybeCaptureNativeScene();hostFrameReady=true;if(ppu.interlace())interlaceField=!interlaceField;else interlaceField=false;}
  void pollInput(){
#ifdef _WIN32
    std::uint16_t j=0;auto kd=[](int k){return (GetAsyncKeyState(k)&0x8000)!=0;};if(kd('X'))j|=0x8000;if(kd('Z'))j|=0x4000;if(kd(VK_SHIFT))j|=0x2000;if(kd(VK_RETURN))j|=0x1000;if(kd(VK_UP))j|=0x0800;if(kd(VK_DOWN))j|=0x0400;if(kd(VK_LEFT))j|=0x0200;if(kd(VK_RIGHT))j|=0x0100;if(kd('A'))j|=0x0080;if(kd('S'))j|=0x0040;if(kd('Q'))j|=0x0020;if(kd('W'))j|=0x0010;
    XINPUT_STATE xs{};if(XInputGetState(0,&xs)==ERROR_SUCCESS){const auto&g=xs.Gamepad;const auto b=g.wButtons;if((b&XINPUT_GAMEPAD_Y)!=0)j|=0x8000;if((b&XINPUT_GAMEPAD_B)!=0)j|=0x4000;if((b&XINPUT_GAMEPAD_BACK)!=0)j|=0x2000;if((b&XINPUT_GAMEPAD_START)!=0)j|=0x1000;if((b&XINPUT_GAMEPAD_DPAD_UP)!=0||g.sThumbLY>9000)j|=0x0800;if((b&XINPUT_GAMEPAD_DPAD_DOWN)!=0||g.sThumbLY<-9000)j|=0x0400;if((b&XINPUT_GAMEPAD_DPAD_LEFT)!=0||g.sThumbLX<-9000)j|=0x0200;if((b&XINPUT_GAMEPAD_DPAD_RIGHT)!=0||g.sThumbLX>9000)j|=0x0100;if((b&XINPUT_GAMEPAD_X)!=0)j|=0x0080;if((b&XINPUT_GAMEPAD_A)!=0)j|=0x0040;if((b&XINPUT_GAMEPAD_LEFT_SHOULDER)!=0)j|=0x0020;if((b&XINPUT_GAMEPAD_RIGHT_SHOULDER)!=0)j|=0x0010;}setJoy1(j);
#endif
  }
#ifdef _WIN32
  static LRESULT CALLBACK wndProc(HWND h,UINT m,WPARAM w,LPARAM l){if(m==WM_CLOSE){DestroyWindow(h);return 0;}if(m==WM_DESTROY){PostQuitMessage(0);return 0;}return DefWindowProc(h,m,w,l);}
  unsigned bestIntegerScale(unsigned srcW,unsigned srcH)const{
    RECT wa{};SystemParametersInfoW(SPI_GETWORKAREA,0,&wa,0);
    unsigned availW=(unsigned)std::max<LONG>(320,(wa.right-wa.left)-80);
    unsigned availH=(unsigned)std::max<LONG>(240,(wa.bottom-wa.top)-100);
    unsigned sx=srcW?availW/srcW:1u,sy=srcH?availH/srcH:1u;
    return std::max(1u,std::min(8u,std::min(sx,sy)));
  }
  void fitClientToIntegerScale(unsigned srcW,unsigned srcH){
    if(!hwnd)return;unsigned sc=bestIntegerScale(srcW,srcH);
    RECT r{0,0,(LONG)(srcW*sc),(LONG)(srcH*sc)};AdjustWindowRect(&r,WS_OVERLAPPEDWINDOW,FALSE);
    SetWindowPos(hwnd,nullptr,0,0,r.right-r.left,r.bottom-r.top,SWP_NOMOVE|SWP_NOZORDER|SWP_NOACTIVATE);
  }
  void initWindow(){hinst=GetModuleHandle(nullptr);WNDCLASSW wc{};wc.lpfnWndProc=wndProc;wc.hInstance=hinst;wc.lpszClassName=L"Forja65NativeWindow";wc.hCursor=LoadCursor(nullptr,IDC_ARROW);wc.hbrBackground=(HBRUSH)GetStockObject(BLACK_BRUSH);RegisterClassW(&wc);RECT r{0,0,1024,896};AdjustWindowRect(&r,WS_OVERLAPPEDWINDOW,FALSE);hwnd=CreateWindowW(wc.lpszClassName,L"Forja65 Native Port - Integer HD",WS_OVERLAPPEDWINDOW|WS_VISIBLE,CW_USEDEFAULT,CW_USEDEFAULT,r.right-r.left,r.bottom-r.top,nullptr,nullptr,hinst,nullptr);fitClientToIntegerScale(256,224);}
  void shutdownWindow(){if(hwnd&&IsWindow(hwnd))DestroyWindow(hwnd);hwnd=nullptr;}
  void paceHostFrame(){if(headless||envFlag("FORJA65_UNCAPPED"))return;auto now=std::chrono::steady_clock::now();auto step=std::chrono::duration_cast<std::chrono::steady_clock::duration>(std::chrono::duration<double>(1.0/hostRefreshHz()));if(!framePacingStarted){nextPresent=now+step;framePacingStarted=true;}else nextPresent+=step;if(nextPresent<now-std::chrono::milliseconds(250))nextPresent=now+step;std::this_thread::sleep_until(nextPresent);}
  void present(){if(headless){const char*e=std::getenv("FORJA65_HEADLESS_FRAMES");unsigned lim=(e&&*e)?(unsigned)std::strtoul(e,nullptr,10):0u;if(lim&&frameCounter>=lim)stopped=true;return;}MSG msg{};while(PeekMessage(&msg,nullptr,0,0,PM_REMOVE)){if(msg.message==WM_QUIT){windowClosed=true;stopped=true;break;}TranslateMessage(&msg);DispatchMessage(&msg);}if(!hwnd||stopped)return;auto& fb=framebuffer;BITMAPINFO bi{};bi.bmiHeader.biSize=sizeof(BITMAPINFOHEADER);bi.bmiHeader.biWidth=(LONG)fbWidth;bi.bmiHeader.biHeight=-(LONG)fbHeight;bi.bmiHeader.biPlanes=1;bi.bmiHeader.biBitCount=32;bi.bmiHeader.biCompression=BI_RGB;RECT rc{};GetClientRect(hwnd,&rc);int cw=std::max<LONG>(1,rc.right-rc.left),ch=std::max<LONG>(1,rc.bottom-rc.top);int sc=std::max(1,std::min(cw/(int)fbWidth,ch/(int)fbHeight));int dw=(int)fbWidth*sc,dh=(int)fbHeight*sc,dx=(cw-dw)/2,dy=(ch-dh)/2;HDC dc=GetDC(hwnd);HBRUSH black=(HBRUSH)GetStockObject(BLACK_BRUSH);FillRect(dc,&rc,black);SetStretchBltMode(dc,COLORONCOLOR);StretchDIBits(dc,dx,dy,dw,dh,0,0,(int)fbWidth,(int)fbHeight,fb.data(),&bi,DIB_RGB_COLORS,SRCCOPY);ReleaseDC(hwnd,dc);paceHostFrame();}
#else
  void initWindow(){} void shutdownWindow(){} void paceHostFrame(){} void present(){const char*e=std::getenv("FORJA65_HEADLESS_FRAMES");unsigned lim=(e&&*e)?(unsigned)std::strtoul(e,nullptr,10):2u;if(lim&&frameCounter>=lim)stopped=true;}
#endif
  static const std::uint8_t* dmaPattern(std::uint8_t mode,std::size_t& n){static const std::uint8_t p0[]={0};static const std::uint8_t p1[]={0,1};static const std::uint8_t p2[]={0,0};static const std::uint8_t p3[]={0,0,1,1};static const std::uint8_t p4[]={0,1,2,3};static const std::uint8_t p5[]={0,1,0,1};static const std::uint8_t p6[]={0,0};static const std::uint8_t p7[]={0,0,1,1};switch(mode&7){case 0:n=1;return p0;case 1:n=2;return p1;case 2:n=2;return p2;case 3:n=4;return p3;case 4:n=4;return p4;case 5:n=4;return p5;case 6:n=2;return p6;default:n=4;return p7;}}
  std::uint8_t getDmaReg(unsigned ch,unsigned r)const{const auto&d=dma[ch&7];switch(r&0xF){case 0:return d.dmap;case 1:return d.bbad;case 2:return d.a1t&0xFF;case 3:return d.a1t>>8;case 4:return d.a1b;case 5:return d.das&0xFF;case 6:return d.das>>8;case 7:return d.dasb;case 8:return d.a2a&0xFF;case 9:return d.a2a>>8;case 0xA:return d.ntrl;default:return 0;}}
  void setDmaReg(unsigned ch,unsigned r,std::uint8_t v){auto&d=dma[ch&7];switch(r&0xF){case 0:d.dmap=v;break;case 1:d.bbad=v;break;case 2:d.a1t=(d.a1t&0xFF00)|v;break;case 3:d.a1t=(d.a1t&0x00FF)|(std::uint16_t(v)<<8);break;case 4:d.a1b=v;break;case 5:d.das=(d.das&0xFF00)|v;break;case 6:d.das=(d.das&0x00FF)|(std::uint16_t(v)<<8);break;case 7:d.dasb=v;break;case 8:d.a2a=(d.a2a&0xFF00)|v;break;case 9:d.a2a=(d.a2a&0x00FF)|(std::uint16_t(v)<<8);break;case 0xA:d.ntrl=v;break;default:break;}}
  void primeHdmaChannel(unsigned ch){ch&=7u;hdmaLines[ch]=0;hdmaEveryLine[ch]=false;hdmaTransfer[ch]=false;dma[ch].a2a=dma[ch].a1t;dma[ch].ntrl=0;hdmaInitialized[ch]=true;}
  void startHdmaFrame(std::uint8_t mask){io.hdmaen=mask;hdmaEnded=0;hdmaActive=mask;for(unsigned ch=0;ch<8;ch++){hdmaInitialized[ch]=false;hdmaLines[ch]=0;hdmaEveryLine[ch]=false;hdmaTransfer[ch]=false;if(mask&(1u<<ch))primeHdmaChannel(ch);}}
  void setHdmaEnable(std::uint8_t mask){io.hdmaen=mask;std::uint8_t requested=(std::uint8_t)(mask&~hdmaEnded);std::uint8_t newly=(std::uint8_t)(requested&~hdmaActive);for(unsigned ch=0;ch<8;ch++)if((newly&(1u<<ch))&&!hdmaInitialized[ch])primeHdmaChannel(ch);hdmaActive=requested;}
  void initializeHdma(std::uint8_t mask){startHdmaFrame(mask);}
  std::uint8_t ppuPortRead(std::uint16_t lo){hwUsage.ppuReads++;rememberFirst(firstPpuPc,lastInstructionPc);if(ppuMode==PpuRuntimeMode::StateOnlyNativeScanout)hwUsage.ppuNativeReads++;else hwUsage.ppuFallbackReads++;return ppu.read(lo);}
  void ppuPortWrite(std::uint16_t lo,std::uint8_t v){hwUsage.ppuWrites++;rememberFirst(firstPpuPc,lastInstructionPc);if(ppuMode==PpuRuntimeMode::StateOnlyNativeScanout)hwUsage.ppuNativeWrites++;else hwUsage.ppuFallbackWrites++;syncPpuBeforeMutation();ppu.write(lo,v);}
  bool nativeBbusRead(std::uint16_t bbus,std::uint8_t&v){if(bbus>=0x2100u&&bbus<=0x213Fu){v=ppuPortRead(bbus);observeBus("read",bbus,v);return true;}if(bbus>=0x2140u&&bbus<=0x2143u){hwUsage.apuReads++;rememberFirst(firstApuPc,lastInstructionPc);v=apu.read(bbus-0x2140u);observeBus("read",bbus,v);return true;}if(bbus==0x2180u){hwUsage.wramReads++;v=ram[io.wramPortAddr&0x1FFFFu];observeBus("read",bbus,v);io.wramPortAddr=(io.wramPortAddr+1)&0x1FFFFu;return true;}return false;}
  bool nativeBbusWrite(std::uint16_t bbus,std::uint8_t v){if(bbus>=0x2100u&&bbus<=0x213Fu){observeBus("write",bbus,v);ppuPortWrite(bbus,v);return true;}if(bbus>=0x2140u&&bbus<=0x2143u){hwUsage.apuWrites++;rememberFirst(firstApuPc,lastInstructionPc);observeBus("write",bbus,v);apu.write(bbus-0x2140u,v);return true;}if(bbus==0x2180u){observeBus("write",bbus,v);hwUsage.wramWrites++;ram[io.wramPortAddr&0x1FFFFu]=v;io.wramPortAddr=(io.wramPortAddr+1)&0x1FFFFu;return true;}return false;}
  void executeHdmaLine(){hdmaExecutedThisLine=true;ForjaTraceContext context(traceRoutine,traceSource,traceRoutine,"HDMA");if(hdmaActive)trace.emit(frameCounter,traceRoutine,lastInstructionPc,"hdma","DMA_REG",0x420Cu,hdmaActive,"HDMA");advanceCpuMasterCycles(DMA_SYNC_MC);hdmaStallMasterCycles+=DMA_SYNC_MC;rememberFirst(firstHdmaPc,lastInstructionPc);for(unsigned ch=0;ch<8;ch++){if(!(hdmaActive&(1u<<ch)))continue;auto&d=dma[ch];if(hdmaLines[ch]==0){std::uint32_t table=(std::uint32_t(d.a1b)<<16)|d.a2a;std::uint8_t desc=(std::uint8_t)read(table);d.a2a++;if(desc==0){hdmaEnded|=(std::uint8_t)(1u<<ch);hdmaActive&=(std::uint8_t)~(1u<<ch);hdmaTransfer[ch]=false;continue;}hdmaEveryLine[ch]=(desc&0x80u)!=0;hdmaLines[ch]=(desc&0x7Fu)?(desc&0x7Fu):128u;hdmaTransfer[ch]=true;if(d.dmap&0x40){std::uint32_t p=(std::uint32_t(d.a1b)<<16)|d.a2a;d.das=(std::uint16_t)(read(p)|(read(p+1)<<8));d.a2a+=2;}}
    if(hdmaTransfer[ch]){std::size_t pn=0;const auto*pat=dmaPattern(d.dmap,pn);bool indirect=(d.dmap&0x40u)!=0,reverse=(d.dmap&0x80u)!=0;std::uint32_t src=indirect?((std::uint32_t(d.dasb)<<16)|d.das):((std::uint32_t(d.a1b)<<16)|d.a2a);for(std::size_t k=0;k<pn;k++){hwUsage.hdmaBytes++;std::uint16_t bbus=(std::uint16_t)(0x2100u|((d.bbad+pat[k])&0xFFu));bool nativeDone=false;if(reverse){std::uint8_t v=0;if(nativeDmaEnabled&&nativeBbusRead(bbus,v)){write8(src,v);nativeDone=true;}else{v=(std::uint8_t)read(bbus);write8(src,v);}}else{std::uint8_t v=(std::uint8_t)read(src);if(nativeDmaEnabled&&nativeBbusWrite(bbus,v))nativeDone=true;else write8(bbus,v);}if(nativeDone)hwUsage.hdmaNativeBytes++;else hwUsage.hdmaFallbackBytes++;src=(src+1)&0xFFFFFFu;advanceCpuMasterCycles(8u);hdmaStallMasterCycles+=8u;}if(indirect)d.das=(std::uint16_t)src;else d.a2a=(std::uint16_t)src;}
    if(hdmaLines[ch]){hdmaLines[ch]--;}if(hdmaLines[ch]==0)hdmaTransfer[ch]=true;else hdmaTransfer[ch]=hdmaEveryLine[ch];unsigned left=hdmaLines[ch]==128u?0u:(hdmaLines[ch]&0x7Fu);d.ntrl=(std::uint8_t)((hdmaEveryLine[ch]?0x80u:0u)|left);}}
  std::uint32_t read(std::uint32_t a){const auto v=readBus(a);observeBus("read",a,v);return v;}
  std::uint32_t readBus(std::uint32_t a){a&=0xFFFFFF;std::uint16_t lo=a&0xFFFF;if(ioBank(a)){if(lo>=0x2100&&lo<=0x213F)return ppuPortRead(lo);if(lo>=0x2140&&lo<=0x2143){hwUsage.apuReads++;rememberFirst(firstApuPc,lastInstructionPc);return apu.read(lo-0x2140);}hwUsage.ioReads++;if(lo==0x2180){hwUsage.wramReads++;auto v=ram[io.wramPortAddr&0x1FFFFu];io.wramPortAddr=(io.wramPortAddr+1)&0x1FFFFu;return v;}if(lo==0x4016)return io.readJoySerial(0);if(lo==0x4017)return io.readJoySerial(1);if(lo==0x4200)return io.nmitimen;if(lo==0x4201||lo==0x4213)return io.wrio;if(lo==0x420B)return io.mdmaen;if(lo==0x420C)return io.hdmaen;if(lo==0x420D)return io.memsel;if(lo==0x4210){auto v=(std::uint8_t)(io.nmiPending?0x80:0);io.nmiPending=false;return v;}if(lo==0x4211){auto v=(std::uint8_t)(io.irqPending?0x80:0);io.irqPending=false;cpuIrqInterruptPending=false;return v;}if(lo==0x4212)return (io.vblank?0x80:0)|(io.hblank?0x40:0);if(lo==0x4214)return io.quotient&0xFF;if(lo==0x4215)return io.quotient>>8;if(lo==0x4216)return io.remainder&0xFF;if(lo==0x4217)return io.remainder>>8;if(lo>=0x4218&&lo<=0x421F){unsigned p=(lo-0x4218)>>1;return (lo&1)?(io.joy[p]>>8):(io.joy[p]&0xFF);}if(lo>=0x4300&&lo<=0x437F)return getDmaReg((lo-0x4300)>>4,lo&0xF);}auto wo=wramOffset(a);if(wo!=(std::size_t)-1){hwUsage.wramReads++;return ram[wo];}auto so=sramOffset(a);if(so!=(std::size_t)-1){hwUsage.sramReads++;return sram[so];}if(cartChipAddress(a)){hwUsage.cartChipReads++;return unresolvedCartChipRead(a);}auto ro=romOffset(a);if(ro!=(std::size_t)-1){hwUsage.romReads++;rememberFirst(firstRomPc,lastInstructionPc);markRomRead(ro);std::uint8_t nv=0;if(nativeRom.read(ro,nv)){hwUsage.romNativeReads++;return nv;}if(!cart.empty()&&ro<cart.size()){hwUsage.romFallbackReads++;return cart[ro];}std::ofstream miss("forja65-native-rom-missing.txt",std::ios::app);if(miss)miss<<std::hex<<ro<<" snes="<<a<<" pc="<<lastInstructionPc<<"\\n";throw std::runtime_error("native ROM pack sem offset 0x"+([&](){std::ostringstream q;q<<std::hex<<ro;return q.str();})());}return 0;}
  std::uint32_t readW(std::uint32_t a,int w){std::uint32_t v=read(a);if(w==16)v|=read((a+1)&0xFFFFFF)<<8;return v;} std::uint32_t read24(std::uint32_t a){return read(a)|(read((a+1)&0xFFFFFF)<<8)|(read((a+2)&0xFFFFFF)<<16);} std::uint16_t read16BankWrap(std::uint32_t a){a&=0xFFFFFFu;auto b=(a&0xFF0000u)|((a+1u)&0xFFFFu);return(std::uint16_t)(read(a)|(read(b)<<8));}
  void executeDma(std::uint8_t mask){ForjaTraceContext context(traceRoutine,traceSource,traceRoutine,"DMA");trace.emit(frameCounter,traceRoutine,lastInstructionPc,"dma","DMA_REG",0x420Bu,mask,"DMA");io.mdmaen=mask;rememberFirst(firstDmaPc,lastInstructionPc);for(unsigned ch=0;ch<8;ch++)if(mask&(1u<<ch)){auto&d=dma[ch];advanceCpuMasterCycles(8u);dmaStallMasterCycles+=8u;std::uint32_t count=d.das?d.das:0x10000u,src=(std::uint32_t(d.a1b)<<16)|d.a1t;bool reverse=d.dmap&0x80,fixed=(d.dmap&0x08)!=0,decrement=(d.dmap&0x10)!=0;std::size_t pn=0;const auto*pat=dmaPattern(d.dmap,pn);for(std::uint32_t k=0;k<count;k++){hwUsage.dmaBytes++;std::uint16_t bbus=(std::uint16_t)(0x2100u|((d.bbad+pat[k%pn])&0xFFu));bool nativeDone=false;if(reverse){std::uint8_t v=0;if(nativeDmaEnabled&&nativeBbusRead(bbus,v)){write8(src,v);nativeDone=true;}else{v=(std::uint8_t)read(bbus);write8(src,v);}}else{auto v=(std::uint8_t)read(src);if(nativeDmaEnabled&&nativeBbusWrite(bbus,v))nativeDone=true;else write8(bbus,v);}if(nativeDone)hwUsage.dmaNativeBytes++;else hwUsage.dmaFallbackBytes++;if(!fixed)src=(src&0xFF0000u)|((src+(decrement?0xFFFFu:1u))&0xFFFFu);advanceCpuMasterCycles(8u);dmaStallMasterCycles+=8u;}d.a1t=src&0xFFFF;d.a1b=(src>>16)&0xFF;d.das=0;}io.mdmaen=0;}
  void write8(std::uint32_t a,std::uint8_t v){observeBus("write",a,v);a&=0xFFFFFF;std::uint16_t lo=a&0xFFFF;if(ioBank(a)){if(lo>=0x2100&&lo<=0x213F){ppuPortWrite(lo,v);return;}if(lo>=0x2140&&lo<=0x2143){hwUsage.apuWrites++;rememberFirst(firstApuPc,lastInstructionPc);apu.write(lo-0x2140,v);return;}hwUsage.ioWrites++;if(lo==0x2180){hwUsage.wramWrites++;ram[io.wramPortAddr&0x1FFFFu]=v;io.wramPortAddr=(io.wramPortAddr+1)&0x1FFFFu;return;}if(lo==0x2181){io.wramPortAddr=(io.wramPortAddr&0x1FF00u)|v;return;}if(lo==0x2182){io.wramPortAddr=(io.wramPortAddr&0x100FFu)|(std::uint32_t(v)<<8);return;}if(lo==0x2183){io.wramPortAddr=(io.wramPortAddr&0x0FFFFu)|(std::uint32_t(v&1u)<<16);return;}if(lo==0x4016){io.setJoyStrobe((v&1u)!=0);return;}if(lo==0x4200){bool enabled=io.nmiEnable;io.setNmitimen(v);if(!(v&0x30u)){io.irqPending=false;cpuIrqInterruptPending=false;}if(!enabled&&io.nmiEnable&&io.nmiPending&&io.vblank)cpuNmiInterruptPending=true;return;}if(lo==0x4201){io.wrio=v;return;}if(lo==0x4202){io.wrmpya=v;return;}if(lo==0x4203){io.multiply(v);return;}if(lo==0x4204){io.wrdiv=(io.wrdiv&0xFF00u)|v;return;}if(lo==0x4205){io.wrdiv=(io.wrdiv&0x00FFu)|(std::uint16_t(v)<<8);return;}if(lo==0x4206){io.divide(v);return;}if(lo==0x4207){io.htime=(io.htime&0x100u)|v;return;}if(lo==0x4208){io.htime=(io.htime&0x0FFu)|((std::uint16_t)(v&1u)<<8);return;}if(lo==0x4209){io.vtime=(io.vtime&0x100u)|v;return;}if(lo==0x420A){io.vtime=(io.vtime&0x0FFu)|((std::uint16_t)(v&1u)<<8);return;}if(lo==0x420B){executeDma(v);return;}if(lo==0x420C){setHdmaEnable(v);return;}if(lo==0x420D){io.memsel=v;return;}if(lo>=0x4300&&lo<=0x437F){setDmaReg((lo-0x4300)>>4,lo&0xF,v);return;}}auto wo=wramOffset(a);if(wo!=(std::size_t)-1){hwUsage.wramWrites++;ram[wo]=v;return;}auto so=sramOffset(a);if(so!=(std::size_t)-1){hwUsage.sramWrites++;sram[so]=v;sramDirty=true;return;}if(cartChipAddress(a)){hwUsage.cartChipWrites++;unresolvedCartChipWrite(a,v);return;}/* ROM e regioes sem RAM sao somente leitura/ignoradas nesta ponte. */}
  void write(std::uint32_t a,std::uint32_t v,int w){write8(a,(std::uint8_t)(v&0xFF));if(w==16)write8((a+1)&0xFFFFFF,(std::uint8_t)((v>>8)&0xFF));}
  void traceInstruction(std::uint32_t pc,const CpuState& cpu,unsigned opcode=256u){
    if(hostFrameReady){hostFrameReady=false;present();if(stopped)throw std::runtime_error("FORJA65_HEADLESS_COMPLETE");}
    lastInstructionPc=pc&0xFFFFFFu; cpuInstructionCount++;cpuInstructionTraced=true;trace.emit(frameCounter,traceRoutine,lastInstructionPc,"instruction","CPU",lastInstructionPc,opcode,traceSource);
    cpuTrace[cpuTracePos]={pc&0xFFFFFFu,cpu.a,cpu.x,cpu.y,cpu.s,cpu.d,cpu.db,cpu.pb,cpu.packP(),cpu.e,cpu.m8,cpu.x8,cpu.c};
    cpuTracePos=(cpuTracePos+1)%cpuTrace.size(); if(cpuTraceCount<cpuTrace.size())cpuTraceCount++;
    if(instructionWatchdogLimit&&cpuInstructionCount>=instructionWatchdogLimit){dumpCpuTrace("instruction-watchdog");throw std::runtime_error("watchdog de instrucoes atingido");}
  }
  void dumpCpuTrace(const std::string& reason)const{
    std::ofstream f("forja65-crash-trace.txt",std::ios::trunc); if(!f)return;
    f<<"FORJA65 RUNTIME TRACE\\nreason="<<reason<<"\\nframe="<<frameCounter<<" instruction="<<cpuInstructionCount<<" scanline="<<currentScanline<<" master_cycle="<<currentMasterCycle<<"\\n";
    f<<std::hex<<"wram_004a_0052="; for(unsigned a=0x4A;a<=0x52;a++)f<<(unsigned)ram[a]<<(a==0x52?'\\n':' ');
    f<<"apu_in="<<(unsigned)apu.spc.portOut[0]<<' '<<(unsigned)apu.spc.portOut[1]<<' '<<(unsigned)apu.spc.portOut[2]<<' '<<(unsigned)apu.spc.portOut[3]<<" apu_out="<<(unsigned)apu.spc.portIn[0]<<' '<<(unsigned)apu.spc.portIn[1]<<' '<<(unsigned)apu.spc.portIn[2]<<' '<<(unsigned)apu.spc.portIn[3]<<"\\n";
    f<<std::dec<<"native_return_depth="<<nativeReturns.size()<<"\\n";
    std::size_t st=(cpuTracePos+cpuTrace.size()-cpuTraceCount)%cpuTrace.size();
    for(std::size_t k=0;k<cpuTraceCount;k++){const auto&e=cpuTrace[(st+k)%cpuTrace.size()];f<<std::hex<<e.pc<<" A="<<e.a<<" X="<<e.x<<" Y="<<e.y<<" S="<<e.s<<" D="<<e.d<<" DB="<<(unsigned)e.db<<" PB="<<(unsigned)e.pb<<" P="<<(unsigned)e.p<<" E="<<e.e<<" M="<<e.m8<<" X8="<<e.x8<<" C="<<e.c<<"\\n";}
  }
  void requestDispatch(std::uint32_t target,std::uint32_t from){dispatchPending=true;dispatchTarget=target&0xFFFFFFu;dispatchFrom=from&0xFFFFFFu;}
  void pushNativeReturn(std::uint32_t t,bool longCall){nativeReturns.push_back({t&0xFFFFFFu,longCall});}
  bool nativeReturnMatches(std::uint32_t t,bool longCall)const{return!nativeReturns.empty()&&nativeReturns.back().target==(t&0xFFFFFFu)&&nativeReturns.back().longCall==longCall;}
  void popNativeReturn(){if(!nativeReturns.empty())nativeReturns.pop_back();}
  static bool fileHasExactLine(const std::string&path,const std::string&line){std::ifstream in(path);std::string q;while(std::getline(in,q))if(q==line)return true;return false;}
  void appendRuntimeHint(std::uint32_t pc,std::uint32_t t,const CpuState&cpu,const char*kind){std::ostringstream ss;ss<<"rom="<<cartHashHex()<<" target="<<std::hex<<(t&0xFFFFFFu)<<" from="<<(pc&0xFFFFFFu)<<" kind="<<kind<<" e="<<std::dec<<(cpu.e?1:0)<<" m="<<(cpu.m8?1:0)<<" x="<<(cpu.x8?1:0)<<" c="<<(cpu.c?1:0);const auto line=ss.str();for(const char*path:{"forja65-oracle-hints.txt","forja65-runtime-hints.txt"})if(!fileHasExactLine(path,line)){std::ofstream h(path,std::ios::app);if(h)h<<line<<"\\n";}std::ofstream obs("forja65-oracle-observations.log",std::ios::app);if(obs)obs<<line<<" frame="<<frameCounter<<" instruction="<<cpuInstructionCount<<" pb="<<std::hex<<(unsigned)cpu.pb<<" db="<<(unsigned)cpu.db<<" s="<<cpu.s<<" d="<<cpu.d<<"\\n";}
  [[noreturn]] void unresolvedReturn(std::uint32_t pc,std::uint32_t t,const CpuState&cpu,const char*kind="STACK-RETURN"){std::ofstream f("forja65-unresolved-returns.txt",std::ios::app);if(f)f<<std::hex<<pc<<" -> "<<t<<"\\n";appendRuntimeHint(pc,t,cpu,kind);dumpCpuTrace("unresolved-return");throw std::runtime_error("retorno 65C816 nao corresponde ao frame C++ recompilado");}
  [[noreturn]] void unsupported(std::uint32_t pc,std::uint32_t op){throw std::runtime_error("opcode nao recompilado: pc="+std::to_string(pc)+" op="+std::to_string(op));} [[noreturn]] void partial(std::uint32_t pc,const std::string& what){throw std::runtime_error("recurso parcial em pc="+std::to_string(pc)+": "+what);} [[noreturn]] void unresolvedState(std::uint32_t from,std::uint32_t pc,bool e,bool m,bool x,bool c){std::ofstream f("forja65-unresolved-state.txt",std::ios::app);if(f)f<<std::hex<<from<<" -> "<<pc<<" e="<<e<<" m="<<m<<" x="<<x<<" c="<<c<<"\\n";/* legacy runtime hint shape: kind=STATE ; c="<<(c?1:0) */ CpuState observed;observed.e=e;observed.m8=m;observed.x8=x;observed.c=c;observed.pb=(std::uint8_t)(pc>>16);appendRuntimeHint(from,pc,observed,"STATE");dumpCpuTrace("unresolved-state");throw std::runtime_error("estado M/X/C nao recompilado em pc="+std::to_string(pc));} [[noreturn]] void unresolvedFlow(std::uint32_t pc,std::uint32_t target,const CpuState&cpu){appendRuntimeHint(pc,target,cpu,"FLOW");unresolvedFlow(pc,target);} [[noreturn]] void unresolvedFlow(std::uint32_t pc,std::uint32_t target){std::ofstream f("forja65-unresolved-targets.txt",std::ios::app);if(f)f<<std::hex<<pc<<" -> "<<target<<"\\n";dumpCpuTrace("unresolved-flow");throw std::runtime_error("fluxo CFG nao resolvido em pc="+std::to_string(pc)+" target="+std::to_string(target));}
};
inline std::uint16_t forja65_read16_bank0(SnesRuntime& hw,std::uint16_t p){return(std::uint16_t)(hw.read(p)|(hw.read((std::uint16_t)(p+1))<<8));}
inline std::uint32_t CpuState::addressDpIndirectX(SnesRuntime& hw,std::uint32_t q)const{std::uint16_t p=(std::uint16_t)(d+q+x),base=forja65_read16_bank0(hw,p);return((std::uint32_t)db<<16)|base;}
inline std::uint32_t CpuState::addressDpIndirect(SnesRuntime& hw,std::uint32_t q)const{std::uint16_t p=(std::uint16_t)(d+q),base=forja65_read16_bank0(hw,p);return((std::uint32_t)db<<16)|base;}
inline std::uint32_t CpuState::addressDpIndirectY(SnesRuntime& hw,std::uint32_t q)const{std::uint16_t p=(std::uint16_t)(d+q),base=forja65_read16_bank0(hw,p);return((std::uint32_t)db<<16)|((base+y)&0xFFFFu);}
inline std::uint32_t CpuState::addressDpLong(SnesRuntime& hw,std::uint32_t q)const{std::uint16_t p=(std::uint16_t)(d+q);return(hw.read(p)|(hw.read((std::uint16_t)(p+1))<<8)|(hw.read((std::uint16_t)(p+2))<<16))&0xFFFFFFu;}
inline std::uint32_t CpuState::addressDpLongY(SnesRuntime& hw,std::uint32_t q)const{return(addressDpLong(hw,q)+y)&0xFFFFFFu;}
inline std::uint32_t CpuState::addressStackIndirectY(SnesRuntime& hw,std::uint32_t q)const{std::uint16_t p=(std::uint16_t)(s+q),base=forja65_read16_bank0(hw,p);return((std::uint32_t)db<<16)|((base+y)&0xFFFFu);}
inline void CpuState::incMem(SnesRuntime& hw,std::uint32_t addr,int w){std::uint32_t mask=w==8?0xFF:0xFFFF,v=(hw.readW(addr,w)+1)&mask;hw.write(addr,v,w);nz((std::uint16_t)v,w);}
inline void CpuState::decMem(SnesRuntime& hw,std::uint32_t addr,int w){std::uint32_t mask=w==8?0xFF:0xFFFF,v=(hw.readW(addr,w)-1)&mask;hw.write(addr,v,w);nz((std::uint16_t)v,w);}
inline void CpuState::aslMem(SnesRuntime& hw,std::uint32_t addr,int w){std::uint32_t mask=w==8?0xFF:0xFFFF,sign=w==8?0x80:0x8000,old=hw.readW(addr,w)&mask;c=(old&sign)!=0;std::uint32_t r=(old<<1)&mask;hw.write(addr,r,w);nz((std::uint16_t)r,w);}
inline void CpuState::lsrMem(SnesRuntime& hw,std::uint32_t addr,int w){std::uint32_t mask=w==8?0xFF:0xFFFF,old=hw.readW(addr,w)&mask;c=(old&1u)!=0;std::uint32_t r=(old>>1)&mask;hw.write(addr,r,w);nz((std::uint16_t)r,w);}
inline void CpuState::rolMem(SnesRuntime& hw,std::uint32_t addr,int w){std::uint32_t mask=w==8?0xFF:0xFFFF,sign=w==8?0x80:0x8000,old=hw.readW(addr,w)&mask,r=((old<<1)|(c?1u:0u))&mask;c=(old&sign)!=0;hw.write(addr,r,w);nz((std::uint16_t)r,w);}
inline void CpuState::rorMem(SnesRuntime& hw,std::uint32_t addr,int w){std::uint32_t mask=w==8?0xFF:0xFFFF,sign=w==8?0x80:0x8000,old=hw.readW(addr,w)&mask,r=((old>>1)|(c?sign:0u))&mask;c=(old&1u)!=0;hw.write(addr,r,w);nz((std::uint16_t)r,w);}
inline void CpuState::tsb(SnesRuntime& hw,std::uint32_t addr,int w){std::uint32_t mask=w==8?0xFF:0xFFFF,mem=hw.readW(addr,w)&mask,av=a&mask;z=(mem&av)==0;hw.write(addr,mem|av,w);}
inline void CpuState::trb(SnesRuntime& hw,std::uint32_t addr,int w){std::uint32_t mask=w==8?0xFF:0xFFFF,mem=hw.readW(addr,w)&mask,av=a&mask;z=(mem&av)==0;hw.write(addr,mem&(~av&mask),w);}
inline void CpuState::push8Value(SnesRuntime& hw,std::uint8_t b){std::uint32_t a=e?(0x100|(s&0xFF)):s;hw.write(a,b,8);s=e?(0x100|((s-1)&0xFF)):(std::uint16_t)(s-1);}
inline std::uint8_t CpuState::peekStack8(SnesRuntime& hw,unsigned depth)const{std::uint16_t sp=e?(std::uint16_t)(0x100|((s+depth)&0xFF)):(std::uint16_t)(s+depth);return(std::uint8_t)hw.read(sp);}
inline std::uint8_t CpuState::pop8Value(SnesRuntime& hw){s=e?(std::uint16_t)(0x100|((s+1)&0xFF)):(std::uint16_t)(s+1);return(std::uint8_t)hw.read(e?(0x100|(s&0xFF)):s);}
inline void CpuState::push16Value(SnesRuntime& hw,std::uint16_t v){push8Value(hw,(std::uint8_t)(v>>8));push8Value(hw,(std::uint8_t)v);}
inline std::uint16_t CpuState::peekStack16(SnesRuntime& hw)const{return(std::uint16_t)(peekStack8(hw,1)|(peekStack8(hw,2)<<8));}
inline std::uint16_t CpuState::pop16Value(SnesRuntime& hw){std::uint16_t lo=pop8Value(hw),hi=pop8Value(hw);return(std::uint16_t)(lo|(hi<<8));}
inline void CpuState::enterInterrupt(SnesRuntime& hw,std::uint32_t resumePc,bool software){resumePc&=0xFFFFFFu;if(!e)push8Value(hw,pb);push16Value(hw,(std::uint16_t)(resumePc&0xFFFFu));std::uint8_t p=packP();if(e){p|=0x20u;if(software)p|=0x10u;else p&=(std::uint8_t)~0x10u;}push8Value(hw,p);i=true;decimalMode=false;pb=0;}
inline std::uint32_t CpuState::returnInterrupt(SnesRuntime& hw){unpackP(pop8Value(hw));std::uint16_t pc=pop16Value(hw);std::uint8_t bank=e?0:pop8Value(hw);pb=e?0:bank;return (std::uint32_t(pb)<<16)|pc;}
inline void CpuState::blockMove(SnesRuntime& hw,std::uint8_t dst,std::uint8_t src,bool dec){db=dst;for(;;){std::uint32_t sa=((std::uint32_t)src<<16)|x,da=((std::uint32_t)dst<<16)|y;hw.write(da,hw.read(sa),8);if(x8){x=(std::uint16_t)((x&0xFF00u)|((x+(dec?-1:1))&0xFFu));y=(std::uint16_t)((y&0xFF00u)|((y+(dec?-1:1))&0xFFu));}else{x=(std::uint16_t)(x+(dec?-1:1));y=(std::uint16_t)(y+(dec?-1:1));}a=(std::uint16_t)(a-1);if(a==0xFFFFu)break;}}
inline void CpuState::push(const std::string& what,SnesRuntime& hw){auto p8=[&](std::uint8_t v){std::uint32_t a=e?(0x100|(s&0xFF)):s;hw.write(a,v,8);s=e?(0x100|((s-1)&0xFF)):(std::uint16_t)(s-1);};auto p16=[&](std::uint16_t v){p8((v>>8)&0xFF);p8(v&0xFF);};if(what=="PHA"){if(m8)p8(a&0xFF);else p16(a);}else if(what=="PHX"){if(x8)p8(x&0xFF);else p16(x);}else if(what=="PHY"){if(x8)p8(y&0xFF);else p16(y);}else if(what=="PHP")p8(packP());else if(what=="PHB")p8(db);else if(what=="PHK")p8(pb);else if(what=="PHD")p16(d);}
inline void CpuState::pop(const std::string& what,SnesRuntime& hw){auto g8=[&](){s=e?(0x100|((s+1)&0xFF)):(std::uint16_t)(s+1);std::uint32_t a=e?(0x100|(s&0xFF)):s;return(std::uint8_t)hw.read(a);};auto g16=[&](){std::uint16_t lo=g8(),hi=g8();return(std::uint16_t)(lo|(hi<<8));};if(what=="PLA"){if(m8)setA(g8(),8);else setA(g16(),16);}else if(what=="PLX"){if(x8)setX(g8(),8);else setX(g16(),16);}else if(what=="PLY"){if(x8)setY(g8(),8);else setY(g16(),16);}else if(what=="PLP")unpackP(g8());else if(what=="PLB"){db=g8();nz(db,8);}else if(what=="PLD"){d=g16();nz(d,16);}}
`;}
function reportText(a){
  const lines=[`FORJA65 ${VERSION} - RELATORIO DE PORT`,``,`ROM: ${a.title}`,`Mapper: ${a.mapping}`,`Reset: $${hex(a.resetPc,6)}`,`Tamanho: ${a.romSize} bytes`,`Copier header: ${a.copierHeader?'sim':'nao'}`,`Tipo de cartucho: $${hex(a.romType||0,2)}`,`SRAM: ${a.sramBytes||0} bytes${a.hasBattery?' + bateria':''}`,`Coprocessador: ${a.coprocessor||'NONE'}`,``,`CPU 65C816 - CFG por vetores`,`Decodificadas (enderecos unicos): ${a.decoded}`,`Instrucoes traduziveis diretamente: ${a.native}`,`Parciais: ${a.partial}`,`Nao suportadas: ${a.unsupported}`,`Cobertura de traducao do CFG descoberto: ${a.nativeRatio.toFixed(1)}%`,`Reconhecidas no CFG descoberto (inclui parcial): ${a.recognizedRatio.toFixed(1)}%`,``,`Entradas de sistema`,`Vetores/entradas validas: ${a.cfgEntryPoints}`];
  for(const e of a.entryPoints)lines.push(`- ${e.name}: vetor $${hex(e.vector,4)} -> $${hex(e.target,6)}`);
  lines.push(``,`CFG estatico/dinamico`,`Rotinas: ${a.cfgFunctions}`,`Variantes de entrada M/X: ${a.cfgFunctionVariants}`,`Enderecos com multiplas variantes M/X: ${a.stateVariantAddressCount}`,`Blocos: ${a.cfgBlocks}`,`Arestas: ${a.cfgEdges}`,`Chamadas/vetores: ${a.cfgCalls}`,`Return-sites estaticos despachaveis: ${(a.staticReturnTargets||[]).length}`,``,`Video/Hardware`,`Renderer: ${a.renderer}`,`HDMA: ${a.hdma}`,`APU bridge: ${a.apuBridge}`,`Hardware de boot: ${a.bootHardware}`,`Acessos ja traduzidos: ${a.hardwareNative}`,`Acessos ainda pendentes: ${a.hardwarePending}`,``,`STATUS: ${a.status}`,``,`Problemas/avisos:`);
  lines.push('- A porcentagem acima mede somente o CFG descoberto estaticamente/runtime-hints; nao significa porcentagem do jogo completo.');
  if(!a.issues.length)lines.push('- Nenhum bloqueio detectado no CFG analisado. Isso ainda nao garante compatibilidade do jogo inteiro.');
  for(const q of a.issues.slice(0,400))lines.push(`- ${q.pc===null?'':('$'+hex(q.pc,6)+' ')}[${q.kind}] ${q.detail}${(q.occurrences||1)>1?' (x'+q.occurrences+' variantes)':''}`);
  lines.push('', 'Catalogo de sintaxe 65C816: 256/256 opcodes.', '', 'Base acumulada ate v0.3.20:',
    '- Dispatcher consciente de mirrors/aliases de ROM: enderecos SNES diferentes que apontam para o mesmo offset da ROM reutilizam o mesmo codigo recompilado.',
    '- O PB (Program Bank) agora e sincronizado somente na entrada real do dispatcher, preservando o banco efetivamente executado em aliases HiROM/LoROM.',
    '- Regras E/M/X, XCE, REP/SEP e stack do 65C816 foram corrigidas para respeitar melhor o modo de emulacao e a largura real dos registradores.',
    '- Retornos para codigo adjacente a RTS/RTL recebem uma varredura conservadora, cobrindo rotinas que nao aparecem como call-sites estaticos.',
    '- O runtime APU agora executa o IPL e um interpretador SPC700 completo de 256 opcodes; as portas $2140-$2143 deixam de ser apenas ACK simulado.',
    '- Vetores NMI/IRQ nativos sao analisados nas quatro combinacoes M/X para aceitar entradas validas com larguras diferentes em tempo de execucao.',
    '- Ponteiros longos montados em RAM podem ser descobertos por dataflow local mesmo quando LOAD e STORE nao sao imediatamente adjacentes.',
    '- Jump tables indexadas do padrao AND/LSR/TAX/JMP (table,X) podem ter a faixa inferida e os destinos precompilados.',
    '- Tabelas inline ASL/TAX/JMP (table,X) agora usam o menor handler valido para fechar estruturalmente a tabela, sem inventar limite runtime de X.',
    '- A retomada por endereco recompilado, stack/retornos reais, runtime hints, ring trace/watchdog e build C++ fragmentado continuam ativos.', '', 'Migracao host:',
    '- CPU traduzida e hardware virtual continuam como referencia. Apenas rotinas host substituidas contam como nativas.',
    '- Trace, profiles e native-map permitem escolher a proxima rotina com evidencia.',
    '- Trampolins PEI+RTS com base 16-bit e indice baixo derivado por mascara/shift agora sao descobertos estaticamente.', '', 'Limitacoes atuais:',
    '- Trampolins de stack mais complexos que nao possam ser demonstrados pelo dataflow conservador ainda podem exigir runtime-hints.',
    '- Destinos dinamicos que nao podem ser demonstrados estaticamente continuam gerando forja65-runtime-hints.txt e forja65-crash-trace.txt.',
    '- DSP-1 de cartucho ainda nao esta implementado; jogos que dependem desse coprocessador continuam bloqueados quando o alcancam.',
    '- O backend DSP/BRR e funcional, mas ainda nao pretende reproduzir todos os detalhes analogicos/timing do S-DSP real.',
    '- cart-data.bin ainda preserva dados brutos do cartucho; a separacao completa de assets nativos continua futura.');
  return lines.join('\r\n');
}
function cppCond(m){return {BEQ:'cpu.z',BNE:'!cpu.z',BCC:'!cpu.c',BCS:'cpu.c',BMI:'cpu.n',BPL:'!cpu.n',BVC:'!cpu.v',BVS:'cpu.v'}[m]||'false';}
function cppLabel(pc){return 'L_'+hex(pc,6);}
function cppStateSuffix(s){return 'E'+(s.emulation?1:0)+'M'+(s.m8?1:0)+'X'+(s.x8?1:0)+'C'+(s.carry===null?'Q':s.carry?1:0);}
function cppFn(pc,state){return 'sub_'+hex(pc,6)+'_'+cppStateSuffix(state);}
function cppStatePred(s){return `cpu.e==${s.emulation?'true':'false'} && cpu.m8==${s.m8?'true':'false'} && cpu.x8==${s.x8?'true':'false'}`+(s.carry===null?'':` && cpu.c==${s.carry?'true':'false'}`);}
function generateVariantBody(i,pcs,knownTargets){
  const n=nextPc(i),t=i.flowTarget;let out=`    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x${hex(i.pc&0xFFFF,4)}u,cpu,0x${hex(i.opcode,2)}u);\n`+emitInstructionTiming(i);
  if(isCondBranch(i.mnemonic)&&t!==null){
    out+=`    // $${hex(i.pc,6)} ${i.mnemonic} -> $${hex(t,6)}\n`;
    const branchPenalty=1+((i.stateIn.emulation&&timingBranchPageCross(i))?1:0);
    out+=pcs.has(t)?`    if (${cppCond(i.mnemonic)}) { hw.addCpuInternalCycles(${branchPenalty}u); goto ${cppLabel(t)}; }\n`:`    if (${cppCond(i.mnemonic)}) { hw.addCpuInternalCycles(${branchPenalty}u); hw.unresolvedFlow(0x${hex(i.pc,6)}u,0x${hex(t,6)}u,cpu); }\n`;
    out+=pcs.has(n)?`    goto ${cppLabel(n)};\n`:`    return;\n`;return out;
  }
  if(isUncondBranch(i.mnemonic)&&t!==null){out+=`    // $${hex(i.pc,6)} ${i.mnemonic} -> $${hex(t,6)}\n`;if(i.mnemonic==='BRA'&&i.stateIn.emulation&&timingBranchPageCross(i))out+=`    hw.addCpuInternalCycles(1u); // penalidade de page-cross em emulacao\n`;out+=pcs.has(t)?`    goto ${cppLabel(t)};\n`:`    hw.unresolvedFlow(0x${hex(i.pc,6)}u,0x${hex(t,6)}u,cpu); return;\n`;return out;}
  if((i.mnemonic==='BRK'||i.mnemonic==='COP')&&t!==null){out+=`    cpu.enterInterrupt(hw,(std::uint32_t(cpu.pb)<<16)|0x${hex(n&0xFFFF,4)}u,true);\n    hw.requestDispatch(0x${hex(t,6)}u,0x${hex(i.pc,6)}u);return;\n`;return out;}
  if(isDirectCall(i)&&t!==null){out+=`    // $${hex(i.pc,6)} ${i.mnemonic} -> $${hex(t,6)} stack real\n`;const lc=i.mnemonic==='JSL',raw=(i.pc+i.size-1)&0xFFFF,retLo=(i.pc+i.size)&0xFFFF;const targetExpr=lc?`0x${hex(t,6)}u`:`((std::uint32_t(cpu.pb)<<16)|0x${hex(t&0xFFFF,4)}u)`;out+=`    { ${lc?'cpu.push8Value(hw,cpu.pb); ':''}cpu.push16Value(hw,0x${hex(raw,4)}u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x${hex(retLo,4)}u,${lc?'true':'false'}); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ${targetExpr}, 0x${hex(i.pc,6)}u); }\n`;out+=pcs.has(n)?`    goto ${cppLabel(n)};\n`:`    return;\n`;return out;}
  if(isDirectJump(i)&&t!==null){out+=`    // $${hex(i.pc,6)} ${i.mnemonic} -> $${hex(t,6)}\n`;if(pcs.has(t)){if(i.mnemonic==='JML')out+=`    cpu.pb=0x${hex((t>>>16)&0xFF,2)}u; // JML troca o Program Bank mesmo em goto local recompilado\n`;out+=`    goto ${cppLabel(t)};\n`;}else{const te=i.mnemonic==='JMP'?`((std::uint32_t(cpu.pb)<<16)|0x${hex(t&0xFFFF,4)}u)`:`0x${hex(t,6)}u`;out+=`    hw.requestDispatch(${te},0x${hex(i.pc,6)}u); return;\n`;}return out;}
  if(i.mnemonic==='JMP'&&i.mode==='AbsoluteIndirectLong'){out+=`    // $${hex(i.pc,6)} JMP [${hex(i.operand,4)}] -> dispatcher C++ dinamico\n`;out+=`    hw.requestDispatch(hw.read24(0x${hex(i.operand,4)}u),0x${hex(i.pc,6)}u); return;\n`;return out;}
  if(i.mnemonic==='JMP'&&i.mode==='AbsoluteIndirect'){out+=`    // $${hex(i.pc,6)} JMP (${hex(i.operand,4)}) dinamico\n`;out+=`    { auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(0x${hex(i.operand,4)}u); hw.requestDispatch(dst,0x${hex(i.pc,6)}u); return; }\n`;return out;}
  if(i.mnemonic==='JMP'&&i.mode==='AbsoluteIndexedIndirectX'){out+=`    // $${hex(i.pc,6)} JMP (${hex(i.operand,4)},X) dinamico\n`;out+=`    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x${hex(i.operand,4)}u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x${hex(i.pc,6)}u); return; }\n`;return out;}
  if(i.mnemonic==='JSR'&&i.mode==='AbsoluteIndexedIndirectX'){out+=`    // $${hex(i.pc,6)} JSR (${hex(i.operand,4)},X) dinamico stack real\n`;out+=`    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x${hex(i.operand,4)}u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); cpu.push16Value(hw,0x${hex((i.pc+i.size-1)&0xFFFF,4)}u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x${hex((i.pc+i.size)&0xFFFF,4)}u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, dst, 0x${hex(i.pc,6)}u); }\n`;out+=pcs.has(n)?`    goto ${cppLabel(n)};\n`:`    return;\n`;return out;}
  if(isReturn(i)){out+=`    // $${hex(i.pc,6)} ${i.mnemonic} stack real\n`;if(i.mnemonic==='RTS'){out+=`    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x${hex(i.pc,6)}u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x${hex(i.pc,6)}u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }\n`;return out;}if(i.mnemonic==='RTL'){out+=`    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x${hex(i.pc,6)}u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x${hex(i.pc,6)}u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }\n`;return out;}out+=`    {auto dst=cpu.returnInterrupt(hw);hw.requestDispatch(dst,0x${hex(i.pc,6)}u);return;}\n`;return out;}
  out+=emitInstruction(i).split('\n').map(x=>x?('  '+x):x).join('\n');
  if(['BRK','COP','STP'].includes(i.mnemonic)||i.status!=='native')return out;
  out+=pcs.has(n)?`    goto ${cppLabel(n)};\n`:`    return;\n`;return out;
}
function generateFunction(fn,knownTargets){
  const groups=new Map();for(const i of fn.instructions){if(!groups.has(i.pc))groups.set(i.pc,[]);groups.get(i.pc).push(i);}const pcs=new Set(groups.keys()),ordered=[...groups.keys()].sort((a,b)=>a-b);
  let out=`void ${cppFn(fn.start,fn.entryState)}(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {\n  switch(entryPc&0xFFFFFFu){\n`;
  for(const pc of ordered)out+=`    case 0x${hex(pc,6)}u: goto ${cppLabel(pc)};\n`;
  out+=`    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;\n  }\n`;
  for(const pc of ordered){
    const vars=groups.get(pc).slice().sort((a,b)=>(a.stateIn.carry===null?1:0)-(b.stateIn.carry===null?1:0)||a.stateSig.localeCompare(b.stateSig));out+=`${cppLabel(pc)}:\n  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.\n`;
    out+=`  if(hw.stopped)return;\n  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x${hex(pc&0xFFFF,4)}u))return;\n`;
    if(vars.length===1){const v=vars[0];if(v.returnSite)out+=`  if (!(${cppStatePred(v.stateIn)})) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x${hex(pc&0xFFFF,4)}u,0x${hex(pc,6)}u); return; } // callee devolveu M/X/E diferente do previsto\n`;out+=generateVariantBody(v,pcs,knownTargets);continue;}
    out+=`  // ${vars.length} variantes de decodificacao M/X para este endereco.\n`;
    for(const i of vars){out+=`  if (${cppStatePred(i.stateIn)}) {\n`;out+=generateVariantBody(i,pcs,knownTargets);out+=`  }\n`;}
    out+=`  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x${hex(pc&0xFFFF,4)}u,0x${hex(pc,6)}u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher\n`;
  }
  out+='}\n';return out;
}
function cartChipCpp(name){return {NONE:'CartChip::None',DSP1:'CartChip::DSP1',DSP2:'CartChip::DSP2',DSP3:'CartChip::DSP3',DSP4:'CartChip::DSP4','GSU/SUPERFX':'CartChip::GSU',OBC1:'CartChip::OBC1',SA1:'CartChip::SA1',SDD1:'CartChip::SDD1',SRTC:'CartChip::SRTC',SPC7110:'CartChip::SPC7110','ST010/ST011':'CartChip::ST010_011',ST018:'CartChip::ST018',CX4:'CartChip::CX4',CUSTOM:'CartChip::Custom',COPROCESSOR:'CartChip::Other'}[name]||'CartChip::None';}
function generateProject(rom,a,options={}){
  // Cada endereco ja recompilado vira um alvo retomavel. O dispatcher escolhe uma funcao que contenha
  // aquele label e que tenha variante M/X/E compativel com o estado real de CPU.
  const dispatchByPc=new Map();
  for(const f of a.functions)for(const i of f.instructions){const pc=i.pc&0xFFFFFF;if(!dispatchByPc.has(pc))dispatchByPc.set(pc,[]);const arr=dispatchByPc.get(pc),sig=f.functionKey+'|'+stateKeySig(i.stateIn);if(!arr.some(x=>x.sig===sig))arr.push({f,state:i.stateIn,sig});}
  const knownTargets=new Set(dispatchByPc.keys());let fnDecl='';
  for(const f of a.functions)fnDecl+=`void ${cppFn(f.start,f.entryState)}(CpuState&, SnesRuntime&, std::uint32_t entryPc=0x${hex(f.start,6)}u);\n`;
  const decl='void forja65_register_native_hooks(SnesRuntime&);\nvoid forja65_dispatch(CpuState&, SnesRuntime&, std::uint32_t, std::uint32_t);\nbool forja65_is_stack_return_target(std::uint32_t, SnesRuntime&);\nvoid forja65_wait(CpuState&, SnesRuntime&, std::uint32_t);\n';
  // Shards fixos e deterministas: 32 unidades reduzem overhead de MSBuild sem invalidar tudo a cada nova rotina.
  // O header comum nao lista mais todas as subrotinas, evitando invalidar todos os .o por uma unica descoberta nova.
  const unitFiles={},SHARD_COUNT=32,shards=Array.from({length:SHARD_COUNT},()=>[]);
  const shardFor=f=>{let h=(f.start>>>0)^((f.entryState&&f.entryState.emulation?1:0)<<27)^((f.entryState&&f.entryState.m8?1:0)<<28)^((f.entryState&&f.entryState.x8?1:0)<<29);h^=h>>>16;h=Math.imul(h,0x45D9F3B);h^=h>>>16;return (h>>>0)&(SHARD_COUNT-1);};
  for(const f of a.functions)shards[shardFor(f)].push(f);
  for(let n=0;n<SHARD_COUNT;n++){if(!shards[n].length)continue;shards[n].sort((a,b)=>a.start-b.start||stateKeySig(a.entryState).localeCompare(stateKeySig(b.entryState)));const name='src/generated_'+String(n).padStart(3,'0')+'.cpp';unitFiles[name]='#include "generated.hpp"\n'+shards[n].map(f=>generateFunction(f,knownTargets)).join('\n')+'\n';}
  let dispatch='#include "generated.hpp"\n#include <cstddef>\n'+fnDecl;
  const compiledByRomOffset=[];for(const pc of [...knownTargets].sort((a,b)=>a-b)){const off=snesToRom(rom,pc);if(off!==null)compiledByRomOffset.push([off,pc]);}
  const dispatchEntries=[];for(const[pc,cs]of[...dispatchByPc].sort((a,b)=>a[0]-b[0]))for(const c of cs.slice().sort((x,y)=>Number(x.f.start!==pc)-Number(y.f.start!==pc)))dispatchEntries.push({pc,state:c.state,fn:cppFn(c.f.start,c.f.entryState),routine:c.f.start});
  dispatch+='struct Forja65AliasEntry{std::uint32_t off,pc;};\nstatic const Forja65AliasEntry kForja65Aliases[]={\n';
  for(const[off,pc]of[...compiledByRomOffset].sort((a,b)=>a[0]-b[0]||a[1]-b[1]))dispatch+=`{0x${hex(off,6)}u,0x${hex(pc,6)}u},\n`;
  dispatch+='};\nstatic constexpr std::size_t kForja65AliasCount=sizeof(kForja65Aliases)/sizeof(kForja65Aliases[0]);\n';
  dispatch+='static std::size_t forja65_alias_lower_bound(std::uint32_t off){std::size_t lo=0,hi=kForja65AliasCount;while(lo<hi){auto m=lo+(hi-lo)/2;if(kForja65Aliases[m].off<off)lo=m+1;else hi=m;}return lo;}\n';
  dispatch+='static std::uint32_t forja65_compiled_alias(SnesRuntime&hw,std::uint32_t target){auto off=hw.romOffset(target);if(off==(std::size_t)-1)return target&0xFFFFFFu;auto i=forja65_alias_lower_bound((std::uint32_t)off);return i<kForja65AliasCount&&kForja65Aliases[i].off==off?kForja65Aliases[i].pc:(target&0xFFFFFFu);}\n';
  dispatch+='bool forja65_is_stack_return_target(std::uint32_t target,SnesRuntime&hw){auto off=hw.romOffset(target);if(off==(std::size_t)-1)return false;auto i=forja65_alias_lower_bound((std::uint32_t)off);return i<kForja65AliasCount&&kForja65Aliases[i].off==off;}\n';
  dispatch+='using Forja65DispatchFn=void(*)(CpuState&,SnesRuntime&,std::uint32_t);\nstruct Forja65DispatchEntry{std::uint32_t pc;bool e,m,x,carryKnown,c;Forja65DispatchFn fn;std::uint32_t routine;};\nstatic const Forja65DispatchEntry kForja65Dispatch[]={\n';
  for(const e of dispatchEntries)dispatch+=`{0x${hex(e.pc,6)}u,${e.state.emulation?'true':'false'},${e.state.m8?'true':'false'},${e.state.x8?'true':'false'},${e.state.carry===null?'false':'true'},${e.state.carry?'true':'false'},&${e.fn},0x${hex(e.routine,6)}u},\n`;
  dispatch+='};\nstatic constexpr std::size_t kForja65DispatchCount=sizeof(kForja65Dispatch)/sizeof(kForja65Dispatch[0]);\n';
  dispatch+='static std::size_t forja65_dispatch_lower_bound(std::uint32_t pc){std::size_t lo=0,hi=kForja65DispatchCount;while(lo<hi){auto m=lo+(hi-lo)/2;if(kForja65Dispatch[m].pc<pc)lo=m+1;else hi=m;}return lo;}\n';
  dispatch+='static bool forja65_has_variant(std::uint32_t pc,const CpuState&cpu){for(auto k=forja65_dispatch_lower_bound(pc);k<kForja65DispatchCount&&kForja65Dispatch[k].pc==pc;++k){const auto&e=kForja65Dispatch[k];if(cpu.e==e.e&&cpu.m8==e.m&&cpu.x8==e.x&&(!e.carryKnown||cpu.c==e.c))return true;}return false;}\n';
  dispatch+='static std::uint32_t forja65_compiled_alias(SnesRuntime&hw,std::uint32_t target,const CpuState&cpu){target&=0xFFFFFFu;if(forja65_has_variant(target,cpu))return target;auto off=hw.romOffset(target);if(off!=(std::size_t)-1){for(auto k=forja65_alias_lower_bound((std::uint32_t)off);k<kForja65AliasCount&&kForja65Aliases[k].off==off;++k)if((kForja65Aliases[k].pc&0xFFFFu)==(target&0xFFFFu)&&forja65_has_variant(kForja65Aliases[k].pc,cpu))return kForja65Aliases[k].pc;}const auto fallback=forja65_compiled_alias(hw,target);return (fallback&0xFFFFu)==(target&0xFFFFu)?fallback:target;}\n';
  dispatch+='void forja65_dispatch(CpuState&cpu,SnesRuntime&hw,std::uint32_t target,std::uint32_t from){auto cur=target&0xFFFFFFu,src=from&0xFFFFFFu;bool hookEligible=hw.nativeCallPending;hw.nativeCallPending=false;for(;;){hw.dispatchPending=false;const auto requested=cur;cpu.pb=(std::uint8_t)(requested>>16);auto exec=forja65_compiled_alias(hw,requested,cpu);auto pos=forja65_dispatch_lower_bound(exec);if(pos>=kForja65DispatchCount||kForja65Dispatch[pos].pc!=exec){hw.unresolvedFlow(src,requested,cpu);}bool matched=false;for(int pass=0;pass<2&&!matched;++pass){for(auto k=pos;k<kForja65DispatchCount&&kForja65Dispatch[k].pc==exec;++k){const auto&e=kForja65Dispatch[k];if(cpu.e!=e.e||cpu.m8!=e.m||cpu.x8!=e.x)continue;if(pass==0){if(!e.carryKnown||cpu.c!=e.c)continue;}else if(e.carryKnown)continue;{ForjaTraceContext context(hw.traceRoutine,hw.traceSource,e.routine,"CPU");hw.trace.emit(hw.frameCounter,e.routine,src,"entry","CPU",requested,context.oldRoutine);if(!(hookEligible&&exec==e.routine&&hw.runNativeHook(exec,cpu)))e.fn(cpu,hw,exec);hw.trace.emit(hw.frameCounter,e.routine,hw.lastInstructionPc,"return","CPU",requested,0);}hookEligible=false;matched=true;break;}}if(!matched)hw.unresolvedState(src,requested,cpu.e,cpu.m8,cpu.x8,cpu.c);if(!hw.dispatchPending)return;hookEligible=false;src=hw.dispatchFrom;cur=hw.dispatchTarget;}}\n';
  const nmi=(a.entryPoints.find(e=>e.name.startsWith('NMI-NATIVE'))||a.entryPoints.find(e=>e.name==='NMI-EMU'));
  const irq=(a.entryPoints.find(e=>e.name.startsWith('IRQ-NATIVE'))||a.entryPoints.find(e=>e.name==='IRQ-BRK-EMU'));
  dispatch+='void forja65_wait(CpuState&cpu,SnesRuntime&hw,std::uint32_t resumePc){while(!hw.stopped&&!hw.cpuNmiInterruptPending&&!hw.cpuIrqInterruptPending){hw.advanceCpuMasterCycles(64u);if(hw.hostFrameReady){hw.hostFrameReady=false;hw.present();}}if(!hw.stopped)hw.serviceCpuEvents(cpu,resumePc); }\n';
  const mapper=a.mapping===MAP.HIROM?'MapperKind::HiROM':a.mapping===MAP.EXHIROM?'MapperKind::ExHiROM':'MapperKind::LoROM';
  const reset=a.functions.find(f=>f.start===a.resetPc&&f.entryName==='RESET')||a.functions.find(f=>f.start===a.resetPc);
  const projectRomHash=romFingerprint(rom);
  const main=`#include "generated.hpp"\n#include <iostream>\n#include <fstream>\n#include <cstdlib>\n#ifdef FORJA65_NATIVE_SPC_LINKED\nvoid forja65_native_spc_tick(ApuBridge&,unsigned);\n#endif\nstatic void forja65Fatal(const char*msg){std::ofstream f("forja65-last-error.txt",std::ios::trunc);if(f)f<<msg<<'\\n';std::cerr<<msg<<'\\n';\n#ifdef _WIN32\nMessageBoxA(nullptr,msg,"Forja65 - erro ao executar o port",MB_OK|MB_ICONERROR);\n#endif\n}\nint main(){CpuState cpu;try{SnesRuntime hw("assets/cart-data.bin",${mapper},${rom.header.sramBytes||0}u,${rom.header.romSize||0}u,${rom.header.sramSize||0}u,${cartChipCpp(rom.header.coprocessor)},"save.srm",${rom.header.region||0}u);\n#ifdef FORJA65_NATIVE_SPC_LINKED\nhw.apu.setNativeStepHook(&forja65_native_spc_tick);\n#endif\nforja65_register_native_hooks(hw);\nif(hw.cartHashHex()!="${projectRomHash}")throw std::runtime_error("ROM/native pack fingerprint mismatch: "+hw.cartHashHex()+" expected ${projectRomHash}");\nhw.beginFrame();try{forja65_dispatch(cpu,hw,0x${hex(reset.start,6)}u,0xFFFFFFu);}catch(const std::exception&e){if(std::string(e.what())!="FORJA65_HEADLESS_COMPLETE")throw;hw.stopped=true;}unsigned lim=0;if(const char*e=std::getenv("FORJA65_HEADLESS_FRAMES"))lim=(unsigned)std::strtoul(e,nullptr,10);while(!hw.stopped){forja65_wait(cpu,hw,hw.lastInstructionPc);if(hw.dispatchPending)forja65_dispatch(cpu,hw,hw.dispatchTarget,hw.dispatchFrom);hw.maybeCaptureNativeScene();if(lim&&hw.frameCounter>=lim)hw.stopped=true;}hw.writeNativeDependencyReport();std::ofstream qa("forja65-qa-status.txt",std::ios::trunc);if(qa)qa<<"FORJA65_QA 1\\nrom="<<hw.cartHashHex()<<"\\nruntime_started=PASS\\nframes="<<hw.frameCounter<<"\\ninstructions="<<hw.cpuInstructionCount<<"\\nnmi_services="<<hw.nmiServiceCount<<"\\nirq_services="<<hw.irqServiceCount<<"\\nppu_forced_blank="<<((hw.ppu.regs[0]&0x80u)?1:0)<<"\\nframebuffer_hash="<<std::hex<<hw.framebufferHash()<<"\\nwram_hash="<<hw.ramHash()<<std::dec<<"\\nnew_oracle_hints="<<(std::filesystem::exists("forja65-oracle-hints.txt")?"YES":"NO")<<"\\nppu_virtual_accesses="<<(hw.hwUsage.ppuReads+hw.hwUsage.ppuWrites)<<"\\nppu_accesses="<<(hw.hwUsage.ppuReads+hw.hwUsage.ppuWrites)<<"\\nppu_native_accesses="<<(hw.hwUsage.ppuNativeReads+hw.hwUsage.ppuNativeWrites)<<"\\nppu_fallback_accesses="<<(hw.hwUsage.ppuFallbackReads+hw.hwUsage.ppuFallbackWrites)<<"\\napu_virtual_accesses="<<(hw.hwUsage.apuReads+hw.hwUsage.apuWrites)<<"\\napu_accesses="<<(hw.hwUsage.apuReads+hw.hwUsage.apuWrites)<<"\\napu_native_master_cycles="<<hw.apu.nativeMasterCycles<<"\\napu_fallback_master_cycles="<<hw.apu.fallbackMasterCycles<<"\\ndsp_native_samples="<<hw.apu.dspNativeSamples<<"\\ndsp_fallback_samples="<<hw.apu.dspFallbackSamples<<"\\nrom_runtime_reads="<<hw.hwUsage.romReads<<"\\nrom_native_reads="<<hw.hwUsage.romNativeReads<<"\\nrom_fallback_reads="<<hw.hwUsage.romFallbackReads<<"\\ndma_bytes="<<hw.hwUsage.dmaBytes<<"\\ndma_native_bytes="<<hw.hwUsage.dmaNativeBytes<<"\\ndma_fallback_bytes="<<hw.hwUsage.dmaFallbackBytes<<"\\nhdma_bytes="<<hw.hwUsage.hdmaBytes<<"\\nhdma_native_bytes="<<hw.hwUsage.hdmaNativeBytes<<"\\nhdma_fallback_bytes="<<hw.hwUsage.hdmaFallbackBytes<<"\\n";std::cout<<"Forja65: port C++ executado, frames="<<hw.frameCounter<<"\\n";}catch(const std::exception&e){forja65Fatal(e.what());std::ofstream qa("forja65-qa-status.txt",std::ios::trunc);if(qa)qa<<"FORJA65_QA 1\\nruntime_started=FAIL\\nerror="<<e.what()<<"\\n";return 2;}return 0;}\n`;
  const h='#pragma once\n#include "runtime.hpp"\n'+decl;
  const generatedSources=['src/dispatch.cpp',...Object.keys(unitFiles)].join(' ');
  const cm='cmake_minimum_required(VERSION 3.20)\nproject(GeneratedSNESPort LANGUAGES CXX)\nset(CMAKE_CXX_STANDARD 20)\nset(CMAKE_CXX_STANDARD_REQUIRED ON)\noption(FORJA65_STRICT "Warnings as errors" OFF)\noption(FORJA65_SANITIZERS "Enable Address/Undefined sanitizers where supported" OFF)\nfunction(forja65_quality target)\n  if(FORJA65_STRICT)\n    if(MSVC)\n      target_compile_options(${target} PRIVATE /W4 /WX /permissive-)\n    else()\n      target_compile_options(${target} PRIVATE -Wall -Wextra -Wpedantic -Werror)\n    endif()\n  endif()\n  if(FORJA65_SANITIZERS)\n    if(MSVC)\n      target_compile_options(${target} PRIVATE /fsanitize=address /Zi)\n    elseif(CMAKE_CXX_COMPILER_ID MATCHES "Clang|GNU")\n      target_compile_options(${target} PRIVATE -fsanitize=address,undefined -fno-omit-frame-pointer)\n      target_link_options(${target} PRIVATE -fsanitize=address,undefined)\n    endif()\n  endif()\nendfunction()\nadd_library(forja65_generated OBJECT '+generatedSources+')\ntarget_include_directories(forja65_generated PRIVATE src)\nforja65_quality(forja65_generated)\nadd_executable(game src/main.cpp $<TARGET_OBJECTS:forja65_generated>)\ntarget_include_directories(game PRIVATE src)\nforja65_quality(game)\nif(EXISTS "${CMAKE_SOURCE_DIR}/src/spc700_native.cpp")\n  target_sources(game PRIVATE src/spc700_native.cpp)\n  target_compile_definitions(game PRIVATE FORJA65_NATIVE_SPC_LINKED=1)\nendif()\nadd_executable(runtime_smoke tests/runtime_smoke.cpp)\ntarget_include_directories(runtime_smoke PRIVATE src)\nforja65_quality(runtime_smoke)\nadd_executable(scene_capture_smoke tests/scene_capture_smoke.cpp)\ntarget_include_directories(scene_capture_smoke PRIVATE src)\nforja65_quality(scene_capture_smoke)\nadd_executable(oracle_learning_smoke tests/oracle_learning_smoke.cpp)\ntarget_include_directories(oracle_learning_smoke PRIVATE src)\nforja65_quality(oracle_learning_smoke)\nadd_executable(deterministic_input_smoke tests/deterministic_input_smoke.cpp)\ntarget_include_directories(deterministic_input_smoke PRIVATE src)\nforja65_quality(deterministic_input_smoke)\nadd_executable(native_dependency_smoke tests/native_dependency_smoke.cpp)\ntarget_include_directories(native_dependency_smoke PRIVATE src)\nforja65_quality(native_dependency_smoke)\nadd_executable(native_migration_smoke tests/native_migration_smoke.cpp)\ntarget_include_directories(native_migration_smoke PRIVATE src)\nforja65_quality(native_migration_smoke)\nadd_executable(rom_pack_builder tools/rom_pack_builder.cpp)\nforja65_quality(rom_pack_builder)\nadd_executable(equivalence_runner tests/equivalence_runner.cpp $<TARGET_OBJECTS:forja65_generated>)\ntarget_include_directories(equivalence_runner PRIVATE src)\nforja65_quality(equivalence_runner)\nif(WIN32)\n  foreach(t game runtime_smoke scene_capture_smoke oracle_learning_smoke deterministic_input_smoke native_dependency_smoke native_migration_smoke equivalence_runner)\n    target_link_libraries(${t} PRIVATE user32 gdi32 xinput9_1_0 winmm)\n  endforeach()\nendif()\nfile(COPY assets DESTINATION ${CMAKE_BINARY_DIR})\nadd_custom_command(TARGET game POST_BUILD COMMAND ${CMAKE_COMMAND} -E copy_directory "${CMAKE_SOURCE_DIR}/assets" "$<TARGET_FILE_DIR:game>/assets")\nadd_custom_command(TARGET scene_capture_smoke POST_BUILD COMMAND ${CMAKE_COMMAND} -E copy_directory "${CMAKE_SOURCE_DIR}/assets" "$<TARGET_FILE_DIR:scene_capture_smoke>/assets")\nforeach(t runtime_smoke oracle_learning_smoke deterministic_input_smoke native_dependency_smoke native_migration_smoke equivalence_runner)\n  add_custom_command(TARGET ${t} POST_BUILD COMMAND ${CMAKE_COMMAND} -E copy_directory "${CMAKE_SOURCE_DIR}/assets" "$<TARGET_FILE_DIR:${t}>/assets")\nendforeach()\nenable_testing()\nadd_test(NAME runtime_smoke COMMAND runtime_smoke)\nadd_test(NAME scene_capture_smoke COMMAND scene_capture_smoke)\nadd_test(NAME oracle_learning_smoke COMMAND oracle_learning_smoke)\nadd_test(NAME deterministic_input_smoke COMMAND deterministic_input_smoke)\nadd_test(NAME native_dependency_smoke COMMAND native_dependency_smoke)\nadd_test(NAME native_migration_smoke COMMAND native_migration_smoke)\nadd_test(NAME equivalence_vectors COMMAND equivalence_runner "${CMAKE_SOURCE_DIR}/tests/equivalence-cases.txt")\nset_tests_properties(equivalence_vectors PROPERTIES SKIP_RETURN_CODE 77)\n';
  const runtimeSmoke=`#include "runtime.hpp"\n#include <iostream>\nint main(){try{SnesRuntime hw("assets/cart-data.bin",${mapper},${rom.header.sramBytes||0}u,${rom.header.romSize||0}u,${rom.header.sramSize||0}u,${cartChipCpp(rom.header.coprocessor)},"runtime-smoke.srm",${rom.header.region||0}u,true);if(hw.cart.empty()||hw.framebuffer.empty())return 3;if(hw.cartHashHex()!="${projectRomHash}"){std::cerr<<"ROM fingerprint mismatch "<<hw.cartHashHex()<<" expected ${projectRomHash}\\n";return 4;}std::cout<<"FORJA65_RUNTIME_SMOKE_OK cart="<<hw.cart.size()<<" refresh="<<hw.hostRefreshHz()<<" rom=${projectRomHash}\\n";return 0;}catch(const std::exception&e){std::cerr<<e.what()<<'\\n';return 2;}}\n`;
  const sceneCaptureSmoke=`#include "runtime.hpp"\n#include <filesystem>\n#include <fstream>\n#include <iostream>\n#include <cstring>\nint main(){namespace fs=std::filesystem;try{SnesRuntime hw("assets/cart-data.bin",${mapper},${rom.header.sramBytes||0}u,${rom.header.romSize||0}u,${rom.header.sramSize||0}u,${cartChipCpp(rom.header.coprocessor)},"scene-smoke.srm",${rom.header.region||0}u,true);hw.ppu.bgmode=1;hw.ppu.tm=1;hw.ppu.ts=0;hw.ppu.brightness=15;hw.ppu.cgram[2]=0x1f;hw.ppu.cgram[3]=0;hw.ppu.vram[0]=0x80;hw.ppu.vram[1]=0;hw.framebuffer.assign(hw.fbWidth*hw.fbHeight,0xFF336699u);fs::remove_all("scene-smoke");if(!hw.captureNativeScene("scene-smoke","smoke"))return 4;for(const char*f:{"scene-smoke/smoke.nscene","scene-smoke/palette.npal","scene-smoke/bg1.ntiles","scene-smoke/bg1.nmap","scene-smoke/vram.bin","scene-smoke/oam.bin","scene-smoke/preview.ppm","scene-smoke/oam-layer.nspr","scene-smoke/oam-sprites.txt","scene-smoke/capture-manifest.txt"})if(!fs::exists(f)||fs::file_size(f)==0)return 5;std::ifstream n("scene-smoke/palette.npal",std::ios::binary);char m[4]{};n.read(m,4);if(std::memcmp(m,"NPAL",4)!=0)return 6;std::ifstream sn("scene-smoke/oam-layer.nspr",std::ios::binary);char sm[4]{};sn.read(sm,4);if(std::memcmp(sm,"NSPR",4)!=0)return 7;std::cout<<"FORJA65_SCENE_CAPTURE_SMOKE_OK hash="<<std::hex<<hw.framebufferHash()<<"\\n";return 0;}catch(const std::exception&e){std::cerr<<e.what()<<'\\n';return 2;}}\n`;
  const oracleLearningSmoke=`#include "runtime.hpp"\n#include <filesystem>\n#include <fstream>\n#include <iostream>\n#include <string>\nint main(){namespace fs=std::filesystem;try{fs::remove("forja65-oracle-hints.txt");fs::remove("forja65-runtime-hints.txt");fs::remove("forja65-oracle-observations.log");SnesRuntime hw("assets/cart-data.bin",${mapper},${rom.header.sramBytes||0}u,${rom.header.romSize||0}u,${rom.header.sramSize||0}u,${cartChipCpp(rom.header.coprocessor)},"oracle-smoke.srm",${rom.header.region||0}u,true);CpuState cpu;cpu.e=false;cpu.m8=false;cpu.x8=true;cpu.c=true;cpu.pb=0x80;hw.appendRuntimeHint(0x808000u,0x808123u,cpu,"FLOW");hw.appendRuntimeHint(0x808000u,0x808123u,cpu,"FLOW");std::ifstream in("forja65-oracle-hints.txt");std::string line,only;unsigned lines=0;while(std::getline(in,line))if(!line.empty()){lines++;only=line;}if(lines!=1)return 4;if(only.find("rom="+hw.cartHashHex()+" ")!=0)return 6;if(!fs::exists("forja65-oracle-observations.log")||fs::file_size("forja65-oracle-observations.log")==0)return 5;std::cout<<"FORJA65_ORACLE_LEARNING_SMOKE_OK unique="<<lines<<" rom="<<hw.cartHashHex()<<"\\n";return 0;}catch(const std::exception&e){std::cerr<<e.what()<<'\\n';return 2;}}\n`;
  const deterministicInputSmoke=`#include "runtime.hpp"\n#include <filesystem>\n#include <iostream>\nint main(){namespace fs=std::filesystem;try{fs::remove("input-smoke.trace");SnesRuntime rec("assets/cart-data.bin",${mapper},${rom.header.sramBytes||0}u,${rom.header.romSize||0}u,${rom.header.sramSize||0}u,${cartChipCpp(rom.header.coprocessor)},"input-rec.srm",${rom.header.region||0}u,true);rec.setInputRecordPath("input-smoke.trace",true);rec.frameCounter=0;rec.setJoy1(0x1234);rec.setJoy2(0xABCD);rec.recordInputFrame();rec.frameCounter=1;rec.setJoy1(0x00F0);rec.setJoy2(0x0F00);rec.recordInputFrame();SnesRuntime play("assets/cart-data.bin",${mapper},${rom.header.sramBytes||0}u,${rom.header.romSize||0}u,${rom.header.sramSize||0}u,${cartChipCpp(rom.header.coprocessor)},"input-play.srm",${rom.header.region||0}u,true);if(!play.loadInputReplay("input-smoke.trace"))return 3;play.frameCounter=0;if(!play.applyReplayInput()||play.io.joy[0]!=0x1234||play.io.joy[1]!=0xABCD)return 4;play.frameCounter=1;if(!play.applyReplayInput()||play.io.joy[0]!=0x00F0||play.io.joy[1]!=0x0F00)return 5;std::cout<<"FORJA65_DETERMINISTIC_INPUT_SMOKE_OK rom="<<play.cartHashHex()<<"\\n";return 0;}catch(const std::exception&e){std::cerr<<e.what()<<'\\n';return 2;}}\n`;
  const nativeDependencySmoke=`#include "runtime.hpp"\n#include <filesystem>\n#include <fstream>\n#include <iostream>\nint main(){try{SnesRuntime hw("assets/cart-data.bin",${mapper},${rom.header.sramBytes||0}u,${rom.header.romSize||0}u,${rom.header.sramSize||0}u,${cartChipCpp(rom.header.coprocessor)},"native-audit.srm",${rom.header.region||0}u,true);hw.lastInstructionPc=0x808000u;auto ro=hw.romOffset(0x808000u);if(ro!=(std::size_t)-1)(void)hw.read(0x808000u);hw.write8(0x7E0010u,0x42);(void)hw.read(0x7E0010u);hw.write8(0x2100u,0x0Fu);(void)hw.read(0x213Fu);hw.write8(0x2140u,0x55);(void)hw.read(0x2140u);hw.writeNativeDependencyReport("native-audit-smoke.txt");if(hw.hwUsage.wramReads==0||hw.hwUsage.wramWrites==0||hw.hwUsage.ppuReads==0||hw.hwUsage.ppuWrites==0||hw.hwUsage.apuReads==0||hw.hwUsage.apuWrites==0)return 4;if(ro!=(std::size_t)-1&&hw.hwUsage.romReads==0)return 5;if(!std::filesystem::exists("native-audit-smoke.txt"))return 6;std::ifstream in("native-audit-smoke.txt");std::string text((std::istreambuf_iterator<char>(in)),{});if(text.find("FORJA65_NATIVE_DEPENDENCY_AUDIT 1")==std::string::npos||text.find("PPU_VIRTUAL_HW=YES")==std::string::npos)return 7;std::cout<<"FORJA65_NATIVE_DEPENDENCY_SMOKE_OK\\n";return 0;}catch(const std::exception&e){std::cerr<<e.what()<<'\\n';return 2;}}\n`;
  const nativeMigrationSmoke=`#include "runtime.hpp"
#include <filesystem>
#include <iostream>
static unsigned gNativeApuCalls=0;
static void nativeApuStep(ApuBridge&a,unsigned mc){(void)mc;gNativeApuCalls++;a.spc.portOut[0]=0x5Au;}
int main(){try{SnesRuntime hw("assets/cart-data.bin",${mapper},${rom.header.sramBytes||0}u,${rom.header.romSize||0}u,${rom.header.sramSize||0}u,${cartChipCpp(rom.header.coprocessor)},"migration-smoke.srm",${rom.header.region||0}u,true);hw.ppuMode=PpuRuntimeMode::StateOnlyNativeScanout;hw.nativeDmaEnabled=true;hw.write8(0x002100u,0x0Fu);if(hw.ppu.brightness!=15||hw.hwUsage.ppuNativeWrites==0)return 3;hw.ram[0]=0x12;hw.ram[1]=0x34;hw.ppu.vmadd=0;hw.ppu.vmain=0;hw.dma[0].dmap=0;hw.dma[0].bbad=0x18;hw.dma[0].a1b=0x7E;hw.dma[0].a1t=0;hw.dma[0].das=2;hw.executeDma(1);if(hw.hwUsage.dmaNativeBytes!=2||hw.hwUsage.dmaFallbackBytes!=0)return 4;if(hw.ppu.vram[0]!=0x12||hw.ppu.vram[2]!=0x34)return 5;hw.ram[0x100]=1;hw.ram[0x101]=0x0E;hw.ram[0x102]=0;hw.dma[1].dmap=0;hw.dma[1].bbad=0x00;hw.dma[1].a1b=0x7E;hw.dma[1].a1t=0x0100;hw.startHdmaFrame(2);hw.executeHdmaLine();if(hw.hwUsage.hdmaNativeBytes==0||hw.ppu.brightness!=14)return 6;auto fallbackBefore=hw.apu.fallbackMasterCycles;hw.apu.setNativeStepHook(&nativeApuStep);hw.apu.setNativeDsp(true);hw.apu.tickMasterCycles(84);if(!gNativeApuCalls||hw.apu.nativeMasterCycles!=84||hw.apu.fallbackMasterCycles!=fallbackBefore||hw.apu.read(0)!=0x5A)return 7;hw.apu.tickMasterCycles(ApuBridge::DSP_SAMPLE_MASTER_CYCLES*4u);if(hw.apu.dspNativeSamples<4||hw.apu.dspFallbackSamples!=0||hw.apu.nativePcm.size()<8)return 8;if(!hw.apu.saveNativeAudioWav("native-audio-smoke.wav")||!std::filesystem::exists("native-audio-smoke.wav")||std::filesystem::file_size("native-audio-smoke.wav")<=44)return 9;if(hw.hwUsage.ppuFallbackReads||hw.hwUsage.ppuFallbackWrites)return 10;auto off=hw.romOffset(0x${hex(a.resetPc,6)}u);if(off==(std::size_t)-1||off>=hw.cart.size())return 11;auto expected=hw.cart[off];auto hash=hw.cartHashValue();NativeRomRegion reg;reg.off=(std::uint32_t)off;reg.data.push_back(expected);hw.nativeRom.logicalSize=(std::uint32_t)hw.romLogicalSize;hw.nativeRom.sourceHash=hash;hw.nativeRom.regions.push_back(reg);hw.cart.clear();hw.romMode=RomRuntimeMode::NativeOnly;auto got=hw.read(0x${hex(a.resetPc,6)}u);if(got!=expected||hw.hwUsage.romNativeReads==0||hw.hwUsage.romFallbackReads!=0)return 12;if(hw.nativeRom.coverageBytes()!=1||hw.nativeRom.coveragePercent()<=0.0)return 13;std::cout<<"FORJA65_NATIVE_MIGRATION_SMOKE_OK dma_native="<<hw.hwUsage.dmaNativeBytes<<" hdma_native="<<hw.hwUsage.hdmaNativeBytes<<" apu_native_cycles="<<hw.apu.nativeMasterCycles<<" dsp_native_samples="<<hw.apu.dspNativeSamples<<" rom_native="<<hw.hwUsage.romNativeReads<<"\\n";return 0;}catch(const std::exception&e){std::cerr<<e.what()<<'\\n';return 2;}}
`;
  const equivalenceRunner=`#include "generated.hpp"\n#include <fstream>\n#include <iostream>\n#include <sstream>\n#include <string>\n#include <map>\nstatic unsigned long long num(const std::string&s){return std::stoull(s,nullptr,0);}\nint main(int argc,char**argv){if(argc<2)return 77;std::ifstream in(argv[1]);if(!in)return 77;std::string line;unsigned cases=0;while(std::getline(in,line)){if(line.empty()||line[0]=='#'||line[0]==';')continue;std::istringstream ss(line);std::string part;std::map<std::string,std::string> q;while(ss>>part){auto p=part.find('=');if(p!=std::string::npos)q[part.substr(0,p)]=part.substr(p+1);}if(!q.count("entry"))continue;SnesRuntime hw("assets/cart-data.bin",${mapper},${rom.header.sramBytes||0}u,${rom.header.romSize||0}u,${rom.header.sramSize||0}u,${cartChipCpp(rom.header.coprocessor)},"equivalence.srm",${rom.header.region||0}u,true);CpuState cpu;auto get=[&](const char*k,unsigned long long d){auto it=q.find(k);return it==q.end()?d:num(it->second);};const auto entry=(std::uint32_t)num(q["entry"]);cpu.a=(std::uint16_t)get("a",0);cpu.x=(std::uint16_t)get("x",0);cpu.y=(std::uint16_t)get("y",0);cpu.s=(std::uint16_t)get("s",0x1FF);cpu.d=(std::uint16_t)get("d",0);cpu.db=(std::uint8_t)get("db",0);cpu.pb=(std::uint8_t)get("pb",(entry>>16)&255);cpu.e=get("e",1)!=0;cpu.m8=get("m",1)!=0;cpu.x8=get("x8",1)!=0;cpu.c=get("c",0)!=0;const auto sentinel=((std::uint32_t)cpu.pb<<16)|0x0001u;cpu.push16Value(hw,0x0000u);hw.pushNativeReturn(sentinel,false);forja65_dispatch(cpu,hw,entry,0xFFFFFEu);auto chk=[&](const char*k,unsigned long long got){auto it=q.find(std::string("expect_")+k);if(it==q.end())return true;auto exp=num(it->second);if(got!=exp){std::cerr<<"case "<<cases<<" "<<k<<" got="<<got<<" expected="<<exp<<"\\n";return false;}return true;};if(!chk("a",cpu.a)||!chk("x",cpu.x)||!chk("y",cpu.y)||!chk("s",cpu.s)||!chk("d",cpu.d)||!chk("db",cpu.db)||!chk("pb",cpu.pb)||!chk("c",cpu.c?1:0))return 4;cases++;}if(!cases)return 77;std::cout<<"FORJA65_EQUIVALENCE_VECTORS_PASS cases="<<cases<<"\\n";return 0;}\n`;
  const buildCmd='@echo off\r\nsetlocal\r\ncd /d "%~dp0"\r\nwhere cmake >nul 2>nul || (echo ERRO: CMake nao encontrado no PATH. & pause & exit /b 1)\r\ncmake -S . -B build-win -G "Visual Studio 17 2022" -A x64 || goto :err\r\ncmake --build build-win --config Release --target game runtime_smoke scene_capture_smoke oracle_learning_smoke deterministic_input_smoke native_dependency_smoke native_migration_smoke rom_pack_builder equivalence_runner || goto :err\r\nctest --test-dir build-win -C Release --output-on-failure || goto :err\r\nif not exist bin mkdir bin\r\ncopy /Y build-win\\Release\\game.exe bin\\game.exe >nul\r\nxcopy /E /I /Y assets bin\\assets >nul\r\ncopy /Y RUN-WINDOWS.cmd bin\\RUN-WINDOWS.cmd >nul\r\ncopy /Y RUN-ORACLE.cmd bin\\RUN-ORACLE.cmd >nul\r\ncopy /Y RUN-HEADLESS.cmd bin\\RUN-HEADLESS.cmd >nul\r\ncopy /Y RUN-INPUT-RECORD.cmd bin\\RUN-INPUT-RECORD.cmd >nul\r\ncopy /Y RUN-INPUT-REPLAY.cmd bin\\RUN-INPUT-REPLAY.cmd >nul\r\ncopy /Y forja65-build-manifest.txt bin\\forja65-build-manifest.txt >nul\r\necho.\r\necho OK: bin\\game.exe\r\npause\r\nexit /b 0\r\n:err\r\necho.\r\necho FALHA NO BUILD NATIVO. Veja as mensagens acima.\r\npause\r\nexit /b 1\r\n';
  const qualityCmd='@echo off\r\nsetlocal\r\ncd /d "%~dp0"\r\nwhere cmake >nul 2>nul || (echo ERRO: CMake nao encontrado no PATH. & pause & exit /b 1)\r\ncmake -S . -B build-quality -G "Visual Studio 17 2022" -A x64 -DFORJA65_STRICT=ON -DFORJA65_SANITIZERS=ON || goto :err\r\ncmake --build build-quality --config RelWithDebInfo --target game runtime_smoke scene_capture_smoke oracle_learning_smoke deterministic_input_smoke native_dependency_smoke native_migration_smoke rom_pack_builder equivalence_runner || goto :err\r\nctest --test-dir build-quality -C RelWithDebInfo --output-on-failure || goto :err\r\necho QUALITY PASS\r\npause\r\nexit /b 0\r\n:err\r\necho QUALITY FAIL\r\npause\r\nexit /b 1\r\n';
  const recordCmd='@echo off\r\nsetlocal\r\ncd /d "%~dp0"\r\nset TRACE=%~1\r\nif "%TRACE%"=="" set TRACE=forja65-input.trace\r\nset FORJA65_INPUT_RECORD=%TRACE%\r\nset FORJA65_FRAME_HASHES=1\r\nif exist game.exe goto run\r\nif exist bin\\game.exe (cd bin & goto run)\r\necho Execute BUILD-WINDOWS.cmd primeiro.\r\npause\r\nexit /b 1\r\n:run\r\ngame.exe\r\nexit /b %ERRORLEVEL%\r\n';
  const replayCmd='@echo off\r\nsetlocal\r\ncd /d "%~dp0"\r\nset TRACE=%~1\r\nif "%TRACE%"=="" set TRACE=forja65-input.trace\r\nif not exist "%TRACE%" (echo Trace nao encontrado: %TRACE% & pause & exit /b 2)\r\nset FORJA65_INPUT_REPLAY=%TRACE%\r\nset FORJA65_FRAME_HASHES=1\r\nif exist game.exe goto run\r\nif exist bin\\game.exe (cd bin & goto run)\r\necho Execute BUILD-WINDOWS.cmd primeiro.\r\npause\r\nexit /b 1\r\n:run\r\ngame.exe\r\nexit /b %ERRORLEVEL%\r\n';
  const runCmd='@echo off\r\nsetlocal\r\ncd /d "%~dp0"\r\nif exist game.exe goto run\r\nif exist bin\\game.exe (cd bin & goto run)\r\necho Execute BUILD-WINDOWS.cmd primeiro.\r\npause\r\nexit /b 1\r\n:run\r\ngame.exe\r\nset CODE=%ERRORLEVEL%\r\nif not "%CODE%"=="0" (echo. & echo O port encerrou com erro %CODE%. & if exist forja65-last-error.txt type forja65-last-error.txt & echo. & echo Veja tambem forja65-crash-trace.txt e forja65-runtime-hints.txt, se existirem. & pause)\r\nexit /b %CODE%\r\n';
  const headlessCmd='@echo off\r\nsetlocal\r\ncd /d "%~dp0"\r\nset FORJA65_HEADLESS=1\r\nif "%FORJA65_HEADLESS_FRAMES%"=="" set FORJA65_HEADLESS_FRAMES=2\r\nif "%FORJA65_WATCHDOG_INSTRUCTIONS%"=="" set FORJA65_WATCHDOG_INSTRUCTIONS=50000000\r\nif exist game.exe goto run\r\nif exist build-win\\Release\\game.exe (cd build-win\\Release & goto run)\r\nif exist bin\\game.exe (cd bin & goto run)\r\necho Execute BUILD-WINDOWS.cmd primeiro.\r\npause\r\nexit /b 1\r\n:run\r\ngame.exe\r\nset CODE=%ERRORLEVEL%\r\nif not "%CODE%"=="0" (echo. & echo HEADLESS encerrou com erro %CODE%. & if exist forja65-last-error.txt type forja65-last-error.txt & if exist forja65-crash-trace.txt type forja65-crash-trace.txt & pause)\r\nexit /b %CODE%\r\n';
  const oracleCmd='@echo off\r\nsetlocal\r\ncd /d "%~dp0"\r\nset FRAMES=%~1\r\nif "%FRAMES%"=="" set FRAMES=300\r\nset LIMIT=%~2\r\nif "%LIMIT%"=="" set LIMIT=50000000\r\nset FORJA65_HEADLESS=1\r\nset FORJA65_HEADLESS_FRAMES=%FRAMES%\r\nset FORJA65_WATCHDOG_INSTRUCTIONS=%LIMIT%\r\nif exist game.exe goto run\r\nif exist bin\game.exe (cd bin & goto run)\r\nif exist build-win\Release\game.exe (cd build-win\Release & goto run)\r\necho Execute BUILD-WINDOWS.cmd primeiro.\r\npause\r\nexit /b 1\r\n:run\r\necho [Forja65 Oracle] Executando ate descobrir novo fluxo/estado ou completar %FRAMES% frames...\r\ngame.exe\r\nset CODE=%ERRORLEVEL%\r\necho.\r\nif exist forja65-oracle-hints.txt (echo === ORACLE HINTS === & type forja65-oracle-hints.txt & echo. & echo Importe forja65-oracle-hints.txt na Forja65; a analise sera refeita automaticamente.) else (echo Nenhum alvo novo foi descoberto nesta execucao.)\r\nexit /b %CODE%\r\n';
  const captureCmd='@echo off\r\nsetlocal\r\ncd /d "%~dp0"\r\nset FRAME=%~1\r\nif "%FRAME%"=="" set FRAME=1\r\nset FORJA65_HEADLESS=1\r\nset FORJA65_HEADLESS_FRAMES=%FRAME%\r\nset FORJA65_CAPTURE_FRAME=%FRAME%\r\nset FORJA65_CAPTURE_DIR=scene-capture\r\nset FORJA65_CAPTURE_STOP=1\r\nif exist game.exe goto run\r\nif exist bin\\game.exe (cd bin & goto run)\r\nif exist build-win\\Release\\game.exe (cd build-win\\Release & goto run)\r\necho Execute BUILD-WINDOWS.cmd primeiro.\r\npause\r\nexit /b 1\r\n:run\r\ngame.exe\r\nset CODE=%ERRORLEVEL%\r\necho.\r\nif exist forja65-scene-capture.txt type forja65-scene-capture.txt\r\nif not "%CODE%"=="0" (if exist forja65-last-error.txt type forja65-last-error.txt & pause)\r\nexit /b %CODE%\r\n';
  const romPackBuilder=`#include <cstdint>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
struct R{std::uint32_t off{},len{};};
static std::uint64_t fnv(const std::vector<std::uint8_t>&v){std::uint64_t h=1469598103934665603ull;for(auto b:v){h^=b;h*=1099511628211ull;}return h;}
static void w32(std::ofstream&o,std::uint32_t v){o.write((const char*)&v,4);}static void w64(std::ofstream&o,std::uint64_t v){o.write((const char*)&v,8);}
int main(int argc,char**argv){if(argc<4){std::cerr<<"usage: rom_pack_builder cart-data.bin ranges.txt native-rom-data.bin\\n";return 2;}std::ifstream c(argv[1],std::ios::binary);if(!c){std::cerr<<"cart missing\\n";return 3;}std::vector<std::uint8_t> cart((std::istreambuf_iterator<char>(c)),{});std::ifstream p(argv[2]);if(!p){std::cerr<<"profile missing\\n";return 4;}std::vector<R> rs;std::string line;while(std::getline(p,line)){auto a=line.find("range=0x"),b=line.find(" length=0x");if(a==std::string::npos||b==std::string::npos)continue;R r;r.off=(std::uint32_t)std::stoul(line.substr(a+8,b-(a+8)),nullptr,16);r.len=(std::uint32_t)std::stoul(line.substr(b+10),nullptr,16);if(r.len&&r.off<cart.size()){if((std::uint64_t)r.off+r.len>cart.size())r.len=(std::uint32_t)(cart.size()-r.off);rs.push_back(r);}}if(rs.empty()){std::cerr<<"no ranges\\n";return 5;}std::sort(rs.begin(),rs.end(),[](auto&a,auto&b){return a.off<b.off;});std::vector<R> merged;for(auto r:rs){if(!merged.empty()&&(std::uint64_t)r.off<=((std::uint64_t)merged.back().off+merged.back().len+16u)){auto e=std::max<std::uint64_t>((std::uint64_t)merged.back().off+merged.back().len,(std::uint64_t)r.off+r.len);merged.back().len=(std::uint32_t)(e-merged.back().off);}else merged.push_back(r);}std::ofstream o(argv[3],std::ios::binary|std::ios::trunc);if(!o)return 6;o.write("F65R",4);w32(o,1);w32(o,(std::uint32_t)cart.size());w64(o,fnv(cart));w32(o,(std::uint32_t)merged.size());std::uint64_t bytes=0;for(auto r:merged){w32(o,r.off);w32(o,r.len);o.write((const char*)cart.data()+r.off,r.len);bytes+=r.len;}std::cout<<"FORJA65_ROM_PACK_OK regions="<<merged.size()<<" bytes="<<bytes<<" full="<<cart.size()<<"\\n";return 0;}
`;
  const hostDoc='FORJA65 '+VERSION+' - HOST NATIVO\n\nA fundacao Win32 foi reforcada com ideias reutilizaveis do port DKC3 Native PC v0.7.0.1:\n- XInput + teclado no host Windows.\n- pacing de apresentacao por steady_clock em 60 Hz/50 Hz conforme regiao, sem Sleep(16) fixo.\n- FORJA65_HEADLESS=1 impede abertura da janela para diagnosticos automatizados.\n- runtime_smoke + CTest validam carregamento do cart-data, framebuffer e inicializacao do runtime antes de executar o codigo convertido.\n- BUILD-WINDOWS.cmd e RUN-WINDOWS.cmd acompanham cada projeto gerado.\n- CMake copia assets tambem para a pasta final do executavel em builds multi-config (ex.: Release).\n- Falhas do game gravam forja65-last-error.txt e, no Windows, exibem MessageBox para o erro nao desaparecer.\n- Captura de cena PPU deterministica exporta VRAM/CGRAM/OAM, NPAL/NTIL/NMAP/NSCENE, camada OAM em NSPR, preview PPM e hashes de integridade.\n- A captura registra hash da ROM e do framebuffer para impedir mistura silenciosa de assets entre ROMs/capturas.\n- Oracle runtime registra FLOW/STATE/STACK dinamicos em forja65-oracle-hints.txt sem duplicatas e mantem forja65-oracle-observations.log com contexto de execucao.\n- Hints FLOW vindos de JMP/JSR (abs,X) podem expandir automaticamente vizinhos plausiveis da mesma tabela ROM.\n- RUN-ORACLE.cmd executa headless ate encontrar novo conhecimento ou completar o limite escolhido.\n- Oracle/hints agora carregam rom=<FNV1a64>; conhecimento de outra ROM/revisao e rejeitado pela analise.\n- Replay deterministico: FORJA65_INPUT_RECORD grava joypads por frame e FORJA65_INPUT_REPLAY reproduz exatamente o trace.\n- FORJA65_FRAME_HASHES=1 grava framebuffer/WRAM/PC por frame para comparar replays.\n- BUILD-QUALITY-WINDOWS.cmd ativa warnings-as-errors e sanitizers quando suportados pelo compilador.\n- equivalence_runner valida vetores de equivalencia produzidos por um oracle 65C816 de teste; ele nunca entra no game final.\n\nFORJA65_CAPTURE_FRAME=N captura ao concluir o frame N. FORJA65_CAPTURE_DIR escolhe a pasta e FORJA65_CAPTURE_NAME o nome da cena. FORJA65_CAPTURE_STOP=1 encerra logo apos a captura.\nFORJA65_UNCAPPED=1 desativa o limitador de apresentacao.\nFORJA65_HEADLESS_FRAMES=N encerra teste headless depois de N frames.\n';
  const nativeAuditCmd='@echo off\r\nsetlocal\r\ncd /d "%~dp0"\r\nset FORJA65_HEADLESS=1\r\nset FORJA65_HEADLESS_FRAMES=%~1\r\nif "%FORJA65_HEADLESS_FRAMES%"=="" set FORJA65_HEADLESS_FRAMES=600\r\nset FORJA65_NATIVE_AUDIT=1\r\nif exist forja65-native-dependency.csv del /q forja65-native-dependency.csv\r\nif exist forja65-native-dependency-report.txt del /q forja65-native-dependency-report.txt\r\ncall RUN-WINDOWS.cmd\r\necho.\r\necho Auditoria: forja65-native-dependency.csv e forja65-native-dependency-report.txt\r\npause\r\n';
  const migrationCmd='@echo off\r\nsetlocal\r\ncd /d "%~dp0"\r\nset FORJA65_PPU_MODE=state\r\nset FORJA65_DMA_MODE=native\r\nset FORJA65_AUDIO_MODE=native\r\nset FORJA65_ROM_MODE=hybrid\r\nset FORJA65_NATIVE_AUDIT=1\r\nset FORJA65_HEADLESS=1\r\nset FORJA65_HEADLESS_FRAMES=%~1\r\nif "%FORJA65_HEADLESS_FRAMES%"=="" set FORJA65_HEADLESS_FRAMES=600\r\ncall RUN-WINDOWS.cmd\r\necho.\r\necho Veja forja65-native-dependency-report.txt\r\npause\r\n';
  const romProfileCmd='@echo off\r\nsetlocal\r\ncd /d "%~dp0"\r\nset FORJA65_ROM_MODE=cart\r\nset FORJA65_ROM_PROFILE=1\r\nset FORJA65_HEADLESS=1\r\nset FORJA65_HEADLESS_FRAMES=%~1\r\nif "%FORJA65_HEADLESS_FRAMES%"=="" set FORJA65_HEADLESS_FRAMES=1200\r\nif exist forja65-rom-read-ranges.txt del /q forja65-rom-read-ranges.txt\r\ncall RUN-WINDOWS.cmd\r\necho Perfil: forja65-rom-read-ranges.txt\r\npause\r\n';
  const romPackCmd='@echo off\r\nsetlocal\r\ncd /d "%~dp0"\r\nif not exist forja65-rom-read-ranges.txt (echo Rode RUN-ROM-PROFILE.cmd primeiro.& pause & exit /b 2)\r\nset TOOL=build\\Release\\rom_pack_builder.exe\r\nif not exist "%TOOL%" set TOOL=build\\rom_pack_builder.exe\r\nif not exist "%TOOL%" (echo Compile primeiro com BUILD-WINDOWS.cmd.& pause & exit /b 3)\r\n"%TOOL%" assets\\cart-data.bin forja65-rom-read-ranges.txt assets\\native-rom-data.bin\r\nif errorlevel 1 (pause & exit /b 4)\r\necho Criado assets\\native-rom-data.bin\r\npause\r\n';
  const romNativeCmd='@echo off\r\nsetlocal\r\ncd /d "%~dp0"\r\nif not exist assets\\native-rom-data.bin (echo Crie o pack com BUILD-NATIVE-ROM-PACK.cmd.& pause & exit /b 2)\r\nset FORJA65_ROM_MODE=native\r\nset FORJA65_PPU_MODE=state\r\nset FORJA65_DMA_MODE=native\r\nset FORJA65_AUDIO_MODE=native\r\nset FORJA65_NATIVE_AUDIT=1\r\nset FORJA65_HEADLESS=1\r\nset FORJA65_HEADLESS_FRAMES=%~1\r\nif "%FORJA65_HEADLESS_FRAMES%"=="" set FORJA65_HEADLESS_FRAMES=600\r\ncall RUN-WINDOWS.cmd\r\npause\r\n';
  const captureSpcCmd='@echo off\r\nsetlocal\r\ncd /d "%~dp0"\r\nset FRAME=%~1\r\nif "%FRAME%"=="" set FRAME=300\r\nset /a LIMIT=FRAME+2\r\nset FORJA65_CAPTURE_SPC_FRAME=%FRAME%\r\nset FORJA65_CAPTURE_SPC_STOP=1\r\nset FORJA65_HEADLESS=1\r\nset FORJA65_HEADLESS_FRAMES=%LIMIT%\r\ncall RUN-WINDOWS.cmd\r\necho Captura: forja65-spc-capture\\spc-ram.bin + spc-capture.txt\r\npause\r\n';
  const nativeCutoverCmd='@echo off\r\nsetlocal\r\ncd /d "%~dp0"\r\nset FORJA65_PPU_MODE=state\r\nset FORJA65_DMA_MODE=native\r\nset FORJA65_AUDIO_MODE=native\r\nset FORJA65_ROM_MODE=hybrid\r\nset FORJA65_NATIVE_AUDIT=1\r\nset FORJA65_AUDIO_DUMP=1\r\nset FORJA65_HEADLESS=1\r\nset FORJA65_HEADLESS_FRAMES=%~1\r\nif "%FORJA65_HEADLESS_FRAMES%"=="" set FORJA65_HEADLESS_FRAMES=1200\r\nif exist forja65-native-dependency.csv del /q forja65-native-dependency.csv\r\nif exist forja65-native-dependency-report.txt del /q forja65-native-dependency-report.txt\r\ncall RUN-WINDOWS.cmd\r\necho.\r\necho CUTOVER concluido. Verifique PPU_VIRTUAL_HW, APU_VIRTUAL_HW, DSP_VIRTUAL_HW, DMA fallback e ROM fallback no relatorio.\r\npause\r\n';
  const nativeAudioCmd='@echo off\r\nsetlocal\r\ncd /d "%~dp0"\r\nset FORJA65_AUDIO_MODE=native\r\nset FORJA65_AUDIO_DUMP=1\r\nset FORJA65_HEADLESS=1\r\nset FORJA65_HEADLESS_FRAMES=%~1\r\nif "%FORJA65_HEADLESS_FRAMES%"=="" set FORJA65_HEADLESS_FRAMES=600\r\ncall RUN-WINDOWS.cmd\r\necho Audio PCM: forja65-native-audio.wav\r\npause\r\n';
  const romConvergeCmd='@echo off\r\nsetlocal EnableExtensions\r\ncd /d "%~dp0"\r\nset FRAMES=%~1\r\nif "%FRAMES%"=="" set FRAMES=1200\r\nset GAME=bin\\game.exe\r\nif not exist "%GAME%" set GAME=build-win\\Release\\game.exe\r\nif not exist "%GAME%" (echo Execute BUILD-WINDOWS.cmd primeiro.& pause & exit /b 2)\r\nset FORJA65_HEADLESS=1\r\nset FORJA65_HEADLESS_FRAMES=%FRAMES%\r\nset FORJA65_ROM_MODE=cart\r\nset FORJA65_ROM_PROFILE=1\r\nif exist forja65-rom-read-ranges.txt del /q forja65-rom-read-ranges.txt\r\n"%GAME%" || (echo Falha durante profile.& pause & exit /b 3)\r\nset TOOL=build-win\\Release\\rom_pack_builder.exe\r\nif not exist "%TOOL%" set TOOL=build\\Release\\rom_pack_builder.exe\r\nif not exist "%TOOL%" set TOOL=build\\rom_pack_builder.exe\r\nif not exist "%TOOL%" (echo rom_pack_builder nao encontrado. Recompile.& pause & exit /b 4)\r\n"%TOOL%" assets\\cart-data.bin forja65-rom-read-ranges.txt assets\\native-rom-data.bin || (pause & exit /b 5)\r\nset FORJA65_ROM_PROFILE=\r\nset FORJA65_ROM_MODE=native\r\nset FORJA65_PPU_MODE=state\r\nset FORJA65_DMA_MODE=native\r\nset FORJA65_AUDIO_MODE=native\r\nset FORJA65_NATIVE_AUDIT=1\r\n"%GAME%" || (echo Pack ainda incompleto. Veja forja65-native-rom-missing.txt.& pause & exit /b 6)\r\necho ROM convergence PASS para %FRAMES% frames.\r\npause\r\n';
  const nativePortRunCmd='@echo off\r\nsetlocal\r\ncd /d "%~dp0"\r\nset FORJA65_ROM_MODE=native\r\nset FORJA65_PPU_MODE=state\r\nset FORJA65_DMA_MODE=native\r\nset FORJA65_AUDIO_MODE=native\r\nset FORJA65_AUDIO_DUMP=0\r\ngame.exe\r\nexit /b %ERRORLEVEL%\r\n';
  const packageNativeCmd='@echo off\r\nsetlocal EnableExtensions\r\ncd /d "%~dp0"\r\nif not exist assets\\native-rom-data.bin (echo Falta assets\\native-rom-data.bin. Rode RUN-ROM-CONVERGE.cmd.& pause & exit /b 2)\r\nset GAME=bin\\game.exe\r\nif not exist "%GAME%" set GAME=build-win\\Release\\game.exe\r\nif not exist "%GAME%" (echo game.exe nao encontrado.& pause & exit /b 3)\r\nset FORJA65_HEADLESS=1\r\nset FORJA65_HEADLESS_FRAMES=%~1\r\nif "%FORJA65_HEADLESS_FRAMES%"=="" set FORJA65_HEADLESS_FRAMES=600\r\nset FORJA65_ROM_MODE=native\r\nset FORJA65_PPU_MODE=state\r\nset FORJA65_DMA_MODE=native\r\nset FORJA65_AUDIO_MODE=native\r\n"%GAME%" || (echo O teste native-only falhou. Nao vou empacotar.& pause & exit /b 4)\r\nif exist native-release rmdir /s /q native-release\r\nmkdir native-release\\assets\r\ncopy /y "%GAME%" native-release\\game.exe >nul\r\ncopy /y assets\\native-rom-data.bin native-release\\assets\\native-rom-data.bin >nul\r\ncopy /y RUN-NATIVE-PORT.cmd native-release\\RUN-NATIVE-PORT.cmd >nul\r\ncopy /y forja65-build-manifest.txt native-release\\forja65-build-manifest.txt >nul\r\necho Criado native-release SEM cart-data.bin.\r\npause\r\n';
  const nativeAuditDoc='Forja65 Native Hardware Cutover v0.3.29\n\nInspirado no fluxo de migracao progressiva do SuperMarioWorldRecomp. O objetivo nao e chamar hardware virtual de nativo: a Forja mede exatamente quanto do port ainda toca ROM, PPU, APU, DMA/HDMA e cart chips em runtime.\n\nUse RUN-NATIVE-AUDIT.cmd [frames]. O CSV grava deltas por frame; o report final mostra totais e o primeiro PC recompilado que tocou cada subsistema. Isso orienta a proxima ilha nativa a substituir. CPU_AOT=YES significa 65C816 recompilado; PPU_VIRTUAL_HW/APU_VIRTUAL_HW mostram dependencias restantes.\n';
  const analysis=JSON.stringify({forja65_version:VERSION,title:a.title,mapping:a.mapping,rom_fingerprint:a.romFingerprint||projectRomHash,runtime_hints_rejected:a.runtimeHintsRejected||0,reset_pc:'0x'+hex(a.resetPc,6),decoded_instructions:a.decoded,native_instructions:a.native,partial_instructions:a.partial,unsupported_instructions:a.unsupported,cfg:{entry_points:a.entryPoints,functions:a.cfgFunctions,function_state_variants:a.cfgFunctionVariants,blocks:a.cfgBlocks,edges:a.cfgEdges,calls:a.cfgCalls,return_adjacent_seeds:a.returnAdjacentSeeds||0,runtime_hints_imported:a.runtimeHintsImported||0,dispatch_targets:knownTargets.size,static_return_targets:a.staticReturnTargets||[],synthetic_return_targets:a.syntheticReturnTargets||[]},hardware:{native_accesses:a.hardwareNative,pending_accesses:a.hardwarePending,renderer:a.renderer,hdma:a.hdma,apu_bridge:a.apuBridge,boot_hardware:a.bootHardware,native_frame_loop:true,joypad:true,joypad_serial:true,rom_data_bus:true,wram_port:true,math_unit:true,scanline_renderer:true,window_math:true,mode7_basic:true,ppu_priority:true,direct_color:true,extbg:true,pseudo_hires:true,hires_modes_5_6:true,interlace_basic:true,overscan_239:true,scanline_irq:true,master_cycle_irq:true,subscanline_raster:true,instruction_master_cycles:true,bus_speed_6_8_12:true,ppu_write_raster_sync:true,hd_output:true,integer_scale:true,aspect_preserved:true,letterbox:true,wram_refresh_stall:true,dma_bus_stall:true,hdma_bus_stall:true,interrupt_entry_timing:true,hdma_midframe_mask:true,spc_dsp_backend:true,brr_decoder:true,spc_upload_manifest:true,function_entry_guard:true,persistent_apu_ack:false,runtime_ring_trace:true,instruction_watchdog:true,instruction_watchdog_cached:true,runtime_hints:true,iterative_dispatch:true,resumable_dispatch:true,static_return_sites:true,program_bank_label_sync:false,program_bank_dispatch_sync:true,rom_mirror_dispatch:true,resumable_any_compiled_return:true,return_adjacent_code_sweep:true,stack_rts_pei_dataflow:true,stack_rts_lowbyte_table_inference:true,stack_trampoline_call_summaries:true,local_computed_jump_runs:true,inline_indexed_jump_table_ranges:true,inline_structural_dispatch_tables:true,pea_inline_dispatch_tables:true,dp_indexed_table_range_inference:true,stable_cpp_shards:true,generated_shard_count:32,vector_table_code_guard:true,msvc_macro_safe_runtime:true,issue_deduplication:true,stable_generated_header:true,cpu_emulation_state_parity:true,spc700_runtime_interpreter:true,spc_cpu_port_isolation:true,long_jump_program_bank:true,tail_vector_register_propagation:true,runtime_return_table_expansion:true,runtime_return_table_dedup:true,runtime_return_table_observed_state:true,carry_aware_cfg:true,carry_aware_runtime_hints:true,pea_stack_bootstrap:true,interrupt_state_variants:true,interrupt_stack_frames:true,rti_state_restore:true,fragmented_cpp_units:true,compact_table_dispatch:true,headless_frame_limit_env:true,native_host_foundation:true,xinput_gamepad:true,clock_frame_pacing:true,headless_no_window:true,cmake_runtime_smoke:true,windows_build_run_scripts:true,post_build_assets:true,fatal_error_log:true,fatal_error_messagebox:true,native_scene_capture:true,scene_capture_rom_hash:true,scene_capture_frame_hash:true,scene_capture_asset_manifest:true,scene_capture_ppm_preview:true,native_sprite_capture:true,nspr_oam_layer:true,oracle_runtime_learning:true,oracle_unique_hints:true,oracle_observation_log:true,oracle_flow_table_expansion:true,rom_bound_oracle_hints:true,deterministic_input_replay:true,frame_hash_trace:true,strict_build_option:true,sanitizer_build_option:true,equivalence_vector_harness:true,build_integrity_manifest:true,qa_status_file:true,native_dependency_audit:true,per_frame_hardware_usage:true,rom_runtime_read_counter:true,ppu_runtime_access_counter:true,apu_runtime_access_counter:true,dma_hdma_byte_counter:true,first_hardware_use_pc:true,ppu_state_only_native_scanout:true,native_dma_bbus_fastpath:true,native_hdma_bbus_fastpath:true,spc_snapshot_capture:true,native_spc_aot_hook:true,rom_read_profile:true,sparse_native_rom_pack:true,native_rom_only_mode:true,ppu_fallback_accounting:true,native_dsp_clock:true,native_dsp_pcm:true,native_audio_wav_dump:true,native_rom_coverage_report:true,rom_convergence_script:true,native_release_without_cart:true},status:a.status,issues:a.issues.slice(0,1000)},null,2);
  const files={'CMakeLists.txt':cm,'BUILD-WINDOWS.cmd':buildCmd,'BUILD-QUALITY-WINDOWS.cmd':qualityCmd,'RUN-WINDOWS.cmd':runCmd,'RUN-HEADLESS.cmd':headlessCmd,'RUN-ORACLE.cmd':oracleCmd,'RUN-CAPTURE-SCENE.cmd':captureCmd,'RUN-INPUT-RECORD.cmd':recordCmd,'RUN-INPUT-REPLAY.cmd':replayCmd,'RUN-NATIVE-AUDIT.cmd':nativeAuditCmd,'RUN-NATIVE-MIGRATION.cmd':migrationCmd,'RUN-NATIVE-CUTOVER.cmd':nativeCutoverCmd,'RUN-NATIVE-AUDIO.cmd':nativeAudioCmd,'RUN-ROM-CONVERGE.cmd':romConvergeCmd,'PACKAGE-NATIVE-WITHOUT-ROM.cmd':packageNativeCmd,'RUN-NATIVE-PORT.cmd':nativePortRunCmd,'RUN-ROM-PROFILE.cmd':romProfileCmd,'BUILD-NATIVE-ROM-PACK.cmd':romPackCmd,'RUN-ROM-NATIVE.cmd':romNativeCmd,'RUN-CAPTURE-SPC.cmd':captureSpcCmd,'docs/HOST-RUNTIME.txt':hostDoc,'docs/ORACLE-RUNTIME.txt':'Forja65 Oracle Runtime\n\n1. Execute BUILD-WINDOWS.cmd.\n2. Rode RUN-ORACLE.cmd.\n3. Se o runtime encontrar destino/estado/retorno ainda nao recompilado, ele grava forja65-oracle-hints.txt sem duplicatas.\n4. Na Forja65, use Importar Oracle/hints. A ROM e reanalisada automaticamente com o conhecimento acumulado.\n5. Gere novamente o port.\n\nPara JMP/JSR (abs,X), um alvo observado tambem pode revelar vizinhos plausiveis da mesma tabela ROM, reduzindo rodadas manuais.\n','docs/DETERMINISTIC-QA.txt':'Forja65 Deterministic QA\n\nRUN-INPUT-RECORD.cmd grava controles por frame. RUN-INPUT-REPLAY.cmd reproduz o mesmo trace. FORJA65_FRAME_HASHES=1 grava hashes de framebuffer/WRAM/PC por frame. Compare forja65-frame-hashes.txt entre builds para detectar regressao deterministica.\n','docs/NATIVE-DEPENDENCY-AUDIT.txt':nativeAuditDoc,'docs/NATIVE-HARDWARE-MIGRATION.txt':'Forja65 v0.3.29 - native hardware cutover\n\nPPU: FORJA65_PPU_MODE=state usa state-only + scanout C++; o relatorio agora separa ppu_native_* de ppu_fallback_* e PPU_NATIVE_ONLY so fica YES com fallback zero.\nDMA/HDMA: FORJA65_DMA_MODE=native mantem fast-path B-bus e mede bytes native/fallback.\nSPC700: captura + hook AOT continuam disponiveis.\nDSP: FORJA65_AUDIO_MODE=native avanca o mixer BRR/DSP C++ a 32 kHz pelo master clock, gera PCM e pode salvar forja65-native-audio.wav com FORJA65_AUDIO_DUMP=1.\nROM: RUN-ROM-CONVERGE.cmd faz profile -> pack -> teste native-only. PACKAGE-NATIVE-WITHOUT-ROM.cmd so cria native-release quando o teste passa e nao copia cart-data.bin.\n','docs/EQUIVALENCE-ORACLE.txt':'Equivalence harness (TEST ONLY)\n\nO game final nao contem interpretador. Gere tests/equivalence-cases.txt com resultados esperados obtidos da rotina 65C816 original em um oracle de teste separado. Cada linha aceita entry,a,x,y,s,d,db,pb,e,m,x8,c e expect_a/expect_x/expect_y/expect_s/expect_d/expect_db/expect_pb/expect_c. O CTest equivalence_vectors valida o C++ nativo contra esses vetores; sem vetores ele aparece como SKIP.\n','tests/runtime_smoke.cpp':runtimeSmoke,'tests/scene_capture_smoke.cpp':sceneCaptureSmoke,'tests/oracle_learning_smoke.cpp':oracleLearningSmoke,'tests/deterministic_input_smoke.cpp':deterministicInputSmoke,'tests/native_dependency_smoke.cpp':nativeDependencySmoke,'tests/native_migration_smoke.cpp':nativeMigrationSmoke,'tools/rom_pack_builder.cpp':romPackBuilder,'tests/equivalence_runner.cpp':equivalenceRunner,'tests/equivalence-cases.txt':'# Vetores esperados do oracle 65C816 de teste. Ex.: entry=0x808000 a=0x1 expect_a=0x2\n','src/runtime.hpp':runtimeHpp(),'src/generated.hpp':h,'src/dispatch.cpp':dispatch,'src/main.cpp':main,...unitFiles,'assets/cart-data.bin':rom.data,'analysis.json':analysis,'compatibility-report.txt':reportText(a),'README.txt':`Port C++ gerado pelo Forja65 ${VERSION} para ${a.title}.\n\nA v0.3.29 avanca o cutover nativo: PPU mede fallback real e pode provar PPU_NATIVE_ONLY; DSP/BRR roda em clock nativo de 32 kHz e gera PCM/WAV; ROM mostra cobertura do pack, ganha convergencia automatica e empacotamento sem cart-data.bin quando o teste native-only passa.\n\nA v0.3.28 iniciou a retirada real do hardware virtual: PPU state-only/native scanout, DMA/HDMA B-bus fast-path, captura+hook AOT de SPC700 e pack esparso de dados ROM.\n\nA v0.3.27 adiciona auditoria de dependencia nativa inspirada no SuperMarioWorldRecomp: contadores por frame de ROM/WRAM/PPU/APU/DMA/HDMA, primeiro PC que toca cada subsistema, relatorio final e RUN-NATIVE-AUDIT.cmd.\n\nA v0.3.26 adiciona QA deterministico e equivalencia: hints presos ao hash da ROM, replay/gravacao de controles por frame, hashes de framebuffer/WRAM, build strict/sanitizers, manifesto de integridade e harness de vetores ROM↔C++.\n\nA v0.3.25 adiciona Oracle runtime generico: fluxos, estados e retornos dinamicos desconhecidos viram hints unicos reaproveitaveis; JMP/JSR (abs,X) observados podem expandir automaticamente tabelas vizinhas. Use RUN-ORACLE.cmd e reimporte forja65-oracle-hints.txt na interface.\n\nA v0.3.23 mantem a fundacao de host do DKC3 Native PC: XInput + teclado, pacing por relogio em vez de Sleep(16), modo headless sem janela, CTest/runtime_smoke e scripts BUILD/RUN Windows. A camada 65C816 continua sendo recompilada pela Forja; estas mudancas melhoram o host PC e o diagnostico, sem misturar logica especifica do DKC3.\n\nA v0.3.23 tambem incorpora da arquitetura DKC3 v0.7.10 um pipeline generico de captura de cena PPU: VRAM/CGRAM/OAM, NPAL/NTIL/NMAP/NSCENE, camada de sprites OAM em NSPR, preview PPM, hash do framebuffer, hash da ROM e manifesto de integridade. Use RUN-CAPTURE-SCENE.cmd N para capturar um frame.\n\nA base v0.3.21 de Carry (C), runtime hints, STACK-RTL, shards estaveis, jump tables, interrupcoes, mirrors, SPC700 e dispatcher retomavel permanece ativa.\n\nFORJA65_HEADLESS=1 executa sem janela. FORJA65_HEADLESS_FRAMES limita frames em testes. FORJA65_UNCAPPED=1 remove o pacing de apresentacao. FORJA65_WATCHDOG_INSTRUCTIONS interrompe loops longos e grava forja65-crash-trace.txt.\n\nStatus atual: ${a.status}.\n`};
  const manifestLines=['FORJA65_BUILD_MANIFEST 1','forja65_version='+VERSION,'title='+a.title,'mapping='+a.mapping,'rom_fingerprint='+projectRomHash,'rom_size='+rom.data.length,'reset_pc=0x'+hex(a.resetPc,6),'decoded='+a.decoded,'native='+a.native,'partial='+a.partial,'unsupported='+a.unsupported,'generated_cpp_shards='+Object.keys(unitFiles).length,'generated_shard_capacity=32'];
  for(const name of Object.keys(files).sort()){const v=files[name];let size=0,hash='';if(typeof v==='string'){const enc=typeof TextEncoder!=='undefined'?new TextEncoder().encode(v):Uint8Array.from(Buffer.from(v,'utf8'));size=enc.length;hash=fnv1a64Bytes(enc);}else if(v instanceof Uint8Array){size=v.length;hash=fnv1a64Bytes(v);}else if(v&&v.buffer){const q=new Uint8Array(v.buffer,v.byteOffset||0,v.byteLength||v.length||0);size=q.length;hash=fnv1a64Bytes(q);}if(hash)manifestLines.push('file='+name+' size='+size+' fnv1a64='+hash);}
  files['forja65-build-manifest.txt']=manifestLines.join('\n')+'\n';
  const map=Framework.buildNativeMap(rom,a,options.trace||null,options.profile||{});
  Object.assign(files,FrameworkTemplates);
  files['src/native_hooks.cpp']='#include \"generated.hpp\"\nvoid forja65_register_native_hooks(SnesRuntime&hw){(void)hw;}\n';
  files['CMakeLists.txt']=files['CMakeLists.txt'].replace('add_library(forja65_generated OBJECT ','option(FORJA65_ENABLE_TRACE \"Enable bounded runtime trace\" OFF)\nadd_compile_definitions(FORJA65_ENABLE_TRACE=$<BOOL:${FORJA65_ENABLE_TRACE}>)\nadd_library(forja65_generated OBJECT src/native_hooks.cpp ');
  files['README.txt']='Forja65 '+VERSION+' - '+a.title+'\n\nProjeto C++ para migracao incremental. CPU 65C816 recompilada = TRANSLATED. PPU state-only, DMA/HDMA B-bus, SPC700/DSP virtual e packs ROM continuam dependencias de hardware/dados. Apenas substituicoes host validadas contam como NATIVE. O native score permanece nao medido.\n\nEdite src/native_hooks.cpp para registrar implementacoes host nas entradas de rotina descobertas. FORJA65_EXECUTION=reference ignora os hooks. Retorne os master clocks originais do corpo + RTS/RTL; o dispatcher cuida da pilha de retorno. Hooks sao aplicados a JSR/JSL, nunca automaticamente a interrupcoes, jumps locais ou labels de retomada.\n\nO trace precisa de cmake -DFORJA65_ENABLE_TRACE=ON e FORJA65_TRACE=forja-trace.csv. Limite padrao 250000 eventos; o rodape registra descartes e finalizacao. Importe o CSV na interface Forja65 ou no CLI para atualizar native-map.json. Trace limitado ou interrompido nao prova cobertura completa.\n\nanalysis/function-analysis.json preserva o CFG gerado; analysis/native-map.json registra dependencias observadas por rotina e chamadas. profiles/game_config.json vincula nomes/aliases e heuristicas ao fingerprint da ROM. reports/compatibility-report.json distingue traducao e fallback. ForjaIR/ForjaRenderer sao uma base de palette/scroll host; composicao completa ainda nao esta implementada.\n\nBUILD-WINDOWS.cmd compila o port. O runtime pode precisar de assets/cart-data.bin ou native ROM pack: remover o arquivo ROM nao elimina automaticamente sua representacao de dados.\n';
  files['docs/NATIVE-HARDWARE-MIGRATION.txt']='Os nomes antigos de flags native em PPU/DMA/DSP/ROM foram preservados por compatibilidade. PPU_NATIVE_ONLY mede ausencia de acesso ao caminho legado dentro do hardware virtual. FORJA65_AUDIO_MODE=native seleciona DSP/BRR C++, ainda simulacao do hardware. RUN-ROM-CONVERGE.cmd e PACKAGE-NATIVE-WITHOUT-ROM.cmd continuam disponiveis; empacotar dados em native-rom-data.bin nao elimina sua representacao ROM. Eles selecionam caminhos C++ de hardware virtual ou armazenamento de dados; nao comprovam port host semantico. Use reports/compatibility-report.json e o native-map para as novas metricas.\n';
  files['docs/EQUIVALENCE-ORACLE.txt']=files['docs/EQUIVALENCE-ORACLE.txt'].replace('O game final nao contem interpretador.','A CPU usa codigo recompilado; o fallback SPC700 pode conter interpretador.');
  files['analysis/native-map.json']=JSON.stringify(map,null,2);
  files['analysis/runtime-hints.txt']=formatRuntimeHints(a.runtimeHints||[])+'\n';
  files['analysis/function-analysis.json']=JSON.stringify({rom:map.rom,mapping:a.mapping,decoded:a.decoded,native:a.native,coprocessor:a.coprocessor,functions:a.functions.map(f=>({start:f.start,stateSig:f.functionKey,calls:f.calls,instructions:f.instructions.map(i=>({pc:i.pc,mnemonic:i.mnemonic,operand:i.operand,mode:i.mode}))}))},null,2);
  files['analysis/native-map.md']=Framework.nativeMapMarkdown(map);
  files['reports/compatibility-report.json']=JSON.stringify(Framework.compatibilityReport(map,a),null,2);
  files['reports/compatibility-report.md']=Framework.nativeMapMarkdown(map);
  files['profiles/game_config.json']=JSON.stringify(map.profile,null,2);
  files['CMakeLists.txt']+='\nadd_executable(framework_smoke tests/framework_smoke.cpp)\ntarget_include_directories(framework_smoke PRIVATE src)\nforja65_quality(framework_smoke)\nif(WIN32)\n  target_link_libraries(framework_smoke PRIVATE user32 gdi32 xinput9_1_0 winmm)\nendif()\nadd_test(NAME framework_smoke COMMAND framework_smoke)\n';
  files['RUN-FORJA-TRACE.cmd']='@echo off\r\nsetlocal\r\ncd /d "%~dp0"\r\nset FORJA65_TRACE=forja-trace.csv\r\nset FORJA65_TRACE_LIMIT=250000\r\nset FORJA65_HEADLESS=1\r\nset FORJA65_HEADLESS_FRAMES=%~1\r\nif "%FORJA65_HEADLESS_FRAMES%"=="" set FORJA65_HEADLESS_FRAMES=120\r\ncall RUN-WINDOWS.cmd\r\necho Rebuild with FORJA65_ENABLE_TRACE=ON if no trace was produced.\r\npause\r\n';
  for(const name of ['BUILD-WINDOWS.cmd','BUILD-QUALITY-WINDOWS.cmd'])files[name]=files[name].replace('rom_pack_builder equivalence_runner','rom_pack_builder equivalence_runner framework_smoke');
  files['RUN-ORACLE.cmd']=files['RUN-ORACLE.cmd'].replaceAll('bingame.exe','bin\\game.exe').replaceAll('build-winReleasegame.exe','build-win\\Release\\game.exe').replaceAll('cd build-winRelease','cd build-win\\Release');
  // Recompute manifest after adding framework files; preserve original integrity format.
  files['forja65-build-manifest.txt']=manifestLines.filter(line=>!line.startsWith('file=')).concat(Object.keys(files).filter(n=>n!=='forja65-build-manifest.txt').sort().map(n=>{const b=files[n] instanceof Uint8Array?files[n]:new TextEncoder().encode(String(files[n]));return 'file='+n+' size='+b.length+' fnv1a64='+fnv1a64Bytes(b);})).join('\n')+'\n';
  return files;
}

// ---------------- SPC700 capture -> direct C++ recompiler (v0.2.5) ----------------
const SPC_META={
  0x00:['NOP','imp',1,'native'],0xE8:['MOV_A_IMM','imm',2,'native'],0xCD:['MOV_X_IMM','imm',2,'native'],0x8D:['MOV_Y_IMM','imm',2,'native'],
  0xE4:['MOV_A_DP','dp',2,'native'],0xF4:['MOV_A_DPX','dp',2,'native'],0xE5:['MOV_A_ABS','abs',3,'native'],0xF5:['MOV_A_ABSX','abs',3,'native'],0xF6:['MOV_A_ABSY','abs',3,'native'],
  0xF8:['MOV_X_DP','dp',2,'native'],0xF9:['MOV_X_DPY','dp',2,'native'],0xE9:['MOV_X_ABS','abs',3,'native'],0xEB:['MOV_Y_DP','dp',2,'native'],0xFB:['MOV_Y_DPX','dp',2,'native'],0xEC:['MOV_Y_ABS','abs',3,'native'],
  0xC4:['MOV_DP_A','dp',2,'native'],0xD4:['MOV_DPX_A','dp',2,'native'],0xC5:['MOV_ABS_A','abs',3,'native'],0xD5:['MOV_ABSX_A','abs',3,'native'],0xD6:['MOV_ABSY_A','abs',3,'native'],0xD8:['MOV_DP_X','dp',2,'native'],0xCB:['MOV_DP_Y','dp',2,'native'],0x8F:['MOV_DP_IMM','imm_dp',3,'native'],
  0x08:['OR_A_IMM','imm',2,'native'],0x04:['OR_A_DP','dp',2,'native'],0x05:['OR_A_ABS','abs',3,'native'],0x28:['AND_A_IMM','imm',2,'native'],0x24:['AND_A_DP','dp',2,'native'],0x25:['AND_A_ABS','abs',3,'native'],
  0x48:['EOR_A_IMM','imm',2,'native'],0x44:['EOR_A_DP','dp',2,'native'],0x45:['EOR_A_ABS','abs',3,'native'],0x68:['CMP_A_IMM','imm',2,'native'],0x64:['CMP_A_DP','dp',2,'native'],0x65:['CMP_A_ABS','abs',3,'native'],
  0x88:['ADC_A_IMM','imm',2,'native'],0x84:['ADC_A_DP','dp',2,'native'],0x85:['ADC_A_ABS','abs',3,'native'],0xA8:['SBC_A_IMM','imm',2,'native'],0xA4:['SBC_A_DP','dp',2,'native'],0xA5:['SBC_A_ABS','abs',3,'native'],
  0xBC:['INC_A','imp',1,'native'],0x3D:['INC_X','imp',1,'native'],0xFC:['INC_Y','imp',1,'native'],0x9C:['DEC_A','imp',1,'native'],0x1D:['DEC_X','imp',1,'native'],0xDC:['DEC_Y','imp',1,'native'],
  0x60:['CLRC','imp',1,'native'],0x80:['SETC','imp',1,'native'],0xED:['NOTC','imp',1,'native'],0xE0:['CLRV','imp',1,'native'],0x20:['CLRP','imp',1,'native'],0x40:['SETP','imp',1,'native'],
  0x2F:['BRA','rel',2,'native'],0xF0:['BEQ','rel',2,'native'],0xD0:['BNE','rel',2,'native'],0x90:['BCC','rel',2,'native'],0xB0:['BCS','rel',2,'native'],0x30:['BMI','rel',2,'native'],0x10:['BPL','rel',2,'native'],0x50:['BVC','rel',2,'native'],0x70:['BVS','rel',2,'native'],
  0x3F:['CALL','abs',3,'native'],0x5F:['JMP','abs',3,'native'],0x6F:['RET','imp',1,'native'],0x7F:['RETI','imp',1,'native'],0xFF:['STOP','imp',1,'native'],0xEF:['SLEEP','imp',1,'native'],
  0x2D:['PUSH_A','imp',1,'native'],0x4D:['PUSH_X','imp',1,'native'],0x6D:['PUSH_Y','imp',1,'native'],0x0D:['PUSH_PSW','imp',1,'native'],0xAE:['POP_A','imp',1,'native'],0xCE:['POP_X','imp',1,'native'],0xEE:['POP_Y','imp',1,'native'],0x8E:['POP_PSW','imp',1,'native']
};
function parseSpcManifest(text=''){
  const out={upload_base:0,upload_count:0,entry_candidate:0};
  for(const line of String(text).split(/\r?\n/)){const m=line.match(/^([a-z0-9_]+)=(.+)$/i);if(!m)continue;let v=m[2].trim();if(/^0x/i.test(v))v=parseInt(v,16);else if(/^\d+$/.test(v))v=parseInt(v,10);out[m[1]]=v;}
  return out;
}
function loadSpcCapture(input,manifestText=''){
  let d=input instanceof Uint8Array?input:new Uint8Array(input);if(d.length>65536)throw new Error('Captura SPC maior que 64 KiB');if(d.length<65536){const q=new Uint8Array(65536);q.set(d);d=q;}
  const manifest=parseSpcManifest(manifestText),entry=((manifest.entry_candidate||manifest.upload_base||0)&0xFFFF);return {data:d,manifest,entry};
}
function spcDecodeOne(cap,pc){pc&=0xFFFF;const op=cap.data[pc],m=SPC_META[op]||['OP_'+hex(op,2),'imp',1,'unsupported'],len=m[2];let operand=0,raw=[op];for(let i=1;i<len;i++){const b=cap.data[(pc+i)&0xFFFF];raw.push(b);operand|=b<<(8*(i-1));}let target=null;if(m[1]==='rel'){const r=operand&255,sv=(r&0x80)?r-256:r;target=(pc+len+sv)&0xFFFF;}else if(['CALL','JMP'].includes(m[0]))target=operand&0xFFFF;return {pc,opcode:op,mnemonic:m[0],mode:m[1],size:len,operand,raw,status:m[3],target};}
function spcIsCond(m){return ['BEQ','BNE','BCC','BCS','BMI','BPL','BVC','BVS'].includes(m);}
function spcAnalyze(cap,max=8192){
  const by=new Map(),work=[cap.entry&0xFFFF],issues=[],edges=[],calls=[];while(work.length&&by.size<max){const pc=work.pop()&0xFFFF;if(by.has(pc))continue;const i=spcDecodeOne(cap,pc);by.set(pc,i);const next=(pc+i.size)&0xFFFF;const add=(t,kind)=>{t&=0xFFFF;edges.push({from:pc,to:t,kind});if(!by.has(t))work.push(t);};if(i.status==='unsupported'){issues.push({pc,opcode:i.opcode,detail:'opcode SPC700 $'+hex(i.opcode,2)+' ainda sem semantica C++'});continue;}if(i.mnemonic==='BRA'){add(i.target,'branch');continue;}if(spcIsCond(i.mnemonic)){add(i.target,'branch');add(next,'fallthrough');continue;}if(i.mnemonic==='CALL'){calls.push({from:pc,to:i.target});add(i.target,'call');add(next,'return-site');continue;}if(i.mnemonic==='JMP'){add(i.target,'jump');continue;}if(['RET','RETI','STOP','SLEEP'].includes(i.mnemonic))continue;add(next,'next');}
  const ins=[...by.values()].sort((a,b)=>a.pc-b.pc),native=ins.filter(i=>i.status==='native').length,unsupported=ins.length-native;return {entry:cap.entry,instructions:ins,decoded:ins.length,native,unsupported,ratio:ins.length?100*native/ins.length:0,issues,edges,calls,status:unsupported?'SPC700_PARTIAL':'SPC700_CFG_NATIVE'};
}
function spcFormat(i){return hex(i.pc,4)+'  '+i.raw.map(b=>hex(b,2)).join(' ').padEnd(9,' ')+' '+i.mnemonic+(i.mode==='imm'?' #$'+hex(i.operand,2):i.mode==='dp'?' $'+hex(i.operand,2):i.mode==='abs'?' $'+hex(i.operand,4):i.mode==='rel'?' -> $'+hex(i.target,4):i.mode==='imm_dp'?' #$'+hex(i.operand&255,2)+',$'+hex((i.operand>>8)&255,2):'')+(i.status!=='native'?' ; UNSUPPORTED':'');}
function spcReportText(a){let s=`FORJA65 ${VERSION} - RELATORIO SPC700\n\nEntrada: $${hex(a.entry,4)}\nDecodificadas: ${a.decoded}\nNativas diretas: ${a.native}\nNao suportadas: ${a.unsupported}\nCobertura: ${a.ratio.toFixed(1)}%\nChamadas: ${a.calls.length}\nArestas CFG: ${a.edges.length}\nSTATUS: ${a.status}\n`;if(a.issues.length){s+='\nProblemas:\n';for(const q of a.issues.slice(0,300))s+=`- $${hex(q.pc,4)} opcode $${hex(q.opcode,2)}: ${q.detail}\n`;}s+='\nA v0.2.5 gera C++ por labels/gotos e CFG; nao existe loop fetch/decode/execute de opcodes SPC700.\n';return s;}
function spcCpp(cap,a){
  const known=new Set(a.instructions.map(i=>i.pc));const L=p=>'S_'+hex(p,4);let body='';
  const next=i=>(i.pc+i.size)&0xFFFF;const rd=i=>i.mode==='dp'?`apu.spcRead(dp(cpu,0x${hex(i.operand,2)}u))`:`apu.spcRead(0x${hex(i.operand,4)}u)`;
  const alu=(op,src)=>{if(op==='OR')return`cpu.a=(std::uint8_t)(cpu.a|${src}); nz(cpu,cpu.a);`;if(op==='AND')return`cpu.a=(std::uint8_t)(cpu.a&${src}); nz(cpu,cpu.a);`;if(op==='EOR')return`cpu.a=(std::uint8_t)(cpu.a^${src}); nz(cpu,cpu.a);`;if(op==='CMP')return`cmp8(cpu,cpu.a,${src});`;if(op==='ADC')return`adc8(cpu,${src});`;return`sbc8(cpu,${src});`;};
  for(const i of a.instructions){body+=`${L(i.pc)}:\n  cpu.pc=0x${hex(i.pc,4)}u; if(++steps>=budget)return;\n`;if(i.status!=='native'){body+=`  throw std::runtime_error("SPC700 opcode nao recompilado em $${hex(i.pc,4)}: $${hex(i.opcode,2)}");\n`;continue;}const n=next(i);switch(i.mnemonic){
    case'NOP':body+=`  goto ${L(n)};\n`;break;case'MOV_A_IMM':body+=`  cpu.a=0x${hex(i.operand,2)}u; nz(cpu,cpu.a); goto ${L(n)};\n`;break;case'MOV_X_IMM':body+=`  cpu.x=0x${hex(i.operand,2)}u; nz(cpu,cpu.x); goto ${L(n)};\n`;break;case'MOV_Y_IMM':body+=`  cpu.y=0x${hex(i.operand,2)}u; nz(cpu,cpu.y); goto ${L(n)};\n`;break;
    case'MOV_A_DP':body+=`  cpu.a=apu.spcRead(dp(cpu,0x${hex(i.operand,2)}u)); nz(cpu,cpu.a); goto ${L(n)};\n`;break;case'MOV_A_DPX':body+=`  cpu.a=apu.spcRead(dp(cpu,(std::uint8_t)(0x${hex(i.operand,2)}u+cpu.x))); nz(cpu,cpu.a); goto ${L(n)};\n`;break;case'MOV_A_ABS':body+=`  cpu.a=apu.spcRead(0x${hex(i.operand,4)}u); nz(cpu,cpu.a); goto ${L(n)};\n`;break;case'MOV_A_ABSX':body+=`  cpu.a=apu.spcRead((std::uint16_t)(0x${hex(i.operand,4)}u+cpu.x)); nz(cpu,cpu.a); goto ${L(n)};\n`;break;case'MOV_A_ABSY':body+=`  cpu.a=apu.spcRead((std::uint16_t)(0x${hex(i.operand,4)}u+cpu.y)); nz(cpu,cpu.a); goto ${L(n)};\n`;break;
    case'MOV_X_DP':body+=`  cpu.x=apu.spcRead(dp(cpu,0x${hex(i.operand,2)}u)); nz(cpu,cpu.x); goto ${L(n)};\n`;break;case'MOV_X_DPY':body+=`  cpu.x=apu.spcRead(dp(cpu,(std::uint8_t)(0x${hex(i.operand,2)}u+cpu.y))); nz(cpu,cpu.x); goto ${L(n)};\n`;break;case'MOV_X_ABS':body+=`  cpu.x=apu.spcRead(0x${hex(i.operand,4)}u); nz(cpu,cpu.x); goto ${L(n)};\n`;break;case'MOV_Y_DP':body+=`  cpu.y=apu.spcRead(dp(cpu,0x${hex(i.operand,2)}u)); nz(cpu,cpu.y); goto ${L(n)};\n`;break;case'MOV_Y_DPX':body+=`  cpu.y=apu.spcRead(dp(cpu,(std::uint8_t)(0x${hex(i.operand,2)}u+cpu.x))); nz(cpu,cpu.y); goto ${L(n)};\n`;break;case'MOV_Y_ABS':body+=`  cpu.y=apu.spcRead(0x${hex(i.operand,4)}u); nz(cpu,cpu.y); goto ${L(n)};\n`;break;
    case'MOV_DP_A':body+=`  apu.spcWrite(dp(cpu,0x${hex(i.operand,2)}u),cpu.a); goto ${L(n)};\n`;break;case'MOV_DPX_A':body+=`  apu.spcWrite(dp(cpu,(std::uint8_t)(0x${hex(i.operand,2)}u+cpu.x)),cpu.a); goto ${L(n)};\n`;break;case'MOV_ABS_A':body+=`  apu.spcWrite(0x${hex(i.operand,4)}u,cpu.a); goto ${L(n)};\n`;break;case'MOV_ABSX_A':body+=`  apu.spcWrite((std::uint16_t)(0x${hex(i.operand,4)}u+cpu.x),cpu.a); goto ${L(n)};\n`;break;case'MOV_ABSY_A':body+=`  apu.spcWrite((std::uint16_t)(0x${hex(i.operand,4)}u+cpu.y),cpu.a); goto ${L(n)};\n`;break;case'MOV_DP_X':body+=`  apu.spcWrite(dp(cpu,0x${hex(i.operand,2)}u),cpu.x); goto ${L(n)};\n`;break;case'MOV_DP_Y':body+=`  apu.spcWrite(dp(cpu,0x${hex(i.operand,2)}u),cpu.y); goto ${L(n)};\n`;break;case'MOV_DP_IMM':body+=`  apu.spcWrite(dp(cpu,0x${hex((i.operand>>8)&255,2)}u),0x${hex(i.operand&255,2)}u); goto ${L(n)};\n`;break;
    case'OR_A_IMM':case'AND_A_IMM':case'EOR_A_IMM':case'CMP_A_IMM':case'ADC_A_IMM':case'SBC_A_IMM':{const op=i.mnemonic.split('_')[0];body+=`  ${alu(op,'0x'+hex(i.operand,2)+'u')} goto ${L(n)};\n`;break;}case'OR_A_DP':case'AND_A_DP':case'EOR_A_DP':case'CMP_A_DP':case'ADC_A_DP':case'SBC_A_DP':{const op=i.mnemonic.split('_')[0];body+=`  ${alu(op,rd(i))} goto ${L(n)};\n`;break;}case'OR_A_ABS':case'AND_A_ABS':case'EOR_A_ABS':case'CMP_A_ABS':case'ADC_A_ABS':case'SBC_A_ABS':{const op=i.mnemonic.split('_')[0];body+=`  ${alu(op,rd(i))} goto ${L(n)};\n`;break;}
    case'INC_A':body+=`  cpu.a++; nz(cpu,cpu.a); goto ${L(n)};\n`;break;case'INC_X':body+=`  cpu.x++; nz(cpu,cpu.x); goto ${L(n)};\n`;break;case'INC_Y':body+=`  cpu.y++; nz(cpu,cpu.y); goto ${L(n)};\n`;break;case'DEC_A':body+=`  cpu.a--; nz(cpu,cpu.a); goto ${L(n)};\n`;break;case'DEC_X':body+=`  cpu.x--; nz(cpu,cpu.x); goto ${L(n)};\n`;break;case'DEC_Y':body+=`  cpu.y--; nz(cpu,cpu.y); goto ${L(n)};\n`;break;
    case'CLRC':body+=`  cpu.c=false; goto ${L(n)};\n`;break;case'SETC':body+=`  cpu.c=true; goto ${L(n)};\n`;break;case'NOTC':body+=`  cpu.c=!cpu.c; goto ${L(n)};\n`;break;case'CLRV':body+=`  cpu.v=false; cpu.h=false; goto ${L(n)};\n`;break;case'CLRP':body+=`  cpu.p=false; goto ${L(n)};\n`;break;case'SETP':body+=`  cpu.p=true; goto ${L(n)};\n`;break;
    case'BRA':body+=`  goto ${L(i.target)};\n`;break;case'BEQ':body+=`  if(cpu.z){goto ${L(i.target)};} goto ${L(n)};\n`;break;case'BNE':body+=`  if(!cpu.z){goto ${L(i.target)};} goto ${L(n)};\n`;break;case'BCC':body+=`  if(!cpu.c){goto ${L(i.target)};} goto ${L(n)};\n`;break;case'BCS':body+=`  if(cpu.c){goto ${L(i.target)};} goto ${L(n)};\n`;break;case'BMI':body+=`  if(cpu.n){goto ${L(i.target)};} goto ${L(n)};\n`;break;case'BPL':body+=`  if(!cpu.n){goto ${L(i.target)};} goto ${L(n)};\n`;break;case'BVC':body+=`  if(!cpu.v){goto ${L(i.target)};} goto ${L(n)};\n`;break;case'BVS':body+=`  if(cpu.v){goto ${L(i.target)};} goto ${L(n)};\n`;break;
    case'CALL':body+=`  push16(cpu,apu,0x${hex(n,4)}u); goto ${L(i.target)};\n`;break;case'JMP':body+=`  goto ${L(i.target)};\n`;break;case'RET':case'RETI':body+=`  cpu.pc=pop16(cpu,apu); goto DISPATCH;\n`;break;case'PUSH_A':body+=`  push8(cpu,apu,cpu.a); goto ${L(n)};\n`;break;case'PUSH_X':body+=`  push8(cpu,apu,cpu.x); goto ${L(n)};\n`;break;case'PUSH_Y':body+=`  push8(cpu,apu,cpu.y); goto ${L(n)};\n`;break;case'PUSH_PSW':body+=`  push8(cpu,apu,pack(cpu)); goto ${L(n)};\n`;break;case'POP_A':body+=`  cpu.a=pop8(cpu,apu); goto ${L(n)};\n`;break;case'POP_X':body+=`  cpu.x=pop8(cpu,apu); goto ${L(n)};\n`;break;case'POP_Y':body+=`  cpu.y=pop8(cpu,apu); goto ${L(n)};\n`;break;case'POP_PSW':body+=`  unpack(cpu,pop8(cpu,apu)); goto ${L(n)};\n`;break;case'STOP':body+=`  cpu.stopped=true; return;\n`;break;case'SLEEP':body+=`  cpu.sleeping=true; return;\n`;break;default:body+=`  throw std::runtime_error("SPC700 gerador sem caso para ${i.mnemonic}");\n`;}}
  let dispatch='DISPATCH:\n  switch(cpu.pc){\n';for(const i of a.instructions)dispatch+=`    case 0x${hex(i.pc,4)}u: goto ${L(i.pc)};\n`;dispatch+='    default: throw std::runtime_error("SPC700 destino dinamico nao recompilado");\n  }\n';
  return `#include "runtime.hpp"\n#include <cstdint>\n#include <stdexcept>\nstruct SpcCpuState{std::uint8_t a{},x{},y{},sp{0xEF};std::uint16_t pc{0x${hex(a.entry,4)}};bool n{},v{},p{},h{},z{},c{},stopped{},sleeping{};};\n[[maybe_unused]] static std::uint16_t dp(const SpcCpuState&c,std::uint8_t d){return(std::uint16_t)((c.p?0x100:0)+d);}\n[[maybe_unused]] static void nz(SpcCpuState&c,std::uint8_t v){c.z=v==0;c.n=(v&0x80)!=0;}\n[[maybe_unused]] static void cmp8(SpcCpuState&c,std::uint8_t a,std::uint8_t b){std::uint16_t r=(std::uint16_t)a-b;c.c=a>=b;nz(c,(std::uint8_t)r);}\n[[maybe_unused]] static void adc8(SpcCpuState&c,std::uint8_t b){std::uint16_t r=(std::uint16_t)c.a+b+(c.c?1:0);c.v=((~(c.a^b)&(c.a^(std::uint8_t)r)&0x80)!=0);c.h=((c.a&15)+(b&15)+(c.c?1:0))>15;c.c=r>255;c.a=(std::uint8_t)r;nz(c,c.a);}\n[[maybe_unused]] static void sbc8(SpcCpuState&c,std::uint8_t b){adc8(c,(std::uint8_t)~b);}\n[[maybe_unused]] static std::uint8_t pack(const SpcCpuState&c){return(c.n?0x80:0)|(c.v?0x40:0)|(c.p?0x20:0)|(c.h?0x08:0)|(c.z?0x02:0)|(c.c?1:0);}\n[[maybe_unused]] static void unpack(SpcCpuState&c,std::uint8_t q){c.n=q&0x80;c.v=q&0x40;c.p=q&0x20;c.h=q&8;c.z=q&2;c.c=q&1;}\n[[maybe_unused]] static void push8(SpcCpuState&c,ApuBridge&a,std::uint8_t v){a.spcWrite((std::uint16_t)(0x100|c.sp),v);c.sp--;}\n[[maybe_unused]] static std::uint8_t pop8(SpcCpuState&c,ApuBridge&a){c.sp++;return a.spcRead((std::uint16_t)(0x100|c.sp));}\n[[maybe_unused]] static void push16(SpcCpuState&c,ApuBridge&a,std::uint16_t v){push8(c,a,(std::uint8_t)(v>>8));push8(c,a,(std::uint8_t)v);}\n[[maybe_unused]] static std::uint16_t pop16(SpcCpuState&c,ApuBridge&a){std::uint8_t lo=pop8(c,a),hi=pop8(c,a);return(std::uint16_t)(lo|(hi<<8));}\nvoid forja65_spc_run_slice(SpcCpuState&cpu,ApuBridge&apu,unsigned budget){if(cpu.stopped||cpu.sleeping)return;unsigned steps=0;goto DISPATCH;\n${dispatch}${body}}\nvoid forja65_native_spc_tick(ApuBridge&apu,unsigned masterCycles){static SpcCpuState cpu;static bool init=false;static unsigned rem=0;if(!init){cpu.pc=0x${hex(a.entry,4)}u;init=true;}rem+=masterCycles;while(rem>=42u&&!cpu.stopped&&!cpu.sleeping){rem-=42u;forja65_spc_run_slice(cpu,apu,2u);}}\n`;
}
function generateSpcProject(cap,a){const src=spcCpp(cap,a);return {'CMakeLists.txt':'cmake_minimum_required(VERSION 3.20)\nproject(Forja65SpcNative LANGUAGES CXX)\nset(CMAKE_CXX_STANDARD 20)\nadd_executable(spc_test main.cpp spc700_native.cpp)\n','runtime.hpp':runtimeHpp(),'spc700_native.cpp':src,'spc700-report.txt':spcReportText(a),'spc700-disasm.txt':a.instructions.map(spcFormat).join('\n'),'capture.bin':cap.data,'capture.txt':Object.entries(cap.manifest).map(([k,v])=>k+'='+v).join('\n'),'main.cpp':'#include "runtime.hpp"\n#include <iostream>\nstruct SpcCpuState; void forja65_spc_run_slice(SpcCpuState&,ApuBridge&,unsigned); void forja65_native_spc_tick(ApuBridge&,unsigned); int main(){std::cout<<"Forja65 SPC700 native module gerado\\n";return 0;}\n'};}

function crcTable(){const t=new Uint32Array(256);for(let n=0;n<256;n++){let c=n;for(let k=0;k<8;k++)c=(c&1)?0xEDB88320^(c>>>1):c>>>1;t[n]=c>>>0;}return t;}const CRCT=crcTable();
function crc32(b){let c=0xFFFFFFFF;for(const v of b)c=CRCT[(c^v)&255]^(c>>>8);return(c^0xFFFFFFFF)>>>0;}
function u16(n){return new Uint8Array([n&255,(n>>>8)&255]);}function u32(n){return new Uint8Array([n&255,(n>>>8)&255,(n>>>16)&255,(n>>>24)&255]);}
function concat(arrs){let n=arrs.reduce((a,b)=>a+b.length,0),o=new Uint8Array(n),p=0;for(const a of arrs){o.set(a,p);p+=a.length;}return o;}
function buildZip(files){const enc=new TextEncoder(),parts=[],central=[];let offset=0,count=0;for(const[name,val]of Object.entries(files)){const nb=enc.encode(name),data=val instanceof Uint8Array?val:enc.encode(String(val)),crc=crc32(data);const lh=concat([new Uint8Array([80,75,3,4]),u16(20),u16(0),u16(0),u16(0),u16(0),u32(crc),u32(data.length),u32(data.length),u16(nb.length),u16(0),nb,data]);parts.push(lh);const ch=concat([new Uint8Array([80,75,1,2]),u16(20),u16(20),u16(0),u16(0),u16(0),u16(0),u32(crc),u32(data.length),u32(data.length),u16(nb.length),u16(0),u16(0),u16(0),u16(0),u32(0),u32(offset),nb]);central.push(ch);offset+=lh.length;count++;}const cdOffset=offset,cd=concat(central);return concat([...parts,cd,new Uint8Array([80,75,5,6]),u16(0),u16(0),u16(count),u16(count),u32(cd.length),u32(cdOffset),u16(0)]);}
function makeSyntheticRom(){const d=new Uint8Array(0x8000);d.fill(0xEA);const h=0x7FC0,title='FORJA65 SYNTH TEST';for(let i=0;i<21;i++)d[h+i]=i<title.length?title.charCodeAt(i):32;d[h+0x15]=0x20;d[h+0x16]=0x00;d[h+0x17]=0x05;d[h+0x18]=0;d[h+0x1C]=0xCB;d[h+0x1D]=0xED;d[h+0x1E]=0x34;d[h+0x1F]=0x12;// Vetores sinteticos nao usados ficam nulos para nao parecerem handlers reais.
for(let o=0x20;o<0x40;o++)d[h+o]=0;
d[h+0x3C]=0x00;d[h+0x3D]=0x80;const code=[0x78,0x9C,0x10,0x00,0x18,0xA9,0x10,0x69,0x05,0x8D,0x00,0x20,0xE8,0xEA,0x60];d.set(code,0);return d;}
return {...Framework,VERSION,MAP,loadRom,romFingerprint,fnv1a64Bytes,parseRuntimeHints,formatRuntimeHints,mergeRuntimeHints,snesToRom,isRomAddress,systemEntryPoints,resetAddress,decodeOne,decodeLinear,formatInstruction,analyze,focusAnalyze,nativeDispatchPlan,nativeDispatchCpp,reportText,generateProject,buildZip,makeSyntheticRom,hex,parseSpcManifest,loadSpcCapture,spcDecodeOne,spcAnalyze,spcFormat,spcReportText,generateSpcProject,spcCpp};
});
