@echo off
cd /d "%~dp0"
call "%~dp0Forja65-Windows-App.cmd"
