'use strict';
const fs=require('fs'),path=require('path'),os=require('os'),cp=require('child_process'),C=require('../forja65-core');
const files=C.generateProject(C.loadRom(C.makeSyntheticRom()),C.analyze(C.loadRom(C.makeSyntheticRom()),128));
const d=fs.mkdtempSync(path.join(os.tmpdir(),'forja-sprite-row-'));
// Observe real sprite loop work without adding instrumentation to production.
let h=files['src/runtime.hpp'].replace('struct PpuState {','struct PpuState { mutable unsigned testSpriteVisits{};');
h=h.replaceAll('for(int si=127;si>=0;--si){','for(int si=127;si>=0;--si){testSpriteVisits++;');
fs.writeFileSync(path.join(d,'runtime.hpp'),h);fs.copyFileSync(path.join(__dirname,'fixtures/ppu-v034-reference.hpp'),path.join(d,'reference.hpp'));
fs.writeFileSync(path.join(d,'probe.cpp'),String.raw`#include "runtime.hpp"
#include "reference.hpp"
#include <cassert>
#include <iostream>
static unsigned seed=17;static unsigned rnd(){seed=seed*1664525u+1013904223u;return seed;}
template<class P>void init(P&p,unsigned n){seed=17+n;for(auto&b:p.vram)b=rnd()>>24;for(auto&b:p.cgram)b=rnd()>>24;for(auto&b:p.oam)b=rnd()>>24;
 p.brightness=15;p.bgmode=n&7;p.obsel=(n%8)<<5;p.tm=0x1f;p.ts=0x1f;p.setini=(n&8)?9:0;p.cgwsel=(n*19)&255;p.cgadsub=(n*53)|0x3f;
 p.fixedR=7;p.fixedG=11;p.fixedB=13;p.w12sel=n*11;p.w34sel=n*7;p.wobjsel=n*13;p.wbglog=n*3;p.wobjlog=n;p.tmw=n;p.tsw=n*5;
 p.wh[0]=30;p.wh[1]=180;p.wh[2]=70;p.wh[3]=230;p.m7[0]=256;p.m7[3]=256;
 for(unsigned i=0;i<4;i++){p.bgsc[i]=4+i*4;p.bgnba[i]=i+1;p.scrollX[i]=i*3;p.scrollY[i]=i*7;}}
int main(){
 // Complexity budget: one scan of the 128 OAM entries per rendered segment.
 PpuState p;p.brightness=15;p.tm=0x10;std::vector<std::uint32_t>f;p.renderOutputSegment(f,32,0,256);std::cout<<"sprite visits="<<p.testSpriteVisits<<std::endl;assert(p.testSpriteVisits<=128);
 // Hand-checked mutation: OAM, tile data and CGRAM all change between segments.
 PpuState live;live.brightness=15;live.tm=0x10;for(unsigned i=1;i<128;i++)live.oam[i*4+1]=240;
 live.oam[0]=100;live.cgram[258]=31;live.vram[0]=255;std::vector<std::uint32_t> lf;live.renderOutputSegment(lf,0,0,64);
 live.oam[0]=80;live.cgram[258]=0xe0;live.cgram[259]=3;live.vram[0]=0x80;live.renderOutputSegment(lf,0,64,256);
 assert(lf[80]==0xff00ff00u&&lf[81]==0xff000000u&&lf[100]==0xff000000u);
 // Pixel equivalence to the frozen renderer across modes, windows and math.
 for(unsigned n=0;n<64;n++){PpuState a;ReferencePpuState b;init(a,n);init(b,n);std::vector<std::uint32_t>x,y;
 for(int row:{0,7,31,111,223}){for(unsigned field:{0,1}){a.renderOutputScanline(x,row,field);b.renderOutputScanline(y,row,field);assert(x==y);}}
 // A mutation between segments must be visible immediately (no stale row cache).
 x.clear();y.clear();a.renderOutputSegment(x,7,0,73);b.renderOutputSegment(y,7,0,73);
 a.oam[1]=b.oam[1]=7;a.oam[0]=b.oam[0]=80;a.cgram[258]=b.cgram[258]=31;a.vram[0]=b.vram[0]=255;
 a.obsel=b.obsel=0;a.renderOutputSegment(x,7,73,a.outputWidth());b.renderOutputSegment(y,7,73,b.outputWidth());assert(x==y);
 }
 std::cout<<"sprite row equivalence: PASS (64 scenes, five rows, two fields, live segment mutations)\n";
}`);
cp.execFileSync('g++',['-std=c++20','-O2','-Wall','-Wextra','-Werror','probe.cpp','-o','probe'],{cwd:d});
cp.execFileSync(path.join(d,'probe'),[],{cwd:d,stdio:'inherit'});
