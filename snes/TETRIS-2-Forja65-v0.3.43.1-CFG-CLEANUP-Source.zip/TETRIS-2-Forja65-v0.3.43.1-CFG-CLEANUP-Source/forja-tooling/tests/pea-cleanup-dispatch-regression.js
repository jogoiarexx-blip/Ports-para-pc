const fs=require('fs'),os=require('os'),path=require('path'),cp=require('child_process'),assert=require('assert'),C=require('../forja65-core');
// Unlike an immediate RTS trampoline, the synthetic return restores X/DB and
// stores a cleanup value before the table. Handler discovery must retain it.
const data=C.makeSyntheticRom();data.fill(0xdb,0,0x100);
data.set([0x18,0xfb,0xc2,0x30,0x20,0x20,0x80,0xdb],0);
data.set([0x8b,0xa6,0x10,0xf4,0x28,0x80,0x7c,0x33,0x80,
  0xa6,0x12,0xa9,0xff,0xff,0x9d,0xdc,0x02,0xab,0x60,
  0x37,0x80,0x3d,0x80,0xa9,7,0,0x85,0x14,0x60,0xa9,9,0,0x85,0x14,0x60],0x20);
const rom=C.loadRom(data),a=C.analyze(rom,1024);
for(const pc of [0x8029,0x8037,0x803d])assert(a.instructions.some(i=>i.pc===pc),'missing cleanup dispatch target '+pc.toString(16));
// decodeOne reads contiguous operands. Reject a continuation instruction that
// straddles the PB boundary instead of trusting bytes from the next ROM bank.
const high=C.loadRom(C.makeSyntheticRom());high.header.mapping='HiROM';high.data=new Uint8Array(0x20000);high.data.fill(0xdb);
high.data.set([0x00,0xa9,0x34,0x12,0x60,7,0,0x60],0);
high.data.set([0x4c,0xf9,0xff],0xffdd);
high.data.set([0xf4,0xfe,0xff,0x7c,5,0,0xc2],0xfff9);high.data[0x10000]=0x20;
assert(!C.analyze(high,1024,'target=c0ffdd kind=FLOW e=0 m=1 x=1 c=?').instructions.some(i=>i.pc===0xc00007),'cross-bank operand must not infer handlers');
for(const [name,at,value] of [['wrong PEA',0x24,0x27],['missing RTS',0x32,0xea],['branch in cleanup',0x29,0x80],['unknown status',0x29,0x28]]){
  const b=Uint8Array.from(data);b[at]=value;
  assert(!C.analyze(C.loadRom(b),1024).instructions.some(i=>i.pc===0x803d),name+' must not seed handlers');
}
const files=C.generateProject(rom,a),dir=fs.mkdtempSync(path.join(os.tmpdir(),'forja-pea-cleanup-'));
for(const [n,v]of Object.entries(files)){const p=path.join(dir,n);fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,v);}
fs.writeFileSync(path.join(dir,'probe.cpp'),`#include "src/generated.hpp"
#include <cassert>
int main(){for(unsigned x:{0u,2u}){SnesRuntime h("assets/cart-data.bin",MapperKind::LoROM);CpuState c;
h.ram[0x10]=x;h.ram[0x12]=4;c.db=0x7e;
forja65_dispatch(c,h,0x8000,0xffffff);
assert(h.ram[0x14]==(x?9:7)&&h.ram[0x2e0]==0xff&&h.ram[0x2e1]==0xff);
assert(c.x==4&&c.db==0x7e&&c.s==0x1ff&&h.nativeReturns.empty()&&h.stopped);}}
`);
const units=Object.keys(files).filter(n=>/^src\/(dispatch|generated_\d+|native_hooks)\.cpp$/.test(n));
cp.execFileSync('g++',['-std=c++20','-O1','probe.cpp',...units,'-o','probe'],{cwd:dir});
cp.execFileSync(path.join(dir,'probe'),[],{cwd:dir,env:{...process.env,FORJA65_HEADLESS:'1'}});
console.log('pea-cleanup-dispatch-regression: OK (two handlers, cleanup effects, stack/DB, invalid anchors rejected)');
