'use strict';
const fs=require('fs'),path=require('path'),C=require('../forja65-core');
function hintKey(h){return [h.rom,h.target,h.from,h.kind,h.state.emulation,h.state.m8,h.state.x8,h.state.carry].join('|');}
function readOptional(file){return fs.existsSync(file)?fs.readFileSync(file,'utf8'):'';}
function writeFiles(out,files){fs.mkdirSync(out,{recursive:true});const changed=[];for(const [n,v]of Object.entries(files)){const p=path.join(out,n),bytes=typeof v==='string'?Buffer.from(v):Buffer.from(v);if(fs.existsSync(p)&&fs.readFileSync(p).equals(bytes))continue;fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,bytes);changed.push(n);}return changed;}
function refreshManifest(project,changed){const file=path.join(project,'forja65-build-manifest.txt'),lines=fs.readFileSync(file,'utf8').trimEnd().split('\n');for(const [name,value]of Object.entries(changed)){const bytes=typeof value==='string'?Buffer.from(value):Buffer.from(value),line='file='+name+' size='+bytes.length+' fnv1a64='+C.fnv1a64Bytes(bytes),i=lines.findIndex(l=>l.startsWith('file='+name+' size='));if(i>=0)lines[i]=line;else lines.push(line);}writeFiles(project,{'forja65-build-manifest.txt':lines.join('\n')+'\n'});}
function generate({romPath,out,max=65536,hints='',profile,trace=null,knowledge=null,update=false}){
 const rom=C.loadRom(new Uint8Array(fs.readFileSync(romPath)),path.basename(romPath)),hash=C.romFingerprint(rom),existing=fs.existsSync(out)&&fs.readdirSync(out).length>0;
 if(existing&&!update)throw new Error('Output already exists; choose another --out or use --update.');
 if(existing){for(const n of ['analysis.json','analysis/generation-options.json','profiles/game_config.json']){const file=path.join(out,n);if(fs.existsSync(file)){const meta=JSON.parse(fs.readFileSync(file,'utf8')),identity=meta.rom_fingerprint||meta.rom;if(identity&&identity!==hash)throw new Error('Existing project belongs to another ROM; choose a new output directory.');}}}
 const savedProfile=path.join(out,'profiles/game_config.json');profile=profile||(existing&&fs.existsSync(savedProfile)?JSON.parse(fs.readFileSync(savedProfile,'utf8')):{});
 const savedKnowledge=path.join(out,'analysis/knowledge-pack.json');if(!knowledge&&existing&&fs.existsSync(savedKnowledge))knowledge=JSON.parse(fs.readFileSync(savedKnowledge,'utf8'));if(knowledge){knowledge=C.normalizeKnowledgePack(knowledge,hash);profile=C.mergeKnowledgeProfile(profile,knowledge,hash);}
 const texts=[hints];if(existing)for(const n of ['analysis/runtime-hints.txt','forja65-runtime-hints.txt','forja65-oracle-hints.txt'])texts.push(readOptional(path.join(out,n)));
 const byKey=new Map();for(const text of texts)for(const h of C.parseRuntimeHints(text)){const key=hintKey(h),prev=byKey.get(key);if(!prev||h.observed>prev.observed)byKey.set(key,h);}const bound=[...byKey.values()];if(bound.some(h=>h.rom&&h.rom!==hash))throw new Error('Runtime hints belong to another ROM.');for(const h of bound)h.rom=hash;
 const savedHints=C.formatRuntimeHints(bound),a=C.analyze(rom,max,bound,{knowledge}),files=C.generateProject(rom,a,{profile,trace});
 if(knowledge)files['analysis/knowledge-pack.json']=JSON.stringify(knowledge,null,2)+'\n';
 files['analysis/runtime-hints.txt']=savedHints+'\n';
 files['analysis/generation-options.json']=JSON.stringify({schema:1,rom:hash,max},null,2)+'\n';
 const preserved={};if(existing)for(const n of ['src/native_hooks.cpp','tests/equivalence-cases.txt']){const p=path.join(out,n);if(fs.existsSync(p))files[n]=fs.readFileSync(p,'utf8');}
 const changed=writeFiles(out,files);for(const n of ['analysis/runtime-hints.txt','analysis/generation-options.json','src/native_hooks.cpp','tests/equivalence-cases.txt'])preserved[n]=files[n];refreshManifest(out,preserved);
 return {rom,a,hints:savedHints,changed};
}
module.exports={writeFiles,refreshManifest,generate,readOptional,hintKey};
