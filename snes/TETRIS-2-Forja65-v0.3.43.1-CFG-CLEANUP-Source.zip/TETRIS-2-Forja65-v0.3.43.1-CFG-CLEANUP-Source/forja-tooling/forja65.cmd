@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (echo Node.js is required only for CLI mode. Use Forja65-Windows-App.cmd for the interface.& exit /b 2)
node tools\forja65.js %*
