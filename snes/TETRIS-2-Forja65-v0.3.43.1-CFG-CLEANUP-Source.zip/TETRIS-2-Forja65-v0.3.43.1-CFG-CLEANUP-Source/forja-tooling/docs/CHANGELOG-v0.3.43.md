# Forja65 v0.3.43 — Handler Equivalence Crossfeed

- `native-dispatch` now accepts `--proofs forja65.handler-equivalence.v1` and can promote individual handlers instead of treating the whole dispatcher as all-or-nothing.
- A full cutover proof must match the ROM fingerprint, dispatcher site, handler target, ROM span fingerprint, `scope=handler-abi`, and `verification.result=PASS`.
- `dependency-boundary` is preserved separately from full equivalence. It can mark a reviewed native prefix/body as ready without setting `equivalence_proven` or removing fallback.
- Generated handler metadata now distinguishes `translation_candidate`, `native_body_ready`, and `equivalence_proven`.
- Dispatch plans report `partial_handler_execution_ready`, count proven semantic handlers, and count dependency-boundary handlers.
- DKC3 crossfeed proves `$B9A319` under its semantic handler ABI while `$B9A589` remains dependency-boundary because `$BB8591` is not yet natively closed.
