# Estado da v0.3.34

Causa da tela preta após configuração Normal corrigida no DMA genérico. Preparação do ROUND 1 e início da partida observados em capturas reais; esquerda, rotação A e queda com Baixo comparadas em replays isolados. Replay Normal de 6000 frames sem novos hints ou forced blank; terminou na tela TRY AGAIN, aguardando escolha após a derrota.

70 testes Forja passaram; build Release com avisos como erros passou; 7 CTests passaram e o teste externo sem vetores ficou SKIP. Interface validada em DOM simulado. Revisão independente aprovou a mudança.

Esta é uma validação limitada ao replay e ao início da partida, não ao jogo completo. Windows e equivalência ao console ainda não foram testados. O hardware virtual e os dados ROM continuam usados; tradução da CPU não comprova migração completa do hardware. Sem novo benchmark de velocidade.

Veja validation/RESULTADOS-v0.3.34.md para evidências, resultados e instruções de compilação.
