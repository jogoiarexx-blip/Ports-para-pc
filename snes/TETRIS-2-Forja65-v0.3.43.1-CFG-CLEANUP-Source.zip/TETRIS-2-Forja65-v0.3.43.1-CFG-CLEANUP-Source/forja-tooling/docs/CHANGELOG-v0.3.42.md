# Forja65 v0.3.42 — Native Dispatch Plan

- Added `native-dispatch` to convert a ROM-bound, domain-proven indirect table into a deterministic native routing plan.
- The plan preserves ordered table entries (including aliases), observed command IDs, unique handler targets, focused CFG metrics and fallback status.
- A handler is only marked `translation_candidate` when focused CFG has no `CFG-DYNAMIC`/`FOCUS-DECODE`; this is deliberately **not** semantic equivalence.
- Generated C++ exposes constexpr route/handler tables. `equivalence_proven` defaults false, so generated routing cannot silently remove the 65C816 fallback.
- DKC3 `$B9A157`: 27 routes, 25 unique handlers, 20 unique translation candidates, 5 unique fallback-required handlers. Command 8 remains structurally routable but was not observed in the audited ROM scripts.
