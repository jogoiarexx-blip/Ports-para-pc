# Forja65 v0.3.33 — tabelas inline e watchdog

O crash enviado aponta um JMP (abs,X) precedido de PEA, com retorno RTS seguido de tabela inline. O gerador agora reconhece essa convenção, verifica a âncora de retorno e o intervalo da tabela e compila seus handlers e continuação. Não depende de endereços do Tetris ou de um índice concreto observado.

O watchdog passa a ler seu limite da variável de ambiente ao criar o runtime. Cada instrução compara somente o contador com esse limite. A falha no limite continua gerando o trace, como antes. Alterações à variável de ambiente dentro de um processo já iniciado não mudam o limite desse runtime.

Testes novos exercitam ambos os índices vindos da RAM, retorno pela pilha, rejeição de âncora inválida, número de consultas à variável e limite exato de instruções. Os hints do usuário foram preservados no port e vinculados ao fingerprint original da ROM.

O retorno preserva PB ao cruzar FFFF -> 0000; o caso HiROM foi aprovado após revisão. A execução longa passou do CFG original, mas ficou em tela preta na preparação da fase, conforme STATUS e relatório.
