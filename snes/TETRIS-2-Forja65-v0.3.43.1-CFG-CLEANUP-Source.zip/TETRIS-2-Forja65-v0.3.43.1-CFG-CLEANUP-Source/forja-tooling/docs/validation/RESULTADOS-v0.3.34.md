# Forja65 v0.3.34 — fase após a tela preta

A causa da tela preta foi corrigida no DMA genérico do Forja. O replay Normal passou da configuração, mostrou ROUND 1 e entrou no tabuleiro com peças ativas. Movimento à esquerda, rotação com A e queda acelerada com Baixo foram confirmados em replays separados.

## Causa e mudança

DMAP 08 deveria repetir o byte zero da origem ROM 808D46, transferindo 2048 bytes pelo porto WRAM para a região 7E2000. O Forja interpretava os bits de endereço fixo e decremento ao contrário. A memória em 7E2406 recebeu instruções da ROM em vez de zeros; os vinte bytes observados coincidiram exatamente com a sequência invertida da ROM em 808940. Isso deixou os dez candidatos do tabuleiro ocupados e impediu a preparação da fase de terminar. O trace registra a escrita DMA em 829175.

O runtime agora interpreta D3 como endereço fixo e D4 como decremento. Ao avançar, preserva o banco e faz wrap no endereço de 16 bits. A regra é compartilhada pelos caminhos virtual/native e pelas duas direções. Nenhum endereço específico do Tetris foi inserido no código do Forja; os endereços acima pertencem apenas ao diagnóstico.

O novo teste reproduziu a falha antes da correção e passou depois. Cobre preenchimento fixo a partir da ROM, fixed com decremento ativado, incremento/decremento nas fronteiras do banco, DMA reverso e ambos os caminhos. A revisão independente aprovou o delta.

## Validação

| Verificação | Resultado |
| --- | --- |
| Suíte Forja | 70/70 passaram |
| Interface | Eventos e fluxos verificados em DOM simulado |
| C++ GCC 13/Linux, Release, avisos como erros | Compilação completa passou |
| CTest | 7 passaram; equivalência externa ficou SKIP por falta de vetores |
| Entrada na fase | Captura 1250: ROUND 1; captura 1699: peças ativas e próxima peça |
| Controles isolados | Esquerda move 8 pixels; A gira; Baixo acelera a queda e antecipa a próxima peça |
| Execução padrão / reference | Os 2200 hashes por frame de framebuffer, WRAM e PC coincidiram |
| Replay Normal prolongado | 6000 frames, 83,660,394 instruções, saída 0, forced blank 0, nenhum novo hint |

No frame 5999, a captura mostra a tela TRY AGAIN após perder a partida. O replay não envia comandos depois do frame 1720; portanto, termina aguardando essa escolha. Reiniciar por YES/NO não foi validado nesta rodada.

Os pares de controles coincidiram em framebuffer, WRAM e PC até o comando diferente. Primeiras diferenças visuais: esquerda no frame 1602, A no 1652 e Baixo no 1703. Capturas e OAM exportado comprovam os efeitos visuais; os hashes completos permitem reproduzir a comparação.

A correção do DMA permitiu alcançar código que antes não era executado. Foram aprendidos 19 hints observados no replay, vinculados ao fingerprint original 8c0b44eecc03e2e1. A validação curta convergiu em 15 rodadas e a longa em 6. Não há salto de preparação nem memória do jogo forçada artificialmente. Perfil, hooks e limite de análise 65536 foram preservados.

## Pacotes e limites

O ZIP Tetris contém código C++, dados do port fornecido, ferramentas, hints, replays e evidências. Extraia em uma pasta nova, execute BUILD-WINDOWS.cmd e depois RUN-WINDOWS.cmd. VALIDAR-NORMAL.cmd repete os 2200 frames iniciais com Node.js, CMake e compilador instalados. O ZIP Forja Portable atualiza o gerador; o ZIP Source-and-Tests inclui a suíte e os logs.

A compilação e os replays foram executados em Linux. Não foi validado um EXE Windows nesta máquina. O período de 6000 frames deste replay não comprova todas as fases ou modos, fidelidade audiovisual completa ou equivalência ao console. Não foi feito benchmark novo de velocidade na v0.3.34. A otimização do watchdog da v0.3.33 permanece.

Evidências: validation/root-cause/proof.json, writes-before.log e wram-before.bin; validation/convergence-normal-2200.json e convergence-normal-6000.json; validation/controls/comparison.json, RESULTADOS.md e capturas; validation/frame-1699.png e frame-5999.png; forja-tooling e analysis/runtime-hints.txt. Logs da suíte, compilação e CTest estão em docs/validation do Forja.
