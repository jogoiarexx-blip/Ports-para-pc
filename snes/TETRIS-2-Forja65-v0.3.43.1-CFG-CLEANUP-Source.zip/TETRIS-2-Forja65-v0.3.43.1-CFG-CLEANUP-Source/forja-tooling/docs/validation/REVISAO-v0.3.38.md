# Revisão v0.3.38 — focused crossfeed

## Testes diretamente afetados

PASS:

- `cross-project-knowledge-v0337-regression.js`
- `focused-crossfeed-v0338-regression.js`
- `state-aware-cfg-v022-regression.js`
- `tail-vector-propagation-v0315-regression.js`
- `vector-table-guard-v0330-regression.js`
- `native-map-framework-regression.js`
- `cfg-direct-v014-regression.js`
- `carry-aware-cfg-v0321-regression.js`

Também foi executado `focus-analyze` contra a ROM real do DKC3 com 14 alvos. Todos retornaram categoria do knowledge pack; 3 issues de CFG foram preservados em vez de ocultados.

## Limite desta validação

`node tools/test.js` foi iniciado, mas a suíte histórica completa inclui regressões de hardware/convergência que excederam o limite de execução disponível antes de terminar. O timeout não foi contado como PASS nem como falha funcional. A validação desta versão, portanto, declara os oito testes acima e o caso real DKC3, não uma execução completa dos 74 testes em uma única passada.
