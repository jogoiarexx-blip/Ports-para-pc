# Forja65 e Tetris 2 v0.3.35 — desempenho geral

A otimização do renderizador foi aplicada ao Forja e ao Tetris regenerado. A mediana de processamento do replay dos menus ficou **3.11× mais rápida** e a do replay que entra na partida ficou **3.27× mais rápida**, nesta máquina Linux headless. Pixels, WRAM e PC coincidiram em todos os registros comparados. A pausa, retomada e escolha Try Again foram executadas; a captura final mostra a partida novamente ativa.

## Resultado medido

| Replay | Antes v0.3.34 | Depois v0.3.35 | Ganho de velocidade | Redução de tempo |
| --- | --- | --- | --- | --- |
| Menus e entrada da fase, 1200 frames | 15.74 s | 5.07 s | 3.11× | 67.80% |
| Menus + fase + comandos, 2200 frames | 36.07 s | 11.02 s | 3.27× | 69.45% |

Foram três pares por cenário, alternando a ordem das versões, execução sequencial e sem compilação concorrente. GCC 13/Linux, Release O3, trace compilado desativado, headless reference/cart, mesmo replay e dados ROM, watchdog 100 milhões e hashes por frame ativados. Cada processo começou em uma pasta nova, sem save prévio. Os 20400 registros de framebuffer, WRAM e PC coincidiram. Contadores de instruções/NMI/IRQ e hashes finais também coincidiram em cada cenário.

O cenário de 2200 frames inclui os menus; a tabela não é uma medição isolada dos frames da partida. Velocidade headless mede capacidade de processamento, não FPS de apresentação da janela. O ganho precisa ser medido no Windows; o ritmo normal de apresentação permanece o original do runtime.

## Gargalo e correção genérica

Perfil por amostragem do binário anterior em 2400 frames: compose recebeu 70,10% do tempo, sampleBg 17,46% e seu helper de composição 3,74%. A varredura de 128 sprites para cada pixel foi confirmada com contagem instrumentada apenas no teste.

O Forja agora percorre os descritores OAM uma vez por segmento de linha, descarta sprites fora do trecho vertical/tela e calcula só os pixels cobertos. Main e sub usam a mesma linha de sprites. Prioridades, desempate pelo menor índice OAM, tamanho, flips, transparência, janelas, paletas e mistura de cores permanecem. O subscreen usado na mistura é calculado uma vez. A linha é local ao segmento, então alterações posteriores de OAM, VRAM e CGRAM são observadas no próximo trecho, inclusive escritas diretas.

O teste de custo passou de 32768 visitas OAM para 128 no segmento normal de 256 pixels. Comparação C++ contra o renderer v0.3.34 congelado: 64 cenas, modos 0–7, cinco linhas, dois fields, janelas, mistura e alterações entre segmentos. Um caso literal verifica mudança simultânea de posição, tile e cor. O teste falhou antes e passou depois; revisão independente aprovou sem achados bloqueantes.

Nenhum endereço do Tetris foi inserido no runtime. CPU, DMA, APU e scheduler não foram alterados nesta versão. A correção DMA e o watchdog das versões anteriores foram mantidos. A mudança geral chega aos projetos novos e aos regenerados pelo Forja.

## Fluxos e validação

| Verificação | Resultado |
| --- | --- |
| Suíte Forja | 71/71 passaram |
| Interface | Eventos, profile, ZIP e rejeição de trace de outra ROM passaram em DOM simulado |
| Build completo GCC/Linux | Release, avisos como erros, passou |
| CTest | 7 passaram; equivalência externa ficou SKIP por falta de vetores |
| Replay normal, execução padrão | 6000 frames, 83,660,394 instruções, saída 0, forced blank 0, nenhum novo hint |
| Equivalência com a v0.3.34 | Todos os 6000 hashes de framebuffer, WRAM e PC coincidiram |
| Pausa, retomada, derrota e Try Again | Replay de 6200 frames passou; captura 6199 mostra tabuleiro ativo após reinício |

A comparação longa usou uma nova execução do binário v0.3.34 congelado. Seu registro antigo tinha só 5977 linhas, embora a saída QA informasse 6000 frames; os registros presentes coincidiam. A nova referência contém os 6000 registros completos. O primeiro erro do comparador e a correção da evidência estão documentados em validation/VALIDATION-NOTE.md.

O replay adicional encontrou 3 caminhos ainda não compilados, agora aprendidos por execução e vinculados ao fingerprint 8c0b44eecc03e2e1. Esses hints pertencem ao projeto Tetris e não ao código genérico do Forja. Perfil, hooks e limite 65536 foram preservados. Captura de pausa e hashes permitem examinar o fluxo. Os controles do replay normal são esquerda, rotação A e Baixo.

## Uso e limites

Extraia o Tetris em uma pasta nova, execute BUILD-WINDOWS.cmd e depois RUN-WINDOWS.cmd. Setas movem, A gira e Enter envia Start. VALIDAR-NORMAL.cmd repete o trecho inicial; VALIDAR-PARTIDA.cmd executa pausa/retomada/Try Again com Node.js, CMake e compilador disponíveis. O pacote inclui fontes C++, dados do port fornecido, gerador atualizado, replays e evidências.

Não foi executado um novo EXE Windows nesta máquina. A comparação preserva o comportamento anterior nos replays; não comprova fidelidade completa ao console, áudio original, todos os modos ou conclusão de todas as fases. O hardware virtual e os dados ROM continuam usados. A v0.3.34 permanece separada.

Evidências: validation/performance/benchmark.json e pastas dos 12 processos; validation/baseline/flat-profile-v034.txt; validation/normal-6000/comparison.json; validation/convergence-pause-retry.json; validation/frame-retry-6199.png e pause-2000/frame.png. Testes, revisão e logs de build/CTest estão em docs/validation do Forja.
