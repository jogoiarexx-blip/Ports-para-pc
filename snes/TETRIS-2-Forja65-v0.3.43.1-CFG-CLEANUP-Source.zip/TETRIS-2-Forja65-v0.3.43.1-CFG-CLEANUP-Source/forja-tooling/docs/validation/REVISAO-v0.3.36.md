# Revisão independente v0.3.36

Aprovação; nenhum achado bloqueante no delta contra forja65-core-v035-baseline.js. Revisão somente leitura; o revisor não executou builds.

A chave (wx>>3, wy) distingue corretamente as metades de tiles 16x16; seleção do tile e inversão dos bits preservam flips e hires. Endereços dos planos equivalem aos decodificadores anteriores em 2/4/8bpp. Compartilhamento main/sub preserva janelas e mistura; cache local evita dados obsoletos entre segmentos. Mode7, CPU, APU e DMA permanecem fora do delta. Cobertura inclui renderer congelado, orçamento de leituras e mutações literais.
