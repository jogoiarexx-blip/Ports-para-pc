# Métricas verificadas

A base enviada possuía 51 scripts de regressão: 50 passaram em GCC/Linux com CMake instalado. O teste state-summary retornava código 2 porque o limite headless normal era tratado como erro; a nova versão corrige esse término.

## Referência traduzida versus host

ROM sintética com duas chamadas: uma JSR e uma JSL por alias. Ambos os caminhos executam a mesma sequência de controle.

| Métrica | Referência traduzida | Hooks host |
|---|---:|---:|
| Instruções traduzidas executadas | 9 | 3 |
| Corpos substituídos por chamadas host | 0 | 2 |
| Master clocks | 294 | 294 |
| RAM final | Igual | Igual |
| A/X/S/PB/flags | Igual | Igual |
| Pilha de retornos pendente | 0 | 0 |
| PC SPC700 | Igual | Igual |

A redução é de 66,7% nas instruções traduzidas desse caso sintético, sem mudar os ciclos equivalentes. Não é medição de FPS, porcentagem de jogo portado ou compatibilidade de uma ROM comercial. O contador anterior somava trace/timing duas vezes; o novo contador preserva as chamadas isoladas à API de timing e conta cada instrução emitida uma única vez.

## Capacidades antes/depois

| Capacidade | Base anexada | v0.3.31 |
|---|---|---|
| Auditoria de hardware | Contadores globais/por frame | Preservados + eventos por rotina |
| Relação CFG → dependências | Sem mapa cruzado | Native Map + chamadas/dependências |
| Código host de rotina | Sem registro genérico JSR/JSL | Hooks com guard/estados/retorno verificado |
| Symbol profile | Hints ligados à ROM | Símbolos/aliases/categorias ligados à ROM |
| Integridade após trace | Sem atualização desse fluxo | Map/report/manifest sincronizados |
| Native score semântico | Flags/contadores antigos | Explicitamente não medido |
| Estado palette/scroll host | Dependência dos registradores PPU | IR host independente, ainda sem compositor |

O teste de sobreposição confirma que tail jump permanece traduzido e uma chamada direta à rotina com hook é substituída. Os testes de bus verificam NMI read-clear, WRAM port, DMA fast path, limite de eventos e ausência de arquivos na build TRACE OFF. A regeneração CLI conserva código host e nomes do profile.

A compilação dedicada com FORJA65_STRICT=ON e TRACE=ON passou; 8/8 CTests passaram, incluindo equivalence_vectors com um vetor esperado real da fixture (nenhum SKIP). A lógica de eventos da interface passou em VM; a validação visual no browser e a execução real no Windows não foram concluídas neste ambiente.

Resultados finais: **58/58 scripts de regressão aprovados**. A varredura final detectou uma referência de comando ausente na documentação antiga; o texto de compatibilidade foi corrigido e esse script reexecutado com sucesso. Os demais 57 haviam passado sem alteração. Logs e resultados por teste estão nesta pasta.
