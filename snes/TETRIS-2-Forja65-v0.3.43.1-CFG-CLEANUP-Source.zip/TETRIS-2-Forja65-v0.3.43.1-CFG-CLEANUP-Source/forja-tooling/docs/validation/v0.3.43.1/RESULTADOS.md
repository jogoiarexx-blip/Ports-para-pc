# Tetris 2 / Forja65 v0.3.43.1 — correção de dispatch com limpeza

Corrigida uma limitação genérica do gerador fornecido v0.3.43. O salto
**82E0F6 → 82E15B**, enviado no diagnóstico do frame **9.222**, agora é
descoberto estaticamente e executa no teste isolado, sem importar seu hint.
Esta derivação corretiva é independente dos trabalhos com Forja v0.3.44+.

## Causa e mudança

O reconhecimento anterior aceitava `PEA return-1; JMP (table,X); RTS; table`.
O Tetris usa uma continuação de limpeza entre o salto e o RTS: restaura X,
grava um valor e restaura DB antes de retornar. O gerador passou a decodificar
essa continuação reta, limitada a 32 bytes e terminada por RTS imediatamente
antes da tabela. Mantém validação da âncora PEA e dos destinos da tabela.

Âncoras inválidas, branches/chamadas e alterações de status sem largura
conhecida são rejeitados. A revisão identificou leitura de operandos fora do
banco em instruções que cruzam FFFF; a regressão reproduziu o falso candidato
e a guarda agora rejeita conservadoramente essas instruções. O caso histórico
de JMP terminando em FFFF e RTS em 0000, no mesmo PB, continua válido.

A análise encontra os três candidatos da tabela, incluindo 82E15B; nenhum
alvo foi importado como knowledge para esse salto.

O código do Forja não contém endereços específicos do Tetris. A ROM continua
selecionando os destinos em runtime. Descoberta CFG não prova o domínio do
índice X nem equivalência de um handler: nenhum handler nativo foi promovido.

## Evidências

| Verificação | Resultado |
| --- | --- |
| Novo teste sintético antes da correção | Falhou: continuação/handler não descoberto |
| Novo teste depois da correção | Dois handlers, limpeza, X/DB e pilha corretos; negativos rejeitados |
| Regressão HiROM de operandos cruzando banco | Falhou antes da guarda; passou depois |
| Probe do salto na base v0.3.43 | Erro 2, mesmo PC/target do diagnóstico enviado |
| Mesmo probe no Tetris atualizado | Saída 0; handler, retorno sintético e limpeza passaram |
| Normal | 12.000 frames idênticos à v0.3.43 |
| Pausa, retomada e Try Again | 6.200 frames idênticos à v0.3.43 |
| Versus 1PvsCOM | 3.200 frames idênticos à v0.3.43 |
| Suíte do Forja | 80/80 passaram |
| Build GCC/Linux Release | Avisos como erros; passou |
| CTest | 7 passaram; equivalência externa SKIP por ausência de vetores |
| Revisão independente | Aprovada após correção do achado de fronteira de banco |

A primeira captura da base Normal tinha 11.999 registros para 12.000 frames;
os registros disponíveis e QA coincidiam. Ela foi repetida para obter uma
comparação completa.

Todos os 21.400 registros de framebuffer/WRAM/PC e campos QA dos três
replays coincidiram com a base. Não houve novos hints nesses replays. Os hints
anteriores foram preservados byte a byte, incluindo a expansão Versus anterior.

O replay Normal da base também chegou a 12.000 frames sem reproduzir o erro
enviado; os comandos exatos da sessão do usuário não estão disponíveis.
O probe reconstrói o estado CPU do salto com WRAM/PPU controlados: não é um
snapshot completo do frame 9.222 nem prova de uma partida inteira. Ele reproduz
isoladamente o bloqueio e valida a execução do destino e da limpeza.

O renderer, DMA e watchdog da base foram preservados. Não foi medido ganho
adicional de FPS/desempenho nesta correção. Não foi compilado nem testado um
EXE Windows aqui; o pacote do Tetris contém fontes para recompilar.

## Uso

Extraia o Tetris em pasta nova. Execute `BUILD-WINDOWS.cmd`, depois
`RUN-WINDOWS.cmd`. Requisitos: CMake e Visual Studio 2022 com C++ desktop.
Setas movem, A gira e Enter envia Start. `VALIDAR-NORMAL.cmd`,
`VALIDAR-PARTIDA.cmd` e `VALIDAR-VERSUS.cmd` continuam incluídos.

O ZIP separado do Forja contém o gerador corrigido e seus 80 testes; o mesmo
gerador está em `forja-tooling` no Tetris. Os diagnósticos enviados, probes,
hashes, análises e logs ficam em `validation` e `analysis/cleanup-dispatch`.
Hardware virtual e dados da ROM continuam usados. A entrega não comprova
todas as fases/modos, áudio original ou independência completa desse hardware.
