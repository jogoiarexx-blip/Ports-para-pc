# Revisão v0.3.40

Regressões diretamente relacionadas executadas com sucesso:

1. `cross-project-knowledge-v0337-regression.js`
2. `focused-crossfeed-v0338-regression.js`
3. `bounded-dispatch-v0339-regression.js`
4. `writer-domain-crossfeed-v0340-regression.js`
5. `state-aware-cfg-v022-regression.js`
6. `vector-table-guard-v0330-regression.js`
7. `table-aware-runtime-hints-v0320-regression.js`

O novo teste de writer-domain valida tabela de registros com stride 4, sentinela zero e override imediato. O teste bounded-dispatch agora também exige `CFG-INDEX-DOMAIN-UNPROVEN` quando a máscara local excede a extensão conhecida da tabela e confirma que `dispatch.resolution` sobrevive à normalização.

A suíte histórica inteira não foi declarada como PASS nesta revisão; foram executadas as regressões diretamente impactadas pela mudança.
