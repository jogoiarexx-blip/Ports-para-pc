Revisão independente do delta em relação à v0.3.32.

Identificado P2: cálculo da continuação após JMP em FFFD incrementava PB. Corrigido: leitura do padrão por endereços SNES e wrapping de 16 bits, preservando PB. Acrescentado teste HiROM com JMP C0FFFD, retorno C00000, rejeição de C10000. Revisor reexecutou e aprovou a correção.

69/69 testes antes dessa correção de fronteira; o teste específico completo foi reexecutado e passou depois da correção.
