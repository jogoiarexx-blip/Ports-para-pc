# Revisão v0.3.41

Regressões focais executadas:

1. `script-domain-crossfeed-v0341-regression.js`
2. `bounded-dispatch-v0339-regression.js`
3. `writer-domain-crossfeed-v0340-regression.js`
4. `focused-crossfeed-v0338-regression.js`

O novo teste valida os dois lados da regra: auditoria parcial permanece aberta e auditoria completa pode fechar o domínio somente quando os IDs provados cabem na tabela.

Resultado focal desta revisão: **8/8 regressões selecionadas passaram** (`script-domain`, `bounded-dispatch`, `writer-domain`, `focused-crossfeed`, `native-map-framework`, `state-aware-cfg`, `local-computed-jump-run`, `project-regeneration`). A suíte histórica completa não foi usada como critério desta etapa porque contém testes longos fora do escopo alterado.

Integração real DKC3 v0.72: o produtor auditou 877 slots (854 não vazios, 23 vazios), fechou **854/854** entradas não vazias, encontrou 0 inválidas e provou IDs até 26 para uma tabela de 27 entradas. No `focus-analyze`, `$B9A157` foi promovido para `index_bounds_proven=true` / `index_domain_fits_table=true`, sem `CFG-INDEX-DOMAIN-UNPROVEN` nem `CFG-SCRIPT-DOMAIN-PARTIAL`.
