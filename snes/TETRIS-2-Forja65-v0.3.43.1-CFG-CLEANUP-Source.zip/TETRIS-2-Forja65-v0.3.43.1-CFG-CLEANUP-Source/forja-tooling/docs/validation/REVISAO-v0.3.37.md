# Revisão v0.3.37 — crossfeed

Validação focada nos subsistemas alterados:

- `cross-project-knowledge-v0337-regression.js`: PASS.
- `native-map-framework-regression.js`: PASS.
- `project-regeneration-regression.js`: PASS.
- `state-aware-cfg-v022-regression.js`: PASS.
- `cfg-direct-v014-regression.js`: PASS.
- `cfg-vectors-v018-regression.js`: PASS.
- `carry-aware-cfg-v0321-regression.js`: PASS.
- `stable-shards-v0319-regression.js`: PASS.
- `rom-bound-oracle-v0326-regression.js`: PASS.

DKC3 cross-analysis real:

- knowledge pack: 4,724 entries, 536 known data regions, 4 reviewed dispatch groups;
- 160 prioritized seeds imported;
- 12,121 unique decoded instruction addresses;
- 502 CFG routine starts / 513 state variants;
- 2,002 CFG calls;
- 337 instruction addresses with multiple state variants;
- 134/134 current DKC3 native-map routines matched after conflict-safe data-region filtering.

The general full Forja test harness was started but exceeded the available single-command execution window before completion; no failure was observed in the completed tests. The focused analyzer/regeneration suite above is the validation claim for this release.
