# Revisão e decisões de escopo

A revisão independente apontou sobreposição de rotinas, retorno físico adulterado e relatórios desatualizados após trace. Cada caso recebeu reprodução e correção verificadas em teste. A integridade do manifesto e a indicação de captura incompleta também foram corrigidas.

Decisões: avançar o fluxo genérico de descoberta/substituição e manter o CPU existente; não atribuir porcentagens de migração a hardware escrito em C++; só habilitar hooks em entradas de subrotina descobertas; manter dados originais/fallback até que as substituições sejam comprovadas. O custo dessas decisões é que renderer, entidades, áudio host, chips e independência completa da ROM ainda precisam de implementação e testes próprios.

Notas de validação: testes C++ em GCC/Linux não validam execução real em MSVC/Windows. O teste de lógica da interface foi executado em VM JavaScript; a validação visual/Chromium não foi concluída porque o binário de browser não ficou disponível no ambiente.
