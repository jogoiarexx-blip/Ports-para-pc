# Revisão v0.3.39

Validated with synthetic regressions and the DKC3 PT-BR development ROM used by the paired project.

- `bounded-dispatch-v0339-regression.js`: PASS; structural indexed table is resolved and external dispatch knowledge is honored by focus and whole analysis.
- `inline-indexed-table-v0312-regression.js`: PASS.
- `focused-crossfeed-v0338-regression.js`: PASS.
- `cartridge-flow-sram-v033-regression.js`: PASS.
- Real focused DKC3 pass: `$B9A157` = 25 unique structural targets, `$B7C76A` = 2 RAM-vector candidates; second pass receives 25/25 and 2/2 through knowledge dispatch.

The full historic suite contains long-running hardware/convergence tests and is not represented here as a full-suite PASS unless run to completion.
