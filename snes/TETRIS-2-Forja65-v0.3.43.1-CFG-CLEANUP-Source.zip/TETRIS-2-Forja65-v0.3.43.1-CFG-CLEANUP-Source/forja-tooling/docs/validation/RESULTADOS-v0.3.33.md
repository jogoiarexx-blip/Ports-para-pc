# Forja65 v0.3.33 — correção do crash enviado

O erro `fluxo CFG nao resolvido em pc=8690912 target=8690920` corresponde a `$849CE0 -> $849CE8`. Foi reproduzido no binário congelado da v0.3.32 usando `validation/input-normal.txt`: encerrou no frame 852, instrução 12.533.795. O trace do usuário tem outro momento de entrada (frame 1133), mas o mesmo salto e fingerprint `8c0b44eecc03e2e1`.

O Forja agora reconhece genericamente `PEA retorno-1; JMP (tabela,X); RTS; vetores; handlers`. Verifica a âncora e o tamanho da tabela, compila os dois destinos e a continuação, sem usar endereços específicos do Tetris. A descoberta foi conferida também sem o hint enviado. O salto continua dinâmico e os retornos usam a pilha real. A revisão identificou uma fronteira de banco HiROM; foi corrigida preservando PB e verificando os bytes por endereços SNES.

O watchdog agora lê `FORJA65_WATCHDOG_INSTRUCTIONS` uma vez, ao criar o runtime. Antes consultava a variável em cada instrução. O teste instrumentado constatou zero novas consultas nas primeiras 100 instruções e disparo exato na instrução 101. Mudar a variável depois de criar o runtime não muda seu limite.

| Verificação | Resultado |
| --- | --- |
| Suíte Forja | 69/69 passaram; teste de fronteira HiROM e testes relacionados reexecutados após revisão |
| C++ GCC 13/Linux, Release, avisos como erros | Compilação completa passou |
| CTest | 7 passaram; equivalência externa sem vetores ficou SKIP |
| Interface | Eventos, importação de perfil, ZIP e rejeição de trace de outra ROM passaram em DOM simulado |
| Replay que reproduziu o erro, versão corrigida | 6.000 frames, 99.084.390 instruções, saída 0, nenhum novo hint |
| Desempenho dos menus, 3 pares de 1.200 frames | Medianas 19.49 s antes / 17.50 s depois; velocidade +11.35% |
| Estado no benchmark | Todos os 7.200 registros por frame coincidiram: framebuffer, WRAM e PC |

Os benchmarks foram sequenciais, alternando versões, sem compilação concorrente, com o mesmo replay, `HEADLESS=1`, `EXECUTION=reference`, `ROM_MODE=cart`, hashes ativados e watchdog de 50 milhões. A comparação mede as duas versões nesta máquina Linux; o ganho em Windows ainda precisa ser medido. Não houve teste do novo executável em Windows/Edge.

O aprendizado limitado do replay de 1.800 frames importou dois caminhos posteriores: retorno `$808359` e fluxo `$829147`. Os hints permanecem vinculados à ROM. A regeneração final manteve o perfil, hooks e limite 65.536; gerou 9.795 endereços decodificados em 32 unidades C++. Tradução da CPU não significa migração completa do hardware.

**Pendência: a partida ainda não está funcional.** A execução de 6.000 frames ficou com forced blank ativo e framebuffer preto. O probe com limite de 30 milhões parou no frame 1938 em `$848045`, dentro da repetição `$848035/$8096A3`, buscando uma célula vazia em `$7E2406`. Os dez valores candidatos observados eram não zero. Isso confirma um bloqueio posterior de preparação; a causa dessa memória incorreta não foi resolvida. PASS de execução significa apenas ausência do crash no período, não progresso da partida ou equivalência com o console.

Os ZIPs incluem código, scripts, hints e evidências. O pacote Tetris usa os dados do port fornecido e precisa de `BUILD-WINDOWS.cmd` para produzir `bin/game.exe`. Nenhum binário Linux foi apresentado como EXE Windows. A v0.3.32 permanece separada.

Evidências principais no Tetris: `validation/user-crash-trace.txt`, `validation/baseline/forja65-crash-trace.txt`, `reports/convergence-report.json`, `validation/normal-extended/forja65-qa-status.txt`, `validation/loading-diagnostic/stdout.log`, `validation/performance/benchmark.json` e capturas dos frames 1799/5999.
