# Revisão v0.3.42 — native dispatch plan

Validation targets:
- `native-dispatch-plan-v0342-regression.js`
- `script-domain-crossfeed-v0341-regression.js`
- `bounded-dispatch-v0339-regression.js`
- `writer-domain-crossfeed-v0340-regression.js`
- `focused-crossfeed-v0338-regression.js`

The generator must refuse route generation when index-domain proof is absent. Generated routing is not handler equivalence and leaves `equivalence_proven=false` by default.

## Resultado

As 9 regressões selecionadas passaram. A integração real com DKC3 v0.73 gerou **27 rotas / 25 handlers únicos**, preservou os aliases 6/8 e 7/9, marcou **20/25 handlers** apenas como candidatos de tradução e manteve **5/25** explicitamente com CFG dinâmico. `handler_execution_ready=false` permanece obrigatório porque nenhum handler recebeu prova de equivalência semântica nesta etapa.
