Revisao das correcoes essenciais
===============================

A revisao identificou e levou a correcoes de: perfil antigo aplicado a outra ROM; logs/hashes reaproveitados entre execucoes; PB real em guardas, timing e JSR indexado; hash duplicado por frame; IRQ limpo antes do ACK; fase NMI; selecao de aliases por E/M/X/C; aliases fisicos com low PC diferente.

Aliases com low PC diferente exigem traducao propria, tanto no dispatcher quanto em hooks. O fixture confirma que a CPU nao executa o corpo errado.

A suite tem 67 testes aprovados. Oito verificacoes direcionadas foram repetidas apos os ajustes de aliases e hooks.

Os resultados de equivalencia interna dos fixtures nao comprovam equivalencia externa da ROM comercial.
