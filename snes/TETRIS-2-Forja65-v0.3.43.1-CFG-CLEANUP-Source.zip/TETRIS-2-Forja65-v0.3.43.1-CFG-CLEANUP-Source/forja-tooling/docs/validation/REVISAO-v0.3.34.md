Revisão independente, somente leitura, do delta contra a v0.3.33.

Aprovação: D3 mantém a origem fixa, inclusive com D4 ativado; D4 decrementa quando D3 está desligado. O avanço preserva o banco e faz wrap de 16 bits, em ambas as direções e caminhos DMA. Os modos B-bus continuam selecionados por dmap&7.

O teste cobre origem fixa, precedência de fixed, incremento/decremento nas fronteiras, reverse e caminhos native/virtual. O revisor não reexecutou o teste; o coordenador registrou vermelho e verde e a suíte final 70/70.

A primeira tentativa da suíte teve cmake ausente do PATH nos testes cli-trace-framework-regression.js, convergence-pipeline-regression.js e cross-game-cpu-flow-v028-regression.js. O ambiente foi corrigido; a suíte completa passou 70/70, conforme log final.
