# Forja65 v0.3.41 — Script Domain Proof

- `dispatch.resolution.script_domain` passa a ser interpretado como evidência ROM-bound de bytecode.
- Auditoria parcial mantém `index_bounds_proven=false` e produz `CFG-SCRIPT-DOMAIN-PARTIAL`.
- Auditoria completa só fecha o domínio se os IDs provados couberem na extensão estrutural da tabela.
- O objeto `script_domain` continua preservado pelo normalize/roundtrip do `forja65.knowledge.v1`.
- A regra é genérica; o Forja não contém endereços, nomes ou regras específicas de DKC3.
