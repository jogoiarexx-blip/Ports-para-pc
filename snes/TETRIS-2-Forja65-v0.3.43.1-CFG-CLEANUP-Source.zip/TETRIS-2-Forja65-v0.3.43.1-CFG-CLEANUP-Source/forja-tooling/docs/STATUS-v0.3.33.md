# Estado da v0.3.33

Esta versão corrige a descoberta de destinos do padrão PEA/JMP(abs,X)/RTS/tabela inline e remove consultas à variável de ambiente do watchdog do loop de instruções. O relatório da entrega registra o caminho executado e os resultados medidos.

Os testes C++ e benchmarks foram executados em GCC/Linux. A interface foi verificada em DOM simulado. Não houve execução do novo binário em Windows/Edge nem comprovação de equivalência externa com console. A CPU continua traduzida para C++, com runtime de hardware virtual e dados da ROM.

Validação: 69 testes Forja, teste de fronteira e relacionados após revisão; build rigoroso, 7 CTests e 1 SKIP, replay normal de 6000 frames sem novo hint. Mediana de três pares: +11,35% de velocidade em Linux, hashes por frame coincidentes. O início da partida continua bloqueado com forced blank e procura de célula vazia em 7E2406. A causa permanece pendente.
