# Forja65 v0.3.40 — Writer Domain Crossfeed

## Mudanças

- `JMP (abs)` sobre vetores RAM agora pode recuperar domínio de destinos a partir de escritores diretos no mesmo banco mapeado.
- Reconhece stores imediatos e um padrão conservador de tabela de registros: índice escalado, word companheiro, word handler, `STA vetor` e sentinela zero/zero.
- A resolução registra `direct_absolute_sta_sites`, `direct_absolute_sta_covered`, `direct_absolute_writer_closure`, writers imediatos e tabelas/terminadores encontrados.
- O fechamento é explicitamente local: stores indiretos/aliased em WRAM continuam fora da prova estática.
- `JMP (abs,X)` agora separa extensão comprovada da tabela de domínio comprovado do índice.
- Quando `AND/ASL/TAX` permite mais índices do que a tabela conhecida, `focus-analyze` emite `CFG-INDEX-DOMAIN-UNPROVEN`.
- Metadados `dispatch[].resolution` sobrevivem à normalização do `forja65.knowledge.v1`, permitindo roundtrip sem perda da evidência.

## Caso DKC3 que motivou a generalização

O vetor `$1963` deixou de ser tratado como apenas dois stores imediatos. A análise encontrou três `STA $1963` diretos na região revisada. Um deles recebe o handler de uma tabela de 21 registros com 8 destinos únicos; os outros dois são overrides imediatos. O conjunto estático resultante tem 10 destinos.

Em `$B9A157`, a tabela de dispatch tem 27 entradas / 25 destinos e a extensão é corroborada por região de dados externa, porém `AND #$007F` ainda admite teoricamente IDs 0..127. A versão 0.3.40 reporta essa diferença em vez de chamar o domínio runtime de fechado.
