# Forja65 v0.3.37 — cross-project knowledge feed

This release adds a generic `forja65.knowledge.v1` bridge so reverse-engineering evidence learned in a specialized port can seed Forja65 without hard-coding game-specific rules.

## Structural change

- `analyze` accepts `--knowledge knowledge.json`.
- Reviewed external routine entry points become prioritized CFG seeds with explicit M/X/E/C state.
- Names/categories are merged into the generated `game_config.json` profile.
- `cross-analyze` runs a lightweight CPU/CFG analysis and emits `function-analysis.json`, `native-map.json`, merged profile and a summary without generating the full C++ port.
- `import-knowledge` converts a knowledge pack to a Forja profile.
- `export-knowledge` sends Forja native-map discoveries back to another port.
- ROM FNV identity is mandatory when supplied; mismatched knowledge is rejected.

Knowledge remains evidence, not truth: a seed does not prove that a routine executes in normal gameplay or that an imported semantic label is correct.

DKC3 Native PC v0.68 is the first producer/consumer used to validate the bridge, but the schema and implementation contain no DKC3-specific addresses.

## First real crossfeed: DKC3

Using the DKC3 v0.68 knowledge pack with `--max 30000 --seed-limit 160 --summary-rounds 0`, Forja65 decoded 12,121 instruction addresses, built 502 CFG routine starts / 513 state variants and matched all 134 routines currently tracked by the DKC3 native-map. Known data regions also blocked five return-adjacent false code seeds during an intermediate validation run; reviewed routine boundaries take precedence when source annotations conflict.
