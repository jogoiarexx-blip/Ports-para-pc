# Forja65 v0.3.32: correções essenciais

A versão corrige bloqueios reais encontrados no Tetris 2 anexado e promove mecanismos reutilizáveis ao gerador.

- Análise de PHP/PLP por uma pilha abstrata de bytes, com saves aninhados e guardas de retomada. PLP sem status conhecido compila as quatro larguras nativas legais.
- Carry observado também gera um seed com C desconhecido; XCE com C desconhecido bifurca os dois modos possíveis. Os hints originais permanecem preservados.
- CPU, PPU e APU avançam pelo mesmo scheduler de instruções. NMI/IRQ podem preemptar busy loops sem WAI; RTI retoma o endereço real. A fase NMI é 12 master cycles; refresh, HDMA e PAL312 continuam no scheduler.
- IRQ permanece elegível até ACK/desabilitação. Status NMI lido pela CPU é independente da borda pendente de serviço.
- PC de trace/timing, guardas e retorno de JSR indexado preservam PB real dos aliases. O dispatcher escolhe o alias com E/M/X/C compatível, evitando rejeitar código que já foi compilado. Código e hooks só compartilham aliases com low PC idêntico; outro endereço exige sua própria tradução.
- Hashes e auditoria são gravados uma vez por frame; capturas funcionam em loops sem WAI.
- Novo CLI `converge`: executar, importar observações presas à ROM, regenerar e recompilar com limites de rodadas, instruções e tempo. Cada execução tem diretório isolado.
- Regeneração preserva hints, perfil, hooks, vetores e budget. Conteúdo idêntico mantém timestamp. ROM diferente exige saída diferente, inclusive quando fornecido outro perfil explícito.
- Scripts Windows incluem framework_smoke no build e conservam os separadores do launcher Oracle.

Não há lógica de peças, tabuleiro ou endereços específicos do Tetris no runtime/genérico. As capturas e o replay usados na validação ficam no pacote do jogo.
