# Forja65 v0.3.43 — selective semantic cutover

The cross-project loop can now advance from structural routing to selective native execution without trusting a label alone. Handler proofs are ROM-bound and span-bound. A clean CFG still means only `translation_candidate`; a reviewed native body with an unresolved external dependency is `native_body_ready`; only a PASS handler-ABI proof sets `equivalence_proven`.

For the current DKC3 `$B9A157` plan: 27 command routes, 25 unique handlers, 20 translation candidates, 5 CFG fallback handlers, **1 equivalence-proven native handler**, and **1 dependency-boundary handler**. The remaining handlers stay on fallback.
