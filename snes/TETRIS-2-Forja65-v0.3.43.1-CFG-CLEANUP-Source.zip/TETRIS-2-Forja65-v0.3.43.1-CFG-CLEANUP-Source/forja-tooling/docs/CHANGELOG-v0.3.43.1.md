# Forja65 v0.3.43.1 — PEA e continuação de limpeza

Base: v0.3.43-handler-equivalence-crossfeed fornecida. Esta é uma derivação
corretiva para Tetris, independente das versões v0.3.44+ de outros trabalhos.

O reconhecimento de `PEA return-1; JMP (table,X)` passa a aceitar uma
continuação reta de até 32 bytes, terminada por `RTS` imediatamente antes
da tabela. A continuação é decodificada, inclusive larguras M/X; não se
procura o byte 60 em dados. Âncora incorreta, branches, chamadas, interrupções,
status desconhecido por PLP/XCE e falta de RTS não autorizam a descoberta.

Os destinos continuam candidatos CFG. A execução lê a tabela real em runtime.
Esta correção não prova o domínio de X, não instala handlers nativos e não
altera os requisitos de equivalência do Forja v0.3.43.

O teste `pea-cleanup-dispatch-regression.js` executa dois handlers de uma ROM
sintética e confere os efeitos da limpeza, restauração de X/DB e equilíbrio
da pilha; também rejeita âncoras inválidas. O teste histórico cobre RTS
imediato e retorno com wrap no mesmo banco HiROM.

No Tetris, essa forma ocorre em 82E0F6: PEA E0F8, salto pela tabela E103,
continuação E0F9 (LDX/LDA/STA/PLB/RTS). O destino 82E15B observado no erro
é descoberto sem importar seu hint. Consulte o relatório de validação desta
entrega para resultados e limites, inclusive o teste isolado do estado CPU.
