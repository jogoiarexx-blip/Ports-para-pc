# Forja65 v0.3.38 — focused crossfeed

The v0.3.37 whole-project knowledge feed remains intact. v0.3.38 adds a cheaper second path for small compatibility queues: `focus-analyze`.

A producer can export `forja65.knowledge.v1`, ask Forja65 to inspect only selected addresses, then import the returned `forja65.focus-analysis.v1`. Function spans allow Forja65 to recognize internal/tail entries as members of a larger reviewed family. Tiny, classified JMP/JML vectors may lend their category to a direct target; this is intentionally narrower than propagating semantics through arbitrary calls.

## DKC3 validation

The first focused pass covered 14 previously prioritized DKC3 addresses. The updated DKC knowledge pack returns all 14 as classified seeds: 4 AUDIO, 3 COLLISION, 2 PLAYER and 5 OBJECT in the generic Forja vocabulary. Three CFG issues remain attached to two targets and are not hidden by the classification.

The result is routing evidence only. `focus-analyze` does not prove execution, full function boundaries, gameplay correctness or equivalence to original hardware.
