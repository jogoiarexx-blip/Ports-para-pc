# Implementation plan

1. Measure original JS suite and inspect existing analyzer, bus, dispatcher, replay, and pack tools. Preserve these systems.
2. Add tests for ROM-bound profile validation, call graph and read/write dependency merging, trace round trips, and honest native metrics. Run RED before implementation.
3. Add analysis/native-map.js (UMD): profile normalization, CFG grouping, CSV/JSON/TXT trace conversion, native map and compatibility reports. Core API extends rather than replaces existing exports.
4. Add native/forja_trace.hpp and native/forja_ir.hpp templates. Instrument existing bus and generated dispatch without extra bus reads. Expose disabled/reference/native paths. Compile and execute generated tests, including JSR/JSL stack and M/X guards.
5. Add CLI analyze, trace import, and build-native project generation; connect browser profile/trace import and native map panel. Keep Windows app launcher.
6. Run complete regressions and generated CTest, compare synthetic reference/host results and recorded counts. Document unsupported portions, current limits, native-score denominators, and before/after. Package current docs only in portable and source ZIPs.
