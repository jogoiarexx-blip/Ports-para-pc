# Forja65: generic native migration workbench

Intent: turn evidence from the existing 65C816 translator and virtual hardware into reusable native migration tools. Preserve the supplied 0.3.30 CPU and generated project interfaces. No game-specific addresses in core.

This delivery connects existing CFG analysis, bounded runtime events, ROM-bound profiles, per-routine dependencies, conservative subsystem hypotheses, and a guarded host routine replacement ABI. A small host IR stores palette and scroll independently of PPU registers. It does not claim automatic conversion of gameplay, full host rendering, ROM independence, ExLoROM, or chips unsupported by the supplied runtime.

The trace records instruction PC/opcode, dispatch entry/exit, bus read/write, DMA/HDMA source, and input. Disabled by default, compile-time removable, bounded with explicit dropped-event metadata. It never reads the bus to inspect the bus. Native-map preserves original addresses and distinguishes observed data from static candidates; gameplay categories need profile evidence. Profiles bind to the existing ROM fingerprint. Hooks use the real JSR/JSL return frame, cannot intercept interrupts or arbitrary resume labels, and must preserve stack ownership. Reference mode bypasses all native hooks.

Validation: old JS regressions; new profile/map/trace/IR tests; generated C++ compilation and CTest; a synthetic ROM with short and long calls exercising host replacement and translated reference equivalence. Metrics are observed counts with named denominators, never estimated whole-game percentages.
