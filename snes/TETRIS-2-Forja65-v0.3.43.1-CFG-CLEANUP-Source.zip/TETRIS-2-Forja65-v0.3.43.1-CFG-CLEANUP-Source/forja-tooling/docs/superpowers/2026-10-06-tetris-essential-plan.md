# Tetris 2 e Forja65: melhorias essenciais

Objetivo autorizado: corrigir bloqueios observados no port anexado e promover apenas mecanismos independentes do jogo para o Forja65.

1. Reproduzir falha do pacote original e medir avanço em frames/PC.
2. Corrigir os defeitos encontrados com fixtures pequenas, incluindo regeneração sem perda de hints e sem recompilar arquivos idênticos.
3. Automatizar rodadas limitadas de executar → importar hints presos à ROM → regenerar → compilar, distinguindo conclusão, estagnação e erro de build.
4. Rodar Tetris sem input e com replay, capturar imagem/estado e comparar repetições determinísticas. Não declarar jogabilidade se menus/partida não forem comprovados.
5. Verificar testes existentes, revisar alterações e entregar código e instruções atualizados. Manter a lógica específica do Tetris fora do núcleo.
