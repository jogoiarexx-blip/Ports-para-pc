# Desempenho do jogo e gerador

Objetivo autorizado: melhorar o desempenho do Tetris e aplicar as melhorias gerais ao Forja. Preservar o jogo original e a v0.3.34 congelada.

1. Perfil por amostragem apontou compose como principal custo; varredura observada de OAM confirmou 128 sprites por pixel.
2. Teste de custo falhou em 32768 visitas; mudança local por segmento reduziu a 128. Oracle C++ congelado e caso literal verificam pixels e mutações.
3. Regeneração manteve perfil, hooks, dados ROM, hints e limite 65536. Revisão independente aprovou o delta.
4. Executar suíte completa, DOM UI, build rigoroso/CTest, replays de controles, pausa, retomada, Try Again e comparação 6000 frames.
5. Medir três pares alternados para 1200 e 2200 frames, sem compilação concorrente; comparar hashes completos e distinguir velocidade headless de FPS de apresentação Windows.
6. Empacotar fontes, ferramentas, replays e evidências; salvar os novos ZIPs e relatório.
