# Forja65 v0.3.35 — renderização geral

Perfil por amostragem do Tetris v0.3.34 em GCC/Linux (2400 frames) apontou 70,10% do tempo em compose, 17,46% em sampleBg e 3,74% na composição dos backgrounds. A composição anterior varria 128 sprites para cada pixel.

A composição de OBJ agora monta uma linha local por segmento renderizado. Percorre os 128 descritores uma vez, rejeita sprites fora da linha/tela e calcula apenas os pixels cobertos. Preserva prioridade, desempate por índice OAM, flips, tamanho, base de tiles e transparência. Main e sub reutilizam essa linha; janelas e mistura de cores continuam por pixel. O subscreen da mistura é calculado uma vez.

A linha local é descartada ao terminar o segmento; não há cache persistente que exija interceptar escritas diretas em OAM/VRAM/CGRAM. Alterações sincronizadas no meio da linha têm efeito no próximo segmento. Hires, pseudo-hires e interlace mantêm a coordenada usada antes. CPU, DMA e scheduler não foram alterados.

Teste de trabalho observado, instrumentado apenas na cópia do teste: 32768 visitas OAM antes, 128 depois para uma linha com 256 pixels. Comparação C++ com renderer v0.3.34 congelado: 64 cenas, modos 0–7, janelas, mistura, cinco linhas, dois fields e mutações entre segmentos. Um caso literal confere alteração simultânea de posição, tile e cor. Revisão independente aprovou sem bloqueios.

Desempenho real, replays e limites estão no relatório desta versão. Nenhum endereço ou exceção de jogo foi inserido no Forja.
