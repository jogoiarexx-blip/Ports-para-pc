# Status — Forja65 v0.3.40

O crossfeed agora transporta não só destinos, mas também a qualidade da prova usada para obtê-los.

- RAM-vector writer domain: implementado de forma conservadora.
- Cobertura de stores absolutos diretos: contabilizada.
- Tabelas de registros com stride/sentinela: suportadas no padrão validado.
- Extensão estrutural de tabela `JMP(abs,X)`: separada de limite runtime do índice.
- `CFG-INDEX-DOMAIN-UNPROVEN`: novo diagnóstico focal.
- `dispatch.resolution`: preservado no knowledge pack normalizado.

Limite: ausência de writers indiretos/aliased não pode ser provada apenas pela varredura atual. O dispatcher runtime deve permanecer quando essa hipótese ainda puder ocorrer.
