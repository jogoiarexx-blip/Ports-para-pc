# Forja65 v0.3.39 — Bounded Dispatch Crossfeed

- Added structural recognition for inline `ASL` + `TAX` + `JMP (abs,X)` dispatch tables. The table is bounded by its own handler pointers instead of assuming arbitrary data after the jump.
- `focus-analyze` now emits every resolved indirect site, candidate target set and resolution kind.
- `forja65.knowledge.v1` dispatch hints are consumed by both focused and whole-project CFG analysis.
- `knowledge-return.json` now returns newly discovered dispatch candidate sets so another port can persist them and feed them back on the next pass.
- Candidate sets never claim runtime index bounds or semantic equivalence. Dynamic dispatch remains preserved at runtime unless separate evidence proves a closed value domain.

## DKC3 crossfeed result

`$B9A157` is no longer `CFG-DYNAMIC`: the structural table at `$B9A15A..$B9A18F` exposes 27 entries / 25 unique handler targets. The RAM vector at `$B7C76A` exposes the two static candidates `$B7C76D` and `$B7C840`. A second DKC3 -> Forja pass confirms all of those candidates arrive through `knowledge_targets`.
