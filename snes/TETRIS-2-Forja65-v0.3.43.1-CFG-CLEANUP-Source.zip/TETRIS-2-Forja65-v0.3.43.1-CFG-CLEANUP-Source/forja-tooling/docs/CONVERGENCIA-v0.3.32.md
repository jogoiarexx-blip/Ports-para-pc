# Aprendizado automático e regeneração

Abra AUTO-APRENDER-PORT.cmd ou use:

```sh
node tools/forja65.js analyze game.sfc --out project
node tools/forja65.js converge project --frames 1200 --rounds 32
node tools/forja65.js converge project --frames 1200 --replay input.txt
```

O modo exige Node.js, CMake e compilador C++. A interface HTML permanece utilizável sem Node.js.

| Resultado | Significado |
|---|---|
| PASS | Processo terminou sem erro e QA registrou pelo menos o número de frames solicitado. |
| BLOCKED | Houve erro de execução sem um hint novo para aprender. |
| INCOMPLETE | Processo terminou antes do número de frames solicitado. |
| ROUND_LIMIT | Hints foram aprendidos, mas o limite de tentativas foi atingido. |
| EXECUTION_ERROR | Timeout, falha ao iniciar processo ou outro erro do host. |
| BUILD_OR_GENERATION_ERROR | Falha de geração ou compilação. |

PASS se refere apenas à sequência executada. Teste menus, partida, game over e cenários diferentes com replays separados.

`reports/convergence-report.json` contém ROM, sequência, tentativas, frames observados, QA e caminhos dos logs. `reports/convergence/session-*` isola saves, hints e hashes. `analysis/runtime-hints.txt` guarda conhecimento acumulado para a próxima geração, inclusive em projetos criados pela interface.

`analyze --update` conserva código host, perfil, equivalence-cases.txt, hints e limite anterior; comparar bytes antes de gravar impede reconstrução dos arquivos que não mudaram. Projetos de ROMs diferentes precisam de pastas diferentes. ZIPs extraídos manualmente não passam por esse mecanismo de preservação.
