# Forja65 / Tetris 2 v0.3.36 — fundos por tile

A melhoria foi aplicada ao gerador Forja e ao Tetris regenerado. Nesta máquina Linux headless, o replay dos menus processou **1.10× mais rápido** e o replay de menus + partida + comandos **1.14× mais rápido**, comparados com a v0.3.35. Pixels, WRAM, PC e todos os campos QA coincidiram nos replays longos. Pausa, retomada, derrota e Try Again foram repetidos sem novo hint.

## Desempenho medido

| Replay | v0.3.35 | v0.3.36 | Velocidade relativa | Redução de tempo |
| --- | --- | --- | --- | --- |
| Menus, 1200 frames | 5.189 s | 4.713 s | 1.10× | 9.17% |
| Menus + partida + comandos, 2200 frames | 11.742 s | 10.263 s | 1.14× | 12.59% |

Três pares por cenário, ordem alternada, execução sequencial, sem compilação concorrente. GCC13/Linux, Release O3, trace compilado desativado, reference/cart, mesmos assets/replay, watchdog 100 milhões, hashes habilitados e pasta limpa sem saves para cada processo. Os 20400 registros dos 12 processos coincidiram por cenário. O replay de partida inclui menus, não mede apenas frames dentro da fase. Estes valores medem capacidade de processamento headless; FPS e ganho no Windows não foram medidos. A cadência da janela continua a original.

## Causa e implementação

Perfil por amostragem da v0.3.35 em 2400 frames: sampleBg recebeu 47,17% do tempo. Antes, o mesmo descritor do tilemap e os mesmos bytes dos planos eram lidos para cada pixel. Agora um cache de oito pixels por camada usa a coordenada mundial x/8 e y após mosaico/scroll. Tilemap e planos são lidos uma vez por tile da linha; main/sub compartilham os pixels, mantendo janelas e mistura por pixel. Tiles grandes, flips, paletas e cores diretas seguem o cálculo anterior. Mode7 continua no caminho anterior.

O cache existe apenas durante renderOutputSegment. VRAM, CGRAM, scroll, modo ou registradores alterados após um segmento são observados no próximo. Nenhum endereço do Tetris foi adicionado ao runtime. CPU, DMA, APU e scheduler não foram alterados. As correções e otimizações anteriores foram preservadas.

O teste instrumenta somente uma cópia C++ do renderer: uma linha 4bpp de 256 pixels passou de **1536 para 192 leituras VRAM**, redução de 87,5%. O teste falhou antes e passou depois. Comparação contra renderer v0.3.34 congelado: 128 cenas determinísticas, modos 0–7, tiles 8/16, mosaico, scroll e mapas de tamanhos variados, janelas, mistura, hires, interlace e alterações entre segmentos. Um caso literal confirma que tile, paleta e scroll modificados produzem o verde esperado. Revisão independente aprovou sem achados bloqueantes.

## Validação

| Verificação | Resultado |
| --- | --- |
| Suíte completa Forja | 72/72 passaram |
| Interface | Eventos, perfil, geração ZIP e rejeição de trace de outra ROM passaram em DOM simulado |
| Build completo GCC/Linux | Release, avisos como erros, passou |
| CTest | 7 passaram; equivalência externa ficou SKIP por falta de vetores |
| Normal, execução padrão | 6000 frames; 83660394 instruções; saída 0; forced blank 0; sem novo hint |
| Pausa/retomada/Try Again, execução padrão | 6200 frames; 86405243 instruções; saída 0; forced blank 0; sem novo hint |
| Equivalência v0.3.35/v0.3.36 | 12200 registros completos de framebuffer/WRAM/PC coincidiram; todos os campos QA também |

As duas versões foram executadas novamente em pastas novas, com os mesmos replays. Os dois registros têm exatamente os números de frames solicitados. Capturas: normal frame1699 e reinício frame6199. O fingerprint 8c0b44eecc03e2e1, perfil, hooks, limite65536 e os hints aprendidos na versão anterior foram mantidos. Não houve novo aprendizado específico de ROM nesta entrega.

## Como rodar

Extraia o Tetris em uma pasta nova. Instale CMake e Visual Studio2022 com Desenvolvimento desktop C++; execute BUILD-WINDOWS.cmd e depois RUN-WINDOWS.cmd. Setas movem, A gira e Enter envia Start. VALIDAR-NORMAL.cmd e VALIDAR-PARTIDA.cmd usam Node.js/CMake/compilador para repetir os replays.

O pacote contém fontes C++, assets do port fornecido, gerador atualizado, replays, logs, capturas e comparações. O ZIP não inclui um novo EXE Windows: compilação e execução Windows não foram feitas nesta máquina. Não se comprova conclusão de todas as fases, todos os modos, áudio original nem equivalência completa ao console. O hardware virtual e dados ROM continuam usados.

Evidências: validation/performance/benchmark.json, pastas dos12 processos, validation/comparison.json, normal-v036-6000 e pause-retry-v036-6200, validation/baseline/flat-profile.txt. No Forja: docs/validation/REVISAO-v0.3.36.md, suite/build/CTest e resultados. Cada ZIP inclui lista SHA256 dos arquivos e foi verificado por CRC e SHA256.
