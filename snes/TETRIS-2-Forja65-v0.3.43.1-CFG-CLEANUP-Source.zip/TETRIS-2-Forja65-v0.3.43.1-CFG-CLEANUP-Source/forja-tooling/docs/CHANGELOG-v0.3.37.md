# Changelog v0.3.37

- Added generic `forja65.knowledge.v1` import/export.
- Added external state-aware CFG seeds to the 65C816 analyzer.
- Added `cross-analyze`, `import-knowledge`, and `export-knowledge` CLI commands.
- Project regeneration preserves imported knowledge packs.
- Added regression coverage for unreachable external CFG seeds and ROM mismatch rejection.
