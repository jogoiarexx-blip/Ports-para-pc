# Status — Forja65 v0.3.39

The cross-project bridge now persists bounded indirect-dispatch knowledge, not only routine categories and entry states.

For DKC3, the focused analyzer closes the former dynamic CFG at `$B9A157` into a structural 25-target set and retains two candidates for the `$1963` RAM-vector dispatch at `$B7C76A`. Those sets can be exported by the game-specific project and imported on the next Forja pass.

This is a static control-flow improvement. It does **not** prove which table index occurs at runtime, does not remove the runtime dispatcher, and does not claim full native equivalence. The gain is that all candidate handlers enter CFG/code discovery and the same information survives the roundtrip instead of being rediscovered.
