# Estado da v0.3.35

Renderização de sprites por segmento e reutilização de subscreen aplicadas ao gerador e ao Tetris. Benchmark Linux headless: 3.11× no replay dos menus; 3.27× no replay que inclui partida. Três pares por cenário, pixels/WRAM/PC e contadores coincidentes.

71 testes Forja passaram; build completo rigoroso passou; 7 CTests passaram, 1 sem vetores ficou SKIP. Replay normal de 6000 frames coincidiu integralmente com v0.3.34. Pausa, retomada e Try Again passaram em 6200 frames, com tabuleiro ativo após reinício.

Validação limitada aos replays e aos testes de renderer. Windows, equivalência ao console e todos os modos/fases não foram validados. Hardware virtual e dados ROM continuam usados. Veja validation/RESULTADOS-v0.3.35.md.
