# Escopo dos 40 requisitos

Esta versão entrega uma evolução funcional do fluxo de migração, não a conclusão de todo o framework.

| Requisito | Estado nesta entrega |
|---|---|
| 1 CPU | Tradutor preservado; contador trace/timing corrigido. |
| 2 ROM Analyzer | Analyzer/CFG anterior reaproveitado; classificação abrangente de dados/assets ainda futura. |
| 3 Trace | Novo trace instrumentado, limitado, desligável e exportável. |
| 4 Native Map | Implementado com dependências observadas e candidatas estáticas. |
| 5 Call Graph | Chamadas do CFG e invocações observadas por rotina. |
| 6 Dependency Graph | Leitura/escrita de RAM/ROM/portas e origem DMA/HDMA por rotina. |
| 7 Subsistemas | Heurísticas conservadoras AUDIO/RENDER/SAVE; demais papéis precisam de evidência. |
| 8 Profiles | Fingerprint, símbolos, aliases, categorias e configuração de heurísticas. |
| 9 Plugins | Sistema geral de plugins ainda futuro; hooks são extensão C++ específica. |
| 10 Renderer | Base host palette/scroll; composição completa pendente. |
| 11 PPU state/lazy | State-only anterior preservado como hardware virtual; lazy semântico pendente. |
| 12 DMA | Trace de transferências/fast paths; substituição automática por intenção pendente. |
| 13 HDMA | Trace de origem/portas; IR de efeitos por scanline pendente. |
| 14 IR | Implementada base SetPalette/SetScroll, validada em C++. |
| 15 Extrator | Capturador de cenas anterior preservado; extractor ROM genérico amplo pendente. |
| 16 ROM runtime | Contadores anteriores e dependências por rotina; objetivo 0 não alcançado globalmente. |
| 17 Entidades | Sistema host de entidades/adaptadores ainda futuro. |
| 18 Hooks | Substituição host JSR/JSL, guards, estados e verificação de retorno. |
| 19 Reference/native | Modo reference bypassa hooks; testes sintéticos comparativos. |
| 20 First divergence | Comparador dos hashes por frame existentes; snapshots byte a byte pendentes. |
| 21 Replay | Sistema anterior preservado. |
| 22 Snapshots | Capturas PPU/SPC anteriores preservadas; snapshot integral/restauração pendentes. |
| 23 Debugger | Native Map na interface; painéis/breakpoints completos pendentes. |
| 24 Symbols | JSON por ROM e aliases, preservado na atualização CLI. |
| 25 IA opcional | function-analysis.json disponível; nenhuma dependência de IA. |
| 26 Áudio | SPC/DSP fallback anterior; API áudio host semântica pendente. |
| 27 Chips | Diagnósticos anteriores preservados; implementação/plugin dos chips pendente. |
| 28 Compatibilidade | Novos JSON/Markdown sem confundir tradução e port host. |
| 29 Native Score | Não inventado; null até existir cobertura/denominadores verificáveis. |
| 30 Tests | Suíte antiga e novos testes de trace, hooks, ABI, CLI e métricas. |
| 31 Games regressions | Fixtures sintéticas; corpus de testes de jogos reais pendente. |
| 32 Estrutura | Módulos analíticos/native/tools/profiles adicionados sem reescrever CPU. |
| 33 Performance | TRACE compilável OFF; analyzers fora do executável. |
| 34 Não duplicar | CFG/replay/auditoria/capturador existentes reutilizados; bundle é gerado das mesmas fontes. |
| 35 Compatibilidade | Core standalone e APIs existentes preservados; projetos anteriores não são alterados automaticamente. |
| 36 Aprender com ports | Profiles e evidências reutilizáveis; promoção automática de padrões pendente. |
| 37 Níveis | Relatórios novos separam tradução, hardware virtual e corpos host observados. |
| 38 Prioridade | Análise/trace/hooks/validação primeiro; CPU não reescrita. |
| 39 Processo ROM | CLI analyze, trace/import-trace, build-native; não conversão automática completa. |
| 40 Entrega | Código, testes, documentação e métricas comparativas. |
