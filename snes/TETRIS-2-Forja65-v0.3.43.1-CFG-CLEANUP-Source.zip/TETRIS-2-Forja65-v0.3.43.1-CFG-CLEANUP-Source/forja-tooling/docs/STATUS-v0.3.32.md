# Estado da v0.3.32

O gerador continua emitindo C++ traduzido da CPU 65C816 e um runtime de hardware/dados. O pipeline de aprendizado reduz trabalho manual e resolve destinos observados; não é uma decompilação semântica automática.

Validação desta entrega: consulte docs/validation/results-v0.3.32.json e o relatório Tetris fornecido junto aos ZIPs. Testes genéricos exercitam status stack, XCE, NMI/IRQ em chamadas aninhadas, aliases/FastROM, HDMA/refresh/PAL, regeneração e aprendizado real de uma ROM sintética. O smoke de UI foi executado em DOM simulado; não houve validação visual no Edge.

Os builds C++ foram executados com GCC/Linux. Scripts e requisitos Windows foram verificados no código; não houve execução em Windows/MSVC. A interface portátil mantém Edge App Mode. Para compilar o jogo no Windows, use CMake e Visual Studio 2022 com desenvolvimento desktop C++.

Precisão total do console e equivalência externa da ROM comercial ainda não estão comprovadas. A entrada de interrupção conserva a aproximação anterior de 42 master cycles. Hooks host devem ser validados em seus estados/timing reais; o scheduler não executa instruções originais dentro de callbacks host.
