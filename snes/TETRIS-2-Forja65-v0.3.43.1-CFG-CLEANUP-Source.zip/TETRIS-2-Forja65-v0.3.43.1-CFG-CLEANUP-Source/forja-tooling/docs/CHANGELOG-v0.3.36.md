# v0.3.36 — cache local de tiles dos fundos

O perfil da v0.3.35 atribuiu 47,17% das amostras à leitura/decodificação dos fundos (sampleBg). Agora cada camada reutiliza os oito pixels do último tile de sua linha durante o segmento renderizado. Tilemap e bytes dos planos são lidos uma vez; main/sub compartilham a decodificação. Mode7 mantém o caminho anterior.

O cache é local a renderOutputSegment: alterações posteriores de VRAM, CGRAM, scroll ou outros registradores são observadas no próximo segmento. Não existem endereços de jogo nem invalidadores persistentes. CPU, DMA, APU e scheduler não foram alterados.

Teste instrumentado apenas em cópia de teste: 1536 → 192 leituras de VRAM em uma linha 4bpp de 256 pixels. Comparação com renderer congelado: 128 cenas, modos 0–7, tiles 8/16, scroll/mapas/mosaico, fields/hires, janelas e mistura; caso literal confirma cor/tile/scroll alterados entre segmentos.

Benchmarks e validação do port estão em validation/RESULTADOS-v0.3.36.md. Os ganhos medem processamento headless Linux; execução Windows precisa de recompilação e medição própria.
