# Forja65 v0.3.42 — native dispatch generation

The cross-project loop now goes beyond CFG classification: a dispatch whose table extent and runtime index domain are proven can be materialized as native C++ routing data.

For DKC3 `$B9A157`, the generator preserves all 27 table slots and both aliases (6/8 and 7/9), while keeping handler execution on fallback until semantic equivalence is proven independently. Focused CFG marks 20 of 25 unique handlers as translation candidates and leaves five dynamic handlers explicit.
