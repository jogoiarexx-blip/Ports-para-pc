# Cross-project knowledge packs

Schema: `forja65.knowledge.v1`.

A pack may contain `entries` (65816 entry points plus E/M/X/C state and optional reviewed function `span`), `dataRegions`, and reviewed `dispatch` metadata. The ROM identity is bound by FNV-1a64. SHA-256 may also be carried as provenance.

Forja65 uses prioritized entries as CFG seeds. Known data regions suppress external seeds and return-adjacent linear seeds that would otherwise decode reviewed data as code. Imported names/categories feed the native-map profile.

Commands:

```text
node tools/forja65.js cross-analyze game.sfc --knowledge pack.json --out analysis
node tools/forja65.js focus-analyze game.sfc --knowledge pack.json --addresses B2802D,B2804B --out focus
node tools/forja65.js analyze game.sfc --knowledge pack.json --out project
node tools/forja65.js import-knowledge pack.json --rom game.sfc --out game_config.json
node tools/forja65.js export-knowledge project --out knowledge.json
```

Knowledge is evidence only. A seed is not runtime coverage, and a category is not semantic proof.

`focus-analyze` is intended for small UNKNOWN queues. It emits `focus-analysis.json` plus `knowledge-return.json` and can recognize direct JMP/JML family entries from already-classified tiny spans. This remains static evidence only.

## v0.3.39 bounded dispatch feedback

Focused results now expose `indirect_sites` and `knowledge-return.json` includes a `dispatch` array. A game-specific port can persist these candidates into its next `forja65.knowledge.v1` export. The next Forja pass consumes those candidates in both focused and whole-project CFG analysis. This is static discovery evidence only; unresolved runtime index bounds remain explicit.

## v0.3.40 writer-domain evidence

`dispatch[]` pode carregar `resolution`, contendo metadados de prova. O Forja preserva esse objeto na normalização. Para vetores RAM, o analisador pode registrar writers diretos e tabelas de registros; para `JMP(abs,X)`, pode registrar separadamente `table_extent_proven`, `index_bounds_proven` e `index_domain_fits_table`.

Isso evita que um port devolva ao Forja apenas uma lista de alvos sem indicar se ela veio de uma tabela estrutural, writer-domain local ou prova mais forte.


## v0.3.41 script-domain proof

`dispatch[].resolution.script_domain` pode transportar uma auditoria ROM-bound de produtores de bytecode. Campos como `closed_entries`, `invalid_entries`, `observed_ids_in_closed_entries`, `complete` e `index_bounds_proven` ficam anexados à evidência do dispatcher.

O Forja nunca converte `complete=false` em fechamento. Quando `complete=true`, `index_bounds_proven=true` e o maior ID provado cabe na tabela estrutural, o `focus-analyze` pode substituir o limite teórico local por `external-bytecode-script-domain-proof`.

## v0.3.42 native dispatch plan

Once a dispatch has both exact table extent and proven index-domain evidence, generate native routing with:

`node tools/forja65.js native-dispatch game.sfc --knowledge pack.json --site B9A157 --out native-dispatch`

The output contains `native-dispatch.json` plus `native_dispatch.generated.hpp`. It preserves aliases and observed IDs. It does not claim handler equivalence; generated handler execution remains fallback-required until a separate semantic/equivalence proof is supplied.

## Handler equivalence proofs (v0.3.43)

A project may return semantic proof separately from structural knowledge:

`node tools/forja65.js native-dispatch game.sfc --knowledge pack.json --site B9A157 --proofs handler-equivalence.json --out native-dispatch`

`forja65.handler-equivalence.v1` is deliberately strict. `equivalent` requires a matching ROM fingerprint, matching handler-span fingerprint, `scope=handler-abi`, and a PASS verification record. `dependency-boundary` may describe a reviewed native prefix plus unresolved calls, but never enables `equivalence_proven` by itself.
