# Changelog v0.3.38

- Added `focus-analyze` for fast per-address CFG analysis without re-running the whole-ROM cross analysis.
- Knowledge entries may now carry reviewed function `span` metadata; validation rejects entries outside their spans.
- Added direct JMP/JML family discovery from already-classified tiny spans (<=64 bytes).
- Focus output reports family, entry CPU state, instruction/call counts, issues and state-variant addresses.
- Added `knowledge-return.json` for a focused analysis handoff back to the producer project.
- Added regression coverage for category inheritance, span validation and an otherwise-unreachable focused target.
- DKC3 Native PC v0.69 is the first validation consumer; the implementation contains no DKC3-specific addresses.
