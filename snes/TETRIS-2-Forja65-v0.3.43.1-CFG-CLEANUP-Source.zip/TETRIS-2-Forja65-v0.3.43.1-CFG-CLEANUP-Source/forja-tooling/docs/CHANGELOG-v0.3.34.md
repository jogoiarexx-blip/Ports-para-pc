# Forja65 v0.3.34 — DMA e preparação da fase

Corrige a inversão dos bits de controle DMAP: bit 3 fixa o endereço A-bus; bit 4 seleciona decremento quando o endereço não está fixo. O avanço do endereço agora preserva o banco e faz wrap de 16 bits. O mesmo cálculo serve aos caminhos virtual/native e à direção reversa. Padrão dos registradores B-bus e contagem permanecem iguais.

O Tetris usa origem fixa em ROM contendo zero para limpar sua memória pelo porto WRAM. Na versão anterior o endereço era decrementado e copiava código da ROM; esses bytes impediram o fim da geração da fase. O problema foi confirmado por equivalência exata dos bytes e pelas escritas DMA capturadas.

Teste novo cobre preenchimento a partir de origem fixa, precedência de fixed, incremento/decremento nas fronteiras, direção reversa e ambos os caminhos DMA. Nenhum endereço do Tetris foi adicionado ao código do Forja.

Referências: Nintendo SNES Development Manual, livro 1, p. 148, seção 2-28-10 (D3/D4), https://floating.muncher.se/bot/manual/book1_text.pdf ; código oficial Snes9x, https://github.com/snes9xgit/snes9x/blob/master/dma.cpp (endereço A de 16 bits e banco separado).
