# Forja65 v0.3.31

Esta evolução preserva o tradutor 65C816 e conecta descoberta, trace, dependências e substituições host. A base é o ZIP v0.3.30 anexado; não incorpora automaticamente alterações de outras versões não anexadas.

## O gargalo encontrado

A base já tinha CFG com estados M/X/E/Carry, dispatcher retomável, Oracle/hints vinculados à ROM, replay, captura de assets PPU e auditoria global de hardware. Faltava cruzar essas informações por rotina e oferecer uma substituição host genérica com contrato de retorno verificável. Reescrever a CPU ou duplicar o capturador não resolveria esse gargalo.

## Componentes e contratos

| Componente | Função |
|---|---|
| `analysis/native-map.js` | Mescla CFG e eventos por rotina, gera grafo de chamadas e dependências, conserva símbolos e separa evidência estática/dinâmica. |
| `native/forja_trace.hpp` | Trace do runtime: PC/opcode, entrada/retorno de dispatch, bus read/write, portas PPU/APU/input, DMA/HDMA e controles. |
| `native/forja_ir.hpp` | IR host de palette e scroll, com validação de limites, independente de registradores PPU. |
| `SnesRuntime::registerNativeHook` | Substitui o corpo de uma rotina descoberta quando a entrada vem de JSR/JSL e as condições são atendidas. |
| `tools/forja65.js` | CLI para analisar, gerar/compilar projeto, executar/importar trace e comparar hashes por frame. |
| `profiles/game_config.json` | Fingerprint, nomes, aliases, categorias conhecidas e heurísticas por ROM. |

O core continua funcionando como arquivo único em Node, browser e hosts VM antigos. Os módulos são fontes de manutenção; `tools/sync-templates.js` e `tools/bundle-core.js` regeneram o bundle. O código analítico JavaScript não é ligado ao executável do jogo.

## Fluxo

```bash
node tools/forja65.js analyze game.sfc --out project
node tools/forja65.js trace project --frames 120 --execution reference
node tools/forja65.js build-native project
node tools/forja65.js import-trace forja-trace.csv --rom game.sfc --out analysis
node tools/forja65.js compare reference-hashes.txt --native native-hashes.txt --out first-divergence.json
```

O trace executa um projeto gerado e compila com instrumentação habilitada. O CMake deixa instrumentação desabilitada por padrão; para habilitar manualmente use `-DFORJA65_ENABLE_TRACE=ON`. Os modos anteriores de auditoria/replay/captura continuam disponíveis.

Na interface, use **Importar profile**, **Importar trace**, **Native Map** e **Salvar Native Map**. Um trace de outra ROM é rejeitado antes de alterar o estado atual. Os símbolos importados entram também no projeto C++ exportado.

`analyze --update` conserva o arquivo de hooks escrito pelo usuário e os símbolos do profile existente. Uma ROM diferente não pode reutilizar silenciosamente esse profile. O CLI rejeita a sobrescrita de um diretório existente sem essa opção. O build-native explicita TRACE OFF, inclusive se o cache CMake anterior tinha TRACE ON.

## Trace e interpretação

`FORJA65_TRACE=forja-trace.csv` seleciona o arquivo. `FORJA65_TRACE_LIMIT=250000` limita os eventos. O rodapé registra descartes e finalização; captura sem rodapé é incompleta. JSON/CSV/TXT são formatos de exportação analítica. O native-map Markdown é o modo resumido por rotina.

Os acessos são observados sem uma segunda leitura do bus. Os valores de registradores que limpam flags ao ler, como NMI, não são lidos de novo. Os fast paths B-bus também produzem eventos, com origem DMA/HDMA. Os endereços são endereços de bus SNES; aliases e portas indiretas de WRAM ainda exigem interpretação do mapper/estado para unir todas as dependências físicas.

`entry`/`return` são limites de invocação do dispatcher. Jumps/branches locais aparecem no fluxo de instruções/CFG; o trace não pretende detectar automaticamente toda função sem dispatch nem reconstruir todos os frames físicos de chamada do SNES.

Categorias AUDIO/RENDER/SAVE podem ser sugeridas por acessos observados. O peso de confiança é uma heurística para priorizar investigação, não uma probabilidade calibrada. PLAYER/ENEMY/COLLISION/CAMERA exigem conhecimento do profile ou investigação adicional; não são inventados a partir de endereços.

## ABI dos hooks

Implemente `src/native_hooks.cpp` do projeto gerado. Ele já é ligado pelo CMake e chamado na inicialização. O hook recebe CPU/runtime e retorna a duração equivalente em **master clocks** do corpo original, incluindo RTS/RTL; o tempo do JSR/JSL já foi contabilizado pelo chamador.

O dispatcher:

1. Prioriza a rotina cuja entrada coincide com o destino, inclusive quando o CFG de outra rotina contém o mesmo label.
2. Verifica estados E/M/X e um guard opcional sem efeitos colaterais.
3. Verifica o frame real de retorno antes e depois do corpo.
4. Confere S/E, profundidade/tipo/alvo de retorno e ausência de dispatch pendente.
5. Consome o retorno real, restaura PB e avança o clock.

Não faça RTS/RTL, push/pop de retorno ou dispatch dentro do corpo host. Violações encerram a execução; não há fallback automático depois de um hook ter alterado estado. Guard recusado ou M/X/E incompatível usa o código traduzido. `FORJA65_EXECUTION=reference` ignora todos os hooks.

Hooks atendem entradas de rotina recompiladas e chamadas JSR/JSL. Interrupções, jumps locais, tail jumps e labels de retomada permanecem no caminho traduzido nesta entrega. O autor da substituição deve preservar flags, memória, estado e timing necessários; o framework não prova equivalência por registrar um callback.

## Relatórios e métricas

O mapa conserva endereço original, nome/aliases, variantes de estado, chamadas estáticas/dinâmicas, instruções e conjuntos de RAM/ROM/portas lidos/escritos. Candidatos estáticos com data bank desconhecido são rotulados como candidatos, não como acessos comprovados.

O trace CLI atualiza native-map, compatibility-report e os hashes desses arquivos no manifesto. `analysis/function-analysis.json` conserva o CFG usado na geração, para não reanalisar com limites/hints diferentes ao importar uma execução.

CPU recompilada = **TRANSLATED**. PPU/DMA/HDMA/SPC700/DSP virtual = **EMULATED**. Corpo host observado = **NATIVE_OBSERVED**; execução com os dois caminhos = **MIXED**. Os antigos campos/flags chamados native foram preservados por compatibilidade, mas não são usados como prova de migração semântica nos novos relatórios.

O native score permanece `null` porque faltam denominadores confiáveis de jogo inteiro, renderer, objetos, áudio e independência de dados. Zero leituras ROM em um trecho curto não prova independência da ROM do jogo inteiro. Packs ROM ainda preservam representações dos dados originais.

## Comparação

`compare` localiza o primeiro frame com hashes de WRAM/framebuffer/PC distintos ou frame ausente. É comparação dos registros fornecidos, não comparação byte a byte de snapshots completos. Diferenças de PC podem ser esperadas após substituições host. O resultado distingue campo divergente e frame, sem inventar posições de player, RNG ou objetos que não tenham sido capturados.

A validação host desta entrega também compara diretamente RAM, A/X/S/PB/flags e PC SPC700 entre duas execuções sintéticas. Ambas conservam 294 master clocks; a contagem de instruções foi corrigida para não somar duas vezes trace + timing.

## Limites atuais

Não há renderer host completo, migração automática de entidades/áudio, runtime universal independente da ROM, banco de snapshots completo, debugger com todos os painéis ou implementação dos chips especiais. ForjaRenderer armazena palette/scroll, mas não compõe a cena final. O capturador PPU anterior permanece a ferramenta de extração existente.

ExLoROM não foi acrescentado; o suporte de mapper do runtime enviado foi preservado. O teste em jogos comerciais e a validação real de MSVC/Windows continuam necessários; compilações desta entrega foram executadas com GCC/Linux. A interface Windows continua usando a janela Edge App Mode existente.
