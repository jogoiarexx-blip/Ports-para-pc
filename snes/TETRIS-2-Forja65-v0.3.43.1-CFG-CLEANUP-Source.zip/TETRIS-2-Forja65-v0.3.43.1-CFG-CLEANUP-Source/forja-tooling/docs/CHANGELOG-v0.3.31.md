# v0.3.31 — Generic Native Map

- Mapa genérico de rotinas, chamadas e dependências cruzando CFG/trace.
- Trace do bus, PC/opcode, dispatch, DMA/HDMA, PPU/APU e input, limitado e removível da build.
- Profiles vinculados à ROM, símbolos/aliases e heurísticas conservadoras.
- Hooks host com states/guards, aliases, preferência por entrada exata e verificação da pilha física.
- Reference mode para manter execução traduzida como comparação.
- IR host inicial SetPalette/SetScroll, separado de registradores PPU.
- CLI e controles Native Map/profile/trace na interface existente.
- Comparador de primeira divergência nos hashes de frame existentes.
- Regeneração CLI conserva código host e símbolos; trace atualiza relatórios e manifesto.
- Contagem de instruções corrigida para evitar duplicidade trace/timing.
- Término normal por limite headless deixa de ser registrado como falha.
- Bundle standalone preserva hosts browser/VM anteriores.

A CPU não foi reescrita. Renderização host completa, entidades, áudio host e conversão automática sem ROM permanecem trabalho futuro.
