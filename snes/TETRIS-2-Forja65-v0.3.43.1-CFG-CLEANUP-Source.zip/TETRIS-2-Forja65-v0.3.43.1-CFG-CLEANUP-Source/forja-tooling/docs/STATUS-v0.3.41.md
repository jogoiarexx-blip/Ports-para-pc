# Status — Forja65 v0.3.41

A v0.3.41 preserva writer-domain e bounded-dispatch das versões anteriores e acrescenta uma camada de prova para dispatchers alimentados por bytecode.

`CFG-SCRIPT-DOMAIN-PARTIAL` significa que existe auditoria estrutural de scripts, mas ainda há entradas não resolvidas. Esse diagnóstico é propositalmente diferente de `CFG-INDEX-DOMAIN-UNPROVEN`: o primeiro descreve a cobertura do produtor de bytecode, enquanto o segundo descreve o limite local do índice no 65816.

Nenhuma evidência parcial é promovida a equivalência runtime.

Uma auditoria completa e ROM-bound, quando todos os IDs provados cabem na tabela estrutural, pode promover `index_bounds_proven=true` sem remover o dispatcher runtime. O DKC3 v0.72 validou esse caminho com 854/854 scripts não vazios fechados.
