#ifndef FORJA_TRACE_HPP
#define FORJA_TRACE_HPP
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <string>
#include <stdexcept>
#ifndef FORJA65_ENABLE_TRACE
#define FORJA65_ENABLE_TRACE 1
#endif
// No observer performs a bus read. Disabled builds perform no file or event work.
struct ForjaTrace {
#if FORJA65_ENABLE_TRACE
  std::ofstream out;
  std::uint64_t sequence{},written{},dropped{},limit{250000};
  bool enabled{};
  void start(const std::string&path,const std::string&rom,std::uint64_t cap=250000){close();out.open(path,std::ios::trunc);if(!out)throw std::runtime_error("Cannot open ForjaTrace: "+path);sequence=written=dropped=0;limit=cap;enabled=true;out<<"# FORJA_TRACE 1 rom="<<rom<<"\nseq,frame,routine,pc,kind,space,address,value,source\n";}
  void initialize(const std::string&rom){const char*p=std::getenv("FORJA65_TRACE");if(!p||!*p||std::string(p)=="0")return;std::uint64_t cap=250000;if(const char*c=std::getenv("FORJA65_TRACE_LIMIT")){try{cap=std::stoull(c);}catch(...){throw std::runtime_error("Invalid FORJA65_TRACE_LIMIT");}}start(std::string(p)=="1"?"forja-trace.csv":p,rom,cap);}
  void emit(std::uint64_t frame,std::uint32_t routine,std::uint32_t pc,const char*kind,const char*space,std::uint32_t address,std::uint64_t value,const char*source="CPU"){if(!enabled)return;const auto seq=sequence++;if(written>=limit){dropped++;return;}out<<seq<<','<<frame<<','<<routine<<','<<pc<<','<<kind<<','<<space<<','<<address<<','<<value<<','<<source<<'\n';if(!out)throw std::runtime_error("ForjaTrace write failed");written++;}
  void close(){if(out.is_open()){out<<"# written="<<written<<" dropped="<<dropped<<'\n';out.close();}enabled=false;}
#else
  static constexpr bool enabled=false;
  void start(const std::string&,const std::string&,std::uint64_t=250000){}
  void initialize(const std::string&){}
  void emit(std::uint64_t,std::uint32_t,std::uint32_t,const char*,const char*,std::uint32_t,std::uint64_t,const char* = "CPU"){}
  void close(){}
#endif
  ~ForjaTrace(){close();}
};
struct ForjaTraceContext {
  std::uint32_t&routine;const char*&source;std::uint32_t oldRoutine;const char*oldSource;
  ForjaTraceContext(std::uint32_t&r,const char*&s,std::uint32_t next,const char*origin):routine(r),source(s),oldRoutine(r),oldSource(s){routine=next;source=origin;}
  ~ForjaTraceContext(){routine=oldRoutine;source=oldSource;}
};

#endif
