@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if not exist assets\native-rom-data.bin (echo Falta assets\native-rom-data.bin. Rode RUN-ROM-CONVERGE.cmd.& pause & exit /b 2)
set GAME=bin\game.exe
if not exist "%GAME%" set GAME=build-win\Release\game.exe
if not exist "%GAME%" (echo game.exe nao encontrado.& pause & exit /b 3)
set FORJA65_HEADLESS=1
set FORJA65_HEADLESS_FRAMES=%~1
if "%FORJA65_HEADLESS_FRAMES%"=="" set FORJA65_HEADLESS_FRAMES=600
set FORJA65_ROM_MODE=native
set FORJA65_PPU_MODE=state
set FORJA65_DMA_MODE=native
set FORJA65_AUDIO_MODE=native
"%GAME%" || (echo O teste native-only falhou. Nao vou empacotar.& pause & exit /b 4)
if exist native-release rmdir /s /q native-release
mkdir native-release\assets
copy /y "%GAME%" native-release\game.exe >nul
copy /y assets\native-rom-data.bin native-release\assets\native-rom-data.bin >nul
copy /y RUN-NATIVE-PORT.cmd native-release\RUN-NATIVE-PORT.cmd >nul
copy /y forja65-build-manifest.txt native-release\forja65-build-manifest.txt >nul
echo Criado native-release SEM cart-data.bin.
pause
