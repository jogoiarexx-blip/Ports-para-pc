@echo off
setlocal
cd /d "%~dp0"
set FORJA65_ROM_MODE=cart
set FORJA65_ROM_PROFILE=1
set FORJA65_HEADLESS=1
set FORJA65_HEADLESS_FRAMES=%~1
if "%FORJA65_HEADLESS_FRAMES%"=="" set FORJA65_HEADLESS_FRAMES=1200
if exist forja65-rom-read-ranges.txt del /q forja65-rom-read-ranges.txt
call RUN-WINDOWS.cmd
echo Perfil: forja65-rom-read-ranges.txt
pause
