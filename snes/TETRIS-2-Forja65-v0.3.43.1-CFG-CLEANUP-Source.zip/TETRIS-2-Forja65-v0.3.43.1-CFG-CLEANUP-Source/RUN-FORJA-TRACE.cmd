@echo off
setlocal
cd /d "%~dp0"
set FORJA65_TRACE=forja-trace.csv
set FORJA65_TRACE_LIMIT=250000
set FORJA65_HEADLESS=1
set FORJA65_HEADLESS_FRAMES=%~1
if "%FORJA65_HEADLESS_FRAMES%"=="" set FORJA65_HEADLESS_FRAMES=120
call RUN-WINDOWS.cmd
echo Rebuild with FORJA65_ENABLE_TRACE=ON if no trace was produced.
pause
