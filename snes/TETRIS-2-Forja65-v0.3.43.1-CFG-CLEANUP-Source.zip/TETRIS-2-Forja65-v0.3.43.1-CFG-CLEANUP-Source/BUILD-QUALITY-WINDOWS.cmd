@echo off
setlocal
cd /d "%~dp0"
where cmake >nul 2>nul || (echo ERRO: CMake nao encontrado no PATH. & pause & exit /b 1)
cmake -S . -B build-quality -G "Visual Studio 17 2022" -A x64 -DFORJA65_STRICT=ON -DFORJA65_SANITIZERS=ON || goto :err
cmake --build build-quality --config RelWithDebInfo --target game runtime_smoke scene_capture_smoke oracle_learning_smoke deterministic_input_smoke native_dependency_smoke native_migration_smoke rom_pack_builder equivalence_runner framework_smoke || goto :err
ctest --test-dir build-quality -C RelWithDebInfo --output-on-failure || goto :err
echo QUALITY PASS
pause
exit /b 0
:err
echo QUALITY FAIL
pause
exit /b 1
