@echo off
setlocal
cd /d "%~dp0"
set FORJA65_ROM_MODE=native
set FORJA65_PPU_MODE=state
set FORJA65_DMA_MODE=native
set FORJA65_AUDIO_MODE=native
set FORJA65_AUDIO_DUMP=0
game.exe
exit /b %ERRORLEVEL%
