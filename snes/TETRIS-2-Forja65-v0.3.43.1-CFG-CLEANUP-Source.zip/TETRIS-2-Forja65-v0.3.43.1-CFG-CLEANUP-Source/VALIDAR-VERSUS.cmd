@echo off
setlocal
cd /d "%~dp0"
node forja-tooling\tools\forja65.js converge "%~dp0." --frames 3200 --rounds 24 --watchdog 100000000 --replay "%~dp0validation\input-versus-com.txt"
set "CODE=%ERRORLEVEL%"
pause
exit /b %CODE%
