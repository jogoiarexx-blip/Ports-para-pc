#include "generated.hpp"
void sub_808345_E0M1X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808345u: goto L_808345;
    case 0x808349u: goto L_808349;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808345:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8345u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8345u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8345u, 8u, 4u, 0x84BD3Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808345 JSL -> $84BD3E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8348u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8349u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84BD3Eu, 0x808345u); }
    goto L_808349;
L_808349:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8349u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8349u,0x808349u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8349u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8349u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808349 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808349u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x808349u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_808345_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808345u: goto L_808345;
    case 0x808349u: goto L_808349;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808345:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8345u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8345u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8345u, 8u, 4u, 0x84BD3Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808345 JSL -> $84BD3E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8348u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8349u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84BD3Eu, 0x808345u); }
    goto L_808349;
L_808349:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8349u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8349u,0x808349u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8349u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8349u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808349 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808349u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x808349u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_808420_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808420u: goto L_808420;
    case 0x808424u: goto L_808424;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808420:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8420u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8420u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8420u, 8u, 4u, 0x829128u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808420 JSL -> $829128 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8423u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8424u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x829128u, 0x808420u); }
    goto L_808424;
L_808424:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8424u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8424u,0x808424u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8424u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8424u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808424 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808424u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x808424u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_8084B8_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8084B8u: goto L_8084B8;
    case 0x8084BCu: goto L_8084BC;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8084B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84B8u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84B8u, 8u, 4u, 0x84BEA5u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8084B8 JSL -> $84BEA5 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x84BBu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x84BCu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84BEA5u, 0x8084B8u); }
    goto L_8084BC;
L_8084BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84BCu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x84BCu,0x8084BCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84BCu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84BCu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8084BC RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8084BCu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8084BCu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_8084B8_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8084B8u: goto L_8084B8;
    case 0x8084BCu: goto L_8084BC;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8084B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84B8u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84B8u, 8u, 4u, 0x84BEA5u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8084B8 JSL -> $84BEA5 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x84BBu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x84BCu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84BEA5u, 0x8084B8u); }
    goto L_8084BC;
L_8084BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84BCu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x84BCu,0x8084BCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84BCu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84BCu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8084BC RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8084BCu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8084BCu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_808547_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808547u: goto L_808547;
    case 0x808548u: goto L_808548;
    case 0x80854Au: goto L_80854A;
    case 0x80854Bu: goto L_80854B;
    case 0x80854Du: goto L_80854D;
    case 0x80854Fu: goto L_80854F;
    case 0x808552u: goto L_808552;
    case 0x808554u: goto L_808554;
    case 0x808555u: goto L_808555;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808547:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8547u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8547u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8547u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808547 PHP
    cpu.push("PHP", hw);
    goto L_808548;
L_808548:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8548u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8548u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8548u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808548 SEP
    cpu.sep(0x20u);
    goto L_80854A;
L_80854A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x854Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x854Au,cpu,0x58u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x854Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80854A CLI
    cpu.setFlag('I', false);
    goto L_80854B;
L_80854B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x854Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x854Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x854Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x73u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80854B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x73u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80854D;
L_80854D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x854Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x854Du,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x854Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80854D ORA
    cpu.logicOr(0x81u);
    goto L_80854F;
L_80854F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x854Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x854Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x854Fu, 4u, 3u, cpu.address("abs", 0x4200u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80854F STA
    hw.write(cpu.address("abs", 0x4200u), cpu.a, cpu.m8?8:16);
    goto L_808552;
L_808552:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8552u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8552u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8552u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x73u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808552 STA
    hw.write(cpu.address("dp", 0x73u), cpu.a, cpu.m8?8:16);
    goto L_808554;
L_808554:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8554u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8554u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8554u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808554 PLP
    cpu.pop("PLP", hw);
    goto L_808555;
L_808555:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8555u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8555u,0x808555u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8555u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8555u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808555 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808555u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x808555u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_8085AD_E0M1X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8085ADu: goto L_8085AD;
    case 0x8085AFu: goto L_8085AF;
    case 0x8085B2u: goto L_8085B2;
    case 0x8085B4u: goto L_8085B4;
    case 0x8085B7u: goto L_8085B7;
    case 0x8085B9u: goto L_8085B9;
    case 0x8085BCu: goto L_8085BC;
    case 0x8085BEu: goto L_8085BE;
    case 0x8085C1u: goto L_8085C1;
    case 0x8085C3u: goto L_8085C3;
    case 0x8085C6u: goto L_8085C6;
    case 0x8085C8u: goto L_8085C8;
    case 0x8085CBu: goto L_8085CB;
    case 0x8085CDu: goto L_8085CD;
    case 0x8085D0u: goto L_8085D0;
    case 0x8085D2u: goto L_8085D2;
    case 0x8085D5u: goto L_8085D5;
    case 0x8085D7u: goto L_8085D7;
    case 0x8085DAu: goto L_8085DA;
    case 0x8085DCu: goto L_8085DC;
    case 0x8085DFu: goto L_8085DF;
    case 0x8085E1u: goto L_8085E1;
    case 0x8085E4u: goto L_8085E4;
    case 0x8085E6u: goto L_8085E6;
    case 0x8085E9u: goto L_8085E9;
    case 0x8085EBu: goto L_8085EB;
    case 0x8085EEu: goto L_8085EE;
    case 0x8085F0u: goto L_8085F0;
    case 0x8085F3u: goto L_8085F3;
    case 0x8085F5u: goto L_8085F5;
    case 0x8085F8u: goto L_8085F8;
    case 0x8085FAu: goto L_8085FA;
    case 0x8085FDu: goto L_8085FD;
    case 0x808600u: goto L_808600;
    case 0x808603u: goto L_808603;
    case 0x808606u: goto L_808606;
    case 0x808609u: goto L_808609;
    case 0x80860Cu: goto L_80860C;
    case 0x80860Fu: goto L_80860F;
    case 0x808612u: goto L_808612;
    case 0x808615u: goto L_808615;
    case 0x808618u: goto L_808618;
    case 0x80861Bu: goto L_80861B;
    case 0x80861Eu: goto L_80861E;
    case 0x808621u: goto L_808621;
    case 0x808624u: goto L_808624;
    case 0x808627u: goto L_808627;
    case 0x80862Au: goto L_80862A;
    case 0x80862Du: goto L_80862D;
    case 0x808630u: goto L_808630;
    case 0x808633u: goto L_808633;
    case 0x808636u: goto L_808636;
    case 0x808639u: goto L_808639;
    case 0x80863Cu: goto L_80863C;
    case 0x80863Fu: goto L_80863F;
    case 0x808642u: goto L_808642;
    case 0x808645u: goto L_808645;
    case 0x808647u: goto L_808647;
    case 0x80864Au: goto L_80864A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8085AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85ADu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85ADu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085AD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085AF;
L_8085AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85AFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85AFu, 4u, 3u, cpu.address("abs", 0x210Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085AF STA
    hw.write(cpu.address("abs", 0x210Du), cpu.a, cpu.m8?8:16);
    goto L_8085B2;
L_8085B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85B2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85B2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085B2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085B4;
L_8085B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85B4u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85B4u, 4u, 3u, cpu.address("abs", 0x210Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085B4 STA
    hw.write(cpu.address("abs", 0x210Du), cpu.a, cpu.m8?8:16);
    goto L_8085B7;
L_8085B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85B7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85B7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x80u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085B7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x80u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085B9;
L_8085B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85B9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85B9u, 4u, 3u, cpu.address("abs", 0x210Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085B9 STA
    hw.write(cpu.address("abs", 0x210Eu), cpu.a, cpu.m8?8:16);
    goto L_8085BC;
L_8085BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85BCu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85BCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x81u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085BC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x81u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085BE;
L_8085BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85BEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85BEu, 4u, 3u, cpu.address("abs", 0x210Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085BE STA
    hw.write(cpu.address("abs", 0x210Eu), cpu.a, cpu.m8?8:16);
    goto L_8085C1;
L_8085C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85C1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85C1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x82u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085C1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x82u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085C3;
L_8085C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85C3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85C3u, 4u, 3u, cpu.address("abs", 0x210Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085C3 STA
    hw.write(cpu.address("abs", 0x210Fu), cpu.a, cpu.m8?8:16);
    goto L_8085C6;
L_8085C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85C6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85C6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x83u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085C6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x83u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085C8;
L_8085C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85C8u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85C8u, 4u, 3u, cpu.address("abs", 0x210Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085C8 STA
    hw.write(cpu.address("abs", 0x210Fu), cpu.a, cpu.m8?8:16);
    goto L_8085CB;
L_8085CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85CBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85CBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x84u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085CB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x84u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085CD;
L_8085CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85CDu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85CDu, 4u, 3u, cpu.address("abs", 0x2110u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085CD STA
    hw.write(cpu.address("abs", 0x2110u), cpu.a, cpu.m8?8:16);
    goto L_8085D0;
L_8085D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85D0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85D0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x85u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085D0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x85u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085D2;
L_8085D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85D2u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85D2u, 4u, 3u, cpu.address("abs", 0x2110u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085D2 STA
    hw.write(cpu.address("abs", 0x2110u), cpu.a, cpu.m8?8:16);
    goto L_8085D5;
L_8085D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85D5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85D5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x86u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085D5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x86u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085D7;
L_8085D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85D7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85D7u, 4u, 3u, cpu.address("abs", 0x2111u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085D7 STA
    hw.write(cpu.address("abs", 0x2111u), cpu.a, cpu.m8?8:16);
    goto L_8085DA;
L_8085DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85DAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85DAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x87u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085DA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x87u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085DC;
L_8085DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85DCu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85DCu, 4u, 3u, cpu.address("abs", 0x2111u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085DC STA
    hw.write(cpu.address("abs", 0x2111u), cpu.a, cpu.m8?8:16);
    goto L_8085DF;
L_8085DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85DFu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85DFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085DF LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x88u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085E1;
L_8085E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85E1u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85E1u, 4u, 3u, cpu.address("abs", 0x2112u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085E1 STA
    hw.write(cpu.address("abs", 0x2112u), cpu.a, cpu.m8?8:16);
    goto L_8085E4;
L_8085E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85E4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85E4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x89u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085E4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x89u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085E6;
L_8085E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85E6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85E6u, 4u, 3u, cpu.address("abs", 0x2112u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085E6 STA
    hw.write(cpu.address("abs", 0x2112u), cpu.a, cpu.m8?8:16);
    goto L_8085E9;
L_8085E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85E9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85E9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085E9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085EB;
L_8085EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85EBu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85EBu, 4u, 3u, cpu.address("abs", 0x2113u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085EB STA
    hw.write(cpu.address("abs", 0x2113u), cpu.a, cpu.m8?8:16);
    goto L_8085EE;
L_8085EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85EEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85EEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085EE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085F0;
L_8085F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85F0u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85F0u, 4u, 3u, cpu.address("abs", 0x2113u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085F0 STA
    hw.write(cpu.address("abs", 0x2113u), cpu.a, cpu.m8?8:16);
    goto L_8085F3;
L_8085F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85F3u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85F3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085F3 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085F5;
L_8085F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85F5u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85F5u, 4u, 3u, cpu.address("abs", 0x2114u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085F5 STA
    hw.write(cpu.address("abs", 0x2114u), cpu.a, cpu.m8?8:16);
    goto L_8085F8;
L_8085F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85F8u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85F8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085F8 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085FA;
L_8085FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85FAu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85FAu, 4u, 3u, cpu.address("abs", 0x2114u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085FA STA
    hw.write(cpu.address("abs", 0x2114u), cpu.a, cpu.m8?8:16);
    goto L_8085FD;
L_8085FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85FDu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85FDu, 4u, 3u, cpu.address("abs", 0x0100u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085FD LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x100u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808600;
L_808600:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8600u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8600u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8600u, 4u, 3u, cpu.address("abs", 0x211Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808600 STA
    hw.write(cpu.address("abs", 0x211Bu), cpu.a, cpu.m8?8:16);
    goto L_808603;
L_808603:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8603u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8603u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8603u, 4u, 3u, cpu.address("abs", 0x0101u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808603 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x101u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808606;
L_808606:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8606u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8606u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8606u, 4u, 3u, cpu.address("abs", 0x211Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808606 STA
    hw.write(cpu.address("abs", 0x211Bu), cpu.a, cpu.m8?8:16);
    goto L_808609;
L_808609:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8609u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8609u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8609u, 4u, 3u, cpu.address("abs", 0x0102u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808609 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x102u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80860C;
L_80860C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x860Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x860Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x860Cu, 4u, 3u, cpu.address("abs", 0x211Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80860C STA
    hw.write(cpu.address("abs", 0x211Cu), cpu.a, cpu.m8?8:16);
    goto L_80860F;
L_80860F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x860Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x860Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x860Fu, 4u, 3u, cpu.address("abs", 0x0103u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80860F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x103u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808612;
L_808612:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8612u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8612u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8612u, 4u, 3u, cpu.address("abs", 0x211Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808612 STA
    hw.write(cpu.address("abs", 0x211Cu), cpu.a, cpu.m8?8:16);
    goto L_808615;
L_808615:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8615u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8615u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8615u, 4u, 3u, cpu.address("abs", 0x0104u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808615 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x104u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808618;
L_808618:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8618u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8618u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8618u, 4u, 3u, cpu.address("abs", 0x211Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808618 STA
    hw.write(cpu.address("abs", 0x211Du), cpu.a, cpu.m8?8:16);
    goto L_80861B;
L_80861B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x861Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x861Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x861Bu, 4u, 3u, cpu.address("abs", 0x0105u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80861B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x105u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80861E;
L_80861E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x861Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x861Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x861Eu, 4u, 3u, cpu.address("abs", 0x211Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80861E STA
    hw.write(cpu.address("abs", 0x211Du), cpu.a, cpu.m8?8:16);
    goto L_808621;
L_808621:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8621u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8621u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8621u, 4u, 3u, cpu.address("abs", 0x0106u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808621 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x106u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808624;
L_808624:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8624u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8624u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8624u, 4u, 3u, cpu.address("abs", 0x211Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808624 STA
    hw.write(cpu.address("abs", 0x211Eu), cpu.a, cpu.m8?8:16);
    goto L_808627;
L_808627:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8627u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8627u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8627u, 4u, 3u, cpu.address("abs", 0x0107u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808627 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x107u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80862A;
L_80862A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x862Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x862Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x862Au, 4u, 3u, cpu.address("abs", 0x211Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80862A STA
    hw.write(cpu.address("abs", 0x211Eu), cpu.a, cpu.m8?8:16);
    goto L_80862D;
L_80862D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x862Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x862Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x862Du, 4u, 3u, cpu.address("abs", 0x0108u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80862D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x108u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808630;
L_808630:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8630u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8630u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8630u, 4u, 3u, cpu.address("abs", 0x211Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808630 STA
    hw.write(cpu.address("abs", 0x211Fu), cpu.a, cpu.m8?8:16);
    goto L_808633;
L_808633:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8633u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8633u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8633u, 4u, 3u, cpu.address("abs", 0x0109u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808633 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x109u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808636;
L_808636:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8636u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8636u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8636u, 4u, 3u, cpu.address("abs", 0x211Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808636 STA
    hw.write(cpu.address("abs", 0x211Fu), cpu.a, cpu.m8?8:16);
    goto L_808639;
L_808639:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8639u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8639u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8639u, 4u, 3u, cpu.address("abs", 0x010Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808639 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x10Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80863C;
L_80863C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x863Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x863Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x863Cu, 4u, 3u, cpu.address("abs", 0x2120u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80863C STA
    hw.write(cpu.address("abs", 0x2120u), cpu.a, cpu.m8?8:16);
    goto L_80863F;
L_80863F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x863Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x863Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x863Fu, 4u, 3u, cpu.address("abs", 0x010Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80863F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x10Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808642;
L_808642:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8642u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8642u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8642u, 4u, 3u, cpu.address("abs", 0x2120u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808642 STA
    hw.write(cpu.address("abs", 0x2120u), cpu.a, cpu.m8?8:16);
    goto L_808645;
L_808645:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8645u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8645u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8645u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808645 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x77u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808647;
L_808647:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8647u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8647u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8647u, 4u, 3u, cpu.address("abs", 0x2106u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808647 STA
    hw.write(cpu.address("abs", 0x2106u), cpu.a, cpu.m8?8:16);
    goto L_80864A;
L_80864A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x864Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x864Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x864Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80864A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80864Au);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80864Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_8085AD_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8085ADu: goto L_8085AD;
    case 0x8085AFu: goto L_8085AF;
    case 0x8085B2u: goto L_8085B2;
    case 0x8085B4u: goto L_8085B4;
    case 0x8085B7u: goto L_8085B7;
    case 0x8085B9u: goto L_8085B9;
    case 0x8085BCu: goto L_8085BC;
    case 0x8085BEu: goto L_8085BE;
    case 0x8085C1u: goto L_8085C1;
    case 0x8085C3u: goto L_8085C3;
    case 0x8085C6u: goto L_8085C6;
    case 0x8085C8u: goto L_8085C8;
    case 0x8085CBu: goto L_8085CB;
    case 0x8085CDu: goto L_8085CD;
    case 0x8085D0u: goto L_8085D0;
    case 0x8085D2u: goto L_8085D2;
    case 0x8085D5u: goto L_8085D5;
    case 0x8085D7u: goto L_8085D7;
    case 0x8085DAu: goto L_8085DA;
    case 0x8085DCu: goto L_8085DC;
    case 0x8085DFu: goto L_8085DF;
    case 0x8085E1u: goto L_8085E1;
    case 0x8085E4u: goto L_8085E4;
    case 0x8085E6u: goto L_8085E6;
    case 0x8085E9u: goto L_8085E9;
    case 0x8085EBu: goto L_8085EB;
    case 0x8085EEu: goto L_8085EE;
    case 0x8085F0u: goto L_8085F0;
    case 0x8085F3u: goto L_8085F3;
    case 0x8085F5u: goto L_8085F5;
    case 0x8085F8u: goto L_8085F8;
    case 0x8085FAu: goto L_8085FA;
    case 0x8085FDu: goto L_8085FD;
    case 0x808600u: goto L_808600;
    case 0x808603u: goto L_808603;
    case 0x808606u: goto L_808606;
    case 0x808609u: goto L_808609;
    case 0x80860Cu: goto L_80860C;
    case 0x80860Fu: goto L_80860F;
    case 0x808612u: goto L_808612;
    case 0x808615u: goto L_808615;
    case 0x808618u: goto L_808618;
    case 0x80861Bu: goto L_80861B;
    case 0x80861Eu: goto L_80861E;
    case 0x808621u: goto L_808621;
    case 0x808624u: goto L_808624;
    case 0x808627u: goto L_808627;
    case 0x80862Au: goto L_80862A;
    case 0x80862Du: goto L_80862D;
    case 0x808630u: goto L_808630;
    case 0x808633u: goto L_808633;
    case 0x808636u: goto L_808636;
    case 0x808639u: goto L_808639;
    case 0x80863Cu: goto L_80863C;
    case 0x80863Fu: goto L_80863F;
    case 0x808642u: goto L_808642;
    case 0x808645u: goto L_808645;
    case 0x808647u: goto L_808647;
    case 0x80864Au: goto L_80864A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8085AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85ADu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85ADu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085AD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085AF;
L_8085AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85AFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85AFu, 4u, 3u, cpu.address("abs", 0x210Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085AF STA
    hw.write(cpu.address("abs", 0x210Du), cpu.a, cpu.m8?8:16);
    goto L_8085B2;
L_8085B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85B2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85B2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085B2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085B4;
L_8085B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85B4u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85B4u, 4u, 3u, cpu.address("abs", 0x210Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085B4 STA
    hw.write(cpu.address("abs", 0x210Du), cpu.a, cpu.m8?8:16);
    goto L_8085B7;
L_8085B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85B7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85B7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x80u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085B7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x80u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085B9;
L_8085B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85B9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85B9u, 4u, 3u, cpu.address("abs", 0x210Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085B9 STA
    hw.write(cpu.address("abs", 0x210Eu), cpu.a, cpu.m8?8:16);
    goto L_8085BC;
L_8085BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85BCu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85BCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x81u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085BC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x81u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085BE;
L_8085BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85BEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85BEu, 4u, 3u, cpu.address("abs", 0x210Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085BE STA
    hw.write(cpu.address("abs", 0x210Eu), cpu.a, cpu.m8?8:16);
    goto L_8085C1;
L_8085C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85C1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85C1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x82u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085C1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x82u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085C3;
L_8085C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85C3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85C3u, 4u, 3u, cpu.address("abs", 0x210Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085C3 STA
    hw.write(cpu.address("abs", 0x210Fu), cpu.a, cpu.m8?8:16);
    goto L_8085C6;
L_8085C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85C6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85C6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x83u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085C6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x83u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085C8;
L_8085C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85C8u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85C8u, 4u, 3u, cpu.address("abs", 0x210Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085C8 STA
    hw.write(cpu.address("abs", 0x210Fu), cpu.a, cpu.m8?8:16);
    goto L_8085CB;
L_8085CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85CBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85CBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x84u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085CB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x84u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085CD;
L_8085CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85CDu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85CDu, 4u, 3u, cpu.address("abs", 0x2110u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085CD STA
    hw.write(cpu.address("abs", 0x2110u), cpu.a, cpu.m8?8:16);
    goto L_8085D0;
L_8085D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85D0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85D0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x85u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085D0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x85u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085D2;
L_8085D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85D2u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85D2u, 4u, 3u, cpu.address("abs", 0x2110u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085D2 STA
    hw.write(cpu.address("abs", 0x2110u), cpu.a, cpu.m8?8:16);
    goto L_8085D5;
L_8085D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85D5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85D5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x86u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085D5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x86u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085D7;
L_8085D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85D7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85D7u, 4u, 3u, cpu.address("abs", 0x2111u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085D7 STA
    hw.write(cpu.address("abs", 0x2111u), cpu.a, cpu.m8?8:16);
    goto L_8085DA;
L_8085DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85DAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85DAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x87u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085DA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x87u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085DC;
L_8085DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85DCu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85DCu, 4u, 3u, cpu.address("abs", 0x2111u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085DC STA
    hw.write(cpu.address("abs", 0x2111u), cpu.a, cpu.m8?8:16);
    goto L_8085DF;
L_8085DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85DFu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85DFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085DF LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x88u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085E1;
L_8085E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85E1u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85E1u, 4u, 3u, cpu.address("abs", 0x2112u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085E1 STA
    hw.write(cpu.address("abs", 0x2112u), cpu.a, cpu.m8?8:16);
    goto L_8085E4;
L_8085E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85E4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85E4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x89u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085E4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x89u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085E6;
L_8085E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85E6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85E6u, 4u, 3u, cpu.address("abs", 0x2112u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085E6 STA
    hw.write(cpu.address("abs", 0x2112u), cpu.a, cpu.m8?8:16);
    goto L_8085E9;
L_8085E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85E9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85E9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085E9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085EB;
L_8085EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85EBu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85EBu, 4u, 3u, cpu.address("abs", 0x2113u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085EB STA
    hw.write(cpu.address("abs", 0x2113u), cpu.a, cpu.m8?8:16);
    goto L_8085EE;
L_8085EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85EEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85EEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085EE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085F0;
L_8085F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85F0u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85F0u, 4u, 3u, cpu.address("abs", 0x2113u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085F0 STA
    hw.write(cpu.address("abs", 0x2113u), cpu.a, cpu.m8?8:16);
    goto L_8085F3;
L_8085F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85F3u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85F3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085F3 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085F5;
L_8085F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85F5u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85F5u, 4u, 3u, cpu.address("abs", 0x2114u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085F5 STA
    hw.write(cpu.address("abs", 0x2114u), cpu.a, cpu.m8?8:16);
    goto L_8085F8;
L_8085F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85F8u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85F8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085F8 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085FA;
L_8085FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85FAu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85FAu, 4u, 3u, cpu.address("abs", 0x2114u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085FA STA
    hw.write(cpu.address("abs", 0x2114u), cpu.a, cpu.m8?8:16);
    goto L_8085FD;
L_8085FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85FDu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85FDu, 4u, 3u, cpu.address("abs", 0x0100u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085FD LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x100u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808600;
L_808600:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8600u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8600u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8600u, 4u, 3u, cpu.address("abs", 0x211Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808600 STA
    hw.write(cpu.address("abs", 0x211Bu), cpu.a, cpu.m8?8:16);
    goto L_808603;
L_808603:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8603u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8603u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8603u, 4u, 3u, cpu.address("abs", 0x0101u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808603 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x101u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808606;
L_808606:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8606u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8606u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8606u, 4u, 3u, cpu.address("abs", 0x211Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808606 STA
    hw.write(cpu.address("abs", 0x211Bu), cpu.a, cpu.m8?8:16);
    goto L_808609;
L_808609:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8609u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8609u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8609u, 4u, 3u, cpu.address("abs", 0x0102u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808609 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x102u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80860C;
L_80860C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x860Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x860Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x860Cu, 4u, 3u, cpu.address("abs", 0x211Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80860C STA
    hw.write(cpu.address("abs", 0x211Cu), cpu.a, cpu.m8?8:16);
    goto L_80860F;
L_80860F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x860Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x860Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x860Fu, 4u, 3u, cpu.address("abs", 0x0103u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80860F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x103u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808612;
L_808612:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8612u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8612u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8612u, 4u, 3u, cpu.address("abs", 0x211Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808612 STA
    hw.write(cpu.address("abs", 0x211Cu), cpu.a, cpu.m8?8:16);
    goto L_808615;
L_808615:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8615u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8615u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8615u, 4u, 3u, cpu.address("abs", 0x0104u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808615 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x104u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808618;
L_808618:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8618u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8618u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8618u, 4u, 3u, cpu.address("abs", 0x211Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808618 STA
    hw.write(cpu.address("abs", 0x211Du), cpu.a, cpu.m8?8:16);
    goto L_80861B;
L_80861B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x861Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x861Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x861Bu, 4u, 3u, cpu.address("abs", 0x0105u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80861B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x105u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80861E;
L_80861E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x861Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x861Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x861Eu, 4u, 3u, cpu.address("abs", 0x211Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80861E STA
    hw.write(cpu.address("abs", 0x211Du), cpu.a, cpu.m8?8:16);
    goto L_808621;
L_808621:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8621u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8621u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8621u, 4u, 3u, cpu.address("abs", 0x0106u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808621 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x106u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808624;
L_808624:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8624u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8624u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8624u, 4u, 3u, cpu.address("abs", 0x211Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808624 STA
    hw.write(cpu.address("abs", 0x211Eu), cpu.a, cpu.m8?8:16);
    goto L_808627;
L_808627:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8627u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8627u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8627u, 4u, 3u, cpu.address("abs", 0x0107u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808627 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x107u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80862A;
L_80862A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x862Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x862Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x862Au, 4u, 3u, cpu.address("abs", 0x211Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80862A STA
    hw.write(cpu.address("abs", 0x211Eu), cpu.a, cpu.m8?8:16);
    goto L_80862D;
L_80862D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x862Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x862Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x862Du, 4u, 3u, cpu.address("abs", 0x0108u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80862D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x108u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808630;
L_808630:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8630u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8630u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8630u, 4u, 3u, cpu.address("abs", 0x211Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808630 STA
    hw.write(cpu.address("abs", 0x211Fu), cpu.a, cpu.m8?8:16);
    goto L_808633;
L_808633:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8633u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8633u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8633u, 4u, 3u, cpu.address("abs", 0x0109u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808633 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x109u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808636;
L_808636:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8636u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8636u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8636u, 4u, 3u, cpu.address("abs", 0x211Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808636 STA
    hw.write(cpu.address("abs", 0x211Fu), cpu.a, cpu.m8?8:16);
    goto L_808639;
L_808639:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8639u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8639u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8639u, 4u, 3u, cpu.address("abs", 0x010Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808639 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x10Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80863C;
L_80863C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x863Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x863Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x863Cu, 4u, 3u, cpu.address("abs", 0x2120u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80863C STA
    hw.write(cpu.address("abs", 0x2120u), cpu.a, cpu.m8?8:16);
    goto L_80863F;
L_80863F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x863Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x863Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x863Fu, 4u, 3u, cpu.address("abs", 0x010Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80863F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x10Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808642;
L_808642:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8642u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8642u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8642u, 4u, 3u, cpu.address("abs", 0x2120u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808642 STA
    hw.write(cpu.address("abs", 0x2120u), cpu.a, cpu.m8?8:16);
    goto L_808645;
L_808645:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8645u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8645u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8645u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808645 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x77u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808647;
L_808647:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8647u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8647u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8647u, 4u, 3u, cpu.address("abs", 0x2106u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808647 STA
    hw.write(cpu.address("abs", 0x2106u), cpu.a, cpu.m8?8:16);
    goto L_80864A;
L_80864A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x864Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x864Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x864Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80864A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80864Au);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80864Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_808AC7_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808AC7u: goto L_808AC7;
    case 0x808ACAu: goto L_808ACA;
    case 0x808ACCu: goto L_808ACC;
    case 0x808ACEu: goto L_808ACE;
    case 0x808AD1u: goto L_808AD1;
    case 0x808AD3u: goto L_808AD3;
    case 0x808AD4u: goto L_808AD4;
    case 0x808AD6u: goto L_808AD6;
    case 0x808AD8u: goto L_808AD8;
    case 0x808AD9u: goto L_808AD9;
    case 0x808ADBu: goto L_808ADB;
    case 0x808ADDu: goto L_808ADD;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808AC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AC7u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AC7u, 4u + 1u, 3u, cpu.address("absy", 0x0005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808AC7 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808ACA;
L_808ACA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ACAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ACAu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ACAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808ACA AND
    cpu.logicAnd(0xF0u);
    goto L_808ACC;
L_808ACC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ACCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ACCu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ACCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808ACC STA
    hw.write(cpu.address("dp", 0x1Au), cpu.a, cpu.m8?8:16);
    goto L_808ACE;
L_808ACE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ACEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ACEu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ACEu, 4u + 1u, 3u, cpu.address("absy", 0x0005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808ACE LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808AD1;
L_808AD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AD1u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AD1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808AD1 AND
    cpu.logicAnd(0x3u);
    goto L_808AD3;
L_808AD3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AD3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AD3u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AD3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808AD3 DEC
    cpu.decReg('A');
    goto L_808AD4;
L_808AD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AD4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AD4u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AD4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808AD4 BPL -> $808AD8
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_808AD8; }
    goto L_808AD6;
L_808AD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AD6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AD6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808AD6 LDA
    cpu.setA(0x0u, 8);
    goto L_808AD8;
L_808AD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AD8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AD8u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AD8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808AD8 ASL
    cpu.aslA();
    goto L_808AD9;
L_808AD9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AD9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AD9u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AD9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808AD9 ORA
    cpu.logicOr(0x8u);
    goto L_808ADB;
L_808ADB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ADBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ADBu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ADBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808ADB ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16));
    goto L_808ADD;
L_808ADD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ADDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ADDu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ADDu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808ADD RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x808ADDu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x808ADDu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_808D4A_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808D4Au: goto L_808D4A;
    case 0x808D4Bu: goto L_808D4B;
    case 0x808D4Eu: goto L_808D4E;
    case 0x808D4Fu: goto L_808D4F;
    case 0x808D50u: goto L_808D50;
    case 0x808D54u: goto L_808D54;
    case 0x808D55u: goto L_808D55;
    case 0x808D58u: goto L_808D58;
    case 0x808D5Cu: goto L_808D5C;
    case 0x808D5Du: goto L_808D5D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808D4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D4Au,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D4Au, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808D4A PHP
    cpu.push("PHP", hw);
    goto L_808D4B;
L_808D4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D4Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D4Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D4B AND
    cpu.logicAnd(0x7u);
    goto L_808D4E;
L_808D4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D4Eu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D4Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D4E ASL
    cpu.aslA();
    goto L_808D4F;
L_808D4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D4Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D4Fu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D4Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D4F TAX
    cpu.transfer("TAX");
    goto L_808D50;
L_808D50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D50u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D50u, 6u, 4u, ((0x808D5Eu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D50 LDA
    cpu.loadA(hw.readW(((0x808D5Eu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808D54;
L_808D54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D54u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D54u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D54 TAY
    cpu.transfer("TAY");
    goto L_808D55;
L_808D55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D55u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D55u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D55 LDA
    cpu.setA(0x80u, 16);
    goto L_808D58;
L_808D58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D58u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D58u, 8u, 4u, 0x808DBEu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808D58 JSL -> $808DBE stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8D5Bu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8D5Cu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808DBEu, 0x808D58u); }
    goto L_808D5C;
L_808D5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D5Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D5Cu,0x808D5Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D5Cu,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D5Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808D5C PLP
    cpu.pop("PLP", hw);
    goto L_808D5D;
L_808D5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D5Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D5Du,0x808D5Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D5Du,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D5Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808D5D RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808D5Du);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x808D5Du,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_808D4A_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808D4Au: goto L_808D4A;
    case 0x808D4Bu: goto L_808D4B;
    case 0x808D4Eu: goto L_808D4E;
    case 0x808D4Fu: goto L_808D4F;
    case 0x808D50u: goto L_808D50;
    case 0x808D54u: goto L_808D54;
    case 0x808D55u: goto L_808D55;
    case 0x808D58u: goto L_808D58;
    case 0x808D5Cu: goto L_808D5C;
    case 0x808D5Du: goto L_808D5D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808D4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D4Au,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D4Au, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808D4A PHP
    cpu.push("PHP", hw);
    goto L_808D4B;
L_808D4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D4Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D4Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D4B AND
    cpu.logicAnd(0x7u);
    goto L_808D4E;
L_808D4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D4Eu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D4Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D4E ASL
    cpu.aslA();
    goto L_808D4F;
L_808D4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D4Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D4Fu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D4Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D4F TAX
    cpu.transfer("TAX");
    goto L_808D50;
L_808D50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D50u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D50u, 6u, 4u, ((0x808D5Eu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D50 LDA
    cpu.loadA(hw.readW(((0x808D5Eu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808D54;
L_808D54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D54u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D54u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D54 TAY
    cpu.transfer("TAY");
    goto L_808D55;
L_808D55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D55u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D55u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D55 LDA
    cpu.setA(0x80u, 16);
    goto L_808D58;
L_808D58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D58u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D58u, 8u, 4u, 0x808DBEu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808D58 JSL -> $808DBE stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8D5Bu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8D5Cu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808DBEu, 0x808D58u); }
    goto L_808D5C;
L_808D5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D5Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D5Cu,0x808D5Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D5Cu,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D5Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808D5C PLP
    cpu.pop("PLP", hw);
    goto L_808D5D;
L_808D5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D5Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D5Du,0x808D5Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D5Du,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D5Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808D5D RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808D5Du);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x808D5Du,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_809BFB_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809BFBu: goto L_809BFB;
    case 0x809BFDu: goto L_809BFD;
    case 0x809BFFu: goto L_809BFF;
    case 0x809C00u: goto L_809C00;
    case 0x809C02u: goto L_809C02;
    case 0x809C06u: goto L_809C06;
    case 0x809C07u: goto L_809C07;
    case 0x809C08u: goto L_809C08;
    case 0x809C09u: goto L_809C09;
    case 0x809C0Au: goto L_809C0A;
    case 0x809C0Cu: goto L_809C0C;
    case 0x809C0Fu: goto L_809C0F;
    case 0x809C12u: goto L_809C12;
    case 0x809C15u: goto L_809C15;
    case 0x809C19u: goto L_809C19;
    case 0x809C1Du: goto L_809C1D;
    case 0x809C1Eu: goto L_809C1E;
    case 0x809C1Fu: goto L_809C1F;
    case 0x809C22u: goto L_809C22;
    case 0x809C23u: goto L_809C23;
    case 0x809C24u: goto L_809C24;
    case 0x809C26u: goto L_809C26;
    case 0x809C29u: goto L_809C29;
    case 0x809C2Cu: goto L_809C2C;
    case 0x809C30u: goto L_809C30;
    case 0x809C34u: goto L_809C34;
    case 0x809C35u: goto L_809C35;
    case 0x809C36u: goto L_809C36;
    case 0x809C37u: goto L_809C37;
    case 0x809C39u: goto L_809C39;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809BFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BFBu,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BFBu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $809BFB LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809BFD;
L_809BFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BFDu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BFDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809BFD BPL -> $809C00
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_809C00; }
    goto L_809BFF;
L_809BFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BFFu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BFFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $809BFF RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x809BFFu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x809BFFu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_809C00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C00u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C00u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C00 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16));
    goto L_809C02;
L_809C02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C02u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C02u, 6u, 4u, ((0x7E2800u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C02 STA
    hw.write(((0x7E2800u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_809C06;
L_809C06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C06u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C06u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C06 INX
    cpu.inc('X');
    goto L_809C07;
L_809C07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C07u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C07u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C07 INX
    cpu.inc('X');
    goto L_809C08;
L_809C08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C08u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C08u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C08 INY
    cpu.inc('Y');
    goto L_809C09;
L_809C09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C09u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C09u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C09 INY
    cpu.inc('Y');
    goto L_809C0A;
L_809C0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C0Au,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C0Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C0A BPL -> $809BFB
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_809BFB; }
    goto L_809C0C;
L_809C0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C0Cu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C0Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C0C LDY
    cpu.setY(0x16u, 16);
    goto L_809C0F;
L_809C0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C0Fu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C0Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C0F LDX
    cpu.setX(0x0u, 16);
    goto L_809C12;
L_809C12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C12u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C12u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C12 LDA
    cpu.setA(0xFFFFu, 16);
    goto L_809C15;
L_809C15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C15u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C15u, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C15 STA
    hw.write(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_809C19;
L_809C19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C19u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C19u, 6u, 4u, ((0x7E2220u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C19 STA
    hw.write(((0x7E2220u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_809C1D;
L_809C1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C1Du,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C1Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C1D TXA
    cpu.transfer("TXA");
    goto L_809C1E;
L_809C1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C1Eu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C1Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C1E CLC
    cpu.setFlag('C', false);
    goto L_809C1F;
L_809C1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C1Fu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C1Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C1F ADC
    cpu.adc(0x16u);
    goto L_809C22;
L_809C22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C22u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C22u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C22 TAX
    cpu.transfer("TAX");
    goto L_809C23;
L_809C23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C23u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C23u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C23 DEY
    cpu.decReg('Y');
    goto L_809C24;
L_809C24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C24u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C24u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C24 BPL -> $809C12
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_809C12; }
    goto L_809C26;
L_809C26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C26u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C26u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C26 LDY
    cpu.setY(0xBu, 16);
    goto L_809C29;
L_809C29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C29u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C29u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C29 LDA
    cpu.setA(0xFFFFu, 16);
    goto L_809C2C;
L_809C2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C2Cu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C2Cu, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C2C STA
    hw.write(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_809C30;
L_809C30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C30u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C30u, 6u, 4u, ((0x7E2220u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C30 STA
    hw.write(((0x7E2220u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_809C34;
L_809C34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C34u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C34u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C34 INX
    cpu.inc('X');
    goto L_809C35;
L_809C35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C35u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C35u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C35 INX
    cpu.inc('X');
    goto L_809C36;
L_809C36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C36u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C36u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C36 DEY
    cpu.decReg('Y');
    goto L_809C37;
L_809C37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C37u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C37u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C37 BPL -> $809C29
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_809C29; }
    goto L_809C39;
L_809C39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C39u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C39u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $809C39 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x809C39u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x809C39u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80AE47_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80AE47u: goto L_80AE47;
    case 0x80AE4Au: goto L_80AE4A;
    case 0x80AE4Cu: goto L_80AE4C;
    case 0x80AE4Fu: goto L_80AE4F;
    case 0x80AE52u: goto L_80AE52;
    case 0x80AE54u: goto L_80AE54;
    case 0x80AE57u: goto L_80AE57;
    case 0x80AE5Au: goto L_80AE5A;
    case 0x80AE5Du: goto L_80AE5D;
    case 0x80AE60u: goto L_80AE60;
    case 0x80AE63u: goto L_80AE63;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80AE47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE47u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE47u, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE47 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x958u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AE4A;
L_80AE4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE4Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE4Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE4A BEQ -> $80AE5D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AE5D; }
    goto L_80AE4C;
L_80AE4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE4Cu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE4Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE4C LDX
    cpu.setX(0x328u, 16);
    goto L_80AE4F;
L_80AE4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE4Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE4Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE4Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE4F LDA
    cpu.setA(0x3u, 16);
    goto L_80AE52;
L_80AE52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE52u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE52u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE52 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80AE54;
L_80AE54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE54u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE54u, 8u, 3u, cpu.address("abs", 0x0986u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE54 INC
    cpu.incMem(hw, cpu.address("abs", 0x986u), cpu.m8?8:16);
    goto L_80AE57;
L_80AE57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE57u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE57u, 6u, 3u, cpu.address("abs", 0xC829u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AE57 JSR -> $80C829 stack real
    { cpu.push16Value(hw,0xAE59u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAE5Au,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC829u), 0x80AE57u); }
    goto L_80AE5A;
L_80AE5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE5Au))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE5Au,0x80AE5Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE5Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE5Au, 6u, 3u, cpu.address("abs", 0xBBFAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AE5A JSR -> $80BBFA stack real
    { cpu.push16Value(hw,0xAE5Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAE5Du,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBBFAu), 0x80AE5Au); }
    goto L_80AE5D;
L_80AE5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE5Du))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE5Du,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE5Du, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE5D STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80AE60;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE5Du,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE5Du, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE5D STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80AE60;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE5Du,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE5Du, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE5D STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80AE60;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE5Du,0x80AE5Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AE60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE60u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE60u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE60u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE60 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80AE63;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE60u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE60u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE60 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80AE63;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE60u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE60u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE60 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80AE63;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE60u,0x80AE60u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AE63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE63u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE63u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE63u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AE63 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80AE63u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80AE63u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE63u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE63u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AE63 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80AE63u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80AE63u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE63u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE63u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AE63 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80AE63u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80AE63u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE63u,0x80AE63u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80AF42_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80AF42u: goto L_80AF42;
    case 0x80AF45u: goto L_80AF45;
    case 0x80AF47u: goto L_80AF47;
    case 0x80AF4Au: goto L_80AF4A;
    case 0x80AF4Cu: goto L_80AF4C;
    case 0x80AF4Fu: goto L_80AF4F;
    case 0x80AF52u: goto L_80AF52;
    case 0x80AF55u: goto L_80AF55;
    case 0x80AF57u: goto L_80AF57;
    case 0x80AF5Au: goto L_80AF5A;
    case 0x80AF5Du: goto L_80AF5D;
    case 0x80AF60u: goto L_80AF60;
    case 0x80AF63u: goto L_80AF63;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80AF42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF42u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF42u, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF42 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x958u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AF45;
L_80AF45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF45u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF45u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF45 BEQ -> $80AF5D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AF5D; }
    goto L_80AF47;
L_80AF47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF47u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF47u, 5u, 3u, cpu.address("abs", 0x0916u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF47 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x916u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AF4A;
L_80AF4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF4Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF4Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF4A BEQ -> $80AF5D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AF5D; }
    goto L_80AF4C;
L_80AF4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF4Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF4Cu, 5u, 3u, cpu.address("abs", 0x097Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF4C STA
    hw.write(cpu.address("abs", 0x97Au), cpu.a, cpu.m8?8:16);
    goto L_80AF4F;
L_80AF4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF4Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF4Fu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF4Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF4F LDX
    cpu.setX(0x41Au, 16);
    goto L_80AF52;
L_80AF52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF52u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF52u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF52 LDA
    cpu.setA(0x3u, 16);
    goto L_80AF55;
L_80AF55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF55u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF55u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF55 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80AF57;
L_80AF57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF57u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF57u, 8u, 3u, cpu.address("abs", 0x0986u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF57 INC
    cpu.incMem(hw, cpu.address("abs", 0x986u), cpu.m8?8:16);
    goto L_80AF5A;
L_80AF5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF5Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF5Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF5Au, 6u, 3u, cpu.address("abs", 0xC85Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AF5A JSR -> $80C85C stack real
    { cpu.push16Value(hw,0xAF5Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF5Du,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC85Cu), 0x80AF5Au); }
    goto L_80AF5D;
L_80AF5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF5Du))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF5Du,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF5Du, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF5D STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80AF60;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF5Du,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF5Du, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF5D STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80AF60;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF5Du,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF5Du, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF5D STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80AF60;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF5Du,0x80AF5Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AF60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF60u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF60u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF60u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF60 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80AF63;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF60u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF60u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF60 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80AF63;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF60u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF60u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF60 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80AF63;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF60u,0x80AF60u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AF63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF63u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF63u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF63u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AF63 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80AF63u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80AF63u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF63u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF63u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AF63 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80AF63u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80AF63u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF63u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF63u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AF63 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80AF63u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80AF63u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF63u,0x80AF63u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80AF42_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80AF42u: goto L_80AF42;
    case 0x80AF45u: goto L_80AF45;
    case 0x80AF47u: goto L_80AF47;
    case 0x80AF4Au: goto L_80AF4A;
    case 0x80AF4Cu: goto L_80AF4C;
    case 0x80AF4Fu: goto L_80AF4F;
    case 0x80AF52u: goto L_80AF52;
    case 0x80AF55u: goto L_80AF55;
    case 0x80AF57u: goto L_80AF57;
    case 0x80AF5Au: goto L_80AF5A;
    case 0x80AF5Du: goto L_80AF5D;
    case 0x80AF60u: goto L_80AF60;
    case 0x80AF63u: goto L_80AF63;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80AF42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF42u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF42u, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF42 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x958u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AF45;
L_80AF45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF45u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF45u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF45 BEQ -> $80AF5D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AF5D; }
    goto L_80AF47;
L_80AF47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF47u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF47u, 5u, 3u, cpu.address("abs", 0x0916u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF47 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x916u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AF4A;
L_80AF4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF4Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF4Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF4A BEQ -> $80AF5D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AF5D; }
    goto L_80AF4C;
L_80AF4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF4Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF4Cu, 5u, 3u, cpu.address("abs", 0x097Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF4C STA
    hw.write(cpu.address("abs", 0x97Au), cpu.a, cpu.m8?8:16);
    goto L_80AF4F;
L_80AF4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF4Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF4Fu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF4Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF4F LDX
    cpu.setX(0x41Au, 16);
    goto L_80AF52;
L_80AF52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF52u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF52u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF52 LDA
    cpu.setA(0x3u, 16);
    goto L_80AF55;
L_80AF55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF55u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF55u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF55 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80AF57;
L_80AF57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF57u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF57u, 8u, 3u, cpu.address("abs", 0x0986u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF57 INC
    cpu.incMem(hw, cpu.address("abs", 0x986u), cpu.m8?8:16);
    goto L_80AF5A;
L_80AF5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF5Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF5Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF5Au, 6u, 3u, cpu.address("abs", 0xC85Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AF5A JSR -> $80C85C stack real
    { cpu.push16Value(hw,0xAF5Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF5Du,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC85Cu), 0x80AF5Au); }
    goto L_80AF5D;
L_80AF5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF5Du))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF5Du,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF5Du, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF5D STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80AF60;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF5Du,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF5Du, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF5D STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80AF60;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF5Du,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF5Du, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF5D STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80AF60;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF5Du,0x80AF5Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AF60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF60u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF60u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF60u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF60 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80AF63;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF60u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF60u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF60 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80AF63;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF60u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF60u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF60 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80AF63;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF60u,0x80AF60u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AF63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF63u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF63u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF63u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AF63 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80AF63u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80AF63u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF63u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF63u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AF63 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80AF63u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80AF63u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF63u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF63u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AF63 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80AF63u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80AF63u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF63u,0x80AF63u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80B1F0_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B1F0u: goto L_80B1F0;
    case 0x80B1F3u: goto L_80B1F3;
    case 0x80B1F5u: goto L_80B1F5;
    case 0x80B1F8u: goto L_80B1F8;
    case 0x80B1FAu: goto L_80B1FA;
    case 0x80B1FDu: goto L_80B1FD;
    case 0x80B200u: goto L_80B200;
    case 0x80B203u: goto L_80B203;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B1F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F0u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F0u, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B1F0 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x958u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B1F3;
L_80B1F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B1F3 BEQ -> $80B1FD
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B1FD; }
    goto L_80B1F5;
L_80B1F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F5u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F5u, 5u, 3u, cpu.address("abs", 0x095Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B1F5 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x95Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B1F8;
L_80B1F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F8u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B1F8 BEQ -> $80B1FD
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B1FD; }
    goto L_80B1FA;
L_80B1FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1FAu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1FAu, 8u, 3u, cpu.address("abs", 0x0986u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B1FA INC
    cpu.incMem(hw, cpu.address("abs", 0x986u), cpu.m8?8:16);
    goto L_80B1FD;
L_80B1FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1FDu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1FDu, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B1FD INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B200;
L_80B200:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB200u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB200u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB200u, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B200 STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80B203;
L_80B203:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB203u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB203u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB203u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B203 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B203u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B203u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80B27F_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B27Fu: goto L_80B27F;
    case 0x80B282u: goto L_80B282;
    case 0x80B284u: goto L_80B284;
    case 0x80B287u: goto L_80B287;
    case 0x80B28Au: goto L_80B28A;
    case 0x80B28Du: goto L_80B28D;
    case 0x80B290u: goto L_80B290;
    case 0x80B292u: goto L_80B292;
    case 0x80B295u: goto L_80B295;
    case 0x80B298u: goto L_80B298;
    case 0x80B29Bu: goto L_80B29B;
    case 0x80B29Eu: goto L_80B29E;
    case 0x80B2A1u: goto L_80B2A1;
    case 0x80B2A4u: goto L_80B2A4;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B27F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB27Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB27Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB27Fu, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B27F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x958u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B282;
L_80B282:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB282u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB282u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB282u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B282 BEQ -> $80B29E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B29E; }
    goto L_80B284;
L_80B284:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB284u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB284u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB284u, 5u, 3u, cpu.address("abs", 0x090Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B284 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x90Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B287;
L_80B287:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB287u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB287u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB287u, 5u, 3u, cpu.address("abs", 0x0910u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B287 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x910u), cpu.m8?8:16));
    goto L_80B28A;
L_80B28A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB28Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB28Au,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB28Au, 5u, 3u, cpu.address("abs", 0x0912u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B28A ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x912u), cpu.m8?8:16));
    goto L_80B28D;
L_80B28D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB28Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB28Du,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB28Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B28D CMP
    cpu.compareA(0x4u);
    goto L_80B290;
L_80B290:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB290u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB290u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB290u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B290 BNE -> $80B29E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B29E; }
    goto L_80B292;
L_80B292:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB292u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB292u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB292u, 8u, 3u, cpu.address("abs", 0x0986u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B292 INC
    cpu.incMem(hw, cpu.address("abs", 0x986u), cpu.m8?8:16);
    goto L_80B295;
L_80B295:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB295u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB295u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB295u, 5u, 3u, cpu.address("abs", 0x0914u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B295 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x914u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B298;
L_80B298:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB298u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB298u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB298u, 5u, 3u, cpu.address("abs", 0x097Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B298 STA
    hw.write(cpu.address("abs", 0x97Au), cpu.a, cpu.m8?8:16);
    goto L_80B29B;
L_80B29B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB29Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB29Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB29Bu, 6u, 3u, cpu.address("abs", 0xCE62u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B29B JSR -> $80CE62 stack real
    { cpu.push16Value(hw,0xB29Du); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB29Eu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCE62u), 0x80B29Bu); }
    goto L_80B29E;
L_80B29E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB29Eu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB29Eu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB29Eu, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B29E STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80B2A1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB29Eu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB29Eu, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B29E STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80B2A1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB29Eu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB29Eu, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B29E STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80B2A1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB29Eu,0x80B29Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2A1u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2A1u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2A1u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2A1 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B2A4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2A1u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2A1u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2A1 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B2A4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2A1u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2A1u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2A1 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B2A4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2A1u,0x80B2A1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2A4u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2A4u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2A4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B2A4 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B2A4u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B2A4u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2A4u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2A4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B2A4 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B2A4u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B2A4u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2A4u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2A4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B2A4 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B2A4u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B2A4u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2A4u,0x80B2A4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80B987_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B987u: goto L_80B987;
    case 0x80B98Au: goto L_80B98A;
    case 0x80B98Cu: goto L_80B98C;
    case 0x80B98Fu: goto L_80B98F;
    case 0x80B991u: goto L_80B991;
    case 0x80B994u: goto L_80B994;
    case 0x80B997u: goto L_80B997;
    case 0x80B99Au: goto L_80B99A;
    case 0x80B99Cu: goto L_80B99C;
    case 0x80B99Fu: goto L_80B99F;
    case 0x80B9A1u: goto L_80B9A1;
    case 0x80B9A4u: goto L_80B9A4;
    case 0x80B9A6u: goto L_80B9A6;
    case 0x80B9A9u: goto L_80B9A9;
    case 0x80B9ACu: goto L_80B9AC;
    case 0x80B9AFu: goto L_80B9AF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B987:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB987u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB987u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB987u, 5u, 3u, cpu.address("abs", 0x094Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B987 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x94Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B98A;
L_80B98A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB98Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB98Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB98Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B98A BNE -> $80B99C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B99C; }
    goto L_80B98C;
L_80B98C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB98Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB98Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB98Cu, 5u, 3u, cpu.address("abs", 0x0944u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B98C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x944u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B98F;
L_80B98F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB98Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB98Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB98Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B98F BNE -> $80B99C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B99C; }
    goto L_80B991;
L_80B991:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB991u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB991u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB991u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B991 LDA
    cpu.setA(0x200u, 16);
    goto L_80B994;
L_80B994:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB994u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB994u,cpu,0x0Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB994u, 8u, 3u, cpu.address("abs", 0x0922u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B994 TSB
    cpu.tsb(hw, cpu.address("abs", 0x922u), cpu.m8?8:16);
    goto L_80B997;
L_80B997:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB997u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB997u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB997u, 8u, 3u, cpu.address("abs", 0x0948u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B997 INC
    cpu.incMem(hw, cpu.address("abs", 0x948u), cpu.m8?8:16);
    goto L_80B99A;
L_80B99A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB99Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB99Au,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB99Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B99A BRA -> $80B9AF
    goto L_80B9AF;
L_80B99C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB99Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB99Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB99Cu, 5u, 3u, cpu.address("abs", 0x0948u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B99C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x948u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B99F;
L_80B99F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB99Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB99Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB99Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B99F BNE -> $80B9AF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B9AF; }
    goto L_80B9A1;
L_80B9A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9A1u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9A1u, 5u, 3u, cpu.address("abs", 0x0942u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9A1 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x942u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B9A4;
L_80B9A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9A4u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9A4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9A4 BNE -> $80B9AF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B9AF; }
    goto L_80B9A6;
L_80B9A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9A6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9A6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9A6 LDA
    cpu.setA(0x100u, 16);
    goto L_80B9A9;
L_80B9A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9A9u,cpu,0x0Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9A9u, 8u, 3u, cpu.address("abs", 0x0922u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9A9 TSB
    cpu.tsb(hw, cpu.address("abs", 0x922u), cpu.m8?8:16);
    goto L_80B9AC;
L_80B9AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9ACu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9ACu, 8u, 3u, cpu.address("abs", 0x094Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9AC INC
    cpu.incMem(hw, cpu.address("abs", 0x94Au), cpu.m8?8:16);
    goto L_80B9AF;
L_80B9AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9AFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9AFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B9AF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B9AFu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B9AFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80BB30_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80BB30u: goto L_80BB30;
    case 0x80BB33u: goto L_80BB33;
    case 0x80BB36u: goto L_80BB36;
    case 0x80BB38u: goto L_80BB38;
    case 0x80BB3Bu: goto L_80BB3B;
    case 0x80BB3Eu: goto L_80BB3E;
    case 0x80BB3Fu: goto L_80BB3F;
    case 0x80BB40u: goto L_80BB40;
    case 0x80BB44u: goto L_80BB44;
    case 0x80BB46u: goto L_80BB46;
    case 0x80BB49u: goto L_80BB49;
    case 0x80BB4Bu: goto L_80BB4B;
    case 0x80BB4Eu: goto L_80BB4E;
    case 0x80BB50u: goto L_80BB50;
    case 0x80BB53u: goto L_80BB53;
    case 0x80BB56u: goto L_80BB56;
    case 0x80BB58u: goto L_80BB58;
    case 0x80BB5Bu: goto L_80BB5B;
    case 0x80BB5Du: goto L_80BB5D;
    case 0x80BB60u: goto L_80BB60;
    case 0x80BB64u: goto L_80BB64;
    case 0x80BB67u: goto L_80BB67;
    case 0x80BB6Au: goto L_80BB6A;
    case 0x80BB6Du: goto L_80BB6D;
    case 0x80BB6Fu: goto L_80BB6F;
    case 0x80BB71u: goto L_80BB71;
    case 0x80BB73u: goto L_80BB73;
    case 0x80BB76u: goto L_80BB76;
    case 0x80BB79u: goto L_80BB79;
    case 0x80BB7Bu: goto L_80BB7B;
    case 0x80BB7Eu: goto L_80BB7E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80BB30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB30u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB30u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB30 LDX
    cpu.setX(0x41Au, 16);
    goto L_80BB33;
L_80BB33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB33u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB33u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB33 LDA
    cpu.setA(0xEu, 16);
    goto L_80BB36;
L_80BB36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB36u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB36u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB36 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80BB38;
L_80BB38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB38u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB38u, 5u, 3u, cpu.address("abs", 0x0988u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB38 STZ
    hw.write(cpu.address("abs", 0x988u), 0, cpu.m8?8:16);
    goto L_80BB3B;
L_80BB3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB3Bu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB3Bu, 5u, 3u, cpu.address("abs", 0x098Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB3B STZ
    hw.write(cpu.address("abs", 0x98Au), 0, cpu.m8?8:16);
    goto L_80BB3E;
L_80BB3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB3Eu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB3Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB3E DEX
    cpu.decReg('X');
    goto L_80BB3F;
L_80BB3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB3Fu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB3Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB3F DEX
    cpu.decReg('X');
    goto L_80BB40;
L_80BB40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB40u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB40u, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB40 LDA
    cpu.loadA(hw.readW(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BB44;
L_80BB44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB44u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB44u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB44 BEQ -> $80BB3E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BB3E; }
    goto L_80BB46;
L_80BB46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB46u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB46u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB46 CMP
    cpu.compareA(0xFFFFu);
    goto L_80BB49;
L_80BB49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB49u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB49u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB49 BEQ -> $80BB6F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BB6F; }
    goto L_80BB4B;
L_80BB4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB4Bu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB4Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB4B BIT
    cpu.bit(0x2000u, true);
    goto L_80BB4E;
L_80BB4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB4Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB4Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB4E BNE -> $80BB58
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BB58; }
    goto L_80BB50;
L_80BB50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB50u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB50u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB50 AND
    cpu.logicAnd(0xFu);
    goto L_80BB53;
L_80BB53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB53u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB53u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB53u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB53 CMP
    cpu.compareA(0xFu);
    goto L_80BB56;
L_80BB56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB56u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB56u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB56u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB56 BNE -> $80BB3E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BB3E; }
    goto L_80BB58;
L_80BB58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB58u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB58u, 5u, 3u, cpu.address("abs", 0x0988u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB58 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x988u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BB5B;
L_80BB5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB5Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB5Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB5Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB5B BNE -> $80BB6A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BB6A; }
    goto L_80BB5D;
L_80BB5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB5Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB5Du,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB5Du, 5u, 3u, cpu.address("abs", 0x098Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB5D STX
    hw.write(cpu.address("abs", 0x98Cu), cpu.x, cpu.x8?8:16);
    goto L_80BB60;
L_80BB60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB60u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB60u, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB60 LDA
    cpu.loadA(hw.readW(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BB64;
L_80BB64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB64u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB64u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB64 AND
    cpu.logicAnd(0x300u);
    goto L_80BB67;
L_80BB67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB67u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB67u, 5u, 3u, cpu.address("abs", 0x098Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB67 STA
    hw.write(cpu.address("abs", 0x98Eu), cpu.a, cpu.m8?8:16);
    goto L_80BB6A;
L_80BB6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB6Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB6Au,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB6Au, 8u, 3u, cpu.address("abs", 0x0988u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB6A INC
    cpu.incMem(hw, cpu.address("abs", 0x988u), cpu.m8?8:16);
    goto L_80BB6D;
L_80BB6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB6Du,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB6Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB6D BRA -> $80BB3E
    goto L_80BB3E;
L_80BB6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB6Fu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB6Fu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB6F DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_80BB71;
L_80BB71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB71u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB71u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB71 BNE -> $80BB3E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BB3E; }
    goto L_80BB73;
L_80BB73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB73u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB73u, 5u, 3u, cpu.address("abs", 0x0988u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB73 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x988u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BB76;
L_80BB76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB76u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB76u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB76 CMP
    cpu.compareA(0x5u);
    goto L_80BB79;
L_80BB79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB79u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB79u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB79 BCS -> $80BB7E
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80BB7E; }
    goto L_80BB7B;
L_80BB7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB7Bu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB7Bu, 8u, 3u, cpu.address("abs", 0x098Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB7B INC
    cpu.incMem(hw, cpu.address("abs", 0x98Au), cpu.m8?8:16);
    goto L_80BB7E;
L_80BB7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB7Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB7Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BB7E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80BB7Eu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80BB7Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80C48E_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80C48Eu: goto L_80C48E;
    case 0x80C491u: goto L_80C491;
    case 0x80C494u: goto L_80C494;
    case 0x80C496u: goto L_80C496;
    case 0x80C499u: goto L_80C499;
    case 0x80C49Bu: goto L_80C49B;
    case 0x80C49Du: goto L_80C49D;
    case 0x80C49Fu: goto L_80C49F;
    case 0x80C4A1u: goto L_80C4A1;
    case 0x80C4A2u: goto L_80C4A2;
    case 0x80C4A3u: goto L_80C4A3;
    case 0x80C4A7u: goto L_80C4A7;
    case 0x80C4A9u: goto L_80C4A9;
    case 0x80C4ACu: goto L_80C4AC;
    case 0x80C4AEu: goto L_80C4AE;
    case 0x80C4B0u: goto L_80C4B0;
    case 0x80C4B3u: goto L_80C4B3;
    case 0x80C4B5u: goto L_80C4B5;
    case 0x80C4B7u: goto L_80C4B7;
    case 0x80C4B9u: goto L_80C4B9;
    case 0x80C4BBu: goto L_80C4BB;
    case 0x80C4BEu: goto L_80C4BE;
    case 0x80C4C2u: goto L_80C4C2;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80C48E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC48Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC48Eu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC48Eu, 5u, 3u, cpu.address("abs", 0x096Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C48E LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x96Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C491;
L_80C491:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC491u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC491u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC491u, 5u, 3u, cpu.address("abs", 0x0970u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C491 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x970u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C494;
L_80C494:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC494u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC494u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC494u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C494 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80C496;
L_80C496:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC496u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC496u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC496u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C496 LDA
    cpu.setA(0x1Eu, 16);
    goto L_80C499;
L_80C499:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC499u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC499u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC499u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C499 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_80C49B;
L_80C49B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC49Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC49Bu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC49Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C49B STZ
    hw.write(cpu.address("dp", 0x63u), 0, cpu.m8?8:16);
    goto L_80C49D;
L_80C49D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC49Du))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC49Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC49Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C49D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C49F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC49Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC49Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C49D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C49F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC49Du,0x80C49Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C49F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC49Fu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC49Fu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC49Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C49F BMI -> $80C4B9
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_80C4B9; }
    goto L_80C4A1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC49Fu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC49Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C49F BMI -> $80C4B9
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_80C4B9; }
    goto L_80C4A1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC49Fu,0x80C49Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C4A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4A1u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4A1u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4A1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4A1 INX
    cpu.inc('X');
    goto L_80C4A2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4A1u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4A1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4A1 INX
    cpu.inc('X');
    goto L_80C4A2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC4A1u,0x80C4A1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C4A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4A2u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4A2u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4A2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4A2 INX
    cpu.inc('X');
    goto L_80C4A3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4A2u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4A2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4A2 INX
    cpu.inc('X');
    goto L_80C4A3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC4A2u,0x80C4A2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C4A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4A3u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4A3u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4A3u, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4A3 LDA
    cpu.loadA(hw.readW(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C4A7;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4A3u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4A3u, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4A3 LDA
    cpu.loadA(hw.readW(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C4A7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC4A3u,0x80C4A3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C4A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4A7u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4A7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4A7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4A7 BEQ -> $80C49D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C49D; }
    goto L_80C4A9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4A7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4A7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4A7 BEQ -> $80C49D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C49D; }
    goto L_80C4A9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC4A7u,0x80C4A7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C4A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4A9u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4A9u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4A9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4A9 CMP
    cpu.compareA(0xFFFFu);
    goto L_80C4AC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4A9u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4A9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4A9 CMP
    cpu.compareA(0xFFFFu);
    goto L_80C4AC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC4A9u,0x80C4A9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C4AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4ACu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4ACu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4AC BEQ -> $80C4B5
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C4B5; }
    goto L_80C4AE;
L_80C4AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4AEu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4AEu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4AE DEC
    cpu.decMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_80C4B0;
L_80C4B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B0u, 6u, 3u, cpu.address("abs", 0xC4C3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80C4B0 JSR -> $80C4C3 stack real
    { cpu.push16Value(hw,0xC4B2u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC4B3u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC4C3u), 0x80C4B0u); }
    goto L_80C4B3;
L_80C4B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4B3u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC4B3u,0x80C4B3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B3u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4B3 BRA -> $80C49D
    goto L_80C49D;
L_80C4B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B5u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B5u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4B5 DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_80C4B7;
L_80C4B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B7u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4B7 BNE -> $80C49D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C49D; }
    goto L_80C4B9;
L_80C4B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4B9u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B9u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4B9 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C4BB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B9u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4B9 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C4BB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC4B9u,0x80C4B9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C4BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4BBu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4BBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4BBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4BB LDA
    cpu.setA(0xFFFFu, 16);
    goto L_80C4BE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4BBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4BBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4BB LDA
    cpu.setA(0xFFFFu, 16);
    goto L_80C4BE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC4BBu,0x80C4BBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C4BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4BEu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4BEu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4BEu, 6u, 4u, ((0x7E2440u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4BE STA
    hw.write(((0x7E2440u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80C4C2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4BEu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4BEu, 6u, 4u, ((0x7E2440u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4BE STA
    hw.write(((0x7E2440u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80C4C2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC4BEu,0x80C4BEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C4C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4C2u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4C2u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4C2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80C4C2 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80C4C2u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80C4C2u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4C2u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4C2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80C4C2 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80C4C2u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80C4C2u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC4C2u,0x80C4C2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_8292EF_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8292EFu: goto L_8292EF;
    case 0x8292F1u: goto L_8292F1;
    case 0x8292F3u: goto L_8292F3;
    case 0x8292F5u: goto L_8292F5;
    case 0x8292F8u: goto L_8292F8;
    case 0x8292FBu: goto L_8292FB;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8292EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92EFu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92EFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292EF SEP
    cpu.sep(0x20u);
    goto L_8292F1;
L_8292F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92F1u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92F1u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292F1 INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_8292F3;
L_8292F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92F3u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92F3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292F3 REP
    cpu.rep(0x20u);
    goto L_8292F5;
L_8292F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92F5u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92F5u, 6u, 3u, cpu.address("abs", 0x94CFu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8292F5 JSR -> $8294CF stack real
    { cpu.push16Value(hw,0x92F7u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x92F8u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x94CFu), 0x8292F5u); }
    goto L_8292F8;
L_8292F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92F8u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x92F8u,0x8292F8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92F8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92F8u, 6u, 3u, cpu.address("abs", 0xD399u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8292F8 JSR -> $82D399 stack real
    { cpu.push16Value(hw,0x92FAu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x92FBu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD399u), 0x8292F8u); }
    goto L_8292FB;
L_8292FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92FBu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x92FBu,0x8292FBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92FBu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92FBu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8292FB RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8292FBu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8292FBu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_829C82_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x829C82u: goto L_829C82;
    case 0x829C85u: goto L_829C85;
    case 0x829C87u: goto L_829C87;
    case 0x829C88u: goto L_829C88;
    case 0x829C89u: goto L_829C89;
    case 0x829C8Cu: goto L_829C8C;
    case 0x829C8Du: goto L_829C8D;
    case 0x829C8Fu: goto L_829C8F;
    case 0x829C92u: goto L_829C92;
    case 0x829C95u: goto L_829C95;
    case 0x829C97u: goto L_829C97;
    case 0x829C9Au: goto L_829C9A;
    case 0x829C9Bu: goto L_829C9B;
    case 0x829C9Du: goto L_829C9D;
    case 0x829C9Fu: goto L_829C9F;
    case 0x829CA2u: goto L_829CA2;
    case 0x829CA3u: goto L_829CA3;
    case 0x829CA6u: goto L_829CA6;
    case 0x829CA9u: goto L_829CA9;
    case 0x829CABu: goto L_829CAB;
    case 0x829CAEu: goto L_829CAE;
    case 0x829CAFu: goto L_829CAF;
    case 0x829CB2u: goto L_829CB2;
    case 0x829CB5u: goto L_829CB5;
    case 0x829CB7u: goto L_829CB7;
    case 0x829CBAu: goto L_829CBA;
    case 0x829CBDu: goto L_829CBD;
    case 0x829CC0u: goto L_829CC0;
    case 0x829CC3u: goto L_829CC3;
    case 0x829CC6u: goto L_829CC6;
    case 0x829CC9u: goto L_829CC9;
    case 0x829CCCu: goto L_829CCC;
    case 0x829CCEu: goto L_829CCE;
    case 0x829CD0u: goto L_829CD0;
    case 0x829CD3u: goto L_829CD3;
    case 0x829CD5u: goto L_829CD5;
    case 0x829CD8u: goto L_829CD8;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_829C82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C82u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C82u, 5u + 1u, 3u, cpu.address("absy", 0x040Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829C82 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x40Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829C85;
L_829C85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C85u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C85u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829C85 BNE -> $829CA3
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_829CA3; }
    goto L_829C87;
L_829C87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C87u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C87u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829C87 PHY
    cpu.push("PHY", hw);
    goto L_829C88;
L_829C88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C88u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C88u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C88u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829C88 TYA
    cpu.transfer("TYA");
    goto L_829C89;
L_829C89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C89u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C89u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829C89 EOR
    cpu.logicXor(0x100u);
    goto L_829C8C;
L_829C8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C8Cu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C8Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829C8C TAY
    cpu.transfer("TAY");
    goto L_829C8D;
L_829C8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C8Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C8Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829C8D STA
    hw.write(cpu.address("dp", 0x5Bu), cpu.a, cpu.m8?8:16);
    goto L_829C8F;
L_829C8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C8Fu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C8Fu, 5u + 1u, 3u, cpu.address("absy", 0x040Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829C8F LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x40Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829C92;
L_829C92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C92u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C92u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829C92 CMP
    cpu.compareA(0x2u);
    goto L_829C95;
L_829C95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C95u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C95u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829C95 BCC -> $829C9A
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_829C9A; }
    goto L_829C97;
L_829C97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C97u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C97u, 6u, 3u, cpu.address("abs", 0xA5D0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829C97 JSR -> $82A5D0 stack real
    { cpu.push16Value(hw,0x9C99u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9C9Au,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA5D0u), 0x829C97u); }
    goto L_829C9A;
L_829C9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C9Au))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9C9Au,0x829C9Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C9Au,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C9Au, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829C9A PLY
    cpu.pop("PLY", hw);
    goto L_829C9B;
L_829C9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C9Bu,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C9Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829C9B STY
    hw.write(cpu.address("dp", 0x5Bu), cpu.y, cpu.x8?8:16);
    goto L_829C9D;
L_829C9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C9Du,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C9Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829C9D LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_829C9F;
L_829C9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C9Fu,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C9Fu, 9u, 3u, cpu.address("absx", 0x040Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829C9F INC
    cpu.incMem(hw, cpu.address("absx", 0x40Au), cpu.m8?8:16);
    goto L_829CA2;
L_829CA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CA2u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CA2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829CA2 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x829CA2u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829CA2u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_829CA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CA3u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CA3u, 5u + 1u, 3u, cpu.address("absy", 0x02F2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829CA3 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x2F2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829CA6;
L_829CA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CA6u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CA6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829CA6 CMP
    cpu.compareA(0xFFFFu);
    goto L_829CA9;
L_829CA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CA9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CA9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829CA9 BEQ -> $829CAF
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_829CAF; }
    goto L_829CAB;
L_829CAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CABu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CABu, 6u, 3u, cpu.address("abs", 0x989Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829CAB JSR -> $82989B stack real
    { cpu.push16Value(hw,0x9CADu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9CAEu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x989Bu), 0x829CABu); }
    goto L_829CAE;
L_829CAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CAEu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CAEu,0x829CAEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CAEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CAEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829CAE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x829CAEu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829CAEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_829CAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CAFu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CAFu, 6u, 3u, cpu.address("abs", 0xA5A4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829CAF JSR -> $82A5A4 stack real
    { cpu.push16Value(hw,0x9CB1u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9CB2u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA5A4u), 0x829CAFu); }
    goto L_829CB2;
L_829CB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CB2u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CB2u,0x829CB2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB2u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB2u, 6u, 3u, cpu.address("abs", 0xA7C0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829CB2 JSR -> $82A7C0 stack real
    { cpu.push16Value(hw,0x9CB4u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9CB5u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA7C0u), 0x829CB2u); }
    goto L_829CB5;
L_829CB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CB5u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CB5u,0x829CB5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB5u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829CB5 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_829CB7;
L_829CB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829CB7 LDA
    cpu.setA(0xFFFFu, 16);
    goto L_829CBA;
L_829CBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CBAu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CBAu, 6u, 3u, cpu.address("absx", 0x0240u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829CBA STA
    hw.write(cpu.address("absx", 0x240u), cpu.a, cpu.m8?8:16);
    goto L_829CBD;
L_829CBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CBDu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CBDu, 6u, 3u, cpu.address("absx", 0x0246u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829CBD STA
    hw.write(cpu.address("absx", 0x246u), cpu.a, cpu.m8?8:16);
    goto L_829CC0;
L_829CC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC0u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC0u, 6u, 3u, cpu.address("absx", 0x024Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829CC0 STA
    hw.write(cpu.address("absx", 0x24Cu), cpu.a, cpu.m8?8:16);
    goto L_829CC3;
L_829CC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC3u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC3u, 6u, 3u, cpu.address("absx", 0x0252u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829CC3 STA
    hw.write(cpu.address("absx", 0x252u), cpu.a, cpu.m8?8:16);
    goto L_829CC6;
L_829CC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC6u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC6u, 9u, 3u, cpu.address("absx", 0x0200u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829CC6 INC
    cpu.incMem(hw, cpu.address("absx", 0x200u), cpu.m8?8:16);
    goto L_829CC9;
L_829CC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC9u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC9u, 6u, 3u, cpu.address("absx", 0x02C8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829CC9 STZ
    hw.write(cpu.address("absx", 0x2C8u), 0, cpu.m8?8:16);
    goto L_829CCC;
L_829CCC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CCCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCCu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829CCC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829CCE;
L_829CCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CCEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829CCE BNE -> $829CD5
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_829CD5; }
    goto L_829CD0;
L_829CD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CD0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD0u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD0u, 5u, 3u, cpu.address("abs", 0x0193u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829CD0 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x193u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829CD3;
L_829CD3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CD3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829CD3 BEQ -> $829CD8
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_829CD8; }
    goto L_829CD5;
L_829CD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD5u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD5u, 5u, 3u, cpu.address("abs", 0x099Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829CD5 STZ
    hw.write(cpu.address("abs", 0x99Au), 0, cpu.m8?8:16);
    goto L_829CD8;
L_829CD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CD8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD8u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829CD8 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x829CD8u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829CD8u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_829DB6_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x829DB6u: goto L_829DB6;
    case 0x829DB9u: goto L_829DB9;
    case 0x829DBCu: goto L_829DBC;
    case 0x829DBEu: goto L_829DBE;
    case 0x829DC0u: goto L_829DC0;
    case 0x829DC3u: goto L_829DC3;
    case 0x829DC6u: goto L_829DC6;
    case 0x829DC8u: goto L_829DC8;
    case 0x829DCAu: goto L_829DCA;
    case 0x829DCCu: goto L_829DCC;
    case 0x829DCEu: goto L_829DCE;
    case 0x829DD1u: goto L_829DD1;
    case 0x829DD3u: goto L_829DD3;
    case 0x829DD5u: goto L_829DD5;
    case 0x829DD7u: goto L_829DD7;
    case 0x829DDAu: goto L_829DDA;
    case 0x829DDCu: goto L_829DDC;
    case 0x829DDEu: goto L_829DDE;
    case 0x829DE0u: goto L_829DE0;
    case 0x829DE3u: goto L_829DE3;
    case 0x829DE5u: goto L_829DE5;
    case 0x829DE8u: goto L_829DE8;
    case 0x829DEBu: goto L_829DEB;
    case 0x829DEDu: goto L_829DED;
    case 0x829DF0u: goto L_829DF0;
    case 0x829DF3u: goto L_829DF3;
    case 0x829DF6u: goto L_829DF6;
    case 0x829DFAu: goto L_829DFA;
    case 0x829DFDu: goto L_829DFD;
    case 0x829E00u: goto L_829E00;
    case 0x829E02u: goto L_829E02;
    case 0x829E05u: goto L_829E05;
    case 0x829E06u: goto L_829E06;
    case 0x829E09u: goto L_829E09;
    case 0x829E0Bu: goto L_829E0B;
    case 0x829E0Eu: goto L_829E0E;
    case 0x829E0Fu: goto L_829E0F;
    case 0x829E12u: goto L_829E12;
    case 0x829E14u: goto L_829E14;
    case 0x829E16u: goto L_829E16;
    case 0x829E19u: goto L_829E19;
    case 0x829E1Cu: goto L_829E1C;
    case 0x829E1Fu: goto L_829E1F;
    case 0x829E20u: goto L_829E20;
    case 0x829E22u: goto L_829E22;
    case 0x829E25u: goto L_829E25;
    case 0x829E28u: goto L_829E28;
    case 0x829E2Bu: goto L_829E2B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_829DB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DB6u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DB6u, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829DB6 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829DB9;
L_829DB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DB9u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DB9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829DB9 CMP
    cpu.compareA(0x2u);
    goto L_829DBC;
L_829DBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DBCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DBCu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DBCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829DBC BCC -> $829DDE
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_829DDE; }
    goto L_829DBE;
L_829DBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DBEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DBEu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DBEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829DBE LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_829DC0;
L_829DC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC0u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC0u, 5u + 1u, 3u, cpu.address("absx", 0x0416u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829DC0 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x416u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829DC3;
L_829DC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC3u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829DC3 CMP
    cpu.compareA(0x2u);
    goto L_829DC6;
L_829DC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC6u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829DC6 BCS -> $829E06
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_829E06; }
    goto L_829DC8;
L_829DC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC8u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829DC8 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_829DCA;
L_829DCA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DCAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DCAu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DCAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829DCA BNE -> $829DD5
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_829DD5; }
    goto L_829DCC;
L_829DCC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DCCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DCCu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DCCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829DCC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829DCE;
L_829DCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DCEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DCEu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DCEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829DCE BIT
    cpu.bit(0x1u, true);
    goto L_829DD1;
L_829DD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DD1u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DD1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829DD1 BEQ -> $829DED
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_829DED; }
    goto L_829DD3;
L_829DD3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DD3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DD3u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DD3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829DD3 BRA -> $829E00
    goto L_829E00;
L_829DD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DD5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DD5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829DD5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829DD7;
L_829DD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DD7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DD7u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DD7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829DD7 BIT
    cpu.bit(0x1u, true);
    goto L_829DDA;
L_829DDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DDAu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DDAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829DDA BNE -> $829DED
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_829DED; }
    goto L_829DDC;
L_829DDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DDCu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DDCu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829DDC BRA -> $829E00
    goto L_829E00;
L_829DDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DDEu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DDEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829DDE LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_829DE0;
L_829DE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE0u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE0u, 5u + 1u, 3u, cpu.address("absx", 0x0416u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829DE0 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x416u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829DE3;
L_829DE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829DE3 BEQ -> $829E00
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_829E00; }
    goto L_829DE5;
L_829DE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE5u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE5u, 5u + 1u, 3u, cpu.address("absx", 0x0416u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829DE5 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x416u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829DE8;
L_829DE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE8u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829DE8 CMP
    cpu.compareA(0x2u);
    goto L_829DEB;
L_829DEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DEBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DEBu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DEBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829DEB BCS -> $829E06
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_829E06; }
    goto L_829DED;
L_829DED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DEDu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DEDu, 6u, 3u, cpu.address("abs", 0xA098u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829DED JSR -> $82A098 stack real
    { cpu.push16Value(hw,0x9DEFu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9DF0u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA098u), 0x829DEDu); }
    goto L_829DF0;
L_829DF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DF0u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9DF0u,0x829DF0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF0u, 6u, 3u, cpu.address("abs", 0xA070u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829DF0 JSR -> $82A070 stack real
    { cpu.push16Value(hw,0x9DF2u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9DF3u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA070u), 0x829DF0u); }
    goto L_829DF3;
L_829DF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DF3u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9DF3u,0x829DF3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829DF3 LDA
    cpu.setA(0x2u, 16);
    goto L_829DF6;
L_829DF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF6u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF6u, 8u, 4u, 0x80A6FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829DF6 JSL -> $80A6FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9DF9u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9DFAu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6FBu, 0x829DF6u); }
    goto L_829DFA;
L_829DFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DFAu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9DFAu,0x829DFAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DFAu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DFAu, 6u, 3u, cpu.address("abs", 0x97A3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829DFA JSR -> $8297A3 stack real
    { cpu.push16Value(hw,0x9DFCu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9DFDu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x97A3u), 0x829DFAu); }
    goto L_829DFD;
L_829DFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DFDu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9DFDu,0x829DFDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DFDu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DFDu, 6u, 3u, cpu.address("abs", 0xB284u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829DFD JSR -> $82B284 stack real
    { cpu.push16Value(hw,0x9DFFu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9E00u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB284u), 0x829DFDu); }
    goto L_829E00;
L_829E00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E00u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E00u,0x829E00u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E00u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E00u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829E00 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_829E02;
L_829E02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E02u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E02u, 9u, 3u, cpu.address("absx", 0x0416u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829E02 INC
    cpu.incMem(hw, cpu.address("absx", 0x416u), cpu.m8?8:16);
    goto L_829E05;
L_829E05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E05u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E05u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829E05 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x829E05u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829E05u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_829E06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E06u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E06u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829E06 CMP
    cpu.compareA(0x6u);
    goto L_829E09;
L_829E09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E09u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E09u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829E09 BCS -> $829E0F
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_829E0F; }
    goto L_829E0B;
L_829E0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E0Bu,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E0Bu, 9u, 3u, cpu.address("absx", 0x0416u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829E0B INC
    cpu.incMem(hw, cpu.address("absx", 0x416u), cpu.m8?8:16);
    goto L_829E0E;
L_829E0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E0Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E0Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829E0E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x829E0Eu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829E0Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_829E0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E0Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E0Fu, 6u, 3u, cpu.address("abs", 0x9844u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829E0F JSR -> $829844 stack real
    { cpu.push16Value(hw,0x9E11u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9E12u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9844u), 0x829E0Fu); }
    goto L_829E12;
L_829E12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E12u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E12u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E12u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829E12 BCS -> $829E20
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_829E20; }
    goto L_829E14;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E12u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E12u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829E12 BCS -> $829E20
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_829E20; }
    goto L_829E14;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E12u,0x829E12u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829E14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E14u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E14u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E14u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829E14 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_829E16;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E14u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E14u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829E14 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_829E16;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E14u,0x829E14u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829E16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E16u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E16u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E16u, 9u, 3u, cpu.address("absx", 0x0200u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829E16 DEC
    cpu.decMem(hw, cpu.address("absx", 0x200u), cpu.m8?8:16);
    goto L_829E19;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E16u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E16u, 9u, 3u, cpu.address("absx", 0x0200u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829E16 DEC
    cpu.decMem(hw, cpu.address("absx", 0x200u), cpu.m8?8:16);
    goto L_829E19;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E16u,0x829E16u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829E19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E19u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E19u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E19u, 9u, 3u, cpu.address("absx", 0x0200u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829E19 DEC
    cpu.decMem(hw, cpu.address("absx", 0x200u), cpu.m8?8:16);
    goto L_829E1C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E19u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E19u, 9u, 3u, cpu.address("absx", 0x0200u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829E19 DEC
    cpu.decMem(hw, cpu.address("absx", 0x200u), cpu.m8?8:16);
    goto L_829E1C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E19u,0x829E19u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829E1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E1Cu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Cu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Cu, 6u, 3u, cpu.address("absx", 0x0416u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829E1C STZ
    hw.write(cpu.address("absx", 0x416u), 0, cpu.m8?8:16);
    goto L_829E1F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Cu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Cu, 6u, 3u, cpu.address("absx", 0x0416u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829E1C STZ
    hw.write(cpu.address("absx", 0x416u), 0, cpu.m8?8:16);
    goto L_829E1F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E1Cu,0x829E1Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829E1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E1Fu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829E1F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x829E1Fu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829E1Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829E1F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x829E1Fu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829E1Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E1Fu,0x829E1Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829E20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E20u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E20u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E20u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829E20 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_829E22;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E20u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E20u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829E20 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_829E22;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E20u,0x829E20u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829E22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E22u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E22u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E22u, 9u, 3u, cpu.address("absx", 0x0200u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829E22 INC
    cpu.incMem(hw, cpu.address("absx", 0x200u), cpu.m8?8:16);
    goto L_829E25;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E22u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E22u, 9u, 3u, cpu.address("absx", 0x0200u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829E22 INC
    cpu.incMem(hw, cpu.address("absx", 0x200u), cpu.m8?8:16);
    goto L_829E25;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E22u,0x829E22u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829E25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E25u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E25u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E25u, 6u, 3u, cpu.address("absx", 0x02CCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829E25 STZ
    hw.write(cpu.address("absx", 0x2CCu), 0, cpu.m8?8:16);
    goto L_829E28;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E25u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E25u, 6u, 3u, cpu.address("absx", 0x02CCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829E25 STZ
    hw.write(cpu.address("absx", 0x2CCu), 0, cpu.m8?8:16);
    goto L_829E28;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E25u,0x829E25u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829E28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E28u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E28u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E28u, 6u, 3u, cpu.address("absx", 0x0416u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829E28 STZ
    hw.write(cpu.address("absx", 0x416u), 0, cpu.m8?8:16);
    goto L_829E2B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E28u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E28u, 6u, 3u, cpu.address("absx", 0x0416u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829E28 STZ
    hw.write(cpu.address("absx", 0x416u), 0, cpu.m8?8:16);
    goto L_829E2B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E28u,0x829E28u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829E2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E2Bu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E2Bu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E2Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829E2B RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x829E2Bu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829E2Bu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E2Bu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E2Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829E2B RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x829E2Bu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829E2Bu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E2Bu,0x829E2Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_82A070_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82A070u: goto L_82A070;
    case 0x82A072u: goto L_82A072;
    case 0x82A074u: goto L_82A074;
    case 0x82A076u: goto L_82A076;
    case 0x82A079u: goto L_82A079;
    case 0x82A07Bu: goto L_82A07B;
    case 0x82A07Du: goto L_82A07D;
    case 0x82A07Fu: goto L_82A07F;
    case 0x82A081u: goto L_82A081;
    case 0x82A082u: goto L_82A082;
    case 0x82A085u: goto L_82A085;
    case 0x82A087u: goto L_82A087;
    case 0x82A089u: goto L_82A089;
    case 0x82A08Bu: goto L_82A08B;
    case 0x82A08Eu: goto L_82A08E;
    case 0x82A08Fu: goto L_82A08F;
    case 0x82A090u: goto L_82A090;
    case 0x82A091u: goto L_82A091;
    case 0x82A092u: goto L_82A092;
    case 0x82A093u: goto L_82A093;
    case 0x82A094u: goto L_82A094;
    case 0x82A096u: goto L_82A096;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82A070:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA070u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA070u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA070u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A070 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A072;
L_82A072:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA072u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA072u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA072u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A072 STZ
    hw.write(cpu.address("dp", 0xAu), 0, cpu.m8?8:16);
    goto L_82A074;
L_82A074:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA074u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA074u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA074u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A074 SEP
    cpu.sep(0x20u);
    goto L_82A076;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA074u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA074u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A074 SEP
    cpu.sep(0x20u);
    goto L_82A076;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA074u,0x82A074u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82A076:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA076u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA076u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA076u, 4u + 1u, 3u, cpu.address("absx", 0x0208u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A076 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x208u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A079;
L_82A079:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA079u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA079u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA079u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A079 BPL -> $82A082
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82A082; }
    goto L_82A07B;
L_82A07B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA07Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA07Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA07Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A07B CMP
    cpu.compareA(0x80u);
    goto L_82A07D;
L_82A07D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA07Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA07Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA07Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A07D BNE -> $82A08E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A08E; }
    goto L_82A07F;
L_82A07F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA07Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA07Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA07Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A07F REP
    cpu.rep(0x20u);
    goto L_82A081;
L_82A081:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA081u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA081u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA081u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A081 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82A081u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82A081u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82A082:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA082u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA082u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA082u, 6u, 3u, cpu.address("abs", 0xA0E6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A082 JSR -> $82A0E6 stack real
    { cpu.push16Value(hw,0xA084u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA085u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA0E6u), 0x82A082u); }
    goto L_82A085;
L_82A085:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA085u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA085u,0x82A085u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA085u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA085u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A085 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xCu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A087;
L_82A087:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA087u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA087u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA087u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 3u, 0u);
    // $82A087 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A089;
L_82A089:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA089u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA089u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA089u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A089 BEQ -> $82A08E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A08E; }
    goto L_82A08B;
L_82A08B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA08Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA08Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA08Bu, 6u, 3u, cpu.address("abs", 0xA22Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A08B JSR -> $82A22B stack real
    { cpu.push16Value(hw,0xA08Du); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA08Eu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA22Bu), 0x82A08Bu); }
    goto L_82A08E;
L_82A08E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA08Eu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA08Eu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA08Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A08E INX
    cpu.inc('X');
    goto L_82A08F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA08Eu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA08Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A08E INX
    cpu.inc('X');
    goto L_82A08F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA08Eu,0x82A08Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82A08F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA08Fu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA08Fu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA08Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A08F INX
    cpu.inc('X');
    goto L_82A090;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA08Fu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA08Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A08F INX
    cpu.inc('X');
    goto L_82A090;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA08Fu,0x82A08Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82A090:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA090u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA090u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA090u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A090 INX
    cpu.inc('X');
    goto L_82A091;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA090u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA090u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A090 INX
    cpu.inc('X');
    goto L_82A091;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA090u,0x82A090u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82A091:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA091u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA091u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA091u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A091 INX
    cpu.inc('X');
    goto L_82A092;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA091u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA091u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A091 INX
    cpu.inc('X');
    goto L_82A092;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA091u,0x82A091u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82A092:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA092u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA092u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA092u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A092 INX
    cpu.inc('X');
    goto L_82A093;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA092u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA092u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A092 INX
    cpu.inc('X');
    goto L_82A093;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA092u,0x82A092u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82A093:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA093u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA093u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA093u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A093 INX
    cpu.inc('X');
    goto L_82A094;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA093u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA093u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A093 INX
    cpu.inc('X');
    goto L_82A094;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA093u,0x82A093u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82A094:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA094u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA094u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA094u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A094 INC
    cpu.incMem(hw, cpu.address("dp", 0xAu), cpu.m8?8:16);
    goto L_82A096;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA094u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA094u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A094 INC
    cpu.incMem(hw, cpu.address("dp", 0xAu), cpu.m8?8:16);
    goto L_82A096;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA094u,0x82A094u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82A096:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA096u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA096u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA096u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A096 BRA -> $82A074
    goto L_82A074;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA096u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA096u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A096 BRA -> $82A074
    goto L_82A074;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA096u,0x82A096u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_82A1CF_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82A1CFu: goto L_82A1CF;
    case 0x82A1D1u: goto L_82A1D1;
    case 0x82A1D4u: goto L_82A1D4;
    case 0x82A1D6u: goto L_82A1D6;
    case 0x82A1D8u: goto L_82A1D8;
    case 0x82A1DAu: goto L_82A1DA;
    case 0x82A1DCu: goto L_82A1DC;
    case 0x82A1DDu: goto L_82A1DD;
    case 0x82A1DFu: goto L_82A1DF;
    case 0x82A1E0u: goto L_82A1E0;
    case 0x82A1E3u: goto L_82A1E3;
    case 0x82A1E4u: goto L_82A1E4;
    case 0x82A1E6u: goto L_82A1E6;
    case 0x82A1E8u: goto L_82A1E8;
    case 0x82A1EBu: goto L_82A1EB;
    case 0x82A1EEu: goto L_82A1EE;
    case 0x82A1F0u: goto L_82A1F0;
    case 0x82A1F3u: goto L_82A1F3;
    case 0x82A1F4u: goto L_82A1F4;
    case 0x82A1F5u: goto L_82A1F5;
    case 0x82A1F6u: goto L_82A1F6;
    case 0x82A1F7u: goto L_82A1F7;
    case 0x82A1F8u: goto L_82A1F8;
    case 0x82A1F9u: goto L_82A1F9;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82A1CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1CFu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1CFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1CF SEP
    cpu.sep(0x20u);
    goto L_82A1D1;
L_82A1D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1D1u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D1u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D1u, 4u + 1u, 3u, cpu.address("absy", 0x0224u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1D1 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x224u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A1D4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D1u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D1u, 4u + 1u, 3u, cpu.address("absy", 0x0224u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1D1 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x224u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A1D4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA1D1u,0x82A1D1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82A1D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1D4u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D4u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1D4 BPL -> $82A1DD
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82A1DD; }
    goto L_82A1D6;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D4u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1D4 BPL -> $82A1DD
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82A1DD; }
    goto L_82A1D6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA1D4u,0x82A1D4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82A1D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1D6u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D6u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1D6 CMP
    cpu.compareA(0x80u);
    goto L_82A1D8;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D6u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1D6 CMP
    cpu.compareA(0x80u);
    goto L_82A1D8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA1D6u,0x82A1D6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82A1D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D8u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1D8 BNE -> $82A1F3
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A1F3; }
    goto L_82A1DA;
L_82A1DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1DAu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1DAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1DA REP
    cpu.rep(0x20u);
    goto L_82A1DC;
L_82A1DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1DCu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1DCu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A1DC RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82A1DCu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82A1DCu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82A1DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1DDu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1DDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1DDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1DD LDA
    cpu.setA(0x0u, 8);
    goto L_82A1DF;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1DDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1DDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1DD LDA
    cpu.setA(0x0u, 8);
    goto L_82A1DF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA1DDu,0x82A1DDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82A1DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1DFu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1DFu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1DFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1DF SEC
    cpu.setFlag('C', true);
    goto L_82A1E0;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1DFu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1DFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1DF SEC
    cpu.setFlag('C', true);
    goto L_82A1E0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA1DFu,0x82A1DFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82A1E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1E0u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1E0u, 4u + 1u, 3u, cpu.address("absy", 0x0227u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1E0 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x227u), cpu.m8?8:16));
    goto L_82A1E3;
L_82A1E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1E3u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1E3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1E3 SEC
    cpu.setFlag('C', true);
    goto L_82A1E4;
L_82A1E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1E4u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1E4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1E4 SBC
    cpu.sbc(0x8u);
    goto L_82A1E6;
L_82A1E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1E6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1E6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1E6 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82A1E8;
L_82A1E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1E8u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1E8u, 4u + 1u, 3u, cpu.address("absy", 0x0226u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1E8 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x226u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A1EB;
L_82A1EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1EBu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1EBu, 5u, 3u, cpu.address("absy", 0x0227u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1EB STA
    hw.write(cpu.address("absy", 0x227u), cpu.a, cpu.m8?8:16);
    goto L_82A1EE;
L_82A1EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1EEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1EEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1EE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A1F0;
L_82A1F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1F0u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1F0u, 5u, 3u, cpu.address("absy", 0x0226u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1F0 STA
    hw.write(cpu.address("absy", 0x226u), cpu.a, cpu.m8?8:16);
    goto L_82A1F3;
L_82A1F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1F3u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1F3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1F3 INY
    cpu.inc('Y');
    goto L_82A1F4;
L_82A1F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1F4u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1F4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1F4 INY
    cpu.inc('Y');
    goto L_82A1F5;
L_82A1F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1F5u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1F5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1F5 INY
    cpu.inc('Y');
    goto L_82A1F6;
L_82A1F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1F6u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1F6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1F6 INY
    cpu.inc('Y');
    goto L_82A1F7;
L_82A1F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1F7u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1F7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1F7 INY
    cpu.inc('Y');
    goto L_82A1F8;
L_82A1F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1F8u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1F8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1F8 INY
    cpu.inc('Y');
    goto L_82A1F9;
L_82A1F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1F9u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1F9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1F9 BRA -> $82A1D1
    goto L_82A1D1;
}

void sub_82A1CF_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82A1CFu: goto L_82A1CF;
    case 0x82A1D1u: goto L_82A1D1;
    case 0x82A1D4u: goto L_82A1D4;
    case 0x82A1D6u: goto L_82A1D6;
    case 0x82A1D8u: goto L_82A1D8;
    case 0x82A1DAu: goto L_82A1DA;
    case 0x82A1DCu: goto L_82A1DC;
    case 0x82A1DDu: goto L_82A1DD;
    case 0x82A1DFu: goto L_82A1DF;
    case 0x82A1E0u: goto L_82A1E0;
    case 0x82A1E3u: goto L_82A1E3;
    case 0x82A1E4u: goto L_82A1E4;
    case 0x82A1E6u: goto L_82A1E6;
    case 0x82A1E8u: goto L_82A1E8;
    case 0x82A1EBu: goto L_82A1EB;
    case 0x82A1EEu: goto L_82A1EE;
    case 0x82A1F0u: goto L_82A1F0;
    case 0x82A1F3u: goto L_82A1F3;
    case 0x82A1F4u: goto L_82A1F4;
    case 0x82A1F5u: goto L_82A1F5;
    case 0x82A1F6u: goto L_82A1F6;
    case 0x82A1F7u: goto L_82A1F7;
    case 0x82A1F8u: goto L_82A1F8;
    case 0x82A1F9u: goto L_82A1F9;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82A1CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1CFu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1CFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1CF SEP
    cpu.sep(0x20u);
    goto L_82A1D1;
L_82A1D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D1u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D1u, 4u + 1u, 3u, cpu.address("absy", 0x0224u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1D1 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x224u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A1D4;
L_82A1D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D4u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1D4 BPL -> $82A1DD
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82A1DD; }
    goto L_82A1D6;
L_82A1D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D6u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1D6 CMP
    cpu.compareA(0x80u);
    goto L_82A1D8;
L_82A1D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D8u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1D8 BNE -> $82A1F3
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A1F3; }
    goto L_82A1DA;
L_82A1DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1DAu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1DAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1DA REP
    cpu.rep(0x20u);
    goto L_82A1DC;
L_82A1DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1DCu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1DCu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A1DC RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82A1DCu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82A1DCu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82A1DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1DDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1DDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1DD LDA
    cpu.setA(0x0u, 8);
    goto L_82A1DF;
L_82A1DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1DFu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1DFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1DF SEC
    cpu.setFlag('C', true);
    goto L_82A1E0;
L_82A1E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1E0u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1E0u, 4u + 1u, 3u, cpu.address("absy", 0x0227u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1E0 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x227u), cpu.m8?8:16));
    goto L_82A1E3;
L_82A1E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1E3u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1E3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1E3 SEC
    cpu.setFlag('C', true);
    goto L_82A1E4;
L_82A1E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1E4u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1E4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1E4 SBC
    cpu.sbc(0x8u);
    goto L_82A1E6;
L_82A1E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1E6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1E6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1E6 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82A1E8;
L_82A1E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1E8u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1E8u, 4u + 1u, 3u, cpu.address("absy", 0x0226u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1E8 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x226u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A1EB;
L_82A1EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1EBu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1EBu, 5u, 3u, cpu.address("absy", 0x0227u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1EB STA
    hw.write(cpu.address("absy", 0x227u), cpu.a, cpu.m8?8:16);
    goto L_82A1EE;
L_82A1EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1EEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1EEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1EE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A1F0;
L_82A1F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1F0u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1F0u, 5u, 3u, cpu.address("absy", 0x0226u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1F0 STA
    hw.write(cpu.address("absy", 0x226u), cpu.a, cpu.m8?8:16);
    goto L_82A1F3;
L_82A1F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1F3u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1F3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1F3 INY
    cpu.inc('Y');
    goto L_82A1F4;
L_82A1F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1F4u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1F4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1F4 INY
    cpu.inc('Y');
    goto L_82A1F5;
L_82A1F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1F5u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1F5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1F5 INY
    cpu.inc('Y');
    goto L_82A1F6;
L_82A1F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1F6u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1F6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1F6 INY
    cpu.inc('Y');
    goto L_82A1F7;
L_82A1F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1F7u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1F7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1F7 INY
    cpu.inc('Y');
    goto L_82A1F8;
L_82A1F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1F8u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1F8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1F8 INY
    cpu.inc('Y');
    goto L_82A1F9;
L_82A1F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1F9u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1F9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1F9 BRA -> $82A1D1
    goto L_82A1D1;
}

void sub_82AB2E_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82AB2Eu: goto L_82AB2E;
    case 0x82AB30u: goto L_82AB30;
    case 0x82AB33u: goto L_82AB33;
    case 0x82AB36u: goto L_82AB36;
    case 0x82AB38u: goto L_82AB38;
    case 0x82AB39u: goto L_82AB39;
    case 0x82AB3Cu: goto L_82AB3C;
    case 0x82AB3Eu: goto L_82AB3E;
    case 0x82AB3Fu: goto L_82AB3F;
    case 0x82AB42u: goto L_82AB42;
    case 0x82AB45u: goto L_82AB45;
    case 0x82AB47u: goto L_82AB47;
    case 0x82AB49u: goto L_82AB49;
    case 0x82AB4Bu: goto L_82AB4B;
    case 0x82AB4Cu: goto L_82AB4C;
    case 0x82AB4Fu: goto L_82AB4F;
    case 0x82AB50u: goto L_82AB50;
    case 0x82AB52u: goto L_82AB52;
    case 0x82AB53u: goto L_82AB53;
    case 0x82AB56u: goto L_82AB56;
    case 0x82AB59u: goto L_82AB59;
    case 0x82AB5Bu: goto L_82AB5B;
    case 0x82AB5Cu: goto L_82AB5C;
    case 0x82AB5Du: goto L_82AB5D;
    case 0x82AB5Eu: goto L_82AB5E;
    case 0x82AB60u: goto L_82AB60;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82AB2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB2Eu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB2Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x3Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AB2E LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x3Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AB30;
L_82AB30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB30u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB30u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AB30 AND
    cpu.logicAnd(0xFFu);
    goto L_82AB33;
L_82AB33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB33u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB33u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AB33 CMP
    cpu.compareA(0x6u);
    goto L_82AB36;
L_82AB36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB36u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB36u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AB36 BCS -> $82AB3E
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_82AB3E; }
    goto L_82AB38;
L_82AB38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB38u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB38u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AB38 CLC
    cpu.setFlag('C', false);
    goto L_82AB39;
L_82AB39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB39u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB39u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AB39 ADC
    cpu.adc(0x355Au);
    goto L_82AB3C;
L_82AB3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB3Cu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB3Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AB3C BRA -> $82AB42
    goto L_82AB42;
L_82AB3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB3Eu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB3Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AB3E CLC
    cpu.setFlag('C', false);
    goto L_82AB3F;
L_82AB3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB3Fu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB3Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AB3F ADC
    cpu.adc(0x356Au);
    goto L_82AB42;
L_82AB42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB42u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB42u, 6u, 3u, cpu.address("absy", 0x2800u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AB42 STA
    hw.write(cpu.address("absy", 0x2800u), cpu.a, cpu.m8?8:16);
    goto L_82AB45;
L_82AB45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB45u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB45u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AB45 STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_82AB47;
L_82AB47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB47u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB47u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AB47 STY
    hw.write(cpu.address("dp", 0x63u), cpu.y, cpu.x8?8:16);
    goto L_82AB49;
L_82AB49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB49u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB49u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AB49 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x63u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AB4B;
L_82AB4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB4Bu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB4Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AB4B CLC
    cpu.setFlag('C', false);
    goto L_82AB4C;
L_82AB4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB4Cu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB4Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AB4C ADC
    cpu.adc(0x40u);
    goto L_82AB4F;
L_82AB4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB4Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB4Fu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB4Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AB4F TAY
    cpu.transfer("TAY");
    goto L_82AB50;
L_82AB50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB50u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB50u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AB50 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AB52;
L_82AB52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB52u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB52u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AB52 CLC
    cpu.setFlag('C', false);
    goto L_82AB53;
L_82AB53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB53u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB53u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB53u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AB53 ADC
    cpu.adc(0x10u);
    goto L_82AB56;
L_82AB56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB56u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB56u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB56u, 6u, 3u, cpu.address("absy", 0x2800u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AB56 STA
    hw.write(cpu.address("absy", 0x2800u), cpu.a, cpu.m8?8:16);
    goto L_82AB59;
L_82AB59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB59u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB59u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AB59 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82AB5B;
L_82AB5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB5Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB5Bu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB5Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AB5B INY
    cpu.inc('Y');
    goto L_82AB5C;
L_82AB5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB5Cu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB5Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AB5C INY
    cpu.inc('Y');
    goto L_82AB5D;
L_82AB5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB5Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB5Du,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB5Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AB5D DEX
    cpu.decReg('X');
    goto L_82AB5E;
L_82AB5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB5Eu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB5Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AB5E BPL -> $82AB2E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82AB2E; }
    goto L_82AB60;
L_82AB60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB60u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB60u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AB60 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82AB60u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82AB60u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82B220_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B220u: goto L_82B220;
    case 0x82B222u: goto L_82B222;
    case 0x82B224u: goto L_82B224;
    case 0x82B226u: goto L_82B226;
    case 0x82B228u: goto L_82B228;
    case 0x82B22Au: goto L_82B22A;
    case 0x82B22Cu: goto L_82B22C;
    case 0x82B22Eu: goto L_82B22E;
    case 0x82B231u: goto L_82B231;
    case 0x82B234u: goto L_82B234;
    case 0x82B237u: goto L_82B237;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B220:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB220u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB220u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB220u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B220 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B222;
L_82B222:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB222u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB222u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB222u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B222 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x9Eu), cpu.m8?8:16));
    goto L_82B224;
L_82B224:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB224u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB224u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB224u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B224 BEQ -> $82B22E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B22E; }
    goto L_82B226;
L_82B226:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB226u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB226u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB226u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B226 SEP
    cpu.sep(0x20u);
    goto L_82B228;
L_82B228:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB228u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB228u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB228u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B228 LDA
    cpu.setA(0xBu, 8);
    goto L_82B22A;
L_82B22A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB22Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB22Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB22Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B22A STA
    hw.write(cpu.address("dp", 0x49u), cpu.a, cpu.m8?8:16);
    goto L_82B22C;
L_82B22C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB22Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB22Cu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB22Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B22C REP
    cpu.rep(0x20u);
    goto L_82B22E;
L_82B22E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB22Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB22Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB22Eu, 6u, 3u, cpu.address("abs", 0xD5A3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B22E JSR -> $82D5A3 stack real
    { cpu.push16Value(hw,0xB230u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB231u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD5A3u), 0x82B22Eu); }
    goto L_82B231;
L_82B231:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB231u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB231u,0x82B231u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB231u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB231u, 6u, 3u, cpu.address("abs", 0xCA5Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B231 JSR -> $82CA5A stack real
    { cpu.push16Value(hw,0xB233u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB234u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCA5Au), 0x82B231u); }
    goto L_82B234;
L_82B234:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB234u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB234u,0x82B234u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB234u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB234u, 6u, 3u, cpu.address("abs", 0xD4F9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B234 JSR -> $82D4F9 stack real
    { cpu.push16Value(hw,0xB236u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB237u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD4F9u), 0x82B234u); }
    goto L_82B237;
L_82B237:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB237u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB237u,0x82B237u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB237u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB237u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B237 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B237u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B237u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82B2B8_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B2B8u: goto L_82B2B8;
    case 0x82B2BBu: goto L_82B2BB;
    case 0x82B2BEu: goto L_82B2BE;
    case 0x82B2C0u: goto L_82B2C0;
    case 0x82B2C2u: goto L_82B2C2;
    case 0x82B2C4u: goto L_82B2C4;
    case 0x82B2C7u: goto L_82B2C7;
    case 0x82B2CAu: goto L_82B2CA;
    case 0x82B2CCu: goto L_82B2CC;
    case 0x82B2CDu: goto L_82B2CD;
    case 0x82B2CEu: goto L_82B2CE;
    case 0x82B2CFu: goto L_82B2CF;
    case 0x82B2D0u: goto L_82B2D0;
    case 0x82B2D1u: goto L_82B2D1;
    case 0x82B2D2u: goto L_82B2D2;
    case 0x82B2D3u: goto L_82B2D3;
    case 0x82B2D4u: goto L_82B2D4;
    case 0x82B2D5u: goto L_82B2D5;
    case 0x82B2D8u: goto L_82B2D8;
    case 0x82B2DBu: goto L_82B2DB;
    case 0x82B2DDu: goto L_82B2DD;
    case 0x82B2E0u: goto L_82B2E0;
    case 0x82B2E3u: goto L_82B2E3;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B2B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2B8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2B8u, 6u, 3u, cpu.address("abs", 0xB409u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B2B8 JSR -> $82B409 stack real
    { cpu.push16Value(hw,0xB2BAu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB2BBu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB409u), 0x82B2B8u); }
    goto L_82B2BB;
L_82B2BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2BBu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2BBu,0x82B2BBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2BBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2BBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2BB LDA
    cpu.setA(0x3u, 16);
    goto L_82B2BE;
L_82B2BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2BEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2BEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2BE STA
    hw.write(cpu.address("dp", 0x61u), cpu.a, cpu.m8?8:16);
    goto L_82B2C0;
L_82B2C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C0u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2C0 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B2C2;
L_82B2C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C2u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2C2 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B2C4;
L_82B2C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C4u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C4u, 5u + 1u, 3u, cpu.address("absy", 0x0208u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2C4 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x208u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B2C7;
L_82B2C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C7u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2C7 AND
    cpu.logicAnd(0xFFu);
    goto L_82B2CA;
L_82B2CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CAu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2CA BEQ -> $82B2E0
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B2E0; }
    goto L_82B2CC;
L_82B2CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CCu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2CC INY
    cpu.inc('Y');
    goto L_82B2CD;
L_82B2CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CDu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2CD INY
    cpu.inc('Y');
    goto L_82B2CE;
L_82B2CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CEu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2CE INY
    cpu.inc('Y');
    goto L_82B2CF;
L_82B2CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CFu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2CF INY
    cpu.inc('Y');
    goto L_82B2D0;
L_82B2D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D0u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2D0 INY
    cpu.inc('Y');
    goto L_82B2D1;
L_82B2D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D1u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2D1 INY
    cpu.inc('Y');
    goto L_82B2D2;
L_82B2D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D2u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2D2 INX
    cpu.inc('X');
    goto L_82B2D3;
L_82B2D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D3u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2D3 INX
    cpu.inc('X');
    goto L_82B2D4;
L_82B2D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D4u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2D4 TXA
    cpu.transfer("TXA");
    goto L_82B2D5;
L_82B2D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D5u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2D5 AND
    cpu.logicAnd(0xFu);
    goto L_82B2D8;
L_82B2D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D8u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2D8 CMP
    cpu.compareA(0x8u);
    goto L_82B2DB;
L_82B2DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2DBu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2DBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2DB BCS -> $82B2E3
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_82B2E3; }
    goto L_82B2DD;
L_82B2DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2DDu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2DDu, 3u, 3u, cpu.address("abs", 0xB2C4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2DD JMP -> $82B2C4
    goto L_82B2C4;
L_82B2E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E0u, 6u, 3u, cpu.address("abs", 0xB42Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B2E0 JSR -> $82B42F stack real
    { cpu.push16Value(hw,0xB2E2u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB2E3u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB42Fu), 0x82B2E0u); }
    goto L_82B2E3;
L_82B2E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2E3u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2E3u,0x82B2E3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E3u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B2E3 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B2E3u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B2E3u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82C8CB_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82C8CBu: goto L_82C8CB;
    case 0x82C8CEu: goto L_82C8CE;
    case 0x82C8D1u: goto L_82C8D1;
    case 0x82C8D3u: goto L_82C8D3;
    case 0x82C8D6u: goto L_82C8D6;
    case 0x82C8D8u: goto L_82C8D8;
    case 0x82C8DBu: goto L_82C8DB;
    case 0x82C8DDu: goto L_82C8DD;
    case 0x82C8DEu: goto L_82C8DE;
    case 0x82C8E1u: goto L_82C8E1;
    case 0x82C8E4u: goto L_82C8E4;
    case 0x82C8E6u: goto L_82C8E6;
    case 0x82C8E9u: goto L_82C8E9;
    case 0x82C8ECu: goto L_82C8EC;
    case 0x82C8EFu: goto L_82C8EF;
    case 0x82C8F1u: goto L_82C8F1;
    case 0x82C8F4u: goto L_82C8F4;
    case 0x82C8F7u: goto L_82C8F7;
    case 0x82C8FAu: goto L_82C8FA;
    case 0x82C8FCu: goto L_82C8FC;
    case 0x82C8FFu: goto L_82C8FF;
    case 0x82C901u: goto L_82C901;
    case 0x82C904u: goto L_82C904;
    case 0x82C907u: goto L_82C907;
    case 0x82C90Au: goto L_82C90A;
    case 0x82C90Cu: goto L_82C90C;
    case 0x82C90Du: goto L_82C90D;
    case 0x82C90Eu: goto L_82C90E;
    case 0x82C90Fu: goto L_82C90F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82C8CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8CBu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8CBu, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C8CB LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C8CE;
L_82C8CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8CEu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8CEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C8CE CMP
    cpu.compareA(0x2u);
    goto L_82C8D1;
L_82C8D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8D1u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8D1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C8D1 BCC -> $82C90E
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_82C90E; }
    goto L_82C8D3;
L_82C8D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8D3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8D3u, 6u, 3u, cpu.address("abs", 0xC910u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C8D3 JSR -> $82C910 stack real
    { cpu.push16Value(hw,0xC8D5u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC8D6u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC910u), 0x82C8D3u); }
    goto L_82C8D6;
L_82C8D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8D6u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC8D6u,0x82C8D6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8D6u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8D6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C8D6 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82C8D8;
L_82C8D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8D8u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8D8u, 5u + 1u, 3u, cpu.address("absx", 0x0402u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C8D8 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x402u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C8DB;
L_82C8DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8DBu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8DBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C8DB BEQ -> $82C8E9
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C8E9; }
    goto L_82C8DD;
L_82C8DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8DDu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8DDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C8DD CLC
    cpu.setFlag('C', false);
    goto L_82C8DE;
L_82C8DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8DEu,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8DEu, 5u + 1u, 3u, cpu.address("absx", 0x0400u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C8DE ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x400u), cpu.m8?8:16));
    goto L_82C8E1;
L_82C8E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8E1u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8E1u, 6u, 3u, cpu.address("absx", 0x0400u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C8E1 STA
    hw.write(cpu.address("absx", 0x400u), cpu.a, cpu.m8?8:16);
    goto L_82C8E4;
L_82C8E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8E4u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8E4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C8E4 BPL -> $82C8E9
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82C8E9; }
    goto L_82C8E6;
L_82C8E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8E6u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8E6u, 6u, 3u, cpu.address("absx", 0x0400u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C8E6 STZ
    hw.write(cpu.address("absx", 0x400u), 0, cpu.m8?8:16);
    goto L_82C8E9;
L_82C8E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8E9u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8E9u, 6u, 3u, cpu.address("absx", 0x0402u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C8E9 STZ
    hw.write(cpu.address("absx", 0x402u), 0, cpu.m8?8:16);
    goto L_82C8EC;
L_82C8EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8ECu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8ECu, 6u, 3u, cpu.address("absx", 0x0404u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C8EC STZ
    hw.write(cpu.address("absx", 0x404u), 0, cpu.m8?8:16);
    goto L_82C8EF;
L_82C8EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8EFu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8EFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C8EF LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82C8F1;
L_82C8F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8F1u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8F1u, 5u + 1u, 3u, cpu.address("absx", 0x0418u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C8F1 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x418u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C8F4;
L_82C8F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8F4u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8F4u, 5u + 1u, 3u, cpu.address("absx", 0x041Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C8F4 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x41Au), cpu.m8?8:16));
    goto L_82C8F7;
L_82C8F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8F7u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8F7u, 5u + 1u, 3u, cpu.address("absx", 0x041Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C8F7 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x41Cu), cpu.m8?8:16));
    goto L_82C8FA;
L_82C8FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8FAu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8FAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C8FA BPL -> $82C90E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82C90E; }
    goto L_82C8FC;
L_82C8FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8FCu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8FCu, 6u, 3u, cpu.address("abs", 0xC981u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C8FC JSR -> $82C981 stack real
    { cpu.push16Value(hw,0xC8FEu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC8FFu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC981u), 0x82C8FCu); }
    goto L_82C8FF;
L_82C8FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8FFu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC8FFu,0x82C8FFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8FFu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8FFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C8FF LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82C901;
L_82C901:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC901u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC901u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC901u, 5u + 1u, 3u, cpu.address("absx", 0x0418u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C901 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x418u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C904;
L_82C904:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC904u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC904u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC904u, 5u + 1u, 3u, cpu.address("absx", 0x041Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C904 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x41Au), cpu.m8?8:16));
    goto L_82C907;
L_82C907:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC907u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC907u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC907u, 5u + 1u, 3u, cpu.address("absx", 0x041Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C907 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x41Cu), cpu.m8?8:16));
    goto L_82C90A;
L_82C90A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC90Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC90Au,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC90Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C90A BPL -> $82C90E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82C90E; }
    goto L_82C90C;
L_82C90C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC90Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC90Cu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC90Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C90C SEC
    cpu.setFlag('C', true);
    goto L_82C90D;
L_82C90D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC90Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC90Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC90Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C90D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C90Du);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C90Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82C90E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC90Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC90Eu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC90Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C90E CLC
    cpu.setFlag('C', false);
    goto L_82C90F;
L_82C90F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC90Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC90Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC90Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C90F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C90Fu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C90Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82C8CB_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82C8CBu: goto L_82C8CB;
    case 0x82C8CEu: goto L_82C8CE;
    case 0x82C8D1u: goto L_82C8D1;
    case 0x82C8D3u: goto L_82C8D3;
    case 0x82C8D6u: goto L_82C8D6;
    case 0x82C8D8u: goto L_82C8D8;
    case 0x82C8DBu: goto L_82C8DB;
    case 0x82C8DDu: goto L_82C8DD;
    case 0x82C8DEu: goto L_82C8DE;
    case 0x82C8E1u: goto L_82C8E1;
    case 0x82C8E4u: goto L_82C8E4;
    case 0x82C8E6u: goto L_82C8E6;
    case 0x82C8E9u: goto L_82C8E9;
    case 0x82C8ECu: goto L_82C8EC;
    case 0x82C8EFu: goto L_82C8EF;
    case 0x82C8F1u: goto L_82C8F1;
    case 0x82C8F4u: goto L_82C8F4;
    case 0x82C8F7u: goto L_82C8F7;
    case 0x82C8FAu: goto L_82C8FA;
    case 0x82C8FCu: goto L_82C8FC;
    case 0x82C8FFu: goto L_82C8FF;
    case 0x82C901u: goto L_82C901;
    case 0x82C904u: goto L_82C904;
    case 0x82C907u: goto L_82C907;
    case 0x82C90Au: goto L_82C90A;
    case 0x82C90Cu: goto L_82C90C;
    case 0x82C90Du: goto L_82C90D;
    case 0x82C90Eu: goto L_82C90E;
    case 0x82C90Fu: goto L_82C90F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82C8CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8CBu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8CBu, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C8CB LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C8CE;
L_82C8CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8CEu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8CEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C8CE CMP
    cpu.compareA(0x2u);
    goto L_82C8D1;
L_82C8D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8D1u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8D1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C8D1 BCC -> $82C90E
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_82C90E; }
    goto L_82C8D3;
L_82C8D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8D3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8D3u, 6u, 3u, cpu.address("abs", 0xC910u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C8D3 JSR -> $82C910 stack real
    { cpu.push16Value(hw,0xC8D5u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC8D6u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC910u), 0x82C8D3u); }
    goto L_82C8D6;
L_82C8D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8D6u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC8D6u,0x82C8D6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8D6u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8D6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C8D6 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82C8D8;
L_82C8D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8D8u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8D8u, 5u + 1u, 3u, cpu.address("absx", 0x0402u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C8D8 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x402u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C8DB;
L_82C8DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8DBu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8DBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C8DB BEQ -> $82C8E9
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C8E9; }
    goto L_82C8DD;
L_82C8DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8DDu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8DDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C8DD CLC
    cpu.setFlag('C', false);
    goto L_82C8DE;
L_82C8DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8DEu,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8DEu, 5u + 1u, 3u, cpu.address("absx", 0x0400u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C8DE ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x400u), cpu.m8?8:16));
    goto L_82C8E1;
L_82C8E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8E1u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8E1u, 6u, 3u, cpu.address("absx", 0x0400u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C8E1 STA
    hw.write(cpu.address("absx", 0x400u), cpu.a, cpu.m8?8:16);
    goto L_82C8E4;
L_82C8E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8E4u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8E4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C8E4 BPL -> $82C8E9
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82C8E9; }
    goto L_82C8E6;
L_82C8E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8E6u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8E6u, 6u, 3u, cpu.address("absx", 0x0400u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C8E6 STZ
    hw.write(cpu.address("absx", 0x400u), 0, cpu.m8?8:16);
    goto L_82C8E9;
L_82C8E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8E9u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8E9u, 6u, 3u, cpu.address("absx", 0x0402u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C8E9 STZ
    hw.write(cpu.address("absx", 0x402u), 0, cpu.m8?8:16);
    goto L_82C8EC;
L_82C8EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8ECu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8ECu, 6u, 3u, cpu.address("absx", 0x0404u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C8EC STZ
    hw.write(cpu.address("absx", 0x404u), 0, cpu.m8?8:16);
    goto L_82C8EF;
L_82C8EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8EFu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8EFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C8EF LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82C8F1;
L_82C8F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8F1u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8F1u, 5u + 1u, 3u, cpu.address("absx", 0x0418u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C8F1 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x418u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C8F4;
L_82C8F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8F4u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8F4u, 5u + 1u, 3u, cpu.address("absx", 0x041Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C8F4 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x41Au), cpu.m8?8:16));
    goto L_82C8F7;
L_82C8F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8F7u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8F7u, 5u + 1u, 3u, cpu.address("absx", 0x041Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C8F7 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x41Cu), cpu.m8?8:16));
    goto L_82C8FA;
L_82C8FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8FAu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8FAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C8FA BPL -> $82C90E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82C90E; }
    goto L_82C8FC;
L_82C8FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8FCu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8FCu, 6u, 3u, cpu.address("abs", 0xC981u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C8FC JSR -> $82C981 stack real
    { cpu.push16Value(hw,0xC8FEu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC8FFu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC981u), 0x82C8FCu); }
    goto L_82C8FF;
L_82C8FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8FFu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC8FFu,0x82C8FFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8FFu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8FFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C8FF LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82C901;
L_82C901:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC901u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC901u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC901u, 5u + 1u, 3u, cpu.address("absx", 0x0418u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C901 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x418u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C904;
L_82C904:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC904u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC904u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC904u, 5u + 1u, 3u, cpu.address("absx", 0x041Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C904 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x41Au), cpu.m8?8:16));
    goto L_82C907;
L_82C907:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC907u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC907u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC907u, 5u + 1u, 3u, cpu.address("absx", 0x041Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C907 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x41Cu), cpu.m8?8:16));
    goto L_82C90A;
L_82C90A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC90Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC90Au,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC90Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C90A BPL -> $82C90E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82C90E; }
    goto L_82C90C;
L_82C90C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC90Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC90Cu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC90Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C90C SEC
    cpu.setFlag('C', true);
    goto L_82C90D;
L_82C90D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC90Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC90Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC90Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C90D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C90Du);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C90Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82C90E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC90Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC90Eu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC90Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C90E CLC
    cpu.setFlag('C', false);
    goto L_82C90F;
L_82C90F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC90Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC90Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC90Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C90F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C90Fu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C90Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82CAEE_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82CAEEu: goto L_82CAEE;
    case 0x82CAF1u: goto L_82CAF1;
    case 0x82CAF2u: goto L_82CAF2;
    case 0x82CAF3u: goto L_82CAF3;
    case 0x82CAF6u: goto L_82CAF6;
    case 0x82CAF9u: goto L_82CAF9;
    case 0x82CAFDu: goto L_82CAFD;
    case 0x82CAFEu: goto L_82CAFE;
    case 0x82CB02u: goto L_82CB02;
    case 0x82CB05u: goto L_82CB05;
    case 0x82CB06u: goto L_82CB06;
    case 0x82CB07u: goto L_82CB07;
    case 0x82CB0Au: goto L_82CB0A;
    case 0x82CB0Du: goto L_82CB0D;
    case 0x82CB11u: goto L_82CB11;
    case 0x82CB12u: goto L_82CB12;
    case 0x82CB16u: goto L_82CB16;
    case 0x82CB19u: goto L_82CB19;
    case 0x82CB1Au: goto L_82CB1A;
    case 0x82CB1Cu: goto L_82CB1C;
    case 0x82CB20u: goto L_82CB20;
    case 0x82CB22u: goto L_82CB22;
    case 0x82CB25u: goto L_82CB25;
    case 0x82CB27u: goto L_82CB27;
    case 0x82CB2Au: goto L_82CB2A;
    case 0x82CB2Eu: goto L_82CB2E;
    case 0x82CB30u: goto L_82CB30;
    case 0x82CB33u: goto L_82CB33;
    case 0x82CB36u: goto L_82CB36;
    case 0x82CB3Au: goto L_82CB3A;
    case 0x82CB3Du: goto L_82CB3D;
    case 0x82CB3Eu: goto L_82CB3E;
    case 0x82CB40u: goto L_82CB40;
    case 0x82CB44u: goto L_82CB44;
    case 0x82CB46u: goto L_82CB46;
    case 0x82CB49u: goto L_82CB49;
    case 0x82CB4Bu: goto L_82CB4B;
    case 0x82CB4Eu: goto L_82CB4E;
    case 0x82CB52u: goto L_82CB52;
    case 0x82CB54u: goto L_82CB54;
    case 0x82CB57u: goto L_82CB57;
    case 0x82CB5Au: goto L_82CB5A;
    case 0x82CB5Eu: goto L_82CB5E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82CAEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAEEu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAEEu, 5u, 3u, cpu.address("abs", 0x02A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CAEE LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2A2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CAF1;
L_82CAF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAF1u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAF1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CAF1 ASL
    cpu.aslA();
    goto L_82CAF2;
L_82CAF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAF2u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAF2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CAF2 CLC
    cpu.setFlag('C', false);
    goto L_82CAF3;
L_82CAF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAF3u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAF3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CAF3 ADC
    cpu.adc(0xA6u);
    goto L_82CAF6;
L_82CAF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAF6u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAF6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CAF6 ORA
    cpu.logicOr(0x3400u);
    goto L_82CAF9;
L_82CAF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAF9u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAF9u, 6u, 4u, 0x7E2E1Cu, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CAF9 STA
    hw.write(0x7E2E1Cu, cpu.a, cpu.m8?8:16);
    goto L_82CAFD;
L_82CAFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAFDu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAFDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CAFD INC
    cpu.inc('A');
    goto L_82CAFE;
L_82CAFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAFEu,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAFEu, 6u, 4u, 0x7E2E1Eu, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CAFE STA
    hw.write(0x7E2E1Eu, cpu.a, cpu.m8?8:16);
    goto L_82CB02;
L_82CB02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB02u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB02u, 5u, 3u, cpu.address("abs", 0x03A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB02 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x3A2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CB05;
L_82CB05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB05u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB05u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB05 ASL
    cpu.aslA();
    goto L_82CB06;
L_82CB06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB06u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB06u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB06 CLC
    cpu.setFlag('C', false);
    goto L_82CB07;
L_82CB07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB07u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB07u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB07 ADC
    cpu.adc(0xF6u);
    goto L_82CB0A;
L_82CB0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB0Au,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB0Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB0A ORA
    cpu.logicOr(0x3400u);
    goto L_82CB0D;
L_82CB0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB0Du,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB0Du, 6u, 4u, 0x7E2E20u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB0D STA
    hw.write(0x7E2E20u, cpu.a, cpu.m8?8:16);
    goto L_82CB11;
L_82CB11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB11u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB11u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB11 INC
    cpu.inc('A');
    goto L_82CB12;
L_82CB12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB12u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB12u, 6u, 4u, 0x7E2E22u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB12 STA
    hw.write(0x7E2E22u, cpu.a, cpu.m8?8:16);
    goto L_82CB16;
L_82CB16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB16u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB16u, 5u, 3u, cpu.address("abs", 0x02CEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB16 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2CEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CB19;
L_82CB19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB19u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB19u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB19 INC
    cpu.inc('A');
    goto L_82CB1A;
L_82CB1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB1Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB1Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB1A STA
    hw.write(cpu.address("dp", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_82CB1C;
L_82CB1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB1Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB1Cu, 8u, 4u, 0x809315u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82CB1C JSL -> $809315 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xCB1Fu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCB20u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809315u, 0x82CB1Cu); }
    goto L_82CB20;
L_82CB20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB20u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCB20u,0x82CB20u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB20u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB20u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB20 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CB22;
L_82CB22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB22u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB22u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB22 AND
    cpu.logicAnd(0xFFu);
    goto L_82CB25;
L_82CB25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB25u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB25u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB25 BEQ -> $82CB2A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CB2A; }
    goto L_82CB27;
L_82CB27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB27u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB27u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB27 ORA
    cpu.logicOr(0x34B0u);
    goto L_82CB2A;
L_82CB2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB2Au,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB2Au, 6u, 4u, 0x7E2D9Cu, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB2A STA
    hw.write(0x7E2D9Cu, cpu.a, cpu.m8?8:16);
    goto L_82CB2E;
L_82CB2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB2Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB2Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB2E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CB30;
L_82CB30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB30u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB30u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB30 AND
    cpu.logicAnd(0xFFu);
    goto L_82CB33;
L_82CB33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB33u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB33u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB33 ORA
    cpu.logicOr(0x34B0u);
    goto L_82CB36;
L_82CB36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB36u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB36u, 6u, 4u, 0x7E2D9Eu, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB36 STA
    hw.write(0x7E2D9Eu, cpu.a, cpu.m8?8:16);
    goto L_82CB3A;
L_82CB3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB3Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB3Au, 5u, 3u, cpu.address("abs", 0x03CEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB3A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x3CEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CB3D;
L_82CB3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB3Du,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB3Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB3D INC
    cpu.inc('A');
    goto L_82CB3E;
L_82CB3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB3Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB3Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB3E STA
    hw.write(cpu.address("dp", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_82CB40;
L_82CB40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB40u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB40u, 8u, 4u, 0x809315u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82CB40 JSL -> $809315 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xCB43u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCB44u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809315u, 0x82CB40u); }
    goto L_82CB44;
L_82CB44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB44u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCB44u,0x82CB44u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB44u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB44u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB44 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CB46;
L_82CB46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB46u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB46u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB46 AND
    cpu.logicAnd(0xFFu);
    goto L_82CB49;
L_82CB49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB49u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB49u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB49 BEQ -> $82CB4E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CB4E; }
    goto L_82CB4B;
L_82CB4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB4Bu,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB4Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB4B ORA
    cpu.logicOr(0x34D0u);
    goto L_82CB4E;
L_82CB4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB4Eu,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB4Eu, 6u, 4u, 0x7E2DA0u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB4E STA
    hw.write(0x7E2DA0u, cpu.a, cpu.m8?8:16);
    goto L_82CB52;
L_82CB52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB52u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB52u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB52 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CB54;
L_82CB54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB54u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB54u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB54 AND
    cpu.logicAnd(0xFFu);
    goto L_82CB57;
L_82CB57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB57u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB57u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB57 ORA
    cpu.logicOr(0x34D0u);
    goto L_82CB5A;
L_82CB5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB5Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB5Au,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB5Au, 6u, 4u, 0x7E2DA2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB5A STA
    hw.write(0x7E2DA2u, cpu.a, cpu.m8?8:16);
    goto L_82CB5E;
L_82CB5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB5Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB5Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82CB5E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82CB5Eu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82CB5Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82CAEE_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82CAEEu: goto L_82CAEE;
    case 0x82CAF1u: goto L_82CAF1;
    case 0x82CAF2u: goto L_82CAF2;
    case 0x82CAF3u: goto L_82CAF3;
    case 0x82CAF6u: goto L_82CAF6;
    case 0x82CAF9u: goto L_82CAF9;
    case 0x82CAFDu: goto L_82CAFD;
    case 0x82CAFEu: goto L_82CAFE;
    case 0x82CB02u: goto L_82CB02;
    case 0x82CB05u: goto L_82CB05;
    case 0x82CB06u: goto L_82CB06;
    case 0x82CB07u: goto L_82CB07;
    case 0x82CB0Au: goto L_82CB0A;
    case 0x82CB0Du: goto L_82CB0D;
    case 0x82CB11u: goto L_82CB11;
    case 0x82CB12u: goto L_82CB12;
    case 0x82CB16u: goto L_82CB16;
    case 0x82CB19u: goto L_82CB19;
    case 0x82CB1Au: goto L_82CB1A;
    case 0x82CB1Cu: goto L_82CB1C;
    case 0x82CB20u: goto L_82CB20;
    case 0x82CB22u: goto L_82CB22;
    case 0x82CB25u: goto L_82CB25;
    case 0x82CB27u: goto L_82CB27;
    case 0x82CB2Au: goto L_82CB2A;
    case 0x82CB2Eu: goto L_82CB2E;
    case 0x82CB30u: goto L_82CB30;
    case 0x82CB33u: goto L_82CB33;
    case 0x82CB36u: goto L_82CB36;
    case 0x82CB3Au: goto L_82CB3A;
    case 0x82CB3Du: goto L_82CB3D;
    case 0x82CB3Eu: goto L_82CB3E;
    case 0x82CB40u: goto L_82CB40;
    case 0x82CB44u: goto L_82CB44;
    case 0x82CB46u: goto L_82CB46;
    case 0x82CB49u: goto L_82CB49;
    case 0x82CB4Bu: goto L_82CB4B;
    case 0x82CB4Eu: goto L_82CB4E;
    case 0x82CB52u: goto L_82CB52;
    case 0x82CB54u: goto L_82CB54;
    case 0x82CB57u: goto L_82CB57;
    case 0x82CB5Au: goto L_82CB5A;
    case 0x82CB5Eu: goto L_82CB5E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82CAEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAEEu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAEEu, 5u, 3u, cpu.address("abs", 0x02A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CAEE LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2A2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CAF1;
L_82CAF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAF1u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAF1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CAF1 ASL
    cpu.aslA();
    goto L_82CAF2;
L_82CAF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAF2u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAF2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CAF2 CLC
    cpu.setFlag('C', false);
    goto L_82CAF3;
L_82CAF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAF3u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAF3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CAF3 ADC
    cpu.adc(0xA6u);
    goto L_82CAF6;
L_82CAF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAF6u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAF6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CAF6 ORA
    cpu.logicOr(0x3400u);
    goto L_82CAF9;
L_82CAF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAF9u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAF9u, 6u, 4u, 0x7E2E1Cu, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CAF9 STA
    hw.write(0x7E2E1Cu, cpu.a, cpu.m8?8:16);
    goto L_82CAFD;
L_82CAFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAFDu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAFDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CAFD INC
    cpu.inc('A');
    goto L_82CAFE;
L_82CAFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAFEu,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAFEu, 6u, 4u, 0x7E2E1Eu, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CAFE STA
    hw.write(0x7E2E1Eu, cpu.a, cpu.m8?8:16);
    goto L_82CB02;
L_82CB02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB02u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB02u, 5u, 3u, cpu.address("abs", 0x03A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB02 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x3A2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CB05;
L_82CB05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB05u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB05u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB05 ASL
    cpu.aslA();
    goto L_82CB06;
L_82CB06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB06u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB06u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB06 CLC
    cpu.setFlag('C', false);
    goto L_82CB07;
L_82CB07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB07u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB07u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB07 ADC
    cpu.adc(0xF6u);
    goto L_82CB0A;
L_82CB0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB0Au,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB0Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB0A ORA
    cpu.logicOr(0x3400u);
    goto L_82CB0D;
L_82CB0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB0Du,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB0Du, 6u, 4u, 0x7E2E20u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB0D STA
    hw.write(0x7E2E20u, cpu.a, cpu.m8?8:16);
    goto L_82CB11;
L_82CB11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB11u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB11u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB11 INC
    cpu.inc('A');
    goto L_82CB12;
L_82CB12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB12u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB12u, 6u, 4u, 0x7E2E22u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB12 STA
    hw.write(0x7E2E22u, cpu.a, cpu.m8?8:16);
    goto L_82CB16;
L_82CB16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB16u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB16u, 5u, 3u, cpu.address("abs", 0x02CEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB16 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2CEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CB19;
L_82CB19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB19u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB19u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB19 INC
    cpu.inc('A');
    goto L_82CB1A;
L_82CB1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB1Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB1Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB1A STA
    hw.write(cpu.address("dp", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_82CB1C;
L_82CB1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB1Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB1Cu, 8u, 4u, 0x809315u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82CB1C JSL -> $809315 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xCB1Fu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCB20u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809315u, 0x82CB1Cu); }
    goto L_82CB20;
L_82CB20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB20u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCB20u,0x82CB20u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB20u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB20u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB20 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CB22;
L_82CB22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB22u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB22u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB22 AND
    cpu.logicAnd(0xFFu);
    goto L_82CB25;
L_82CB25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB25u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB25u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB25 BEQ -> $82CB2A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CB2A; }
    goto L_82CB27;
L_82CB27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB27u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB27u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB27 ORA
    cpu.logicOr(0x34B0u);
    goto L_82CB2A;
L_82CB2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB2Au,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB2Au, 6u, 4u, 0x7E2D9Cu, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB2A STA
    hw.write(0x7E2D9Cu, cpu.a, cpu.m8?8:16);
    goto L_82CB2E;
L_82CB2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB2Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB2Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB2E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CB30;
L_82CB30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB30u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB30u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB30 AND
    cpu.logicAnd(0xFFu);
    goto L_82CB33;
L_82CB33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB33u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB33u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB33 ORA
    cpu.logicOr(0x34B0u);
    goto L_82CB36;
L_82CB36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB36u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB36u, 6u, 4u, 0x7E2D9Eu, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB36 STA
    hw.write(0x7E2D9Eu, cpu.a, cpu.m8?8:16);
    goto L_82CB3A;
L_82CB3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB3Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB3Au, 5u, 3u, cpu.address("abs", 0x03CEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB3A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x3CEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CB3D;
L_82CB3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB3Du,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB3Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB3D INC
    cpu.inc('A');
    goto L_82CB3E;
L_82CB3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB3Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB3Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB3E STA
    hw.write(cpu.address("dp", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_82CB40;
L_82CB40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB40u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB40u, 8u, 4u, 0x809315u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82CB40 JSL -> $809315 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xCB43u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCB44u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809315u, 0x82CB40u); }
    goto L_82CB44;
L_82CB44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB44u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCB44u,0x82CB44u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB44u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB44u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB44 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CB46;
L_82CB46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB46u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB46u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB46 AND
    cpu.logicAnd(0xFFu);
    goto L_82CB49;
L_82CB49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB49u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB49u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB49 BEQ -> $82CB4E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CB4E; }
    goto L_82CB4B;
L_82CB4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB4Bu,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB4Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB4B ORA
    cpu.logicOr(0x34D0u);
    goto L_82CB4E;
L_82CB4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB4Eu,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB4Eu, 6u, 4u, 0x7E2DA0u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB4E STA
    hw.write(0x7E2DA0u, cpu.a, cpu.m8?8:16);
    goto L_82CB52;
L_82CB52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB52u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB52u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB52 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CB54;
L_82CB54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB54u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB54u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB54 AND
    cpu.logicAnd(0xFFu);
    goto L_82CB57;
L_82CB57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB57u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB57u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB57 ORA
    cpu.logicOr(0x34D0u);
    goto L_82CB5A;
L_82CB5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB5Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB5Au,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB5Au, 6u, 4u, 0x7E2DA2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CB5A STA
    hw.write(0x7E2DA2u, cpu.a, cpu.m8?8:16);
    goto L_82CB5E;
L_82CB5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB5Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB5Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82CB5E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82CB5Eu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82CB5Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82CD6B_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82CD6Bu: goto L_82CD6B;
    case 0x82CD6Eu: goto L_82CD6E;
    case 0x82CD71u: goto L_82CD71;
    case 0x82CD73u: goto L_82CD73;
    case 0x82CD76u: goto L_82CD76;
    case 0x82CD77u: goto L_82CD77;
    case 0x82CD78u: goto L_82CD78;
    case 0x82CD79u: goto L_82CD79;
    case 0x82CD7Cu: goto L_82CD7C;
    case 0x82CD7Eu: goto L_82CD7E;
    case 0x82CD81u: goto L_82CD81;
    case 0x82CD83u: goto L_82CD83;
    case 0x82CD85u: goto L_82CD85;
    case 0x82CD88u: goto L_82CD88;
    case 0x82CD8Bu: goto L_82CD8B;
    case 0x82CD8Du: goto L_82CD8D;
    case 0x82CD8Eu: goto L_82CD8E;
    case 0x82CD8Fu: goto L_82CD8F;
    case 0x82CD91u: goto L_82CD91;
    case 0x82CD92u: goto L_82CD92;
    case 0x82CD96u: goto L_82CD96;
    case 0x82CD98u: goto L_82CD98;
    case 0x82CD9Cu: goto L_82CD9C;
    case 0x82CD9Fu: goto L_82CD9F;
    case 0x82CDA1u: goto L_82CDA1;
    case 0x82CDA4u: goto L_82CDA4;
    case 0x82CDA7u: goto L_82CDA7;
    case 0x82CDA9u: goto L_82CDA9;
    case 0x82CDACu: goto L_82CDAC;
    case 0x82CDAEu: goto L_82CDAE;
    case 0x82CDB2u: goto L_82CDB2;
    case 0x82CDB3u: goto L_82CDB3;
    case 0x82CDB4u: goto L_82CDB4;
    case 0x82CDB5u: goto L_82CDB5;
    case 0x82CDB6u: goto L_82CDB6;
    case 0x82CDB8u: goto L_82CDB8;
    case 0x82CDBBu: goto L_82CDBB;
    case 0x82CDBDu: goto L_82CDBD;
    case 0x82CDBEu: goto L_82CDBE;
    case 0x82CDBFu: goto L_82CDBF;
    case 0x82CDC1u: goto L_82CDC1;
    case 0x82CDC4u: goto L_82CDC4;
    case 0x82CDC7u: goto L_82CDC7;
    case 0x82CDC9u: goto L_82CDC9;
    case 0x82CDCBu: goto L_82CDCB;
    case 0x82CDCCu: goto L_82CDCC;
    case 0x82CDCDu: goto L_82CDCD;
    case 0x82CDCFu: goto L_82CDCF;
    case 0x82CDD1u: goto L_82CDD1;
    case 0x82CDD4u: goto L_82CDD4;
    case 0x82CDD7u: goto L_82CDD7;
    case 0x82CDDAu: goto L_82CDDA;
    case 0x82CDDEu: goto L_82CDDE;
    case 0x82CDE0u: goto L_82CDE0;
    case 0x82CDE3u: goto L_82CDE3;
    case 0x82CDE5u: goto L_82CDE5;
    case 0x82CDE8u: goto L_82CDE8;
    case 0x82CDEAu: goto L_82CDEA;
    case 0x82CDEDu: goto L_82CDED;
    case 0x82CDEEu: goto L_82CDEE;
    case 0x82CDEFu: goto L_82CDEF;
    case 0x82CDF0u: goto L_82CDF0;
    case 0x82CDF3u: goto L_82CDF3;
    case 0x82CDF5u: goto L_82CDF5;
    case 0x82CDF6u: goto L_82CDF6;
    case 0x82CDF7u: goto L_82CDF7;
    case 0x82CDFAu: goto L_82CDFA;
    case 0x82CDFCu: goto L_82CDFC;
    case 0x82CDFEu: goto L_82CDFE;
    case 0x82CE01u: goto L_82CE01;
    case 0x82CE02u: goto L_82CE02;
    case 0x82CE03u: goto L_82CE03;
    case 0x82CE05u: goto L_82CE05;
    case 0x82CE08u: goto L_82CE08;
    case 0x82CE0Bu: goto L_82CE0B;
    case 0x82CE0Eu: goto L_82CE0E;
    case 0x82CE10u: goto L_82CE10;
    case 0x82CE11u: goto L_82CE11;
    case 0x82CE12u: goto L_82CE12;
    case 0x82CE14u: goto L_82CE14;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82CD6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD6Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD6Bu, 5u, 3u, cpu.address("abs", 0x01D7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CD6B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1D7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CD6E;
L_82CD6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD6Eu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD6Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CD6E BIT
    cpu.bit(0x1u, true);
    goto L_82CD71;
L_82CD71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD71u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD71u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CD71 BEQ -> $82CD85
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CD85; }
    goto L_82CD73;
L_82CD73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD73u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD73u, 5u, 3u, cpu.address("abs", 0x02CEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CD73 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2CEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CD76;
L_82CD76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD76u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD76u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CD76 ASL
    cpu.aslA();
    goto L_82CD77;
L_82CD77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD77u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD77u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD77u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CD77 XBA
    cpu.xba();
    goto L_82CD78;
L_82CD78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD78u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD78u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CD78 CLC
    cpu.setFlag('C', false);
    goto L_82CD79;
L_82CD79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD79u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD79u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CD79 ADC
    cpu.adc(0x0u);
    goto L_82CD7C;
L_82CD7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD7Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD7Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CD7C STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82CD7E;
L_82CD7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD7Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD7Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CD7E LDA
    cpu.setA(0x70u, 16);
    goto L_82CD81;
L_82CD81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD81u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD81u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CD81 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_82CD83;
L_82CD83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD83u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD83u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CD83 BRA -> $82CDA1
    goto L_82CDA1;
L_82CD85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD85u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD85u, 5u, 3u, cpu.address("abs", 0x02CEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CD85 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2CEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CD88;
L_82CD88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD88u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD88u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD88u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CD88 AND
    cpu.logicAnd(0x7Fu);
    goto L_82CD8B;
L_82CD8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD8Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD8Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CD8B STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_82CD8D;
L_82CD8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD8Du,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD8Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CD8D ASL
    cpu.aslA();
    goto L_82CD8E;
L_82CD8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD8Eu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD8Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CD8E CLC
    cpu.setFlag('C', false);
    goto L_82CD8F;
L_82CD8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD8Fu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD8Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CD8F ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16));
    goto L_82CD91;
L_82CD91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD91u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD91u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CD91 TAX
    cpu.transfer("TAX");
    goto L_82CD92;
L_82CD92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD92u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD92u, 6u, 4u, ((0x9E9604u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CD92 LDA
    cpu.loadA(hw.readW(((0x9E9604u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CD96;
L_82CD96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD96u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD96u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CD96 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82CD98;
L_82CD98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD98u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD98u, 6u, 4u, ((0x9E9606u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CD98 LDA
    cpu.loadA(hw.readW(((0x9E9606u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CD9C;
L_82CD9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD9Cu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD9Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CD9C AND
    cpu.logicAnd(0xFFu);
    goto L_82CD9F;
L_82CD9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD9Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD9Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CD9F STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_82CDA1;
L_82CDA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDA1u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDA1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CDA1 LDY
    cpu.setY(0x0u, 16);
    goto L_82CDA4;
L_82CDA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDA4u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDA4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CDA4 LDX
    cpu.setX(0x1F8u, 16);
    goto L_82CDA7;
L_82CDA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDA7u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDA7u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $82CDA7 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CDA9;
L_82CDA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDA9u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDA9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CDA9 CMP
    cpu.compareA(0x8080u);
    goto L_82CDAC;
L_82CDAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDACu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDACu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CDAC BEQ -> $82CDB8
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CDB8; }
    goto L_82CDAE;
L_82CDAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDAEu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDAEu, 6u, 4u, ((0x7E2220u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CDAE STA
    hw.write(((0x7E2220u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_82CDB2;
L_82CDB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDB2u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDB2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CDB2 INY
    cpu.inc('Y');
    goto L_82CDB3;
L_82CDB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDB3u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDB3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CDB3 INY
    cpu.inc('Y');
    goto L_82CDB4;
L_82CDB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDB4u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDB4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CDB4 DEX
    cpu.decReg('X');
    goto L_82CDB5;
L_82CDB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDB5u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDB5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CDB5 DEX
    cpu.decReg('X');
    goto L_82CDB6;
L_82CDB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDB6u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDB6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CDB6 BRA -> $82CDA7
    goto L_82CDA7;
L_82CDB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDB8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDB8u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDB8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CDB8 LDX
    cpu.setX(0x0u, 16);
    goto L_82CDBB;
L_82CDBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDBBu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDBBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CDBB STZ
    hw.write(cpu.address("dp", 0x10u), 0, cpu.m8?8:16);
    goto L_82CDBD;
L_82CDBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDBDu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDBDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CDBD INY
    cpu.inc('Y');
    goto L_82CDBE;
L_82CDBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDBEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDBEu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDBEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CDBE INY
    cpu.inc('Y');
    goto L_82CDBF;
L_82CDBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDBFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDBFu,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDBFu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $82CDBF LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CDC1;
L_82CDC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC1u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC1u, 6u, 3u, cpu.address("absx", 0x0806u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CDC1 STA
    hw.write(cpu.address("absx", 0x806u), cpu.a, cpu.m8?8:16);
    goto L_82CDC4;
L_82CDC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC4u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CDC4 CMP
    cpu.compareA(0xFFFFu);
    goto L_82CDC7;
L_82CDC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CDC7 BEQ -> $82CDCF
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CDCF; }
    goto L_82CDC9;
L_82CDC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC9u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC9u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CDC9 INC
    cpu.incMem(hw, cpu.address("dp", 0x10u), cpu.m8?8:16);
    goto L_82CDCB;
L_82CDCB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDCBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDCBu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDCBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CDCB INX
    cpu.inc('X');
    goto L_82CDCC;
L_82CDCC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDCCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDCCu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDCCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CDCC INX
    cpu.inc('X');
    goto L_82CDCD;
L_82CDCD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDCDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDCDu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDCDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CDCD BRA -> $82CDBD
    goto L_82CDBD;
L_82CDCF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDCFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDCFu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDCFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CDCF LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CDD1;
L_82CDD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD1u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD1u, 5u, 3u, cpu.address("abs", 0x0802u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CDD1 STA
    hw.write(cpu.address("abs", 0x802u), cpu.a, cpu.m8?8:16);
    goto L_82CDD4;
L_82CDD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDD4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD4u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD4u, 5u, 3u, cpu.address("abs", 0x0804u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CDD4 STA
    hw.write(cpu.address("abs", 0x804u), cpu.a, cpu.m8?8:16);
    goto L_82CDD7;
L_82CDD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDD7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD7u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CDD7 LDX
    cpu.setX(0x1F8u, 16);
    goto L_82CDDA;
L_82CDDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDDAu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDDAu, 6u, 4u, ((0x7E2220u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CDDA LDA
    cpu.loadA(hw.readW(((0x7E2220u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CDDE;
L_82CDDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDDEu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDDEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CDDE BEQ -> $82CE10
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CE10; }
    goto L_82CDE0;
L_82CDE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDE0u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDE0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CDE0 CMP
    cpu.compareA(0xFFFFu);
    goto L_82CDE3;
L_82CDE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDE3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDE3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CDE3 BEQ -> $82CE14
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CE14; }
    goto L_82CDE5;
L_82CDE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDE5u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDE5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CDE5 BIT
    cpu.bit(0x2000u, true);
    goto L_82CDE8;
L_82CDE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDE8u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDE8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CDE8 BEQ -> $82CE10
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CE10; }
    goto L_82CDEA;
L_82CDEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDEAu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDEAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CDEA AND
    cpu.logicAnd(0x300u);
    goto L_82CDED;
L_82CDED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDEDu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDEDu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CDED XBA
    cpu.xba();
    goto L_82CDEE;
L_82CDEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDEEu,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDEEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CDEE DEC
    cpu.decReg('A');
    goto L_82CDEF;
L_82CDEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDEFu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDEFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CDEF ASL
    cpu.aslA();
    goto L_82CDF0;
L_82CDF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDF0u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDF0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CDF0 ORA
    cpu.logicOr(0x100u);
    goto L_82CDF3;
L_82CDF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDF3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDF3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CDF3 STA
    hw.write(cpu.address("dp", 0x61u), cpu.a, cpu.m8?8:16);
    goto L_82CDF5;
L_82CDF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDF5u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDF5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CDF5 TXA
    cpu.transfer("TXA");
    goto L_82CDF6;
L_82CDF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDF6u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDF6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CDF6 SEC
    cpu.setFlag('C', true);
    goto L_82CDF7;
L_82CDF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDF7u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDF7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CDF7 SBC
    cpu.sbc(0x1E6u);
    goto L_82CDFA;
L_82CDFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDFAu,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDFAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CDFA STX
    hw.write(cpu.address("dp", 0x63u), cpu.x, cpu.x8?8:16);
    goto L_82CDFC;
L_82CDFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDFCu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDFCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CDFC LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x61u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82CDFE;
L_82CDFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDFEu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDFEu, 6u, 3u, cpu.address("absx", 0x02AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CDFE STA
    hw.write(cpu.address("absx", 0x2AAu), cpu.a, cpu.m8?8:16);
    goto L_82CE01;
L_82CE01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE01u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE01u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE01 ASL
    cpu.aslA();
    goto L_82CE02;
L_82CE02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE02u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE02u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE02 ASL
    cpu.aslA();
    goto L_82CE03;
L_82CE03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE03u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE03u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE03 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x61u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82CE05;
L_82CE05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE05u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE05u, 6u, 3u, cpu.address("absx", 0x02B0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE05 STA
    hw.write(cpu.address("absx", 0x2B0u), cpu.a, cpu.m8?8:16);
    goto L_82CE08;
L_82CE08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE08u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE08u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE08 LDA
    cpu.setA(0xCCu, 16);
    goto L_82CE0B;
L_82CE0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE0Bu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE0Bu, 6u, 3u, cpu.address("absx", 0x02B6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE0B STA
    hw.write(cpu.address("absx", 0x2B6u), cpu.a, cpu.m8?8:16);
    goto L_82CE0E;
L_82CE0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE0Eu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE0Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE0E LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82CE10;
L_82CE10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE10u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE10u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE10 DEX
    cpu.decReg('X');
    goto L_82CE11;
L_82CE11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE11u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE11u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE11 DEX
    cpu.decReg('X');
    goto L_82CE12;
L_82CE12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE12u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE12u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE12 BRA -> $82CDDA
    goto L_82CDDA;
L_82CE14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE14u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE14u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82CE14 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82CE14u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82CE14u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82CE15_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82CE15u: goto L_82CE15;
    case 0x82CE18u: goto L_82CE18;
    case 0x82CE1Bu: goto L_82CE1B;
    case 0x82CE1Du: goto L_82CE1D;
    case 0x82CE20u: goto L_82CE20;
    case 0x82CE22u: goto L_82CE22;
    case 0x82CE25u: goto L_82CE25;
    case 0x82CE28u: goto L_82CE28;
    case 0x82CE2Au: goto L_82CE2A;
    case 0x82CE2Cu: goto L_82CE2C;
    case 0x82CE2Fu: goto L_82CE2F;
    case 0x82CE31u: goto L_82CE31;
    case 0x82CE34u: goto L_82CE34;
    case 0x82CE37u: goto L_82CE37;
    case 0x82CE3Au: goto L_82CE3A;
    case 0x82CE3Du: goto L_82CE3D;
    case 0x82CE40u: goto L_82CE40;
    case 0x82CE43u: goto L_82CE43;
    case 0x82CE46u: goto L_82CE46;
    case 0x82CE49u: goto L_82CE49;
    case 0x82CE4Cu: goto L_82CE4C;
    case 0x82CE4Fu: goto L_82CE4F;
    case 0x82CE52u: goto L_82CE52;
    case 0x82CE55u: goto L_82CE55;
    case 0x82CE58u: goto L_82CE58;
    case 0x82CE5Bu: goto L_82CE5B;
    case 0x82CE5Eu: goto L_82CE5E;
    case 0x82CE61u: goto L_82CE61;
    case 0x82CE64u: goto L_82CE64;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82CE15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE15u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE15u, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE15 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CE18;
L_82CE18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE18u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE18u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE18 CMP
    cpu.compareA(0x1u);
    goto L_82CE1B;
L_82CE1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE1Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE1Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE1B BNE -> $82CE64
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CE64; }
    goto L_82CE1D;
L_82CE1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE1Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE1Du, 5u, 3u, cpu.address("abs", 0x0816u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE1D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x816u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CE20;
L_82CE20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE20u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE20u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE20 BNE -> $82CE64
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CE64; }
    goto L_82CE22;
L_82CE22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE22u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE22u, 5u, 3u, cpu.address("abs", 0x0200u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE22 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x200u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CE25;
L_82CE25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE25u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE25u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE25 CMP
    cpu.compareA(0x7u);
    goto L_82CE28;
L_82CE28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE28u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE28u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE28 BCS -> $82CE64
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_82CE64; }
    goto L_82CE2A;
L_82CE2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE2Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE2Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE2A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CE2C;
L_82CE2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE2Cu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE2Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE2C BIT
    cpu.bit(0x2000u, true);
    goto L_82CE2F;
L_82CE2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE2Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE2Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE2F BEQ -> $82CE64
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CE64; }
    goto L_82CE31;
L_82CE31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE31u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE31u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE31 LDA
    cpu.setA(0xFFFFu, 16);
    goto L_82CE34;
L_82CE34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE34u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE34u, 5u, 3u, cpu.address("abs", 0x0208u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE34 STA
    hw.write(cpu.address("abs", 0x208u), cpu.a, cpu.m8?8:16);
    goto L_82CE37;
L_82CE37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE37u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE37u, 5u, 3u, cpu.address("abs", 0x020Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE37 STA
    hw.write(cpu.address("abs", 0x20Eu), cpu.a, cpu.m8?8:16);
    goto L_82CE3A;
L_82CE3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE3Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE3Au, 5u, 3u, cpu.address("abs", 0x0214u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE3A STA
    hw.write(cpu.address("abs", 0x214u), cpu.a, cpu.m8?8:16);
    goto L_82CE3D;
L_82CE3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE3Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE3Du, 5u, 3u, cpu.address("abs", 0x021Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE3D STA
    hw.write(cpu.address("abs", 0x21Au), cpu.a, cpu.m8?8:16);
    goto L_82CE40;
L_82CE40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE40u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE40u, 5u, 3u, cpu.address("abs", 0x0240u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE40 STA
    hw.write(cpu.address("abs", 0x240u), cpu.a, cpu.m8?8:16);
    goto L_82CE43;
L_82CE43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE43u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE43u, 5u, 3u, cpu.address("abs", 0x0246u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE43 STA
    hw.write(cpu.address("abs", 0x246u), cpu.a, cpu.m8?8:16);
    goto L_82CE46;
L_82CE46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE46u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE46u, 5u, 3u, cpu.address("abs", 0x024Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE46 STA
    hw.write(cpu.address("abs", 0x24Cu), cpu.a, cpu.m8?8:16);
    goto L_82CE49;
L_82CE49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE49u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE49u, 5u, 3u, cpu.address("abs", 0x0252u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE49 STA
    hw.write(cpu.address("abs", 0x252u), cpu.a, cpu.m8?8:16);
    goto L_82CE4C;
L_82CE4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE4Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE4Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE4C LDA
    cpu.setA(0xFF00u, 16);
    goto L_82CE4F;
L_82CE4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE4Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE4Fu,cpu,0x0Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE4Fu, 8u, 3u, cpu.address("abs", 0x0884u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE4F TSB
    cpu.tsb(hw, cpu.address("abs", 0x884u), cpu.m8?8:16);
    goto L_82CE52;
L_82CE52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE52u,cpu,0x0Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE52u, 8u, 3u, cpu.address("abs", 0x0886u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE52 TSB
    cpu.tsb(hw, cpu.address("abs", 0x886u), cpu.m8?8:16);
    goto L_82CE55;
L_82CE55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE55u,cpu,0x0Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE55u, 8u, 3u, cpu.address("abs", 0x0888u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE55 TSB
    cpu.tsb(hw, cpu.address("abs", 0x888u), cpu.m8?8:16);
    goto L_82CE58;
L_82CE58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE58u,cpu,0x0Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE58u, 8u, 3u, cpu.address("abs", 0x088Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE58 TSB
    cpu.tsb(hw, cpu.address("abs", 0x88Au), cpu.m8?8:16);
    goto L_82CE5B;
L_82CE5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE5Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE5Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE5Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE5B LDA
    cpu.setA(0xDu, 16);
    goto L_82CE5E;
L_82CE5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE5Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE5Eu, 5u, 3u, cpu.address("abs", 0x0200u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE5E STA
    hw.write(cpu.address("abs", 0x200u), cpu.a, cpu.m8?8:16);
    goto L_82CE61;
L_82CE61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE61u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE61u, 8u, 3u, cpu.address("abs", 0x0816u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE61 INC
    cpu.incMem(hw, cpu.address("abs", 0x816u), cpu.m8?8:16);
    goto L_82CE64;
L_82CE64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE64u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE64u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82CE64 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82CE64u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82CE64u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82CE15_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82CE15u: goto L_82CE15;
    case 0x82CE18u: goto L_82CE18;
    case 0x82CE1Bu: goto L_82CE1B;
    case 0x82CE1Du: goto L_82CE1D;
    case 0x82CE20u: goto L_82CE20;
    case 0x82CE22u: goto L_82CE22;
    case 0x82CE25u: goto L_82CE25;
    case 0x82CE28u: goto L_82CE28;
    case 0x82CE2Au: goto L_82CE2A;
    case 0x82CE2Cu: goto L_82CE2C;
    case 0x82CE2Fu: goto L_82CE2F;
    case 0x82CE31u: goto L_82CE31;
    case 0x82CE34u: goto L_82CE34;
    case 0x82CE37u: goto L_82CE37;
    case 0x82CE3Au: goto L_82CE3A;
    case 0x82CE3Du: goto L_82CE3D;
    case 0x82CE40u: goto L_82CE40;
    case 0x82CE43u: goto L_82CE43;
    case 0x82CE46u: goto L_82CE46;
    case 0x82CE49u: goto L_82CE49;
    case 0x82CE4Cu: goto L_82CE4C;
    case 0x82CE4Fu: goto L_82CE4F;
    case 0x82CE52u: goto L_82CE52;
    case 0x82CE55u: goto L_82CE55;
    case 0x82CE58u: goto L_82CE58;
    case 0x82CE5Bu: goto L_82CE5B;
    case 0x82CE5Eu: goto L_82CE5E;
    case 0x82CE61u: goto L_82CE61;
    case 0x82CE64u: goto L_82CE64;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82CE15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE15u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE15u, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE15 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CE18;
L_82CE18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE18u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE18u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE18 CMP
    cpu.compareA(0x1u);
    goto L_82CE1B;
L_82CE1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE1Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE1Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE1B BNE -> $82CE64
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CE64; }
    goto L_82CE1D;
L_82CE1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE1Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE1Du, 5u, 3u, cpu.address("abs", 0x0816u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE1D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x816u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CE20;
L_82CE20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE20u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE20u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE20 BNE -> $82CE64
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CE64; }
    goto L_82CE22;
L_82CE22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE22u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE22u, 5u, 3u, cpu.address("abs", 0x0200u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE22 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x200u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CE25;
L_82CE25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE25u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE25u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE25 CMP
    cpu.compareA(0x7u);
    goto L_82CE28;
L_82CE28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE28u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE28u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE28 BCS -> $82CE64
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_82CE64; }
    goto L_82CE2A;
L_82CE2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE2Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE2Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE2A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CE2C;
L_82CE2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE2Cu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE2Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE2C BIT
    cpu.bit(0x2000u, true);
    goto L_82CE2F;
L_82CE2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE2Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE2Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE2F BEQ -> $82CE64
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CE64; }
    goto L_82CE31;
L_82CE31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE31u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE31u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE31 LDA
    cpu.setA(0xFFFFu, 16);
    goto L_82CE34;
L_82CE34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE34u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE34u, 5u, 3u, cpu.address("abs", 0x0208u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE34 STA
    hw.write(cpu.address("abs", 0x208u), cpu.a, cpu.m8?8:16);
    goto L_82CE37;
L_82CE37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE37u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE37u, 5u, 3u, cpu.address("abs", 0x020Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE37 STA
    hw.write(cpu.address("abs", 0x20Eu), cpu.a, cpu.m8?8:16);
    goto L_82CE3A;
L_82CE3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE3Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE3Au, 5u, 3u, cpu.address("abs", 0x0214u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE3A STA
    hw.write(cpu.address("abs", 0x214u), cpu.a, cpu.m8?8:16);
    goto L_82CE3D;
L_82CE3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE3Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE3Du, 5u, 3u, cpu.address("abs", 0x021Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE3D STA
    hw.write(cpu.address("abs", 0x21Au), cpu.a, cpu.m8?8:16);
    goto L_82CE40;
L_82CE40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE40u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE40u, 5u, 3u, cpu.address("abs", 0x0240u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE40 STA
    hw.write(cpu.address("abs", 0x240u), cpu.a, cpu.m8?8:16);
    goto L_82CE43;
L_82CE43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE43u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE43u, 5u, 3u, cpu.address("abs", 0x0246u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE43 STA
    hw.write(cpu.address("abs", 0x246u), cpu.a, cpu.m8?8:16);
    goto L_82CE46;
L_82CE46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE46u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE46u, 5u, 3u, cpu.address("abs", 0x024Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE46 STA
    hw.write(cpu.address("abs", 0x24Cu), cpu.a, cpu.m8?8:16);
    goto L_82CE49;
L_82CE49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE49u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE49u, 5u, 3u, cpu.address("abs", 0x0252u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE49 STA
    hw.write(cpu.address("abs", 0x252u), cpu.a, cpu.m8?8:16);
    goto L_82CE4C;
L_82CE4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE4Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE4Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE4C LDA
    cpu.setA(0xFF00u, 16);
    goto L_82CE4F;
L_82CE4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE4Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE4Fu,cpu,0x0Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE4Fu, 8u, 3u, cpu.address("abs", 0x0884u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE4F TSB
    cpu.tsb(hw, cpu.address("abs", 0x884u), cpu.m8?8:16);
    goto L_82CE52;
L_82CE52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE52u,cpu,0x0Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE52u, 8u, 3u, cpu.address("abs", 0x0886u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE52 TSB
    cpu.tsb(hw, cpu.address("abs", 0x886u), cpu.m8?8:16);
    goto L_82CE55;
L_82CE55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE55u,cpu,0x0Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE55u, 8u, 3u, cpu.address("abs", 0x0888u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE55 TSB
    cpu.tsb(hw, cpu.address("abs", 0x888u), cpu.m8?8:16);
    goto L_82CE58;
L_82CE58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE58u,cpu,0x0Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE58u, 8u, 3u, cpu.address("abs", 0x088Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE58 TSB
    cpu.tsb(hw, cpu.address("abs", 0x88Au), cpu.m8?8:16);
    goto L_82CE5B;
L_82CE5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE5Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE5Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE5Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE5B LDA
    cpu.setA(0xDu, 16);
    goto L_82CE5E;
L_82CE5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE5Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE5Eu, 5u, 3u, cpu.address("abs", 0x0200u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE5E STA
    hw.write(cpu.address("abs", 0x200u), cpu.a, cpu.m8?8:16);
    goto L_82CE61;
L_82CE61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE61u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE61u, 8u, 3u, cpu.address("abs", 0x0816u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE61 INC
    cpu.incMem(hw, cpu.address("abs", 0x816u), cpu.m8?8:16);
    goto L_82CE64;
L_82CE64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE64u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE64u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82CE64 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82CE64u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82CE64u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82D373_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82D373u: goto L_82D373;
    case 0x82D376u: goto L_82D376;
    case 0x82D37Au: goto L_82D37A;
    case 0x82D37Du: goto L_82D37D;
    case 0x82D381u: goto L_82D381;
    case 0x82D384u: goto L_82D384;
    case 0x82D385u: goto L_82D385;
    case 0x82D386u: goto L_82D386;
    case 0x82D388u: goto L_82D388;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82D373:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD373u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD373u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD373u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D373 LDX
    cpu.setX(0x6u, 16);
    goto L_82D376;
L_82D376:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD376u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD376u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD376u, 6u, 4u, ((0x82D389u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D376 LDA
    cpu.loadA(hw.readW(((0x82D389u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D37A;
L_82D37A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD37Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD37Au,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD37Au, 6u, 3u, cpu.address("absx", 0x088Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D37A STA
    hw.write(cpu.address("absx", 0x88Cu), cpu.a, cpu.m8?8:16);
    goto L_82D37D;
L_82D37D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD37Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD37Du,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD37Du, 6u, 4u, ((0x82D391u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D37D LDA
    cpu.loadA(hw.readW(((0x82D391u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D381;
L_82D381:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD381u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD381u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD381u, 6u, 3u, cpu.address("absx", 0x0894u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D381 STA
    hw.write(cpu.address("absx", 0x894u), cpu.a, cpu.m8?8:16);
    goto L_82D384;
L_82D384:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD384u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD384u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD384u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D384 DEX
    cpu.decReg('X');
    goto L_82D385;
L_82D385:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD385u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD385u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD385u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D385 DEX
    cpu.decReg('X');
    goto L_82D386;
L_82D386:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD386u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD386u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD386u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D386 BPL -> $82D376
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82D376; }
    goto L_82D388;
L_82D388:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD388u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD388u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD388u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D388 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82D388u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82D388u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_8488CE_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8488CEu: goto L_8488CE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8488CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88CEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88CEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8488CE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8488CEu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8488CEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_8488CE_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8488CEu: goto L_8488CE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8488CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88CEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88CEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8488CE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8488CEu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8488CEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_848A10_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848A10u: goto L_848A10;
    case 0x848A12u: goto L_848A12;
    case 0x848A14u: goto L_848A14;
    case 0x848A15u: goto L_848A15;
    case 0x848A16u: goto L_848A16;
    case 0x848A18u: goto L_848A18;
    case 0x848A1Bu: goto L_848A1B;
    case 0x848A1Du: goto L_848A1D;
    case 0x848A1Fu: goto L_848A1F;
    case 0x848A21u: goto L_848A21;
    case 0x848A24u: goto L_848A24;
    case 0x848A27u: goto L_848A27;
    case 0x848A2Au: goto L_848A2A;
    case 0x848A2Cu: goto L_848A2C;
    case 0x848A2Fu: goto L_848A2F;
    case 0x848A31u: goto L_848A31;
    case 0x848A34u: goto L_848A34;
    case 0x848A36u: goto L_848A36;
    case 0x848A3Au: goto L_848A3A;
    case 0x848A3Bu: goto L_848A3B;
    case 0x848A3Du: goto L_848A3D;
    case 0x848A40u: goto L_848A40;
    case 0x848A43u: goto L_848A43;
    case 0x848A46u: goto L_848A46;
    case 0x848A48u: goto L_848A48;
    case 0x848A4Bu: goto L_848A4B;
    case 0x848A4Du: goto L_848A4D;
    case 0x848A50u: goto L_848A50;
    case 0x848A52u: goto L_848A52;
    case 0x848A56u: goto L_848A56;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848A10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A10u,cpu,0x16u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A10u, 8u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x8Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A10 ASL
    cpu.aslMem(hw, cpu.address("dpx", 0x8Au), cpu.m8?8:16);
    goto L_848A12;
L_848A12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A12u,cpu,0x57u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A12u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x8Au) & 0xFFFFu), 3u, 0u);
    // $848A12 EOR
    cpu.logicXor(hw.readW(cpu.addressDpLongY(hw, 0x8Au), cpu.m8?8:16));
    goto L_848A14;
L_848A14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A14u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A14u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A14 TYA
    cpu.transfer("TYA");
    goto L_848A15;
L_848A15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A15u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A15u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A15 TXA
    cpu.transfer("TXA");
    goto L_848A16;
L_848A16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A16u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A16u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A16 SEP
    cpu.sep(0x20u);
    goto L_848A18;
L_848A18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A18u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A18u, 4u, 3u, cpu.address("abs", 0x062Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A18 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848A1B;
L_848A1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A1Bu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A1Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A1B BIT
    cpu.bit(0x1u, true);
    goto L_848A1D;
L_848A1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A1Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A1Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A1D BNE -> $848A3B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_848A3B; }
    goto L_848A1F;
L_848A1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A1Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A1Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A1F REP
    cpu.rep(0x20u);
    goto L_848A21;
L_848A21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A21u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A21u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A21 LDX
    cpu.setX(0x2u, 16);
    goto L_848A24;
L_848A24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A24u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A24u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A24 LDY
    cpu.setY(0x6u, 16);
    goto L_848A27;
L_848A27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A27u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A27u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A27 LDA
    cpu.setA(0x2A9Au, 16);
    goto L_848A2A;
L_848A2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A2Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A2Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A2A STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_848A2C;
L_848A2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A2Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A2Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A2C LDA
    cpu.setA(0x7Eu, 16);
    goto L_848A2F;
L_848A2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A2Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A2Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A2F STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_848A31;
L_848A31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A31u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A31u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A31 LDA
    cpu.setA(0x1800u, 16);
    goto L_848A34;
L_848A34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A34u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A34u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A34 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_848A36;
L_848A36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A36u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A36u, 8u, 4u, 0x80A839u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848A36 JSL -> $80A839 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8A39u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8A3Au,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A839u, 0x848A36u); }
    goto L_848A3A;
L_848A3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A3Au))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8A3Au,0x848A3Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A3Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A3Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848A3A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848A3Au);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848A3Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_848A3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A3Bu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A3Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A3B REP
    cpu.rep(0x20u);
    goto L_848A3D;
L_848A3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A3Du,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A3Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A3D LDX
    cpu.setX(0x2u, 16);
    goto L_848A40;
L_848A40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A40u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A40u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A40 LDY
    cpu.setY(0x8u, 16);
    goto L_848A43;
L_848A43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A43u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A43u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A43 LDA
    cpu.setA(0x2AAAu, 16);
    goto L_848A46;
L_848A46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A46u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A46u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A46 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_848A48;
L_848A48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A48u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A48u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A48 LDA
    cpu.setA(0x7Eu, 16);
    goto L_848A4B;
L_848A4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A4Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A4Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A4B STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_848A4D;
L_848A4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A4Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A4Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A4D LDA
    cpu.setA(0x1800u, 16);
    goto L_848A50;
L_848A50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A50u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A50u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A50 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_848A52;
L_848A52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A52u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A52u, 8u, 4u, 0x80A839u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848A52 JSL -> $80A839 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8A55u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8A56u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A839u, 0x848A52u); }
    goto L_848A56;
L_848A56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A56u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8A56u,0x848A56u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A56u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A56u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848A56 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848A56u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848A56u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_848A10_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848A10u: goto L_848A10;
    case 0x848A12u: goto L_848A12;
    case 0x848A14u: goto L_848A14;
    case 0x848A15u: goto L_848A15;
    case 0x848A16u: goto L_848A16;
    case 0x848A18u: goto L_848A18;
    case 0x848A1Bu: goto L_848A1B;
    case 0x848A1Du: goto L_848A1D;
    case 0x848A1Fu: goto L_848A1F;
    case 0x848A21u: goto L_848A21;
    case 0x848A24u: goto L_848A24;
    case 0x848A27u: goto L_848A27;
    case 0x848A2Au: goto L_848A2A;
    case 0x848A2Cu: goto L_848A2C;
    case 0x848A2Fu: goto L_848A2F;
    case 0x848A31u: goto L_848A31;
    case 0x848A34u: goto L_848A34;
    case 0x848A36u: goto L_848A36;
    case 0x848A3Au: goto L_848A3A;
    case 0x848A3Bu: goto L_848A3B;
    case 0x848A3Du: goto L_848A3D;
    case 0x848A40u: goto L_848A40;
    case 0x848A43u: goto L_848A43;
    case 0x848A46u: goto L_848A46;
    case 0x848A48u: goto L_848A48;
    case 0x848A4Bu: goto L_848A4B;
    case 0x848A4Du: goto L_848A4D;
    case 0x848A50u: goto L_848A50;
    case 0x848A52u: goto L_848A52;
    case 0x848A56u: goto L_848A56;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848A10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A10u,cpu,0x16u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A10u, 8u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x8Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A10 ASL
    cpu.aslMem(hw, cpu.address("dpx", 0x8Au), cpu.m8?8:16);
    goto L_848A12;
L_848A12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A12u,cpu,0x57u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A12u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x8Au) & 0xFFFFu), 3u, 0u);
    // $848A12 EOR
    cpu.logicXor(hw.readW(cpu.addressDpLongY(hw, 0x8Au), cpu.m8?8:16));
    goto L_848A14;
L_848A14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A14u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A14u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A14 TYA
    cpu.transfer("TYA");
    goto L_848A15;
L_848A15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A15u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A15u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A15 TXA
    cpu.transfer("TXA");
    goto L_848A16;
L_848A16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A16u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A16u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A16 SEP
    cpu.sep(0x20u);
    goto L_848A18;
L_848A18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A18u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A18u, 4u, 3u, cpu.address("abs", 0x062Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A18 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848A1B;
L_848A1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A1Bu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A1Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A1B BIT
    cpu.bit(0x1u, true);
    goto L_848A1D;
L_848A1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A1Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A1Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A1D BNE -> $848A3B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_848A3B; }
    goto L_848A1F;
L_848A1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A1Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A1Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A1F REP
    cpu.rep(0x20u);
    goto L_848A21;
L_848A21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A21u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A21u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A21 LDX
    cpu.setX(0x2u, 16);
    goto L_848A24;
L_848A24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A24u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A24u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A24 LDY
    cpu.setY(0x6u, 16);
    goto L_848A27;
L_848A27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A27u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A27u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A27 LDA
    cpu.setA(0x2A9Au, 16);
    goto L_848A2A;
L_848A2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A2Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A2Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A2A STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_848A2C;
L_848A2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A2Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A2Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A2C LDA
    cpu.setA(0x7Eu, 16);
    goto L_848A2F;
L_848A2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A2Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A2Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A2F STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_848A31;
L_848A31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A31u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A31u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A31 LDA
    cpu.setA(0x1800u, 16);
    goto L_848A34;
L_848A34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A34u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A34u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A34 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_848A36;
L_848A36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A36u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A36u, 8u, 4u, 0x80A839u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848A36 JSL -> $80A839 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8A39u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8A3Au,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A839u, 0x848A36u); }
    goto L_848A3A;
L_848A3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A3Au))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8A3Au,0x848A3Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A3Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A3Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848A3A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848A3Au);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848A3Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_848A3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A3Bu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A3Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A3B REP
    cpu.rep(0x20u);
    goto L_848A3D;
L_848A3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A3Du,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A3Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A3D LDX
    cpu.setX(0x2u, 16);
    goto L_848A40;
L_848A40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A40u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A40u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A40 LDY
    cpu.setY(0x8u, 16);
    goto L_848A43;
L_848A43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A43u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A43u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A43 LDA
    cpu.setA(0x2AAAu, 16);
    goto L_848A46;
L_848A46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A46u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A46u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A46 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_848A48;
L_848A48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A48u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A48u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A48 LDA
    cpu.setA(0x7Eu, 16);
    goto L_848A4B;
L_848A4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A4Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A4Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A4B STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_848A4D;
L_848A4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A4Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A4Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A4D LDA
    cpu.setA(0x1800u, 16);
    goto L_848A50;
L_848A50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A50u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A50u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A50 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_848A52;
L_848A52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A52u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A52u, 8u, 4u, 0x80A839u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848A52 JSL -> $80A839 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8A55u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8A56u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A839u, 0x848A52u); }
    goto L_848A56;
L_848A56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A56u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8A56u,0x848A56u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A56u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A56u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848A56 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848A56u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848A56u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_8491A6_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8491A6u: goto L_8491A6;
    case 0x8491A8u: goto L_8491A8;
    case 0x8491ABu: goto L_8491AB;
    case 0x8491AEu: goto L_8491AE;
    case 0x8491B1u: goto L_8491B1;
    case 0x8491B3u: goto L_8491B3;
    case 0x8491B6u: goto L_8491B6;
    case 0x8491B8u: goto L_8491B8;
    case 0x8491BBu: goto L_8491BB;
    case 0x8491BDu: goto L_8491BD;
    case 0x8491C1u: goto L_8491C1;
    case 0x8491C4u: goto L_8491C4;
    case 0x8491C7u: goto L_8491C7;
    case 0x8491CAu: goto L_8491CA;
    case 0x8491CCu: goto L_8491CC;
    case 0x8491CFu: goto L_8491CF;
    case 0x8491D1u: goto L_8491D1;
    case 0x8491D4u: goto L_8491D4;
    case 0x8491D6u: goto L_8491D6;
    case 0x8491DAu: goto L_8491DA;
    case 0x8491DDu: goto L_8491DD;
    case 0x8491E0u: goto L_8491E0;
    case 0x8491E3u: goto L_8491E3;
    case 0x8491E5u: goto L_8491E5;
    case 0x8491E8u: goto L_8491E8;
    case 0x8491EAu: goto L_8491EA;
    case 0x8491EDu: goto L_8491ED;
    case 0x8491EFu: goto L_8491EF;
    case 0x8491F3u: goto L_8491F3;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8491A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91A6u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91A6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491A6 REP
    cpu.rep(0x20u);
    goto L_8491A8;
L_8491A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91A8u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91A8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491A8 LDX
    cpu.setX(0x2u, 16);
    goto L_8491AB;
L_8491AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91ABu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91ABu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491AB LDY
    cpu.setY(0x3u, 16);
    goto L_8491AE;
L_8491AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91AEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91AEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491AE LDA
    cpu.setA(0x2A98u, 16);
    goto L_8491B1;
L_8491B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491B1 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_8491B3;
L_8491B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491B3 LDA
    cpu.setA(0x7Eu, 16);
    goto L_8491B6;
L_8491B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491B6 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_8491B8;
L_8491B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491B8 LDA
    cpu.setA(0x1000u, 16);
    goto L_8491BB;
L_8491BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91BBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91BBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491BB STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_8491BD;
L_8491BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91BDu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91BDu, 8u, 4u, 0x80A839u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8491BD JSL -> $80A839 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x91C0u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x91C1u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A839u, 0x8491BDu); }
    goto L_8491C1;
L_8491C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91C1u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91C1u,0x8491C1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91C1u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91C1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491C1 LDX
    cpu.setX(0x2u, 16);
    goto L_8491C4;
L_8491C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91C4u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91C4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491C4 LDY
    cpu.setY(0x3u, 16);
    goto L_8491C7;
L_8491C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91C7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91C7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491C7 LDA
    cpu.setA(0x2AA4u, 16);
    goto L_8491CA;
L_8491CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91CAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91CAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491CA STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_8491CC;
L_8491CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91CCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91CCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491CC LDA
    cpu.setA(0x7Eu, 16);
    goto L_8491CF;
L_8491CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91CFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91CFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491CF STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_8491D1;
L_8491D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91D1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91D1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491D1 LDA
    cpu.setA(0x1000u, 16);
    goto L_8491D4;
L_8491D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91D4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91D4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491D4 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_8491D6;
L_8491D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91D6u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91D6u, 8u, 4u, 0x80A839u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8491D6 JSL -> $80A839 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x91D9u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x91DAu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A839u, 0x8491D6u); }
    goto L_8491DA;
L_8491DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91DAu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91DAu,0x8491DAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91DAu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91DAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491DA LDX
    cpu.setX(0x2u, 16);
    goto L_8491DD;
L_8491DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91DDu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91DDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491DD LDY
    cpu.setY(0x4u, 16);
    goto L_8491E0;
L_8491E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91E0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91E0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491E0 LDA
    cpu.setA(0x2AB0u, 16);
    goto L_8491E3;
L_8491E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91E3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91E3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491E3 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_8491E5;
L_8491E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91E5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91E5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491E5 LDA
    cpu.setA(0x7Eu, 16);
    goto L_8491E8;
L_8491E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91E8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91E8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491E8 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_8491EA;
L_8491EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91EAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91EAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491EA LDA
    cpu.setA(0x1000u, 16);
    goto L_8491ED;
L_8491ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91EDu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91EDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491ED STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_8491EF;
L_8491EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91EFu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91EFu, 8u, 4u, 0x80A839u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8491EF JSL -> $80A839 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x91F2u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x91F3u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A839u, 0x8491EFu); }
    goto L_8491F3;
L_8491F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91F3u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91F3u,0x8491F3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91F3u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91F3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8491F3 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8491F3u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8491F3u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_84984F_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84984Fu: goto L_84984F;
    case 0x849851u: goto L_849851;
    case 0x849853u: goto L_849853;
    case 0x849856u: goto L_849856;
    case 0x849858u: goto L_849858;
    case 0x84985Bu: goto L_84985B;
    case 0x84985Du: goto L_84985D;
    case 0x849860u: goto L_849860;
    case 0x849862u: goto L_849862;
    case 0x849863u: goto L_849863;
    case 0x849865u: goto L_849865;
    case 0x849867u: goto L_849867;
    case 0x849869u: goto L_849869;
    case 0x84986Cu: goto L_84986C;
    case 0x849870u: goto L_849870;
    case 0x849872u: goto L_849872;
    case 0x849875u: goto L_849875;
    case 0x849877u: goto L_849877;
    case 0x849878u: goto L_849878;
    case 0x84987Au: goto L_84987A;
    case 0x84987Eu: goto L_84987E;
    case 0x849880u: goto L_849880;
    case 0x849881u: goto L_849881;
    case 0x849883u: goto L_849883;
    case 0x849887u: goto L_849887;
    case 0x849889u: goto L_849889;
    case 0x84988Bu: goto L_84988B;
    case 0x84988Eu: goto L_84988E;
    case 0x849892u: goto L_849892;
    case 0x849894u: goto L_849894;
    case 0x849896u: goto L_849896;
    case 0x849897u: goto L_849897;
    case 0x849899u: goto L_849899;
    case 0x84989Du: goto L_84989D;
    case 0x84989Fu: goto L_84989F;
    case 0x8498A0u: goto L_8498A0;
    case 0x8498A2u: goto L_8498A2;
    case 0x8498A6u: goto L_8498A6;
    case 0x8498A8u: goto L_8498A8;
    case 0x8498A9u: goto L_8498A9;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84984F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x984Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x984Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x984Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84984F REP
    cpu.rep(0x20u);
    goto L_849851;
L_849851:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9851u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9851u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9851u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849851 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849853;
L_849853:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9853u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9853u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9853u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849853 BIT
    cpu.bit(0x1080u, true);
    goto L_849856;
L_849856:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9856u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9856u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9856u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849856 BNE -> $849889
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_849889; }
    goto L_849858;
L_849858:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9858u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9858u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9858u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849858 BIT
    cpu.bit(0x2000u, true);
    goto L_84985B;
L_84985B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x985Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x985Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x985Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84985B BNE -> $849867
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_849867; }
    goto L_84985D;
L_84985D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x985Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x985Du,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x985Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84985D BIT
    cpu.bit(0x8000u, true);
    goto L_849860;
L_849860:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9860u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9860u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9860u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849860 BNE -> $849865
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_849865; }
    goto L_849862;
L_849862:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9862u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9862u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9862u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849862 CLC
    cpu.setFlag('C', false);
    goto L_849863;
L_849863:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9863u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9863u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9863u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849863 BRA -> $8498A9
    goto L_8498A9;
L_849865:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9865u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9865u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9865u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849865 SEP
    cpu.sep(0x20u);
    goto L_849867;
L_849867:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9867u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9867u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9867u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849867 REP
    cpu.rep(0x20u);
    goto L_849869;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9867u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9867u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849867 REP
    cpu.rep(0x20u);
    goto L_849869;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9867u,0x849867u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849869:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9869u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9869u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9869u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849869 LDA
    cpu.setA(0x5u, 16);
    goto L_84986C;
L_84986C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x986Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x986Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x986Cu, 8u, 4u, 0x80A6FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84986C JSL -> $80A6FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x986Fu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9870u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6FBu, 0x84986Cu); }
    goto L_849870;
L_849870:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9870u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9870u,0x849870u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9870u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9870u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849870 SEP
    cpu.sep(0x20u);
    goto L_849872;
L_849872:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9872u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9872u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9872u, 6u, 3u, cpu.address("abs", 0x0657u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849872 INC
    cpu.incMem(hw, cpu.address("abs", 0x657u), cpu.m8?8:16);
    goto L_849875;
L_849875:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9875u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9875u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9875u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849875 LDA
    cpu.setA(0x81u, 8);
    goto L_849877;
L_849877:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9877u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9877u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9877u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849877 XBA
    cpu.xba();
    goto L_849878;
L_849878:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9878u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9878u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9878u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849878 LDA
    cpu.setA(0xFu, 8);
    goto L_84987A;
L_84987A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x987Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x987Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x987Au, 8u, 4u, 0x8086F4u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84987A JSL -> $8086F4 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x987Du); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x987Eu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8086F4u, 0x84987Au); }
    goto L_84987E;
L_84987E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x987Eu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x987Eu,0x84987Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x987Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x987Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84987E LDA
    cpu.setA(0x81u, 8);
    goto L_849880;
L_849880:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9880u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9880u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9880u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849880 XBA
    cpu.xba();
    goto L_849881;
L_849881:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9881u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9881u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9881u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849881 LDA
    cpu.setA(0x5u, 8);
    goto L_849883;
L_849883:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9883u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9883u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9883u, 8u, 4u, 0x808700u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849883 JSL -> $808700 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9886u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9887u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808700u, 0x849883u); }
    goto L_849887;
L_849887:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9887u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9887u,0x849887u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9887u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9887u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849887 BRA -> $8498A6
    goto L_8498A6;
L_849889:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9889u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9889u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9889u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849889 REP
    cpu.rep(0x20u);
    goto L_84988B;
L_84988B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x988Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x988Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x988Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84988B LDA
    cpu.setA(0x4u, 16);
    goto L_84988E;
L_84988E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x988Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x988Eu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x988Eu, 8u, 4u, 0x80A6FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84988E JSL -> $80A6FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9891u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9892u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6FBu, 0x84988Eu); }
    goto L_849892;
L_849892:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9892u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9892u,0x849892u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9892u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9892u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849892 SEP
    cpu.sep(0x20u);
    goto L_849894;
L_849894:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9894u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9894u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9894u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849894 LDA
    cpu.setA(0x81u, 8);
    goto L_849896;
L_849896:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9896u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9896u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9896u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849896 XBA
    cpu.xba();
    goto L_849897;
L_849897:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9897u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9897u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9897u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849897 LDA
    cpu.setA(0xFu, 8);
    goto L_849899;
L_849899:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9899u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9899u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9899u, 8u, 4u, 0x8086F4u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849899 JSL -> $8086F4 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x989Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x989Du,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8086F4u, 0x849899u); }
    goto L_84989D;
L_84989D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x989Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x989Du,0x84989Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x989Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x989Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84989D LDA
    cpu.setA(0x81u, 8);
    goto L_84989F;
L_84989F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x989Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x989Fu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x989Fu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84989F XBA
    cpu.xba();
    goto L_8498A0;
L_8498A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98A0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98A0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498A0 LDA
    cpu.setA(0x5u, 8);
    goto L_8498A2;
L_8498A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98A2u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98A2u, 8u, 4u, 0x808700u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8498A2 JSL -> $808700 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x98A5u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x98A6u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808700u, 0x8498A2u); }
    goto L_8498A6;
L_8498A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98A6u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x98A6u,0x8498A6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98A6u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98A6u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498A6 INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_8498A8;
L_8498A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98A8u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98A8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498A8 SEC
    cpu.setFlag('C', true);
    goto L_8498A9;
L_8498A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98A9u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98A9u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98A9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8498A9 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8498A9u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8498A9u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98A9u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98A9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8498A9 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8498A9u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8498A9u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x98A9u,0x8498A9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_849B2C_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x849B2Cu: goto L_849B2C;
    case 0x849B2Eu: goto L_849B2E;
    case 0x849B30u: goto L_849B30;
    case 0x849B33u: goto L_849B33;
    case 0x849B35u: goto L_849B35;
    case 0x849B38u: goto L_849B38;
    case 0x849B3Au: goto L_849B3A;
    case 0x849B3Du: goto L_849B3D;
    case 0x849B3Fu: goto L_849B3F;
    case 0x849B41u: goto L_849B41;
    case 0x849B43u: goto L_849B43;
    case 0x849B46u: goto L_849B46;
    case 0x849B48u: goto L_849B48;
    case 0x849B4Au: goto L_849B4A;
    case 0x849B4Du: goto L_849B4D;
    case 0x849B50u: goto L_849B50;
    case 0x849B52u: goto L_849B52;
    case 0x849B54u: goto L_849B54;
    case 0x849B57u: goto L_849B57;
    case 0x849B59u: goto L_849B59;
    case 0x849B5Cu: goto L_849B5C;
    case 0x849B5Eu: goto L_849B5E;
    case 0x849B61u: goto L_849B61;
    case 0x849B63u: goto L_849B63;
    case 0x849B66u: goto L_849B66;
    case 0x849B69u: goto L_849B69;
    case 0x849B6Cu: goto L_849B6C;
    case 0x849B6Eu: goto L_849B6E;
    case 0x849B71u: goto L_849B71;
    case 0x849B74u: goto L_849B74;
    case 0x849B76u: goto L_849B76;
    case 0x849B78u: goto L_849B78;
    case 0x849B7Bu: goto L_849B7B;
    case 0x849B7Du: goto L_849B7D;
    case 0x849B7Fu: goto L_849B7F;
    case 0x849B82u: goto L_849B82;
    case 0x849B84u: goto L_849B84;
    case 0x849B86u: goto L_849B86;
    case 0x849B88u: goto L_849B88;
    case 0x849B8Au: goto L_849B8A;
    case 0x849B8Du: goto L_849B8D;
    case 0x849B8Fu: goto L_849B8F;
    case 0x849B92u: goto L_849B92;
    case 0x849B94u: goto L_849B94;
    case 0x849B97u: goto L_849B97;
    case 0x849B99u: goto L_849B99;
    case 0x849B9Bu: goto L_849B9B;
    case 0x849B9Du: goto L_849B9D;
    case 0x849BA0u: goto L_849BA0;
    case 0x849BA2u: goto L_849BA2;
    case 0x849BA5u: goto L_849BA5;
    case 0x849BA9u: goto L_849BA9;
    case 0x849BACu: goto L_849BAC;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_849B2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B2Cu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B2Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B2C REP
    cpu.rep(0x20u);
    goto L_849B2E;
L_849B2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B2Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B2Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B2E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849B30;
L_849B30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B30u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B30u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B30 BIT
    cpu.bit(0x300u, true);
    goto L_849B33;
L_849B33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B33u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B33u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B33 BNE -> $849B3A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_849B3A; }
    goto L_849B35;
L_849B35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B35u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B35u, 5u, 3u, cpu.address("abs", 0x0662u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B35 STZ
    hw.write(cpu.address("abs", 0x662u), 0, cpu.m8?8:16);
    goto L_849B38;
L_849B38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B38u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B38u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B38 BRA -> $849BAC
    goto L_849BAC;
L_849B3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B3Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B3Au, 5u, 3u, cpu.address("abs", 0x0662u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B3A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x662u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849B3D;
L_849B3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B3Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B3Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B3D BEQ -> $849B4A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_849B4A; }
    goto L_849B3F;
L_849B3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B3Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B3Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x71u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B3F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x71u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849B41;
L_849B41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B41u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B41u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B41 BNE -> $849BAC
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_849BAC; }
    goto L_849B43;
L_849B43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B43u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B43u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B43 LDA
    cpu.setA(0x4u, 16);
    goto L_849B46;
L_849B46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B46u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B46u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x71u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B46 STA
    hw.write(cpu.address("dp", 0x71u), cpu.a, cpu.m8?8:16);
    goto L_849B48;
L_849B48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B48u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B48u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B48 BRA -> $849B52
    goto L_849B52;
L_849B4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B4Au,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B4Au, 8u, 3u, cpu.address("abs", 0x0662u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B4A INC
    cpu.incMem(hw, cpu.address("abs", 0x662u), cpu.m8?8:16);
    goto L_849B4D;
L_849B4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B4Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B4Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B4D LDA
    cpu.setA(0x10u, 16);
    goto L_849B50;
L_849B50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B50u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B50u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x71u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B50 STA
    hw.write(cpu.address("dp", 0x71u), cpu.a, cpu.m8?8:16);
    goto L_849B52;
L_849B52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B52u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B52u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B52 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849B54;
L_849B54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B54u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B54u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B54 BIT
    cpu.bit(0x100u, true);
    goto L_849B57;
L_849B57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B57u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B57u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B57 BNE -> $849B63
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_849B63; }
    goto L_849B59;
L_849B59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B59u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B59u, 9u, 3u, cpu.address("absx", 0x063Fu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B59 DEC
    cpu.decMem(hw, cpu.address("absx", 0x63Fu), cpu.m8?8:16);
    goto L_849B5C;
L_849B5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B5Cu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B5Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B5C BPL -> $849B76
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_849B76; }
    goto L_849B5E;
L_849B5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B5Eu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B5Eu, 6u, 3u, cpu.address("absx", 0x063Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B5E STZ
    hw.write(cpu.address("absx", 0x63Fu), 0, cpu.m8?8:16);
    goto L_849B61;
L_849B61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B61u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B61u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B61 BRA -> $849BAC
    goto L_849BAC;
L_849B63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B63u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B63u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B63u, 9u, 3u, cpu.address("absx", 0x063Fu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B63 INC
    cpu.incMem(hw, cpu.address("absx", 0x63Fu), cpu.m8?8:16);
    goto L_849B66;
L_849B66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B66u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B66u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B66u, 5u + 1u, 3u, cpu.address("absx", 0x063Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B66 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x63Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849B69;
L_849B69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B69u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B69u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B69 CMP
    cpu.compareA(0xFu);
    goto L_849B6C;
L_849B6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B6Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B6Cu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B6Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B6C BCC -> $849B76
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_849B76; }
    goto L_849B6E;
L_849B6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B6Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B6Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B6E LDA
    cpu.setA(0xEu, 16);
    goto L_849B71;
L_849B71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B71u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B71u, 6u, 3u, cpu.address("absx", 0x063Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B71 STA
    hw.write(cpu.address("absx", 0x63Fu), cpu.a, cpu.m8?8:16);
    goto L_849B74;
L_849B74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B74u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B74u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B74 BRA -> $849BAC
    goto L_849BAC;
L_849B76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B76u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B76u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x71u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B76 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x71u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849B78;
L_849B78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B78u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B78u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B78 CMP
    cpu.compareA(0x10u);
    goto L_849B7B;
L_849B7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B7Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B7Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B7B BEQ -> $849B9B
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_849B9B; }
    goto L_849B7D;
L_849B7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B7Du,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B7Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B7D SEP
    cpu.sep(0x20u);
    goto L_849B7F;
L_849B7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B7Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B7Fu, 4u, 3u, cpu.address("abs", 0x062Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B7F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849B82;
L_849B82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B82u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B82u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B82 BIT
    cpu.bit(0x1u, true);
    goto L_849B84;
L_849B84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B84u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B84u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B84 BNE -> $849B9B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_849B9B; }
    goto L_849B86;
L_849B86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B86u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B86u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B86 REP
    cpu.rep(0x20u);
    goto L_849B88;
L_849B88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B88u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B88u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B88u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B88 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849B8A;
L_849B8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B8Au,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B8Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B8A BIT
    cpu.bit(0x300u, true);
    goto L_849B8D;
L_849B8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B8Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B8Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B8D BEQ -> $849B9B
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_849B9B; }
    goto L_849B8F;
L_849B8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B8Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B8Fu, 5u, 3u, cpu.address("abs", 0x0647u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B8F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x647u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849B92;
L_849B92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B92u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B92u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B92 BEQ -> $849B9B
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_849B9B; }
    goto L_849B94;
L_849B94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B94u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B94u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B94 CMP
    cpu.compareA(0xEu);
    goto L_849B97;
L_849B97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B97u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B97u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B97 BCS -> $849B9B
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_849B9B; }
    goto L_849B99;
L_849B99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B99u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B99u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B99 BRA -> $849BAC
    goto L_849BAC;
L_849B9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B9Bu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B9Bu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B9Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B9B REP
    cpu.rep(0x20u);
    goto L_849B9D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B9Bu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B9Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B9B REP
    cpu.rep(0x20u);
    goto L_849B9D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9B9Bu,0x849B9Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849B9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B9Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B9Du, 5u, 3u, cpu.address("abs", 0x06F7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B9D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x6F7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849BA0;
L_849BA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BA0u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BA0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849BA0 BNE -> $849BAC
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_849BAC; }
    goto L_849BA2;
L_849BA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BA2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BA2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849BA2 LDA
    cpu.setA(0x7u, 16);
    goto L_849BA5;
L_849BA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BA5u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BA5u, 8u, 4u, 0x80A6FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849BA5 JSL -> $80A6FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9BA8u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9BA9u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6FBu, 0x849BA5u); }
    goto L_849BA9;
L_849BA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BA9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9BA9u,0x849BA9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BA9u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BA9u, 5u, 3u, cpu.address("abs", 0x06F7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849BA9 STZ
    hw.write(cpu.address("abs", 0x6F7u), 0, cpu.m8?8:16);
    goto L_849BAC;
L_849BAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BACu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BACu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849BAC RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x849BACu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x849BACu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_84B526_E0M1X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84B526u: goto L_84B526;
    case 0x84B528u: goto L_84B528;
    case 0x84B52Bu: goto L_84B52B;
    case 0x84B52Du: goto L_84B52D;
    case 0x84B530u: goto L_84B530;
    case 0x84B533u: goto L_84B533;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84B526:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB526u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB526u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB526u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B526 REP
    cpu.rep(0x20u);
    goto L_84B528;
L_84B528:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB528u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB528u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB528u, 6u, 3u, cpu.address("abs", 0xB93Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B528 JSR -> $84B93D stack real
    { cpu.push16Value(hw,0xB52Au); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB52Bu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB93Du), 0x84B528u); }
    goto L_84B52B;
L_84B52B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB52Bu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB52Bu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB52Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B52B BCS -> $84B533
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_84B533; }
    goto L_84B52D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB52Bu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB52Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B52B BCS -> $84B533
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_84B533; }
    goto L_84B52D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB52Bu,0x84B52Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84B52D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB52Du))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB52Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB52Du, 6u, 3u, cpu.address("abs", 0xB5C1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B52D JSR -> $84B5C1 stack real
    { cpu.push16Value(hw,0xB52Fu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB530u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB5C1u), 0x84B52Du); }
    goto L_84B530;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB52Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB52Du, 6u, 3u, cpu.address("abs", 0xB5C1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B52D JSR -> $84B5C1 stack real
    { cpu.push16Value(hw,0xB52Fu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB530u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB5C1u), 0x84B52Du); }
    goto L_84B530;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB52Du,0x84B52Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84B530:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB530u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB530u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB530u, 6u, 3u, cpu.address("abs", 0xB5F5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B530 JSR -> $84B5F5 stack real
    { cpu.push16Value(hw,0xB532u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB533u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB5F5u), 0x84B530u); }
    goto L_84B533;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB530u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB530u, 6u, 3u, cpu.address("abs", 0xB5F5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B530 JSR -> $84B5F5 stack real
    { cpu.push16Value(hw,0xB532u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB533u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB5F5u), 0x84B530u); }
    goto L_84B533;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB530u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB530u, 6u, 3u, cpu.address("abs", 0xB5F5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B530 JSR -> $84B5F5 stack real
    { cpu.push16Value(hw,0xB532u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB533u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB5F5u), 0x84B530u); }
    goto L_84B533;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB530u,0x84B530u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84B533:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB533u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB533u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB533u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B533 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84B533u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84B533u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB533u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB533u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B533 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84B533u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84B533u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB533u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB533u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B533 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84B533u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84B533u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB533u,0x84B533u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_84B526_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84B526u: goto L_84B526;
    case 0x84B528u: goto L_84B528;
    case 0x84B52Bu: goto L_84B52B;
    case 0x84B52Du: goto L_84B52D;
    case 0x84B530u: goto L_84B530;
    case 0x84B533u: goto L_84B533;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84B526:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB526u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB526u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB526u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B526 REP
    cpu.rep(0x20u);
    goto L_84B528;
L_84B528:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB528u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB528u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB528u, 6u, 3u, cpu.address("abs", 0xB93Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B528 JSR -> $84B93D stack real
    { cpu.push16Value(hw,0xB52Au); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB52Bu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB93Du), 0x84B528u); }
    goto L_84B52B;
L_84B52B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB52Bu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB52Bu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB52Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B52B BCS -> $84B533
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_84B533; }
    goto L_84B52D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB52Bu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB52Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B52B BCS -> $84B533
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_84B533; }
    goto L_84B52D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB52Bu,0x84B52Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84B52D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB52Du))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB52Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB52Du, 6u, 3u, cpu.address("abs", 0xB5C1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B52D JSR -> $84B5C1 stack real
    { cpu.push16Value(hw,0xB52Fu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB530u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB5C1u), 0x84B52Du); }
    goto L_84B530;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB52Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB52Du, 6u, 3u, cpu.address("abs", 0xB5C1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B52D JSR -> $84B5C1 stack real
    { cpu.push16Value(hw,0xB52Fu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB530u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB5C1u), 0x84B52Du); }
    goto L_84B530;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB52Du,0x84B52Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84B530:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB530u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB530u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB530u, 6u, 3u, cpu.address("abs", 0xB5F5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B530 JSR -> $84B5F5 stack real
    { cpu.push16Value(hw,0xB532u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB533u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB5F5u), 0x84B530u); }
    goto L_84B533;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB530u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB530u, 6u, 3u, cpu.address("abs", 0xB5F5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B530 JSR -> $84B5F5 stack real
    { cpu.push16Value(hw,0xB532u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB533u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB5F5u), 0x84B530u); }
    goto L_84B533;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB530u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB530u, 6u, 3u, cpu.address("abs", 0xB5F5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B530 JSR -> $84B5F5 stack real
    { cpu.push16Value(hw,0xB532u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB533u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB5F5u), 0x84B530u); }
    goto L_84B533;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB530u,0x84B530u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84B533:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB533u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB533u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB533u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B533 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84B533u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84B533u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB533u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB533u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B533 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84B533u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84B533u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB533u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB533u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B533 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84B533u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84B533u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB533u,0x84B533u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_84BEA2_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84BEA2u: goto L_84BEA2;
    case 0x84BEA4u: goto L_84BEA4;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84BEA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEA2u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEA2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEA2 REP
    cpu.rep(0x20u);
    goto L_84BEA4;
L_84BEA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEA4u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEA4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84BEA4 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x84BEA4u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84BEA4u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_84BEA2_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84BEA2u: goto L_84BEA2;
    case 0x84BEA4u: goto L_84BEA4;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84BEA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEA2u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEA2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEA2 REP
    cpu.rep(0x20u);
    goto L_84BEA4;
L_84BEA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEA4u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEA4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84BEA4 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x84BEA4u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84BEA4u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_84C0F4_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84C0F4u: goto L_84C0F4;
    case 0x84C0F6u: goto L_84C0F6;
    case 0x84C0F9u: goto L_84C0F9;
    case 0x84C0FCu: goto L_84C0FC;
    case 0x84C0FFu: goto L_84C0FF;
    case 0x84C102u: goto L_84C102;
    case 0x84C105u: goto L_84C105;
    case 0x84C108u: goto L_84C108;
    case 0x84C10Cu: goto L_84C10C;
    case 0x84C10Fu: goto L_84C10F;
    case 0x84C112u: goto L_84C112;
    case 0x84C115u: goto L_84C115;
    case 0x84C118u: goto L_84C118;
    case 0x84C11Cu: goto L_84C11C;
    case 0x84C11Fu: goto L_84C11F;
    case 0x84C123u: goto L_84C123;
    case 0x84C127u: goto L_84C127;
    case 0x84C129u: goto L_84C129;
    case 0x84C12Bu: goto L_84C12B;
    case 0x84C12Cu: goto L_84C12C;
    case 0x84C12Fu: goto L_84C12F;
    case 0x84C132u: goto L_84C132;
    case 0x84C135u: goto L_84C135;
    case 0x84C139u: goto L_84C139;
    case 0x84C13Cu: goto L_84C13C;
    case 0x84C13Fu: goto L_84C13F;
    case 0x84C142u: goto L_84C142;
    case 0x84C145u: goto L_84C145;
    case 0x84C148u: goto L_84C148;
    case 0x84C14Bu: goto L_84C14B;
    case 0x84C14Eu: goto L_84C14E;
    case 0x84C151u: goto L_84C151;
    case 0x84C154u: goto L_84C154;
    case 0x84C157u: goto L_84C157;
    case 0x84C159u: goto L_84C159;
    case 0x84C15Cu: goto L_84C15C;
    case 0x84C15Fu: goto L_84C15F;
    case 0x84C161u: goto L_84C161;
    case 0x84C164u: goto L_84C164;
    case 0x84C168u: goto L_84C168;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84C0F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0F4u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0F4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C0F4 REP
    cpu.rep(0x20u);
    goto L_84C0F6;
L_84C0F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0F6u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0F6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C0F6 LDX
    cpu.setX(0x8000u, 16);
    goto L_84C0F9;
L_84C0F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0F9u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0F9u, 5u, 3u, cpu.address("abs", 0x00B9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C0F9 STX
    hw.write(cpu.address("abs", 0xB9u), cpu.x, cpu.x8?8:16);
    goto L_84C0FC;
L_84C0FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0FCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0FCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C0FC LDA
    cpu.setA(0x7Eu, 16);
    goto L_84C0FF;
L_84C0FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0FFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0FFu, 5u, 3u, cpu.address("abs", 0x00BBu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C0FF STA
    hw.write(cpu.address("abs", 0xBBu), cpu.a, cpu.m8?8:16);
    goto L_84C102;
L_84C102:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC102u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC102u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC102u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C102 LDX
    cpu.setX(0x1000u, 16);
    goto L_84C105;
L_84C105:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC105u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC105u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC105u, 5u, 3u, cpu.address("abs", 0x00BDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C105 STX
    hw.write(cpu.address("abs", 0xBDu), cpu.x, cpu.x8?8:16);
    goto L_84C108;
L_84C108:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC108u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC108u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC108u, 8u, 4u, 0x8097FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84C108 JSL -> $8097FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC10Bu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC10Cu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8097FBu, 0x84C108u); }
    goto L_84C10C;
L_84C10C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC10Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC10Cu,0x84C10Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC10Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC10Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C10C LDA
    cpu.setA(0xD85Cu, 16);
    goto L_84C10F;
L_84C10F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC10Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC10Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC10Fu, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C10F STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_84C112;
L_84C112:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC112u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC112u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC112u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C112 LDA
    cpu.setA(0x9Eu, 16);
    goto L_84C115;
L_84C115:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC115u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC115u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC115u, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C115 STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_84C118;
L_84C118:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC118u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC118u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC118u, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84C118 JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC11Bu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC11Cu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x84C118u); }
    goto L_84C11C;
L_84C11C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC11Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC11Cu,0x84C11Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC11Cu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC11Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C11C LDY
    cpu.setY(0x9000u, 16);
    goto L_84C11F;
L_84C11F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC11Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC11Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC11Fu, 8u, 4u, 0x809887u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84C11F JSL -> $809887 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC122u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC123u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809887u, 0x84C11Fu); }
    goto L_84C123;
L_84C123:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC123u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC123u,0x84C123u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC123u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC123u, 8u, 4u, 0x809850u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84C123 JSL -> $809850 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC126u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC127u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809850u, 0x84C123u); }
    goto L_84C127;
L_84C127:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC127u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC127u,0x84C127u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC127u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC127u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C127 SEP
    cpu.sep(0x20u);
    goto L_84C129;
L_84C129:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC129u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC129u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC129u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C129 LDA
    cpu.setA(0x7Fu, 8);
    goto L_84C12B;
L_84C12B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC12Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC12Bu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC12Bu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $84C12B PHA
    cpu.push("PHA", hw);
    goto L_84C12C;
L_84C12C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC12Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC12Cu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC12Cu, 5u, 3u, cpu.address("abs", 0x0000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84C12C PEA
    cpu.push16Value(hw, 0x0u);
    goto L_84C12F;
L_84C12F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC12Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC12Fu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC12Fu, 5u, 3u, cpu.address("abs", 0x0000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84C12F PEA
    cpu.push16Value(hw, 0x0u);
    goto L_84C132;
L_84C132:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC132u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC132u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC132u, 5u, 3u, cpu.address("abs", 0x6000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84C132 PEA
    cpu.push16Value(hw, 0x6000u);
    goto L_84C135;
L_84C135:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC135u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC135u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC135u, 8u, 4u, 0x809B54u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84C135 JSL -> $809B54 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC138u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC139u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809B54u, 0x84C135u); }
    goto L_84C139;
L_84C139:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC139u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC139u,0x84C139u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC139u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC139u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C139 LDX
    cpu.setX(0x100u, 16);
    goto L_84C13C;
L_84C13C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC13Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC13Cu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC13Cu, 5u, 3u, cpu.address("abs", 0x0100u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C13C STX
    hw.write(cpu.address("abs", 0x100u), cpu.x, cpu.x8?8:16);
    goto L_84C13F;
L_84C13F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC13Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC13Fu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC13Fu, 5u, 3u, cpu.address("abs", 0x0106u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C13F STX
    hw.write(cpu.address("abs", 0x106u), cpu.x, cpu.x8?8:16);
    goto L_84C142;
L_84C142:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC142u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC142u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC142u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C142 LDX
    cpu.setX(0x0u, 16);
    goto L_84C145;
L_84C145:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC145u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC145u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC145u, 5u, 3u, cpu.address("abs", 0x0102u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C145 STX
    hw.write(cpu.address("abs", 0x102u), cpu.x, cpu.x8?8:16);
    goto L_84C148;
L_84C148:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC148u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC148u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC148u, 5u, 3u, cpu.address("abs", 0x0104u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C148 STX
    hw.write(cpu.address("abs", 0x104u), cpu.x, cpu.x8?8:16);
    goto L_84C14B;
L_84C14B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC14Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC14Bu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC14Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C14B LDX
    cpu.setX(0x80u, 16);
    goto L_84C14E;
L_84C14E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC14Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC14Eu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC14Eu, 5u, 3u, cpu.address("abs", 0x0108u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C14E STX
    hw.write(cpu.address("abs", 0x108u), cpu.x, cpu.x8?8:16);
    goto L_84C151;
L_84C151:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC151u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC151u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC151u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C151 LDX
    cpu.setX(0x30u, 16);
    goto L_84C154;
L_84C154:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC154u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC154u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC154u, 5u, 3u, cpu.address("abs", 0x010Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C154 STX
    hw.write(cpu.address("abs", 0x10Au), cpu.x, cpu.x8?8:16);
    goto L_84C157;
L_84C157:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC157u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC157u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC157u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C157 SEP
    cpu.sep(0x20u);
    goto L_84C159;
L_84C159:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC159u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC159u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC159u, 4u, 3u, cpu.address("abs", 0x06E2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C159 STZ
    hw.write(cpu.address("abs", 0x6E2u), 0, cpu.m8?8:16);
    goto L_84C15C;
L_84C15C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC15Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC15Cu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC15Cu, 4u, 3u, cpu.address("abs", 0x06E4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C15C STZ
    hw.write(cpu.address("abs", 0x6E4u), 0, cpu.m8?8:16);
    goto L_84C15F;
L_84C15F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC15Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC15Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC15Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C15F REP
    cpu.rep(0x20u);
    goto L_84C161;
L_84C161:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC161u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC161u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC161u, 5u, 3u, cpu.address("abs", 0x0112u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C161 STZ
    hw.write(cpu.address("abs", 0x112u), 0, cpu.m8?8:16);
    goto L_84C164;
L_84C164:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC164u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC164u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC164u, 8u, 4u, 0x8098BBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84C164 JSL -> $8098BB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC167u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC168u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8098BBu, 0x84C164u); }
    goto L_84C168;
L_84C168:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC168u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC168u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC168u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84C168 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84C168u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84C168u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC168u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC168u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84C168 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84C168u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84C168u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC168u,0x84C168u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_84C0F4_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84C0F4u: goto L_84C0F4;
    case 0x84C0F6u: goto L_84C0F6;
    case 0x84C0F9u: goto L_84C0F9;
    case 0x84C0FCu: goto L_84C0FC;
    case 0x84C0FFu: goto L_84C0FF;
    case 0x84C102u: goto L_84C102;
    case 0x84C105u: goto L_84C105;
    case 0x84C108u: goto L_84C108;
    case 0x84C10Cu: goto L_84C10C;
    case 0x84C10Fu: goto L_84C10F;
    case 0x84C112u: goto L_84C112;
    case 0x84C115u: goto L_84C115;
    case 0x84C118u: goto L_84C118;
    case 0x84C11Cu: goto L_84C11C;
    case 0x84C11Fu: goto L_84C11F;
    case 0x84C123u: goto L_84C123;
    case 0x84C127u: goto L_84C127;
    case 0x84C129u: goto L_84C129;
    case 0x84C12Bu: goto L_84C12B;
    case 0x84C12Cu: goto L_84C12C;
    case 0x84C12Fu: goto L_84C12F;
    case 0x84C132u: goto L_84C132;
    case 0x84C135u: goto L_84C135;
    case 0x84C139u: goto L_84C139;
    case 0x84C13Cu: goto L_84C13C;
    case 0x84C13Fu: goto L_84C13F;
    case 0x84C142u: goto L_84C142;
    case 0x84C145u: goto L_84C145;
    case 0x84C148u: goto L_84C148;
    case 0x84C14Bu: goto L_84C14B;
    case 0x84C14Eu: goto L_84C14E;
    case 0x84C151u: goto L_84C151;
    case 0x84C154u: goto L_84C154;
    case 0x84C157u: goto L_84C157;
    case 0x84C159u: goto L_84C159;
    case 0x84C15Cu: goto L_84C15C;
    case 0x84C15Fu: goto L_84C15F;
    case 0x84C161u: goto L_84C161;
    case 0x84C164u: goto L_84C164;
    case 0x84C168u: goto L_84C168;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84C0F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0F4u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0F4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C0F4 REP
    cpu.rep(0x20u);
    goto L_84C0F6;
L_84C0F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0F6u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0F6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C0F6 LDX
    cpu.setX(0x8000u, 16);
    goto L_84C0F9;
L_84C0F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0F9u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0F9u, 5u, 3u, cpu.address("abs", 0x00B9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C0F9 STX
    hw.write(cpu.address("abs", 0xB9u), cpu.x, cpu.x8?8:16);
    goto L_84C0FC;
L_84C0FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0FCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0FCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C0FC LDA
    cpu.setA(0x7Eu, 16);
    goto L_84C0FF;
L_84C0FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0FFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0FFu, 5u, 3u, cpu.address("abs", 0x00BBu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C0FF STA
    hw.write(cpu.address("abs", 0xBBu), cpu.a, cpu.m8?8:16);
    goto L_84C102;
L_84C102:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC102u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC102u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC102u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C102 LDX
    cpu.setX(0x1000u, 16);
    goto L_84C105;
L_84C105:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC105u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC105u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC105u, 5u, 3u, cpu.address("abs", 0x00BDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C105 STX
    hw.write(cpu.address("abs", 0xBDu), cpu.x, cpu.x8?8:16);
    goto L_84C108;
L_84C108:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC108u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC108u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC108u, 8u, 4u, 0x8097FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84C108 JSL -> $8097FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC10Bu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC10Cu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8097FBu, 0x84C108u); }
    goto L_84C10C;
L_84C10C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC10Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC10Cu,0x84C10Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC10Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC10Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C10C LDA
    cpu.setA(0xD85Cu, 16);
    goto L_84C10F;
L_84C10F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC10Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC10Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC10Fu, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C10F STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_84C112;
L_84C112:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC112u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC112u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC112u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C112 LDA
    cpu.setA(0x9Eu, 16);
    goto L_84C115;
L_84C115:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC115u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC115u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC115u, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C115 STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_84C118;
L_84C118:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC118u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC118u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC118u, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84C118 JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC11Bu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC11Cu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x84C118u); }
    goto L_84C11C;
L_84C11C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC11Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC11Cu,0x84C11Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC11Cu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC11Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C11C LDY
    cpu.setY(0x9000u, 16);
    goto L_84C11F;
L_84C11F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC11Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC11Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC11Fu, 8u, 4u, 0x809887u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84C11F JSL -> $809887 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC122u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC123u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809887u, 0x84C11Fu); }
    goto L_84C123;
L_84C123:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC123u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC123u,0x84C123u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC123u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC123u, 8u, 4u, 0x809850u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84C123 JSL -> $809850 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC126u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC127u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809850u, 0x84C123u); }
    goto L_84C127;
L_84C127:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC127u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC127u,0x84C127u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC127u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC127u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C127 SEP
    cpu.sep(0x20u);
    goto L_84C129;
L_84C129:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC129u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC129u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC129u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C129 LDA
    cpu.setA(0x7Fu, 8);
    goto L_84C12B;
L_84C12B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC12Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC12Bu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC12Bu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $84C12B PHA
    cpu.push("PHA", hw);
    goto L_84C12C;
L_84C12C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC12Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC12Cu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC12Cu, 5u, 3u, cpu.address("abs", 0x0000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84C12C PEA
    cpu.push16Value(hw, 0x0u);
    goto L_84C12F;
L_84C12F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC12Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC12Fu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC12Fu, 5u, 3u, cpu.address("abs", 0x0000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84C12F PEA
    cpu.push16Value(hw, 0x0u);
    goto L_84C132;
L_84C132:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC132u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC132u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC132u, 5u, 3u, cpu.address("abs", 0x6000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84C132 PEA
    cpu.push16Value(hw, 0x6000u);
    goto L_84C135;
L_84C135:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC135u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC135u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC135u, 8u, 4u, 0x809B54u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84C135 JSL -> $809B54 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC138u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC139u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809B54u, 0x84C135u); }
    goto L_84C139;
L_84C139:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC139u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC139u,0x84C139u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC139u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC139u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C139 LDX
    cpu.setX(0x100u, 16);
    goto L_84C13C;
L_84C13C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC13Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC13Cu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC13Cu, 5u, 3u, cpu.address("abs", 0x0100u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C13C STX
    hw.write(cpu.address("abs", 0x100u), cpu.x, cpu.x8?8:16);
    goto L_84C13F;
L_84C13F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC13Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC13Fu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC13Fu, 5u, 3u, cpu.address("abs", 0x0106u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C13F STX
    hw.write(cpu.address("abs", 0x106u), cpu.x, cpu.x8?8:16);
    goto L_84C142;
L_84C142:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC142u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC142u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC142u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C142 LDX
    cpu.setX(0x0u, 16);
    goto L_84C145;
L_84C145:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC145u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC145u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC145u, 5u, 3u, cpu.address("abs", 0x0102u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C145 STX
    hw.write(cpu.address("abs", 0x102u), cpu.x, cpu.x8?8:16);
    goto L_84C148;
L_84C148:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC148u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC148u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC148u, 5u, 3u, cpu.address("abs", 0x0104u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C148 STX
    hw.write(cpu.address("abs", 0x104u), cpu.x, cpu.x8?8:16);
    goto L_84C14B;
L_84C14B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC14Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC14Bu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC14Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C14B LDX
    cpu.setX(0x80u, 16);
    goto L_84C14E;
L_84C14E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC14Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC14Eu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC14Eu, 5u, 3u, cpu.address("abs", 0x0108u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C14E STX
    hw.write(cpu.address("abs", 0x108u), cpu.x, cpu.x8?8:16);
    goto L_84C151;
L_84C151:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC151u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC151u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC151u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C151 LDX
    cpu.setX(0x30u, 16);
    goto L_84C154;
L_84C154:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC154u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC154u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC154u, 5u, 3u, cpu.address("abs", 0x010Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C154 STX
    hw.write(cpu.address("abs", 0x10Au), cpu.x, cpu.x8?8:16);
    goto L_84C157;
L_84C157:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC157u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC157u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC157u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C157 SEP
    cpu.sep(0x20u);
    goto L_84C159;
L_84C159:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC159u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC159u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC159u, 4u, 3u, cpu.address("abs", 0x06E2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C159 STZ
    hw.write(cpu.address("abs", 0x6E2u), 0, cpu.m8?8:16);
    goto L_84C15C;
L_84C15C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC15Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC15Cu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC15Cu, 4u, 3u, cpu.address("abs", 0x06E4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C15C STZ
    hw.write(cpu.address("abs", 0x6E4u), 0, cpu.m8?8:16);
    goto L_84C15F;
L_84C15F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC15Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC15Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC15Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C15F REP
    cpu.rep(0x20u);
    goto L_84C161;
L_84C161:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC161u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC161u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC161u, 5u, 3u, cpu.address("abs", 0x0112u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C161 STZ
    hw.write(cpu.address("abs", 0x112u), 0, cpu.m8?8:16);
    goto L_84C164;
L_84C164:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC164u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC164u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC164u, 8u, 4u, 0x8098BBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84C164 JSL -> $8098BB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC167u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC168u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8098BBu, 0x84C164u); }
    goto L_84C168;
L_84C168:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC168u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC168u,0x84C168u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC168u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC168u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84C168 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84C168u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84C168u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_F7B1B8_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xF7B1B8u: goto L_F7B1B8;
    case 0xF7B1B9u: goto L_F7B1B9;
    case 0xF7B1BAu: goto L_F7B1BA;
    case 0xF7B1BBu: goto L_F7B1BB;
    case 0xF7B1BCu: goto L_F7B1BC;
    case 0xF7B1BDu: goto L_F7B1BD;
    case 0xF7B1BFu: goto L_F7B1BF;
    case 0xF7B1EFu: goto L_F7B1EF;
    case 0xF7B1F1u: goto L_F7B1F1;
    case 0xF7B1F4u: goto L_F7B1F4;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_F7B1B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1B8u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1B8u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $F7B1B8 PHP
    cpu.push("PHP", hw);
    goto L_F7B1B9;
L_F7B1B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1B9u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1B9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $F7B1B9 CLC
    cpu.setFlag('C', false);
    goto L_F7B1BA;
L_F7B1BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1BAu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1BAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $F7B1BA CLC
    cpu.setFlag('C', false);
    goto L_F7B1BB;
L_F7B1BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1BBu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1BBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $F7B1BB SEC
    cpu.setFlag('C', true);
    goto L_F7B1BC;
L_F7B1BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1BCu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1BCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $F7B1BC SEC
    cpu.setFlag('C', true);
    goto L_F7B1BD;
L_F7B1BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1BDu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1BDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $F7B1BD BMI -> $F7B1EF
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_F7B1EF; }
    goto L_F7B1BF;
L_F7B1BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1BFu,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1BFu, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $F7B1BF BRK
    hw.partial(0xF7B1BFu, "BRK"); return;
L_F7B1EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1EFu,cpu,0x01u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1EFu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xE0u + cpu.x) & 0xFFFFu), 2u, 0u);
    // $F7B1EF ORA
    cpu.logicOr(hw.readW(cpu.addressDpIndirectX(hw, 0xE0u), cpu.m8?8:16));
    goto L_F7B1F1;
L_F7B1F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F1u,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F1u, 5u, 3u, cpu.address("abs", 0x1BEFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $F7B1F1 ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x1BEFu), cpu.m8?8:16));
    goto L_F7B1F4;
L_F7B1F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F4u,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F4u, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $F7B1F4 BRK
    hw.partial(0xF7B1F4u, "BRK"); return;
}

