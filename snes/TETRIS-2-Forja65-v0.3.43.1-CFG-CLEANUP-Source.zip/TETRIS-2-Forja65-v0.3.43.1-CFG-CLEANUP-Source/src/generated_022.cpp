#include "generated.hpp"
void sub_808556_E0M0X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808556u: goto L_808556;
    case 0x808557u: goto L_808557;
    case 0x808559u: goto L_808559;
    case 0x80855Bu: goto L_80855B;
    case 0x80855Du: goto L_80855D;
    case 0x808560u: goto L_808560;
    case 0x808562u: goto L_808562;
    case 0x808563u: goto L_808563;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808556:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8556u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8556u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8556u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808556 PHP
    cpu.push("PHP", hw);
    goto L_808557;
L_808557:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8557u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8557u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8557u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808557 SEP
    cpu.sep(0x24u);
    goto L_808559;
L_808559:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8559u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8559u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8559u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x73u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808559 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x73u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80855B;
L_80855B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x855Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x855Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x855Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80855B AND
    cpu.logicAnd(0xEu);
    goto L_80855D;
L_80855D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x855Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x855Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x855Du, 4u, 3u, cpu.address("abs", 0x4200u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80855D STA
    hw.write(cpu.address("abs", 0x4200u), cpu.a, cpu.m8?8:16);
    goto L_808560;
L_808560:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8560u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8560u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8560u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x73u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808560 STA
    hw.write(cpu.address("dp", 0x73u), cpu.a, cpu.m8?8:16);
    goto L_808562;
L_808562:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8562u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8562u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8562u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808562 PLP
    cpu.pop("PLP", hw);
    goto L_808563;
L_808563:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8563u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8563u,0x808563u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8563u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8563u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808563 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808563u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x808563u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_8085AD_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8085ADu: goto L_8085AD;
    case 0x8085AFu: goto L_8085AF;
    case 0x8085B2u: goto L_8085B2;
    case 0x8085B4u: goto L_8085B4;
    case 0x8085B7u: goto L_8085B7;
    case 0x8085B9u: goto L_8085B9;
    case 0x8085BCu: goto L_8085BC;
    case 0x8085BEu: goto L_8085BE;
    case 0x8085C1u: goto L_8085C1;
    case 0x8085C3u: goto L_8085C3;
    case 0x8085C6u: goto L_8085C6;
    case 0x8085C8u: goto L_8085C8;
    case 0x8085CBu: goto L_8085CB;
    case 0x8085CDu: goto L_8085CD;
    case 0x8085D0u: goto L_8085D0;
    case 0x8085D2u: goto L_8085D2;
    case 0x8085D5u: goto L_8085D5;
    case 0x8085D7u: goto L_8085D7;
    case 0x8085DAu: goto L_8085DA;
    case 0x8085DCu: goto L_8085DC;
    case 0x8085DFu: goto L_8085DF;
    case 0x8085E1u: goto L_8085E1;
    case 0x8085E4u: goto L_8085E4;
    case 0x8085E6u: goto L_8085E6;
    case 0x8085E9u: goto L_8085E9;
    case 0x8085EBu: goto L_8085EB;
    case 0x8085EEu: goto L_8085EE;
    case 0x8085F0u: goto L_8085F0;
    case 0x8085F3u: goto L_8085F3;
    case 0x8085F5u: goto L_8085F5;
    case 0x8085F8u: goto L_8085F8;
    case 0x8085FAu: goto L_8085FA;
    case 0x8085FDu: goto L_8085FD;
    case 0x808600u: goto L_808600;
    case 0x808603u: goto L_808603;
    case 0x808606u: goto L_808606;
    case 0x808609u: goto L_808609;
    case 0x80860Cu: goto L_80860C;
    case 0x80860Fu: goto L_80860F;
    case 0x808612u: goto L_808612;
    case 0x808615u: goto L_808615;
    case 0x808618u: goto L_808618;
    case 0x80861Bu: goto L_80861B;
    case 0x80861Eu: goto L_80861E;
    case 0x808621u: goto L_808621;
    case 0x808624u: goto L_808624;
    case 0x808627u: goto L_808627;
    case 0x80862Au: goto L_80862A;
    case 0x80862Du: goto L_80862D;
    case 0x808630u: goto L_808630;
    case 0x808633u: goto L_808633;
    case 0x808636u: goto L_808636;
    case 0x808639u: goto L_808639;
    case 0x80863Cu: goto L_80863C;
    case 0x80863Fu: goto L_80863F;
    case 0x808642u: goto L_808642;
    case 0x808645u: goto L_808645;
    case 0x808647u: goto L_808647;
    case 0x80864Au: goto L_80864A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8085AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85ADu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85ADu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085AD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085AF;
L_8085AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85AFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85AFu, 4u, 3u, cpu.address("abs", 0x210Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085AF STA
    hw.write(cpu.address("abs", 0x210Du), cpu.a, cpu.m8?8:16);
    goto L_8085B2;
L_8085B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85B2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85B2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085B2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085B4;
L_8085B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85B4u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85B4u, 4u, 3u, cpu.address("abs", 0x210Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085B4 STA
    hw.write(cpu.address("abs", 0x210Du), cpu.a, cpu.m8?8:16);
    goto L_8085B7;
L_8085B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85B7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85B7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x80u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085B7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x80u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085B9;
L_8085B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85B9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85B9u, 4u, 3u, cpu.address("abs", 0x210Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085B9 STA
    hw.write(cpu.address("abs", 0x210Eu), cpu.a, cpu.m8?8:16);
    goto L_8085BC;
L_8085BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85BCu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85BCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x81u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085BC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x81u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085BE;
L_8085BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85BEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85BEu, 4u, 3u, cpu.address("abs", 0x210Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085BE STA
    hw.write(cpu.address("abs", 0x210Eu), cpu.a, cpu.m8?8:16);
    goto L_8085C1;
L_8085C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85C1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85C1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x82u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085C1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x82u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085C3;
L_8085C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85C3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85C3u, 4u, 3u, cpu.address("abs", 0x210Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085C3 STA
    hw.write(cpu.address("abs", 0x210Fu), cpu.a, cpu.m8?8:16);
    goto L_8085C6;
L_8085C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85C6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85C6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x83u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085C6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x83u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085C8;
L_8085C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85C8u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85C8u, 4u, 3u, cpu.address("abs", 0x210Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085C8 STA
    hw.write(cpu.address("abs", 0x210Fu), cpu.a, cpu.m8?8:16);
    goto L_8085CB;
L_8085CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85CBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85CBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x84u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085CB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x84u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085CD;
L_8085CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85CDu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85CDu, 4u, 3u, cpu.address("abs", 0x2110u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085CD STA
    hw.write(cpu.address("abs", 0x2110u), cpu.a, cpu.m8?8:16);
    goto L_8085D0;
L_8085D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85D0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85D0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x85u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085D0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x85u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085D2;
L_8085D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85D2u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85D2u, 4u, 3u, cpu.address("abs", 0x2110u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085D2 STA
    hw.write(cpu.address("abs", 0x2110u), cpu.a, cpu.m8?8:16);
    goto L_8085D5;
L_8085D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85D5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85D5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x86u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085D5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x86u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085D7;
L_8085D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85D7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85D7u, 4u, 3u, cpu.address("abs", 0x2111u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085D7 STA
    hw.write(cpu.address("abs", 0x2111u), cpu.a, cpu.m8?8:16);
    goto L_8085DA;
L_8085DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85DAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85DAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x87u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085DA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x87u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085DC;
L_8085DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85DCu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85DCu, 4u, 3u, cpu.address("abs", 0x2111u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085DC STA
    hw.write(cpu.address("abs", 0x2111u), cpu.a, cpu.m8?8:16);
    goto L_8085DF;
L_8085DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85DFu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85DFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085DF LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x88u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085E1;
L_8085E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85E1u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85E1u, 4u, 3u, cpu.address("abs", 0x2112u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085E1 STA
    hw.write(cpu.address("abs", 0x2112u), cpu.a, cpu.m8?8:16);
    goto L_8085E4;
L_8085E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85E4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85E4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x89u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085E4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x89u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085E6;
L_8085E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85E6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85E6u, 4u, 3u, cpu.address("abs", 0x2112u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085E6 STA
    hw.write(cpu.address("abs", 0x2112u), cpu.a, cpu.m8?8:16);
    goto L_8085E9;
L_8085E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85E9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85E9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085E9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085EB;
L_8085EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85EBu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85EBu, 4u, 3u, cpu.address("abs", 0x2113u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085EB STA
    hw.write(cpu.address("abs", 0x2113u), cpu.a, cpu.m8?8:16);
    goto L_8085EE;
L_8085EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85EEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85EEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085EE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085F0;
L_8085F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85F0u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85F0u, 4u, 3u, cpu.address("abs", 0x2113u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085F0 STA
    hw.write(cpu.address("abs", 0x2113u), cpu.a, cpu.m8?8:16);
    goto L_8085F3;
L_8085F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85F3u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85F3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085F3 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085F5;
L_8085F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85F5u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85F5u, 4u, 3u, cpu.address("abs", 0x2114u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085F5 STA
    hw.write(cpu.address("abs", 0x2114u), cpu.a, cpu.m8?8:16);
    goto L_8085F8;
L_8085F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85F8u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85F8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085F8 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085FA;
L_8085FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85FAu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85FAu, 4u, 3u, cpu.address("abs", 0x2114u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085FA STA
    hw.write(cpu.address("abs", 0x2114u), cpu.a, cpu.m8?8:16);
    goto L_8085FD;
L_8085FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85FDu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85FDu, 4u, 3u, cpu.address("abs", 0x0100u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085FD LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x100u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808600;
L_808600:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8600u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8600u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8600u, 4u, 3u, cpu.address("abs", 0x211Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808600 STA
    hw.write(cpu.address("abs", 0x211Bu), cpu.a, cpu.m8?8:16);
    goto L_808603;
L_808603:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8603u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8603u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8603u, 4u, 3u, cpu.address("abs", 0x0101u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808603 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x101u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808606;
L_808606:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8606u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8606u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8606u, 4u, 3u, cpu.address("abs", 0x211Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808606 STA
    hw.write(cpu.address("abs", 0x211Bu), cpu.a, cpu.m8?8:16);
    goto L_808609;
L_808609:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8609u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8609u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8609u, 4u, 3u, cpu.address("abs", 0x0102u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808609 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x102u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80860C;
L_80860C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x860Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x860Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x860Cu, 4u, 3u, cpu.address("abs", 0x211Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80860C STA
    hw.write(cpu.address("abs", 0x211Cu), cpu.a, cpu.m8?8:16);
    goto L_80860F;
L_80860F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x860Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x860Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x860Fu, 4u, 3u, cpu.address("abs", 0x0103u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80860F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x103u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808612;
L_808612:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8612u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8612u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8612u, 4u, 3u, cpu.address("abs", 0x211Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808612 STA
    hw.write(cpu.address("abs", 0x211Cu), cpu.a, cpu.m8?8:16);
    goto L_808615;
L_808615:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8615u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8615u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8615u, 4u, 3u, cpu.address("abs", 0x0104u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808615 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x104u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808618;
L_808618:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8618u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8618u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8618u, 4u, 3u, cpu.address("abs", 0x211Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808618 STA
    hw.write(cpu.address("abs", 0x211Du), cpu.a, cpu.m8?8:16);
    goto L_80861B;
L_80861B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x861Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x861Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x861Bu, 4u, 3u, cpu.address("abs", 0x0105u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80861B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x105u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80861E;
L_80861E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x861Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x861Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x861Eu, 4u, 3u, cpu.address("abs", 0x211Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80861E STA
    hw.write(cpu.address("abs", 0x211Du), cpu.a, cpu.m8?8:16);
    goto L_808621;
L_808621:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8621u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8621u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8621u, 4u, 3u, cpu.address("abs", 0x0106u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808621 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x106u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808624;
L_808624:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8624u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8624u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8624u, 4u, 3u, cpu.address("abs", 0x211Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808624 STA
    hw.write(cpu.address("abs", 0x211Eu), cpu.a, cpu.m8?8:16);
    goto L_808627;
L_808627:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8627u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8627u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8627u, 4u, 3u, cpu.address("abs", 0x0107u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808627 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x107u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80862A;
L_80862A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x862Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x862Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x862Au, 4u, 3u, cpu.address("abs", 0x211Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80862A STA
    hw.write(cpu.address("abs", 0x211Eu), cpu.a, cpu.m8?8:16);
    goto L_80862D;
L_80862D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x862Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x862Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x862Du, 4u, 3u, cpu.address("abs", 0x0108u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80862D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x108u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808630;
L_808630:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8630u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8630u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8630u, 4u, 3u, cpu.address("abs", 0x211Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808630 STA
    hw.write(cpu.address("abs", 0x211Fu), cpu.a, cpu.m8?8:16);
    goto L_808633;
L_808633:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8633u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8633u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8633u, 4u, 3u, cpu.address("abs", 0x0109u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808633 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x109u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808636;
L_808636:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8636u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8636u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8636u, 4u, 3u, cpu.address("abs", 0x211Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808636 STA
    hw.write(cpu.address("abs", 0x211Fu), cpu.a, cpu.m8?8:16);
    goto L_808639;
L_808639:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8639u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8639u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8639u, 4u, 3u, cpu.address("abs", 0x010Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808639 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x10Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80863C;
L_80863C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x863Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x863Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x863Cu, 4u, 3u, cpu.address("abs", 0x2120u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80863C STA
    hw.write(cpu.address("abs", 0x2120u), cpu.a, cpu.m8?8:16);
    goto L_80863F;
L_80863F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x863Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x863Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x863Fu, 4u, 3u, cpu.address("abs", 0x010Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80863F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x10Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808642;
L_808642:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8642u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8642u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8642u, 4u, 3u, cpu.address("abs", 0x2120u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808642 STA
    hw.write(cpu.address("abs", 0x2120u), cpu.a, cpu.m8?8:16);
    goto L_808645;
L_808645:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8645u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8645u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8645u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808645 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x77u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808647;
L_808647:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8647u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8647u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8647u, 4u, 3u, cpu.address("abs", 0x2106u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808647 STA
    hw.write(cpu.address("abs", 0x2106u), cpu.a, cpu.m8?8:16);
    goto L_80864A;
L_80864A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x864Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x864Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x864Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80864A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80864Au);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80864Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80870C_E0M0X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8086A1u: goto L_8086A1;
    case 0x8086A4u: goto L_8086A4;
    case 0x8086A7u: goto L_8086A7;
    case 0x8086A9u: goto L_8086A9;
    case 0x8086ACu: goto L_8086AC;
    case 0x8086AFu: goto L_8086AF;
    case 0x8086B2u: goto L_8086B2;
    case 0x8086B5u: goto L_8086B5;
    case 0x8086B8u: goto L_8086B8;
    case 0x8086BBu: goto L_8086BB;
    case 0x8086BEu: goto L_8086BE;
    case 0x8086C1u: goto L_8086C1;
    case 0x8086C3u: goto L_8086C3;
    case 0x8086C6u: goto L_8086C6;
    case 0x8086C9u: goto L_8086C9;
    case 0x8086CBu: goto L_8086CB;
    case 0x8086CCu: goto L_8086CC;
    case 0x8086CDu: goto L_8086CD;
    case 0x8086CEu: goto L_8086CE;
    case 0x8086CFu: goto L_8086CF;
    case 0x8086D0u: goto L_8086D0;
    case 0x8086D1u: goto L_8086D1;
    case 0x8086D2u: goto L_8086D2;
    case 0x8086D3u: goto L_8086D3;
    case 0x8086D4u: goto L_8086D4;
    case 0x8086D5u: goto L_8086D5;
    case 0x8086D6u: goto L_8086D6;
    case 0x8086D9u: goto L_8086D9;
    case 0x8086DBu: goto L_8086DB;
    case 0x8086DDu: goto L_8086DD;
    case 0x8086E0u: goto L_8086E0;
    case 0x8086E4u: goto L_8086E4;
    case 0x8086E6u: goto L_8086E6;
    case 0x8086E8u: goto L_8086E8;
    case 0x8086EBu: goto L_8086EB;
    case 0x8086EDu: goto L_8086ED;
    case 0x8086F0u: goto L_8086F0;
    case 0x8086F2u: goto L_8086F2;
    case 0x8086F3u: goto L_8086F3;
    case 0x80870Cu: goto L_80870C;
    case 0x80870Eu: goto L_80870E;
    case 0x808710u: goto L_808710;
    case 0x808712u: goto L_808712;
    case 0x808714u: goto L_808714;
    case 0x808716u: goto L_808716;
    case 0x808719u: goto L_808719;
    case 0x80871Bu: goto L_80871B;
    case 0x80871Du: goto L_80871D;
    case 0x808724u: goto L_808724;
    case 0x808726u: goto L_808726;
    case 0x808728u: goto L_808728;
    case 0x80872Au: goto L_80872A;
    case 0x80872Du: goto L_80872D;
    case 0x80872Eu: goto L_80872E;
    case 0x80872Fu: goto L_80872F;
    case 0x808730u: goto L_808730;
    case 0x808732u: goto L_808732;
    case 0x808734u: goto L_808734;
    case 0x808736u: goto L_808736;
    case 0x808738u: goto L_808738;
    case 0x80873Au: goto L_80873A;
    case 0x80873Bu: goto L_80873B;
    case 0x80873Eu: goto L_80873E;
    case 0x808740u: goto L_808740;
    case 0x808744u: goto L_808744;
    case 0x808746u: goto L_808746;
    case 0x808747u: goto L_808747;
    case 0x808748u: goto L_808748;
    case 0x80874Bu: goto L_80874B;
    case 0x80874Du: goto L_80874D;
    case 0x808758u: goto L_808758;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8086A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86A1u))return;
  // 4 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86A1u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86A1u, 5u + ((((0x1800u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1800u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086A1 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1800u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8086A4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86A1u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86A1u, 5u + ((((0x1800u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1800u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086A1 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1800u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8086A4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86A1u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86A1u, 4u + ((((0x1800u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1800u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086A1 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1800u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8086A4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86A1u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86A1u, 4u + ((((0x1800u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1800u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086A1 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1800u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8086A4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86A1u,0x8086A1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8086A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86A4u))return;
  // 4 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86A4u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86A4u, 5u, 3u, cpu.address("abs", 0x2115u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086A4 STA
    hw.write(cpu.address("abs", 0x2115u), cpu.a, cpu.m8?8:16);
    goto L_8086A7;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86A4u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86A4u, 5u, 3u, cpu.address("abs", 0x2115u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086A4 STA
    hw.write(cpu.address("abs", 0x2115u), cpu.a, cpu.m8?8:16);
    goto L_8086A7;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86A4u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86A4u, 4u, 3u, cpu.address("abs", 0x2115u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086A4 STA
    hw.write(cpu.address("abs", 0x2115u), cpu.a, cpu.m8?8:16);
    goto L_8086A7;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86A4u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86A4u, 4u, 3u, cpu.address("abs", 0x2115u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086A4 STA
    hw.write(cpu.address("abs", 0x2115u), cpu.a, cpu.m8?8:16);
    goto L_8086A7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86A4u,0x8086A4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8086A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86A7u))return;
  // 4 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86A7u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86A7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086A7 REP
    cpu.rep(0x20u);
    goto L_8086A9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86A7u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86A7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086A7 REP
    cpu.rep(0x20u);
    goto L_8086A9;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86A7u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86A7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086A7 REP
    cpu.rep(0x20u);
    goto L_8086A9;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86A7u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86A7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086A7 REP
    cpu.rep(0x20u);
    goto L_8086A9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86A7u,0x8086A7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8086A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86A9u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86A9u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86A9u, 5u + ((((0x1801u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1801u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086A9 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1801u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8086AC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86A9u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86A9u, 5u + ((((0x1801u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1801u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086A9 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1801u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8086AC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86A9u,0x8086A9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8086AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86ACu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86ACu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86ACu, 5u, 3u, cpu.address("abs", 0x2116u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086AC STA
    hw.write(cpu.address("abs", 0x2116u), cpu.a, cpu.m8?8:16);
    goto L_8086AF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86ACu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86ACu, 5u, 3u, cpu.address("abs", 0x2116u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086AC STA
    hw.write(cpu.address("abs", 0x2116u), cpu.a, cpu.m8?8:16);
    goto L_8086AF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86ACu,0x8086ACu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8086AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86AFu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86AFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86AFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086AF LDA
    cpu.setA(0x1801u, 16);
    goto L_8086B2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86AFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86AFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086AF LDA
    cpu.setA(0x1801u, 16);
    goto L_8086B2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86AFu,0x8086AFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8086B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86B2u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B2u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B2u, 5u, 3u, cpu.address("abs", 0x4370u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086B2 STA
    hw.write(cpu.address("abs", 0x4370u), cpu.a, cpu.m8?8:16);
    goto L_8086B5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B2u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B2u, 5u, 3u, cpu.address("abs", 0x4370u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086B2 STA
    hw.write(cpu.address("abs", 0x4370u), cpu.a, cpu.m8?8:16);
    goto L_8086B5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86B2u,0x8086B2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8086B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86B5u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B5u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B5u, 5u + ((((0x1803u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1803u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086B5 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1803u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8086B8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B5u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B5u, 5u + ((((0x1803u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1803u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086B5 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1803u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8086B8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86B5u,0x8086B5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8086B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86B8u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B8u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B8u, 5u, 3u, cpu.address("abs", 0x4372u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086B8 STA
    hw.write(cpu.address("abs", 0x4372u), cpu.a, cpu.m8?8:16);
    goto L_8086BB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B8u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B8u, 5u, 3u, cpu.address("abs", 0x4372u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086B8 STA
    hw.write(cpu.address("abs", 0x4372u), cpu.a, cpu.m8?8:16);
    goto L_8086BB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86B8u,0x8086B8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8086BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86BBu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86BBu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86BBu, 5u + ((((0x1805u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1805u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086BB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1805u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8086BE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86BBu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86BBu, 5u + ((((0x1805u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1805u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086BB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1805u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8086BE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86BBu,0x8086BBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8086BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86BEu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86BEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86BEu, 5u, 3u, cpu.address("abs", 0x4374u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086BE STA
    hw.write(cpu.address("abs", 0x4374u), cpu.a, cpu.m8?8:16);
    goto L_8086C1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86BEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86BEu, 5u, 3u, cpu.address("abs", 0x4374u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086BE STA
    hw.write(cpu.address("abs", 0x4374u), cpu.a, cpu.m8?8:16);
    goto L_8086C1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86BEu,0x8086BEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8086C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86C1u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C1u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086C1 SEP
    cpu.sep(0x20u);
    goto L_8086C3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C1u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086C1 SEP
    cpu.sep(0x20u);
    goto L_8086C3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86C1u,0x8086C1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8086C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86C3u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C3u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C3u, 4u + ((((0x1807u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1807u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086C3 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1807u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8086C6;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C3u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C3u, 4u + ((((0x1807u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1807u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086C3 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1807u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8086C6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86C3u,0x8086C3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8086C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86C6u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C6u, 5u, 3u, cpu.address("abs", 0x4376u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086C6 STA
    hw.write(cpu.address("abs", 0x4376u), cpu.a, cpu.m8?8:16);
    goto L_8086C9;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C6u, 4u, 3u, cpu.address("abs", 0x4376u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086C6 STA
    hw.write(cpu.address("abs", 0x4376u), cpu.a, cpu.m8?8:16);
    goto L_8086C9;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C6u, 4u, 3u, cpu.address("abs", 0x4376u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086C6 STA
    hw.write(cpu.address("abs", 0x4376u), cpu.a, cpu.m8?8:16);
    goto L_8086C9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86C6u,0x8086C6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8086C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86C9u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086C9 LDA
    cpu.setA(0x8D80u, 16);
    goto L_8086CC;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086C9 LDA
    cpu.setA(0x80u, 8);
    goto L_8086CB;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086C9 LDA
    cpu.setA(0x80u, 8);
    goto L_8086CB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86C9u,0x8086C9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8086CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86CBu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86CBu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86CBu, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086CB STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_8086CE;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86CBu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86CBu, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086CB STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_8086CE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86CBu,0x8086CBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8086CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86CCu,cpu,0x0Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86CCu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8086CC PHD
    cpu.push("PHD", hw);
    goto L_8086CD;
L_8086CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86CDu,cpu,0x42u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86CDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086CD WDM
    ;
    goto L_8086CF;
L_8086CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86CEu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86CEu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86CEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086CE INX
    cpu.inc('X');
    goto L_8086CF;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86CEu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86CEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086CE INX
    cpu.inc('X');
    goto L_8086CF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86CEu,0x8086CEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8086CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86CFu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86CFu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86CFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086CF INX
    cpu.inc('X');
    goto L_8086D0;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86CFu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86CFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086CF INX
    cpu.inc('X');
    goto L_8086D0;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86CFu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86CFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086CF INX
    cpu.inc('X');
    goto L_8086D0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86CFu,0x8086CFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8086D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86D0u))return;
  // 4 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D0u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086D0 INX
    cpu.inc('X');
    goto L_8086D1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D0u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086D0 INX
    cpu.inc('X');
    goto L_8086D1;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D0u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086D0 INX
    cpu.inc('X');
    goto L_8086D1;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D0u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086D0 INX
    cpu.inc('X');
    goto L_8086D1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86D0u,0x8086D0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8086D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86D1u))return;
  // 4 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D1u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086D1 INX
    cpu.inc('X');
    goto L_8086D2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D1u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086D1 INX
    cpu.inc('X');
    goto L_8086D2;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D1u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086D1 INX
    cpu.inc('X');
    goto L_8086D2;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D1u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086D1 INX
    cpu.inc('X');
    goto L_8086D2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86D1u,0x8086D1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8086D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86D2u))return;
  // 4 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D2u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086D2 INX
    cpu.inc('X');
    goto L_8086D3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D2u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086D2 INX
    cpu.inc('X');
    goto L_8086D3;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D2u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086D2 INX
    cpu.inc('X');
    goto L_8086D3;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D2u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086D2 INX
    cpu.inc('X');
    goto L_8086D3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86D2u,0x8086D2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8086D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86D3u))return;
  // 4 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D3u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086D3 INX
    cpu.inc('X');
    goto L_8086D4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D3u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086D3 INX
    cpu.inc('X');
    goto L_8086D4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D3u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086D3 INX
    cpu.inc('X');
    goto L_8086D4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D3u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086D3 INX
    cpu.inc('X');
    goto L_8086D4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86D3u,0x8086D3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8086D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86D4u))return;
  // 4 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D4u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086D4 INX
    cpu.inc('X');
    goto L_8086D5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D4u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086D4 INX
    cpu.inc('X');
    goto L_8086D5;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D4u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086D4 INX
    cpu.inc('X');
    goto L_8086D5;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D4u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086D4 INX
    cpu.inc('X');
    goto L_8086D5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86D4u,0x8086D4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8086D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86D5u))return;
  // 4 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D5u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086D5 INX
    cpu.inc('X');
    goto L_8086D6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D5u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086D5 INX
    cpu.inc('X');
    goto L_8086D6;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D5u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086D5 INX
    cpu.inc('X');
    goto L_8086D6;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D5u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086D5 INX
    cpu.inc('X');
    goto L_8086D6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86D5u,0x8086D5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8086D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86D6u))return;
  // 4 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D6u,cpu,0xECu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D6u, 4u, 3u, cpu.address("abs", 0x0124u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086D6 CPX
    cpu.compareX(hw.readW(cpu.address("abs", 0x124u), cpu.x8?8:16));
    goto L_8086D9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D6u,cpu,0xECu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D6u, 4u, 3u, cpu.address("abs", 0x0124u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086D6 CPX
    cpu.compareX(hw.readW(cpu.address("abs", 0x124u), cpu.x8?8:16));
    goto L_8086D9;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D6u,cpu,0xECu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D6u, 4u, 3u, cpu.address("abs", 0x0124u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086D6 CPX
    cpu.compareX(hw.readW(cpu.address("abs", 0x124u), cpu.x8?8:16));
    goto L_8086D9;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D6u,cpu,0xECu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D6u, 4u, 3u, cpu.address("abs", 0x0124u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086D6 CPX
    cpu.compareX(hw.readW(cpu.address("abs", 0x124u), cpu.x8?8:16));
    goto L_8086D9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86D6u,0x8086D6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8086D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86D9u))return;
  // 4 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D9u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086D9 BCC -> $8086A1
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_8086A1; }
    goto L_8086DB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D9u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086D9 BCC -> $8086A1
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_8086A1; }
    goto L_8086DB;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D9u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086D9 BCC -> $8086A1
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_8086A1; }
    goto L_8086DB;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D9u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086D9 BCC -> $8086A1
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_8086A1; }
    goto L_8086DB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86D9u,0x8086D9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8086DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86DBu))return;
  // 4 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86DBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86DBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xB4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086DB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xB4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8086DD;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86DBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86DBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xB4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086DB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xB4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8086DD;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86DBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86DBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xB4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086DB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xB4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8086DD;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86DBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86DBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xB4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086DB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xB4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8086DD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86DBu,0x8086DBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8086DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86DDu))return;
  // 4 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86DDu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86DDu, 5u, 3u, cpu.address("abs", 0x420Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086DD STA
    hw.write(cpu.address("abs", 0x420Cu), cpu.a, cpu.m8?8:16);
    goto L_8086E0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86DDu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86DDu, 5u, 3u, cpu.address("abs", 0x420Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086DD STA
    hw.write(cpu.address("abs", 0x420Cu), cpu.a, cpu.m8?8:16);
    goto L_8086E0;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86DDu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86DDu, 4u, 3u, cpu.address("abs", 0x420Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086DD STA
    hw.write(cpu.address("abs", 0x420Cu), cpu.a, cpu.m8?8:16);
    goto L_8086E0;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86DDu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86DDu, 4u, 3u, cpu.address("abs", 0x420Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086DD STA
    hw.write(cpu.address("abs", 0x420Cu), cpu.a, cpu.m8?8:16);
    goto L_8086E0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86DDu,0x8086DDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8086E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86E0u))return;
  // 4 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86E0u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86E0u, 8u, 4u, 0x808B92u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8086E0 JSL -> $808B92 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x86E3u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x86E4u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808B92u, 0x8086E0u); }
    goto L_8086E4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86E0u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86E0u, 8u, 4u, 0x808B92u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8086E0 JSL -> $808B92 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x86E3u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x86E4u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808B92u, 0x8086E0u); }
    goto L_8086E4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86E0u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86E0u, 8u, 4u, 0x808B92u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8086E0 JSL -> $808B92 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x86E3u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x86E4u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808B92u, 0x8086E0u); }
    goto L_8086E4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86E0u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86E0u, 8u, 4u, 0x808B92u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8086E0 JSL -> $808B92 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x86E3u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x86E4u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808B92u, 0x8086E0u); }
    goto L_8086E4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86E0u,0x8086E0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8086E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86E4u))return;
  // 4 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86E4u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86E4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086E4 REP
    cpu.rep(0x20u);
    goto L_8086E6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86E4u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86E4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086E4 REP
    cpu.rep(0x20u);
    goto L_8086E6;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86E4u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86E4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086E4 REP
    cpu.rep(0x20u);
    goto L_8086E6;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86E4u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86E4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086E4 REP
    cpu.rep(0x20u);
    goto L_8086E6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86E4u,0x8086E4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8086E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86E6u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86E6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86E6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086E6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8086E8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86E6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86E6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086E6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8086E8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86E6u,0x8086E6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8086E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86E8u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86E8u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86E8u, 5u, 3u, cpu.address("abs", 0x212Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086E8 STA
    hw.write(cpu.address("abs", 0x212Cu), cpu.a, cpu.m8?8:16);
    goto L_8086EB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86E8u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86E8u, 5u, 3u, cpu.address("abs", 0x212Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086E8 STA
    hw.write(cpu.address("abs", 0x212Cu), cpu.a, cpu.m8?8:16);
    goto L_8086EB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86E8u,0x8086E8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8086EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86EBu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86EBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86EBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086EB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8086ED;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86EBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86EBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086EB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8086ED;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86EBu,0x8086EBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8086ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86EDu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86EDu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86EDu, 5u, 3u, cpu.address("abs", 0x212Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086ED STA
    hw.write(cpu.address("abs", 0x212Eu), cpu.a, cpu.m8?8:16);
    goto L_8086F0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86EDu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86EDu, 5u, 3u, cpu.address("abs", 0x212Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086ED STA
    hw.write(cpu.address("abs", 0x212Eu), cpu.a, cpu.m8?8:16);
    goto L_8086F0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86EDu,0x8086EDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8086F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86F0u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F0u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086F0 SEP
    cpu.sep(0x20u);
    goto L_8086F2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F0u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086F0 SEP
    cpu.sep(0x20u);
    goto L_8086F2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86F0u,0x8086F0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8086F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86F2u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F2u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F2u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8086F2 PLP
    cpu.pop("PLP", hw);
    goto L_8086F3;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F2u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F2u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8086F2 PLP
    cpu.pop("PLP", hw);
    goto L_8086F3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86F2u,0x8086F2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8086F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86F3u))return;
  // 8 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F3u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8086F3 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8086F3u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8086F3u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F3u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8086F3 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8086F3u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8086F3u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F3u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8086F3 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8086F3u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8086F3u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F3u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8086F3 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8086F3u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8086F3u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F3u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8086F3 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8086F3u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8086F3u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F3u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8086F3 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8086F3u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8086F3u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F3u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8086F3 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8086F3u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8086F3u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F3u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8086F3 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8086F3u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8086F3u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86F3u,0x8086F3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80870C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x870Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x870Cu,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x870Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80870C BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x75u), cpu.m8?8:16), false);
    goto L_80870E;
L_80870E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x870Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x870Eu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x870Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80870E BPL -> $80872E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80872E; }
    goto L_808710;
L_808710:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8710u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8710u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8710u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808710 DEC
    cpu.decMem(hw, cpu.address("dp", 0x76u), cpu.m8?8:16);
    goto L_808712;
L_808712:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8712u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8712u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8712u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808712 BPL -> $80872E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80872E; }
    goto L_808714;
L_808714:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8714u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8714u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8714u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808714 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x74u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808716;
L_808716:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8716u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8716u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8716u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808716 AND
    cpu.logicAnd(0x700Fu);
    goto L_808719;
L_808719:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8719u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8719u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8719u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808719 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x3Au), cpu.m8?8:16));
    goto L_80871B;
L_80871B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x871Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x871Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x871Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80871B BNE -> $808726
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_808726; }
    goto L_80871D;
L_80871D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x871Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x871Du,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x871Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80871D BRA -> $808724
    goto L_808724;
L_808724:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8724u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8724u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8724u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808724 STZ
    hw.write(cpu.address("dp", 0x75u), 0, cpu.m8?8:16);
    goto L_808726;
L_808726:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8726u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8726u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8726u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808726 STA
    hw.write(cpu.address("dp", 0x74u), cpu.a, cpu.m8?8:16);
    goto L_808728;
L_808728:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8728u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8728u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8728u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808728 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x75u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80872A;
L_80872A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x872Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x872Au,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x872Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80872A AND
    cpu.logicAnd(0x853Fu);
    goto L_80872D;
L_80872D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x872Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x872Du,cpu,0x76u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x872Du, 8u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x24u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80872D ROR
    cpu.rorMem(hw, cpu.address("dpx", 0x24u), cpu.m8?8:16);
    goto L_80872F;
L_80872E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x872Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x872Eu,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x872Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x78u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80872E BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x78u), cpu.m8?8:16), false);
    goto L_808730;
L_80872F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x872Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x872Fu,cpu,0x78u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x872Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80872F SEI
    cpu.setFlag('I', true);
    goto L_808730;
L_808730:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8730u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8730u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8730u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808730 BPL -> $808758
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_808758; }
    goto L_808732;
L_808732:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8732u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8732u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8732u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x79u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808732 DEC
    cpu.decMem(hw, cpu.address("dp", 0x79u), cpu.m8?8:16);
    goto L_808734;
L_808734:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8734u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8734u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8734u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808734 BPL -> $808758
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_808758; }
    goto L_808736;
L_808736:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8736u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8736u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8736u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808736 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x77u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808738;
L_808738:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8738u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8738u,cpu,0x70u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8738u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808738 BVS -> $808747
    if (cpu.v) { hw.addCpuInternalCycles(1u); goto L_808747; }
    goto L_80873A;
L_80873A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x873Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x873Au,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x873Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80873A CLC
    cpu.setFlag('C', false);
    goto L_80873B;
L_80873B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x873Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x873Bu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x873Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80873B ADC
    cpu.adc(0xC910u);
    goto L_80873E;
L_80873E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x873Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x873Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x873Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80873E BEQ -> $8086D0
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8086D0; }
    goto L_808740;
L_808740:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8740u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8740u,cpu,0x0Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8740u, 6u, 4u, 0x090F29u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808740 ORA
    cpu.logicOr(hw.readW(0x90F29u, cpu.m8?8:16));
    goto L_808744;
L_808744:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8744u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8744u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8744u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808744 BEQ -> $8086C6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8086C6; }
    goto L_808746;
L_808746:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8746u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8746u,cpu,0x07u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8746u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x38u) & 0xFFFFu), 3u, 0u);
    // $808746 ORA
    cpu.logicOr(hw.readW(cpu.addressDpLong(hw, 0x38u), cpu.m8?8:16));
    goto L_808748;
L_808747:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8747u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8747u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8747u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808747 SEC
    cpu.setFlag('C', true);
    goto L_808748;
L_808748:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8748u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8748u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8748u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808748 SBC
    cpu.sbc(0xB010u);
    goto L_80874B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8748u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8748u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808748 SBC
    cpu.sbc(0xB010u);
    goto L_80874B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8748u,0x808748u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80874B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x874Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x874Bu,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x874Bu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA9u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80874B TSB
    cpu.tsb(hw, cpu.address("dp", 0xA9u), cpu.m8?8:16);
    goto L_80874D;
L_80874D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x874Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x874Du,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x874Du, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $80874D BRK
    hw.partial(0x80874Du, "BRK"); return;
L_808758:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8758u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8758u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8758u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808758 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808758u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x808758u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_808BEA_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808BEAu: goto L_808BEA;
    case 0x808BEBu: goto L_808BEB;
    case 0x808BEDu: goto L_808BED;
    case 0x808BEFu: goto L_808BEF;
    case 0x808BF1u: goto L_808BF1;
    case 0x808BF4u: goto L_808BF4;
    case 0x808BF6u: goto L_808BF6;
    case 0x808BF8u: goto L_808BF8;
    case 0x808BFAu: goto L_808BFA;
    case 0x808BFBu: goto L_808BFB;
    case 0x808BFCu: goto L_808BFC;
    case 0x808BFEu: goto L_808BFE;
    case 0x808BFFu: goto L_808BFF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808BEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEAu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEAu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808BEA PHP
    cpu.push("PHP", hw);
    goto L_808BEB;
L_808BEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BEBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEBu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEBu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BEB REP
    cpu.rep(0x20u);
    goto L_808BED;
L_808BED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEDu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEDu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Bu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BED INC
    cpu.incMem(hw, cpu.address("dp", 0x6Bu), cpu.m8?8:16);
    goto L_808BEF;
L_808BEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEFu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEFu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Du), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BEF INC
    cpu.incMem(hw, cpu.address("dp", 0x6Du), cpu.m8?8:16);
    goto L_808BF1;
L_808BF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF1u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BF1 LDX
    cpu.setX(0x2u, 16);
    goto L_808BF4;
L_808BF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF4u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF4u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x6Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BF4 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x6Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808BF6;
L_808BF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BF6 BEQ -> $808BFA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_808BFA; }
    goto L_808BF8;
L_808BF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF8u,cpu,0xD6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF8u, 8u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x6Fu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BF8 DEC
    cpu.decMem(hw, cpu.address("dpx", 0x6Fu), cpu.m8?8:16);
    goto L_808BFA;
L_808BFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFAu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BFA DEX
    cpu.decReg('X');
    goto L_808BFB;
L_808BFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFBu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BFB DEX
    cpu.decReg('X');
    goto L_808BFC;
L_808BFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFCu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BFC BPL -> $808BF4
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_808BF4; }
    goto L_808BFE;
L_808BFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFEu,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFEu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808BFE PLP
    cpu.pop("PLP", hw);
    goto L_808BFF;
L_808BFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BFFu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BFFu,0x808BFFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFFu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808BFF RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808BFFu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x808BFFu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_809CC1_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809CC1u: goto L_809CC1;
    case 0x809CC2u: goto L_809CC2;
    case 0x809CC5u: goto L_809CC5;
    case 0x809CC6u: goto L_809CC6;
    case 0x809CC9u: goto L_809CC9;
    case 0x809CCAu: goto L_809CCA;
    case 0x809CCCu: goto L_809CCC;
    case 0x809CCEu: goto L_809CCE;
    case 0x809CCFu: goto L_809CCF;
    case 0x809CD0u: goto L_809CD0;
    case 0x809CD2u: goto L_809CD2;
    case 0x809CD5u: goto L_809CD5;
    case 0x809CD8u: goto L_809CD8;
    case 0x809CDAu: goto L_809CDA;
    case 0x809CDBu: goto L_809CDB;
    case 0x809CDDu: goto L_809CDD;
    case 0x809CDEu: goto L_809CDE;
    case 0x809CDFu: goto L_809CDF;
    case 0x809CE2u: goto L_809CE2;
    case 0x809CE5u: goto L_809CE5;
    case 0x809CE6u: goto L_809CE6;
    case 0x809CE7u: goto L_809CE7;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809CC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC1u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809CC1 CLC
    cpu.setFlag('C', false);
    goto L_809CC2;
L_809CC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC2u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809CC2 ADC
    cpu.adc(0x1F8u);
    goto L_809CC5;
L_809CC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC5u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809CC5 TAY
    cpu.transfer("TAY");
    goto L_809CC6;
L_809CC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC6u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809CC6 LDX
    cpu.setX(0x16u, 16);
    goto L_809CC9;
L_809CC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC9u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC9u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809CC9 PHB
    cpu.push("PHB", hw);
    goto L_809CCA;
L_809CCA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CCAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCAu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809CCA SEP
    cpu.sep(0x20u);
    goto L_809CCC;
L_809CCC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CCCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809CCC LDA
    cpu.setA(0x7Eu, 8);
    goto L_809CCE;
L_809CCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CCEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCEu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCEu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809CCE PHA
    cpu.push("PHA", hw);
    goto L_809CCF;
L_809CCF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CCFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCFu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCFu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809CCF PLB
    cpu.pop("PLB", hw);
    goto L_809CD0;
L_809CD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CD0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD0u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809CD0 REP
    cpu.rep(0x20u);
    goto L_809CD2;
L_809CD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CD2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD2u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD2u, 5u + 1u, 3u, cpu.address("absy", 0x2000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809CD2 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x2000u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809CD5;
L_809CD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD5u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809CD5 CMP
    cpu.compareA(0xFFFFu);
    goto L_809CD8;
L_809CD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CD8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD8u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809CD8 BNE -> $809CDF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_809CDF; }
    goto L_809CDA;
L_809CDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CDAu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CDAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809CDA DEX
    cpu.decReg('X');
    goto L_809CDB;
L_809CDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CDBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CDBu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CDBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809CDB BPL -> $809CE5
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_809CE5; }
    goto L_809CDD;
L_809CDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CDDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CDDu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CDDu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809CDD PLB
    cpu.pop("PLB", hw);
    goto L_809CDE;
L_809CDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CDEu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CDEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $809CDE RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x809CDEu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x809CDEu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_809CDF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CDFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CDFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CDFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809CDF LDA
    cpu.setA(0x0u, 16);
    goto L_809CE2;
L_809CE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CE2u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CE2u, 6u, 3u, cpu.address("absy", 0x2000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809CE2 STA
    hw.write(cpu.address("absy", 0x2000u), cpu.a, cpu.m8?8:16);
    goto L_809CE5;
L_809CE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CE5u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CE5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809CE5 DEY
    cpu.decReg('Y');
    goto L_809CE6;
L_809CE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CE6u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CE6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809CE6 DEY
    cpu.decReg('Y');
    goto L_809CE7;
L_809CE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CE7u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CE7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809CE7 BRA -> $809CD2
    goto L_809CD2;
}

void sub_80A6FB_E0M1X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80A6FBu: goto L_80A6FB;
    case 0x80A6FCu: goto L_80A6FC;
    case 0x80A6FDu: goto L_80A6FD;
    case 0x80A6FFu: goto L_80A6FF;
    case 0x80A700u: goto L_80A700;
    case 0x80A703u: goto L_80A703;
    case 0x80A705u: goto L_80A705;
    case 0x80A707u: goto L_80A707;
    case 0x80A709u: goto L_80A709;
    case 0x80A70Au: goto L_80A70A;
    case 0x80A70Du: goto L_80A70D;
    case 0x80A70Fu: goto L_80A70F;
    case 0x80A711u: goto L_80A711;
    case 0x80A713u: goto L_80A713;
    case 0x80A715u: goto L_80A715;
    case 0x80A717u: goto L_80A717;
    case 0x80A719u: goto L_80A719;
    case 0x80A71Bu: goto L_80A71B;
    case 0x80A71Eu: goto L_80A71E;
    case 0x80A71Fu: goto L_80A71F;
    case 0x80A721u: goto L_80A721;
    case 0x80A722u: goto L_80A722;
    case 0x80A723u: goto L_80A723;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80A6FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FBu,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FBu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80A6FB PHX
    cpu.push("PHX", hw);
    goto L_80A6FC;
L_80A6FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FCu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FCu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A6FC PHP
    cpu.push("PHP", hw);
    goto L_80A6FD;
L_80A6FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FDu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A6FD SEP
    cpu.sep(0x20u);
    goto L_80A6FF;
L_80A6FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FFu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FFu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A6FF PHA
    cpu.push("PHA", hw);
    goto L_80A700;
L_80A700:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA700u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA700u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA700u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A700 LDX
    cpu.setX(0x0u, 16);
    goto L_80A703;
L_80A703:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA703u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA703u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA703u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xDDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A703 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xDDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A705;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA703u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA703u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xDDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A703 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xDDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A705;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA703u,0x80A703u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A705:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA705u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA705u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA705u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A705 CMP
    cpu.compareA(0xFFu);
    goto L_80A707;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA705u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA705u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A705 CMP
    cpu.compareA(0xFFu);
    goto L_80A707;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA705u,0x80A705u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A707:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA707u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA707u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA707u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A707 BEQ -> $80A71E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80A71E; }
    goto L_80A709;
L_80A709:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA709u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA709u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA709u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A709 INX
    cpu.inc('X');
    goto L_80A70A;
L_80A70A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA70Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Au,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A70A CPX
    cpu.compareX(0x4u);
    goto L_80A70D;
L_80A70D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA70Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Du,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A70D BCC -> $80A703
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80A703; }
    goto L_80A70F;
L_80A70F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA70Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A70F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A711;
L_80A711:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA711u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA711u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA711u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A711 STA
    hw.write(cpu.address("dp", 0xDDu), cpu.a, cpu.m8?8:16);
    goto L_80A713;
L_80A713:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA713u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA713u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA713u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A713 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A715;
L_80A715:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA715u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA715u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA715u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A715 STA
    hw.write(cpu.address("dp", 0xDEu), cpu.a, cpu.m8?8:16);
    goto L_80A717;
L_80A717:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA717u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA717u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA717u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xE0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A717 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xE0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A719;
L_80A719:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA719u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA719u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA719u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A719 STA
    hw.write(cpu.address("dp", 0xDFu), cpu.a, cpu.m8?8:16);
    goto L_80A71B;
L_80A71B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA71Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA71Bu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA71Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A71B LDX
    cpu.setX(0x3u, 16);
    goto L_80A71E;
L_80A71E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA71Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA71Eu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA71Eu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A71E PLA
    cpu.pop("PLA", hw);
    goto L_80A71F;
L_80A71F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA71Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA71Fu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA71Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xDDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A71F STA
    hw.write(cpu.address("dpx", 0xDDu), cpu.a, cpu.m8?8:16);
    goto L_80A721;
L_80A721:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA721u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA721u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA721u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A721 PLP
    cpu.pop("PLP", hw);
    goto L_80A722;
L_80A722:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA722u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA722u,0x80A722u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA722u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA722u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80A722 PLX
    cpu.pop("PLX", hw);
    goto L_80A723;
L_80A723:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA723u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA723u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA723u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A723 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80A723u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80A723u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80A6FB_E0M1X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80A6FBu: goto L_80A6FB;
    case 0x80A6FCu: goto L_80A6FC;
    case 0x80A6FDu: goto L_80A6FD;
    case 0x80A6FFu: goto L_80A6FF;
    case 0x80A700u: goto L_80A700;
    case 0x80A703u: goto L_80A703;
    case 0x80A705u: goto L_80A705;
    case 0x80A707u: goto L_80A707;
    case 0x80A709u: goto L_80A709;
    case 0x80A70Au: goto L_80A70A;
    case 0x80A70Du: goto L_80A70D;
    case 0x80A70Fu: goto L_80A70F;
    case 0x80A711u: goto L_80A711;
    case 0x80A713u: goto L_80A713;
    case 0x80A715u: goto L_80A715;
    case 0x80A717u: goto L_80A717;
    case 0x80A719u: goto L_80A719;
    case 0x80A71Bu: goto L_80A71B;
    case 0x80A71Eu: goto L_80A71E;
    case 0x80A71Fu: goto L_80A71F;
    case 0x80A721u: goto L_80A721;
    case 0x80A722u: goto L_80A722;
    case 0x80A723u: goto L_80A723;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80A6FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FBu,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FBu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80A6FB PHX
    cpu.push("PHX", hw);
    goto L_80A6FC;
L_80A6FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FCu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FCu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A6FC PHP
    cpu.push("PHP", hw);
    goto L_80A6FD;
L_80A6FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FDu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A6FD SEP
    cpu.sep(0x20u);
    goto L_80A6FF;
L_80A6FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FFu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FFu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A6FF PHA
    cpu.push("PHA", hw);
    goto L_80A700;
L_80A700:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA700u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA700u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA700u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A700 LDX
    cpu.setX(0x0u, 16);
    goto L_80A703;
L_80A703:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA703u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA703u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA703u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xDDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A703 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xDDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A705;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA703u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA703u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xDDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A703 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xDDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A705;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA703u,0x80A703u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A705:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA705u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA705u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA705u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A705 CMP
    cpu.compareA(0xFFu);
    goto L_80A707;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA705u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA705u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A705 CMP
    cpu.compareA(0xFFu);
    goto L_80A707;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA705u,0x80A705u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A707:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA707u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA707u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA707u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A707 BEQ -> $80A71E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80A71E; }
    goto L_80A709;
L_80A709:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA709u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA709u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA709u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A709 INX
    cpu.inc('X');
    goto L_80A70A;
L_80A70A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA70Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Au,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A70A CPX
    cpu.compareX(0x4u);
    goto L_80A70D;
L_80A70D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA70Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Du,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A70D BCC -> $80A703
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80A703; }
    goto L_80A70F;
L_80A70F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA70Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A70F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A711;
L_80A711:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA711u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA711u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA711u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A711 STA
    hw.write(cpu.address("dp", 0xDDu), cpu.a, cpu.m8?8:16);
    goto L_80A713;
L_80A713:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA713u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA713u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA713u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A713 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A715;
L_80A715:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA715u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA715u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA715u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A715 STA
    hw.write(cpu.address("dp", 0xDEu), cpu.a, cpu.m8?8:16);
    goto L_80A717;
L_80A717:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA717u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA717u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA717u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xE0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A717 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xE0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A719;
L_80A719:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA719u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA719u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA719u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A719 STA
    hw.write(cpu.address("dp", 0xDFu), cpu.a, cpu.m8?8:16);
    goto L_80A71B;
L_80A71B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA71Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA71Bu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA71Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A71B LDX
    cpu.setX(0x3u, 16);
    goto L_80A71E;
L_80A71E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA71Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA71Eu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA71Eu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A71E PLA
    cpu.pop("PLA", hw);
    goto L_80A71F;
L_80A71F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA71Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA71Fu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA71Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xDDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A71F STA
    hw.write(cpu.address("dpx", 0xDDu), cpu.a, cpu.m8?8:16);
    goto L_80A721;
L_80A721:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA721u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA721u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA721u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A721 PLP
    cpu.pop("PLP", hw);
    goto L_80A722;
L_80A722:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA722u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA722u,0x80A722u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA722u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA722u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80A722 PLX
    cpu.pop("PLX", hw);
    goto L_80A723;
L_80A723:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA723u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA723u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA723u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A723 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80A723u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80A723u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80A6FB_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80A6FBu: goto L_80A6FB;
    case 0x80A6FCu: goto L_80A6FC;
    case 0x80A6FDu: goto L_80A6FD;
    case 0x80A6FFu: goto L_80A6FF;
    case 0x80A700u: goto L_80A700;
    case 0x80A703u: goto L_80A703;
    case 0x80A705u: goto L_80A705;
    case 0x80A707u: goto L_80A707;
    case 0x80A709u: goto L_80A709;
    case 0x80A70Au: goto L_80A70A;
    case 0x80A70Du: goto L_80A70D;
    case 0x80A70Fu: goto L_80A70F;
    case 0x80A711u: goto L_80A711;
    case 0x80A713u: goto L_80A713;
    case 0x80A715u: goto L_80A715;
    case 0x80A717u: goto L_80A717;
    case 0x80A719u: goto L_80A719;
    case 0x80A71Bu: goto L_80A71B;
    case 0x80A71Eu: goto L_80A71E;
    case 0x80A71Fu: goto L_80A71F;
    case 0x80A721u: goto L_80A721;
    case 0x80A722u: goto L_80A722;
    case 0x80A723u: goto L_80A723;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80A6FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FBu,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FBu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80A6FB PHX
    cpu.push("PHX", hw);
    goto L_80A6FC;
L_80A6FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FCu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FCu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A6FC PHP
    cpu.push("PHP", hw);
    goto L_80A6FD;
L_80A6FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FDu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A6FD SEP
    cpu.sep(0x20u);
    goto L_80A6FF;
L_80A6FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FFu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FFu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A6FF PHA
    cpu.push("PHA", hw);
    goto L_80A700;
L_80A700:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA700u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA700u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA700u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A700 LDX
    cpu.setX(0x0u, 16);
    goto L_80A703;
L_80A703:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA703u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA703u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA703u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xDDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A703 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xDDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A705;
L_80A705:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA705u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA705u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA705u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A705 CMP
    cpu.compareA(0xFFu);
    goto L_80A707;
L_80A707:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA707u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA707u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA707u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A707 BEQ -> $80A71E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80A71E; }
    goto L_80A709;
L_80A709:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA709u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA709u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA709u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A709 INX
    cpu.inc('X');
    goto L_80A70A;
L_80A70A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA70Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Au,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A70A CPX
    cpu.compareX(0x4u);
    goto L_80A70D;
L_80A70D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA70Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Du,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A70D BCC -> $80A703
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80A703; }
    goto L_80A70F;
L_80A70F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA70Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A70F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A711;
L_80A711:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA711u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA711u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA711u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A711 STA
    hw.write(cpu.address("dp", 0xDDu), cpu.a, cpu.m8?8:16);
    goto L_80A713;
L_80A713:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA713u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA713u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA713u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A713 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A715;
L_80A715:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA715u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA715u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA715u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A715 STA
    hw.write(cpu.address("dp", 0xDEu), cpu.a, cpu.m8?8:16);
    goto L_80A717;
L_80A717:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA717u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA717u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA717u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xE0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A717 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xE0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A719;
L_80A719:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA719u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA719u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA719u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A719 STA
    hw.write(cpu.address("dp", 0xDFu), cpu.a, cpu.m8?8:16);
    goto L_80A71B;
L_80A71B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA71Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA71Bu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA71Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A71B LDX
    cpu.setX(0x3u, 16);
    goto L_80A71E;
L_80A71E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA71Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA71Eu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA71Eu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A71E PLA
    cpu.pop("PLA", hw);
    goto L_80A71F;
L_80A71F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA71Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA71Fu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA71Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xDDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A71F STA
    hw.write(cpu.address("dpx", 0xDDu), cpu.a, cpu.m8?8:16);
    goto L_80A721;
L_80A721:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA721u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA721u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA721u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A721 PLP
    cpu.pop("PLP", hw);
    goto L_80A722;
L_80A722:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA722u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA722u,0x80A722u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA722u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA722u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80A722 PLX
    cpu.pop("PLX", hw);
    goto L_80A723;
L_80A723:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA723u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA723u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA723u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A723 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80A723u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80A723u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80B00D_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B00Du: goto L_80B00D;
    case 0x80B010u: goto L_80B010;
    case 0x80B012u: goto L_80B012;
    case 0x80B015u: goto L_80B015;
    case 0x80B018u: goto L_80B018;
    case 0x80B01Bu: goto L_80B01B;
    case 0x80B01Eu: goto L_80B01E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B00D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB00Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB00Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB00Du, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B00D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x958u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B010;
L_80B010:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB010u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB010u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB010u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B010 BEQ -> $80B01B
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B01B; }
    goto L_80B012;
L_80B012:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB012u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB012u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB012u, 6u, 3u, cpu.address("abs", 0xC8FEu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B012 JSR -> $80C8FE stack real
    { cpu.push16Value(hw,0xB014u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB015u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC8FEu), 0x80B012u); }
    goto L_80B015;
L_80B015:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB015u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB015u,0x80B015u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB015u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB015u, 6u, 3u, cpu.address("abs", 0xC9DDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B015 JSR -> $80C9DD stack real
    { cpu.push16Value(hw,0xB017u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB018u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC9DDu), 0x80B015u); }
    goto L_80B018;
L_80B018:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB018u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB018u,0x80B018u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB018u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB018u, 6u, 3u, cpu.address("abs", 0xBBFAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B018 JSR -> $80BBFA stack real
    { cpu.push16Value(hw,0xB01Au); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB01Bu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBBFAu), 0x80B018u); }
    goto L_80B01B;
L_80B01B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB01Bu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB01Bu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB01Bu, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B01B INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B01E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB01Bu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB01Bu, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B01B INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B01E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB01Bu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB01Bu, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B01B INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B01E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB01Bu,0x80B01Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B01E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB01Eu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB01Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB01Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B01E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B01Eu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B01Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB01Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB01Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B01E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B01Eu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B01Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB01Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB01Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B01E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B01Eu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B01Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB01Eu,0x80B01Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80B229_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B229u: goto L_80B229;
    case 0x80B22Cu: goto L_80B22C;
    case 0x80B22Eu: goto L_80B22E;
    case 0x80B231u: goto L_80B231;
    case 0x80B233u: goto L_80B233;
    case 0x80B236u: goto L_80B236;
    case 0x80B239u: goto L_80B239;
    case 0x80B23Cu: goto L_80B23C;
    case 0x80B23Fu: goto L_80B23F;
    case 0x80B242u: goto L_80B242;
    case 0x80B245u: goto L_80B245;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B229:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB229u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB229u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB229u, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B229 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x958u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B22C;
L_80B22C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB22Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB22Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB22Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B22C BEQ -> $80B23F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B23F; }
    goto L_80B22E;
L_80B22E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB22Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB22Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB22Eu, 5u, 3u, cpu.address("abs", 0x098Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B22E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x98Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B231;
L_80B231:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB231u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB231u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB231u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B231 BEQ -> $80B23F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B23F; }
    goto L_80B233;
L_80B233:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB233u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB233u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB233u, 8u, 3u, cpu.address("abs", 0x0986u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B233 INC
    cpu.incMem(hw, cpu.address("abs", 0x986u), cpu.m8?8:16);
    goto L_80B236;
L_80B236:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB236u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB236u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB236u, 5u, 3u, cpu.address("abs", 0x0914u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B236 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x914u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B239;
L_80B239:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB239u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB239u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB239u, 5u, 3u, cpu.address("abs", 0x097Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B239 STA
    hw.write(cpu.address("abs", 0x97Au), cpu.a, cpu.m8?8:16);
    goto L_80B23C;
L_80B23C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB23Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB23Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB23Cu, 6u, 3u, cpu.address("abs", 0xCE62u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B23C JSR -> $80CE62 stack real
    { cpu.push16Value(hw,0xB23Eu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB23Fu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCE62u), 0x80B23Cu); }
    goto L_80B23F;
L_80B23F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB23Fu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB23Fu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB23Fu, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B23F STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80B242;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB23Fu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB23Fu, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B23F STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80B242;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB23Fu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB23Fu, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B23F STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80B242;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB23Fu,0x80B23Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B242:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB242u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB242u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB242u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B242 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B245;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB242u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB242u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B242 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B245;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB242u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB242u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B242 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B245;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB242u,0x80B242u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B245:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB245u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB245u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB245u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B245 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B245u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B245u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB245u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB245u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B245 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B245u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B245u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB245u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB245u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B245 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B245u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B245u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB245u,0x80B245u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80D2B7_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80D2B7u: goto L_80D2B7;
    case 0x80D2B9u: goto L_80D2B9;
    case 0x80D2BDu: goto L_80D2BD;
    case 0x80D2C0u: goto L_80D2C0;
    case 0x80D2C2u: goto L_80D2C2;
    case 0x80D2C4u: goto L_80D2C4;
    case 0x80D2C5u: goto L_80D2C5;
    case 0x80D2C6u: goto L_80D2C6;
    case 0x80D2C9u: goto L_80D2C9;
    case 0x80D2CAu: goto L_80D2CA;
    case 0x80D2CDu: goto L_80D2CD;
    case 0x80D2CFu: goto L_80D2CF;
    case 0x80D2D3u: goto L_80D2D3;
    case 0x80D2D5u: goto L_80D2D5;
    case 0x80D2D7u: goto L_80D2D7;
    case 0x80D2D9u: goto L_80D2D9;
    case 0x80D2DDu: goto L_80D2DD;
    case 0x80D2E0u: goto L_80D2E0;
    case 0x80D2E2u: goto L_80D2E2;
    case 0x80D2E4u: goto L_80D2E4;
    case 0x80D2E8u: goto L_80D2E8;
    case 0x80D2EAu: goto L_80D2EA;
    case 0x80D2EDu: goto L_80D2ED;
    case 0x80D2EFu: goto L_80D2EF;
    case 0x80D2F3u: goto L_80D2F3;
    case 0x80D2F5u: goto L_80D2F5;
    case 0x80D2F7u: goto L_80D2F7;
    case 0x80D2F9u: goto L_80D2F9;
    case 0x80D2FBu: goto L_80D2FB;
    case 0x80D2FEu: goto L_80D2FE;
    case 0x80D300u: goto L_80D300;
    case 0x80D304u: goto L_80D304;
    case 0x80D307u: goto L_80D307;
    case 0x80D309u: goto L_80D309;
    case 0x80D30Bu: goto L_80D30B;
    case 0x80D30Cu: goto L_80D30C;
    case 0x80D30Du: goto L_80D30D;
    case 0x80D310u: goto L_80D310;
    case 0x80D312u: goto L_80D312;
    case 0x80D316u: goto L_80D316;
    case 0x80D318u: goto L_80D318;
    case 0x80D31Cu: goto L_80D31C;
    case 0x80D31Eu: goto L_80D31E;
    case 0x80D322u: goto L_80D322;
    case 0x80D325u: goto L_80D325;
    case 0x80D329u: goto L_80D329;
    case 0x80D32Bu: goto L_80D32B;
    case 0x80D32Du: goto L_80D32D;
    case 0x80D32Fu: goto L_80D32F;
    case 0x80D331u: goto L_80D331;
    case 0x80D333u: goto L_80D333;
    case 0x80D335u: goto L_80D335;
    case 0x80D337u: goto L_80D337;
    case 0x80D339u: goto L_80D339;
    case 0x80D33Bu: goto L_80D33B;
    case 0x80D33Du: goto L_80D33D;
    case 0x80D33Fu: goto L_80D33F;
    case 0x80D341u: goto L_80D341;
    case 0x80D342u: goto L_80D342;
    case 0x80D343u: goto L_80D343;
    case 0x80D346u: goto L_80D346;
    case 0x80D347u: goto L_80D347;
    case 0x80D34Au: goto L_80D34A;
    case 0x80D34Cu: goto L_80D34C;
    case 0x80D350u: goto L_80D350;
    case 0x80D352u: goto L_80D352;
    case 0x80D354u: goto L_80D354;
    case 0x80D356u: goto L_80D356;
    case 0x80D35Au: goto L_80D35A;
    case 0x80D35Du: goto L_80D35D;
    case 0x80D35Fu: goto L_80D35F;
    case 0x80D361u: goto L_80D361;
    case 0x80D365u: goto L_80D365;
    case 0x80D367u: goto L_80D367;
    case 0x80D36Au: goto L_80D36A;
    case 0x80D36Cu: goto L_80D36C;
    case 0x80D370u: goto L_80D370;
    case 0x80D372u: goto L_80D372;
    case 0x80D374u: goto L_80D374;
    case 0x80D376u: goto L_80D376;
    case 0x80D378u: goto L_80D378;
    case 0x80D37Bu: goto L_80D37B;
    case 0x80D37Du: goto L_80D37D;
    case 0x80D381u: goto L_80D381;
    case 0x80D384u: goto L_80D384;
    case 0x80D386u: goto L_80D386;
    case 0x80D388u: goto L_80D388;
    case 0x80D389u: goto L_80D389;
    case 0x80D38Au: goto L_80D38A;
    case 0x80D38Du: goto L_80D38D;
    case 0x80D38Fu: goto L_80D38F;
    case 0x80D393u: goto L_80D393;
    case 0x80D395u: goto L_80D395;
    case 0x80D399u: goto L_80D399;
    case 0x80D39Bu: goto L_80D39B;
    case 0x80D39Fu: goto L_80D39F;
    case 0x80D3A2u: goto L_80D3A2;
    case 0x80D3A6u: goto L_80D3A6;
    case 0x80D3A8u: goto L_80D3A8;
    case 0x80D3AAu: goto L_80D3AA;
    case 0x80D3ACu: goto L_80D3AC;
    case 0x80D3AEu: goto L_80D3AE;
    case 0x80D3B0u: goto L_80D3B0;
    case 0x80D3B2u: goto L_80D3B2;
    case 0x80D3B4u: goto L_80D3B4;
    case 0x80D3B6u: goto L_80D3B6;
    case 0x80D3B8u: goto L_80D3B8;
    case 0x80D3BAu: goto L_80D3BA;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80D2B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2B7u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2B7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x65u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2B7 STX
    hw.write(cpu.address("dp", 0x65u), cpu.x, cpu.x8?8:16);
    goto L_80D2B9;
L_80D2B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2B9u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2B9u, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2B9 LDA
    cpu.loadA(hw.readW(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D2BD;
L_80D2BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2BDu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2BDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2BD AND
    cpu.logicAnd(0x300u);
    goto L_80D2C0;
L_80D2C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2C0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2C0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2C0 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_80D2C2;
L_80D2C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2C2u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2C2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2C2 STZ
    hw.write(cpu.address("dp", 0x2u), 0, cpu.m8?8:16);
    goto L_80D2C4;
L_80D2C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2C4u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2C4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2C4 TXA
    cpu.transfer("TXA");
    goto L_80D2C5;
L_80D2C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2C5u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2C5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2C5 SEC
    cpu.setFlag('C', true);
    goto L_80D2C6;
L_80D2C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2C6u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2C6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2C6 SBC
    cpu.sbc(0x16u);
    goto L_80D2C9;
L_80D2C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2C9u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2C9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2C9 TAX
    cpu.transfer("TAX");
    goto L_80D2CA;
L_80D2CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2CAu,cpu,0xECu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2CAu, 5u, 3u, cpu.address("abs", 0x096Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2CA CPX
    cpu.compareX(hw.readW(cpu.address("abs", 0x96Eu), cpu.x8?8:16));
    goto L_80D2CD;
L_80D2CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2CDu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2CDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2CD BCC -> $80D33D
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80D33D; }
    goto L_80D2CF;
L_80D2CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2CFu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2CFu, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2CF LDA
    cpu.loadA(hw.readW(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D2D3;
L_80D2D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2D3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2D3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2D3 BEQ -> $80D2E4
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D2E4; }
    goto L_80D2D5;
L_80D2D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2D5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2D5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2D5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D2D7;
L_80D2D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2D7u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2D7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2D7 BNE -> $80D33D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D33D; }
    goto L_80D2D9;
L_80D2D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2D9u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2D9u, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2D9 LDA
    cpu.loadA(hw.readW(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D2DD;
L_80D2DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2DDu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2DDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2DD AND
    cpu.logicAnd(0x300u);
    goto L_80D2E0;
L_80D2E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2E0u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2E0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2E0 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16));
    goto L_80D2E2;
L_80D2E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2E2u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2E2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2E2 BNE -> $80D33D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D33D; }
    goto L_80D2E4;
L_80D2E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2E4u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2E4u, 6u, 4u, ((0x7E1FFEu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2E4 LDA
    cpu.loadA(hw.readW(((0x7E1FFEu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D2E8;
L_80D2E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2E8u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2E8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2E8 BEQ -> $80D2F5
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D2F5; }
    goto L_80D2EA;
L_80D2EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2EAu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2EAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2EA CMP
    cpu.compareA(0xFFFFu);
    goto L_80D2ED;
L_80D2ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2EDu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2EDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2ED BEQ -> $80D33D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D33D; }
    goto L_80D2EF;
L_80D2EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2EFu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2EFu, 6u, 4u, ((0x7E1FE8u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2EF LDA
    cpu.loadA(hw.readW(((0x7E1FE8u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D2F3;
L_80D2F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2F3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2F3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2F3 BEQ -> $80D2F9
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D2F9; }
    goto L_80D2F5;
L_80D2F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2F5u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2F5u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2F5 INC
    cpu.incMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_80D2F7;
L_80D2F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2F7u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2F7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2F7 BRA -> $80D2C4
    goto L_80D2C4;
L_80D2F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2F9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2F9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2F9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D2FB;
L_80D2FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2FBu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2FBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2FB CMP
    cpu.compareA(0x3u);
    goto L_80D2FE;
L_80D2FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2FEu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2FEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D2FE BCC -> $80D2C4
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80D2C4; }
    goto L_80D300;
L_80D300:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD300u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD300u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD300u, 6u, 4u, ((0x7E1FFEu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D300 LDA
    cpu.loadA(hw.readW(((0x7E1FFEu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D304;
L_80D304:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD304u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD304u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD304u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D304 AND
    cpu.logicAnd(0x300u);
    goto L_80D307;
L_80D307:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD307u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD307u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD307u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D307 STA
    hw.write(cpu.address("dp", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_80D309;
L_80D309:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD309u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD309u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD309u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D309 STX
    hw.write(cpu.address("dp", 0x61u), cpu.x, cpu.x8?8:16);
    goto L_80D30B;
L_80D30B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD30Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD30Bu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD30Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D30B TXA
    cpu.transfer("TXA");
    goto L_80D30C;
L_80D30C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD30Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD30Cu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD30Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D30C SEC
    cpu.setFlag('C', true);
    goto L_80D30D;
L_80D30D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD30Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD30Du,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD30Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D30D SBC
    cpu.sbc(0x18u);
    goto L_80D310;
L_80D310:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD310u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD310u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD310u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D310 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80D312;
L_80D312:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD312u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD312u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD312u, 6u, 4u, ((0x7E2446u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D312 STA
    hw.write(((0x7E2446u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80D316;
L_80D316:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD316u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD316u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD316u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D316 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D318;
L_80D318:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD318u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD318u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD318u, 6u, 4u, ((0x7E2440u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D318 STA
    hw.write(((0x7E2440u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80D31C;
L_80D31C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD31Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD31Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD31Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D31C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x12u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D31E;
L_80D31E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD31Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD31Eu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD31Eu, 6u, 4u, ((0x7E2442u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D31E STA
    hw.write(((0x7E2442u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80D322;
L_80D322:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD322u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD322u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD322u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D322 LDA
    cpu.setA(0x0u, 16);
    goto L_80D325;
L_80D325:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD325u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD325u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD325u, 6u, 4u, ((0x7E2444u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D325 STA
    hw.write(((0x7E2444u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80D329;
L_80D329:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD329u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD329u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD329u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D329 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D32B;
L_80D32B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD32Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD32Bu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD32Bu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D32B INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D32D;
L_80D32D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD32Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD32Du,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD32Du, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D32D INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D32F;
L_80D32F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD32Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD32Fu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD32Fu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D32F INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D331;
L_80D331:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD331u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD331u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD331u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D331 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D333;
L_80D333:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD333u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD333u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD333u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D333 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D335;
L_80D335:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD335u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD335u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD335u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D335 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D337;
L_80D337:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD337u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD337u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD337u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D337 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D339;
L_80D339:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD339u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD339u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD339u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D339 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x61u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80D33B;
L_80D33B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD33Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD33Bu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD33Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D33B BRA -> $80D2C4
    goto L_80D2C4;
L_80D33D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD33Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD33Du,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD33Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x65u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D33D LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x65u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80D33F;
L_80D33F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD33Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD33Fu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD33Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D33F STZ
    hw.write(cpu.address("dp", 0x2u), 0, cpu.m8?8:16);
    goto L_80D341;
L_80D341:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD341u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD341u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD341u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D341 TXA
    cpu.transfer("TXA");
    goto L_80D342;
L_80D342:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD342u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD342u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD342u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D342 SEC
    cpu.setFlag('C', true);
    goto L_80D343;
L_80D343:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD343u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD343u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD343u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D343 SBC
    cpu.sbc(0x16u);
    goto L_80D346;
L_80D346:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD346u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD346u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD346u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D346 TAX
    cpu.transfer("TAX");
    goto L_80D347;
L_80D347:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD347u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD347u,cpu,0xECu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD347u, 5u, 3u, cpu.address("abs", 0x096Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D347 CPX
    cpu.compareX(hw.readW(cpu.address("abs", 0x96Eu), cpu.x8?8:16));
    goto L_80D34A;
L_80D34A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD34Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD34Au,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD34Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D34A BCC -> $80D3BA
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80D3BA; }
    goto L_80D34C;
L_80D34C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD34Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD34Cu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD34Cu, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D34C LDA
    cpu.loadA(hw.readW(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D350;
L_80D350:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD350u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD350u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD350u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D350 BEQ -> $80D361
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D361; }
    goto L_80D352;
L_80D352:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD352u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD352u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD352u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D352 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D354;
L_80D354:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD354u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD354u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD354u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D354 BNE -> $80D3BA
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D3BA; }
    goto L_80D356;
L_80D356:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD356u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD356u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD356u, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D356 LDA
    cpu.loadA(hw.readW(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D35A;
L_80D35A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD35Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD35Au,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD35Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D35A AND
    cpu.logicAnd(0x300u);
    goto L_80D35D;
L_80D35D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD35Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD35Du,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD35Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D35D CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16));
    goto L_80D35F;
L_80D35F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD35Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD35Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD35Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D35F BNE -> $80D3BA
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D3BA; }
    goto L_80D361;
L_80D361:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD361u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD361u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD361u, 6u, 4u, ((0x7E2002u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D361 LDA
    cpu.loadA(hw.readW(((0x7E2002u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D365;
L_80D365:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD365u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD365u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD365u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D365 BEQ -> $80D372
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D372; }
    goto L_80D367;
L_80D367:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD367u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD367u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD367u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D367 CMP
    cpu.compareA(0xFFFFu);
    goto L_80D36A;
L_80D36A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD36Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD36Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD36Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D36A BEQ -> $80D3BA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D3BA; }
    goto L_80D36C;
L_80D36C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD36Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD36Cu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD36Cu, 6u, 4u, ((0x7E1FECu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D36C LDA
    cpu.loadA(hw.readW(((0x7E1FECu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D370;
L_80D370:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD370u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD370u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD370u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D370 BEQ -> $80D376
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D376; }
    goto L_80D372;
L_80D372:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD372u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD372u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD372u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D372 INC
    cpu.incMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_80D374;
L_80D374:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD374u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD374u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD374u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D374 BRA -> $80D341
    goto L_80D341;
L_80D376:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD376u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD376u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD376u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D376 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D378;
L_80D378:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD378u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD378u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD378u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D378 CMP
    cpu.compareA(0x3u);
    goto L_80D37B;
L_80D37B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD37Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD37Bu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD37Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D37B BCC -> $80D341
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80D341; }
    goto L_80D37D;
L_80D37D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD37Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD37Du,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD37Du, 6u, 4u, ((0x7E2002u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D37D LDA
    cpu.loadA(hw.readW(((0x7E2002u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D381;
L_80D381:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD381u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD381u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD381u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D381 AND
    cpu.logicAnd(0x300u);
    goto L_80D384;
L_80D384:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD384u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD384u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD384u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D384 STA
    hw.write(cpu.address("dp", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_80D386;
L_80D386:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD386u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD386u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD386u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D386 STX
    hw.write(cpu.address("dp", 0x61u), cpu.x, cpu.x8?8:16);
    goto L_80D388;
L_80D388:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD388u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD388u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD388u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D388 TXA
    cpu.transfer("TXA");
    goto L_80D389;
L_80D389:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD389u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD389u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD389u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D389 SEC
    cpu.setFlag('C', true);
    goto L_80D38A;
L_80D38A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD38Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD38Au,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD38Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D38A SBC
    cpu.sbc(0x14u);
    goto L_80D38D;
L_80D38D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD38Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD38Du,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD38Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D38D LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80D38F;
L_80D38F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD38Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD38Fu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD38Fu, 6u, 4u, ((0x7E2446u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D38F STA
    hw.write(((0x7E2446u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80D393;
L_80D393:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD393u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD393u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD393u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D393 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D395;
L_80D395:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD395u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD395u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD395u, 6u, 4u, ((0x7E2440u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D395 STA
    hw.write(((0x7E2440u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80D399;
L_80D399:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD399u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD399u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD399u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D399 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x12u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D39B;
L_80D39B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD39Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD39Bu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD39Bu, 6u, 4u, ((0x7E2442u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D39B STA
    hw.write(((0x7E2442u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80D39F;
L_80D39F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD39Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD39Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD39Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D39F LDA
    cpu.setA(0x2u, 16);
    goto L_80D3A2;
L_80D3A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3A2u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3A2u, 6u, 4u, ((0x7E2444u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D3A2 STA
    hw.write(((0x7E2444u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80D3A6;
L_80D3A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3A6u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3A6u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D3A6 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D3A8;
L_80D3A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3A8u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3A8u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D3A8 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D3AA;
L_80D3AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3AAu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3AAu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D3AA INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D3AC;
L_80D3AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3ACu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3ACu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D3AC INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D3AE;
L_80D3AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3AEu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3AEu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D3AE INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D3B0;
L_80D3B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3B0u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3B0u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D3B0 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D3B2;
L_80D3B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3B2u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3B2u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D3B2 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D3B4;
L_80D3B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3B4u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3B4u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D3B4 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D3B6;
L_80D3B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3B6u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3B6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D3B6 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x61u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80D3B8;
L_80D3B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3B8u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3B8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D3B8 BRA -> $80D341
    goto L_80D341;
L_80D3BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3BAu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3BAu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D3BA RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80D3BAu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80D3BAu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_829147_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x829147u: goto L_829147;
    case 0x829149u: goto L_829149;
    case 0x82914Du: goto L_82914D;
    case 0x829150u: goto L_829150;
    case 0x829153u: goto L_829153;
    case 0x829155u: goto L_829155;
    case 0x829158u: goto L_829158;
    case 0x82915Au: goto L_82915A;
    case 0x82915Du: goto L_82915D;
    case 0x82915Fu: goto L_82915F;
    case 0x829162u: goto L_829162;
    case 0x829165u: goto L_829165;
    case 0x829168u: goto L_829168;
    case 0x82916Au: goto L_82916A;
    case 0x82916Du: goto L_82916D;
    case 0x829170u: goto L_829170;
    case 0x829173u: goto L_829173;
    case 0x829175u: goto L_829175;
    case 0x829178u: goto L_829178;
    case 0x82917Bu: goto L_82917B;
    case 0x82917Eu: goto L_82917E;
    case 0x829180u: goto L_829180;
    case 0x829183u: goto L_829183;
    case 0x829185u: goto L_829185;
    case 0x829188u: goto L_829188;
    case 0x82918Au: goto L_82918A;
    case 0x82918Du: goto L_82918D;
    case 0x829190u: goto L_829190;
    case 0x829193u: goto L_829193;
    case 0x829195u: goto L_829195;
    case 0x829198u: goto L_829198;
    case 0x82919Bu: goto L_82919B;
    case 0x82919Eu: goto L_82919E;
    case 0x8291A0u: goto L_8291A0;
    case 0x8291A3u: goto L_8291A3;
    case 0x8291A5u: goto L_8291A5;
    case 0x8291A8u: goto L_8291A8;
    case 0x8291ABu: goto L_8291AB;
    case 0x8291AEu: goto L_8291AE;
    case 0x8291B1u: goto L_8291B1;
    case 0x8291B4u: goto L_8291B4;
    case 0x8291B7u: goto L_8291B7;
    case 0x8291BAu: goto L_8291BA;
    case 0x8291BDu: goto L_8291BD;
    case 0x8291C0u: goto L_8291C0;
    case 0x8291C2u: goto L_8291C2;
    case 0x8291C6u: goto L_8291C6;
    case 0x8291C9u: goto L_8291C9;
    case 0x8291CCu: goto L_8291CC;
    case 0x8291CEu: goto L_8291CE;
    case 0x8291D1u: goto L_8291D1;
    case 0x8291D5u: goto L_8291D5;
    case 0x8291D8u: goto L_8291D8;
    case 0x8291DCu: goto L_8291DC;
    case 0x8291DEu: goto L_8291DE;
    case 0x8291E1u: goto L_8291E1;
    case 0x8291E5u: goto L_8291E5;
    case 0x8291E9u: goto L_8291E9;
    case 0x8291ECu: goto L_8291EC;
    case 0x8291EEu: goto L_8291EE;
    case 0x8291F1u: goto L_8291F1;
    case 0x8291F4u: goto L_8291F4;
    case 0x8291F6u: goto L_8291F6;
    case 0x8291F9u: goto L_8291F9;
    case 0x8291FCu: goto L_8291FC;
    case 0x8291FFu: goto L_8291FF;
    case 0x829202u: goto L_829202;
    case 0x829204u: goto L_829204;
    case 0x829207u: goto L_829207;
    case 0x829209u: goto L_829209;
    case 0x82920Cu: goto L_82920C;
    case 0x82920Eu: goto L_82920E;
    case 0x829211u: goto L_829211;
    case 0x829215u: goto L_829215;
    case 0x829217u: goto L_829217;
    case 0x82921Bu: goto L_82921B;
    case 0x82921Fu: goto L_82921F;
    case 0x829221u: goto L_829221;
    case 0x829225u: goto L_829225;
    case 0x829228u: goto L_829228;
    case 0x82922Au: goto L_82922A;
    case 0x82922Eu: goto L_82922E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_829147:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9147u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9147u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9147u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829147 SEP
    cpu.sep(0x20u);
    goto L_829149;
L_829149:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9149u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9149u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9149u, 8u, 4u, 0x808D3Cu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829149 JSL -> $808D3C stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x914Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x914Du,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808D3Cu, 0x829149u); }
    goto L_82914D;
L_82914D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x914Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x914Du,0x82914Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x914Du,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x914Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82914D LDX
    cpu.setX(0x2000u, 16);
    goto L_829150;
L_829150:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9150u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9150u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9150u, 5u, 3u, cpu.address("abs", 0x2181u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829150 STX
    hw.write(cpu.address("abs", 0x2181u), cpu.x, cpu.x8?8:16);
    goto L_829153;
L_829153:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9153u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9153u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9153u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829153 LDA
    cpu.setA(0x0u, 8);
    goto L_829155;
L_829155:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9155u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9155u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9155u, 4u, 3u, cpu.address("abs", 0x2183u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829155 STA
    hw.write(cpu.address("abs", 0x2183u), cpu.a, cpu.m8?8:16);
    goto L_829158;
L_829158:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9158u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9158u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9158u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829158 LDA
    cpu.setA(0x8u, 8);
    goto L_82915A;
L_82915A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x915Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x915Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x915Au, 4u, 3u, cpu.address("abs", 0x4370u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82915A STA
    hw.write(cpu.address("abs", 0x4370u), cpu.a, cpu.m8?8:16);
    goto L_82915D;
L_82915D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x915Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x915Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x915Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82915D LDA
    cpu.setA(0x80u, 8);
    goto L_82915F;
L_82915F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x915Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x915Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x915Fu, 4u, 3u, cpu.address("abs", 0x4371u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82915F STA
    hw.write(cpu.address("abs", 0x4371u), cpu.a, cpu.m8?8:16);
    goto L_829162;
L_829162:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9162u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9162u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9162u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829162 LDX
    cpu.setX(0x8D46u, 16);
    goto L_829165;
L_829165:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9165u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9165u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9165u, 5u, 3u, cpu.address("abs", 0x4372u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829165 STX
    hw.write(cpu.address("abs", 0x4372u), cpu.x, cpu.x8?8:16);
    goto L_829168;
L_829168:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9168u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9168u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9168u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829168 LDA
    cpu.setA(0x80u, 8);
    goto L_82916A;
L_82916A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x916Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x916Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x916Au, 4u, 3u, cpu.address("abs", 0x4374u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82916A STA
    hw.write(cpu.address("abs", 0x4374u), cpu.a, cpu.m8?8:16);
    goto L_82916D;
L_82916D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x916Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x916Du,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x916Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82916D LDX
    cpu.setX(0x800u, 16);
    goto L_829170;
L_829170:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9170u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9170u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9170u, 5u, 3u, cpu.address("abs", 0x4375u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829170 STX
    hw.write(cpu.address("abs", 0x4375u), cpu.x, cpu.x8?8:16);
    goto L_829173;
L_829173:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9173u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9173u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9173u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829173 LDA
    cpu.setA(0x80u, 8);
    goto L_829175;
L_829175:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9175u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9175u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9175u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829175 STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_829178;
L_829178:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9178u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9178u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9178u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829178 LDX
    cpu.setX(0x3000u, 16);
    goto L_82917B;
L_82917B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x917Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x917Bu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x917Bu, 5u, 3u, cpu.address("abs", 0x2181u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82917B STX
    hw.write(cpu.address("abs", 0x2181u), cpu.x, cpu.x8?8:16);
    goto L_82917E;
L_82917E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x917Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x917Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x917Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82917E LDA
    cpu.setA(0x0u, 8);
    goto L_829180;
L_829180:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9180u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9180u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9180u, 4u, 3u, cpu.address("abs", 0x2183u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829180 STA
    hw.write(cpu.address("abs", 0x2183u), cpu.a, cpu.m8?8:16);
    goto L_829183;
L_829183:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9183u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9183u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9183u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829183 LDA
    cpu.setA(0x8u, 8);
    goto L_829185;
L_829185:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9185u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9185u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9185u, 4u, 3u, cpu.address("abs", 0x4370u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829185 STA
    hw.write(cpu.address("abs", 0x4370u), cpu.a, cpu.m8?8:16);
    goto L_829188;
L_829188:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9188u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9188u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9188u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829188 LDA
    cpu.setA(0x80u, 8);
    goto L_82918A;
L_82918A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x918Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x918Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x918Au, 4u, 3u, cpu.address("abs", 0x4371u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82918A STA
    hw.write(cpu.address("abs", 0x4371u), cpu.a, cpu.m8?8:16);
    goto L_82918D;
L_82918D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x918Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x918Du,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x918Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82918D LDX
    cpu.setX(0x8D46u, 16);
    goto L_829190;
L_829190:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9190u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9190u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9190u, 5u, 3u, cpu.address("abs", 0x4372u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829190 STX
    hw.write(cpu.address("abs", 0x4372u), cpu.x, cpu.x8?8:16);
    goto L_829193;
L_829193:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9193u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9193u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9193u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829193 LDA
    cpu.setA(0x80u, 8);
    goto L_829195;
L_829195:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9195u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9195u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9195u, 4u, 3u, cpu.address("abs", 0x4374u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829195 STA
    hw.write(cpu.address("abs", 0x4374u), cpu.a, cpu.m8?8:16);
    goto L_829198;
L_829198:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9198u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9198u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9198u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829198 LDX
    cpu.setX(0x800u, 16);
    goto L_82919B;
L_82919B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x919Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x919Bu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x919Bu, 5u, 3u, cpu.address("abs", 0x4375u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82919B STX
    hw.write(cpu.address("abs", 0x4375u), cpu.x, cpu.x8?8:16);
    goto L_82919E;
L_82919E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x919Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x919Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x919Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82919E LDA
    cpu.setA(0x80u, 8);
    goto L_8291A0;
L_8291A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91A0u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91A0u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8291A0 STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_8291A3;
L_8291A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91A3u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91A3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8291A3 REP
    cpu.rep(0x20u);
    goto L_8291A5;
L_8291A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91A5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91A5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8291A5 LDA
    cpu.setA(0x1u, 16);
    goto L_8291A8;
L_8291A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91A8u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91A8u, 5u, 3u, cpu.address("abs", 0x0816u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8291A8 STA
    hw.write(cpu.address("abs", 0x816u), cpu.a, cpu.m8?8:16);
    goto L_8291AB;
L_8291AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91ABu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91ABu, 5u, 3u, cpu.address("abs", 0x01AFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8291AB STZ
    hw.write(cpu.address("abs", 0x1AFu), 0, cpu.m8?8:16);
    goto L_8291AE;
L_8291AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91AEu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91AEu, 5u, 3u, cpu.address("abs", 0x01B1u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8291AE STZ
    hw.write(cpu.address("abs", 0x1B1u), 0, cpu.m8?8:16);
    goto L_8291B1;
L_8291B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B1u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B1u, 5u, 3u, cpu.address("abs", 0x017Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8291B1 STZ
    hw.write(cpu.address("abs", 0x17Bu), 0, cpu.m8?8:16);
    goto L_8291B4;
L_8291B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B4u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B4u, 5u, 3u, cpu.address("abs", 0x017Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8291B4 STZ
    hw.write(cpu.address("abs", 0x17Du), 0, cpu.m8?8:16);
    goto L_8291B7;
L_8291B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B7u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B7u, 5u, 3u, cpu.address("abs", 0x017Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8291B7 STZ
    hw.write(cpu.address("abs", 0x17Fu), 0, cpu.m8?8:16);
    goto L_8291BA;
L_8291BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91BAu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91BAu, 5u, 3u, cpu.address("abs", 0x0181u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8291BA STZ
    hw.write(cpu.address("abs", 0x181u), 0, cpu.m8?8:16);
    goto L_8291BD;
L_8291BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91BDu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91BDu, 5u, 3u, cpu.address("abs", 0x0141u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8291BD STZ
    hw.write(cpu.address("abs", 0x141u), 0, cpu.m8?8:16);
    goto L_8291C0;
L_8291C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91C0u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91C0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8291C0 STZ
    hw.write(cpu.address("dp", 0x7Eu), 0, cpu.m8?8:16);
    goto L_8291C2;
L_8291C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91C2u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91C2u, 8u, 4u, 0x809C0Cu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8291C2 JSL -> $809C0C stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x91C5u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x91C6u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809C0Cu, 0x8291C2u); }
    goto L_8291C6;
L_8291C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91C6u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91C6u,0x8291C6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91C6u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91C6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8291C6 LDX
    cpu.setX(0x0u, 16);
    goto L_8291C9;
L_8291C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91C9u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91C9u, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8291C9 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8291CC;
L_8291CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91CCu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91CCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8291CC BNE -> $8291DE
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8291DE; }
    goto L_8291CE;
L_8291CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91CEu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91CEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8291CE LDY
    cpu.setY(0x0u, 16);
    goto L_8291D1;
L_8291D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91D1u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91D1u, 8u, 4u, 0x848221u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8291D1 JSL -> $848221 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x91D4u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x91D5u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x848221u, 0x8291D1u); }
    goto L_8291D5;
L_8291D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91D5u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91D5u,0x8291D5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91D5u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91D5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8291D5 LDX
    cpu.setX(0x0u, 16);
    goto L_8291D8;
L_8291D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91D8u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91D8u, 8u, 4u, 0x848000u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8291D8 JSL -> $848000 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x91DBu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x91DCu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x848000u, 0x8291D8u); }
    goto L_8291DC;
L_8291DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91DCu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91DCu,0x8291DCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91DCu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91DCu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8291DC BRA -> $8291E1
    goto L_8291E1;
L_8291DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91DEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91DEu, 6u, 3u, cpu.address("abs", 0xCD6Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8291DE JSR -> $82CD6B stack real
    { cpu.push16Value(hw,0x91E0u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x91E1u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCD6Bu), 0x8291DEu); }
    goto L_8291E1;
L_8291E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91E1u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91E1u,0x8291E1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91E1u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91E1u, 8u, 4u, 0x809C3Au, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8291E1 JSL -> $809C3A stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x91E4u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x91E5u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809C3Au, 0x8291E1u); }
    goto L_8291E5;
L_8291E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91E5u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91E5u,0x8291E5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91E5u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91E5u, 8u, 4u, 0x809C69u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8291E5 JSL -> $809C69 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x91E8u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x91E9u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809C69u, 0x8291E5u); }
    goto L_8291E9;
L_8291E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91E9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91E9u,0x8291E9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91E9u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91E9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8291E9 LDX
    cpu.setX(0x100u, 16);
    goto L_8291EC;
L_8291EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91ECu,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91ECu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8291EC STX
    hw.write(cpu.address("dp", 0x5Bu), cpu.x, cpu.x8?8:16);
    goto L_8291EE;
L_8291EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91EEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91EEu, 6u, 3u, cpu.address("abs", 0xBD2Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8291EE JSR -> $82BD2B stack real
    { cpu.push16Value(hw,0x91F0u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x91F1u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBD2Bu), 0x8291EEu); }
    goto L_8291F1;
L_8291F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91F1u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91F1u,0x8291F1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91F1u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91F1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8291F1 LDX
    cpu.setX(0x0u, 16);
    goto L_8291F4;
L_8291F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91F4u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91F4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8291F4 STX
    hw.write(cpu.address("dp", 0x5Bu), cpu.x, cpu.x8?8:16);
    goto L_8291F6;
L_8291F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91F6u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91F6u, 6u, 3u, cpu.address("abs", 0xBD2Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8291F6 JSR -> $82BD2B stack real
    { cpu.push16Value(hw,0x91F8u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x91F9u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBD2Bu), 0x8291F6u); }
    goto L_8291F9;
L_8291F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91F9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91F9u,0x8291F9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91F9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91F9u, 6u, 3u, cpu.address("abs", 0xA84Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8291F9 JSR -> $82A84E stack real
    { cpu.push16Value(hw,0x91FBu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x91FCu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA84Eu), 0x8291F9u); }
    goto L_8291FC;
L_8291FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91FCu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91FCu,0x8291FCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91FCu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91FCu, 6u, 3u, cpu.address("abs", 0x9B0Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8291FC JSR -> $829B0B stack real
    { cpu.push16Value(hw,0x91FEu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x91FFu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9B0Bu), 0x8291FCu); }
    goto L_8291FF;
L_8291FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91FFu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91FFu,0x8291FFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91FFu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91FFu, 5u, 3u, cpu.address("abs", 0x0176u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8291FF STZ
    hw.write(cpu.address("abs", 0x176u), 0, cpu.m8?8:16);
    goto L_829202;
L_829202:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9202u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9202u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9202u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829202 SEP
    cpu.sep(0x20u);
    goto L_829204;
L_829204:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9204u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9204u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9204u, 4u, 3u, cpu.address("abs", 0x0193u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829204 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x193u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829207;
L_829207:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9207u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9207u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9207u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829207 BNE -> $829221
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_829221; }
    goto L_829209;
L_829209:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9209u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9209u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9209u, 4u, 3u, cpu.address("abs", 0x018Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829209 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x18Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82920C;
L_82920C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x920Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x920Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x920Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82920C BNE -> $829225
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_829225; }
    goto L_82920E;
L_82920E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x920Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x920Eu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x920Eu, 5u, 3u, cpu.address("abs", 0x014Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82920E LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x14Cu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_829211;
L_829211:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9211u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9211u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9211u, 5u, 4u, ((0x9E9564u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829211 LDA
    cpu.loadA(hw.readW(((0x9E9564u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829215;
L_829215:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9215u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9215u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9215u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829215 BEQ -> $829221
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_829221; }
    goto L_829217;
L_829217:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9217u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9217u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9217u, 8u, 4u, 0x80A6BDu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829217 JSL -> $80A6BD stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x921Au); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x921Bu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6BDu, 0x829217u); }
    goto L_82921B;
L_82921B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x921Bu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x921Bu,0x82921Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x921Bu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x921Bu, 8u, 4u, 0x80A6A5u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82921B JSL -> $80A6A5 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x921Eu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x921Fu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6A5u, 0x82921Bu); }
    goto L_82921F;
L_82921F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x921Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x921Fu,0x82921Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x921Fu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x921Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82921F BRA -> $829225
    goto L_829225;
L_829221:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9221u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9221u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9221u, 8u, 4u, 0x80A5D1u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829221 JSL -> $80A5D1 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9224u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9225u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A5D1u, 0x829221u); }
    goto L_829225;
L_829225:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9225u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9225u,0x829225u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9225u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9225u, 4u, 3u, cpu.address("abs", 0x018Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829225 STZ
    hw.write(cpu.address("abs", 0x18Du), 0, cpu.m8?8:16);
    goto L_829228;
L_829228:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9228u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9228u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9228u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829228 STZ
    hw.write(cpu.address("dp", 0x49u), 0, cpu.m8?8:16);
    goto L_82922A;
L_82922A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x922Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x922Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x922Au, 8u, 4u, 0x808D2Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82922A JSL -> $808D2F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x922Du); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x922Eu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808D2Fu, 0x82922Au); }
    goto L_82922E;
L_82922E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x922Eu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x922Eu,0x82922Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x922Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x922Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82922E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82922Eu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82922Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_829147_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x829147u: goto L_829147;
    case 0x829149u: goto L_829149;
    case 0x82914Du: goto L_82914D;
    case 0x829150u: goto L_829150;
    case 0x829153u: goto L_829153;
    case 0x829155u: goto L_829155;
    case 0x829158u: goto L_829158;
    case 0x82915Au: goto L_82915A;
    case 0x82915Du: goto L_82915D;
    case 0x82915Fu: goto L_82915F;
    case 0x829162u: goto L_829162;
    case 0x829165u: goto L_829165;
    case 0x829168u: goto L_829168;
    case 0x82916Au: goto L_82916A;
    case 0x82916Du: goto L_82916D;
    case 0x829170u: goto L_829170;
    case 0x829173u: goto L_829173;
    case 0x829175u: goto L_829175;
    case 0x829178u: goto L_829178;
    case 0x82917Bu: goto L_82917B;
    case 0x82917Eu: goto L_82917E;
    case 0x829180u: goto L_829180;
    case 0x829183u: goto L_829183;
    case 0x829185u: goto L_829185;
    case 0x829188u: goto L_829188;
    case 0x82918Au: goto L_82918A;
    case 0x82918Du: goto L_82918D;
    case 0x829190u: goto L_829190;
    case 0x829193u: goto L_829193;
    case 0x829195u: goto L_829195;
    case 0x829198u: goto L_829198;
    case 0x82919Bu: goto L_82919B;
    case 0x82919Eu: goto L_82919E;
    case 0x8291A0u: goto L_8291A0;
    case 0x8291A3u: goto L_8291A3;
    case 0x8291A5u: goto L_8291A5;
    case 0x8291A8u: goto L_8291A8;
    case 0x8291ABu: goto L_8291AB;
    case 0x8291AEu: goto L_8291AE;
    case 0x8291B1u: goto L_8291B1;
    case 0x8291B4u: goto L_8291B4;
    case 0x8291B7u: goto L_8291B7;
    case 0x8291BAu: goto L_8291BA;
    case 0x8291BDu: goto L_8291BD;
    case 0x8291C0u: goto L_8291C0;
    case 0x8291C2u: goto L_8291C2;
    case 0x8291C6u: goto L_8291C6;
    case 0x8291C9u: goto L_8291C9;
    case 0x8291CCu: goto L_8291CC;
    case 0x8291CEu: goto L_8291CE;
    case 0x8291D1u: goto L_8291D1;
    case 0x8291D5u: goto L_8291D5;
    case 0x8291D8u: goto L_8291D8;
    case 0x8291DCu: goto L_8291DC;
    case 0x8291DEu: goto L_8291DE;
    case 0x8291E1u: goto L_8291E1;
    case 0x8291E5u: goto L_8291E5;
    case 0x8291E9u: goto L_8291E9;
    case 0x8291ECu: goto L_8291EC;
    case 0x8291EEu: goto L_8291EE;
    case 0x8291F1u: goto L_8291F1;
    case 0x8291F4u: goto L_8291F4;
    case 0x8291F6u: goto L_8291F6;
    case 0x8291F9u: goto L_8291F9;
    case 0x8291FCu: goto L_8291FC;
    case 0x8291FFu: goto L_8291FF;
    case 0x829202u: goto L_829202;
    case 0x829204u: goto L_829204;
    case 0x829207u: goto L_829207;
    case 0x829209u: goto L_829209;
    case 0x82920Cu: goto L_82920C;
    case 0x82920Eu: goto L_82920E;
    case 0x829211u: goto L_829211;
    case 0x829215u: goto L_829215;
    case 0x829217u: goto L_829217;
    case 0x82921Bu: goto L_82921B;
    case 0x82921Fu: goto L_82921F;
    case 0x829221u: goto L_829221;
    case 0x829225u: goto L_829225;
    case 0x829228u: goto L_829228;
    case 0x82922Au: goto L_82922A;
    case 0x82922Eu: goto L_82922E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_829147:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9147u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9147u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9147u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829147 SEP
    cpu.sep(0x20u);
    goto L_829149;
L_829149:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9149u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9149u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9149u, 8u, 4u, 0x808D3Cu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829149 JSL -> $808D3C stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x914Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x914Du,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808D3Cu, 0x829149u); }
    goto L_82914D;
L_82914D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x914Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x914Du,0x82914Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x914Du,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x914Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82914D LDX
    cpu.setX(0x2000u, 16);
    goto L_829150;
L_829150:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9150u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9150u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9150u, 5u, 3u, cpu.address("abs", 0x2181u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829150 STX
    hw.write(cpu.address("abs", 0x2181u), cpu.x, cpu.x8?8:16);
    goto L_829153;
L_829153:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9153u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9153u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9153u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829153 LDA
    cpu.setA(0x0u, 8);
    goto L_829155;
L_829155:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9155u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9155u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9155u, 4u, 3u, cpu.address("abs", 0x2183u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829155 STA
    hw.write(cpu.address("abs", 0x2183u), cpu.a, cpu.m8?8:16);
    goto L_829158;
L_829158:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9158u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9158u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9158u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829158 LDA
    cpu.setA(0x8u, 8);
    goto L_82915A;
L_82915A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x915Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x915Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x915Au, 4u, 3u, cpu.address("abs", 0x4370u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82915A STA
    hw.write(cpu.address("abs", 0x4370u), cpu.a, cpu.m8?8:16);
    goto L_82915D;
L_82915D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x915Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x915Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x915Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82915D LDA
    cpu.setA(0x80u, 8);
    goto L_82915F;
L_82915F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x915Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x915Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x915Fu, 4u, 3u, cpu.address("abs", 0x4371u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82915F STA
    hw.write(cpu.address("abs", 0x4371u), cpu.a, cpu.m8?8:16);
    goto L_829162;
L_829162:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9162u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9162u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9162u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829162 LDX
    cpu.setX(0x8D46u, 16);
    goto L_829165;
L_829165:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9165u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9165u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9165u, 5u, 3u, cpu.address("abs", 0x4372u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829165 STX
    hw.write(cpu.address("abs", 0x4372u), cpu.x, cpu.x8?8:16);
    goto L_829168;
L_829168:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9168u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9168u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9168u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829168 LDA
    cpu.setA(0x80u, 8);
    goto L_82916A;
L_82916A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x916Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x916Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x916Au, 4u, 3u, cpu.address("abs", 0x4374u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82916A STA
    hw.write(cpu.address("abs", 0x4374u), cpu.a, cpu.m8?8:16);
    goto L_82916D;
L_82916D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x916Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x916Du,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x916Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82916D LDX
    cpu.setX(0x800u, 16);
    goto L_829170;
L_829170:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9170u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9170u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9170u, 5u, 3u, cpu.address("abs", 0x4375u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829170 STX
    hw.write(cpu.address("abs", 0x4375u), cpu.x, cpu.x8?8:16);
    goto L_829173;
L_829173:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9173u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9173u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9173u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829173 LDA
    cpu.setA(0x80u, 8);
    goto L_829175;
L_829175:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9175u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9175u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9175u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829175 STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_829178;
L_829178:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9178u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9178u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9178u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829178 LDX
    cpu.setX(0x3000u, 16);
    goto L_82917B;
L_82917B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x917Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x917Bu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x917Bu, 5u, 3u, cpu.address("abs", 0x2181u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82917B STX
    hw.write(cpu.address("abs", 0x2181u), cpu.x, cpu.x8?8:16);
    goto L_82917E;
L_82917E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x917Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x917Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x917Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82917E LDA
    cpu.setA(0x0u, 8);
    goto L_829180;
L_829180:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9180u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9180u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9180u, 4u, 3u, cpu.address("abs", 0x2183u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829180 STA
    hw.write(cpu.address("abs", 0x2183u), cpu.a, cpu.m8?8:16);
    goto L_829183;
L_829183:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9183u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9183u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9183u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829183 LDA
    cpu.setA(0x8u, 8);
    goto L_829185;
L_829185:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9185u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9185u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9185u, 4u, 3u, cpu.address("abs", 0x4370u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829185 STA
    hw.write(cpu.address("abs", 0x4370u), cpu.a, cpu.m8?8:16);
    goto L_829188;
L_829188:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9188u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9188u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9188u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829188 LDA
    cpu.setA(0x80u, 8);
    goto L_82918A;
L_82918A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x918Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x918Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x918Au, 4u, 3u, cpu.address("abs", 0x4371u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82918A STA
    hw.write(cpu.address("abs", 0x4371u), cpu.a, cpu.m8?8:16);
    goto L_82918D;
L_82918D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x918Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x918Du,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x918Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82918D LDX
    cpu.setX(0x8D46u, 16);
    goto L_829190;
L_829190:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9190u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9190u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9190u, 5u, 3u, cpu.address("abs", 0x4372u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829190 STX
    hw.write(cpu.address("abs", 0x4372u), cpu.x, cpu.x8?8:16);
    goto L_829193;
L_829193:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9193u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9193u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9193u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829193 LDA
    cpu.setA(0x80u, 8);
    goto L_829195;
L_829195:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9195u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9195u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9195u, 4u, 3u, cpu.address("abs", 0x4374u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829195 STA
    hw.write(cpu.address("abs", 0x4374u), cpu.a, cpu.m8?8:16);
    goto L_829198;
L_829198:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9198u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9198u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9198u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829198 LDX
    cpu.setX(0x800u, 16);
    goto L_82919B;
L_82919B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x919Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x919Bu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x919Bu, 5u, 3u, cpu.address("abs", 0x4375u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82919B STX
    hw.write(cpu.address("abs", 0x4375u), cpu.x, cpu.x8?8:16);
    goto L_82919E;
L_82919E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x919Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x919Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x919Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82919E LDA
    cpu.setA(0x80u, 8);
    goto L_8291A0;
L_8291A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91A0u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91A0u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8291A0 STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_8291A3;
L_8291A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91A3u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91A3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8291A3 REP
    cpu.rep(0x20u);
    goto L_8291A5;
L_8291A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91A5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91A5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8291A5 LDA
    cpu.setA(0x1u, 16);
    goto L_8291A8;
L_8291A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91A8u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91A8u, 5u, 3u, cpu.address("abs", 0x0816u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8291A8 STA
    hw.write(cpu.address("abs", 0x816u), cpu.a, cpu.m8?8:16);
    goto L_8291AB;
L_8291AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91ABu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91ABu, 5u, 3u, cpu.address("abs", 0x01AFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8291AB STZ
    hw.write(cpu.address("abs", 0x1AFu), 0, cpu.m8?8:16);
    goto L_8291AE;
L_8291AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91AEu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91AEu, 5u, 3u, cpu.address("abs", 0x01B1u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8291AE STZ
    hw.write(cpu.address("abs", 0x1B1u), 0, cpu.m8?8:16);
    goto L_8291B1;
L_8291B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B1u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B1u, 5u, 3u, cpu.address("abs", 0x017Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8291B1 STZ
    hw.write(cpu.address("abs", 0x17Bu), 0, cpu.m8?8:16);
    goto L_8291B4;
L_8291B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B4u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B4u, 5u, 3u, cpu.address("abs", 0x017Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8291B4 STZ
    hw.write(cpu.address("abs", 0x17Du), 0, cpu.m8?8:16);
    goto L_8291B7;
L_8291B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B7u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B7u, 5u, 3u, cpu.address("abs", 0x017Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8291B7 STZ
    hw.write(cpu.address("abs", 0x17Fu), 0, cpu.m8?8:16);
    goto L_8291BA;
L_8291BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91BAu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91BAu, 5u, 3u, cpu.address("abs", 0x0181u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8291BA STZ
    hw.write(cpu.address("abs", 0x181u), 0, cpu.m8?8:16);
    goto L_8291BD;
L_8291BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91BDu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91BDu, 5u, 3u, cpu.address("abs", 0x0141u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8291BD STZ
    hw.write(cpu.address("abs", 0x141u), 0, cpu.m8?8:16);
    goto L_8291C0;
L_8291C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91C0u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91C0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8291C0 STZ
    hw.write(cpu.address("dp", 0x7Eu), 0, cpu.m8?8:16);
    goto L_8291C2;
L_8291C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91C2u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91C2u, 8u, 4u, 0x809C0Cu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8291C2 JSL -> $809C0C stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x91C5u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x91C6u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809C0Cu, 0x8291C2u); }
    goto L_8291C6;
L_8291C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91C6u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91C6u,0x8291C6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91C6u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91C6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8291C6 LDX
    cpu.setX(0x0u, 16);
    goto L_8291C9;
L_8291C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91C9u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91C9u, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8291C9 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8291CC;
L_8291CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91CCu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91CCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8291CC BNE -> $8291DE
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8291DE; }
    goto L_8291CE;
L_8291CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91CEu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91CEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8291CE LDY
    cpu.setY(0x0u, 16);
    goto L_8291D1;
L_8291D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91D1u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91D1u, 8u, 4u, 0x848221u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8291D1 JSL -> $848221 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x91D4u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x91D5u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x848221u, 0x8291D1u); }
    goto L_8291D5;
L_8291D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91D5u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91D5u,0x8291D5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91D5u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91D5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8291D5 LDX
    cpu.setX(0x0u, 16);
    goto L_8291D8;
L_8291D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91D8u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91D8u, 8u, 4u, 0x848000u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8291D8 JSL -> $848000 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x91DBu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x91DCu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x848000u, 0x8291D8u); }
    goto L_8291DC;
L_8291DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91DCu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91DCu,0x8291DCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91DCu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91DCu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8291DC BRA -> $8291E1
    goto L_8291E1;
L_8291DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91DEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91DEu, 6u, 3u, cpu.address("abs", 0xCD6Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8291DE JSR -> $82CD6B stack real
    { cpu.push16Value(hw,0x91E0u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x91E1u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCD6Bu), 0x8291DEu); }
    goto L_8291E1;
L_8291E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91E1u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91E1u,0x8291E1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91E1u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91E1u, 8u, 4u, 0x809C3Au, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8291E1 JSL -> $809C3A stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x91E4u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x91E5u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809C3Au, 0x8291E1u); }
    goto L_8291E5;
L_8291E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91E5u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91E5u,0x8291E5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91E5u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91E5u, 8u, 4u, 0x809C69u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8291E5 JSL -> $809C69 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x91E8u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x91E9u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809C69u, 0x8291E5u); }
    goto L_8291E9;
L_8291E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91E9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91E9u,0x8291E9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91E9u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91E9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8291E9 LDX
    cpu.setX(0x100u, 16);
    goto L_8291EC;
L_8291EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91ECu,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91ECu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8291EC STX
    hw.write(cpu.address("dp", 0x5Bu), cpu.x, cpu.x8?8:16);
    goto L_8291EE;
L_8291EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91EEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91EEu, 6u, 3u, cpu.address("abs", 0xBD2Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8291EE JSR -> $82BD2B stack real
    { cpu.push16Value(hw,0x91F0u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x91F1u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBD2Bu), 0x8291EEu); }
    goto L_8291F1;
L_8291F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91F1u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91F1u,0x8291F1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91F1u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91F1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8291F1 LDX
    cpu.setX(0x0u, 16);
    goto L_8291F4;
L_8291F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91F4u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91F4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8291F4 STX
    hw.write(cpu.address("dp", 0x5Bu), cpu.x, cpu.x8?8:16);
    goto L_8291F6;
L_8291F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91F6u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91F6u, 6u, 3u, cpu.address("abs", 0xBD2Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8291F6 JSR -> $82BD2B stack real
    { cpu.push16Value(hw,0x91F8u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x91F9u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBD2Bu), 0x8291F6u); }
    goto L_8291F9;
L_8291F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91F9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91F9u,0x8291F9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91F9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91F9u, 6u, 3u, cpu.address("abs", 0xA84Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8291F9 JSR -> $82A84E stack real
    { cpu.push16Value(hw,0x91FBu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x91FCu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA84Eu), 0x8291F9u); }
    goto L_8291FC;
L_8291FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91FCu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91FCu,0x8291FCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91FCu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91FCu, 6u, 3u, cpu.address("abs", 0x9B0Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8291FC JSR -> $829B0B stack real
    { cpu.push16Value(hw,0x91FEu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x91FFu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9B0Bu), 0x8291FCu); }
    goto L_8291FF;
L_8291FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91FFu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91FFu,0x8291FFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91FFu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91FFu, 5u, 3u, cpu.address("abs", 0x0176u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8291FF STZ
    hw.write(cpu.address("abs", 0x176u), 0, cpu.m8?8:16);
    goto L_829202;
L_829202:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9202u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9202u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9202u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829202 SEP
    cpu.sep(0x20u);
    goto L_829204;
L_829204:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9204u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9204u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9204u, 4u, 3u, cpu.address("abs", 0x0193u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829204 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x193u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829207;
L_829207:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9207u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9207u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9207u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829207 BNE -> $829221
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_829221; }
    goto L_829209;
L_829209:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9209u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9209u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9209u, 4u, 3u, cpu.address("abs", 0x018Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829209 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x18Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82920C;
L_82920C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x920Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x920Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x920Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82920C BNE -> $829225
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_829225; }
    goto L_82920E;
L_82920E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x920Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x920Eu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x920Eu, 5u, 3u, cpu.address("abs", 0x014Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82920E LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x14Cu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_829211;
L_829211:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9211u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9211u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9211u, 5u, 4u, ((0x9E9564u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829211 LDA
    cpu.loadA(hw.readW(((0x9E9564u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829215;
L_829215:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9215u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9215u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9215u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829215 BEQ -> $829221
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_829221; }
    goto L_829217;
L_829217:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9217u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9217u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9217u, 8u, 4u, 0x80A6BDu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829217 JSL -> $80A6BD stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x921Au); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x921Bu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6BDu, 0x829217u); }
    goto L_82921B;
L_82921B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x921Bu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x921Bu,0x82921Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x921Bu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x921Bu, 8u, 4u, 0x80A6A5u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82921B JSL -> $80A6A5 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x921Eu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x921Fu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6A5u, 0x82921Bu); }
    goto L_82921F;
L_82921F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x921Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x921Fu,0x82921Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x921Fu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x921Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82921F BRA -> $829225
    goto L_829225;
L_829221:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9221u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9221u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9221u, 8u, 4u, 0x80A5D1u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829221 JSL -> $80A5D1 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9224u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9225u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A5D1u, 0x829221u); }
    goto L_829225;
L_829225:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9225u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9225u,0x829225u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9225u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9225u, 4u, 3u, cpu.address("abs", 0x018Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829225 STZ
    hw.write(cpu.address("abs", 0x18Du), 0, cpu.m8?8:16);
    goto L_829228;
L_829228:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9228u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9228u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9228u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829228 STZ
    hw.write(cpu.address("dp", 0x49u), 0, cpu.m8?8:16);
    goto L_82922A;
L_82922A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x922Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x922Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x922Au, 8u, 4u, 0x808D2Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82922A JSL -> $808D2F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x922Du); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x922Eu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808D2Fu, 0x82922Au); }
    goto L_82922E;
L_82922E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x922Eu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x922Eu,0x82922Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x922Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x922Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82922E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82922Eu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82922Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_829280_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x829280u: goto L_829280;
    case 0x829282u: goto L_829282;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_829280:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9280u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9280u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9280u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829280 REP
    cpu.rep(0x20u);
    goto L_829282;
L_829282:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9282u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9282u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9282u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829282 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x829282u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829282u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_829280_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x829280u: goto L_829280;
    case 0x829282u: goto L_829282;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_829280:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9280u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9280u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9280u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829280 REP
    cpu.rep(0x20u);
    goto L_829282;
L_829282:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9282u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9282u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9282u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829282 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x829282u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829282u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_829450_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x829450u: goto L_829450;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_829450:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9450u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9450u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9450u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829450 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x829450u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829450u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_829450_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x829450u: goto L_829450;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_829450:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9450u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9450u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9450u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829450 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x829450u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829450u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82B246_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B246u: goto L_82B246;
    case 0x82B248u: goto L_82B248;
    case 0x82B24Au: goto L_82B24A;
    case 0x82B24Cu: goto L_82B24C;
    case 0x82B24Fu: goto L_82B24F;
    case 0x82B251u: goto L_82B251;
    case 0x82B253u: goto L_82B253;
    case 0x82B256u: goto L_82B256;
    case 0x82B258u: goto L_82B258;
    case 0x82B25Au: goto L_82B25A;
    case 0x82B25Cu: goto L_82B25C;
    case 0x82B25Fu: goto L_82B25F;
    case 0x82B261u: goto L_82B261;
    case 0x82B263u: goto L_82B263;
    case 0x82B265u: goto L_82B265;
    case 0x82B267u: goto L_82B267;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B246:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB246u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB246u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB246u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B246 SEP
    cpu.sep(0x20u);
    goto L_82B248;
L_82B248:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB248u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB248u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB248u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B248 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x75u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B24A;
L_82B24A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB24Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB24Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB24Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B24A BNE -> $82B267
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B267; }
    goto L_82B24C;
L_82B24C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB24Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB24Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB24Cu, 4u, 3u, cpu.address("abs", 0x041Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B24C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x41Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B24F;
L_82B24F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB24Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB24Fu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB24Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B24F CMP
    cpu.compareA(0x3u);
    goto L_82B251;
L_82B251:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB251u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB251u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB251u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B251 BEQ -> $82B25A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B25A; }
    goto L_82B253;
L_82B253:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB253u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB253u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB253u, 4u, 3u, cpu.address("abs", 0x051Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B253 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x51Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B256;
L_82B256:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB256u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB256u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB256u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B256 CMP
    cpu.compareA(0x3u);
    goto L_82B258;
L_82B258:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB258u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB258u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB258u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B258 BNE -> $82B263
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B263; }
    goto L_82B25A;
L_82B25A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB25Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB25Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB25Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B25A LDA
    cpu.setA(0x83u, 8);
    goto L_82B25C;
L_82B25C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB25Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB25Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB25Cu, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B25C STA
    hw.write(cpu.address("abs", 0x2140u), cpu.a, cpu.m8?8:16);
    goto L_82B25F;
L_82B25F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB25Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB25Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB25Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B25F LDA
    cpu.setA(0x8Fu, 8);
    goto L_82B261;
L_82B261:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB261u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB261u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB261u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B261 BRA -> $82B265
    goto L_82B265;
L_82B263:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB263u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB263u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB263u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B263 LDA
    cpu.setA(0x88u, 8);
    goto L_82B265;
L_82B265:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB265u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB265u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB265u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x46u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B265 STA
    hw.write(cpu.address("dp", 0x46u), cpu.a, cpu.m8?8:16);
    goto L_82B267;
L_82B267:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB267u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB267u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB267u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B267 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B267u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B267u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB267u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB267u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B267 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B267u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B267u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB267u,0x82B267u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_82B9B0_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B9B0u: goto L_82B9B0;
    case 0x82B9B1u: goto L_82B9B1;
    case 0x82B9B2u: goto L_82B9B2;
    case 0x82B9B5u: goto L_82B9B5;
    case 0x82B9B6u: goto L_82B9B6;
    case 0x82B9B8u: goto L_82B9B8;
    case 0x82B9BBu: goto L_82B9BB;
    case 0x82B9BDu: goto L_82B9BD;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B9B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9B0u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9B0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B9B0 TYA
    cpu.transfer("TYA");
    goto L_82B9B1;
L_82B9B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9B1u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9B1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B9B1 CLC
    cpu.setFlag('C', false);
    goto L_82B9B2;
L_82B9B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9B2u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9B2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B9B2 ADC
    cpu.adc(0x16u);
    goto L_82B9B5;
L_82B9B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9B5u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9B5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B9B5 TAY
    cpu.transfer("TAY");
    goto L_82B9B6;
L_82B9B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9B6u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9B6u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82B9B6 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B9B8;
L_82B9B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9B8u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9B8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B9B8 AND
    cpu.logicAnd(0xFFFEu);
    goto L_82B9BB;
L_82B9BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9BBu,cpu,0x91u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9BBu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82B9BB STA
    hw.write(cpu.addressDpIndirectY(hw, 0x67u), cpu.a, cpu.m8?8:16);
    goto L_82B9BD;
L_82B9BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9BDu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9BDu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B9BD RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B9BDu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B9BDu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82C120_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82C120u: goto L_82C120;
    case 0x82C122u: goto L_82C122;
    case 0x82C125u: goto L_82C125;
    case 0x82C128u: goto L_82C128;
    case 0x82C12Bu: goto L_82C12B;
    case 0x82C12Eu: goto L_82C12E;
    case 0x82C131u: goto L_82C131;
    case 0x82C134u: goto L_82C134;
    case 0x82C137u: goto L_82C137;
    case 0x82C139u: goto L_82C139;
    case 0x82C13Du: goto L_82C13D;
    case 0x82C141u: goto L_82C141;
    case 0x82C143u: goto L_82C143;
    case 0x82C145u: goto L_82C145;
    case 0x82C149u: goto L_82C149;
    case 0x82C14Du: goto L_82C14D;
    case 0x82C151u: goto L_82C151;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82C120:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC120u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC120u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC120u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C120 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82C122;
L_82C122:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC122u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC122u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC122u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C122 LDA
    cpu.setA(0x8080u, 16);
    goto L_82C125;
L_82C125:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC125u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC125u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC125u, 6u, 3u, cpu.address("absx", 0x02BCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C125 STA
    hw.write(cpu.address("absx", 0x2BCu), cpu.a, cpu.m8?8:16);
    goto L_82C128;
L_82C128:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC128u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC128u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC128u, 6u, 3u, cpu.address("absx", 0x02BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C128 STA
    hw.write(cpu.address("absx", 0x2BEu), cpu.a, cpu.m8?8:16);
    goto L_82C12B;
L_82C12B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC12Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC12Bu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC12Bu, 6u, 3u, cpu.address("absx", 0x02C0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C12B STA
    hw.write(cpu.address("absx", 0x2C0u), cpu.a, cpu.m8?8:16);
    goto L_82C12E;
L_82C12E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC12Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC12Eu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC12Eu, 6u, 3u, cpu.address("absx", 0x02CCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C12E STZ
    hw.write(cpu.address("absx", 0x2CCu), 0, cpu.m8?8:16);
    goto L_82C131;
L_82C131:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC131u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC131u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC131u, 8u, 3u, cpu.address("abs", 0x0176u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C131 INC
    cpu.incMem(hw, cpu.address("abs", 0x176u), cpu.m8?8:16);
    goto L_82C134;
L_82C134:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC134u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC134u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC134u, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C134 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C137;
L_82C137:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC137u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC137u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC137u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C137 BNE -> $82C141
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C141; }
    goto L_82C139;
L_82C139:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC139u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC139u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC139u, 8u, 4u, 0x84B70Cu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82C139 JSL -> $84B70C stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC13Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC13Du,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84B70Cu, 0x82C139u); }
    goto L_82C13D;
L_82C13D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC13Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC13Du,0x82C13Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC13Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC13Du, 8u, 4u, 0x82BC35u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82C13D JSL -> $82BC35 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC140u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC141u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82BC35u, 0x82C13Du); }
    goto L_82C141;
L_82C141:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC141u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC141u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC141u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C141 SEP
    cpu.sep(0x20u);
    goto L_82C143;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC141u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC141u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C141 SEP
    cpu.sep(0x20u);
    goto L_82C143;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC141u,0x82C141u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82C143:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC143u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC143u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC143u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C143 LDA
    cpu.setA(0xAu, 8);
    goto L_82C145;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC143u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC143u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C143 LDA
    cpu.setA(0xAu, 8);
    goto L_82C145;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC143u,0x82C143u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82C145:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC145u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC145u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC145u, 8u, 4u, 0x80A6BDu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82C145 JSL -> $80A6BD stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC148u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC149u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6BDu, 0x82C145u); }
    goto L_82C149;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC145u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC145u, 8u, 4u, 0x80A6BDu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82C145 JSL -> $80A6BD stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC148u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC149u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6BDu, 0x82C145u); }
    goto L_82C149;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC145u,0x82C145u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82C149:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC149u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC149u,0x82C149u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC149u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC149u, 8u, 4u, 0x80A6A5u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82C149 JSL -> $80A6A5 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC14Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC14Du,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6A5u, 0x82C149u); }
    goto L_82C14D;
L_82C14D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC14Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC14Du,0x82C14Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC14Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC14Du, 8u, 4u, 0x808D2Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82C14D JSL -> $808D2F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC150u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC151u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808D2Fu, 0x82C14Du); }
    goto L_82C151;
L_82C151:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC151u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC151u,0x82C151u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC151u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC151u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C151 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C151u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C151u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82C120_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82C120u: goto L_82C120;
    case 0x82C122u: goto L_82C122;
    case 0x82C125u: goto L_82C125;
    case 0x82C128u: goto L_82C128;
    case 0x82C12Bu: goto L_82C12B;
    case 0x82C12Eu: goto L_82C12E;
    case 0x82C131u: goto L_82C131;
    case 0x82C134u: goto L_82C134;
    case 0x82C137u: goto L_82C137;
    case 0x82C139u: goto L_82C139;
    case 0x82C13Du: goto L_82C13D;
    case 0x82C141u: goto L_82C141;
    case 0x82C143u: goto L_82C143;
    case 0x82C145u: goto L_82C145;
    case 0x82C149u: goto L_82C149;
    case 0x82C14Du: goto L_82C14D;
    case 0x82C151u: goto L_82C151;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82C120:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC120u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC120u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC120u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C120 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82C122;
L_82C122:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC122u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC122u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC122u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C122 LDA
    cpu.setA(0x8080u, 16);
    goto L_82C125;
L_82C125:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC125u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC125u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC125u, 6u, 3u, cpu.address("absx", 0x02BCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C125 STA
    hw.write(cpu.address("absx", 0x2BCu), cpu.a, cpu.m8?8:16);
    goto L_82C128;
L_82C128:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC128u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC128u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC128u, 6u, 3u, cpu.address("absx", 0x02BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C128 STA
    hw.write(cpu.address("absx", 0x2BEu), cpu.a, cpu.m8?8:16);
    goto L_82C12B;
L_82C12B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC12Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC12Bu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC12Bu, 6u, 3u, cpu.address("absx", 0x02C0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C12B STA
    hw.write(cpu.address("absx", 0x2C0u), cpu.a, cpu.m8?8:16);
    goto L_82C12E;
L_82C12E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC12Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC12Eu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC12Eu, 6u, 3u, cpu.address("absx", 0x02CCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C12E STZ
    hw.write(cpu.address("absx", 0x2CCu), 0, cpu.m8?8:16);
    goto L_82C131;
L_82C131:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC131u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC131u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC131u, 8u, 3u, cpu.address("abs", 0x0176u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C131 INC
    cpu.incMem(hw, cpu.address("abs", 0x176u), cpu.m8?8:16);
    goto L_82C134;
L_82C134:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC134u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC134u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC134u, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C134 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C137;
L_82C137:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC137u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC137u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC137u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C137 BNE -> $82C141
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C141; }
    goto L_82C139;
L_82C139:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC139u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC139u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC139u, 8u, 4u, 0x84B70Cu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82C139 JSL -> $84B70C stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC13Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC13Du,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84B70Cu, 0x82C139u); }
    goto L_82C13D;
L_82C13D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC13Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC13Du,0x82C13Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC13Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC13Du, 8u, 4u, 0x82BC35u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82C13D JSL -> $82BC35 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC140u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC141u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82BC35u, 0x82C13Du); }
    goto L_82C141;
L_82C141:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC141u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC141u,0x82C141u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC141u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC141u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C141 SEP
    cpu.sep(0x20u);
    goto L_82C143;
L_82C143:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC143u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC143u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC143u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C143 LDA
    cpu.setA(0xAu, 8);
    goto L_82C145;
L_82C145:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC145u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC145u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC145u, 8u, 4u, 0x80A6BDu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82C145 JSL -> $80A6BD stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC148u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC149u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6BDu, 0x82C145u); }
    goto L_82C149;
L_82C149:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC149u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC149u,0x82C149u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC149u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC149u, 8u, 4u, 0x80A6A5u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82C149 JSL -> $80A6A5 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC14Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC14Du,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6A5u, 0x82C149u); }
    goto L_82C14D;
L_82C14D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC14Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC14Du,0x82C14Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC14Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC14Du, 8u, 4u, 0x808D2Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82C14D JSL -> $808D2F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC150u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC151u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808D2Fu, 0x82C14Du); }
    goto L_82C151;
L_82C151:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC151u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC151u,0x82C151u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC151u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC151u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C151 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C151u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C151u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82C303_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82C303u: goto L_82C303;
    case 0x82C306u: goto L_82C306;
    case 0x82C307u: goto L_82C307;
    case 0x82C308u: goto L_82C308;
    case 0x82C30Au: goto L_82C30A;
    case 0x82C30Cu: goto L_82C30C;
    case 0x82C30Du: goto L_82C30D;
    case 0x82C30Eu: goto L_82C30E;
    case 0x82C30Fu: goto L_82C30F;
    case 0x82C312u: goto L_82C312;
    case 0x82C314u: goto L_82C314;
    case 0x82C318u: goto L_82C318;
    case 0x82C31Cu: goto L_82C31C;
    case 0x82C31Eu: goto L_82C31E;
    case 0x82C320u: goto L_82C320;
    case 0x82C321u: goto L_82C321;
    case 0x82C322u: goto L_82C322;
    case 0x82C324u: goto L_82C324;
    case 0x82C325u: goto L_82C325;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82C303:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC303u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC303u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC303u, 5u, 3u, cpu.address("abs", 0x02CCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C303 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2CCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C306;
L_82C306:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC306u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC306u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC306u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C306 ASL
    cpu.aslA();
    goto L_82C307;
L_82C307:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC307u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC307u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC307u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C307 TAY
    cpu.transfer("TAY");
    goto L_82C308;
L_82C308:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC308u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC308u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC308u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $82C308 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C30A;
L_82C30A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC30Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC30Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC30Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C30A BNE -> $82C30E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C30E; }
    goto L_82C30C;
L_82C30C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC30Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC30Cu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC30Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C30C SEC
    cpu.setFlag('C', true);
    goto L_82C30D;
L_82C30D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC30Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC30Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC30Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C30D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C30Du);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C30Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82C30E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC30Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC30Eu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC30Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C30E TAX
    cpu.transfer("TAX");
    goto L_82C30F;
L_82C30F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC30Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC30Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC30Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C30F LDA
    cpu.setA(0x9u, 16);
    goto L_82C312;
L_82C312:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC312u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC312u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC312u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C312 STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_82C314;
L_82C314:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC314u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC314u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC314u, 6u, 4u, ((0x7E2220u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C314 LDA
    cpu.loadA(hw.readW(((0x7E2220u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C318;
L_82C318:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC318u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC318u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC318u, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C318 STA
    hw.write(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_82C31C;
L_82C31C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC31Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC31Cu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC31Cu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C31C DEC
    cpu.decMem(hw, cpu.address("dp", 0x4u), cpu.m8?8:16);
    goto L_82C31E;
L_82C31E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC31Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC31Eu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC31Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C31E BMI -> $82C324
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82C324; }
    goto L_82C320;
L_82C320:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC320u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC320u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC320u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C320 INX
    cpu.inc('X');
    goto L_82C321;
L_82C321:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC321u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC321u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC321u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C321 INX
    cpu.inc('X');
    goto L_82C322;
L_82C322:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC322u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC322u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC322u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C322 BRA -> $82C314
    goto L_82C314;
L_82C324:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC324u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC324u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC324u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C324 CLC
    cpu.setFlag('C', false);
    goto L_82C325;
L_82C325:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC325u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC325u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC325u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C325 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C325u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C325u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82C98B_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82C98Bu: goto L_82C98B;
    case 0x82C98Eu: goto L_82C98E;
    case 0x82C991u: goto L_82C991;
    case 0x82C993u: goto L_82C993;
    case 0x82C994u: goto L_82C994;
    case 0x82C995u: goto L_82C995;
    case 0x82C996u: goto L_82C996;
    case 0x82C997u: goto L_82C997;
    case 0x82C99Au: goto L_82C99A;
    case 0x82C99Cu: goto L_82C99C;
    case 0x82C99Fu: goto L_82C99F;
    case 0x82C9A0u: goto L_82C9A0;
    case 0x82C9A1u: goto L_82C9A1;
    case 0x82C9A5u: goto L_82C9A5;
    case 0x82C9A7u: goto L_82C9A7;
    case 0x82C9AAu: goto L_82C9AA;
    case 0x82C9ACu: goto L_82C9AC;
    case 0x82C9AFu: goto L_82C9AF;
    case 0x82C9B1u: goto L_82C9B1;
    case 0x82C9B4u: goto L_82C9B4;
    case 0x82C9B5u: goto L_82C9B5;
    case 0x82C9B6u: goto L_82C9B6;
    case 0x82C9B9u: goto L_82C9B9;
    case 0x82C9BCu: goto L_82C9BC;
    case 0x82C9BEu: goto L_82C9BE;
    case 0x82C9C0u: goto L_82C9C0;
    case 0x82C9C3u: goto L_82C9C3;
    case 0x82C9C4u: goto L_82C9C4;
    case 0x82C9C5u: goto L_82C9C5;
    case 0x82C9C9u: goto L_82C9C9;
    case 0x82C9CAu: goto L_82C9CA;
    case 0x82C9CDu: goto L_82C9CD;
    case 0x82C9CFu: goto L_82C9CF;
    case 0x82C9D2u: goto L_82C9D2;
    case 0x82C9D4u: goto L_82C9D4;
    case 0x82C9D7u: goto L_82C9D7;
    case 0x82C9D9u: goto L_82C9D9;
    case 0x82C9DAu: goto L_82C9DA;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82C98B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC98Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC98Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC98Bu, 5u, 3u, cpu.address("abs", 0x0414u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C98B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x414u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C98E;
L_82C98E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC98Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC98Eu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC98Eu, 5u, 3u, cpu.address("abs", 0x0514u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C98E ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x514u), cpu.m8?8:16));
    goto L_82C991;
L_82C991:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC991u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC991u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC991u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C991 BNE -> $82C994
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C994; }
    goto L_82C993;
L_82C993:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC993u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC993u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC993u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C993 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C993u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C993u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82C994:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC994u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC994u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC994u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82C994 PHB
    cpu.push("PHB", hw);
    goto L_82C995;
L_82C995:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC995u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC995u,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC995u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82C995 PHK
    cpu.push("PHK", hw);
    goto L_82C996;
L_82C996:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC996u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC996u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC996u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82C996 PLB
    cpu.pop("PLB", hw);
    goto L_82C997;
L_82C997:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC997u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC997u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC997u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C997 LDA
    cpu.setA(0x1u, 16);
    goto L_82C99A;
L_82C99A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC99Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC99Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC99Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C99A STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82C99C;
L_82C99C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC99Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC99Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC99Cu, 5u, 3u, cpu.address("abs", 0x0400u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C99C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x400u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C99F;
L_82C99F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC99Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC99Fu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC99Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C99F ASL
    cpu.aslA();
    goto L_82C9A0;
L_82C9A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9A0u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9A0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C9A0 TAX
    cpu.transfer("TAX");
    goto L_82C9A1;
L_82C9A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9A1u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9A1u, 6u, 4u, ((0x9E956Eu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C9A1 LDA
    cpu.loadA(hw.readW(((0x9E956Eu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C9A5;
L_82C9A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9A5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9A5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C9A5 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_82C9A7;
L_82C9A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9A7u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9A7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C9A7 LDX
    cpu.setX(0x0u, 16);
    goto L_82C9AA;
L_82C9AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9AAu,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9AAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C9AA STX
    hw.write(cpu.address("dp", 0x61u), cpu.x, cpu.x8?8:16);
    goto L_82C9AC;
L_82C9AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9ACu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9ACu, 5u, 3u, cpu.address("abs", 0x0414u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C9AC LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x414u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C9AF;
L_82C9AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9AFu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9AFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C9AF BEQ -> $82C9BC
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C9BC; }
    goto L_82C9B1;
L_82C9B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9B1u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9B1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C9B1 AND
    cpu.logicAnd(0xFFu);
    goto L_82C9B4;
L_82C9B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9B4u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9B4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C9B4 ASL
    cpu.aslA();
    goto L_82C9B5;
L_82C9B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9B5u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9B5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C9B5 TAX
    cpu.transfer("TAX");
    goto L_82C9B6;
L_82C9B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9B6u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9B6u, 5u, 3u, cpu.address("abs", 0xC9BBu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C9B6 PEA
    cpu.push16Value(hw, 0xC9BBu);
    goto L_82C9B9;
L_82C9B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9B9u,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9B9u, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0xC9DBu + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $82C9B9 JMP (C9DB,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0xC9DBu+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x82C9B9u); return; }
L_82C9BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9BCu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9BCu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C9BC DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_82C9BE;
L_82C9BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9BEu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9BEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C9BE BMI -> $82C9D9
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82C9D9; }
    goto L_82C9C0;
L_82C9C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9C0u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9C0u, 5u, 3u, cpu.address("abs", 0x0500u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C9C0 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x500u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C9C3;
L_82C9C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9C3u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9C3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C9C3 ASL
    cpu.aslA();
    goto L_82C9C4;
L_82C9C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9C4u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9C4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C9C4 TAX
    cpu.transfer("TAX");
    goto L_82C9C5;
L_82C9C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9C5u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9C5u, 6u, 4u, ((0x9E9598u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C9C5 LDA
    cpu.loadA(hw.readW(((0x9E9598u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C9C9;
L_82C9C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9C9u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9C9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C9C9 SEC
    cpu.setFlag('C', true);
    goto L_82C9CA;
L_82C9CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9CAu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9CAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C9CA SBC
    cpu.sbc(0x12u);
    goto L_82C9CD;
L_82C9CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9CDu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9CDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C9CD STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_82C9CF;
L_82C9CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9CFu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9CFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C9CF LDX
    cpu.setX(0x100u, 16);
    goto L_82C9D2;
L_82C9D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9D2u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9D2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C9D2 STX
    hw.write(cpu.address("dp", 0x61u), cpu.x, cpu.x8?8:16);
    goto L_82C9D4;
L_82C9D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9D4u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9D4u, 5u, 3u, cpu.address("abs", 0x0514u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C9D4 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x514u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C9D7;
L_82C9D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9D7u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9D7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C9D7 BRA -> $82C9AF
    goto L_82C9AF;
L_82C9D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9D9u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9D9u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82C9D9 PLB
    cpu.pop("PLB", hw);
    goto L_82C9DA;
L_82C9DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9DAu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9DAu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C9DA RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C9DAu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C9DAu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82DD5C_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82DD5Cu: goto L_82DD5C;
    case 0x82DD5Eu: goto L_82DD5E;
    case 0x82DD60u: goto L_82DD60;
    case 0x82DD61u: goto L_82DD61;
    case 0x82DD64u: goto L_82DD64;
    case 0x82DD66u: goto L_82DD66;
    case 0x82DD69u: goto L_82DD69;
    case 0x82DD6Bu: goto L_82DD6B;
    case 0x82DD6Eu: goto L_82DD6E;
    case 0x82DD71u: goto L_82DD71;
    case 0x82DD74u: goto L_82DD74;
    case 0x82DD77u: goto L_82DD77;
    case 0x82DD7Au: goto L_82DD7A;
    case 0x82DD7Cu: goto L_82DD7C;
    case 0x82DD7Eu: goto L_82DD7E;
    case 0x82DD81u: goto L_82DD81;
    case 0x82DD83u: goto L_82DD83;
    case 0x82DD86u: goto L_82DD86;
    case 0x82DD87u: goto L_82DD87;
    case 0x82DD88u: goto L_82DD88;
    case 0x82DD8Cu: goto L_82DD8C;
    case 0x82DD8Eu: goto L_82DD8E;
    case 0x82DD91u: goto L_82DD91;
    case 0x82DD93u: goto L_82DD93;
    case 0x82DD96u: goto L_82DD96;
    case 0x82DD9Au: goto L_82DD9A;
    case 0x82DD9Cu: goto L_82DD9C;
    case 0x82DD9Fu: goto L_82DD9F;
    case 0x82DDA0u: goto L_82DDA0;
    case 0x82DDA4u: goto L_82DDA4;
    case 0x82DDA7u: goto L_82DDA7;
    case 0x82DDA9u: goto L_82DDA9;
    case 0x82DDADu: goto L_82DDAD;
    case 0x82DDAFu: goto L_82DDAF;
    case 0x82DDB1u: goto L_82DDB1;
    case 0x82DDB3u: goto L_82DDB3;
    case 0x82DDB5u: goto L_82DDB5;
    case 0x82DDB8u: goto L_82DDB8;
    case 0x82DDBAu: goto L_82DDBA;
    case 0x82DDBDu: goto L_82DDBD;
    case 0x82DDBFu: goto L_82DDBF;
    case 0x82DDC2u: goto L_82DDC2;
    case 0x82DDC5u: goto L_82DDC5;
    case 0x82DDC8u: goto L_82DDC8;
    case 0x82DDCBu: goto L_82DDCB;
    case 0x82DDCDu: goto L_82DDCD;
    case 0x82DDD0u: goto L_82DDD0;
    case 0x82DDD1u: goto L_82DDD1;
    case 0x82DDD2u: goto L_82DDD2;
    case 0x82DDD6u: goto L_82DDD6;
    case 0x82DDD7u: goto L_82DDD7;
    case 0x82DDDAu: goto L_82DDDA;
    case 0x82DDDEu: goto L_82DDDE;
    case 0x82DDE1u: goto L_82DDE1;
    case 0x82DDE3u: goto L_82DDE3;
    case 0x82DDE6u: goto L_82DDE6;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82DD5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD5Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD5Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DD5C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82DD5E;
L_82DD5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD5Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD5Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DD5E BEQ -> $82DD61
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82DD61; }
    goto L_82DD60;
L_82DD60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD60u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD60u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82DD60 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82DD60u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82DD60u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82DD61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD61u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD61u, 5u, 3u, cpu.address("abs", 0x013Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DD61 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82DD64;
L_82DD64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD64u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD64u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DD64 BEQ -> $82DD6B
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82DD6B; }
    goto L_82DD66;
L_82DD66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD66u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD66u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD66u, 8u, 3u, cpu.address("abs", 0x013Du), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DD66 DEC
    cpu.decMem(hw, cpu.address("abs", 0x13Du), cpu.m8?8:16);
    goto L_82DD69;
L_82DD69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD69u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD69u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DD69 BRA -> $82DDB5
    goto L_82DDB5;
L_82DD6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD6Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD6Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DD6B LDA
    cpu.setA(0x5u, 16);
    goto L_82DD6E;
L_82DD6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD6Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD6Eu, 5u, 3u, cpu.address("abs", 0x013Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DD6E STA
    hw.write(cpu.address("abs", 0x13Du), cpu.a, cpu.m8?8:16);
    goto L_82DD71;
L_82DD71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD71u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD71u, 8u, 3u, cpu.address("abs", 0x0170u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DD71 INC
    cpu.incMem(hw, cpu.address("abs", 0x170u), cpu.m8?8:16);
    goto L_82DD74;
L_82DD74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD74u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD74u, 5u, 3u, cpu.address("abs", 0x0170u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DD74 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x170u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82DD77;
L_82DD77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD77u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD77u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD77u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DD77 CMP
    cpu.compareA(0xDu);
    goto L_82DD7A;
L_82DD7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD7Au,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD7Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DD7A BCS -> $82DDE3
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_82DDE3; }
    goto L_82DD7C;
L_82DD7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD7Cu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD7Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DD7C STZ
    hw.write(cpu.address("dp", 0x0u), 0, cpu.m8?8:16);
    goto L_82DD7E;
L_82DD7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD7Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD7Eu, 5u, 3u, cpu.address("abs", 0x015Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DD7E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x15Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82DD81;
L_82DD81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD81u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD81u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DD81 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_82DD83;
L_82DD83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD83u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD83u, 5u, 3u, cpu.address("abs", 0x0170u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DD83 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x170u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82DD86;
L_82DD86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD86u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD86u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DD86 ASL
    cpu.aslA();
    goto L_82DD87;
L_82DD87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD87u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD87u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DD87 TAX
    cpu.transfer("TAX");
    goto L_82DD88;
L_82DD88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD88u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD88u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD88u, 6u, 4u, ((0x82DDE7u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DD88 LDA
    cpu.loadA(hw.readW(((0x82DDE7u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82DD8C;
L_82DD8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD8Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD8Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DD8C STA
    hw.write(cpu.address("dp", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_82DD8E;
L_82DD8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD8Eu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD8Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DD8E CMP
    cpu.compareA(0x2000u);
    goto L_82DD91;
L_82DD91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD91u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD91u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DD91 BNE -> $82DD9A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82DD9A; }
    goto L_82DD93;
L_82DD93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD93u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD93u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DD93 LDA
    cpu.setA(0x2Eu, 16);
    goto L_82DD96;
L_82DD96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD96u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD96u, 8u, 4u, 0x80A6FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82DD96 JSL -> $80A6FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xDD99u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDD9Au,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6FBu, 0x82DD96u); }
    goto L_82DD9A;
L_82DD9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD9Au))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDD9Au,0x82DD9Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD9Au,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD9Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DD9A LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82DD9C;
L_82DD9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD9Cu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD9Cu, 5u + 1u, 3u, cpu.address("absx", 0x015Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DD9C LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x15Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82DD9F;
L_82DD9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD9Fu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD9Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DD9F TAX
    cpu.transfer("TAX");
    goto L_82DDA0;
L_82DDA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDA0u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDA0u, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DDA0 LDA
    cpu.loadA(hw.readW(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82DDA4;
L_82DDA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDA4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDA4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DDA4 AND
    cpu.logicAnd(0x300u);
    goto L_82DDA7;
L_82DDA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDA7u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDA7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DDA7 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x6u), cpu.m8?8:16));
    goto L_82DDA9;
L_82DDA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDA9u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDA9u, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DDA9 STA
    hw.write(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_82DDAD;
L_82DDAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDADu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDADu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DDAD INC
    cpu.incMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_82DDAF;
L_82DDAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDAFu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDAFu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DDAF INC
    cpu.incMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_82DDB1;
L_82DDB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDB1u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDB1u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DDB1 DEC
    cpu.decMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_82DDB3;
L_82DDB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDB3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDB3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DDB3 BNE -> $82DD9A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82DD9A; }
    goto L_82DDB5;
L_82DDB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDB5u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDB5u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDB5u, 5u, 3u, cpu.address("abs", 0x0172u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DDB5 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x172u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82DDB8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDB5u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDB5u, 5u, 3u, cpu.address("abs", 0x0172u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DDB5 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x172u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82DDB8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDDB5u,0x82DDB5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82DDB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDB8u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDB8u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDB8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DDB8 BEQ -> $82DDBF
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82DDBF; }
    goto L_82DDBA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDB8u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDB8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DDB8 BEQ -> $82DDBF
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82DDBF; }
    goto L_82DDBA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDDB8u,0x82DDB8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82DDBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDBAu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDBAu,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDBAu, 8u, 3u, cpu.address("abs", 0x0172u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DDBA DEC
    cpu.decMem(hw, cpu.address("abs", 0x172u), cpu.m8?8:16);
    goto L_82DDBD;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDBAu,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDBAu, 8u, 3u, cpu.address("abs", 0x0172u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DDBA DEC
    cpu.decMem(hw, cpu.address("abs", 0x172u), cpu.m8?8:16);
    goto L_82DDBD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDDBAu,0x82DDBAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82DDBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDBDu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDBDu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDBDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DDBD BRA -> $82DDE6
    goto L_82DDE6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDBDu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDBDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DDBD BRA -> $82DDE6
    goto L_82DDE6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDDBDu,0x82DDBDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82DDBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDBFu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDBFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDBFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DDBF LDA
    cpu.setA(0x3u, 16);
    goto L_82DDC2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDBFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDBFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DDBF LDA
    cpu.setA(0x3u, 16);
    goto L_82DDC2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDDBFu,0x82DDBFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82DDC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDC2u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDC2u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDC2u, 5u, 3u, cpu.address("abs", 0x0172u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DDC2 STA
    hw.write(cpu.address("abs", 0x172u), cpu.a, cpu.m8?8:16);
    goto L_82DDC5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDC2u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDC2u, 5u, 3u, cpu.address("abs", 0x0172u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DDC2 STA
    hw.write(cpu.address("abs", 0x172u), cpu.a, cpu.m8?8:16);
    goto L_82DDC5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDDC2u,0x82DDC2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82DDC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDC5u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDC5u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDC5u, 5u, 3u, cpu.address("abs", 0x0174u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DDC5 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x174u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82DDC8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDC5u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDC5u, 5u, 3u, cpu.address("abs", 0x0174u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DDC5 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x174u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82DDC8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDDC5u,0x82DDC5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82DDC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDC8u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDC8u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDC8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DDC8 CMP
    cpu.compareA(0xAu);
    goto L_82DDCB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDC8u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDC8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DDC8 CMP
    cpu.compareA(0xAu);
    goto L_82DDCB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDDC8u,0x82DDC8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82DDCB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDCBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDCBu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDCBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DDCB BCS -> $82DDE6
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_82DDE6; }
    goto L_82DDCD;
L_82DDCD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDCDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDCDu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDCDu, 5u, 3u, cpu.address("abs", 0x0174u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DDCD LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x174u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82DDD0;
L_82DDD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDD0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDD0u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDD0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DDD0 ASL
    cpu.aslA();
    goto L_82DDD1;
L_82DDD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDD1u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDD1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DDD1 TAX
    cpu.transfer("TAX");
    goto L_82DDD2;
L_82DDD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDD2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDD2u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDD2u, 6u, 4u, ((0x82DD46u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DDD2 LDA
    cpu.loadA(hw.readW(((0x82DD46u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82DDD6;
L_82DDD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDD6u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDD6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DDD6 TAX
    cpu.transfer("TAX");
    goto L_82DDD7;
L_82DDD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDD7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDD7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDD7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DDD7 LDA
    cpu.setA(0x0u, 16);
    goto L_82DDDA;
L_82DDDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDDAu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDDAu, 6u, 4u, ((0x7E2800u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DDDA STA
    hw.write(((0x7E2800u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_82DDDE;
L_82DDDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDDEu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDDEu, 8u, 3u, cpu.address("abs", 0x0174u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DDDE INC
    cpu.incMem(hw, cpu.address("abs", 0x174u), cpu.m8?8:16);
    goto L_82DDE1;
L_82DDE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDE1u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDE1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DDE1 BRA -> $82DDE6
    goto L_82DDE6;
L_82DDE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDE3u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDE3u, 8u, 3u, cpu.address("abs", 0x013Bu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DDE3 INC
    cpu.incMem(hw, cpu.address("abs", 0x13Bu), cpu.m8?8:16);
    goto L_82DDE6;
L_82DDE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDE6u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDE6u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDE6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82DDE6 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82DDE6u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82DDE6u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDE6u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDE6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82DDE6 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82DDE6u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82DDE6u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDDE6u,0x82DDE6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_8484CA_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8484CAu: goto L_8484CA;
    case 0x8484CCu: goto L_8484CC;
    case 0x8484CFu: goto L_8484CF;
    case 0x8484D1u: goto L_8484D1;
    case 0x8484D3u: goto L_8484D3;
    case 0x8484D6u: goto L_8484D6;
    case 0x8484D8u: goto L_8484D8;
    case 0x8484DAu: goto L_8484DA;
    case 0x8484DDu: goto L_8484DD;
    case 0x8484DFu: goto L_8484DF;
    case 0x8484E1u: goto L_8484E1;
    case 0x8484E3u: goto L_8484E3;
    case 0x8484E5u: goto L_8484E5;
    case 0x8484E7u: goto L_8484E7;
    case 0x8484E9u: goto L_8484E9;
    case 0x8484EBu: goto L_8484EB;
    case 0x8484EDu: goto L_8484ED;
    case 0x8484EFu: goto L_8484EF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8484CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84CAu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84CAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8484CA SEP
    cpu.sep(0x20u);
    goto L_8484CC;
L_8484CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84CCu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84CCu, 4u, 3u, cpu.address("abs", 0x062Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8484CC LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8484CF;
L_8484CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84CFu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84CFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8484CF BIT
    cpu.bit(0x1u, true);
    goto L_8484D1;
L_8484D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84D1u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84D1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8484D1 BNE -> $8484E9
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8484E9; }
    goto L_8484D3;
L_8484D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84D3u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84D3u, 4u, 3u, cpu.address("abs", 0x0629u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8484D3 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x629u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8484D6;
L_8484D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84D6u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84D6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8484D6 BIT
    cpu.bit(0x1u, true);
    goto L_8484D8;
L_8484D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84D8u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84D8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8484D8 BNE -> $8484E1
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8484E1; }
    goto L_8484DA;
L_8484DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84DAu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84DAu, 4u, 3u, cpu.address("abs", 0x062Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8484DA LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8484DD;
L_8484DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84DDu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84DDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8484DD BIT
    cpu.bit(0x1u, true);
    goto L_8484DF;
L_8484DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84DFu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84DFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8484DF BNE -> $8484E9
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8484E9; }
    goto L_8484E1;
L_8484E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84E1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84E1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8484E1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x75u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8484E3;
L_8484E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84E3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84E3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8484E3 BNE -> $8484EF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8484EF; }
    goto L_8484E5;
L_8484E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84E5u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84E5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8484E5 INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_8484E7;
L_8484E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84E7u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84E7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8484E7 BRA -> $8484EF
    goto L_8484EF;
L_8484E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84E9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84E9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x78u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8484E9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x78u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8484EB;
L_8484EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84EBu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84EBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8484EB BNE -> $8484EF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8484EF; }
    goto L_8484ED;
L_8484ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84EDu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84EDu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8484ED INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_8484EF;
L_8484EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84EFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84EFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8484EF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8484EFu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8484EFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_8484CA_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8484CAu: goto L_8484CA;
    case 0x8484CCu: goto L_8484CC;
    case 0x8484CFu: goto L_8484CF;
    case 0x8484D1u: goto L_8484D1;
    case 0x8484D3u: goto L_8484D3;
    case 0x8484D6u: goto L_8484D6;
    case 0x8484D8u: goto L_8484D8;
    case 0x8484DAu: goto L_8484DA;
    case 0x8484DDu: goto L_8484DD;
    case 0x8484DFu: goto L_8484DF;
    case 0x8484E1u: goto L_8484E1;
    case 0x8484E3u: goto L_8484E3;
    case 0x8484E5u: goto L_8484E5;
    case 0x8484E7u: goto L_8484E7;
    case 0x8484E9u: goto L_8484E9;
    case 0x8484EBu: goto L_8484EB;
    case 0x8484EDu: goto L_8484ED;
    case 0x8484EFu: goto L_8484EF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8484CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84CAu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84CAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8484CA SEP
    cpu.sep(0x20u);
    goto L_8484CC;
L_8484CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84CCu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84CCu, 4u, 3u, cpu.address("abs", 0x062Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8484CC LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8484CF;
L_8484CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84CFu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84CFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8484CF BIT
    cpu.bit(0x1u, true);
    goto L_8484D1;
L_8484D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84D1u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84D1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8484D1 BNE -> $8484E9
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8484E9; }
    goto L_8484D3;
L_8484D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84D3u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84D3u, 4u, 3u, cpu.address("abs", 0x0629u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8484D3 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x629u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8484D6;
L_8484D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84D6u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84D6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8484D6 BIT
    cpu.bit(0x1u, true);
    goto L_8484D8;
L_8484D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84D8u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84D8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8484D8 BNE -> $8484E1
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8484E1; }
    goto L_8484DA;
L_8484DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84DAu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84DAu, 4u, 3u, cpu.address("abs", 0x062Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8484DA LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8484DD;
L_8484DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84DDu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84DDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8484DD BIT
    cpu.bit(0x1u, true);
    goto L_8484DF;
L_8484DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84DFu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84DFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8484DF BNE -> $8484E9
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8484E9; }
    goto L_8484E1;
L_8484E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84E1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84E1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8484E1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x75u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8484E3;
L_8484E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84E3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84E3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8484E3 BNE -> $8484EF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8484EF; }
    goto L_8484E5;
L_8484E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84E5u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84E5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8484E5 INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_8484E7;
L_8484E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84E7u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84E7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8484E7 BRA -> $8484EF
    goto L_8484EF;
L_8484E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84E9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84E9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x78u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8484E9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x78u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8484EB;
L_8484EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84EBu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84EBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8484EB BNE -> $8484EF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8484EF; }
    goto L_8484ED;
L_8484ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84EDu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84EDu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8484ED INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_8484EF;
L_8484EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84EFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84EFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8484EF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8484EFu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8484EFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_848FF0_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848FF0u: goto L_848FF0;
    case 0x848FF3u: goto L_848FF3;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848FF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF0u, 6u, 3u, cpu.address("abs", 0x9943u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848FF0 JSR -> $849943 stack real
    { cpu.push16Value(hw,0x8FF2u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8FF3u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9943u), 0x848FF0u); }
    goto L_848FF3;
L_848FF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FF3u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF3u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848FF3 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848FF3u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848FF3u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF3u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848FF3 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848FF3u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848FF3u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8FF3u,0x848FF3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_849DAB_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x849DABu: goto L_849DAB;
    case 0x849DADu: goto L_849DAD;
    case 0x849DB0u: goto L_849DB0;
    case 0x849DB3u: goto L_849DB3;
    case 0x849DB6u: goto L_849DB6;
    case 0x849DB8u: goto L_849DB8;
    case 0x849DBBu: goto L_849DBB;
    case 0x849DBEu: goto L_849DBE;
    case 0x849DC1u: goto L_849DC1;
    case 0x849DC4u: goto L_849DC4;
    case 0x849DC7u: goto L_849DC7;
    case 0x849DC8u: goto L_849DC8;
    case 0x849DC9u: goto L_849DC9;
    case 0x849DCDu: goto L_849DCD;
    case 0x849DCEu: goto L_849DCE;
    case 0x849DD1u: goto L_849DD1;
    case 0x849DD4u: goto L_849DD4;
    case 0x849DD7u: goto L_849DD7;
    case 0x849DDAu: goto L_849DDA;
    case 0x849DDBu: goto L_849DDB;
    case 0x849DDCu: goto L_849DDC;
    case 0x849DDDu: goto L_849DDD;
    case 0x849DE0u: goto L_849DE0;
    case 0x849DE1u: goto L_849DE1;
    case 0x849DE4u: goto L_849DE4;
    case 0x849DE7u: goto L_849DE7;
    case 0x849DEAu: goto L_849DEA;
    case 0x849DEDu: goto L_849DED;
    case 0x849DF0u: goto L_849DF0;
    case 0x849DF2u: goto L_849DF2;
    case 0x849DF5u: goto L_849DF5;
    case 0x849DF8u: goto L_849DF8;
    case 0x849DFBu: goto L_849DFB;
    case 0x849DFEu: goto L_849DFE;
    case 0x849E01u: goto L_849E01;
    case 0x849E02u: goto L_849E02;
    case 0x849E03u: goto L_849E03;
    case 0x849E07u: goto L_849E07;
    case 0x849E08u: goto L_849E08;
    case 0x849E0Bu: goto L_849E0B;
    case 0x849E0Eu: goto L_849E0E;
    case 0x849E11u: goto L_849E11;
    case 0x849E14u: goto L_849E14;
    case 0x849E15u: goto L_849E15;
    case 0x849E16u: goto L_849E16;
    case 0x849E17u: goto L_849E17;
    case 0x849E1Au: goto L_849E1A;
    case 0x849E1Bu: goto L_849E1B;
    case 0x849E1Eu: goto L_849E1E;
    case 0x849E21u: goto L_849E21;
    case 0x849E23u: goto L_849E23;
    case 0x849E26u: goto L_849E26;
    case 0x849E29u: goto L_849E29;
    case 0x849E2Au: goto L_849E2A;
    case 0x849E2Bu: goto L_849E2B;
    case 0x849E2Fu: goto L_849E2F;
    case 0x849E30u: goto L_849E30;
    case 0x849E33u: goto L_849E33;
    case 0x849E36u: goto L_849E36;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_849DAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DABu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DABu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DAB REP
    cpu.rep(0x20u);
    goto L_849DAD;
L_849DAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DADu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DADu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DAD LDY
    cpu.setY(0x8u, 16);
    goto L_849DB0;
L_849DB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DB0u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DB0u, 5u + 1u, 3u, cpu.address("absy", 0x063Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DB0 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x63Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849DB3;
L_849DB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DB3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DB3u, 6u, 3u, cpu.address("abs", 0x9F4Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849DB3 JSR -> $849F4E stack real
    { cpu.push16Value(hw,0x9DB5u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9DB6u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9F4Eu), 0x849DB3u); }
    goto L_849DB6;
L_849DB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DB6u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9DB6u,0x849DB6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DB6u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DB6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DB6 REP
    cpu.rep(0x20u);
    goto L_849DB8;
L_849DB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DB8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DB8u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DB8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DB8 LDX
    cpu.setX(0x0u, 16);
    goto L_849DBB;
L_849DBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DBBu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DBBu, 5u + 1u, 3u, cpu.address("absy", 0x063Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DBB LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x63Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849DBE;
L_849DBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DBEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DBEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DBEu, 6u, 3u, cpu.address("abs", 0x9F86u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849DBE JSR -> $849F86 stack real
    { cpu.push16Value(hw,0x9DC0u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9DC1u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9F86u), 0x849DBEu); }
    goto L_849DC1;
L_849DC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DC1u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9DC1u,0x849DC1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC1u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DC1 LDY
    cpu.setY(0x8u, 16);
    goto L_849DC4;
L_849DC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC4u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC4u, 5u + 1u, 3u, cpu.address("absy", 0x0633u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DC4 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x633u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849DC7;
L_849DC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC7u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DC7 ASL
    cpu.aslA();
    goto L_849DC8;
L_849DC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC8u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DC8 TAX
    cpu.transfer("TAX");
    goto L_849DC9;
L_849DC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC9u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC9u, 6u, 4u, ((0x849FBEu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DC9 LDA
    cpu.loadA(hw.readW(((0x849FBEu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849DCD;
L_849DCD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DCDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DCDu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DCDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DCD TAY
    cpu.transfer("TAY");
    goto L_849DCE;
L_849DCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DCEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DCEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DCEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DCE LDA
    cpu.setA(0x0u, 16);
    goto L_849DD1;
L_849DD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DD1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DD1u, 6u, 3u, cpu.address("abs", 0x9EF1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849DD1 JSR -> $849EF1 stack real
    { cpu.push16Value(hw,0x9DD3u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9DD4u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9EF1u), 0x849DD1u); }
    goto L_849DD4;
L_849DD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DD4u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9DD4u,0x849DD4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DD4u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DD4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DD4 LDY
    cpu.setY(0x8u, 16);
    goto L_849DD7;
L_849DD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DD7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DD7u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DD7u, 5u + 1u, 3u, cpu.address("absy", 0x063Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DD7 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x63Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849DDA;
L_849DDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DDAu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DDAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DDA ASL
    cpu.aslA();
    goto L_849DDB;
L_849DDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DDBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DDBu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DDBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DDB ASL
    cpu.aslA();
    goto L_849DDC;
L_849DDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DDCu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DDCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DDC ASL
    cpu.aslA();
    goto L_849DDD;
L_849DDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DDDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DDDu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DDDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DDD ADC
    cpu.adc(0x68u);
    goto L_849DE0;
L_849DE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE0u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DE0 TAY
    cpu.transfer("TAY");
    goto L_849DE1;
L_849DE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DE1 LDA
    cpu.setA(0x3u, 16);
    goto L_849DE4;
L_849DE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE4u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE4u, 6u, 3u, cpu.address("abs", 0x9EF1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849DE4 JSR -> $849EF1 stack real
    { cpu.push16Value(hw,0x9DE6u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9DE7u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9EF1u), 0x849DE4u); }
    goto L_849DE7;
L_849DE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DE7u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9DE7u,0x849DE7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE7u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DE7 LDY
    cpu.setY(0x4u, 16);
    goto L_849DEA;
L_849DEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DEAu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DEAu, 5u + 1u, 3u, cpu.address("absy", 0x063Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DEA LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x63Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849DED;
L_849DED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DEDu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DEDu, 6u, 3u, cpu.address("abs", 0x9F4Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849DED JSR -> $849F4E stack real
    { cpu.push16Value(hw,0x9DEFu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9DF0u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9F4Eu), 0x849DEDu); }
    goto L_849DF0;
L_849DF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DF0u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9DF0u,0x849DF0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF0u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DF0 REP
    cpu.rep(0x20u);
    goto L_849DF2;
L_849DF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF2u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF2u, 5u + 1u, 3u, cpu.address("absy", 0x063Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DF2 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x63Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849DF5;
L_849DF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF5u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DF5 LDX
    cpu.setX(0x2u, 16);
    goto L_849DF8;
L_849DF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF8u, 6u, 3u, cpu.address("abs", 0x9F86u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849DF8 JSR -> $849F86 stack real
    { cpu.push16Value(hw,0x9DFAu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9DFBu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9F86u), 0x849DF8u); }
    goto L_849DFB;
L_849DFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DFBu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9DFBu,0x849DFBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DFBu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DFBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DFB LDY
    cpu.setY(0x4u, 16);
    goto L_849DFE;
L_849DFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DFEu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DFEu, 5u + 1u, 3u, cpu.address("absy", 0x0633u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DFE LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x633u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849E01;
L_849E01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E01u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E01u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E01 ASL
    cpu.aslA();
    goto L_849E02;
L_849E02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E02u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E02u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E02 TAX
    cpu.transfer("TAX");
    goto L_849E03;
L_849E03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E03u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E03u, 6u, 4u, ((0x849FBEu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E03 LDA
    cpu.loadA(hw.readW(((0x849FBEu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849E07;
L_849E07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E07u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E07u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E07 TAY
    cpu.transfer("TAY");
    goto L_849E08;
L_849E08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E08u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E08u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E08 LDA
    cpu.setA(0x1u, 16);
    goto L_849E0B;
L_849E0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E0Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E0Bu, 6u, 3u, cpu.address("abs", 0x9EF1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849E0B JSR -> $849EF1 stack real
    { cpu.push16Value(hw,0x9E0Du); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9E0Eu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9EF1u), 0x849E0Bu); }
    goto L_849E0E;
L_849E0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E0Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E0Eu,0x849E0Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E0Eu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E0Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E0E LDY
    cpu.setY(0x4u, 16);
    goto L_849E11;
L_849E11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E11u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E11u, 5u + 1u, 3u, cpu.address("absy", 0x063Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E11 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x63Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849E14;
L_849E14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E14u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E14u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E14 ASL
    cpu.aslA();
    goto L_849E15;
L_849E15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E15u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E15u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E15 ASL
    cpu.aslA();
    goto L_849E16;
L_849E16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E16u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E16u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E16 ASL
    cpu.aslA();
    goto L_849E17;
L_849E17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E17u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E17u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E17 ADC
    cpu.adc(0x68u);
    goto L_849E1A;
L_849E1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Au,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E1A TAY
    cpu.transfer("TAY");
    goto L_849E1B;
L_849E1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E1B LDA
    cpu.setA(0x4u, 16);
    goto L_849E1E;
L_849E1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Eu, 6u, 3u, cpu.address("abs", 0x9EF1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849E1E JSR -> $849EF1 stack real
    { cpu.push16Value(hw,0x9E20u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9E21u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9EF1u), 0x849E1Eu); }
    goto L_849E21;
L_849E21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E21u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E21u,0x849E21u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E21u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E21u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E21 REP
    cpu.rep(0x20u);
    goto L_849E23;
L_849E23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E23u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E23u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E23 LDY
    cpu.setY(0x4u, 16);
    goto L_849E26;
L_849E26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E26u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E26u, 5u + 1u, 3u, cpu.address("absy", 0x064Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E26 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x64Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849E29;
L_849E29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E29u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E29u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E29 ASL
    cpu.aslA();
    goto L_849E2A;
L_849E2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E2Au,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E2Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E2A TAX
    cpu.transfer("TAX");
    goto L_849E2B;
L_849E2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E2Bu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E2Bu, 6u, 4u, ((0x849FC8u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E2B LDA
    cpu.loadA(hw.readW(((0x849FC8u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849E2F;
L_849E2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E2Fu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E2Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E2F TAY
    cpu.transfer("TAY");
    goto L_849E30;
L_849E30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E30u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E30u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E30 LDA
    cpu.setA(0x6u, 16);
    goto L_849E33;
L_849E33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E33u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E33u, 6u, 3u, cpu.address("abs", 0x9EF1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849E33 JSR -> $849EF1 stack real
    { cpu.push16Value(hw,0x9E35u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9E36u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9EF1u), 0x849E33u); }
    goto L_849E36;
L_849E36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E36u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E36u,0x849E36u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E36u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E36u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849E36 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x849E36u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x849E36u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_849DAB_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x849DABu: goto L_849DAB;
    case 0x849DADu: goto L_849DAD;
    case 0x849DB0u: goto L_849DB0;
    case 0x849DB3u: goto L_849DB3;
    case 0x849DB6u: goto L_849DB6;
    case 0x849DB8u: goto L_849DB8;
    case 0x849DBBu: goto L_849DBB;
    case 0x849DBEu: goto L_849DBE;
    case 0x849DC1u: goto L_849DC1;
    case 0x849DC4u: goto L_849DC4;
    case 0x849DC7u: goto L_849DC7;
    case 0x849DC8u: goto L_849DC8;
    case 0x849DC9u: goto L_849DC9;
    case 0x849DCDu: goto L_849DCD;
    case 0x849DCEu: goto L_849DCE;
    case 0x849DD1u: goto L_849DD1;
    case 0x849DD4u: goto L_849DD4;
    case 0x849DD7u: goto L_849DD7;
    case 0x849DDAu: goto L_849DDA;
    case 0x849DDBu: goto L_849DDB;
    case 0x849DDCu: goto L_849DDC;
    case 0x849DDDu: goto L_849DDD;
    case 0x849DE0u: goto L_849DE0;
    case 0x849DE1u: goto L_849DE1;
    case 0x849DE4u: goto L_849DE4;
    case 0x849DE7u: goto L_849DE7;
    case 0x849DEAu: goto L_849DEA;
    case 0x849DEDu: goto L_849DED;
    case 0x849DF0u: goto L_849DF0;
    case 0x849DF2u: goto L_849DF2;
    case 0x849DF5u: goto L_849DF5;
    case 0x849DF8u: goto L_849DF8;
    case 0x849DFBu: goto L_849DFB;
    case 0x849DFEu: goto L_849DFE;
    case 0x849E01u: goto L_849E01;
    case 0x849E02u: goto L_849E02;
    case 0x849E03u: goto L_849E03;
    case 0x849E07u: goto L_849E07;
    case 0x849E08u: goto L_849E08;
    case 0x849E0Bu: goto L_849E0B;
    case 0x849E0Eu: goto L_849E0E;
    case 0x849E11u: goto L_849E11;
    case 0x849E14u: goto L_849E14;
    case 0x849E15u: goto L_849E15;
    case 0x849E16u: goto L_849E16;
    case 0x849E17u: goto L_849E17;
    case 0x849E1Au: goto L_849E1A;
    case 0x849E1Bu: goto L_849E1B;
    case 0x849E1Eu: goto L_849E1E;
    case 0x849E21u: goto L_849E21;
    case 0x849E23u: goto L_849E23;
    case 0x849E26u: goto L_849E26;
    case 0x849E29u: goto L_849E29;
    case 0x849E2Au: goto L_849E2A;
    case 0x849E2Bu: goto L_849E2B;
    case 0x849E2Fu: goto L_849E2F;
    case 0x849E30u: goto L_849E30;
    case 0x849E33u: goto L_849E33;
    case 0x849E36u: goto L_849E36;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_849DAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DABu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DABu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DAB REP
    cpu.rep(0x20u);
    goto L_849DAD;
L_849DAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DADu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DADu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DAD LDY
    cpu.setY(0x8u, 16);
    goto L_849DB0;
L_849DB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DB0u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DB0u, 5u + 1u, 3u, cpu.address("absy", 0x063Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DB0 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x63Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849DB3;
L_849DB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DB3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DB3u, 6u, 3u, cpu.address("abs", 0x9F4Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849DB3 JSR -> $849F4E stack real
    { cpu.push16Value(hw,0x9DB5u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9DB6u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9F4Eu), 0x849DB3u); }
    goto L_849DB6;
L_849DB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DB6u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9DB6u,0x849DB6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DB6u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DB6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DB6 REP
    cpu.rep(0x20u);
    goto L_849DB8;
L_849DB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DB8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DB8u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DB8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DB8 LDX
    cpu.setX(0x0u, 16);
    goto L_849DBB;
L_849DBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DBBu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DBBu, 5u + 1u, 3u, cpu.address("absy", 0x063Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DBB LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x63Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849DBE;
L_849DBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DBEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DBEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DBEu, 6u, 3u, cpu.address("abs", 0x9F86u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849DBE JSR -> $849F86 stack real
    { cpu.push16Value(hw,0x9DC0u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9DC1u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9F86u), 0x849DBEu); }
    goto L_849DC1;
L_849DC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DC1u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9DC1u,0x849DC1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC1u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DC1 LDY
    cpu.setY(0x8u, 16);
    goto L_849DC4;
L_849DC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC4u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC4u, 5u + 1u, 3u, cpu.address("absy", 0x0633u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DC4 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x633u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849DC7;
L_849DC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC7u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DC7 ASL
    cpu.aslA();
    goto L_849DC8;
L_849DC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC8u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DC8 TAX
    cpu.transfer("TAX");
    goto L_849DC9;
L_849DC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC9u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC9u, 6u, 4u, ((0x849FBEu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DC9 LDA
    cpu.loadA(hw.readW(((0x849FBEu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849DCD;
L_849DCD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DCDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DCDu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DCDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DCD TAY
    cpu.transfer("TAY");
    goto L_849DCE;
L_849DCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DCEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DCEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DCEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DCE LDA
    cpu.setA(0x0u, 16);
    goto L_849DD1;
L_849DD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DD1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DD1u, 6u, 3u, cpu.address("abs", 0x9EF1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849DD1 JSR -> $849EF1 stack real
    { cpu.push16Value(hw,0x9DD3u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9DD4u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9EF1u), 0x849DD1u); }
    goto L_849DD4;
L_849DD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DD4u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9DD4u,0x849DD4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DD4u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DD4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DD4 LDY
    cpu.setY(0x8u, 16);
    goto L_849DD7;
L_849DD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DD7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DD7u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DD7u, 5u + 1u, 3u, cpu.address("absy", 0x063Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DD7 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x63Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849DDA;
L_849DDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DDAu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DDAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DDA ASL
    cpu.aslA();
    goto L_849DDB;
L_849DDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DDBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DDBu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DDBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DDB ASL
    cpu.aslA();
    goto L_849DDC;
L_849DDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DDCu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DDCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DDC ASL
    cpu.aslA();
    goto L_849DDD;
L_849DDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DDDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DDDu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DDDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DDD ADC
    cpu.adc(0x68u);
    goto L_849DE0;
L_849DE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE0u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DE0 TAY
    cpu.transfer("TAY");
    goto L_849DE1;
L_849DE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DE1 LDA
    cpu.setA(0x3u, 16);
    goto L_849DE4;
L_849DE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE4u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE4u, 6u, 3u, cpu.address("abs", 0x9EF1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849DE4 JSR -> $849EF1 stack real
    { cpu.push16Value(hw,0x9DE6u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9DE7u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9EF1u), 0x849DE4u); }
    goto L_849DE7;
L_849DE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DE7u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9DE7u,0x849DE7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE7u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DE7 LDY
    cpu.setY(0x4u, 16);
    goto L_849DEA;
L_849DEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DEAu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DEAu, 5u + 1u, 3u, cpu.address("absy", 0x063Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DEA LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x63Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849DED;
L_849DED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DEDu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DEDu, 6u, 3u, cpu.address("abs", 0x9F4Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849DED JSR -> $849F4E stack real
    { cpu.push16Value(hw,0x9DEFu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9DF0u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9F4Eu), 0x849DEDu); }
    goto L_849DF0;
L_849DF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DF0u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9DF0u,0x849DF0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF0u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DF0 REP
    cpu.rep(0x20u);
    goto L_849DF2;
L_849DF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF2u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF2u, 5u + 1u, 3u, cpu.address("absy", 0x063Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DF2 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x63Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849DF5;
L_849DF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF5u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DF5 LDX
    cpu.setX(0x2u, 16);
    goto L_849DF8;
L_849DF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF8u, 6u, 3u, cpu.address("abs", 0x9F86u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849DF8 JSR -> $849F86 stack real
    { cpu.push16Value(hw,0x9DFAu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9DFBu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9F86u), 0x849DF8u); }
    goto L_849DFB;
L_849DFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DFBu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9DFBu,0x849DFBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DFBu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DFBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DFB LDY
    cpu.setY(0x4u, 16);
    goto L_849DFE;
L_849DFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DFEu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DFEu, 5u + 1u, 3u, cpu.address("absy", 0x0633u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DFE LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x633u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849E01;
L_849E01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E01u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E01u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E01 ASL
    cpu.aslA();
    goto L_849E02;
L_849E02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E02u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E02u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E02 TAX
    cpu.transfer("TAX");
    goto L_849E03;
L_849E03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E03u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E03u, 6u, 4u, ((0x849FBEu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E03 LDA
    cpu.loadA(hw.readW(((0x849FBEu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849E07;
L_849E07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E07u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E07u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E07 TAY
    cpu.transfer("TAY");
    goto L_849E08;
L_849E08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E08u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E08u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E08 LDA
    cpu.setA(0x1u, 16);
    goto L_849E0B;
L_849E0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E0Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E0Bu, 6u, 3u, cpu.address("abs", 0x9EF1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849E0B JSR -> $849EF1 stack real
    { cpu.push16Value(hw,0x9E0Du); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9E0Eu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9EF1u), 0x849E0Bu); }
    goto L_849E0E;
L_849E0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E0Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E0Eu,0x849E0Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E0Eu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E0Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E0E LDY
    cpu.setY(0x4u, 16);
    goto L_849E11;
L_849E11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E11u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E11u, 5u + 1u, 3u, cpu.address("absy", 0x063Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E11 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x63Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849E14;
L_849E14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E14u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E14u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E14 ASL
    cpu.aslA();
    goto L_849E15;
L_849E15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E15u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E15u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E15 ASL
    cpu.aslA();
    goto L_849E16;
L_849E16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E16u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E16u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E16 ASL
    cpu.aslA();
    goto L_849E17;
L_849E17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E17u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E17u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E17 ADC
    cpu.adc(0x68u);
    goto L_849E1A;
L_849E1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Au,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E1A TAY
    cpu.transfer("TAY");
    goto L_849E1B;
L_849E1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E1B LDA
    cpu.setA(0x4u, 16);
    goto L_849E1E;
L_849E1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Eu, 6u, 3u, cpu.address("abs", 0x9EF1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849E1E JSR -> $849EF1 stack real
    { cpu.push16Value(hw,0x9E20u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9E21u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9EF1u), 0x849E1Eu); }
    goto L_849E21;
L_849E21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E21u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E21u,0x849E21u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E21u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E21u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E21 REP
    cpu.rep(0x20u);
    goto L_849E23;
L_849E23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E23u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E23u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E23 LDY
    cpu.setY(0x4u, 16);
    goto L_849E26;
L_849E26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E26u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E26u, 5u + 1u, 3u, cpu.address("absy", 0x064Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E26 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x64Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849E29;
L_849E29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E29u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E29u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E29 ASL
    cpu.aslA();
    goto L_849E2A;
L_849E2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E2Au,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E2Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E2A TAX
    cpu.transfer("TAX");
    goto L_849E2B;
L_849E2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E2Bu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E2Bu, 6u, 4u, ((0x849FC8u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E2B LDA
    cpu.loadA(hw.readW(((0x849FC8u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849E2F;
L_849E2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E2Fu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E2Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E2F TAY
    cpu.transfer("TAY");
    goto L_849E30;
L_849E30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E30u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E30u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E30 LDA
    cpu.setA(0x6u, 16);
    goto L_849E33;
L_849E33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E33u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E33u, 6u, 3u, cpu.address("abs", 0x9EF1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849E33 JSR -> $849EF1 stack real
    { cpu.push16Value(hw,0x9E35u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9E36u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9EF1u), 0x849E33u); }
    goto L_849E36;
L_849E36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E36u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E36u,0x849E36u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E36u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E36u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849E36 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x849E36u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x849E36u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_84F994_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84F994u: goto L_84F994;
    case 0x84F997u: goto L_84F997;
    case 0x84F999u: goto L_84F999;
    case 0x84F99Cu: goto L_84F99C;
    case 0x84F99Eu: goto L_84F99E;
    case 0x84F9A1u: goto L_84F9A1;
    case 0x84F9A3u: goto L_84F9A3;
    case 0x84F9A6u: goto L_84F9A6;
    case 0x84F9AAu: goto L_84F9AA;
    case 0x84F9ABu: goto L_84F9AB;
    case 0x84F9ACu: goto L_84F9AC;
    case 0x84F9AEu: goto L_84F9AE;
    case 0x84F9B0u: goto L_84F9B0;
    case 0x84F9B2u: goto L_84F9B2;
    case 0x84F9B3u: goto L_84F9B3;
    case 0x84F9B6u: goto L_84F9B6;
    case 0x84F9B8u: goto L_84F9B8;
    case 0x84F9B9u: goto L_84F9B9;
    case 0x84F9BBu: goto L_84F9BB;
    case 0x84F9BDu: goto L_84F9BD;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84F994:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF994u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF994u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF994u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F994 LDX
    cpu.setX(0x30Eu, 16);
    goto L_84F997;
L_84F997:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF997u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF997u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF997u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F997 STX
    hw.write(cpu.address("dp", 0x61u), cpu.x, cpu.x8?8:16);
    goto L_84F999;
L_84F999:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF999u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF999u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF999u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F999 LDA
    cpu.setA(0x6u, 16);
    goto L_84F99C;
L_84F99C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF99Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF99Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF99Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F99C STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_84F99E;
L_84F99E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF99Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF99Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF99Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F99E LDA
    cpu.setA(0x10u, 16);
    goto L_84F9A1;
L_84F9A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF9A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF9A1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF9A1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F9A1 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_84F9A3;
L_84F9A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF9A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF9A3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF9A3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F9A3 LDA
    cpu.setA(0x0u, 16);
    goto L_84F9A6;
L_84F9A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF9A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF9A6u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF9A6u, 6u, 4u, ((0x7E2800u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F9A6 STA
    hw.write(((0x7E2800u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_84F9AA;
L_84F9AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF9AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF9AAu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF9AAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F9AA INX
    cpu.inc('X');
    goto L_84F9AB;
L_84F9AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF9ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF9ABu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF9ABu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F9AB INX
    cpu.inc('X');
    goto L_84F9AC;
L_84F9AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF9ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF9ACu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF9ACu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F9AC DEC
    cpu.decMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_84F9AE;
L_84F9AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF9AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF9AEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF9AEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F9AE BNE -> $84F9A6
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_84F9A6; }
    goto L_84F9B0;
L_84F9B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF9B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF9B0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF9B0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F9B0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x61u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84F9B2;
L_84F9B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF9B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF9B2u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF9B2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F9B2 CLC
    cpu.setFlag('C', false);
    goto L_84F9B3;
L_84F9B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF9B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF9B3u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF9B3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F9B3 ADC
    cpu.adc(0x40u);
    goto L_84F9B6;
L_84F9B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF9B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF9B6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF9B6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F9B6 STA
    hw.write(cpu.address("dp", 0x61u), cpu.a, cpu.m8?8:16);
    goto L_84F9B8;
L_84F9B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF9B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF9B8u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF9B8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F9B8 TAX
    cpu.transfer("TAX");
    goto L_84F9B9;
L_84F9B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF9B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF9B9u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF9B9u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F9B9 DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_84F9BB;
L_84F9BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF9BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF9BBu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF9BBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F9BB BPL -> $84F99E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_84F99E; }
    goto L_84F9BD;
L_84F9BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF9BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF9BDu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF9BDu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84F9BD RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84F9BDu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84F9BDu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

