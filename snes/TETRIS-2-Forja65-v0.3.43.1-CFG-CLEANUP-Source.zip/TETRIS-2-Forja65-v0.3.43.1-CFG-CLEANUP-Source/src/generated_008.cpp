#include "generated.hpp"
void sub_00850F_E0M0X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00850Fu: goto L_00850F;
    case 0x008511u: goto L_008511;
    case 0x008512u: goto L_008512;
    case 0x008513u: goto L_008513;
    case 0x008514u: goto L_008514;
    case 0x008515u: goto L_008515;
    case 0x008516u: goto L_008516;
    case 0x008519u: goto L_008519;
    case 0x00851Bu: goto L_00851B;
    case 0x00851Du: goto L_00851D;
    case 0x00851Fu: goto L_00851F;
    case 0x008520u: goto L_008520;
    case 0x008521u: goto L_008521;
    case 0x008524u: goto L_008524;
    case 0x008527u: goto L_008527;
    case 0x008529u: goto L_008529;
    case 0x00852Au: goto L_00852A;
    case 0x00852Bu: goto L_00852B;
    case 0x00852Cu: goto L_00852C;
    case 0x00852Du: goto L_00852D;
    case 0x00852Eu: goto L_00852E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00850F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x850Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x850Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x850Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00850F REP
    cpu.rep(0x20u);
    goto L_008511;
L_008511:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8511u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8511u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8511u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008511 PHA
    cpu.push("PHA", hw);
    goto L_008512;
L_008512:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8512u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8512u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8512u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $008512 PHX
    cpu.push("PHX", hw);
    goto L_008513;
L_008513:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8513u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8513u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8513u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $008513 PHY
    cpu.push("PHY", hw);
    goto L_008514;
L_008514:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8514u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8514u,cpu,0x0Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8514u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008514 PHD
    cpu.push("PHD", hw);
    goto L_008515;
L_008515:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8515u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8515u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8515u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $008515 PHB
    cpu.push("PHB", hw);
    goto L_008516;
L_008516:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8516u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8516u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8516u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008516 LDA
    cpu.setA(0x0u, 16);
    goto L_008519;
L_008519:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8519u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8519u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8519u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008519 SEP
    cpu.sep(0x20u);
    goto L_00851B;
L_00851B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x851Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x851Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x851Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00851B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00851D;
L_00851D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x851Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x851Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x851Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00851D AND
    cpu.logicAnd(0x7Fu);
    goto L_00851F;
L_00851F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x851Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x851Fu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x851Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00851F ASL
    cpu.aslA();
    goto L_008520;
L_008520:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8520u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8520u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8520u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008520 TAX
    cpu.transfer("TAX");
    goto L_008521;
L_008521:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8521u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8521u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8521u, 4u, 3u, cpu.address("abs", 0x4211u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008521 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x4211u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008524;
L_008524:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8524u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8524u,cpu,0xFCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8524u, 8u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x852Fu + cpu.x) & 0xFFFFu)), 2u, 2u);
    // $008524 JSR (852F,X) dinamico stack real
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x852Fu+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); cpu.push16Value(hw,0x8526u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8527u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, dst, 0x008524u); }
    goto L_008527;
L_008527:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8527u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8527u,0x008527u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8527u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8527u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008527 REP
    cpu.rep(0x20u);
    goto L_008529;
L_008529:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8529u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8529u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8529u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $008529 PLB
    cpu.pop("PLB", hw);
    goto L_00852A;
L_00852A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x852Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x852Au,cpu,0x2Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x852Au, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00852A PLD
    cpu.pop("PLD", hw);
    goto L_00852B;
L_00852B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x852Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x852Bu,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x852Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00852B PLY
    cpu.pop("PLY", hw);
    goto L_00852C;
L_00852C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x852Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x852Cu,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x852Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00852C PLX
    cpu.pop("PLX", hw);
    goto L_00852D;
L_00852D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x852Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x852Du,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x852Du, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00852D PLA
    cpu.pop("PLA", hw);
    goto L_00852E;
L_00852E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x852Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x852Eu,cpu,0x40u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x852Eu, 7u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $00852E RTI stack real
    {auto dst=cpu.returnInterrupt(hw);hw.requestDispatch(dst,0x00852Eu);return;}
}

void sub_608111_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x608111u: goto L_608111;
    case 0x608113u: goto L_608113;
    case 0x608116u: goto L_608116;
    case 0x608118u: goto L_608118;
    case 0x60811Bu: goto L_60811B;
    case 0x60811Eu: goto L_60811E;
    case 0x608120u: goto L_608120;
    case 0x608123u: goto L_608123;
    case 0x608126u: goto L_608126;
    case 0x608129u: goto L_608129;
    case 0x60812Cu: goto L_60812C;
    case 0x60812Fu: goto L_60812F;
    case 0x608132u: goto L_608132;
    case 0x608135u: goto L_608135;
    case 0x608138u: goto L_608138;
    case 0x60813Bu: goto L_60813B;
    case 0x60813Eu: goto L_60813E;
    case 0x608141u: goto L_608141;
    case 0x608144u: goto L_608144;
    case 0x608147u: goto L_608147;
    case 0x60814Au: goto L_60814A;
    case 0x60814Du: goto L_60814D;
    case 0x608150u: goto L_608150;
    case 0x608153u: goto L_608153;
    case 0x608156u: goto L_608156;
    case 0x608159u: goto L_608159;
    case 0x60815Cu: goto L_60815C;
    case 0x60815Fu: goto L_60815F;
    case 0x608162u: goto L_608162;
    case 0x608165u: goto L_608165;
    case 0x608168u: goto L_608168;
    case 0x60816Bu: goto L_60816B;
    case 0x60816Eu: goto L_60816E;
    case 0x608171u: goto L_608171;
    case 0x608173u: goto L_608173;
    case 0x608176u: goto L_608176;
    case 0x608179u: goto L_608179;
    case 0x60817Cu: goto L_60817C;
    case 0x60817Fu: goto L_60817F;
    case 0x608182u: goto L_608182;
    case 0x608185u: goto L_608185;
    case 0x608188u: goto L_608188;
    case 0x60818Bu: goto L_60818B;
    case 0x60818Eu: goto L_60818E;
    case 0x608191u: goto L_608191;
    case 0x608194u: goto L_608194;
    case 0x608197u: goto L_608197;
    case 0x60819Au: goto L_60819A;
    case 0x60819Du: goto L_60819D;
    case 0x6081A0u: goto L_6081A0;
    case 0x6081A3u: goto L_6081A3;
    case 0x6081A6u: goto L_6081A6;
    case 0x6081A9u: goto L_6081A9;
    case 0x6081ACu: goto L_6081AC;
    case 0x6081AFu: goto L_6081AF;
    case 0x6081B2u: goto L_6081B2;
    case 0x6081B5u: goto L_6081B5;
    case 0x6081B8u: goto L_6081B8;
    case 0x6081BBu: goto L_6081BB;
    case 0x6081BEu: goto L_6081BE;
    case 0x6081C1u: goto L_6081C1;
    case 0x6081C4u: goto L_6081C4;
    case 0x6081C7u: goto L_6081C7;
    case 0x6081CAu: goto L_6081CA;
    case 0x6081CDu: goto L_6081CD;
    case 0x6081CFu: goto L_6081CF;
    case 0x6081D2u: goto L_6081D2;
    case 0x6081D5u: goto L_6081D5;
    case 0x6081D7u: goto L_6081D7;
    case 0x6081DAu: goto L_6081DA;
    case 0x6081DDu: goto L_6081DD;
    case 0x6081E0u: goto L_6081E0;
    case 0x6081E2u: goto L_6081E2;
    case 0x6081E4u: goto L_6081E4;
    case 0x6081E7u: goto L_6081E7;
    case 0x6081EAu: goto L_6081EA;
    case 0x6081EDu: goto L_6081ED;
    case 0x6081F0u: goto L_6081F0;
    case 0x6081F3u: goto L_6081F3;
    case 0x6081F6u: goto L_6081F6;
    case 0x6081F9u: goto L_6081F9;
    case 0x6081FCu: goto L_6081FC;
    case 0x6081FFu: goto L_6081FF;
    case 0x608202u: goto L_608202;
    case 0x608205u: goto L_608205;
    case 0x608208u: goto L_608208;
    case 0x60820Bu: goto L_60820B;
    case 0x60820Eu: goto L_60820E;
    case 0x608211u: goto L_608211;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_608111:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8111u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8111u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8111u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608111 LDA
    cpu.setA(0x80u, 8);
    goto L_608113;
L_608113:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8113u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8113u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8113u, 4u, 3u, cpu.address("abs", 0x2100u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608113 STA
    hw.write(cpu.address("abs", 0x2100u), cpu.a, cpu.m8?8:16);
    goto L_608116;
L_608116:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8116u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8116u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8116u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608116 STA
    hw.write(cpu.address("dp", 0x74u), cpu.a, cpu.m8?8:16);
    goto L_608118;
L_608118:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8118u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8118u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8118u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608118 STZ
    hw.write(cpu.address("abs", 0x420Bu), 0, cpu.m8?8:16);
    goto L_60811B;
L_60811B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x811Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x811Bu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x811Bu, 4u, 3u, cpu.address("abs", 0x420Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60811B STZ
    hw.write(cpu.address("abs", 0x420Cu), 0, cpu.m8?8:16);
    goto L_60811E;
L_60811E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x811Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x811Eu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x811Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xB4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60811E STZ
    hw.write(cpu.address("dp", 0xB4u), 0, cpu.m8?8:16);
    goto L_608120;
L_608120:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8120u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8120u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8120u, 4u, 3u, cpu.address("abs", 0x2101u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608120 STZ
    hw.write(cpu.address("abs", 0x2101u), 0, cpu.m8?8:16);
    goto L_608123;
L_608123:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8123u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8123u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8123u, 4u, 3u, cpu.address("abs", 0x2102u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608123 STZ
    hw.write(cpu.address("abs", 0x2102u), 0, cpu.m8?8:16);
    goto L_608126;
L_608126:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8126u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8126u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8126u, 4u, 3u, cpu.address("abs", 0x2103u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608126 STZ
    hw.write(cpu.address("abs", 0x2103u), 0, cpu.m8?8:16);
    goto L_608129;
L_608129:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8129u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8129u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8129u, 4u, 3u, cpu.address("abs", 0x2105u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608129 STZ
    hw.write(cpu.address("abs", 0x2105u), 0, cpu.m8?8:16);
    goto L_60812C;
L_60812C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x812Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x812Cu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x812Cu, 4u, 3u, cpu.address("abs", 0x2106u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60812C STZ
    hw.write(cpu.address("abs", 0x2106u), 0, cpu.m8?8:16);
    goto L_60812F;
L_60812F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x812Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x812Fu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x812Fu, 4u, 3u, cpu.address("abs", 0x2107u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60812F STZ
    hw.write(cpu.address("abs", 0x2107u), 0, cpu.m8?8:16);
    goto L_608132;
L_608132:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8132u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8132u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8132u, 4u, 3u, cpu.address("abs", 0x2108u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608132 STZ
    hw.write(cpu.address("abs", 0x2108u), 0, cpu.m8?8:16);
    goto L_608135;
L_608135:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8135u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8135u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8135u, 4u, 3u, cpu.address("abs", 0x2109u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608135 STZ
    hw.write(cpu.address("abs", 0x2109u), 0, cpu.m8?8:16);
    goto L_608138;
L_608138:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8138u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8138u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8138u, 4u, 3u, cpu.address("abs", 0x210Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608138 STZ
    hw.write(cpu.address("abs", 0x210Au), 0, cpu.m8?8:16);
    goto L_60813B;
L_60813B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x813Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x813Bu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x813Bu, 4u, 3u, cpu.address("abs", 0x210Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60813B STZ
    hw.write(cpu.address("abs", 0x210Bu), 0, cpu.m8?8:16);
    goto L_60813E;
L_60813E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x813Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x813Eu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x813Eu, 4u, 3u, cpu.address("abs", 0x210Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60813E STZ
    hw.write(cpu.address("abs", 0x210Cu), 0, cpu.m8?8:16);
    goto L_608141;
L_608141:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8141u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8141u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8141u, 4u, 3u, cpu.address("abs", 0x210Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608141 STZ
    hw.write(cpu.address("abs", 0x210Du), 0, cpu.m8?8:16);
    goto L_608144;
L_608144:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8144u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8144u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8144u, 4u, 3u, cpu.address("abs", 0x210Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608144 STZ
    hw.write(cpu.address("abs", 0x210Du), 0, cpu.m8?8:16);
    goto L_608147;
L_608147:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8147u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8147u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8147u, 4u, 3u, cpu.address("abs", 0x210Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608147 STZ
    hw.write(cpu.address("abs", 0x210Eu), 0, cpu.m8?8:16);
    goto L_60814A;
L_60814A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x814Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x814Au,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x814Au, 4u, 3u, cpu.address("abs", 0x210Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60814A STZ
    hw.write(cpu.address("abs", 0x210Eu), 0, cpu.m8?8:16);
    goto L_60814D;
L_60814D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x814Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x814Du,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x814Du, 4u, 3u, cpu.address("abs", 0x210Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60814D STZ
    hw.write(cpu.address("abs", 0x210Fu), 0, cpu.m8?8:16);
    goto L_608150;
L_608150:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8150u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8150u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8150u, 4u, 3u, cpu.address("abs", 0x210Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608150 STZ
    hw.write(cpu.address("abs", 0x210Fu), 0, cpu.m8?8:16);
    goto L_608153;
L_608153:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8153u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8153u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8153u, 4u, 3u, cpu.address("abs", 0x2110u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608153 STZ
    hw.write(cpu.address("abs", 0x2110u), 0, cpu.m8?8:16);
    goto L_608156;
L_608156:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8156u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8156u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8156u, 4u, 3u, cpu.address("abs", 0x2110u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608156 STZ
    hw.write(cpu.address("abs", 0x2110u), 0, cpu.m8?8:16);
    goto L_608159;
L_608159:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8159u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8159u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8159u, 4u, 3u, cpu.address("abs", 0x2111u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608159 STZ
    hw.write(cpu.address("abs", 0x2111u), 0, cpu.m8?8:16);
    goto L_60815C;
L_60815C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x815Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x815Cu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x815Cu, 4u, 3u, cpu.address("abs", 0x2111u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60815C STZ
    hw.write(cpu.address("abs", 0x2111u), 0, cpu.m8?8:16);
    goto L_60815F;
L_60815F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x815Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x815Fu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x815Fu, 4u, 3u, cpu.address("abs", 0x2112u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60815F STZ
    hw.write(cpu.address("abs", 0x2112u), 0, cpu.m8?8:16);
    goto L_608162;
L_608162:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8162u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8162u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8162u, 4u, 3u, cpu.address("abs", 0x2112u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608162 STZ
    hw.write(cpu.address("abs", 0x2112u), 0, cpu.m8?8:16);
    goto L_608165;
L_608165:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8165u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8165u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8165u, 4u, 3u, cpu.address("abs", 0x2113u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608165 STZ
    hw.write(cpu.address("abs", 0x2113u), 0, cpu.m8?8:16);
    goto L_608168;
L_608168:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8168u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8168u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8168u, 4u, 3u, cpu.address("abs", 0x2113u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608168 STZ
    hw.write(cpu.address("abs", 0x2113u), 0, cpu.m8?8:16);
    goto L_60816B;
L_60816B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x816Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x816Bu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x816Bu, 4u, 3u, cpu.address("abs", 0x2114u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60816B STZ
    hw.write(cpu.address("abs", 0x2114u), 0, cpu.m8?8:16);
    goto L_60816E;
L_60816E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x816Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x816Eu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x816Eu, 4u, 3u, cpu.address("abs", 0x2114u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60816E STZ
    hw.write(cpu.address("abs", 0x2114u), 0, cpu.m8?8:16);
    goto L_608171;
L_608171:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8171u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8171u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8171u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608171 LDA
    cpu.setA(0x80u, 8);
    goto L_608173;
L_608173:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8173u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8173u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8173u, 4u, 3u, cpu.address("abs", 0x2115u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608173 STA
    hw.write(cpu.address("abs", 0x2115u), cpu.a, cpu.m8?8:16);
    goto L_608176;
L_608176:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8176u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8176u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8176u, 4u, 3u, cpu.address("abs", 0x2116u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608176 STZ
    hw.write(cpu.address("abs", 0x2116u), 0, cpu.m8?8:16);
    goto L_608179;
L_608179:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8179u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8179u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8179u, 4u, 3u, cpu.address("abs", 0x2117u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608179 STZ
    hw.write(cpu.address("abs", 0x2117u), 0, cpu.m8?8:16);
    goto L_60817C;
L_60817C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x817Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x817Cu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x817Cu, 4u, 3u, cpu.address("abs", 0x211Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60817C STZ
    hw.write(cpu.address("abs", 0x211Au), 0, cpu.m8?8:16);
    goto L_60817F;
L_60817F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x817Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x817Fu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x817Fu, 4u, 3u, cpu.address("abs", 0x211Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60817F STZ
    hw.write(cpu.address("abs", 0x211Bu), 0, cpu.m8?8:16);
    goto L_608182;
L_608182:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8182u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8182u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8182u, 4u, 3u, cpu.address("abs", 0x211Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608182 STZ
    hw.write(cpu.address("abs", 0x211Bu), 0, cpu.m8?8:16);
    goto L_608185;
L_608185:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8185u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8185u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8185u, 4u, 3u, cpu.address("abs", 0x211Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608185 STZ
    hw.write(cpu.address("abs", 0x211Cu), 0, cpu.m8?8:16);
    goto L_608188;
L_608188:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8188u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8188u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8188u, 4u, 3u, cpu.address("abs", 0x211Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608188 STZ
    hw.write(cpu.address("abs", 0x211Cu), 0, cpu.m8?8:16);
    goto L_60818B;
L_60818B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x818Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x818Bu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x818Bu, 4u, 3u, cpu.address("abs", 0x211Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60818B STZ
    hw.write(cpu.address("abs", 0x211Du), 0, cpu.m8?8:16);
    goto L_60818E;
L_60818E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x818Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x818Eu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x818Eu, 4u, 3u, cpu.address("abs", 0x211Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60818E STZ
    hw.write(cpu.address("abs", 0x211Du), 0, cpu.m8?8:16);
    goto L_608191;
L_608191:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8191u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8191u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8191u, 4u, 3u, cpu.address("abs", 0x211Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608191 STZ
    hw.write(cpu.address("abs", 0x211Eu), 0, cpu.m8?8:16);
    goto L_608194;
L_608194:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8194u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8194u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8194u, 4u, 3u, cpu.address("abs", 0x211Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608194 STZ
    hw.write(cpu.address("abs", 0x211Eu), 0, cpu.m8?8:16);
    goto L_608197;
L_608197:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8197u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8197u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8197u, 4u, 3u, cpu.address("abs", 0x211Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608197 STZ
    hw.write(cpu.address("abs", 0x211Fu), 0, cpu.m8?8:16);
    goto L_60819A;
L_60819A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x819Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x819Au,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x819Au, 4u, 3u, cpu.address("abs", 0x211Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60819A STZ
    hw.write(cpu.address("abs", 0x211Fu), 0, cpu.m8?8:16);
    goto L_60819D;
L_60819D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x819Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x819Du,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x819Du, 4u, 3u, cpu.address("abs", 0x2120u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60819D STZ
    hw.write(cpu.address("abs", 0x2120u), 0, cpu.m8?8:16);
    goto L_6081A0;
L_6081A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81A0u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81A0u, 4u, 3u, cpu.address("abs", 0x2120u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6081A0 STZ
    hw.write(cpu.address("abs", 0x2120u), 0, cpu.m8?8:16);
    goto L_6081A3;
L_6081A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81A3u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81A3u, 4u, 3u, cpu.address("abs", 0x2121u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6081A3 STZ
    hw.write(cpu.address("abs", 0x2121u), 0, cpu.m8?8:16);
    goto L_6081A6;
L_6081A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81A6u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81A6u, 4u, 3u, cpu.address("abs", 0x2123u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6081A6 STZ
    hw.write(cpu.address("abs", 0x2123u), 0, cpu.m8?8:16);
    goto L_6081A9;
L_6081A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81A9u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81A9u, 4u, 3u, cpu.address("abs", 0x2124u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6081A9 STZ
    hw.write(cpu.address("abs", 0x2124u), 0, cpu.m8?8:16);
    goto L_6081AC;
L_6081AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81ACu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81ACu, 4u, 3u, cpu.address("abs", 0x2125u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6081AC STZ
    hw.write(cpu.address("abs", 0x2125u), 0, cpu.m8?8:16);
    goto L_6081AF;
L_6081AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81AFu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81AFu, 4u, 3u, cpu.address("abs", 0x2126u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6081AF STZ
    hw.write(cpu.address("abs", 0x2126u), 0, cpu.m8?8:16);
    goto L_6081B2;
L_6081B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81B2u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81B2u, 4u, 3u, cpu.address("abs", 0x2127u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6081B2 STZ
    hw.write(cpu.address("abs", 0x2127u), 0, cpu.m8?8:16);
    goto L_6081B5;
L_6081B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81B5u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81B5u, 4u, 3u, cpu.address("abs", 0x2128u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6081B5 STZ
    hw.write(cpu.address("abs", 0x2128u), 0, cpu.m8?8:16);
    goto L_6081B8;
L_6081B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81B8u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81B8u, 4u, 3u, cpu.address("abs", 0x2129u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6081B8 STZ
    hw.write(cpu.address("abs", 0x2129u), 0, cpu.m8?8:16);
    goto L_6081BB;
L_6081BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81BBu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81BBu, 4u, 3u, cpu.address("abs", 0x212Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6081BB STZ
    hw.write(cpu.address("abs", 0x212Au), 0, cpu.m8?8:16);
    goto L_6081BE;
L_6081BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81BEu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81BEu, 4u, 3u, cpu.address("abs", 0x212Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6081BE STZ
    hw.write(cpu.address("abs", 0x212Bu), 0, cpu.m8?8:16);
    goto L_6081C1;
L_6081C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81C1u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81C1u, 4u, 3u, cpu.address("abs", 0x212Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6081C1 STZ
    hw.write(cpu.address("abs", 0x212Cu), 0, cpu.m8?8:16);
    goto L_6081C4;
L_6081C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81C4u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81C4u, 4u, 3u, cpu.address("abs", 0x212Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6081C4 STZ
    hw.write(cpu.address("abs", 0x212Du), 0, cpu.m8?8:16);
    goto L_6081C7;
L_6081C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81C7u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81C7u, 4u, 3u, cpu.address("abs", 0x212Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6081C7 STZ
    hw.write(cpu.address("abs", 0x212Eu), 0, cpu.m8?8:16);
    goto L_6081CA;
L_6081CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81CAu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81CAu, 4u, 3u, cpu.address("abs", 0x212Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6081CA STZ
    hw.write(cpu.address("abs", 0x212Fu), 0, cpu.m8?8:16);
    goto L_6081CD;
L_6081CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81CDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81CDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6081CD LDA
    cpu.setA(0x30u, 8);
    goto L_6081CF;
L_6081CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81CFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81CFu, 4u, 3u, cpu.address("abs", 0x2130u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6081CF STA
    hw.write(cpu.address("abs", 0x2130u), cpu.a, cpu.m8?8:16);
    goto L_6081D2;
L_6081D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81D2u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81D2u, 4u, 3u, cpu.address("abs", 0x2131u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6081D2 STZ
    hw.write(cpu.address("abs", 0x2131u), 0, cpu.m8?8:16);
    goto L_6081D5;
L_6081D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81D5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81D5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6081D5 LDA
    cpu.setA(0xE0u, 8);
    goto L_6081D7;
L_6081D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81D7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81D7u, 4u, 3u, cpu.address("abs", 0x2132u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6081D7 STA
    hw.write(cpu.address("abs", 0x2132u), cpu.a, cpu.m8?8:16);
    goto L_6081DA;
L_6081DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81DAu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81DAu, 4u, 3u, cpu.address("abs", 0x2133u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6081DA STZ
    hw.write(cpu.address("abs", 0x2133u), 0, cpu.m8?8:16);
    goto L_6081DD;
L_6081DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81DDu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81DDu, 4u, 3u, cpu.address("abs", 0x4200u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6081DD STZ
    hw.write(cpu.address("abs", 0x4200u), 0, cpu.m8?8:16);
    goto L_6081E0;
L_6081E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81E0u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81E0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x73u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6081E0 STZ
    hw.write(cpu.address("dp", 0x73u), 0, cpu.m8?8:16);
    goto L_6081E2;
L_6081E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81E2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81E2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6081E2 LDA
    cpu.setA(0xFFu, 8);
    goto L_6081E4;
L_6081E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81E4u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81E4u, 4u, 3u, cpu.address("abs", 0x4201u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6081E4 STA
    hw.write(cpu.address("abs", 0x4201u), cpu.a, cpu.m8?8:16);
    goto L_6081E7;
L_6081E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81E7u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81E7u, 4u, 3u, cpu.address("abs", 0x4202u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6081E7 STZ
    hw.write(cpu.address("abs", 0x4202u), 0, cpu.m8?8:16);
    goto L_6081EA;
L_6081EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81EAu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81EAu, 4u, 3u, cpu.address("abs", 0x4203u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6081EA STZ
    hw.write(cpu.address("abs", 0x4203u), 0, cpu.m8?8:16);
    goto L_6081ED;
L_6081ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81EDu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81EDu, 4u, 3u, cpu.address("abs", 0x4204u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6081ED STZ
    hw.write(cpu.address("abs", 0x4204u), 0, cpu.m8?8:16);
    goto L_6081F0;
L_6081F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81F0u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81F0u, 4u, 3u, cpu.address("abs", 0x4205u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6081F0 STZ
    hw.write(cpu.address("abs", 0x4205u), 0, cpu.m8?8:16);
    goto L_6081F3;
L_6081F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81F3u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81F3u, 4u, 3u, cpu.address("abs", 0x4206u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6081F3 STZ
    hw.write(cpu.address("abs", 0x4206u), 0, cpu.m8?8:16);
    goto L_6081F6;
L_6081F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81F6u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81F6u, 4u, 3u, cpu.address("abs", 0x4207u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6081F6 STZ
    hw.write(cpu.address("abs", 0x4207u), 0, cpu.m8?8:16);
    goto L_6081F9;
L_6081F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81F9u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81F9u, 4u, 3u, cpu.address("abs", 0x4208u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6081F9 STZ
    hw.write(cpu.address("abs", 0x4208u), 0, cpu.m8?8:16);
    goto L_6081FC;
L_6081FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81FCu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81FCu, 4u, 3u, cpu.address("abs", 0x4209u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6081FC STZ
    hw.write(cpu.address("abs", 0x4209u), 0, cpu.m8?8:16);
    goto L_6081FF;
L_6081FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81FFu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81FFu, 4u, 3u, cpu.address("abs", 0x420Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6081FF STZ
    hw.write(cpu.address("abs", 0x420Au), 0, cpu.m8?8:16);
    goto L_608202;
L_608202:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8202u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8202u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8202u, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608202 STZ
    hw.write(cpu.address("abs", 0x2140u), 0, cpu.m8?8:16);
    goto L_608205;
L_608205:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8205u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8205u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8205u, 4u, 3u, cpu.address("abs", 0x2141u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608205 STZ
    hw.write(cpu.address("abs", 0x2141u), 0, cpu.m8?8:16);
    goto L_608208;
L_608208:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8208u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8208u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8208u, 4u, 3u, cpu.address("abs", 0x2142u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608208 STZ
    hw.write(cpu.address("abs", 0x2142u), 0, cpu.m8?8:16);
    goto L_60820B;
L_60820B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x820Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x820Bu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x820Bu, 4u, 3u, cpu.address("abs", 0x2143u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60820B STZ
    hw.write(cpu.address("abs", 0x2143u), 0, cpu.m8?8:16);
    goto L_60820E;
L_60820E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x820Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x820Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x820Eu, 4u, 3u, cpu.address("abs", 0x4210u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60820E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x4210u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_608211;
L_608211:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8211u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8211u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8211u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $608211 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x608211u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x608211u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_6B32CC_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x6B32CCu: goto L_6B32CC;
    case 0x6B32D0u: goto L_6B32D0;
    case 0x6B32D1u: goto L_6B32D1;
    case 0x6B32D2u: goto L_6B32D2;
    case 0x6B32D3u: goto L_6B32D3;
    case 0x6B32D6u: goto L_6B32D6;
    case 0x6B32D7u: goto L_6B32D7;
    case 0x6B32D8u: goto L_6B32D8;
    case 0x6B32D9u: goto L_6B32D9;
    case 0x6B32DAu: goto L_6B32DA;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_6B32CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x32CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x32CCu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x32CCu, 6u, 4u, ((0x571856u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6B32CC SBC
    cpu.sbc(hw.readW(((0x571856u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_6B32D0;
L_6B32D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x32D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x32D0u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x32D0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6B32D0 CLC
    cpu.setFlag('C', false);
    goto L_6B32D1;
L_6B32D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x32D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x32D1u,cpu,0x58u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x32D1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6B32D1 CLI
    cpu.setFlag('I', false);
    goto L_6B32D2;
L_6B32D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x32D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x32D2u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x32D2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6B32D2 CLC
    cpu.setFlag('C', false);
    goto L_6B32D3;
L_6B32D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x32D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x32D3u,cpu,0x59u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x32D3u, 5u + 1u, 3u, cpu.address("absy", 0xFF18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6B32D3 EOR
    cpu.logicXor(hw.readW(cpu.address("absy", 0xFF18u), cpu.m8?8:16));
    goto L_6B32D6;
L_6B32D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x32D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x32D6u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x32D6u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $6B32D6 PHY
    cpu.push("PHY", hw);
    goto L_6B32D7;
L_6B32D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x32D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x32D7u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x32D7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6B32D7 CLC
    cpu.setFlag('C', false);
    goto L_6B32D8;
L_6B32D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x32D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x32D8u,cpu,0x5Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x32D8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6B32D8 TCD
    cpu.tcd();
    goto L_6B32D9;
L_6B32D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x32D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x32D9u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x32D9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6B32D9 CLC
    cpu.setFlag('C', false);
    goto L_6B32DA;
L_6B32DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x32DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x32DAu,cpu,0x5Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x32DAu, 4u, 4u, 0x185D18u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6B32DA JML -> $185D18
    hw.requestDispatch(0x185D18u,0x6B32DAu); return;
}

void sub_8083CA_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8083CAu: goto L_8083CA;
    case 0x8083CEu: goto L_8083CE;
    case 0x8083D0u: goto L_8083D0;
    case 0x8083D3u: goto L_8083D3;
    case 0x8083D6u: goto L_8083D6;
    case 0x8083DAu: goto L_8083DA;
    case 0x8083DCu: goto L_8083DC;
    case 0x8083DFu: goto L_8083DF;
    case 0x8083E2u: goto L_8083E2;
    case 0x8083E4u: goto L_8083E4;
    case 0x808410u: goto L_808410;
    case 0x808412u: goto L_808412;
    case 0x808445u: goto L_808445;
    case 0x808449u: goto L_808449;
    case 0x80844Bu: goto L_80844B;
    case 0x80844Du: goto L_80844D;
    case 0x80844Eu: goto L_80844E;
    case 0x808451u: goto L_808451;
    case 0x808453u: goto L_808453;
    case 0x808456u: goto L_808456;
    case 0x808457u: goto L_808457;
    case 0x808458u: goto L_808458;
    case 0x80845Au: goto L_80845A;
    case 0x80845Bu: goto L_80845B;
    case 0x80845Cu: goto L_80845C;
    case 0x80845Eu: goto L_80845E;
    case 0x808462u: goto L_808462;
    case 0x808463u: goto L_808463;
    case 0x808465u: goto L_808465;
    case 0x808469u: goto L_808469;
    case 0x80846Au: goto L_80846A;
    case 0x80846Bu: goto L_80846B;
    case 0x80847Fu: goto L_80847F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8083CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83CAu,cpu,0x0Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83CAu, 5u, 4u, 0x148084u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083CA ORA
    cpu.logicOr(hw.readW(0x148084u, cpu.m8?8:16));
    goto L_8083CE;
L_8083CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83CEu,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83CEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x80u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083CE STY
    hw.write(cpu.address("dp", 0x80u), cpu.y, cpu.x8?8:16);
    goto L_8083D0;
L_8083D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83D0u,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83D0u, 4u + ((((0x8084u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x8084u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083D0 ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0x8084u), cpu.m8?8:16));
    goto L_8083D3;
L_8083D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83D3u,cpu,0x1Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83D3u, 7u, 3u, cpu.address("absx", 0x8084u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083D3 ASL
    cpu.aslMem(hw, cpu.address("absx", 0x8084u), cpu.m8?8:16);
    goto L_8083D6;
L_8083D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83D6u,cpu,0x1Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83D6u, 5u, 4u, ((0x208084u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083D6 ORA
    cpu.logicOr(hw.readW(((0x208084u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_8083DA;
L_8083DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83DAu,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83DAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x80u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083DA STY
    hw.write(cpu.address("dp", 0x80u), cpu.y, cpu.x8?8:16);
    goto L_8083DC;
L_8083DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83DCu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83DCu, 6u, 3u, cpu.address("abs", 0x8084u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8083DC JSR -> $808084 stack real
    { cpu.push16Value(hw,0x83DEu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x83DFu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8084u), 0x8083DCu); }
    goto L_8083DF;
L_8083DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83DFu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x83DFu,0x8083DFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83DFu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83DFu, 6u, 3u, cpu.address("abs", 0x8084u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8083DF JSR -> $808084 stack real
    { cpu.push16Value(hw,0x83E1u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x83E2u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8084u), 0x8083DFu); }
    goto L_8083E2;
L_8083E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83E2u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x83E2u,0x8083E2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83E2u,cpu,0x25u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83E2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x84u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083E2 AND
    cpu.logicAnd(hw.readW(cpu.address("dp", 0x84u), cpu.m8?8:16));
    goto L_8083E4;
L_8083E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83E4u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83E4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083E4 BRA -> $808410
    goto L_808410;
L_808410:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8410u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8410u,cpu,0x15u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8410u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xABu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808410 ORA
    cpu.logicOr(hw.readW(cpu.address("dpx", 0xABu), cpu.m8?8:16));
    goto L_808412;
L_808412:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8412u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8412u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8412u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808412 BRA -> $80847F
    goto L_80847F;
L_808445:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8445u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8445u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8445u, 8u, 4u, 0x80870Cu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808445 JSL -> $80870C stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8448u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8449u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80870Cu, 0x808445u); }
    goto L_808449;
L_808449:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8449u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8449u,0x808449u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8449u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8449u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x48u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808449 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x48u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80844B;
L_80844B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x844Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x844Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x844Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80844B AND
    cpu.logicAnd(0x7Fu);
    goto L_80844D;
L_80844D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x844Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x844Du,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x844Du, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80844D PHK
    cpu.push("PHK", hw);
    goto L_80844E;
L_80844E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x844Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x844Eu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x844Eu, 5u, 3u, cpu.address("abs", 0x846Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80844E PEA
    cpu.push16Value(hw, 0x846Bu);
    goto L_808451;
L_808451:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8451u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8451u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8451u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808451 REP
    cpu.rep(0x20u);
    goto L_808453;
L_808453:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8453u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8453u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8453u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808453 AND
    cpu.logicAnd(0xFFu);
    goto L_808456;
L_808456:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8456u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8456u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8456u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808456 PHA
    cpu.push("PHA", hw);
    goto L_808457;
L_808457:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8457u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8457u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8457u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808457 ASL
    cpu.aslA();
    goto L_808458;
L_808458:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8458u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8458u,cpu,0x63u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8458u, 5u, 2u, cpu.addressStack(0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808458 ADC
    cpu.adc(hw.readW(cpu.addressStack(0x1u), cpu.m8?8:16));
    goto L_80845A;
L_80845A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x845Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x845Au,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x845Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80845A TAX
    cpu.transfer("TAX");
    goto L_80845B;
L_80845B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x845Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x845Bu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x845Bu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80845B PLA
    cpu.pop("PLA", hw);
    goto L_80845C;
L_80845C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x845Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x845Cu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x845Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80845C SEP
    cpu.sep(0x20u);
    goto L_80845E;
L_80845E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x845Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x845Eu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x845Eu, 5u, 4u, ((0x808470u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80845E LDA
    cpu.loadA(hw.readW(((0x808470u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808462;
L_808462:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8462u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8462u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8462u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808462 PHA
    cpu.push("PHA", hw);
    goto L_808463;
L_808463:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8463u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8463u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8463u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808463 REP
    cpu.rep(0x20u);
    goto L_808465;
L_808465:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8465u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8465u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8465u, 6u, 4u, ((0x80846Eu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808465 LDA
    cpu.loadA(hw.readW(((0x80846Eu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808469;
L_808469:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8469u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8469u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8469u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808469 DEC
    cpu.decReg('A');
    goto L_80846A;
L_80846A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x846Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x846Au,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x846Au, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80846A PHA
    cpu.push("PHA", hw);
    goto L_80846B;
L_80846B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x846Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x846Bu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x846Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80846B RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80846Bu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80846Bu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80847F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x847Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x847Fu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x847Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80847F BRA -> $808445
    goto L_808445;
}

void sub_809472_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809472u: goto L_809472;
    case 0x809473u: goto L_809473;
    case 0x809475u: goto L_809475;
    case 0x809477u: goto L_809477;
    case 0x809479u: goto L_809479;
    case 0x80947Cu: goto L_80947C;
    case 0x80947Eu: goto L_80947E;
    case 0x809480u: goto L_809480;
    case 0x809481u: goto L_809481;
    case 0x809483u: goto L_809483;
    case 0x809485u: goto L_809485;
    case 0x809487u: goto L_809487;
    case 0x809489u: goto L_809489;
    case 0x80948Bu: goto L_80948B;
    case 0x80948Du: goto L_80948D;
    case 0x80948Fu: goto L_80948F;
    case 0x809491u: goto L_809491;
    case 0x809492u: goto L_809492;
    case 0x809494u: goto L_809494;
    case 0x809496u: goto L_809496;
    case 0x809498u: goto L_809498;
    case 0x80949Au: goto L_80949A;
    case 0x80949Cu: goto L_80949C;
    case 0x80949Du: goto L_80949D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809472:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9472u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9472u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9472u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809472 PHP
    cpu.push("PHP", hw);
    goto L_809473;
L_809473:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9473u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9473u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9473u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809473 STZ
    hw.write(cpu.address("dp", 0x3Au), 0, cpu.m8?8:16);
    goto L_809475;
L_809475:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9475u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9475u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9475u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809475 STZ
    hw.write(cpu.address("dp", 0x3Cu), 0, cpu.m8?8:16);
    goto L_809477;
L_809477:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9477u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9477u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9477u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809477 STZ
    hw.write(cpu.address("dp", 0x3Eu), 0, cpu.m8?8:16);
    goto L_809479;
L_809479:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9479u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9479u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9479u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809479 LDY
    cpu.setY(0xFu, 16);
    goto L_80947C;
L_80947C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x947Cu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x947Cu,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x947Cu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x38u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80947C LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x38u), cpu.m8?8:16);
    goto L_80947E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x947Cu,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x947Cu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x38u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80947C LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x38u), cpu.m8?8:16);
    goto L_80947E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x947Cu,0x80947Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80947E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x947Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x947Eu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x947Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80947E BCC -> $80948D
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80948D; }
    goto L_809480;
L_809480:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9480u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9480u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9480u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809480 CLC
    cpu.setFlag('C', false);
    goto L_809481;
L_809481:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9481u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9481u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9481u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809481 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x36u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809483;
L_809483:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9483u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9483u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9483u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809483 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x3Au), cpu.m8?8:16));
    goto L_809485;
L_809485:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9485u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9485u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9485u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809485 STA
    hw.write(cpu.address("dp", 0x3Au), cpu.a, cpu.m8?8:16);
    goto L_809487;
L_809487:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9487u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9487u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9487u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809487 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809489;
L_809489:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9489u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9489u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9489u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809489 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x3Cu), cpu.m8?8:16));
    goto L_80948B;
L_80948B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x948Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x948Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x948Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80948B STA
    hw.write(cpu.address("dp", 0x3Cu), cpu.a, cpu.m8?8:16);
    goto L_80948D;
L_80948D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x948Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x948Du,cpu,0x06u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x948Du, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80948D ASL
    cpu.aslMem(hw, cpu.address("dp", 0x36u), cpu.m8?8:16);
    goto L_80948F;
L_80948F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x948Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x948Fu,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x948Fu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Eu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80948F ROL
    cpu.rolMem(hw, cpu.address("dp", 0x3Eu), cpu.m8?8:16);
    goto L_809491;
L_809491:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9491u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9491u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9491u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809491 DEY
    cpu.decReg('Y');
    goto L_809492;
L_809492:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9492u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9492u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9492u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809492 BPL -> $80947C
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80947C; }
    goto L_809494;
L_809494:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9494u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9494u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9494u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809494 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809496;
L_809496:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9496u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9496u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9496u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809496 STA
    hw.write(cpu.address("dp", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_809498;
L_809498:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9498u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9498u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9498u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809498 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80949A;
L_80949A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x949Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x949Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x949Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x38u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80949A STA
    hw.write(cpu.address("dp", 0x38u), cpu.a, cpu.m8?8:16);
    goto L_80949C;
L_80949C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x949Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x949Cu,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x949Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80949C PLP
    cpu.pop("PLP", hw);
    goto L_80949D;
L_80949D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x949Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x949Du,0x80949Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x949Du,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x949Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80949D RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80949Du);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80949Du,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_809472_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809472u: goto L_809472;
    case 0x809473u: goto L_809473;
    case 0x809475u: goto L_809475;
    case 0x809477u: goto L_809477;
    case 0x809479u: goto L_809479;
    case 0x80947Cu: goto L_80947C;
    case 0x80947Eu: goto L_80947E;
    case 0x809480u: goto L_809480;
    case 0x809481u: goto L_809481;
    case 0x809483u: goto L_809483;
    case 0x809485u: goto L_809485;
    case 0x809487u: goto L_809487;
    case 0x809489u: goto L_809489;
    case 0x80948Bu: goto L_80948B;
    case 0x80948Du: goto L_80948D;
    case 0x80948Fu: goto L_80948F;
    case 0x809491u: goto L_809491;
    case 0x809492u: goto L_809492;
    case 0x809494u: goto L_809494;
    case 0x809496u: goto L_809496;
    case 0x809498u: goto L_809498;
    case 0x80949Au: goto L_80949A;
    case 0x80949Cu: goto L_80949C;
    case 0x80949Du: goto L_80949D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809472:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9472u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9472u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9472u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809472 PHP
    cpu.push("PHP", hw);
    goto L_809473;
L_809473:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9473u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9473u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9473u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809473 STZ
    hw.write(cpu.address("dp", 0x3Au), 0, cpu.m8?8:16);
    goto L_809475;
L_809475:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9475u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9475u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9475u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809475 STZ
    hw.write(cpu.address("dp", 0x3Cu), 0, cpu.m8?8:16);
    goto L_809477;
L_809477:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9477u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9477u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9477u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809477 STZ
    hw.write(cpu.address("dp", 0x3Eu), 0, cpu.m8?8:16);
    goto L_809479;
L_809479:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9479u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9479u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9479u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809479 LDY
    cpu.setY(0xFu, 16);
    goto L_80947C;
L_80947C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x947Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x947Cu,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x947Cu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x38u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80947C LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x38u), cpu.m8?8:16);
    goto L_80947E;
L_80947E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x947Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x947Eu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x947Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80947E BCC -> $80948D
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80948D; }
    goto L_809480;
L_809480:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9480u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9480u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9480u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809480 CLC
    cpu.setFlag('C', false);
    goto L_809481;
L_809481:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9481u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9481u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9481u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809481 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x36u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809483;
L_809483:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9483u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9483u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9483u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809483 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x3Au), cpu.m8?8:16));
    goto L_809485;
L_809485:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9485u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9485u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9485u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809485 STA
    hw.write(cpu.address("dp", 0x3Au), cpu.a, cpu.m8?8:16);
    goto L_809487;
L_809487:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9487u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9487u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9487u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809487 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809489;
L_809489:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9489u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9489u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9489u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809489 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x3Cu), cpu.m8?8:16));
    goto L_80948B;
L_80948B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x948Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x948Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x948Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80948B STA
    hw.write(cpu.address("dp", 0x3Cu), cpu.a, cpu.m8?8:16);
    goto L_80948D;
L_80948D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x948Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x948Du,cpu,0x06u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x948Du, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80948D ASL
    cpu.aslMem(hw, cpu.address("dp", 0x36u), cpu.m8?8:16);
    goto L_80948F;
L_80948F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x948Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x948Fu,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x948Fu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Eu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80948F ROL
    cpu.rolMem(hw, cpu.address("dp", 0x3Eu), cpu.m8?8:16);
    goto L_809491;
L_809491:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9491u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9491u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9491u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809491 DEY
    cpu.decReg('Y');
    goto L_809492;
L_809492:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9492u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9492u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9492u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809492 BPL -> $80947C
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80947C; }
    goto L_809494;
L_809494:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9494u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9494u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9494u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809494 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809496;
L_809496:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9496u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9496u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9496u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809496 STA
    hw.write(cpu.address("dp", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_809498;
L_809498:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9498u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9498u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9498u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809498 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80949A;
L_80949A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x949Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x949Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x949Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x38u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80949A STA
    hw.write(cpu.address("dp", 0x38u), cpu.a, cpu.m8?8:16);
    goto L_80949C;
L_80949C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x949Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x949Cu,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x949Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80949C PLP
    cpu.pop("PLP", hw);
    goto L_80949D;
L_80949D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x949Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x949Du,0x80949Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x949Du,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x949Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80949D RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80949Du);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80949Du,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_8096A3_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8096A3u: goto L_8096A3;
    case 0x8096A5u: goto L_8096A5;
    case 0x8096A7u: goto L_8096A7;
    case 0x8096A8u: goto L_8096A8;
    case 0x8096AAu: goto L_8096AA;
    case 0x8096ACu: goto L_8096AC;
    case 0x8096AEu: goto L_8096AE;
    case 0x8096AFu: goto L_8096AF;
    case 0x8096B0u: goto L_8096B0;
    case 0x8096B1u: goto L_8096B1;
    case 0x8096B3u: goto L_8096B3;
    case 0x8096B5u: goto L_8096B5;
    case 0x8096B7u: goto L_8096B7;
    case 0x8096B9u: goto L_8096B9;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8096A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96A3u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96A3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096A3 SEP
    cpu.sep(0x20u);
    goto L_8096A5;
L_8096A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96A5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96A5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096A5 LDA
    cpu.setA(0xB3u, 8);
    goto L_8096A7;
L_8096A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96A7u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96A7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096A7 CLC
    cpu.setFlag('C', false);
    goto L_8096A8;
L_8096A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96A8u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96A8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x51u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096A8 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x51u), cpu.m8?8:16));
    goto L_8096AA;
L_8096AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96AAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96AAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x51u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096AA STA
    hw.write(cpu.address("dp", 0x51u), cpu.a, cpu.m8?8:16);
    goto L_8096AC;
L_8096AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96ACu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96ACu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x52u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096AC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x52u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8096AE;
L_8096AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96AEu,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96AEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096AE ROL
    cpu.rolA();
    goto L_8096AF;
L_8096AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96AFu,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96AFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096AF ROL
    cpu.rolA();
    goto L_8096B0;
L_8096B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B0u,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096B0 ROL
    cpu.rolA();
    goto L_8096B1;
L_8096B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B1u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096B1 EOR
    cpu.logicXor(0xFFu);
    goto L_8096B3;
L_8096B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B3u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x51u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096B3 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x51u), cpu.m8?8:16));
    goto L_8096B5;
L_8096B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x52u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096B5 STA
    hw.write(cpu.address("dp", 0x52u), cpu.a, cpu.m8?8:16);
    goto L_8096B7;
L_8096B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B7u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096B7 REP
    cpu.rep(0x20u);
    goto L_8096B9;
L_8096B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B9u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8096B9 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8096B9u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8096B9u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_8096A3_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8096A3u: goto L_8096A3;
    case 0x8096A5u: goto L_8096A5;
    case 0x8096A7u: goto L_8096A7;
    case 0x8096A8u: goto L_8096A8;
    case 0x8096AAu: goto L_8096AA;
    case 0x8096ACu: goto L_8096AC;
    case 0x8096AEu: goto L_8096AE;
    case 0x8096AFu: goto L_8096AF;
    case 0x8096B0u: goto L_8096B0;
    case 0x8096B1u: goto L_8096B1;
    case 0x8096B3u: goto L_8096B3;
    case 0x8096B5u: goto L_8096B5;
    case 0x8096B7u: goto L_8096B7;
    case 0x8096B9u: goto L_8096B9;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8096A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96A3u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96A3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096A3 SEP
    cpu.sep(0x20u);
    goto L_8096A5;
L_8096A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96A5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96A5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096A5 LDA
    cpu.setA(0xB3u, 8);
    goto L_8096A7;
L_8096A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96A7u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96A7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096A7 CLC
    cpu.setFlag('C', false);
    goto L_8096A8;
L_8096A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96A8u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96A8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x51u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096A8 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x51u), cpu.m8?8:16));
    goto L_8096AA;
L_8096AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96AAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96AAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x51u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096AA STA
    hw.write(cpu.address("dp", 0x51u), cpu.a, cpu.m8?8:16);
    goto L_8096AC;
L_8096AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96ACu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96ACu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x52u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096AC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x52u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8096AE;
L_8096AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96AEu,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96AEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096AE ROL
    cpu.rolA();
    goto L_8096AF;
L_8096AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96AFu,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96AFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096AF ROL
    cpu.rolA();
    goto L_8096B0;
L_8096B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B0u,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096B0 ROL
    cpu.rolA();
    goto L_8096B1;
L_8096B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B1u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096B1 EOR
    cpu.logicXor(0xFFu);
    goto L_8096B3;
L_8096B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B3u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x51u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096B3 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x51u), cpu.m8?8:16));
    goto L_8096B5;
L_8096B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x52u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096B5 STA
    hw.write(cpu.address("dp", 0x52u), cpu.a, cpu.m8?8:16);
    goto L_8096B7;
L_8096B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B7u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096B7 REP
    cpu.rep(0x20u);
    goto L_8096B9;
L_8096B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B9u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8096B9 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8096B9u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8096B9u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80B02B_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B02Bu: goto L_80B02B;
    case 0x80B02Eu: goto L_80B02E;
    case 0x80B030u: goto L_80B030;
    case 0x80B033u: goto L_80B033;
    case 0x80B036u: goto L_80B036;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B02B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB02Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB02Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB02Bu, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B02B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x958u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B02E;
L_80B02E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB02Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB02Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB02Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B02E BEQ -> $80B033
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B033; }
    goto L_80B030;
L_80B030:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB030u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB030u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB030u, 6u, 3u, cpu.address("abs", 0xC404u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B030 JSR -> $80C404 stack real
    { cpu.push16Value(hw,0xB032u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB033u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC404u), 0x80B030u); }
    goto L_80B033;
L_80B033:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB033u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB033u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB033u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B033 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B036;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB033u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB033u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B033 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B036;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB033u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB033u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B033 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B036;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB033u,0x80B033u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B036:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB036u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB036u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB036u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B036 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B036u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B036u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB036u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB036u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B036 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B036u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B036u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB036u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB036u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B036 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B036u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B036u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB036u,0x80B036u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80B037_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B037u: goto L_80B037;
    case 0x80B03Au: goto L_80B03A;
    case 0x80B03Cu: goto L_80B03C;
    case 0x80B03Fu: goto L_80B03F;
    case 0x80B042u: goto L_80B042;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B037:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB037u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB037u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB037u, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B037 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x958u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B03A;
L_80B03A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB03Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB03Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB03Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B03A BEQ -> $80B03F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B03F; }
    goto L_80B03C;
L_80B03C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB03Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB03Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB03Cu, 6u, 3u, cpu.address("abs", 0xC89Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B03C JSR -> $80C89D stack real
    { cpu.push16Value(hw,0xB03Eu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB03Fu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC89Du), 0x80B03Cu); }
    goto L_80B03F;
L_80B03F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB03Fu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB03Fu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB03Fu, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B03F INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B042;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB03Fu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB03Fu, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B03F INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B042;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB03Fu,0x80B03Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B042:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB042u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB042u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB042u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B042 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B042u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B042u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB042u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB042u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B042 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B042u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B042u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB042u,0x80B042u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80B3FB_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B3FBu: goto L_80B3FB;
    case 0x80B3FEu: goto L_80B3FE;
    case 0x80B401u: goto L_80B401;
    case 0x80B404u: goto L_80B404;
    case 0x80B407u: goto L_80B407;
    case 0x80B409u: goto L_80B409;
    case 0x80B40Au: goto L_80B40A;
    case 0x80B40Bu: goto L_80B40B;
    case 0x80B40Cu: goto L_80B40C;
    case 0x80B40Du: goto L_80B40D;
    case 0x80B410u: goto L_80B410;
    case 0x80B411u: goto L_80B411;
    case 0x80B412u: goto L_80B412;
    case 0x80B413u: goto L_80B413;
    case 0x80B414u: goto L_80B414;
    case 0x80B416u: goto L_80B416;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B3FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3FBu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3FBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B3FB LDX
    cpu.setX(0x4u, 16);
    goto L_80B3FE;
L_80B3FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3FEu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3FEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B3FE LDY
    cpu.setY(0x0u, 16);
    goto L_80B401;
L_80B401:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB401u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB401u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB401u, 5u + 1u, 3u, cpu.address("absx", 0x090Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B401 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x90Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B404;
L_80B404:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB404u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB404u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB404u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B404 CMP
    cpu.compareA(0x2u);
    goto L_80B407;
L_80B407:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB407u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB407u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB407u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B407 BCC -> $80B412
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B412; }
    goto L_80B409;
L_80B409:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB409u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB409u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB409u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B409 TXA
    cpu.transfer("TXA");
    goto L_80B40A;
L_80B40A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB40Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB40Au,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB40Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B40A LSR
    cpu.lsrA();
    goto L_80B40B;
L_80B40B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB40Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB40Bu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB40Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B40B INC
    cpu.inc('A');
    goto L_80B40C;
L_80B40C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB40Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB40Cu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB40Cu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B40C XBA
    cpu.xba();
    goto L_80B40D;
L_80B40D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB40Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB40Du,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB40Du, 6u, 3u, cpu.address("absy", 0x0914u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B40D STA
    hw.write(cpu.address("absy", 0x914u), cpu.a, cpu.m8?8:16);
    goto L_80B410;
L_80B410:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB410u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB410u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB410u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B410 INY
    cpu.inc('Y');
    goto L_80B411;
L_80B411:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB411u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB411u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB411u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B411 INY
    cpu.inc('Y');
    goto L_80B412;
L_80B412:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB412u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB412u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB412u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B412 DEX
    cpu.decReg('X');
    goto L_80B413;
L_80B413:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB413u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB413u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB413u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B413 DEX
    cpu.decReg('X');
    goto L_80B414;
L_80B414:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB414u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB414u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB414u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B414 BPL -> $80B401
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80B401; }
    goto L_80B416;
L_80B416:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB416u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB416u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB416u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B416 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B416u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B416u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80D3BB_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80D3BBu: goto L_80D3BB;
    case 0x80D3BCu: goto L_80D3BC;
    case 0x80D3BDu: goto L_80D3BD;
    case 0x80D3BEu: goto L_80D3BE;
    case 0x80D3C0u: goto L_80D3C0;
    case 0x80D3C2u: goto L_80D3C2;
    case 0x80D3C5u: goto L_80D3C5;
    case 0x80D3C7u: goto L_80D3C7;
    case 0x80D3CBu: goto L_80D3CB;
    case 0x80D3CEu: goto L_80D3CE;
    case 0x80D3D0u: goto L_80D3D0;
    case 0x80D3D3u: goto L_80D3D3;
    case 0x80D3D5u: goto L_80D3D5;
    case 0x80D3D9u: goto L_80D3D9;
    case 0x80D3DBu: goto L_80D3DB;
    case 0x80D3DFu: goto L_80D3DF;
    case 0x80D3E1u: goto L_80D3E1;
    case 0x80D3E5u: goto L_80D3E5;
    case 0x80D3E7u: goto L_80D3E7;
    case 0x80D3E9u: goto L_80D3E9;
    case 0x80D3EBu: goto L_80D3EB;
    case 0x80D3EDu: goto L_80D3ED;
    case 0x80D3EFu: goto L_80D3EF;
    case 0x80D3F1u: goto L_80D3F1;
    case 0x80D3F3u: goto L_80D3F3;
    case 0x80D3F5u: goto L_80D3F5;
    case 0x80D3F7u: goto L_80D3F7;
    case 0x80D3F9u: goto L_80D3F9;
    case 0x80D3FCu: goto L_80D3FC;
    case 0x80D3FEu: goto L_80D3FE;
    case 0x80D400u: goto L_80D400;
    case 0x80D402u: goto L_80D402;
    case 0x80D404u: goto L_80D404;
    case 0x80D406u: goto L_80D406;
    case 0x80D409u: goto L_80D409;
    case 0x80D40Bu: goto L_80D40B;
    case 0x80D40Cu: goto L_80D40C;
    case 0x80D40Du: goto L_80D40D;
    case 0x80D40Fu: goto L_80D40F;
    case 0x80D410u: goto L_80D410;
    case 0x80D413u: goto L_80D413;
    case 0x80D415u: goto L_80D415;
    case 0x80D417u: goto L_80D417;
    case 0x80D418u: goto L_80D418;
    case 0x80D419u: goto L_80D419;
    case 0x80D41Bu: goto L_80D41B;
    case 0x80D41Cu: goto L_80D41C;
    case 0x80D41Fu: goto L_80D41F;
    case 0x80D421u: goto L_80D421;
    case 0x80D423u: goto L_80D423;
    case 0x80D424u: goto L_80D424;
    case 0x80D425u: goto L_80D425;
    case 0x80D427u: goto L_80D427;
    case 0x80D42Au: goto L_80D42A;
    case 0x80D42Bu: goto L_80D42B;
    case 0x80D42Cu: goto L_80D42C;
    case 0x80D42Eu: goto L_80D42E;
    case 0x80D431u: goto L_80D431;
    case 0x80D434u: goto L_80D434;
    case 0x80D435u: goto L_80D435;
    case 0x80D437u: goto L_80D437;
    case 0x80D43Au: goto L_80D43A;
    case 0x80D43Bu: goto L_80D43B;
    case 0x80D43Cu: goto L_80D43C;
    case 0x80D43Du: goto L_80D43D;
    case 0x80D43Eu: goto L_80D43E;
    case 0x80D440u: goto L_80D440;
    case 0x80D442u: goto L_80D442;
    case 0x80D444u: goto L_80D444;
    case 0x80D447u: goto L_80D447;
    case 0x80D44Au: goto L_80D44A;
    case 0x80D44Cu: goto L_80D44C;
    case 0x80D44Eu: goto L_80D44E;
    case 0x80D44Fu: goto L_80D44F;
    case 0x80D452u: goto L_80D452;
    case 0x80D454u: goto L_80D454;
    case 0x80D456u: goto L_80D456;
    case 0x80D459u: goto L_80D459;
    case 0x80D45Cu: goto L_80D45C;
    case 0x80D45Du: goto L_80D45D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80D3BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3BBu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3BBu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80D3BB PHB
    cpu.push("PHB", hw);
    goto L_80D3BC;
L_80D3BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3BCu,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3BCu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80D3BC PHK
    cpu.push("PHK", hw);
    goto L_80D3BD;
L_80D3BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3BDu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3BDu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80D3BD PLB
    cpu.pop("PLB", hw);
    goto L_80D3BE;
L_80D3BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3BEu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3BEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D3BE STZ
    hw.write(cpu.address("dp", 0x61u), 0, cpu.m8?8:16);
    goto L_80D3C0;
L_80D3C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3C0u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3C0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D3C0 STZ
    hw.write(cpu.address("dp", 0x63u), 0, cpu.m8?8:16);
    goto L_80D3C2;
L_80D3C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3C2u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3C2u, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D3C2 STZ
    hw.write(cpu.address("abs", 0x958u), 0, cpu.m8?8:16);
    goto L_80D3C5;
L_80D3C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3C5u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3C5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D3C5 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80D3C7;
L_80D3C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3C7u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3C7u, 6u, 4u, ((0x7E2440u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D3C7 LDA
    cpu.loadA(hw.readW(((0x7E2440u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D3CB;
L_80D3CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3CBu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3CBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D3CB CMP
    cpu.compareA(0xFFFFu);
    goto L_80D3CE;
L_80D3CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3CEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3CEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D3CE BNE -> $80D3D3
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D3D3; }
    goto L_80D3D0;
L_80D3D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3D0u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3D0u, 3u, 3u, cpu.address("abs", 0xD456u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D3D0 JMP -> $80D456
    goto L_80D456;
L_80D3D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3D3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3D3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D3D3 STA
    hw.write(cpu.address("dp", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_80D3D5;
L_80D3D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3D5u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3D5u, 6u, 4u, ((0x7E2442u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D3D5 LDA
    cpu.loadA(hw.readW(((0x7E2442u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D3D9;
L_80D3D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3D9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3D9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D3D9 STA
    hw.write(cpu.address("dp", 0x16u), cpu.a, cpu.m8?8:16);
    goto L_80D3DB;
L_80D3DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3DBu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3DBu, 6u, 4u, ((0x7E2444u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D3DB LDA
    cpu.loadA(hw.readW(((0x7E2444u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D3DF;
L_80D3DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3DFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3DFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D3DF STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_80D3E1;
L_80D3E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3E1u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3E1u, 6u, 4u, ((0x7E2446u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D3E1 LDA
    cpu.loadA(hw.readW(((0x7E2446u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D3E5;
L_80D3E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3E5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3E5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D3E5 STA
    hw.write(cpu.address("dp", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_80D3E7;
L_80D3E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3E7u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3E7u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D3E7 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D3E9;
L_80D3E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3E9u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3E9u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D3E9 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D3EB;
L_80D3EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3EBu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3EBu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D3EB INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D3ED;
L_80D3ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3EDu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3EDu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D3ED INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D3EF;
L_80D3EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3EFu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3EFu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D3EF INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D3F1;
L_80D3F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3F1u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3F1u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D3F1 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D3F3;
L_80D3F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3F3u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3F3u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D3F3 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D3F5;
L_80D3F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3F5u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3F5u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D3F5 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D3F7;
L_80D3F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3F7u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3F7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D3F7 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x10u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80D3F9;
L_80D3F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3F9u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3F9u, 5u + 1u, 3u, cpu.address("absx", 0xEE54u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D3F9 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xEE54u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D3FC;
L_80D3FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3FCu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3FCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D3FC STA
    hw.write(cpu.address("dp", 0x20u), cpu.a, cpu.m8?8:16);
    goto L_80D3FE;
L_80D3FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3FEu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3FEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x65u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D3FE STZ
    hw.write(cpu.address("dp", 0x65u), 0, cpu.m8?8:16);
    goto L_80D400;
L_80D400:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD400u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD400u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD400u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x65u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D400 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x65u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80D402;
L_80D402:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD402u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD402u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD402u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x20u) & 0xFFFFu), 2u, 0u);
    // $80D402 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x20u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D404;
L_80D404:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD404u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD404u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD404u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D404 BMI -> $80D3C2
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_80D3C2; }
    goto L_80D406;
L_80D406:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD406u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD406u,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD406u, 5u, 3u, cpu.address("abs", 0x0904u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D406 CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x904u), cpu.m8?8:16));
    goto L_80D409;
L_80D409:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD409u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD409u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD409u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D409 BNE -> $80D44C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D44C; }
    goto L_80D40B;
L_80D40B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD40Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD40Bu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD40Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D40B INY
    cpu.inc('Y');
    goto L_80D40C;
L_80D40C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD40Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD40Cu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD40Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D40C INY
    cpu.inc('Y');
    goto L_80D40D;
L_80D40D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD40Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD40Du,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD40Du, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x20u) & 0xFFFFu), 2u, 0u);
    // $80D40D LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x20u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D40F;
L_80D40F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD40Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD40Fu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD40Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D40F TAX
    cpu.transfer("TAX");
    goto L_80D410;
L_80D410:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD410u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD410u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD410u, 5u + 1u, 3u, cpu.address("absx", 0x0906u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D410 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x906u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D413;
L_80D413:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD413u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD413u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD413u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D413 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x12u), cpu.m8?8:16));
    goto L_80D415;
L_80D415:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD415u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD415u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD415u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D415 BNE -> $80D44C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D44C; }
    goto L_80D417;
L_80D417:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD417u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD417u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD417u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D417 INY
    cpu.inc('Y');
    goto L_80D418;
L_80D418:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD418u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD418u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD418u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D418 INY
    cpu.inc('Y');
    goto L_80D419;
L_80D419:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD419u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD419u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD419u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x20u) & 0xFFFFu), 2u, 0u);
    // $80D419 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x20u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D41B;
L_80D41B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD41Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD41Bu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD41Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D41B TAX
    cpu.transfer("TAX");
    goto L_80D41C;
L_80D41C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD41Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD41Cu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD41Cu, 5u + 1u, 3u, cpu.address("absx", 0x0906u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D41C LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x906u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D41F;
L_80D41F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD41Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD41Fu,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD41Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D41F CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x12u), cpu.m8?8:16));
    goto L_80D421;
L_80D421:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD421u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD421u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD421u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D421 BNE -> $80D44C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D44C; }
    goto L_80D423;
L_80D423:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD423u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD423u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD423u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D423 INY
    cpu.inc('Y');
    goto L_80D424;
L_80D424:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD424u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD424u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD424u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D424 INY
    cpu.inc('Y');
    goto L_80D425;
L_80D425:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD425u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD425u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD425u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x20u) & 0xFFFFu), 2u, 0u);
    // $80D425 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x20u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D427;
L_80D427:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD427u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD427u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD427u, 5u, 3u, cpu.address("abs", 0x0926u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D427 STA
    hw.write(cpu.address("abs", 0x926u), cpu.a, cpu.m8?8:16);
    goto L_80D42A;
L_80D42A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD42Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD42Au,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD42Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D42A INY
    cpu.inc('Y');
    goto L_80D42B;
L_80D42B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD42Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD42Bu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD42Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D42B INY
    cpu.inc('Y');
    goto L_80D42C;
L_80D42C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD42Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD42Cu,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD42Cu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x20u) & 0xFFFFu), 2u, 0u);
    // $80D42C LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x20u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D42E;
L_80D42E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD42Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD42Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD42Eu, 5u, 3u, cpu.address("abs", 0x091Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D42E STA
    hw.write(cpu.address("abs", 0x91Eu), cpu.a, cpu.m8?8:16);
    goto L_80D431;
L_80D431:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD431u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD431u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD431u, 5u, 3u, cpu.address("abs", 0x0926u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D431 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x926u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D434;
L_80D434:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD434u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD434u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD434u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D434 ASL
    cpu.aslA();
    goto L_80D435;
L_80D435:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD435u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD435u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD435u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D435 STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_80D437;
L_80D437:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD437u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD437u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD437u, 5u, 3u, cpu.address("abs", 0x0904u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D437 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x904u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D43A;
L_80D43A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD43Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD43Au,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD43Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D43A ASL
    cpu.aslA();
    goto L_80D43B;
L_80D43B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD43Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD43Bu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD43Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D43B ASL
    cpu.aslA();
    goto L_80D43C;
L_80D43C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD43Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD43Cu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD43Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D43C ASL
    cpu.aslA();
    goto L_80D43D;
L_80D43D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD43Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD43Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD43Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D43D CLC
    cpu.setFlag('C', false);
    goto L_80D43E;
L_80D43E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD43Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD43Eu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD43Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D43E ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16));
    goto L_80D440;
L_80D440:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD440u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD440u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD440u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D440 STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_80D442;
L_80D442:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD442u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD442u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD442u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D442 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D444;
L_80D444:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD444u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD444u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD444u, 5u, 3u, cpu.address("abs", 0x0918u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D444 STA
    hw.write(cpu.address("abs", 0x918u), cpu.a, cpu.m8?8:16);
    goto L_80D447;
L_80D447:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD447u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD447u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD447u, 6u, 3u, cpu.address("abs", 0xBECBu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D447 JSR -> $80BECB stack real
    { cpu.push16Value(hw,0xD449u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD44Au,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBECBu), 0x80D447u); }
    goto L_80D44A;
L_80D44A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD44Au))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD44Au,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD44Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D44A BCC -> $80D45C
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80D45C; }
    goto L_80D44C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD44Au,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD44Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D44A BCC -> $80D45C
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80D45C; }
    goto L_80D44C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD44Au,0x80D44Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D44C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD44Cu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD44Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD44Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x65u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D44C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x65u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D44E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD44Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD44Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x65u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D44C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x65u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D44E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD44Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD44Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x65u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D44C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x65u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D44E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD44Cu,0x80D44Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D44E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD44Eu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD44Eu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD44Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D44E CLC
    cpu.setFlag('C', false);
    goto L_80D44F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD44Eu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD44Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D44E CLC
    cpu.setFlag('C', false);
    goto L_80D44F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD44Eu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD44Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D44E CLC
    cpu.setFlag('C', false);
    goto L_80D44F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD44Eu,0x80D44Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D44F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD44Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD44Fu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD44Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D44F ADC
    cpu.adc(0xAu);
    goto L_80D452;
L_80D452:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD452u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD452u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD452u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x65u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D452 STA
    hw.write(cpu.address("dp", 0x65u), cpu.a, cpu.m8?8:16);
    goto L_80D454;
L_80D454:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD454u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD454u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD454u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D454 BRA -> $80D400
    goto L_80D400;
L_80D456:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD456u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD456u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD456u, 8u, 3u, cpu.address("abs", 0x0958u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D456 INC
    cpu.incMem(hw, cpu.address("abs", 0x958u), cpu.m8?8:16);
    goto L_80D459;
L_80D459:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD459u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD459u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD459u, 5u, 3u, cpu.address("abs", 0x0926u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D459 STZ
    hw.write(cpu.address("abs", 0x926u), 0, cpu.m8?8:16);
    goto L_80D45C;
L_80D45C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD45Cu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD45Cu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD45Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80D45C PLB
    cpu.pop("PLB", hw);
    goto L_80D45D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD45Cu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD45Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80D45C PLB
    cpu.pop("PLB", hw);
    goto L_80D45D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD45Cu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD45Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80D45C PLB
    cpu.pop("PLB", hw);
    goto L_80D45D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD45Cu,0x80D45Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D45D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD45Du))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD45Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD45Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D45D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80D45Du);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80D45Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD45Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD45Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D45D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80D45Du);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80D45Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD45Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD45Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D45D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80D45Du);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80D45Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD45Du,0x80D45Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_829355_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x829355u: goto L_829355;
    case 0x829358u: goto L_829358;
    case 0x82935Au: goto L_82935A;
    case 0x82935Cu: goto L_82935C;
    case 0x82935Eu: goto L_82935E;
    case 0x829360u: goto L_829360;
    case 0x829362u: goto L_829362;
    case 0x829363u: goto L_829363;
    case 0x829365u: goto L_829365;
    case 0x829369u: goto L_829369;
    case 0x82936Bu: goto L_82936B;
    case 0x82936Cu: goto L_82936C;
    case 0x82936Fu: goto L_82936F;
    case 0x829372u: goto L_829372;
    case 0x829375u: goto L_829375;
    case 0x829376u: goto L_829376;
    case 0x829377u: goto L_829377;
    case 0x82937Au: goto L_82937A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_829355:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9355u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9355u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9355u, 5u, 3u, cpu.address("abs", 0x0193u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829355 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x193u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829358;
L_829358:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9358u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9358u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9358u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829358 BEQ -> $82936C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82936C; }
    goto L_82935A;
L_82935A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x935Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x935Au,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x935Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82935A SEP
    cpu.sep(0x20u);
    goto L_82935C;
L_82935C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x935Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x935Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x935Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82935C LDA
    cpu.setA(0xCu, 8);
    goto L_82935E;
L_82935E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x935Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x935Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x935Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82935E STA
    hw.write(cpu.address("dp", 0x49u), cpu.a, cpu.m8?8:16);
    goto L_829360;
L_829360:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9360u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9360u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9360u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829360 LDA
    cpu.setA(0x81u, 8);
    goto L_829362;
L_829362:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9362u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9362u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9362u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829362 XBA
    cpu.xba();
    goto L_829363;
L_829363:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9363u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9363u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9363u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829363 LDA
    cpu.setA(0xFu, 8);
    goto L_829365;
L_829365:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9365u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9365u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9365u, 8u, 4u, 0x8086F4u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829365 JSL -> $8086F4 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9368u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9369u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8086F4u, 0x829365u); }
    goto L_829369;
L_829369:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9369u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9369u,0x829369u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9369u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9369u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829369 REP
    cpu.rep(0x20u);
    goto L_82936B;
L_82936B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x936Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x936Bu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x936Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82936B RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82936Bu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82936Bu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82936C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x936Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x936Cu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x936Cu, 8u, 3u, cpu.address("abs", 0x014Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82936C INC
    cpu.incMem(hw, cpu.address("abs", 0x14Au), cpu.m8?8:16);
    goto L_82936F;
L_82936F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x936Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x936Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x936Fu, 5u, 3u, cpu.address("abs", 0x017Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82936F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x17Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829372;
L_829372:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9372u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9372u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9372u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829372 AND
    cpu.logicAnd(0xFFu);
    goto L_829375;
L_829375:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9375u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9375u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9375u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829375 ASL
    cpu.aslA();
    goto L_829376;
L_829376:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9376u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9376u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9376u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829376 TAX
    cpu.transfer("TAX");
    goto L_829377;
L_829377:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9377u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9377u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9377u, 5u, 3u, cpu.address("abs", 0x937Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829377 PEA
    cpu.push16Value(hw, 0x937Cu);
    goto L_82937A;
L_82937A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x937Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x937Au,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x937Au, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x9386u + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $82937A JMP (9386,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x9386u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x82937Au); return; }
}

void sub_8297A3_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8297A3u: goto L_8297A3;
    case 0x8297A6u: goto L_8297A6;
    case 0x8297A8u: goto L_8297A8;
    case 0x8297A9u: goto L_8297A9;
    case 0x8297ACu: goto L_8297AC;
    case 0x8297AEu: goto L_8297AE;
    case 0x8297AFu: goto L_8297AF;
    case 0x8297B2u: goto L_8297B2;
    case 0x8297B4u: goto L_8297B4;
    case 0x8297B6u: goto L_8297B6;
    case 0x8297B9u: goto L_8297B9;
    case 0x8297BBu: goto L_8297BB;
    case 0x8297BEu: goto L_8297BE;
    case 0x8297C0u: goto L_8297C0;
    case 0x8297C3u: goto L_8297C3;
    case 0x8297C5u: goto L_8297C5;
    case 0x8297C8u: goto L_8297C8;
    case 0x8297CAu: goto L_8297CA;
    case 0x8297CDu: goto L_8297CD;
    case 0x8297CFu: goto L_8297CF;
    case 0x8297D1u: goto L_8297D1;
    case 0x8297D4u: goto L_8297D4;
    case 0x8297D6u: goto L_8297D6;
    case 0x8297D8u: goto L_8297D8;
    case 0x8297DAu: goto L_8297DA;
    case 0x8297DDu: goto L_8297DD;
    case 0x8297DEu: goto L_8297DE;
    case 0x8297DFu: goto L_8297DF;
    case 0x8297E0u: goto L_8297E0;
    case 0x8297E1u: goto L_8297E1;
    case 0x8297E2u: goto L_8297E2;
    case 0x8297E3u: goto L_8297E3;
    case 0x8297E4u: goto L_8297E4;
    case 0x8297E5u: goto L_8297E5;
    case 0x8297E7u: goto L_8297E7;
    case 0x8297E9u: goto L_8297E9;
    case 0x8297EBu: goto L_8297EB;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8297A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97A3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97A3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8297A3 LDA
    cpu.setA(0x12u, 16);
    goto L_8297A6;
L_8297A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97A6u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97A6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8297A6 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x5Bu), cpu.m8?8:16));
    goto L_8297A8;
L_8297A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97A8u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97A8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8297A8 TAX
    cpu.transfer("TAX");
    goto L_8297A9;
L_8297A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97A9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97A9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8297A9 LDA
    cpu.setA(0x6u, 16);
    goto L_8297AC;
L_8297AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97ACu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97ACu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8297AC ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x5Bu), cpu.m8?8:16));
    goto L_8297AE;
L_8297AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97AEu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97AEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8297AE TAY
    cpu.transfer("TAY");
    goto L_8297AF;
L_8297AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97AFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97AFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8297AF LDA
    cpu.setA(0x3u, 16);
    goto L_8297B2;
L_8297B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97B2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97B2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8297B2 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_8297B4;
L_8297B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97B4u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97B4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8297B4 SEP
    cpu.sep(0x20u);
    goto L_8297B6;
L_8297B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97B6u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97B6u, 4u + 1u, 3u, cpu.address("absx", 0x0208u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8297B6 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x208u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8297B9;
L_8297B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97B9u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97B9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8297B9 BMI -> $8297DD
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_8297DD; }
    goto L_8297BB;
L_8297BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97BBu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97BBu, 4u + 1u, 3u, cpu.address("absx", 0x020Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8297BB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x20Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8297BE;
L_8297BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97BEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97BEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8297BE STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_8297C0;
L_8297C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97C0u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97C0u, 4u + 1u, 3u, cpu.address("absx", 0x020Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8297C0 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x20Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8297C3;
L_8297C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97C3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97C3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8297C3 STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_8297C5;
L_8297C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97C5u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97C5u, 4u + 1u, 3u, cpu.address("absy", 0x0276u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8297C5 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x276u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8297C8;
L_8297C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97C8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97C8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x07u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8297C8 STA
    hw.write(cpu.address("dp", 0x7u), cpu.a, cpu.m8?8:16);
    goto L_8297CA;
L_8297CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97CAu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97CAu, 4u + 1u, 3u, cpu.address("absy", 0x027Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8297CA LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x27Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8297CD;
L_8297CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97CDu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97CDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x09u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8297CD STA
    hw.write(cpu.address("dp", 0x9u), cpu.a, cpu.m8?8:16);
    goto L_8297CF;
L_8297CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97CFu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97CFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8297CF STZ
    hw.write(cpu.address("dp", 0x5u), 0, cpu.m8?8:16);
    goto L_8297D1;
L_8297D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97D1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97D1u, 6u, 3u, cpu.address("abs", 0x97ECu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8297D1 JSR -> $8297EC stack real
    { cpu.push16Value(hw,0x97D3u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x97D4u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x97ECu), 0x8297D1u); }
    goto L_8297D4;
L_8297D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97D4u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x97D4u,0x8297D4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97D4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97D4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8297D4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8297D6;
L_8297D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97D6u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97D6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8297D6 BNE -> $8297DD
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8297DD; }
    goto L_8297D8;
L_8297D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97D8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97D8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8297D8 LDA
    cpu.setA(0x1u, 8);
    goto L_8297DA;
L_8297DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97DAu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97DAu, 5u, 3u, cpu.address("absx", 0x0208u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8297DA STA
    hw.write(cpu.address("absx", 0x208u), cpu.a, cpu.m8?8:16);
    goto L_8297DD;
L_8297DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97DDu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97DDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8297DD DEX
    cpu.decReg('X');
    goto L_8297DE;
L_8297DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97DEu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97DEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8297DE DEX
    cpu.decReg('X');
    goto L_8297DF;
L_8297DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97DFu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97DFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8297DF DEX
    cpu.decReg('X');
    goto L_8297E0;
L_8297E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97E0u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97E0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8297E0 DEX
    cpu.decReg('X');
    goto L_8297E1;
L_8297E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97E1u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97E1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8297E1 DEX
    cpu.decReg('X');
    goto L_8297E2;
L_8297E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97E2u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97E2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8297E2 DEX
    cpu.decReg('X');
    goto L_8297E3;
L_8297E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97E3u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97E3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8297E3 DEY
    cpu.decReg('Y');
    goto L_8297E4;
L_8297E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97E4u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97E4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8297E4 DEY
    cpu.decReg('Y');
    goto L_8297E5;
L_8297E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97E5u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97E5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8297E5 DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_8297E7;
L_8297E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97E7u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97E7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8297E7 BPL -> $8297B6
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_8297B6; }
    goto L_8297E9;
L_8297E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97E9u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97E9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8297E9 REP
    cpu.rep(0x20u);
    goto L_8297EB;
L_8297EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97EBu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97EBu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8297EB RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8297EBu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8297EBu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_829844_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x829844u: goto L_829844;
    case 0x829846u: goto L_829846;
    case 0x829848u: goto L_829848;
    case 0x82984Au: goto L_82984A;
    case 0x82984Cu: goto L_82984C;
    case 0x82984Fu: goto L_82984F;
    case 0x829851u: goto L_829851;
    case 0x829853u: goto L_829853;
    case 0x829855u: goto L_829855;
    case 0x829856u: goto L_829856;
    case 0x829858u: goto L_829858;
    case 0x82985Au: goto L_82985A;
    case 0x82985Bu: goto L_82985B;
    case 0x82985Cu: goto L_82985C;
    case 0x82985Eu: goto L_82985E;
    case 0x82985Fu: goto L_82985F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_829844:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9844u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9844u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9844u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829844 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_829846;
L_829846:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9846u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9846u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9846u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829846 SEP
    cpu.sep(0x20u);
    goto L_829848;
L_829848:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9848u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9848u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9848u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829848 LDA
    cpu.setA(0x3u, 8);
    goto L_82984A;
L_82984A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x984Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x984Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x984Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82984A STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82984C;
L_82984C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x984Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x984Cu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x984Cu, 4u + 1u, 3u, cpu.address("absx", 0x0296u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82984C LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x296u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82984F;
L_82984F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x984Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x984Fu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x984Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82984F BPL -> $82985C
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82985C; }
    goto L_829851;
L_829851:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9851u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9851u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9851u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829851 DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_829853;
L_829853:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9853u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9853u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9853u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829853 BMI -> $829858
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_829858; }
    goto L_829855;
L_829855:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9855u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9855u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9855u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829855 INX
    cpu.inc('X');
    goto L_829856;
L_829856:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9856u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9856u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9856u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829856 BRA -> $82984C
    goto L_82984C;
L_829858:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9858u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9858u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9858u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829858 REP
    cpu.rep(0x20u);
    goto L_82985A;
L_82985A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x985Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x985Au,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x985Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82985A SEC
    cpu.setFlag('C', true);
    goto L_82985B;
L_82985B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x985Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x985Bu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x985Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82985B RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82985Bu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82985Bu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82985C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x985Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x985Cu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x985Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82985C REP
    cpu.rep(0x20u);
    goto L_82985E;
L_82985E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x985Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x985Eu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x985Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82985E CLC
    cpu.setFlag('C', false);
    goto L_82985F;
L_82985F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x985Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x985Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x985Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82985F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82985Fu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82985Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_829CFA_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x829CFAu: goto L_829CFA;
    case 0x829CFDu: goto L_829CFD;
    case 0x829D00u: goto L_829D00;
    case 0x829D03u: goto L_829D03;
    case 0x829D05u: goto L_829D05;
    case 0x829D07u: goto L_829D07;
    case 0x829D0Au: goto L_829D0A;
    case 0x829D0Du: goto L_829D0D;
    case 0x829D0Fu: goto L_829D0F;
    case 0x829D12u: goto L_829D12;
    case 0x829D16u: goto L_829D16;
    case 0x829D17u: goto L_829D17;
    case 0x829D19u: goto L_829D19;
    case 0x829D1Cu: goto L_829D1C;
    case 0x829D1Fu: goto L_829D1F;
    case 0x829D22u: goto L_829D22;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_829CFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CFAu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CFAu, 5u, 3u, cpu.address("abs", 0x0143u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829CFA STZ
    hw.write(cpu.address("abs", 0x143u), 0, cpu.m8?8:16);
    goto L_829CFD;
L_829CFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CFDu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CFDu, 5u, 3u, cpu.address("abs", 0x0145u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829CFD STZ
    hw.write(cpu.address("abs", 0x145u), 0, cpu.m8?8:16);
    goto L_829D00;
L_829D00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D00u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D00u, 6u, 3u, cpu.address("abs", 0xA043u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829D00 JSR -> $82A043 stack real
    { cpu.push16Value(hw,0x9D02u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9D03u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA043u), 0x829D00u); }
    goto L_829D03;
L_829D03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D03u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D03u,0x829D03u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D03u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D03u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829D03 BNE -> $829D17
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_829D17; }
    goto L_829D05;
L_829D05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D05u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D05u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829D05 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_829D07;
L_829D07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D07u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D07u, 9u, 3u, cpu.address("absx", 0x0200u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829D07 INC
    cpu.incMem(hw, cpu.address("absx", 0x200u), cpu.m8?8:16);
    goto L_829D0A;
L_829D0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D0Au,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D0Au, 5u + 1u, 3u, cpu.address("absx", 0x0410u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829D0A LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x410u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829D0D;
L_829D0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D0Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D0Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829D0D BEQ -> $829D16
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_829D16; }
    goto L_829D0F;
L_829D0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D0Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D0Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829D0F LDA
    cpu.setA(0xAu, 16);
    goto L_829D12;
L_829D12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D12u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D12u, 8u, 4u, 0x80A6FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829D12 JSL -> $80A6FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9D15u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9D16u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6FBu, 0x829D12u); }
    goto L_829D16;
L_829D16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D16u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D16u,0x829D16u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D16u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D16u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829D16 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x829D16u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829D16u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_829D17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D17u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D17u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829D17 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_829D19;
L_829D19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D19u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D19u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829D19 LDA
    cpu.setA(0xDu, 16);
    goto L_829D1C;
L_829D1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D1Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D1Cu, 6u, 3u, cpu.address("absx", 0x0200u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829D1C STA
    hw.write(cpu.address("absx", 0x200u), cpu.a, cpu.m8?8:16);
    goto L_829D1F;
L_829D1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D1Fu,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D1Fu, 9u, 3u, cpu.address("absx", 0x0422u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829D1F INC
    cpu.incMem(hw, cpu.address("absx", 0x422u), cpu.m8?8:16);
    goto L_829D22;
L_829D22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D22u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D22u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829D22 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x829D22u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829D22u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82A427_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82A427u: goto L_82A427;
    case 0x82A42Au: goto L_82A42A;
    case 0x82A42Cu: goto L_82A42C;
    case 0x82A42Fu: goto L_82A42F;
    case 0x82A431u: goto L_82A431;
    case 0x82A433u: goto L_82A433;
    case 0x82A435u: goto L_82A435;
    case 0x82A438u: goto L_82A438;
    case 0x82A43Au: goto L_82A43A;
    case 0x82A43Du: goto L_82A43D;
    case 0x82A43Fu: goto L_82A43F;
    case 0x82A440u: goto L_82A440;
    case 0x82A443u: goto L_82A443;
    case 0x82A445u: goto L_82A445;
    case 0x82A448u: goto L_82A448;
    case 0x82A44Au: goto L_82A44A;
    case 0x82A44Cu: goto L_82A44C;
    case 0x82A44Du: goto L_82A44D;
    case 0x82A44Fu: goto L_82A44F;
    case 0x82A453u: goto L_82A453;
    case 0x82A455u: goto L_82A455;
    case 0x82A458u: goto L_82A458;
    case 0x82A45Au: goto L_82A45A;
    case 0x82A45Cu: goto L_82A45C;
    case 0x82A45Du: goto L_82A45D;
    case 0x82A45Eu: goto L_82A45E;
    case 0x82A461u: goto L_82A461;
    case 0x82A463u: goto L_82A463;
    case 0x82A466u: goto L_82A466;
    case 0x82A468u: goto L_82A468;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82A427:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA427u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA427u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA427u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A427 LDX
    cpu.setX(0x0u, 16);
    goto L_82A42A;
L_82A42A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA42Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA42Au,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA42Au, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82A42A LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A42C;
L_82A42C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA42Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA42Cu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA42Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A42C BIT
    cpu.bit(0x4u, true);
    goto L_82A42F;
L_82A42F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA42Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA42Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA42Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A42F BNE -> $82A44D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A44D; }
    goto L_82A431;
L_82A431:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA431u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA431u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA431u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 2u, 0u);
    // $82A431 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A433;
L_82A433:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA433u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA433u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA433u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A433 BEQ -> $82A44D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A44D; }
    goto L_82A435;
L_82A435:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA435u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA435u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA435u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A435 BIT
    cpu.bit(0x6000u, true);
    goto L_82A438;
L_82A438:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA438u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA438u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA438u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A438 BEQ -> $82A440
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A440; }
    goto L_82A43A;
L_82A43A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA43Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA43Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA43Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A43A LDA
    cpu.setA(0x4000u, 16);
    goto L_82A43D;
L_82A43D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA43Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA43Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA43Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A43D STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_82A43F;
L_82A43F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA43Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA43Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA43Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A43F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82A43Fu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82A43Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82A440:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA440u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA440u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA440u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A440 BIT
    cpu.bit(0x8000u, true);
    goto L_82A443;
L_82A443:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA443u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA443u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA443u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A443 BNE -> $82A44D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A44D; }
    goto L_82A445;
L_82A445:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA445u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA445u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA445u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A445 BIT
    cpu.bit(0x30Fu, true);
    goto L_82A448;
L_82A448:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA448u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA448u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA448u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A448 BEQ -> $82A44D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A44D; }
    goto L_82A44A;
L_82A44A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA44Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA44Au,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA44Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A44A STZ
    hw.write(cpu.address("dp", 0xAu), 0, cpu.m8?8:16);
    goto L_82A44C;
L_82A44C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA44Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA44Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA44Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A44C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82A44Cu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82A44Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82A44D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA44Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA44Du,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA44Du, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82A44D LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A44F;
L_82A44F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA44Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA44Fu,cpu,0x3Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA44Fu, 6u, 4u, ((0x82A469u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A44F AND
    cpu.logicAnd(hw.readW(((0x82A469u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_82A453;
L_82A453:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA453u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA453u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA453u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A453 BEQ -> $82A45C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A45C; }
    goto L_82A455;
L_82A455:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA455u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA455u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA455u, 6u, 3u, cpu.address("abs", 0xA481u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A455 JSR -> $82A481 stack real
    { cpu.push16Value(hw,0xA457u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA458u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA481u), 0x82A455u); }
    goto L_82A458;
L_82A458:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA458u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA458u,0x82A458u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA458u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA458u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A458 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A45A;
L_82A45A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA45Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA45Au,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA45Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A45A BPL -> $82A468
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82A468; }
    goto L_82A45C;
L_82A45C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA45Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA45Cu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA45Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A45C INX
    cpu.inc('X');
    goto L_82A45D;
L_82A45D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA45Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA45Du,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA45Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A45D INX
    cpu.inc('X');
    goto L_82A45E;
L_82A45E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA45Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA45Eu,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA45Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A45E CPX
    cpu.compareX(0x8u);
    goto L_82A461;
L_82A461:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA461u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA461u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA461u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A461 BCC -> $82A44D
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_82A44D; }
    goto L_82A463;
L_82A463:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA463u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA463u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA463u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A463 LDA
    cpu.setA(0x8000u, 16);
    goto L_82A466;
L_82A466:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA466u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA466u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA466u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A466 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_82A468;
L_82A468:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA468u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA468u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA468u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A468 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82A468u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82A468u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82AF5B_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82AF5Bu: goto L_82AF5B;
    case 0x82AF5Eu: goto L_82AF5E;
    case 0x82AF61u: goto L_82AF61;
    case 0x82AF63u: goto L_82AF63;
    case 0x82AF65u: goto L_82AF65;
    case 0x82AF67u: goto L_82AF67;
    case 0x82AF69u: goto L_82AF69;
    case 0x82AF6Bu: goto L_82AF6B;
    case 0x82AF6Du: goto L_82AF6D;
    case 0x82AF70u: goto L_82AF70;
    case 0x82AF71u: goto L_82AF71;
    case 0x82AF72u: goto L_82AF72;
    case 0x82AF75u: goto L_82AF75;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82AF5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF5Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF5Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF5Bu, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF5B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AF5E;
L_82AF5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF5Eu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF5Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF5E CMP
    cpu.compareA(0x3u);
    goto L_82AF61;
L_82AF61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF61u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF61u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF61 BNE -> $82AF67
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82AF67; }
    goto L_82AF63;
L_82AF63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF63u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF63u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF63u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF63 STZ
    hw.write(cpu.address("dp", 0xA2u), 0, cpu.m8?8:16);
    goto L_82AF65;
L_82AF65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF65u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF65u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF65 STZ
    hw.write(cpu.address("dp", 0x9Eu), 0, cpu.m8?8:16);
    goto L_82AF67;
L_82AF67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF67u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF67u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF67 SEP
    cpu.sep(0x20u);
    goto L_82AF69;
L_82AF69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF69u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF69u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF69 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x49u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AF6B;
L_82AF6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF6Bu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF6Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF6B REP
    cpu.rep(0x20u);
    goto L_82AF6D;
L_82AF6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF6Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF6Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF6D AND
    cpu.logicAnd(0xFFu);
    goto L_82AF70;
L_82AF70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF70u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF70u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF70 ASL
    cpu.aslA();
    goto L_82AF71;
L_82AF71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF71u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF71u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF71 TAX
    cpu.transfer("TAX");
    goto L_82AF72;
L_82AF72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF72u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF72u, 5u, 3u, cpu.address("abs", 0xAF77u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AF72 PEA
    cpu.push16Value(hw, 0xAF77u);
    goto L_82AF75;
L_82AF75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF75u,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF75u, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0xAF95u + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $82AF75 JMP (AF95,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0xAF95u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x82AF75u); return; }
}

void sub_82AF5B_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82AF5Bu: goto L_82AF5B;
    case 0x82AF5Eu: goto L_82AF5E;
    case 0x82AF61u: goto L_82AF61;
    case 0x82AF63u: goto L_82AF63;
    case 0x82AF65u: goto L_82AF65;
    case 0x82AF67u: goto L_82AF67;
    case 0x82AF69u: goto L_82AF69;
    case 0x82AF6Bu: goto L_82AF6B;
    case 0x82AF6Du: goto L_82AF6D;
    case 0x82AF70u: goto L_82AF70;
    case 0x82AF71u: goto L_82AF71;
    case 0x82AF72u: goto L_82AF72;
    case 0x82AF75u: goto L_82AF75;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82AF5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF5Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF5Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF5Bu, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF5B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AF5E;
L_82AF5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF5Eu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF5Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF5E CMP
    cpu.compareA(0x3u);
    goto L_82AF61;
L_82AF61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF61u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF61u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF61 BNE -> $82AF67
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82AF67; }
    goto L_82AF63;
L_82AF63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF63u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF63u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF63u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF63 STZ
    hw.write(cpu.address("dp", 0xA2u), 0, cpu.m8?8:16);
    goto L_82AF65;
L_82AF65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF65u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF65u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF65 STZ
    hw.write(cpu.address("dp", 0x9Eu), 0, cpu.m8?8:16);
    goto L_82AF67;
L_82AF67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF67u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF67u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF67 SEP
    cpu.sep(0x20u);
    goto L_82AF69;
L_82AF69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF69u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF69u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF69 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x49u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AF6B;
L_82AF6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF6Bu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF6Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF6B REP
    cpu.rep(0x20u);
    goto L_82AF6D;
L_82AF6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF6Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF6Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF6D AND
    cpu.logicAnd(0xFFu);
    goto L_82AF70;
L_82AF70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF70u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF70u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF70 ASL
    cpu.aslA();
    goto L_82AF71;
L_82AF71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF71u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF71u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF71 TAX
    cpu.transfer("TAX");
    goto L_82AF72;
L_82AF72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF72u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF72u, 5u, 3u, cpu.address("abs", 0xAF77u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AF72 PEA
    cpu.push16Value(hw, 0xAF77u);
    goto L_82AF75;
L_82AF75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF75u,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF75u, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0xAF95u + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $82AF75 JMP (AF95,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0xAF95u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x82AF75u); return; }
}

void sub_82B186_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B186u: goto L_82B186;
    case 0x82B189u: goto L_82B189;
    case 0x82B18Bu: goto L_82B18B;
    case 0x82B18Du: goto L_82B18D;
    case 0x82B190u: goto L_82B190;
    case 0x82B192u: goto L_82B192;
    case 0x82B194u: goto L_82B194;
    case 0x82B196u: goto L_82B196;
    case 0x82B198u: goto L_82B198;
    case 0x82B19Au: goto L_82B19A;
    case 0x82B19Du: goto L_82B19D;
    case 0x82B1A0u: goto L_82B1A0;
    case 0x82B1A1u: goto L_82B1A1;
    case 0x82B1A3u: goto L_82B1A3;
    case 0x82B1A5u: goto L_82B1A5;
    case 0x82B1A7u: goto L_82B1A7;
    case 0x82B1A9u: goto L_82B1A9;
    case 0x82B1ABu: goto L_82B1AB;
    case 0x82B1ACu: goto L_82B1AC;
    case 0x82B1AEu: goto L_82B1AE;
    case 0x82B1B2u: goto L_82B1B2;
    case 0x82B1B4u: goto L_82B1B4;
    case 0x82B1B7u: goto L_82B1B7;
    case 0x82B1BBu: goto L_82B1BB;
    case 0x82B1BEu: goto L_82B1BE;
    case 0x82B1C0u: goto L_82B1C0;
    case 0x82B1C3u: goto L_82B1C3;
    case 0x82B1C5u: goto L_82B1C5;
    case 0x82B1C8u: goto L_82B1C8;
    case 0x82B1CBu: goto L_82B1CB;
    case 0x82B1CDu: goto L_82B1CD;
    case 0x82B1D0u: goto L_82B1D0;
    case 0x82B1D2u: goto L_82B1D2;
    case 0x82B1D5u: goto L_82B1D5;
    case 0x82B1D8u: goto L_82B1D8;
    case 0x82B1DAu: goto L_82B1DA;
    case 0x82B1DDu: goto L_82B1DD;
    case 0x82B1E0u: goto L_82B1E0;
    case 0x82B1E2u: goto L_82B1E2;
    case 0x82B1E5u: goto L_82B1E5;
    case 0x82B1E7u: goto L_82B1E7;
    case 0x82B1EAu: goto L_82B1EA;
    case 0x82B1EDu: goto L_82B1ED;
    case 0x82B1EFu: goto L_82B1EF;
    case 0x82B1F2u: goto L_82B1F2;
    case 0x82B1F5u: goto L_82B1F5;
    case 0x82B1F8u: goto L_82B1F8;
    case 0x82B1FAu: goto L_82B1FA;
    case 0x82B1FDu: goto L_82B1FD;
    case 0x82B1FFu: goto L_82B1FF;
    case 0x82B201u: goto L_82B201;
    case 0x82B203u: goto L_82B203;
    case 0x82B205u: goto L_82B205;
    case 0x82B207u: goto L_82B207;
    case 0x82B20Au: goto L_82B20A;
    case 0x82B20Eu: goto L_82B20E;
    case 0x82B211u: goto L_82B211;
    case 0x82B214u: goto L_82B214;
    case 0x82B217u: goto L_82B217;
    case 0x82B21Au: goto L_82B21A;
    case 0x82B21Cu: goto L_82B21C;
    case 0x82B21Fu: goto L_82B21F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B186:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB186u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB186u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB186u, 5u, 3u, cpu.address("abs", 0x0141u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B186 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x141u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B189;
L_82B189:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB189u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB189u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB189u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B189 BEQ -> $82B1A1
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B1A1; }
    goto L_82B18B;
L_82B18B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB18Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB18Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB18Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B18B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x75u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B18D;
L_82B18D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB18Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB18Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB18Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B18D AND
    cpu.logicAnd(0xFFu);
    goto L_82B190;
L_82B190:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB190u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB190u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB190u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B190 BNE -> $82B1BE
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B1BE; }
    goto L_82B192;
L_82B192:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB192u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB192u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB192u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B192 SEP
    cpu.sep(0x20u);
    goto L_82B194;
L_82B194:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB194u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB194u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB194u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B194 LDA
    cpu.setA(0xCu, 8);
    goto L_82B196;
L_82B196:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB196u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB196u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB196u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B196 STA
    hw.write(cpu.address("dp", 0x49u), cpu.a, cpu.m8?8:16);
    goto L_82B198;
L_82B198:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB198u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB198u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB198u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B198 REP
    cpu.rep(0x20u);
    goto L_82B19A;
L_82B19A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB19Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB19Au,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB19Au, 5u, 3u, cpu.address("abs", 0x0141u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B19A STZ
    hw.write(cpu.address("abs", 0x141u), 0, cpu.m8?8:16);
    goto L_82B19D;
L_82B19D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB19Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB19Du,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB19Du, 5u, 3u, cpu.address("abs", 0x0176u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B19D STZ
    hw.write(cpu.address("abs", 0x176u), 0, cpu.m8?8:16);
    goto L_82B1A0;
L_82B1A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1A0u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1A0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B1A0 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B1A0u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B1A0u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82B1A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1A1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1A1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B1A1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B1A3;
L_82B1A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1A3u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1A3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B1A3 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x9Eu), cpu.m8?8:16));
    goto L_82B1A5;
L_82B1A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1A5u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1A5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B1A5 BEQ -> $82B1BE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B1BE; }
    goto L_82B1A7;
L_82B1A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1A7u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1A7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B1A7 SEP
    cpu.sep(0x20u);
    goto L_82B1A9;
L_82B1A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1A9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1A9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B1A9 LDA
    cpu.setA(0x81u, 8);
    goto L_82B1AB;
L_82B1AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1ABu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1ABu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B1AB XBA
    cpu.xba();
    goto L_82B1AC;
L_82B1AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1ACu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1ACu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B1AC LDA
    cpu.setA(0xFu, 8);
    goto L_82B1AE;
L_82B1AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1AEu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1AEu, 8u, 4u, 0x8086F4u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B1AE JSL -> $8086F4 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB1B1u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB1B2u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8086F4u, 0x82B1AEu); }
    goto L_82B1B2;
L_82B1B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1B2u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB1B2u,0x82B1B2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1B2u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1B2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B1B2 REP
    cpu.rep(0x20u);
    goto L_82B1B4;
L_82B1B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1B4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1B4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B1B4 LDA
    cpu.setA(0x37u, 16);
    goto L_82B1B7;
L_82B1B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1B7u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1B7u, 8u, 4u, 0x80A6FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B1B7 JSL -> $80A6FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB1BAu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB1BBu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6FBu, 0x82B1B7u); }
    goto L_82B1BB;
L_82B1BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1BBu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB1BBu,0x82B1BBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1BBu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1BBu, 8u, 3u, cpu.address("abs", 0x0141u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B1BB INC
    cpu.incMem(hw, cpu.address("abs", 0x141u), cpu.m8?8:16);
    goto L_82B1BE;
L_82B1BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1BEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1BEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B1BE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B1C0;
L_82B1C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1C0u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1C0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B1C0 AND
    cpu.logicAnd(0x7u);
    goto L_82B1C3;
L_82B1C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1C3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1C3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B1C3 BNE -> $82B20E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B20E; }
    goto L_82B1C5;
L_82B1C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1C5u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1C5u, 5u, 3u, cpu.address("abs", 0x0176u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B1C5 STZ
    hw.write(cpu.address("abs", 0x176u), 0, cpu.m8?8:16);
    goto L_82B1C8;
L_82B1C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1C8u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1C8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B1C8 LDX
    cpu.setX(0x0u, 16);
    goto L_82B1CB;
L_82B1CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1CBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1CBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B1CB STA
    hw.write(cpu.address("dp", 0x5Bu), cpu.a, cpu.m8?8:16);
    goto L_82B1CD;
L_82B1CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1CDu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1CDu, 5u + 1u, 3u, cpu.address("absx", 0x0402u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B1CD LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x402u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B1D0;
L_82B1D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1D0u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1D0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B1D0 BEQ -> $82B1DA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B1DA; }
    goto L_82B1D2;
L_82B1D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1D2u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1D2u, 5u + 1u, 3u, cpu.address("absx", 0x0404u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B1D2 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x404u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B1D5;
L_82B1D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1D5u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1D5u, 6u, 3u, cpu.address("abs", 0xD68Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B1D5 JSR -> $82D68D stack real
    { cpu.push16Value(hw,0xB1D7u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB1D8u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD68Du), 0x82B1D5u); }
    goto L_82B1D8;
L_82B1D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1D8u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1D8u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1D8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B1D8 BCS -> $82B1DD
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_82B1DD; }
    goto L_82B1DA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1D8u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1D8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B1D8 BCS -> $82B1DD
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_82B1DD; }
    goto L_82B1DA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB1D8u,0x82B1D8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B1DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1DAu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1DAu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1DAu, 8u, 3u, cpu.address("abs", 0x0176u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B1DA INC
    cpu.incMem(hw, cpu.address("abs", 0x176u), cpu.m8?8:16);
    goto L_82B1DD;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1DAu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1DAu, 8u, 3u, cpu.address("abs", 0x0176u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B1DA INC
    cpu.incMem(hw, cpu.address("abs", 0x176u), cpu.m8?8:16);
    goto L_82B1DD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB1DAu,0x82B1DAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B1DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1DDu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1DDu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1DDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B1DD LDX
    cpu.setX(0x100u, 16);
    goto L_82B1E0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1DDu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1DDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B1DD LDX
    cpu.setX(0x100u, 16);
    goto L_82B1E0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB1DDu,0x82B1DDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B1E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1E0u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E0u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B1E0 STX
    hw.write(cpu.address("dp", 0x5Bu), cpu.x, cpu.x8?8:16);
    goto L_82B1E2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E0u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B1E0 STX
    hw.write(cpu.address("dp", 0x5Bu), cpu.x, cpu.x8?8:16);
    goto L_82B1E2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB1E0u,0x82B1E0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B1E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1E2u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E2u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E2u, 5u + 1u, 3u, cpu.address("absx", 0x0402u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B1E2 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x402u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B1E5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E2u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E2u, 5u + 1u, 3u, cpu.address("absx", 0x0402u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B1E2 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x402u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B1E5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB1E2u,0x82B1E2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B1E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1E5u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E5u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B1E5 BEQ -> $82B1EF
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B1EF; }
    goto L_82B1E7;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E5u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B1E5 BEQ -> $82B1EF
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B1EF; }
    goto L_82B1E7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB1E5u,0x82B1E5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B1E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1E7u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E7u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E7u, 5u + 1u, 3u, cpu.address("absx", 0x0404u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B1E7 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x404u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B1EA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E7u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E7u, 5u + 1u, 3u, cpu.address("absx", 0x0404u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B1E7 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x404u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B1EA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB1E7u,0x82B1E7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B1EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1EAu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1EAu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1EAu, 6u, 3u, cpu.address("abs", 0xD68Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B1EA JSR -> $82D68D stack real
    { cpu.push16Value(hw,0xB1ECu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB1EDu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD68Du), 0x82B1EAu); }
    goto L_82B1ED;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1EAu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1EAu, 6u, 3u, cpu.address("abs", 0xD68Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B1EA JSR -> $82D68D stack real
    { cpu.push16Value(hw,0xB1ECu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB1EDu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD68Du), 0x82B1EAu); }
    goto L_82B1ED;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB1EAu,0x82B1EAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B1ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1EDu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1EDu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1EDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B1ED BCS -> $82B1F2
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_82B1F2; }
    goto L_82B1EF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1EDu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1EDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B1ED BCS -> $82B1F2
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_82B1F2; }
    goto L_82B1EF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB1EDu,0x82B1EDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B1EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1EFu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1EFu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1EFu, 8u, 3u, cpu.address("abs", 0x0176u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B1EF INC
    cpu.incMem(hw, cpu.address("abs", 0x176u), cpu.m8?8:16);
    goto L_82B1F2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1EFu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1EFu, 8u, 3u, cpu.address("abs", 0x0176u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B1EF INC
    cpu.incMem(hw, cpu.address("abs", 0x176u), cpu.m8?8:16);
    goto L_82B1F2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB1EFu,0x82B1EFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B1F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1F2u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F2u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F2u, 5u, 3u, cpu.address("abs", 0x0176u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B1F2 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x176u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B1F5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F2u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F2u, 5u, 3u, cpu.address("abs", 0x0176u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B1F2 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x176u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B1F5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB1F2u,0x82B1F2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B1F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1F5u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F5u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B1F5 CMP
    cpu.compareA(0x2u);
    goto L_82B1F8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F5u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B1F5 CMP
    cpu.compareA(0x2u);
    goto L_82B1F8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB1F5u,0x82B1F5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B1F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F8u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B1F8 BCC -> $82B20E
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_82B20E; }
    goto L_82B1FA;
L_82B1FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1FAu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1FAu, 5u, 3u, cpu.address("abs", 0x0141u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B1FA LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x141u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B1FD;
L_82B1FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1FDu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1FDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B1FD BNE -> $82B20E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B20E; }
    goto L_82B1FF;
L_82B1FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1FFu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1FFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B1FF SEP
    cpu.sep(0x20u);
    goto L_82B201;
L_82B201:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB201u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB201u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB201u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B201 LDA
    cpu.setA(0xDu, 8);
    goto L_82B203;
L_82B203:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB203u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB203u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB203u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B203 STA
    hw.write(cpu.address("dp", 0x49u), cpu.a, cpu.m8?8:16);
    goto L_82B205;
L_82B205:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB205u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB205u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB205u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B205 REP
    cpu.rep(0x20u);
    goto L_82B207;
L_82B207:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB207u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB207u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB207u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B207 LDA
    cpu.setA(0x37u, 16);
    goto L_82B20A;
L_82B20A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB20Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Au, 8u, 4u, 0x80A6FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B20A JSL -> $80A6FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB20Du); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB20Eu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6FBu, 0x82B20Au); }
    goto L_82B20E;
L_82B20E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB20Eu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Eu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Eu, 5u, 3u, cpu.address("abs", 0x0176u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B20E STZ
    hw.write(cpu.address("abs", 0x176u), 0, cpu.m8?8:16);
    goto L_82B211;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Eu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Eu, 5u, 3u, cpu.address("abs", 0x0176u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B20E STZ
    hw.write(cpu.address("abs", 0x176u), 0, cpu.m8?8:16);
    goto L_82B211;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB20Eu,0x82B20Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B211:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB211u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB211u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB211u, 6u, 3u, cpu.address("abs", 0xD5A3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B211 JSR -> $82D5A3 stack real
    { cpu.push16Value(hw,0xB213u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB214u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD5A3u), 0x82B211u); }
    goto L_82B214;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB211u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB211u, 6u, 3u, cpu.address("abs", 0xD5A3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B211 JSR -> $82D5A3 stack real
    { cpu.push16Value(hw,0xB213u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB214u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD5A3u), 0x82B211u); }
    goto L_82B214;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB211u,0x82B211u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B214:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB214u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB214u,0x82B214u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB214u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB214u, 6u, 3u, cpu.address("abs", 0xCAA5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B214 JSR -> $82CAA5 stack real
    { cpu.push16Value(hw,0xB216u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB217u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCAA5u), 0x82B214u); }
    goto L_82B217;
L_82B217:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB217u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB217u,0x82B217u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB217u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB217u, 5u, 3u, cpu.address("abs", 0x0141u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B217 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x141u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B21A;
L_82B21A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB21Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB21Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB21Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B21A BNE -> $82B21F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B21F; }
    goto L_82B21C;
L_82B21C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB21Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB21Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB21Cu, 6u, 3u, cpu.address("abs", 0xD4F9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B21C JSR -> $82D4F9 stack real
    { cpu.push16Value(hw,0xB21Eu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB21Fu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD4F9u), 0x82B21Cu); }
    goto L_82B21F;
L_82B21F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB21Fu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB21Fu,0x82B21Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB21Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB21Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B21F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B21Fu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B21Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82D769_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82D769u: goto L_82D769;
    case 0x82D76Bu: goto L_82D76B;
    case 0x82D76Eu: goto L_82D76E;
    case 0x82D772u: goto L_82D772;
    case 0x82D776u: goto L_82D776;
    case 0x82D77Au: goto L_82D77A;
    case 0x82D77Eu: goto L_82D77E;
    case 0x82D781u: goto L_82D781;
    case 0x82D785u: goto L_82D785;
    case 0x82D786u: goto L_82D786;
    case 0x82D787u: goto L_82D787;
    case 0x82D789u: goto L_82D789;
    case 0x82D78Au: goto L_82D78A;
    case 0x82D78Bu: goto L_82D78B;
    case 0x82D78Du: goto L_82D78D;
    case 0x82D78Fu: goto L_82D78F;
    case 0x82D792u: goto L_82D792;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82D769:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD769u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD769u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD769u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D769 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82D76B;
L_82D76B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD76Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD76Bu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD76Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D76B LDY
    cpu.setY(0x9u, 16);
    goto L_82D76E;
L_82D76E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD76Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD76Eu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD76Eu, 6u, 4u, ((0x7E6000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D76E LDA
    cpu.loadA(hw.readW(((0x7E6000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D772;
L_82D772:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD772u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD772u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD772u, 6u, 4u, ((0x7E5FC0u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D772 STA
    hw.write(((0x7E5FC0u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_82D776;
L_82D776:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD776u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD776u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD776u, 6u, 4u, ((0x7E6040u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D776 LDA
    cpu.loadA(hw.readW(((0x7E6040u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D77A;
L_82D77A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD77Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD77Au,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD77Au, 6u, 4u, ((0x7E6000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D77A STA
    hw.write(((0x7E6000u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_82D77E;
L_82D77E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD77Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD77Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD77Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D77E LDA
    cpu.setA(0x0u, 16);
    goto L_82D781;
L_82D781:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD781u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD781u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD781u, 6u, 4u, ((0x7E6040u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D781 STA
    hw.write(((0x7E6040u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_82D785;
L_82D785:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD785u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD785u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD785u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D785 TXA
    cpu.transfer("TXA");
    goto L_82D786;
L_82D786:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD786u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD786u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD786u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D786 CLC
    cpu.setFlag('C', false);
    goto L_82D787;
L_82D787:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD787u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD787u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD787u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D787 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16));
    goto L_82D789;
L_82D789:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD789u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD789u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD789u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D789 TAX
    cpu.transfer("TAX");
    goto L_82D78A;
L_82D78A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD78Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Au,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D78A DEY
    cpu.decReg('Y');
    goto L_82D78B;
L_82D78B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD78Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Bu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D78B BPL -> $82D76E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82D76E; }
    goto L_82D78D;
L_82D78D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD78Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Du,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D78D LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82D78F;
L_82D78F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD78Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Fu,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Fu, 9u, 3u, cpu.address("absx", 0x0400u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D78F DEC
    cpu.decMem(hw, cpu.address("absx", 0x400u), cpu.m8?8:16);
    goto L_82D792;
L_82D792:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD792u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD792u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD792u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D792 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82D792u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82D792u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_848682_E0M1X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848682u: goto L_848682;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848682:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8682u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8682u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8682u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848682 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848682u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848682u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_848682_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848682u: goto L_848682;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848682:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8682u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8682u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8682u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848682 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848682u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848682u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_848766_E0M1X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848766u: goto L_848766;
    case 0x848768u: goto L_848768;
    case 0x84876Au: goto L_84876A;
    case 0x84876Du: goto L_84876D;
    case 0x84876Fu: goto L_84876F;
    case 0x848772u: goto L_848772;
    case 0x848774u: goto L_848774;
    case 0x848775u: goto L_848775;
    case 0x848777u: goto L_848777;
    case 0x848779u: goto L_848779;
    case 0x84877Cu: goto L_84877C;
    case 0x84877Eu: goto L_84877E;
    case 0x848781u: goto L_848781;
    case 0x848783u: goto L_848783;
    case 0x848785u: goto L_848785;
    case 0x848788u: goto L_848788;
    case 0x84878Au: goto L_84878A;
    case 0x84878Cu: goto L_84878C;
    case 0x84878Fu: goto L_84878F;
    case 0x848791u: goto L_848791;
    case 0x848794u: goto L_848794;
    case 0x848797u: goto L_848797;
    case 0x84879Au: goto L_84879A;
    case 0x84879Du: goto L_84879D;
    case 0x8487A1u: goto L_8487A1;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848766:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8766u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8766u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8766u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848766 REP
    cpu.rep(0x20u);
    goto L_848768;
L_848768:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8768u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8768u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8768u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848768 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84876A;
L_84876A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x876Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x876Au,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x876Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84876A BIT
    cpu.bit(0x200u, true);
    goto L_84876D;
L_84876D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x876Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x876Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x876Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84876D BNE -> $848777
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_848777; }
    goto L_84876F;
L_84876F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x876Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x876Fu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x876Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84876F BIT
    cpu.bit(0x100u, true);
    goto L_848772;
L_848772:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8772u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8772u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8772u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848772 BNE -> $848783
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_848783; }
    goto L_848774;
L_848774:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8774u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8774u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8774u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848774 CLC
    cpu.setFlag('C', false);
    goto L_848775;
L_848775:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8775u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8775u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8775u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848775 BRA -> $8487A1
    goto L_8487A1;
L_848777:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8777u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8777u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8777u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848777 SEP
    cpu.sep(0x20u);
    goto L_848779;
L_848779:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8779u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8779u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8779u, 4u, 3u, cpu.address("abs", 0x06FDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848779 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x6FDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84877C;
L_84877C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x877Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x877Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x877Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84877C BEQ -> $8487A1
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8487A1; }
    goto L_84877E;
L_84877E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x877Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x877Eu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x877Eu, 4u, 3u, cpu.address("abs", 0x06FDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84877E STZ
    hw.write(cpu.address("abs", 0x6FDu), 0, cpu.m8?8:16);
    goto L_848781;
L_848781:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8781u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8781u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8781u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848781 BRA -> $84878F
    goto L_84878F;
L_848783:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8783u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8783u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8783u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848783 SEP
    cpu.sep(0x20u);
    goto L_848785;
L_848785:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8785u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8785u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8785u, 4u, 3u, cpu.address("abs", 0x06FDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848785 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x6FDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848788;
L_848788:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8788u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8788u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8788u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848788 BNE -> $8487A1
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8487A1; }
    goto L_84878A;
L_84878A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x878Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x878Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x878Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84878A LDA
    cpu.setA(0x1u, 8);
    goto L_84878C;
L_84878C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x878Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x878Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x878Cu, 4u, 3u, cpu.address("abs", 0x06FDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84878C STA
    hw.write(cpu.address("abs", 0x6FDu), cpu.a, cpu.m8?8:16);
    goto L_84878F;
L_84878F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x878Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x878Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x878Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84878F REP
    cpu.rep(0x20u);
    goto L_848791;
L_848791:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8791u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8791u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8791u, 5u, 3u, cpu.address("abs", 0x065Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848791 STZ
    hw.write(cpu.address("abs", 0x65Au), 0, cpu.m8?8:16);
    goto L_848794;
L_848794:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8794u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8794u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8794u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848794 LDA
    cpu.setA(0x1u, 16);
    goto L_848797;
L_848797:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8797u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8797u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8797u, 5u, 3u, cpu.address("abs", 0x06E9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848797 STA
    hw.write(cpu.address("abs", 0x6E9u), cpu.a, cpu.m8?8:16);
    goto L_84879A;
L_84879A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x879Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x879Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x879Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84879A LDA
    cpu.setA(0x7u, 16);
    goto L_84879D;
L_84879D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x879Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x879Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x879Du, 8u, 4u, 0x80A6FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84879D JSL -> $80A6FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x87A0u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x87A1u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6FBu, 0x84879Du); }
    goto L_8487A1;
L_8487A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87A1u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87A1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87A1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8487A1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8487A1u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8487A1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87A1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87A1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8487A1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8487A1u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8487A1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x87A1u,0x8487A1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_848766_E0M1X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848766u: goto L_848766;
    case 0x848768u: goto L_848768;
    case 0x84876Au: goto L_84876A;
    case 0x84876Du: goto L_84876D;
    case 0x84876Fu: goto L_84876F;
    case 0x848772u: goto L_848772;
    case 0x848774u: goto L_848774;
    case 0x848775u: goto L_848775;
    case 0x848777u: goto L_848777;
    case 0x848779u: goto L_848779;
    case 0x84877Cu: goto L_84877C;
    case 0x84877Eu: goto L_84877E;
    case 0x848781u: goto L_848781;
    case 0x848783u: goto L_848783;
    case 0x848785u: goto L_848785;
    case 0x848788u: goto L_848788;
    case 0x84878Au: goto L_84878A;
    case 0x84878Cu: goto L_84878C;
    case 0x84878Fu: goto L_84878F;
    case 0x848791u: goto L_848791;
    case 0x848794u: goto L_848794;
    case 0x848797u: goto L_848797;
    case 0x84879Au: goto L_84879A;
    case 0x84879Du: goto L_84879D;
    case 0x8487A1u: goto L_8487A1;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848766:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8766u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8766u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8766u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848766 REP
    cpu.rep(0x20u);
    goto L_848768;
L_848768:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8768u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8768u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8768u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848768 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84876A;
L_84876A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x876Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x876Au,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x876Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84876A BIT
    cpu.bit(0x200u, true);
    goto L_84876D;
L_84876D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x876Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x876Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x876Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84876D BNE -> $848777
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_848777; }
    goto L_84876F;
L_84876F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x876Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x876Fu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x876Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84876F BIT
    cpu.bit(0x100u, true);
    goto L_848772;
L_848772:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8772u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8772u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8772u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848772 BNE -> $848783
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_848783; }
    goto L_848774;
L_848774:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8774u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8774u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8774u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848774 CLC
    cpu.setFlag('C', false);
    goto L_848775;
L_848775:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8775u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8775u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8775u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848775 BRA -> $8487A1
    goto L_8487A1;
L_848777:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8777u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8777u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8777u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848777 SEP
    cpu.sep(0x20u);
    goto L_848779;
L_848779:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8779u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8779u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8779u, 4u, 3u, cpu.address("abs", 0x06FDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848779 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x6FDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84877C;
L_84877C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x877Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x877Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x877Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84877C BEQ -> $8487A1
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8487A1; }
    goto L_84877E;
L_84877E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x877Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x877Eu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x877Eu, 4u, 3u, cpu.address("abs", 0x06FDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84877E STZ
    hw.write(cpu.address("abs", 0x6FDu), 0, cpu.m8?8:16);
    goto L_848781;
L_848781:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8781u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8781u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8781u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848781 BRA -> $84878F
    goto L_84878F;
L_848783:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8783u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8783u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8783u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848783 SEP
    cpu.sep(0x20u);
    goto L_848785;
L_848785:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8785u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8785u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8785u, 4u, 3u, cpu.address("abs", 0x06FDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848785 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x6FDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848788;
L_848788:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8788u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8788u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8788u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848788 BNE -> $8487A1
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8487A1; }
    goto L_84878A;
L_84878A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x878Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x878Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x878Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84878A LDA
    cpu.setA(0x1u, 8);
    goto L_84878C;
L_84878C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x878Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x878Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x878Cu, 4u, 3u, cpu.address("abs", 0x06FDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84878C STA
    hw.write(cpu.address("abs", 0x6FDu), cpu.a, cpu.m8?8:16);
    goto L_84878F;
L_84878F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x878Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x878Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x878Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84878F REP
    cpu.rep(0x20u);
    goto L_848791;
L_848791:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8791u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8791u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8791u, 5u, 3u, cpu.address("abs", 0x065Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848791 STZ
    hw.write(cpu.address("abs", 0x65Au), 0, cpu.m8?8:16);
    goto L_848794;
L_848794:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8794u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8794u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8794u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848794 LDA
    cpu.setA(0x1u, 16);
    goto L_848797;
L_848797:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8797u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8797u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8797u, 5u, 3u, cpu.address("abs", 0x06E9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848797 STA
    hw.write(cpu.address("abs", 0x6E9u), cpu.a, cpu.m8?8:16);
    goto L_84879A;
L_84879A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x879Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x879Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x879Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84879A LDA
    cpu.setA(0x7u, 16);
    goto L_84879D;
L_84879D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x879Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x879Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x879Du, 8u, 4u, 0x80A6FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84879D JSL -> $80A6FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x87A0u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x87A1u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6FBu, 0x84879Du); }
    goto L_8487A1;
L_8487A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87A1u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87A1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87A1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8487A1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8487A1u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8487A1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87A1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87A1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8487A1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8487A1u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8487A1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87A1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87A1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8487A1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8487A1u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8487A1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x87A1u,0x8487A1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_848766_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848766u: goto L_848766;
    case 0x848768u: goto L_848768;
    case 0x84876Au: goto L_84876A;
    case 0x84876Du: goto L_84876D;
    case 0x84876Fu: goto L_84876F;
    case 0x848772u: goto L_848772;
    case 0x848774u: goto L_848774;
    case 0x848775u: goto L_848775;
    case 0x848777u: goto L_848777;
    case 0x848779u: goto L_848779;
    case 0x84877Cu: goto L_84877C;
    case 0x84877Eu: goto L_84877E;
    case 0x848781u: goto L_848781;
    case 0x848783u: goto L_848783;
    case 0x848785u: goto L_848785;
    case 0x848788u: goto L_848788;
    case 0x84878Au: goto L_84878A;
    case 0x84878Cu: goto L_84878C;
    case 0x84878Fu: goto L_84878F;
    case 0x848791u: goto L_848791;
    case 0x848794u: goto L_848794;
    case 0x848797u: goto L_848797;
    case 0x84879Au: goto L_84879A;
    case 0x84879Du: goto L_84879D;
    case 0x8487A1u: goto L_8487A1;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848766:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8766u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8766u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8766u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848766 REP
    cpu.rep(0x20u);
    goto L_848768;
L_848768:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8768u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8768u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8768u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848768 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84876A;
L_84876A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x876Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x876Au,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x876Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84876A BIT
    cpu.bit(0x200u, true);
    goto L_84876D;
L_84876D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x876Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x876Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x876Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84876D BNE -> $848777
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_848777; }
    goto L_84876F;
L_84876F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x876Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x876Fu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x876Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84876F BIT
    cpu.bit(0x100u, true);
    goto L_848772;
L_848772:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8772u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8772u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8772u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848772 BNE -> $848783
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_848783; }
    goto L_848774;
L_848774:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8774u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8774u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8774u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848774 CLC
    cpu.setFlag('C', false);
    goto L_848775;
L_848775:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8775u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8775u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8775u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848775 BRA -> $8487A1
    goto L_8487A1;
L_848777:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8777u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8777u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8777u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848777 SEP
    cpu.sep(0x20u);
    goto L_848779;
L_848779:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8779u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8779u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8779u, 4u, 3u, cpu.address("abs", 0x06FDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848779 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x6FDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84877C;
L_84877C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x877Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x877Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x877Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84877C BEQ -> $8487A1
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8487A1; }
    goto L_84877E;
L_84877E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x877Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x877Eu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x877Eu, 4u, 3u, cpu.address("abs", 0x06FDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84877E STZ
    hw.write(cpu.address("abs", 0x6FDu), 0, cpu.m8?8:16);
    goto L_848781;
L_848781:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8781u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8781u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8781u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848781 BRA -> $84878F
    goto L_84878F;
L_848783:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8783u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8783u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8783u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848783 SEP
    cpu.sep(0x20u);
    goto L_848785;
L_848785:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8785u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8785u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8785u, 4u, 3u, cpu.address("abs", 0x06FDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848785 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x6FDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848788;
L_848788:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8788u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8788u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8788u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848788 BNE -> $8487A1
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8487A1; }
    goto L_84878A;
L_84878A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x878Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x878Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x878Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84878A LDA
    cpu.setA(0x1u, 8);
    goto L_84878C;
L_84878C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x878Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x878Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x878Cu, 4u, 3u, cpu.address("abs", 0x06FDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84878C STA
    hw.write(cpu.address("abs", 0x6FDu), cpu.a, cpu.m8?8:16);
    goto L_84878F;
L_84878F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x878Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x878Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x878Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84878F REP
    cpu.rep(0x20u);
    goto L_848791;
L_848791:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8791u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8791u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8791u, 5u, 3u, cpu.address("abs", 0x065Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848791 STZ
    hw.write(cpu.address("abs", 0x65Au), 0, cpu.m8?8:16);
    goto L_848794;
L_848794:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8794u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8794u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8794u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848794 LDA
    cpu.setA(0x1u, 16);
    goto L_848797;
L_848797:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8797u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8797u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8797u, 5u, 3u, cpu.address("abs", 0x06E9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848797 STA
    hw.write(cpu.address("abs", 0x6E9u), cpu.a, cpu.m8?8:16);
    goto L_84879A;
L_84879A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x879Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x879Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x879Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84879A LDA
    cpu.setA(0x7u, 16);
    goto L_84879D;
L_84879D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x879Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x879Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x879Du, 8u, 4u, 0x80A6FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84879D JSL -> $80A6FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x87A0u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x87A1u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6FBu, 0x84879Du); }
    goto L_8487A1;
L_8487A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87A1u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87A1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87A1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8487A1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8487A1u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8487A1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87A1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87A1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8487A1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8487A1u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8487A1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87A1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87A1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8487A1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8487A1u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8487A1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x87A1u,0x8487A1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_848F2B_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848F2Bu: goto L_848F2B;
    case 0x848F2Eu: goto L_848F2E;
    case 0x848F30u: goto L_848F30;
    case 0x848F32u: goto L_848F32;
    case 0x848F35u: goto L_848F35;
    case 0x848F37u: goto L_848F37;
    case 0x848F39u: goto L_848F39;
    case 0x848F3Cu: goto L_848F3C;
    case 0x848F3Eu: goto L_848F3E;
    case 0x848F40u: goto L_848F40;
    case 0x848F42u: goto L_848F42;
    case 0x848F45u: goto L_848F45;
    case 0x848F47u: goto L_848F47;
    case 0x848F4Au: goto L_848F4A;
    case 0x848F4Du: goto L_848F4D;
    case 0x848F50u: goto L_848F50;
    case 0x848F52u: goto L_848F52;
    case 0x848F55u: goto L_848F55;
    case 0x848F58u: goto L_848F58;
    case 0x848F5Au: goto L_848F5A;
    case 0x848F5Cu: goto L_848F5C;
    case 0x848F5Fu: goto L_848F5F;
    case 0x848F61u: goto L_848F61;
    case 0x848F64u: goto L_848F64;
    case 0x848F67u: goto L_848F67;
    case 0x848F6Au: goto L_848F6A;
    case 0x848F6Cu: goto L_848F6C;
    case 0x848F6Fu: goto L_848F6F;
    case 0x848F72u: goto L_848F72;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848F2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F2Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F2Bu, 6u, 3u, cpu.address("abs", 0x984Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848F2B JSR -> $84984F stack real
    { cpu.push16Value(hw,0x8F2Du); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8F2Eu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x984Fu), 0x848F2Bu); }
    goto L_848F2E;
L_848F2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F2Eu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F2Eu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F2Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F2E BCS -> $848F72
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_848F72; }
    goto L_848F30;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F2Eu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F2Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F2E BCS -> $848F72
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_848F72; }
    goto L_848F30;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8F2Eu,0x848F2Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848F30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F30u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F30u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F30u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F30 SEP
    cpu.sep(0x20u);
    goto L_848F32;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F30u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F30u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F30 SEP
    cpu.sep(0x20u);
    goto L_848F32;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8F30u,0x848F30u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848F32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F32u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F32u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F32u, 4u, 3u, cpu.address("abs", 0x062Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F32 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848F35;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F32u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F32u, 4u, 3u, cpu.address("abs", 0x062Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F32 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848F35;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8F32u,0x848F32u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848F35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F35u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F35u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F35u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F35 BIT
    cpu.bit(0x1u, true);
    goto L_848F37;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F35u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F35u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F35 BIT
    cpu.bit(0x1u, true);
    goto L_848F37;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8F35u,0x848F35u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848F37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F37u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F37u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F37u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F37 BEQ -> $848F5A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_848F5A; }
    goto L_848F39;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F37u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F37u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F37 BEQ -> $848F5A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_848F5A; }
    goto L_848F39;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8F37u,0x848F37u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848F39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F39u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F39u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F39u, 4u, 3u, cpu.address("abs", 0x06FDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F39 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x6FDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848F3C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F39u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F39u, 4u, 3u, cpu.address("abs", 0x06FDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F39 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x6FDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848F3C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8F39u,0x848F39u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848F3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F3Cu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F3Cu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F3Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F3C BIT
    cpu.bit(0x1u, true);
    goto L_848F3E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F3Cu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F3Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F3C BIT
    cpu.bit(0x1u, true);
    goto L_848F3E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8F3Cu,0x848F3Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848F3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F3Eu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F3Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F3Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F3E BEQ -> $848F5A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_848F5A; }
    goto L_848F40;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F3Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F3Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F3E BEQ -> $848F5A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_848F5A; }
    goto L_848F40;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8F3Eu,0x848F3Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848F40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F40u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F40u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F40u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F40 REP
    cpu.rep(0x20u);
    goto L_848F42;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F40u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F40u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F40 REP
    cpu.rep(0x20u);
    goto L_848F42;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8F40u,0x848F40u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848F42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F42u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F42u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F42u, 6u, 3u, cpu.address("abs", 0x98F9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848F42 JSR -> $8498F9 stack real
    { cpu.push16Value(hw,0x8F44u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8F45u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x98F9u), 0x848F42u); }
    goto L_848F45;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F42u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F42u, 6u, 3u, cpu.address("abs", 0x98F9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848F42 JSR -> $8498F9 stack real
    { cpu.push16Value(hw,0x8F44u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8F45u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x98F9u), 0x848F42u); }
    goto L_848F45;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8F42u,0x848F42u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848F45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F45u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F45u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F45u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F45 BCS -> $848F4D
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_848F4D; }
    goto L_848F47;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F45u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F45u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F45 BCS -> $848F4D
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_848F4D; }
    goto L_848F47;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8F45u,0x848F45u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848F47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F47u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F47u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F47u, 6u, 3u, cpu.address("abs", 0x96F7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848F47 JSR -> $8496F7 stack real
    { cpu.push16Value(hw,0x8F49u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8F4Au,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x96F7u), 0x848F47u); }
    goto L_848F4A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F47u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F47u, 6u, 3u, cpu.address("abs", 0x96F7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848F47 JSR -> $8496F7 stack real
    { cpu.push16Value(hw,0x8F49u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8F4Au,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x96F7u), 0x848F47u); }
    goto L_848F4A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8F47u,0x848F47u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848F4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F4Au))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8F4Au,0x848F4Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F4Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F4Au, 6u, 3u, cpu.address("abs", 0x9F1Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848F4A JSR -> $849F1F stack real
    { cpu.push16Value(hw,0x8F4Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8F4Du,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9F1Fu), 0x848F4Au); }
    goto L_848F4D;
L_848F4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F4Du))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F4Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F4Du, 6u, 3u, cpu.address("abs", 0x9C6Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848F4D JSR -> $849C6F stack real
    { cpu.push16Value(hw,0x8F4Fu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8F50u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9C6Fu), 0x848F4Du); }
    goto L_848F50;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F4Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F4Du, 6u, 3u, cpu.address("abs", 0x9C6Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848F4D JSR -> $849C6F stack real
    { cpu.push16Value(hw,0x8F4Fu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8F50u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9C6Fu), 0x848F4Du); }
    goto L_848F50;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F4Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F4Du, 6u, 3u, cpu.address("abs", 0x9C6Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848F4D JSR -> $849C6F stack real
    { cpu.push16Value(hw,0x8F4Fu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8F50u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9C6Fu), 0x848F4Du); }
    goto L_848F50;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8F4Du,0x848F4Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848F50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F50u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8F50u,0x848F50u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F50u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F50u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F50 SEP
    cpu.sep(0x20u);
    goto L_848F52;
L_848F52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F52u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F52u, 4u, 3u, cpu.address("abs", 0x06FEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F52 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x6FEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848F55;
L_848F55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F55u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F55u, 6u, 3u, cpu.address("abs", 0x8FDAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848F55 JSR -> $848FDA stack real
    { cpu.push16Value(hw,0x8F57u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8F58u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8FDAu), 0x848F55u); }
    goto L_848F58;
L_848F58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F58u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F58u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F58u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F58 BRA -> $848F72
    goto L_848F72;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F58u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F58u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F58 BRA -> $848F72
    goto L_848F72;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8F58u,0x848F58u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848F5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F5Au))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F5Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F5Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F5A REP
    cpu.rep(0x20u);
    goto L_848F5C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F5Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F5Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F5A REP
    cpu.rep(0x20u);
    goto L_848F5C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8F5Au,0x848F5Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848F5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F5Cu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F5Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F5Cu, 6u, 3u, cpu.address("abs", 0x98AAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848F5C JSR -> $8498AA stack real
    { cpu.push16Value(hw,0x8F5Eu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8F5Fu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x98AAu), 0x848F5Cu); }
    goto L_848F5F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F5Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F5Cu, 6u, 3u, cpu.address("abs", 0x98AAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848F5C JSR -> $8498AA stack real
    { cpu.push16Value(hw,0x8F5Eu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8F5Fu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x98AAu), 0x848F5Cu); }
    goto L_848F5F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8F5Cu,0x848F5Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848F5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F5Fu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F5Fu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F5Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F5F BCS -> $848F67
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_848F67; }
    goto L_848F61;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F5Fu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F5Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F5F BCS -> $848F67
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_848F67; }
    goto L_848F61;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8F5Fu,0x848F5Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848F61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F61u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F61u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F61u, 6u, 3u, cpu.address("abs", 0x977Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848F61 JSR -> $84977C stack real
    { cpu.push16Value(hw,0x8F63u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8F64u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x977Cu), 0x848F61u); }
    goto L_848F64;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F61u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F61u, 6u, 3u, cpu.address("abs", 0x977Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848F61 JSR -> $84977C stack real
    { cpu.push16Value(hw,0x8F63u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8F64u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x977Cu), 0x848F61u); }
    goto L_848F64;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8F61u,0x848F61u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848F64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F64u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8F64u,0x848F64u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F64u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F64u, 6u, 3u, cpu.address("abs", 0x9F1Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848F64 JSR -> $849F1F stack real
    { cpu.push16Value(hw,0x8F66u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8F67u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9F1Fu), 0x848F64u); }
    goto L_848F67;
L_848F67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F67u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F67u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F67u, 6u, 3u, cpu.address("abs", 0x9CB4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848F67 JSR -> $849CB4 stack real
    { cpu.push16Value(hw,0x8F69u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8F6Au,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9CB4u), 0x848F67u); }
    goto L_848F6A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F67u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F67u, 6u, 3u, cpu.address("abs", 0x9CB4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848F67 JSR -> $849CB4 stack real
    { cpu.push16Value(hw,0x8F69u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8F6Au,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9CB4u), 0x848F67u); }
    goto L_848F6A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F67u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F67u, 6u, 3u, cpu.address("abs", 0x9CB4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848F67 JSR -> $849CB4 stack real
    { cpu.push16Value(hw,0x8F69u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8F6Au,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9CB4u), 0x848F67u); }
    goto L_848F6A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8F67u,0x848F67u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848F6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F6Au))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8F6Au,0x848F6Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F6Au,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F6Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F6A SEP
    cpu.sep(0x20u);
    goto L_848F6C;
L_848F6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F6Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F6Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F6Cu, 4u, 3u, cpu.address("abs", 0x062Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F6C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848F6F;
L_848F6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F6Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F6Fu, 6u, 3u, cpu.address("abs", 0x8FB6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848F6F JSR -> $848FB6 stack real
    { cpu.push16Value(hw,0x8F71u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8F72u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8FB6u), 0x848F6Fu); }
    goto L_848F72;
L_848F72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F72u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F72u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F72u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848F72 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848F72u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848F72u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F72u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F72u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848F72 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848F72u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848F72u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F72u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F72u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848F72 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848F72u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848F72u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8F72u,0x848F72u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_849ABA_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x849ABAu: goto L_849ABA;
    case 0x849ABCu: goto L_849ABC;
    case 0x849ABEu: goto L_849ABE;
    case 0x849AC1u: goto L_849AC1;
    case 0x849AC3u: goto L_849AC3;
    case 0x849AC6u: goto L_849AC6;
    case 0x849AC8u: goto L_849AC8;
    case 0x849ACBu: goto L_849ACB;
    case 0x849ACDu: goto L_849ACD;
    case 0x849ACFu: goto L_849ACF;
    case 0x849AD1u: goto L_849AD1;
    case 0x849AD4u: goto L_849AD4;
    case 0x849AD6u: goto L_849AD6;
    case 0x849AD8u: goto L_849AD8;
    case 0x849ADBu: goto L_849ADB;
    case 0x849ADEu: goto L_849ADE;
    case 0x849AE0u: goto L_849AE0;
    case 0x849AE2u: goto L_849AE2;
    case 0x849AE5u: goto L_849AE5;
    case 0x849AE7u: goto L_849AE7;
    case 0x849AEAu: goto L_849AEA;
    case 0x849AECu: goto L_849AEC;
    case 0x849AEFu: goto L_849AEF;
    case 0x849AF1u: goto L_849AF1;
    case 0x849AF4u: goto L_849AF4;
    case 0x849AF7u: goto L_849AF7;
    case 0x849AF9u: goto L_849AF9;
    case 0x849AFCu: goto L_849AFC;
    case 0x849AFFu: goto L_849AFF;
    case 0x849B02u: goto L_849B02;
    case 0x849B04u: goto L_849B04;
    case 0x849B07u: goto L_849B07;
    case 0x849B0Au: goto L_849B0A;
    case 0x849B0Cu: goto L_849B0C;
    case 0x849B0Fu: goto L_849B0F;
    case 0x849B12u: goto L_849B12;
    case 0x849B15u: goto L_849B15;
    case 0x849B17u: goto L_849B17;
    case 0x849B1Au: goto L_849B1A;
    case 0x849B1Du: goto L_849B1D;
    case 0x849B1Fu: goto L_849B1F;
    case 0x849B21u: goto L_849B21;
    case 0x849B24u: goto L_849B24;
    case 0x849B28u: goto L_849B28;
    case 0x849B2Bu: goto L_849B2B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_849ABA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ABAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ABAu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ABAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849ABA REP
    cpu.rep(0x20u);
    goto L_849ABC;
L_849ABC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ABCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ABCu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ABCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849ABC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849ABE;
L_849ABE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ABEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ABEu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ABEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849ABE BIT
    cpu.bit(0x300u, true);
    goto L_849AC1;
L_849AC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AC1u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AC1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849AC1 BNE -> $849AC8
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_849AC8; }
    goto L_849AC3;
L_849AC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AC3u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AC3u, 5u, 3u, cpu.address("abs", 0x0660u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849AC3 STZ
    hw.write(cpu.address("abs", 0x660u), 0, cpu.m8?8:16);
    goto L_849AC6;
L_849AC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AC6u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AC6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849AC6 BRA -> $849B2B
    goto L_849B2B;
L_849AC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AC8u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AC8u, 5u, 3u, cpu.address("abs", 0x0660u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849AC8 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x660u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849ACB;
L_849ACB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ACBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ACBu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ACBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849ACB BEQ -> $849AD8
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_849AD8; }
    goto L_849ACD;
L_849ACD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ACDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ACDu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ACDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849ACD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849ACF;
L_849ACF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ACFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ACFu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ACFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849ACF BNE -> $849B2B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_849B2B; }
    goto L_849AD1;
L_849AD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AD1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AD1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849AD1 LDA
    cpu.setA(0x4u, 16);
    goto L_849AD4;
L_849AD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AD4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AD4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AD4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849AD4 STA
    hw.write(cpu.address("dp", 0x6Fu), cpu.a, cpu.m8?8:16);
    goto L_849AD6;
L_849AD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AD6u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AD6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849AD6 BRA -> $849AE0
    goto L_849AE0;
L_849AD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AD8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AD8u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AD8u, 8u, 3u, cpu.address("abs", 0x0660u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849AD8 INC
    cpu.incMem(hw, cpu.address("abs", 0x660u), cpu.m8?8:16);
    goto L_849ADB;
L_849ADB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ADBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ADBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ADBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849ADB LDA
    cpu.setA(0x10u, 16);
    goto L_849ADE;
L_849ADE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ADEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ADEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ADEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849ADE STA
    hw.write(cpu.address("dp", 0x6Fu), cpu.a, cpu.m8?8:16);
    goto L_849AE0;
L_849AE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AE0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AE0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849AE0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849AE2;
L_849AE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AE2u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AE2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849AE2 BIT
    cpu.bit(0x100u, true);
    goto L_849AE5;
L_849AE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AE5u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AE5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849AE5 BNE -> $849AF1
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_849AF1; }
    goto L_849AE7;
L_849AE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AE7u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AE7u, 9u, 3u, cpu.address("absx", 0x063Fu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849AE7 DEC
    cpu.decMem(hw, cpu.address("absx", 0x63Fu), cpu.m8?8:16);
    goto L_849AEA;
L_849AEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AEAu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AEAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849AEA BPL -> $849B1F
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_849B1F; }
    goto L_849AEC;
L_849AEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AECu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AECu, 6u, 3u, cpu.address("absx", 0x063Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849AEC STZ
    hw.write(cpu.address("absx", 0x63Fu), 0, cpu.m8?8:16);
    goto L_849AEF;
L_849AEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AEFu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AEFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849AEF BRA -> $849B2B
    goto L_849B2B;
L_849AF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AF1u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AF1u, 5u, 3u, cpu.address("abs", 0x0629u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849AF1 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x629u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849AF4;
L_849AF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AF4u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AF4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849AF4 BIT
    cpu.bit(0x1u, true);
    goto L_849AF7;
L_849AF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AF7u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AF7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849AF7 BNE -> $849B0C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_849B0C; }
    goto L_849AF9;
L_849AF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AF9u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AF9u, 9u, 3u, cpu.address("absx", 0x063Fu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849AF9 INC
    cpu.incMem(hw, cpu.address("absx", 0x63Fu), cpu.m8?8:16);
    goto L_849AFC;
L_849AFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AFCu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AFCu, 5u + 1u, 3u, cpu.address("absx", 0x063Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849AFC LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x63Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849AFF;
L_849AFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AFFu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AFFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849AFF CMP
    cpu.compareA(0x1Eu);
    goto L_849B02;
L_849B02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B02u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B02u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B02 BCC -> $849B1F
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_849B1F; }
    goto L_849B04;
L_849B04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B04u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B04u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B04 LDA
    cpu.setA(0x1Du, 16);
    goto L_849B07;
L_849B07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B07u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B07u, 6u, 3u, cpu.address("absx", 0x063Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B07 STA
    hw.write(cpu.address("absx", 0x63Fu), cpu.a, cpu.m8?8:16);
    goto L_849B0A;
L_849B0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B0Au,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B0Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B0A BRA -> $849B2B
    goto L_849B2B;
L_849B0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B0Cu,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B0Cu, 9u, 3u, cpu.address("absx", 0x063Fu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B0C INC
    cpu.incMem(hw, cpu.address("absx", 0x63Fu), cpu.m8?8:16);
    goto L_849B0F;
L_849B0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B0Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B0Fu, 5u + 1u, 3u, cpu.address("absx", 0x063Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B0F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x63Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849B12;
L_849B12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B12u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B12u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B12 CMP
    cpu.compareA(0xFu);
    goto L_849B15;
L_849B15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B15u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B15u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B15 BCC -> $849B1F
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_849B1F; }
    goto L_849B17;
L_849B17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B17u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B17u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B17 LDA
    cpu.setA(0xEu, 16);
    goto L_849B1A;
L_849B1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B1Au,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B1Au, 6u, 3u, cpu.address("absx", 0x063Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B1A STA
    hw.write(cpu.address("absx", 0x63Fu), cpu.a, cpu.m8?8:16);
    goto L_849B1D;
L_849B1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B1Du,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B1Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B1D BRA -> $849B2B
    goto L_849B2B;
L_849B1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B1Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B1Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B1F REP
    cpu.rep(0x20u);
    goto L_849B21;
L_849B21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B21u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B21u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B21 LDA
    cpu.setA(0x7u, 16);
    goto L_849B24;
L_849B24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B24u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B24u, 8u, 4u, 0x80A6FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849B24 JSL -> $80A6FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9B27u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9B28u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6FBu, 0x849B24u); }
    goto L_849B28;
L_849B28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B28u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9B28u,0x849B28u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B28u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B28u, 8u, 3u, cpu.address("abs", 0x06F7u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B28 INC
    cpu.incMem(hw, cpu.address("abs", 0x6F7u), cpu.m8?8:16);
    goto L_849B2B;
L_849B2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B2Bu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B2Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849B2B RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x849B2Bu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x849B2Bu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_849CCF_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x849CCFu: goto L_849CCF;
    case 0x849CD1u: goto L_849CD1;
    case 0x849CD4u: goto L_849CD4;
    case 0x849CD6u: goto L_849CD6;
    case 0x849CD8u: goto L_849CD8;
    case 0x849CDBu: goto L_849CDB;
    case 0x849CDCu: goto L_849CDC;
    case 0x849CDDu: goto L_849CDD;
    case 0x849CE0u: goto L_849CE0;
    case 0x849CE3u: goto L_849CE3;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_849CCF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CCFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCFu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CCF SEP
    cpu.sep(0x20u);
    goto L_849CD1;
L_849CD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD1u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD1u, 4u, 3u, cpu.address("abs", 0x062Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CD1 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849CD4;
L_849CD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CD4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CD4 AND
    cpu.logicAnd(0x1u);
    goto L_849CD6;
L_849CD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD6u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CD6 REP
    cpu.rep(0x20u);
    goto L_849CD8;
L_849CD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CD8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD8u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CD8 AND
    cpu.logicAnd(0xFFu);
    goto L_849CDB;
L_849CDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CDBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CDBu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CDBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CDB ASL
    cpu.aslA();
    goto L_849CDC;
L_849CDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CDCu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CDCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CDC TAX
    cpu.transfer("TAX");
    goto L_849CDD;
L_849CDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CDDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CDDu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CDDu, 5u, 3u, cpu.address("abs", 0x9CE2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849CDD PEA
    cpu.push16Value(hw, 0x9CE2u);
    goto L_849CE0;
L_849CE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CE0u,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CE0u, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x9CE4u + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $849CE0 JMP (9CE4,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x9CE4u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x849CE0u); return; }
L_849CE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CE3u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CE3u,0x849CE3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CE3u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CE3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849CE3 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x849CE3u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x849CE3u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_849CCF_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x849CCFu: goto L_849CCF;
    case 0x849CD1u: goto L_849CD1;
    case 0x849CD4u: goto L_849CD4;
    case 0x849CD6u: goto L_849CD6;
    case 0x849CD8u: goto L_849CD8;
    case 0x849CDBu: goto L_849CDB;
    case 0x849CDCu: goto L_849CDC;
    case 0x849CDDu: goto L_849CDD;
    case 0x849CE0u: goto L_849CE0;
    case 0x849CE3u: goto L_849CE3;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_849CCF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CCFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCFu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CCF SEP
    cpu.sep(0x20u);
    goto L_849CD1;
L_849CD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD1u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD1u, 4u, 3u, cpu.address("abs", 0x062Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CD1 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849CD4;
L_849CD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CD4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CD4 AND
    cpu.logicAnd(0x1u);
    goto L_849CD6;
L_849CD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD6u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CD6 REP
    cpu.rep(0x20u);
    goto L_849CD8;
L_849CD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CD8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD8u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CD8 AND
    cpu.logicAnd(0xFFu);
    goto L_849CDB;
L_849CDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CDBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CDBu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CDBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CDB ASL
    cpu.aslA();
    goto L_849CDC;
L_849CDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CDCu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CDCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CDC TAX
    cpu.transfer("TAX");
    goto L_849CDD;
L_849CDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CDDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CDDu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CDDu, 5u, 3u, cpu.address("abs", 0x9CE2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849CDD PEA
    cpu.push16Value(hw, 0x9CE2u);
    goto L_849CE0;
L_849CE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CE0u,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CE0u, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x9CE4u + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $849CE0 JMP (9CE4,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x9CE4u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x849CE0u); return; }
L_849CE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CE3u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CE3u,0x849CE3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CE3u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CE3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849CE3 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x849CE3u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x849CE3u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_84B626_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84B626u: goto L_84B626;
    case 0x84B629u: goto L_84B629;
    case 0x84B62Bu: goto L_84B62B;
    case 0x84B62Eu: goto L_84B62E;
    case 0x84B630u: goto L_84B630;
    case 0x84B632u: goto L_84B632;
    case 0x84B636u: goto L_84B636;
    case 0x84B639u: goto L_84B639;
    case 0x84B63Bu: goto L_84B63B;
    case 0x84B63Eu: goto L_84B63E;
    case 0x84B640u: goto L_84B640;
    case 0x84B642u: goto L_84B642;
    case 0x84B646u: goto L_84B646;
    case 0x84B649u: goto L_84B649;
    case 0x84B64Bu: goto L_84B64B;
    case 0x84B64Eu: goto L_84B64E;
    case 0x84B650u: goto L_84B650;
    case 0x84B652u: goto L_84B652;
    case 0x84B656u: goto L_84B656;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84B626:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB626u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB626u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB626u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B626 LDA
    cpu.setA(0x1C00u, 16);
    goto L_84B629;
L_84B629:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB629u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB629u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB629u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xD3u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B629 STA
    hw.write(cpu.address("dp", 0xD3u), cpu.a, cpu.m8?8:16);
    goto L_84B62B;
L_84B62B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB62Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB62Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB62Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B62B LDA
    cpu.setA(0x2C86u, 16);
    goto L_84B62E;
L_84B62E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB62Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB62Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB62Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xCDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B62E STA
    hw.write(cpu.address("dp", 0xCDu), cpu.a, cpu.m8?8:16);
    goto L_84B630;
L_84B630:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB630u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB630u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB630u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B630 STA
    hw.write(cpu.address("dp", 0xC9u), cpu.a, cpu.m8?8:16);
    goto L_84B632;
L_84B632:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB632u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB632u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB632u, 8u, 4u, 0x808F30u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B632 JSL -> $808F30 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB635u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB636u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808F30u, 0x84B632u); }
    goto L_84B636;
L_84B636:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB636u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB636u,0x84B636u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB636u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB636u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B636 LDA
    cpu.setA(0x800u, 16);
    goto L_84B639;
L_84B639:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB639u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB639u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB639u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xD3u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B639 STA
    hw.write(cpu.address("dp", 0xD3u), cpu.a, cpu.m8?8:16);
    goto L_84B63B;
L_84B63B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB63Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB63Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB63Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B63B LDA
    cpu.setA(0x2C98u, 16);
    goto L_84B63E;
L_84B63E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB63Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB63Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB63Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xCDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B63E STA
    hw.write(cpu.address("dp", 0xCDu), cpu.a, cpu.m8?8:16);
    goto L_84B640;
L_84B640:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB640u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB640u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB640u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B640 STA
    hw.write(cpu.address("dp", 0xC9u), cpu.a, cpu.m8?8:16);
    goto L_84B642;
L_84B642:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB642u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB642u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB642u, 8u, 4u, 0x808F30u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B642 JSL -> $808F30 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB645u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB646u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808F30u, 0x84B642u); }
    goto L_84B646;
L_84B646:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB646u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB646u,0x84B646u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB646u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB646u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B646 LDA
    cpu.setA(0x800u, 16);
    goto L_84B649;
L_84B649:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB649u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB649u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB649u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xD3u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B649 STA
    hw.write(cpu.address("dp", 0xD3u), cpu.a, cpu.m8?8:16);
    goto L_84B64B;
L_84B64B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB64Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB64Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB64Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B64B LDA
    cpu.setA(0x2CAAu, 16);
    goto L_84B64E;
L_84B64E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB64Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB64Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB64Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xCDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B64E STA
    hw.write(cpu.address("dp", 0xCDu), cpu.a, cpu.m8?8:16);
    goto L_84B650;
L_84B650:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB650u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB650u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB650u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B650 STA
    hw.write(cpu.address("dp", 0xC9u), cpu.a, cpu.m8?8:16);
    goto L_84B652;
L_84B652:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB652u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB652u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB652u, 8u, 4u, 0x808F30u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B652 JSL -> $808F30 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB655u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB656u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808F30u, 0x84B652u); }
    goto L_84B656;
L_84B656:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB656u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB656u,0x84B656u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB656u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB656u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B656 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84B656u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84B656u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_84B6EF_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84B6EFu: goto L_84B6EF;
    case 0x84B6F1u: goto L_84B6F1;
    case 0x84B6F2u: goto L_84B6F2;
    case 0x84B6F5u: goto L_84B6F5;
    case 0x84B6F8u: goto L_84B6F8;
    case 0x84B6FBu: goto L_84B6FB;
    case 0x84B6FEu: goto L_84B6FE;
    case 0x84B701u: goto L_84B701;
    case 0x84B704u: goto L_84B704;
    case 0x84B707u: goto L_84B707;
    case 0x84B70Au: goto L_84B70A;
    case 0x84B70Bu: goto L_84B70B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84B6EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EFu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6EF REP
    cpu.rep(0x20u);
    goto L_84B6F1;
L_84B6F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F1u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F1u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $84B6F1 PHB
    cpu.push("PHB", hw);
    goto L_84B6F2;
L_84B6F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F2u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6F2 LDX
    cpu.setX(0xAB6Cu, 16);
    goto L_84B6F5;
L_84B6F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F5u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6F5 LDY
    cpu.setY(0x1900u, 16);
    goto L_84B6F8;
L_84B6F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6F8 LDA
    cpu.setA(0x5Fu, 16);
    goto L_84B6FB;
L_84B6FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6FBu,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xB6FBu, (std::uint32_t(cpu.a)+1u), 0x8Au, 0x84u);
    // $84B6FB MVN
    cpu.blockMove(hw, 0x84u, 0x8Au, false);
    goto L_84B6FE;
L_84B6FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6FEu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6FEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6FE LDX
    cpu.setX(0x994Cu, 16);
    goto L_84B701;
L_84B701:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB701u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB701u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB701u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B701 LDY
    cpu.setY(0x1AE0u, 16);
    goto L_84B704;
L_84B704:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB704u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB704u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB704u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B704 LDA
    cpu.setA(0x1Fu, 16);
    goto L_84B707;
L_84B707:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB707u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB707u,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xB707u, (std::uint32_t(cpu.a)+1u), 0x8Au, 0x84u);
    // $84B707 MVN
    cpu.blockMove(hw, 0x84u, 0x8Au, false);
    goto L_84B70A;
L_84B70A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB70Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB70Au,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB70Au, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $84B70A PLB
    cpu.pop("PLB", hw);
    goto L_84B70B;
L_84B70B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB70Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB70Bu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB70Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B70B RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84B70Bu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84B70Bu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_84BFC7_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84BFC7u: goto L_84BFC7;
    case 0x84BFC9u: goto L_84BFC9;
    case 0x84BFCBu: goto L_84BFCB;
    case 0x84BFCDu: goto L_84BFCD;
    case 0x84BFD1u: goto L_84BFD1;
    case 0x84BFD5u: goto L_84BFD5;
    case 0x84BFD7u: goto L_84BFD7;
    case 0x84BFDAu: goto L_84BFDA;
    case 0x84BFDDu: goto L_84BFDD;
    case 0x84BFE1u: goto L_84BFE1;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84BFC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFC7u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFC7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BFC7 SEP
    cpu.sep(0x20u);
    goto L_84BFC9;
L_84BFC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFC9u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFC9u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BFC9 INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_84BFCB;
L_84BFCB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFCBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFCBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFCBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BFCB LDA
    cpu.setA(0x10u, 8);
    goto L_84BFCD;
L_84BFCD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFCDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFCDu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFCDu, 8u, 4u, 0x80A6BDu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84BFCD JSL -> $80A6BD stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBFD0u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBFD1u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6BDu, 0x84BFCDu); }
    goto L_84BFD1;
L_84BFD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFD1u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBFD1u,0x84BFD1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFD1u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFD1u, 8u, 4u, 0x80A6A5u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84BFD1 JSL -> $80A6A5 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBFD4u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBFD5u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6A5u, 0x84BFD1u); }
    goto L_84BFD5;
L_84BFD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFD5u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBFD5u,0x84BFD5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFD5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFD5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BFD5 LDA
    cpu.setA(0x1u, 8);
    goto L_84BFD7;
L_84BFD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFD7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFD7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFD7u, 4u, 3u, cpu.address("abs", 0x01BFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BFD7 STA
    hw.write(cpu.address("abs", 0x1BFu), cpu.a, cpu.m8?8:16);
    goto L_84BFDA;
L_84BFDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFDAu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFDAu, 4u, 3u, cpu.address("abs", 0x01C0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BFDA STZ
    hw.write(cpu.address("abs", 0x1C0u), 0, cpu.m8?8:16);
    goto L_84BFDD;
L_84BFDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFDDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFDDu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFDDu, 8u, 4u, 0x808D2Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84BFDD JSL -> $808D2F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBFE0u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBFE1u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808D2Fu, 0x84BFDDu); }
    goto L_84BFE1;
L_84BFE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFE1u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBFE1u,0x84BFE1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFE1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFE1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84BFE1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84BFE1u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84BFE1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_DC049A_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xDC049Au: goto L_DC049A;
    case 0xDC049Cu: goto L_DC049C;
    case 0xDC049Eu: goto L_DC049E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_DC049A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x049Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x049Au,cpu,0x34u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x049Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xC8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $DC049A BIT
    cpu.bit(hw.readW(cpu.address("dpx", 0xC8u), cpu.m8?8:16), false);
    goto L_DC049C;
L_DC049C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x049Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x049Cu,cpu,0x34u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x049Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xCAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $DC049C BIT
    cpu.bit(hw.readW(cpu.address("dpx", 0xCAu), cpu.m8?8:16), false);
    goto L_DC049E;
L_DC049E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x049Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x049Eu,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x049Eu, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x7FC0u + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $DC049E JMP (7FC0,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x7FC0u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0xDC049Eu); return; }
}

