#include "generated.hpp"
void sub_6085AD_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x6085ADu: goto L_6085AD;
    case 0x6085AFu: goto L_6085AF;
    case 0x6085B2u: goto L_6085B2;
    case 0x6085B4u: goto L_6085B4;
    case 0x6085B7u: goto L_6085B7;
    case 0x6085B9u: goto L_6085B9;
    case 0x6085BCu: goto L_6085BC;
    case 0x6085BEu: goto L_6085BE;
    case 0x6085C1u: goto L_6085C1;
    case 0x6085C3u: goto L_6085C3;
    case 0x6085C6u: goto L_6085C6;
    case 0x6085C8u: goto L_6085C8;
    case 0x6085CBu: goto L_6085CB;
    case 0x6085CDu: goto L_6085CD;
    case 0x6085D0u: goto L_6085D0;
    case 0x6085D2u: goto L_6085D2;
    case 0x6085D5u: goto L_6085D5;
    case 0x6085D7u: goto L_6085D7;
    case 0x6085DAu: goto L_6085DA;
    case 0x6085DCu: goto L_6085DC;
    case 0x6085DFu: goto L_6085DF;
    case 0x6085E1u: goto L_6085E1;
    case 0x6085E4u: goto L_6085E4;
    case 0x6085E6u: goto L_6085E6;
    case 0x6085E9u: goto L_6085E9;
    case 0x6085EBu: goto L_6085EB;
    case 0x6085EEu: goto L_6085EE;
    case 0x6085F0u: goto L_6085F0;
    case 0x6085F3u: goto L_6085F3;
    case 0x6085F5u: goto L_6085F5;
    case 0x6085F8u: goto L_6085F8;
    case 0x6085FAu: goto L_6085FA;
    case 0x6085FDu: goto L_6085FD;
    case 0x608600u: goto L_608600;
    case 0x608603u: goto L_608603;
    case 0x608606u: goto L_608606;
    case 0x608609u: goto L_608609;
    case 0x60860Cu: goto L_60860C;
    case 0x60860Fu: goto L_60860F;
    case 0x608612u: goto L_608612;
    case 0x608615u: goto L_608615;
    case 0x608618u: goto L_608618;
    case 0x60861Bu: goto L_60861B;
    case 0x60861Eu: goto L_60861E;
    case 0x608621u: goto L_608621;
    case 0x608624u: goto L_608624;
    case 0x608627u: goto L_608627;
    case 0x60862Au: goto L_60862A;
    case 0x60862Du: goto L_60862D;
    case 0x608630u: goto L_608630;
    case 0x608633u: goto L_608633;
    case 0x608636u: goto L_608636;
    case 0x608639u: goto L_608639;
    case 0x60863Cu: goto L_60863C;
    case 0x60863Fu: goto L_60863F;
    case 0x608642u: goto L_608642;
    case 0x608645u: goto L_608645;
    case 0x608647u: goto L_608647;
    case 0x60864Au: goto L_60864A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_6085AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85ADu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85ADu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6085AD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_6085AF;
L_6085AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85AFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85AFu, 5u, 3u, cpu.address("abs", 0x210Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6085AF STA
    hw.write(cpu.address("abs", 0x210Du), cpu.a, cpu.m8?8:16);
    goto L_6085B2;
L_6085B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85B2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85B2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6085B2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_6085B4;
L_6085B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85B4u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85B4u, 5u, 3u, cpu.address("abs", 0x210Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6085B4 STA
    hw.write(cpu.address("abs", 0x210Du), cpu.a, cpu.m8?8:16);
    goto L_6085B7;
L_6085B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85B7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85B7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x80u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6085B7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x80u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_6085B9;
L_6085B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85B9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85B9u, 5u, 3u, cpu.address("abs", 0x210Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6085B9 STA
    hw.write(cpu.address("abs", 0x210Eu), cpu.a, cpu.m8?8:16);
    goto L_6085BC;
L_6085BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85BCu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85BCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x81u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6085BC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x81u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_6085BE;
L_6085BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85BEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85BEu, 5u, 3u, cpu.address("abs", 0x210Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6085BE STA
    hw.write(cpu.address("abs", 0x210Eu), cpu.a, cpu.m8?8:16);
    goto L_6085C1;
L_6085C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85C1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85C1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x82u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6085C1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x82u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_6085C3;
L_6085C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85C3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85C3u, 5u, 3u, cpu.address("abs", 0x210Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6085C3 STA
    hw.write(cpu.address("abs", 0x210Fu), cpu.a, cpu.m8?8:16);
    goto L_6085C6;
L_6085C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85C6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85C6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x83u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6085C6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x83u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_6085C8;
L_6085C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85C8u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85C8u, 5u, 3u, cpu.address("abs", 0x210Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6085C8 STA
    hw.write(cpu.address("abs", 0x210Fu), cpu.a, cpu.m8?8:16);
    goto L_6085CB;
L_6085CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85CBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85CBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x84u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6085CB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x84u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_6085CD;
L_6085CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85CDu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85CDu, 5u, 3u, cpu.address("abs", 0x2110u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6085CD STA
    hw.write(cpu.address("abs", 0x2110u), cpu.a, cpu.m8?8:16);
    goto L_6085D0;
L_6085D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85D0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85D0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x85u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6085D0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x85u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_6085D2;
L_6085D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85D2u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85D2u, 5u, 3u, cpu.address("abs", 0x2110u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6085D2 STA
    hw.write(cpu.address("abs", 0x2110u), cpu.a, cpu.m8?8:16);
    goto L_6085D5;
L_6085D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85D5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85D5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x86u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6085D5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x86u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_6085D7;
L_6085D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85D7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85D7u, 5u, 3u, cpu.address("abs", 0x2111u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6085D7 STA
    hw.write(cpu.address("abs", 0x2111u), cpu.a, cpu.m8?8:16);
    goto L_6085DA;
L_6085DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85DAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85DAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x87u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6085DA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x87u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_6085DC;
L_6085DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85DCu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85DCu, 5u, 3u, cpu.address("abs", 0x2111u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6085DC STA
    hw.write(cpu.address("abs", 0x2111u), cpu.a, cpu.m8?8:16);
    goto L_6085DF;
L_6085DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85DFu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85DFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6085DF LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x88u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_6085E1;
L_6085E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85E1u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85E1u, 5u, 3u, cpu.address("abs", 0x2112u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6085E1 STA
    hw.write(cpu.address("abs", 0x2112u), cpu.a, cpu.m8?8:16);
    goto L_6085E4;
L_6085E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85E4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85E4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x89u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6085E4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x89u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_6085E6;
L_6085E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85E6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85E6u, 5u, 3u, cpu.address("abs", 0x2112u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6085E6 STA
    hw.write(cpu.address("abs", 0x2112u), cpu.a, cpu.m8?8:16);
    goto L_6085E9;
L_6085E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85E9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85E9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6085E9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_6085EB;
L_6085EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85EBu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85EBu, 5u, 3u, cpu.address("abs", 0x2113u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6085EB STA
    hw.write(cpu.address("abs", 0x2113u), cpu.a, cpu.m8?8:16);
    goto L_6085EE;
L_6085EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85EEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85EEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6085EE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_6085F0;
L_6085F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85F0u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85F0u, 5u, 3u, cpu.address("abs", 0x2113u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6085F0 STA
    hw.write(cpu.address("abs", 0x2113u), cpu.a, cpu.m8?8:16);
    goto L_6085F3;
L_6085F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85F3u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85F3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6085F3 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_6085F5;
L_6085F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85F5u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85F5u, 5u, 3u, cpu.address("abs", 0x2114u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6085F5 STA
    hw.write(cpu.address("abs", 0x2114u), cpu.a, cpu.m8?8:16);
    goto L_6085F8;
L_6085F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85F8u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85F8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6085F8 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_6085FA;
L_6085FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85FAu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85FAu, 5u, 3u, cpu.address("abs", 0x2114u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6085FA STA
    hw.write(cpu.address("abs", 0x2114u), cpu.a, cpu.m8?8:16);
    goto L_6085FD;
L_6085FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85FDu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85FDu, 5u, 3u, cpu.address("abs", 0x0100u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6085FD LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x100u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_608600;
L_608600:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8600u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8600u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8600u, 5u, 3u, cpu.address("abs", 0x211Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608600 STA
    hw.write(cpu.address("abs", 0x211Bu), cpu.a, cpu.m8?8:16);
    goto L_608603;
L_608603:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8603u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8603u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8603u, 5u, 3u, cpu.address("abs", 0x0101u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608603 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x101u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_608606;
L_608606:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8606u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8606u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8606u, 5u, 3u, cpu.address("abs", 0x211Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608606 STA
    hw.write(cpu.address("abs", 0x211Bu), cpu.a, cpu.m8?8:16);
    goto L_608609;
L_608609:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8609u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8609u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8609u, 5u, 3u, cpu.address("abs", 0x0102u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608609 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x102u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_60860C;
L_60860C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x860Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x860Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x860Cu, 5u, 3u, cpu.address("abs", 0x211Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60860C STA
    hw.write(cpu.address("abs", 0x211Cu), cpu.a, cpu.m8?8:16);
    goto L_60860F;
L_60860F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x860Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x860Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x860Fu, 5u, 3u, cpu.address("abs", 0x0103u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60860F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x103u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_608612;
L_608612:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8612u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8612u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8612u, 5u, 3u, cpu.address("abs", 0x211Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608612 STA
    hw.write(cpu.address("abs", 0x211Cu), cpu.a, cpu.m8?8:16);
    goto L_608615;
L_608615:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8615u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8615u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8615u, 5u, 3u, cpu.address("abs", 0x0104u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608615 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x104u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_608618;
L_608618:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8618u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8618u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8618u, 5u, 3u, cpu.address("abs", 0x211Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608618 STA
    hw.write(cpu.address("abs", 0x211Du), cpu.a, cpu.m8?8:16);
    goto L_60861B;
L_60861B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x861Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x861Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x861Bu, 5u, 3u, cpu.address("abs", 0x0105u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60861B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x105u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_60861E;
L_60861E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x861Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x861Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x861Eu, 5u, 3u, cpu.address("abs", 0x211Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60861E STA
    hw.write(cpu.address("abs", 0x211Du), cpu.a, cpu.m8?8:16);
    goto L_608621;
L_608621:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8621u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8621u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8621u, 5u, 3u, cpu.address("abs", 0x0106u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608621 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x106u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_608624;
L_608624:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8624u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8624u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8624u, 5u, 3u, cpu.address("abs", 0x211Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608624 STA
    hw.write(cpu.address("abs", 0x211Eu), cpu.a, cpu.m8?8:16);
    goto L_608627;
L_608627:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8627u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8627u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8627u, 5u, 3u, cpu.address("abs", 0x0107u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608627 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x107u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_60862A;
L_60862A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x862Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x862Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x862Au, 5u, 3u, cpu.address("abs", 0x211Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60862A STA
    hw.write(cpu.address("abs", 0x211Eu), cpu.a, cpu.m8?8:16);
    goto L_60862D;
L_60862D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x862Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x862Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x862Du, 5u, 3u, cpu.address("abs", 0x0108u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60862D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x108u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_608630;
L_608630:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8630u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8630u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8630u, 5u, 3u, cpu.address("abs", 0x211Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608630 STA
    hw.write(cpu.address("abs", 0x211Fu), cpu.a, cpu.m8?8:16);
    goto L_608633;
L_608633:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8633u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8633u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8633u, 5u, 3u, cpu.address("abs", 0x0109u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608633 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x109u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_608636;
L_608636:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8636u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8636u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8636u, 5u, 3u, cpu.address("abs", 0x211Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608636 STA
    hw.write(cpu.address("abs", 0x211Fu), cpu.a, cpu.m8?8:16);
    goto L_608639;
L_608639:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8639u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8639u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8639u, 5u, 3u, cpu.address("abs", 0x010Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608639 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x10Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_60863C;
L_60863C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x863Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x863Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x863Cu, 5u, 3u, cpu.address("abs", 0x2120u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60863C STA
    hw.write(cpu.address("abs", 0x2120u), cpu.a, cpu.m8?8:16);
    goto L_60863F;
L_60863F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x863Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x863Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x863Fu, 5u, 3u, cpu.address("abs", 0x010Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60863F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x10Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_608642;
L_608642:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8642u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8642u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8642u, 5u, 3u, cpu.address("abs", 0x2120u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608642 STA
    hw.write(cpu.address("abs", 0x2120u), cpu.a, cpu.m8?8:16);
    goto L_608645;
L_608645:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8645u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8645u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8645u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608645 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x77u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_608647;
L_608647:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8647u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8647u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8647u, 5u, 3u, cpu.address("abs", 0x2106u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608647 STA
    hw.write(cpu.address("abs", 0x2106u), cpu.a, cpu.m8?8:16);
    goto L_60864A;
L_60864A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x864Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x864Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x864Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $60864A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x60864Au);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x60864Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_808419_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808419u: goto L_808419;
    case 0x80841Du: goto L_80841D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808419:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8419u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8419u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8419u, 8u, 4u, 0x84C5D5u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808419 JSL -> $84C5D5 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x841Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x841Du,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84C5D5u, 0x808419u); }
    goto L_80841D;
L_80841D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x841Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x841Du,0x80841Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x841Du,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x841Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80841D RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80841Du);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80841Du,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_808419_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808419u: goto L_808419;
    case 0x80841Du: goto L_80841D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808419:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8419u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8419u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8419u, 8u, 4u, 0x84C5D5u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808419 JSL -> $84C5D5 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x841Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x841Du,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84C5D5u, 0x808419u); }
    goto L_80841D;
L_80841D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x841Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x841Du,0x80841Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x841Du,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x841Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80841D RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80841Du);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80841Du,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_808426_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808426u: goto L_808426;
    case 0x808429u: goto L_808429;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808426:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8426u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8426u,cpu,0x3Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8426u, 5u + 1u, 3u, cpu.address("absx", 0x82AFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808426 BIT
    cpu.bit(hw.readW(cpu.address("absx", 0x82AFu), cpu.m8?8:16), false);
    goto L_808429;
L_808429:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8429u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8429u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8429u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808429 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808429u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x808429u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80846C_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80846Cu: goto L_80846C;
    case 0x80846Du: goto L_80846D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80846C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x846Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x846Cu,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x846Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80846C PLP
    cpu.pop("PLP", hw);
    goto L_80846D;
L_80846D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x846Du))return;
  // 4 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x846Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x846Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80846D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80846Du);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80846Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x846Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x846Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80846D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80846Du);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80846Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x846Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x846Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80846D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80846Du);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80846Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x846Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x846Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80846D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80846Du);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80846Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x846Du,0x80846Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80846C_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80846Cu: goto L_80846C;
    case 0x80846Du: goto L_80846D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80846C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x846Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x846Cu,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x846Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80846C PLP
    cpu.pop("PLP", hw);
    goto L_80846D;
L_80846D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x846Du))return;
  // 4 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x846Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x846Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80846D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80846Du);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80846Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x846Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x846Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80846D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80846Du);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80846Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x846Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x846Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80846D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80846Du);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80846Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x846Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x846Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80846D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80846Du);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80846Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x846Du,0x80846Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_808580_E0M1X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808580u: goto L_808580;
    case 0x808581u: goto L_808581;
    case 0x808583u: goto L_808583;
    case 0x808585u: goto L_808585;
    case 0x808587u: goto L_808587;
    case 0x808589u: goto L_808589;
    case 0x80858Bu: goto L_80858B;
    case 0x80858Cu: goto L_80858C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808580:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8580u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8580u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8580u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808580 PHP
    cpu.push("PHP", hw);
    goto L_808581;
L_808581:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8581u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8581u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8581u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808581 REP
    cpu.rep(0x20u);
    goto L_808583;
L_808583:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8583u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8583u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8583u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808583 STZ
    hw.write(cpu.address("dp", 0x9Cu), 0, cpu.m8?8:16);
    goto L_808585;
L_808585:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8585u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8585u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8585u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808585 STZ
    hw.write(cpu.address("dp", 0x9Eu), 0, cpu.m8?8:16);
    goto L_808587;
L_808587:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8587u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8587u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8587u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808587 STZ
    hw.write(cpu.address("dp", 0xA0u), 0, cpu.m8?8:16);
    goto L_808589;
L_808589:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8589u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8589u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8589u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808589 STZ
    hw.write(cpu.address("dp", 0xA2u), 0, cpu.m8?8:16);
    goto L_80858B;
L_80858B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x858Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x858Bu,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x858Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80858B PLP
    cpu.pop("PLP", hw);
    goto L_80858C;
L_80858C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x858Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x858Cu,0x80858Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x858Cu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x858Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80858C RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80858Cu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80858Cu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_808580_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808580u: goto L_808580;
    case 0x808581u: goto L_808581;
    case 0x808583u: goto L_808583;
    case 0x808585u: goto L_808585;
    case 0x808587u: goto L_808587;
    case 0x808589u: goto L_808589;
    case 0x80858Bu: goto L_80858B;
    case 0x80858Cu: goto L_80858C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808580:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8580u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8580u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8580u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808580 PHP
    cpu.push("PHP", hw);
    goto L_808581;
L_808581:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8581u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8581u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8581u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808581 REP
    cpu.rep(0x20u);
    goto L_808583;
L_808583:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8583u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8583u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8583u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808583 STZ
    hw.write(cpu.address("dp", 0x9Cu), 0, cpu.m8?8:16);
    goto L_808585;
L_808585:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8585u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8585u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8585u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808585 STZ
    hw.write(cpu.address("dp", 0x9Eu), 0, cpu.m8?8:16);
    goto L_808587;
L_808587:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8587u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8587u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8587u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808587 STZ
    hw.write(cpu.address("dp", 0xA0u), 0, cpu.m8?8:16);
    goto L_808589;
L_808589:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8589u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8589u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8589u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808589 STZ
    hw.write(cpu.address("dp", 0xA2u), 0, cpu.m8?8:16);
    goto L_80858B;
L_80858B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x858Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x858Bu,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x858Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80858B PLP
    cpu.pop("PLP", hw);
    goto L_80858C;
L_80858C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x858Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x858Cu,0x80858Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x858Cu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x858Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80858C RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80858Cu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80858Cu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_809E05_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809E05u: goto L_809E05;
    case 0x809E08u: goto L_809E08;
    case 0x809E09u: goto L_809E09;
    case 0x809E0Au: goto L_809E0A;
    case 0x809E0Bu: goto L_809E0B;
    case 0x809E0Cu: goto L_809E0C;
    case 0x809E0Du: goto L_809E0D;
    case 0x809E10u: goto L_809E10;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809E05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E05u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E05u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E05 AND
    cpu.logicAnd(0x70u);
    goto L_809E08;
L_809E08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E08u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E08u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E08 LSR
    cpu.lsrA();
    goto L_809E09;
L_809E09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E09u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E09u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E09 LSR
    cpu.lsrA();
    goto L_809E0A;
L_809E0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E0Au,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E0Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E0A LSR
    cpu.lsrA();
    goto L_809E0B;
L_809E0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E0Bu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E0Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E0B LSR
    cpu.lsrA();
    goto L_809E0C;
L_809E0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E0Cu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E0Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E0C CLC
    cpu.setFlag('C', false);
    goto L_809E0D;
L_809E0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E0Du,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E0Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E0D ADC
    cpu.adc(0x17u);
    goto L_809E10;
L_809E10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E10u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E10u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809E10 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x809E10u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x809E10u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80A460_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80A460u: goto L_80A460;
    case 0x80A462u: goto L_80A462;
    case 0x80A465u: goto L_80A465;
    case 0x80A468u: goto L_80A468;
    case 0x80A46Bu: goto L_80A46B;
    case 0x80A46Eu: goto L_80A46E;
    case 0x80A472u: goto L_80A472;
    case 0x80A473u: goto L_80A473;
    case 0x80A476u: goto L_80A476;
    case 0x80A479u: goto L_80A479;
    case 0x80A47Cu: goto L_80A47C;
    case 0x80A47Fu: goto L_80A47F;
    case 0x80A480u: goto L_80A480;
    case 0x80A482u: goto L_80A482;
    case 0x80A484u: goto L_80A484;
    case 0x80A487u: goto L_80A487;
    case 0x80A48Au: goto L_80A48A;
    case 0x80A48Du: goto L_80A48D;
    case 0x80A490u: goto L_80A490;
    case 0x80A494u: goto L_80A494;
    case 0x80A495u: goto L_80A495;
    case 0x80A498u: goto L_80A498;
    case 0x80A49Bu: goto L_80A49B;
    case 0x80A49Eu: goto L_80A49E;
    case 0x80A4A1u: goto L_80A4A1;
    case 0x80A4A2u: goto L_80A4A2;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80A460:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA460u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA460u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA460u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A460 STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_80A462;
L_80A462:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA462u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA462u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA462u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A462 LDA
    cpu.setA(0xA425u, 16);
    goto L_80A465;
L_80A465:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA465u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA465u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA465u, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A465 STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_80A468;
L_80A468:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA468u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA468u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA468u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A468 LDA
    cpu.setA(0x8Du, 16);
    goto L_80A46B;
L_80A46B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA46Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA46Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA46Bu, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A46B STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_80A46E;
L_80A46E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA46Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA46Eu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA46Eu, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A46E JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA471u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA472u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x80A46Eu); }
    goto L_80A472;
L_80A472:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA472u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA472u,0x80A472u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA472u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA472u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A472 PHB
    cpu.push("PHB", hw);
    goto L_80A473;
L_80A473:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA473u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA473u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA473u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A473 LDX
    cpu.setX(0x8000u, 16);
    goto L_80A476;
L_80A476:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA476u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA476u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA476u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A476 LDY
    cpu.setY(0x1000u, 16);
    goto L_80A479;
L_80A479:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA479u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA479u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA479u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A479 LDA
    cpu.setA(0x1FFFu, 16);
    goto L_80A47C;
L_80A47C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA47Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA47Cu,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xA47Cu, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Fu);
    // $80A47C MVN
    cpu.blockMove(hw, 0x7Fu, 0x7Eu, false);
    goto L_80A47F;
L_80A47F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA47Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA47Fu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA47Fu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A47F PLB
    cpu.pop("PLB", hw);
    goto L_80A480;
L_80A480:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA480u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA480u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA480u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A480 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A482;
L_80A482:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA482u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA482u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA482u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A482 BMI -> $80A494
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_80A494; }
    goto L_80A484;
L_80A484:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA484u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA484u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA484u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A484 LDA
    cpu.setA(0xB204u, 16);
    goto L_80A487;
L_80A487:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA487u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA487u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA487u, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A487 STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_80A48A;
L_80A48A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA48Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA48Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA48Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A48A LDA
    cpu.setA(0x8Du, 16);
    goto L_80A48D;
L_80A48D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA48Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA48Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA48Du, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A48D STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_80A490;
L_80A490:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA490u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA490u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA490u, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A490 JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA493u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA494u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x80A490u); }
    goto L_80A494;
L_80A494:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA494u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA494u,0x80A494u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA494u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA494u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A494 PHB
    cpu.push("PHB", hw);
    goto L_80A495;
L_80A495:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA495u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA495u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA495u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A495 LDX
    cpu.setX(0x8000u, 16);
    goto L_80A498;
L_80A498:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA498u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA498u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA498u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A498 LDY
    cpu.setY(0x3000u, 16);
    goto L_80A49B;
L_80A49B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA49Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA49Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA49Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A49B LDA
    cpu.setA(0x1FFFu, 16);
    goto L_80A49E;
L_80A49E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA49Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA49Eu,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xA49Eu, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Fu);
    // $80A49E MVN
    cpu.blockMove(hw, 0x7Fu, 0x7Eu, false);
    goto L_80A4A1;
L_80A4A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A1u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A1u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A4A1 PLB
    cpu.pop("PLB", hw);
    goto L_80A4A2;
L_80A4A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A2u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A4A2 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80A4A2u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80A4A2u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80A460_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80A460u: goto L_80A460;
    case 0x80A462u: goto L_80A462;
    case 0x80A465u: goto L_80A465;
    case 0x80A468u: goto L_80A468;
    case 0x80A46Bu: goto L_80A46B;
    case 0x80A46Eu: goto L_80A46E;
    case 0x80A472u: goto L_80A472;
    case 0x80A473u: goto L_80A473;
    case 0x80A476u: goto L_80A476;
    case 0x80A479u: goto L_80A479;
    case 0x80A47Cu: goto L_80A47C;
    case 0x80A47Fu: goto L_80A47F;
    case 0x80A480u: goto L_80A480;
    case 0x80A482u: goto L_80A482;
    case 0x80A484u: goto L_80A484;
    case 0x80A487u: goto L_80A487;
    case 0x80A48Au: goto L_80A48A;
    case 0x80A48Du: goto L_80A48D;
    case 0x80A490u: goto L_80A490;
    case 0x80A494u: goto L_80A494;
    case 0x80A495u: goto L_80A495;
    case 0x80A498u: goto L_80A498;
    case 0x80A49Bu: goto L_80A49B;
    case 0x80A49Eu: goto L_80A49E;
    case 0x80A4A1u: goto L_80A4A1;
    case 0x80A4A2u: goto L_80A4A2;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80A460:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA460u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA460u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA460u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A460 STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_80A462;
L_80A462:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA462u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA462u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA462u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A462 LDA
    cpu.setA(0xA425u, 16);
    goto L_80A465;
L_80A465:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA465u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA465u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA465u, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A465 STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_80A468;
L_80A468:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA468u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA468u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA468u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A468 LDA
    cpu.setA(0x8Du, 16);
    goto L_80A46B;
L_80A46B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA46Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA46Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA46Bu, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A46B STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_80A46E;
L_80A46E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA46Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA46Eu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA46Eu, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A46E JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA471u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA472u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x80A46Eu); }
    goto L_80A472;
L_80A472:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA472u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA472u,0x80A472u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA472u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA472u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A472 PHB
    cpu.push("PHB", hw);
    goto L_80A473;
L_80A473:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA473u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA473u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA473u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A473 LDX
    cpu.setX(0x8000u, 16);
    goto L_80A476;
L_80A476:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA476u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA476u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA476u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A476 LDY
    cpu.setY(0x1000u, 16);
    goto L_80A479;
L_80A479:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA479u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA479u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA479u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A479 LDA
    cpu.setA(0x1FFFu, 16);
    goto L_80A47C;
L_80A47C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA47Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA47Cu,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xA47Cu, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Fu);
    // $80A47C MVN
    cpu.blockMove(hw, 0x7Fu, 0x7Eu, false);
    goto L_80A47F;
L_80A47F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA47Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA47Fu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA47Fu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A47F PLB
    cpu.pop("PLB", hw);
    goto L_80A480;
L_80A480:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA480u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA480u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA480u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A480 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A482;
L_80A482:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA482u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA482u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA482u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A482 BMI -> $80A494
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_80A494; }
    goto L_80A484;
L_80A484:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA484u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA484u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA484u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A484 LDA
    cpu.setA(0xB204u, 16);
    goto L_80A487;
L_80A487:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA487u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA487u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA487u, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A487 STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_80A48A;
L_80A48A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA48Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA48Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA48Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A48A LDA
    cpu.setA(0x8Du, 16);
    goto L_80A48D;
L_80A48D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA48Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA48Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA48Du, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A48D STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_80A490;
L_80A490:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA490u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA490u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA490u, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A490 JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA493u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA494u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x80A490u); }
    goto L_80A494;
L_80A494:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA494u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA494u,0x80A494u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA494u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA494u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A494 PHB
    cpu.push("PHB", hw);
    goto L_80A495;
L_80A495:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA495u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA495u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA495u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A495 LDX
    cpu.setX(0x8000u, 16);
    goto L_80A498;
L_80A498:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA498u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA498u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA498u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A498 LDY
    cpu.setY(0x3000u, 16);
    goto L_80A49B;
L_80A49B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA49Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA49Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA49Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A49B LDA
    cpu.setA(0x1FFFu, 16);
    goto L_80A49E;
L_80A49E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA49Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA49Eu,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xA49Eu, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Fu);
    // $80A49E MVN
    cpu.blockMove(hw, 0x7Fu, 0x7Eu, false);
    goto L_80A4A1;
L_80A4A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A1u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A1u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A4A1 PLB
    cpu.pop("PLB", hw);
    goto L_80A4A2;
L_80A4A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A2u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A4A2 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80A4A2u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80A4A2u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80A6BD_E0M1X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80A6BDu: goto L_80A6BD;
    case 0x80A6BEu: goto L_80A6BE;
    case 0x80A6C0u: goto L_80A6C0;
    case 0x80A6C2u: goto L_80A6C2;
    case 0x80A6C4u: goto L_80A6C4;
    case 0x80A6C5u: goto L_80A6C5;
    case 0x80A6C7u: goto L_80A6C7;
    case 0x80A6C8u: goto L_80A6C8;
    case 0x80A6C9u: goto L_80A6C9;
    case 0x80A6CDu: goto L_80A6CD;
    case 0x80A6CFu: goto L_80A6CF;
    case 0x80A6D3u: goto L_80A6D3;
    case 0x80A6D4u: goto L_80A6D4;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80A6BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6BDu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6BDu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A6BD PHA
    cpu.push("PHA", hw);
    goto L_80A6BE;
L_80A6BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6BEu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6BEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A6BE CMP
    cpu.compareA(0x80u);
    goto L_80A6C0;
L_80A6C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C0u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A6C0 BCS -> $80A6D3
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80A6D3; }
    goto L_80A6C2;
L_80A6C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C2u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A6C2 AND
    cpu.logicAnd(0x3Fu);
    goto L_80A6C4;
L_80A6C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C4u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C4u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A6C4 XBA
    cpu.xba();
    goto L_80A6C5;
L_80A6C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A6C5 LDA
    cpu.setA(0x0u, 8);
    goto L_80A6C7;
L_80A6C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C7u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C7u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A6C7 XBA
    cpu.xba();
    goto L_80A6C8;
L_80A6C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C8u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A6C8 TAX
    cpu.transfer("TAX");
    goto L_80A6C9;
L_80A6C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C9u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C9u, 5u, 4u, ((0x80A512u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A6C9 LDA
    cpu.loadA(hw.readW(((0x80A512u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A6CD;
L_80A6CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6CDu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6CDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A6CD BEQ -> $80A6D3
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80A6D3; }
    goto L_80A6CF;
L_80A6CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6CFu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6CFu, 8u, 4u, 0x80A5EBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A6CF JSL -> $80A5EB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA6D2u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA6D3u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A5EBu, 0x80A6CFu); }
    goto L_80A6D3;
L_80A6D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6D3u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA6D3u,0x80A6D3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D3u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D3u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A6D3 PLA
    cpu.pop("PLA", hw);
    goto L_80A6D4;
L_80A6D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D4u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A6D4 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80A6D4u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80A6D4u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80A6BD_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80A6BDu: goto L_80A6BD;
    case 0x80A6BEu: goto L_80A6BE;
    case 0x80A6C0u: goto L_80A6C0;
    case 0x80A6C2u: goto L_80A6C2;
    case 0x80A6C4u: goto L_80A6C4;
    case 0x80A6C5u: goto L_80A6C5;
    case 0x80A6C7u: goto L_80A6C7;
    case 0x80A6C8u: goto L_80A6C8;
    case 0x80A6C9u: goto L_80A6C9;
    case 0x80A6CDu: goto L_80A6CD;
    case 0x80A6CFu: goto L_80A6CF;
    case 0x80A6D3u: goto L_80A6D3;
    case 0x80A6D4u: goto L_80A6D4;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80A6BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6BDu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6BDu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A6BD PHA
    cpu.push("PHA", hw);
    goto L_80A6BE;
L_80A6BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6BEu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6BEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A6BE CMP
    cpu.compareA(0x80u);
    goto L_80A6C0;
L_80A6C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C0u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A6C0 BCS -> $80A6D3
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80A6D3; }
    goto L_80A6C2;
L_80A6C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C2u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A6C2 AND
    cpu.logicAnd(0x3Fu);
    goto L_80A6C4;
L_80A6C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C4u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C4u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A6C4 XBA
    cpu.xba();
    goto L_80A6C5;
L_80A6C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A6C5 LDA
    cpu.setA(0x0u, 8);
    goto L_80A6C7;
L_80A6C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C7u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C7u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A6C7 XBA
    cpu.xba();
    goto L_80A6C8;
L_80A6C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C8u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A6C8 TAX
    cpu.transfer("TAX");
    goto L_80A6C9;
L_80A6C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C9u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C9u, 5u, 4u, ((0x80A512u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A6C9 LDA
    cpu.loadA(hw.readW(((0x80A512u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A6CD;
L_80A6CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6CDu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6CDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A6CD BEQ -> $80A6D3
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80A6D3; }
    goto L_80A6CF;
L_80A6CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6CFu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6CFu, 8u, 4u, 0x80A5EBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A6CF JSL -> $80A5EB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA6D2u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA6D3u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A5EBu, 0x80A6CFu); }
    goto L_80A6D3;
L_80A6D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6D3u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA6D3u,0x80A6D3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D3u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D3u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A6D3 PLA
    cpu.pop("PLA", hw);
    goto L_80A6D4;
L_80A6D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D4u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A6D4 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80A6D4u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80A6D4u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80AB15_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80AB15u: goto L_80AB15;
    case 0x80AB17u: goto L_80AB17;
    case 0x80AB19u: goto L_80AB19;
    case 0x80AB1Bu: goto L_80AB1B;
    case 0x80AB1Du: goto L_80AB1D;
    case 0x80AB1Fu: goto L_80AB1F;
    case 0x80AB23u: goto L_80AB23;
    case 0x80AB27u: goto L_80AB27;
    case 0x80AB29u: goto L_80AB29;
    case 0x80AB2Du: goto L_80AB2D;
    case 0x80AB2Fu: goto L_80AB2F;
    case 0x80AB33u: goto L_80AB33;
    case 0x80AB35u: goto L_80AB35;
    case 0x80AB39u: goto L_80AB39;
    case 0x80AB3Bu: goto L_80AB3B;
    case 0x80AB3Fu: goto L_80AB3F;
    case 0x80AB41u: goto L_80AB41;
    case 0x80AB45u: goto L_80AB45;
    case 0x80AB47u: goto L_80AB47;
    case 0x80AB4Bu: goto L_80AB4B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80AB15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB15u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB15u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB15 SEP
    cpu.sep(0x20u);
    goto L_80AB17;
L_80AB17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB17u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB17u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x47u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB17 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x47u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AB19;
L_80AB19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB19u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB19u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB19 BPL -> $80AB4B
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80AB4B; }
    goto L_80AB1B;
L_80AB1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB1Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB1Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB1B AND
    cpu.logicAnd(0x7Fu);
    goto L_80AB1D;
L_80AB1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB1Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB1Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x47u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB1D STA
    hw.write(cpu.address("dp", 0x47u), cpu.a, cpu.m8?8:16);
    goto L_80AB1F;
L_80AB1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB1Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB1Fu, 8u, 4u, 0x808D3Cu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AB1F JSL -> $808D3C stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAB22u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAB23u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808D3Cu, 0x80AB1Fu); }
    goto L_80AB23;
L_80AB23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB23u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAB23u,0x80AB23u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB23u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB23u, 8u, 4u, 0x80A554u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AB23 JSL -> $80A554 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAB26u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAB27u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A554u, 0x80AB23u); }
    goto L_80AB27;
L_80AB27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB27u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAB27u,0x80AB27u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB27u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB27u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB27 LDA
    cpu.setA(0x0u, 8);
    goto L_80AB29;
L_80AB29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB29u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB29u, 8u, 4u, 0x80A5EBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AB29 JSL -> $80A5EB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAB2Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAB2Du,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A5EBu, 0x80AB29u); }
    goto L_80AB2D;
L_80AB2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB2Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAB2Du,0x80AB2Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB2Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB2Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB2D LDA
    cpu.setA(0x1u, 8);
    goto L_80AB2F;
L_80AB2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB2Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB2Fu, 8u, 4u, 0x80A5EBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AB2F JSL -> $80A5EB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAB32u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAB33u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A5EBu, 0x80AB2Fu); }
    goto L_80AB33;
L_80AB33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB33u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAB33u,0x80AB33u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB33u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB33u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB33 LDA
    cpu.setA(0x2u, 8);
    goto L_80AB35;
L_80AB35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB35u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB35u, 8u, 4u, 0x80A5EBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AB35 JSL -> $80A5EB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAB38u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAB39u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A5EBu, 0x80AB35u); }
    goto L_80AB39;
L_80AB39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB39u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAB39u,0x80AB39u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB39u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB39u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB39 LDA
    cpu.setA(0x3u, 8);
    goto L_80AB3B;
L_80AB3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB3Bu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB3Bu, 8u, 4u, 0x80A5EBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AB3B JSL -> $80A5EB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAB3Eu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAB3Fu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A5EBu, 0x80AB3Bu); }
    goto L_80AB3F;
L_80AB3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB3Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAB3Fu,0x80AB3Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB3Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB3Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB3F LDA
    cpu.setA(0x10u, 8);
    goto L_80AB41;
L_80AB41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB41u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB41u, 8u, 4u, 0x80A5EBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AB41 JSL -> $80A5EB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAB44u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAB45u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A5EBu, 0x80AB41u); }
    goto L_80AB45;
L_80AB45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB45u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAB45u,0x80AB45u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB45u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB45u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB45 INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_80AB47;
L_80AB47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB47u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB47u, 8u, 4u, 0x808D2Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AB47 JSL -> $808D2F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAB4Au); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAB4Bu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808D2Fu, 0x80AB47u); }
    goto L_80AB4B;
L_80AB4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB4Bu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAB4Bu,0x80AB4Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB4Bu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB4Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AB4B RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80AB4Bu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80AB4Bu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80AB15_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80AB15u: goto L_80AB15;
    case 0x80AB17u: goto L_80AB17;
    case 0x80AB19u: goto L_80AB19;
    case 0x80AB1Bu: goto L_80AB1B;
    case 0x80AB1Du: goto L_80AB1D;
    case 0x80AB1Fu: goto L_80AB1F;
    case 0x80AB23u: goto L_80AB23;
    case 0x80AB27u: goto L_80AB27;
    case 0x80AB29u: goto L_80AB29;
    case 0x80AB2Du: goto L_80AB2D;
    case 0x80AB2Fu: goto L_80AB2F;
    case 0x80AB33u: goto L_80AB33;
    case 0x80AB35u: goto L_80AB35;
    case 0x80AB39u: goto L_80AB39;
    case 0x80AB3Bu: goto L_80AB3B;
    case 0x80AB3Fu: goto L_80AB3F;
    case 0x80AB41u: goto L_80AB41;
    case 0x80AB45u: goto L_80AB45;
    case 0x80AB47u: goto L_80AB47;
    case 0x80AB4Bu: goto L_80AB4B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80AB15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB15u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB15u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB15 SEP
    cpu.sep(0x20u);
    goto L_80AB17;
L_80AB17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB17u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB17u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x47u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB17 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x47u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AB19;
L_80AB19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB19u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB19u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB19 BPL -> $80AB4B
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80AB4B; }
    goto L_80AB1B;
L_80AB1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB1Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB1Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB1B AND
    cpu.logicAnd(0x7Fu);
    goto L_80AB1D;
L_80AB1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB1Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB1Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x47u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB1D STA
    hw.write(cpu.address("dp", 0x47u), cpu.a, cpu.m8?8:16);
    goto L_80AB1F;
L_80AB1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB1Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB1Fu, 8u, 4u, 0x808D3Cu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AB1F JSL -> $808D3C stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAB22u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAB23u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808D3Cu, 0x80AB1Fu); }
    goto L_80AB23;
L_80AB23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB23u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAB23u,0x80AB23u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB23u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB23u, 8u, 4u, 0x80A554u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AB23 JSL -> $80A554 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAB26u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAB27u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A554u, 0x80AB23u); }
    goto L_80AB27;
L_80AB27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB27u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAB27u,0x80AB27u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB27u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB27u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB27 LDA
    cpu.setA(0x0u, 8);
    goto L_80AB29;
L_80AB29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB29u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB29u, 8u, 4u, 0x80A5EBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AB29 JSL -> $80A5EB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAB2Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAB2Du,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A5EBu, 0x80AB29u); }
    goto L_80AB2D;
L_80AB2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB2Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAB2Du,0x80AB2Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB2Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB2Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB2D LDA
    cpu.setA(0x1u, 8);
    goto L_80AB2F;
L_80AB2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB2Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB2Fu, 8u, 4u, 0x80A5EBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AB2F JSL -> $80A5EB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAB32u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAB33u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A5EBu, 0x80AB2Fu); }
    goto L_80AB33;
L_80AB33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB33u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAB33u,0x80AB33u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB33u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB33u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB33 LDA
    cpu.setA(0x2u, 8);
    goto L_80AB35;
L_80AB35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB35u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB35u, 8u, 4u, 0x80A5EBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AB35 JSL -> $80A5EB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAB38u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAB39u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A5EBu, 0x80AB35u); }
    goto L_80AB39;
L_80AB39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB39u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAB39u,0x80AB39u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB39u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB39u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB39 LDA
    cpu.setA(0x3u, 8);
    goto L_80AB3B;
L_80AB3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB3Bu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB3Bu, 8u, 4u, 0x80A5EBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AB3B JSL -> $80A5EB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAB3Eu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAB3Fu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A5EBu, 0x80AB3Bu); }
    goto L_80AB3F;
L_80AB3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB3Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAB3Fu,0x80AB3Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB3Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB3Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB3F LDA
    cpu.setA(0x10u, 8);
    goto L_80AB41;
L_80AB41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB41u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB41u, 8u, 4u, 0x80A5EBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AB41 JSL -> $80A5EB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAB44u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAB45u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A5EBu, 0x80AB41u); }
    goto L_80AB45;
L_80AB45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB45u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAB45u,0x80AB45u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB45u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB45u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB45 INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_80AB47;
L_80AB47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB47u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB47u, 8u, 4u, 0x808D2Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AB47 JSL -> $808D2F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAB4Au); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAB4Bu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808D2Fu, 0x80AB47u); }
    goto L_80AB4B;
L_80AB4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB4Bu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAB4Bu,0x80AB4Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB4Bu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB4Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AB4B RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80AB4Bu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80AB4Bu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80AB5D_E0M1X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80AB5Du: goto L_80AB5D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80AB5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB5Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB5Du,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB5Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AB5D RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80AB5Du);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80AB5Du,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80AB5D_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80AB5Du: goto L_80AB5D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80AB5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB5Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB5Du,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB5Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AB5D RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80AB5Du);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80AB5Du,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80AB7D_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80AB7Du: goto L_80AB7D;
    case 0x80AB7Fu: goto L_80AB7F;
    case 0x80AB81u: goto L_80AB81;
    case 0x80AB83u: goto L_80AB83;
    case 0x80AB85u: goto L_80AB85;
    case 0x80AB87u: goto L_80AB87;
    case 0x80AB8Au: goto L_80AB8A;
    case 0x80AB8Du: goto L_80AB8D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80AB7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB7Du,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB7Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB7D SEP
    cpu.sep(0x20u);
    goto L_80AB7F;
L_80AB7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB7Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB7Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB7F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x75u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AB81;
L_80AB81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB81u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB81u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB81 BNE -> $80AB8D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AB8D; }
    goto L_80AB83;
L_80AB83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB83u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB83u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB83 LDA
    cpu.setA(0x81u, 8);
    goto L_80AB85;
L_80AB85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB85u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB85u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x46u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB85 STA
    hw.write(cpu.address("dp", 0x46u), cpu.a, cpu.m8?8:16);
    goto L_80AB87;
L_80AB87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB87u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB87u, 4u, 3u, cpu.address("abs", 0x019Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB87 STZ
    hw.write(cpu.address("abs", 0x19Fu), 0, cpu.m8?8:16);
    goto L_80AB8A;
L_80AB8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB8Au,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB8Au, 4u, 3u, cpu.address("abs", 0x01A0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB8A STZ
    hw.write(cpu.address("abs", 0x1A0u), 0, cpu.m8?8:16);
    goto L_80AB8D;
L_80AB8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB8Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB8Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AB8D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80AB8Du);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80AB8Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80B151_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B151u: goto L_80B151;
    case 0x80B154u: goto L_80B154;
    case 0x80B156u: goto L_80B156;
    case 0x80B159u: goto L_80B159;
    case 0x80B15Bu: goto L_80B15B;
    case 0x80B15Eu: goto L_80B15E;
    case 0x80B161u: goto L_80B161;
    case 0x80B164u: goto L_80B164;
    case 0x80B166u: goto L_80B166;
    case 0x80B169u: goto L_80B169;
    case 0x80B16Cu: goto L_80B16C;
    case 0x80B16Fu: goto L_80B16F;
    case 0x80B172u: goto L_80B172;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B151:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB151u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB151u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB151u, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B151 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x958u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B154;
L_80B154:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB154u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB154u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB154u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B154 BEQ -> $80B16C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B16C; }
    goto L_80B156;
L_80B156:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB156u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB156u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB156u, 5u, 3u, cpu.address("abs", 0x0916u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B156 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x916u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B159;
L_80B159:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB159u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB159u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB159u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B159 BEQ -> $80B16C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B16C; }
    goto L_80B15B;
L_80B15B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB15Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB15Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB15Bu, 5u, 3u, cpu.address("abs", 0x097Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B15B STA
    hw.write(cpu.address("abs", 0x97Au), cpu.a, cpu.m8?8:16);
    goto L_80B15E;
L_80B15E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB15Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB15Eu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB15Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B15E LDX
    cpu.setX(0x3D8u, 16);
    goto L_80B161;
L_80B161:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB161u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB161u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB161u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B161 LDA
    cpu.setA(0x2u, 16);
    goto L_80B164;
L_80B164:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB164u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB164u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB164u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B164 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80B166;
L_80B166:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB166u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB166u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB166u, 8u, 3u, cpu.address("abs", 0x0986u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B166 INC
    cpu.incMem(hw, cpu.address("abs", 0x986u), cpu.m8?8:16);
    goto L_80B169;
L_80B169:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB169u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB169u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB169u, 6u, 3u, cpu.address("abs", 0xC85Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B169 JSR -> $80C85C stack real
    { cpu.push16Value(hw,0xB16Bu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB16Cu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC85Cu), 0x80B169u); }
    goto L_80B16C;
L_80B16C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB16Cu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB16Cu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB16Cu, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B16C STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80B16F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB16Cu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB16Cu, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B16C STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80B16F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB16Cu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB16Cu, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B16C STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80B16F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB16Cu,0x80B16Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B16F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB16Fu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB16Fu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB16Fu, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B16F INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B172;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB16Fu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB16Fu, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B16F INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B172;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB16Fu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB16Fu, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B16F INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B172;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB16Fu,0x80B16Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B172:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB172u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB172u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB172u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B172 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B172u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B172u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB172u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB172u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B172 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B172u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B172u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB172u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB172u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B172 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B172u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B172u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB172u,0x80B172u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80B30C_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B30Cu: goto L_80B30C;
    case 0x80B30Fu: goto L_80B30F;
    case 0x80B311u: goto L_80B311;
    case 0x80B314u: goto L_80B314;
    case 0x80B316u: goto L_80B316;
    case 0x80B319u: goto L_80B319;
    case 0x80B31Cu: goto L_80B31C;
    case 0x80B31Fu: goto L_80B31F;
    case 0x80B322u: goto L_80B322;
    case 0x80B325u: goto L_80B325;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B30C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB30Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB30Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB30Cu, 5u, 3u, cpu.address("abs", 0x0137u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B30C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x137u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B30F;
L_80B30F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB30Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB30Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB30Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B30F BEQ -> $80B31F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B31F; }
    goto L_80B311;
L_80B311:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB311u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB311u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB311u, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B311 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x958u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B314;
L_80B314:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB314u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB314u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB314u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B314 BEQ -> $80B31F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B31F; }
    goto L_80B316;
L_80B316:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB316u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB316u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB316u, 8u, 3u, cpu.address("abs", 0x0986u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B316 INC
    cpu.incMem(hw, cpu.address("abs", 0x986u), cpu.m8?8:16);
    goto L_80B319;
L_80B319:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB319u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB319u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB319u, 6u, 3u, cpu.address("abs", 0xD45Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B319 JSR -> $80D45E stack real
    { cpu.push16Value(hw,0xB31Bu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB31Cu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD45Eu), 0x80B319u); }
    goto L_80B31C;
L_80B31C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB31Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB31Cu,0x80B31Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB31Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB31Cu, 6u, 3u, cpu.address("abs", 0xCE62u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B31C JSR -> $80CE62 stack real
    { cpu.push16Value(hw,0xB31Eu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB31Fu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCE62u), 0x80B31Cu); }
    goto L_80B31F;
L_80B31F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB31Fu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB31Fu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB31Fu, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B31F STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80B322;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB31Fu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB31Fu, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B31F STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80B322;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB31Fu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB31Fu, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B31F STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80B322;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB31Fu,0x80B31Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B322:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB322u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB322u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB322u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B322 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B325;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB322u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB322u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B322 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B325;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB322u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB322u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B322 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B325;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB322u,0x80B322u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B325:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB325u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB325u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB325u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B325 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B325u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B325u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB325u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB325u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B325 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B325u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B325u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB325u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB325u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B325 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B325u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B325u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB325u,0x80B325u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80C1FD_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80C1FDu: goto L_80C1FD;
    case 0x80C200u: goto L_80C200;
    case 0x80C202u: goto L_80C202;
    case 0x80C205u: goto L_80C205;
    case 0x80C207u: goto L_80C207;
    case 0x80C208u: goto L_80C208;
    case 0x80C20Bu: goto L_80C20B;
    case 0x80C20Eu: goto L_80C20E;
    case 0x80C211u: goto L_80C211;
    case 0x80C213u: goto L_80C213;
    case 0x80C214u: goto L_80C214;
    case 0x80C217u: goto L_80C217;
    case 0x80C21Au: goto L_80C21A;
    case 0x80C21Du: goto L_80C21D;
    case 0x80C21Fu: goto L_80C21F;
    case 0x80C220u: goto L_80C220;
    case 0x80C223u: goto L_80C223;
    case 0x80C226u: goto L_80C226;
    case 0x80C229u: goto L_80C229;
    case 0x80C22Bu: goto L_80C22B;
    case 0x80C22Cu: goto L_80C22C;
    case 0x80C22Fu: goto L_80C22F;
    case 0x80C232u: goto L_80C232;
    case 0x80C235u: goto L_80C235;
    case 0x80C236u: goto L_80C236;
    case 0x80C239u: goto L_80C239;
    case 0x80C23Cu: goto L_80C23C;
    case 0x80C23Fu: goto L_80C23F;
    case 0x80C242u: goto L_80C242;
    case 0x80C244u: goto L_80C244;
    case 0x80C247u: goto L_80C247;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80C1FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1FDu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1FDu, 5u, 3u, cpu.address("abs", 0x0946u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C1FD LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x946u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C200;
L_80C200:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC200u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC200u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC200u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C200 BNE -> $80C244
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C244; }
    goto L_80C202;
L_80C202:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC202u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC202u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC202u, 5u, 3u, cpu.address("abs", 0x0960u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C202 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x960u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C205;
L_80C205:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC205u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC205u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC205u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C205 BMI -> $80C20E
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_80C20E; }
    goto L_80C207;
L_80C207:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC207u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC207u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC207u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C207 CLC
    cpu.setFlag('C', false);
    goto L_80C208;
L_80C208:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC208u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC208u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC208u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C208 ADC
    cpu.adc(0x16u);
    goto L_80C20B;
L_80C20B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC20Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC20Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC20Bu, 5u, 3u, cpu.address("abs", 0x0960u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C20B STA
    hw.write(cpu.address("abs", 0x960u), cpu.a, cpu.m8?8:16);
    goto L_80C20E;
L_80C20E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC20Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC20Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC20Eu, 5u, 3u, cpu.address("abs", 0x0962u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C20E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x962u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C211;
L_80C211:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC211u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC211u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC211u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C211 BMI -> $80C21A
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_80C21A; }
    goto L_80C213;
L_80C213:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC213u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC213u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC213u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C213 CLC
    cpu.setFlag('C', false);
    goto L_80C214;
L_80C214:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC214u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC214u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC214u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C214 ADC
    cpu.adc(0x16u);
    goto L_80C217;
L_80C217:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC217u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC217u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC217u, 5u, 3u, cpu.address("abs", 0x0962u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C217 STA
    hw.write(cpu.address("abs", 0x962u), cpu.a, cpu.m8?8:16);
    goto L_80C21A;
L_80C21A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC21Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC21Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC21Au, 5u, 3u, cpu.address("abs", 0x0964u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C21A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x964u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C21D;
L_80C21D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC21Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC21Du,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC21Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C21D BMI -> $80C226
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_80C226; }
    goto L_80C21F;
L_80C21F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC21Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC21Fu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC21Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C21F CLC
    cpu.setFlag('C', false);
    goto L_80C220;
L_80C220:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC220u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC220u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC220u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C220 ADC
    cpu.adc(0x16u);
    goto L_80C223;
L_80C223:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC223u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC223u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC223u, 5u, 3u, cpu.address("abs", 0x0964u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C223 STA
    hw.write(cpu.address("abs", 0x964u), cpu.a, cpu.m8?8:16);
    goto L_80C226;
L_80C226:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC226u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC226u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC226u, 5u, 3u, cpu.address("abs", 0x0966u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C226 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x966u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C229;
L_80C229:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC229u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC229u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC229u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C229 BMI -> $80C232
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_80C232; }
    goto L_80C22B;
L_80C22B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC22Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC22Bu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC22Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C22B CLC
    cpu.setFlag('C', false);
    goto L_80C22C;
L_80C22C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC22Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC22Cu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC22Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C22C ADC
    cpu.adc(0x16u);
    goto L_80C22F;
L_80C22F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC22Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC22Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC22Fu, 5u, 3u, cpu.address("abs", 0x0966u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C22F STA
    hw.write(cpu.address("abs", 0x966u), cpu.a, cpu.m8?8:16);
    goto L_80C232;
L_80C232:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC232u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC232u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC232u, 5u, 3u, cpu.address("abs", 0x095Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C232 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x95Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C235;
L_80C235:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC235u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC235u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC235u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C235 CLC
    cpu.setFlag('C', false);
    goto L_80C236;
L_80C236:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC236u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC236u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC236u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C236 ADC
    cpu.adc(0x8u);
    goto L_80C239;
L_80C239:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC239u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC239u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC239u, 5u, 3u, cpu.address("abs", 0x095Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C239 STA
    hw.write(cpu.address("abs", 0x95Eu), cpu.a, cpu.m8?8:16);
    goto L_80C23C;
L_80C23C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC23Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC23Cu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC23Cu, 5u, 3u, cpu.address("abs", 0x094Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C23C STZ
    hw.write(cpu.address("abs", 0x94Au), 0, cpu.m8?8:16);
    goto L_80C23F;
L_80C23F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC23Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC23Fu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC23Fu, 5u, 3u, cpu.address("abs", 0x0948u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C23F STZ
    hw.write(cpu.address("abs", 0x948u), 0, cpu.m8?8:16);
    goto L_80C242;
L_80C242:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC242u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC242u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC242u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C242 BRA -> $80C247
    goto L_80C247;
L_80C244:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC244u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC244u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC244u, 6u, 3u, cpu.address("abs", 0xC248u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80C244 JSR -> $80C248 stack real
    { cpu.push16Value(hw,0xC246u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC247u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC248u), 0x80C244u); }
    goto L_80C247;
L_80C247:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC247u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC247u,0x80C247u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC247u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC247u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80C247 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80C247u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80C247u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_8292C2_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8292C2u: goto L_8292C2;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8292C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92C2u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92C2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8292C2 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8292C2u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8292C2u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_8292C2_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8292C2u: goto L_8292C2;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8292C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92C2u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92C2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8292C2 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8292C2u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8292C2u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_8296B0_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8296B0u: goto L_8296B0;
    case 0x8296B2u: goto L_8296B2;
    case 0x8296B5u: goto L_8296B5;
    case 0x8296B8u: goto L_8296B8;
    case 0x8296BAu: goto L_8296BA;
    case 0x8296BDu: goto L_8296BD;
    case 0x8296C0u: goto L_8296C0;
    case 0x8296C1u: goto L_8296C1;
    case 0x8296C3u: goto L_8296C3;
    case 0x8296C6u: goto L_8296C6;
    case 0x8296C8u: goto L_8296C8;
    case 0x8296CBu: goto L_8296CB;
    case 0x8296CCu: goto L_8296CC;
    case 0x8296CDu: goto L_8296CD;
    case 0x8296CEu: goto L_8296CE;
    case 0x8296CFu: goto L_8296CF;
    case 0x8296D0u: goto L_8296D0;
    case 0x8296D1u: goto L_8296D1;
    case 0x8296D2u: goto L_8296D2;
    case 0x8296D5u: goto L_8296D5;
    case 0x8296D8u: goto L_8296D8;
    case 0x8296DAu: goto L_8296DA;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8296B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B0u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296B0 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_8296B2;
L_8296B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B2u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B2u, 5u + 1u, 3u, cpu.address("absx", 0x020Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296B2 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x20Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8296B5;
L_8296B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B5u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296B5 AND
    cpu.logicAnd(0xFFF0u);
    goto L_8296B8;
L_8296B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296B8 STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_8296BA;
L_8296BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96BAu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96BAu, 5u + 1u, 3u, cpu.address("absx", 0x020Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296BA LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x20Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8296BD;
L_8296BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96BDu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96BDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296BD AND
    cpu.logicAnd(0xFu);
    goto L_8296C0;
L_8296C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96C0u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96C0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296C0 LSR
    cpu.lsrA();
    goto L_8296C1;
L_8296C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96C1u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96C1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296C1 BCC -> $8296C6
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_8296C6; }
    goto L_8296C3;
L_8296C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96C3u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96C3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296C3 ORA
    cpu.logicOr(0x8u);
    goto L_8296C6;
L_8296C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96C6u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96C6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296C6 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16));
    goto L_8296C8;
L_8296C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96C8u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96C8u, 6u, 3u, cpu.address("absx", 0x020Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296C8 STA
    hw.write(cpu.address("absx", 0x20Cu), cpu.a, cpu.m8?8:16);
    goto L_8296CB;
L_8296CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96CBu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96CBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296CB INX
    cpu.inc('X');
    goto L_8296CC;
L_8296CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96CCu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96CCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296CC INX
    cpu.inc('X');
    goto L_8296CD;
L_8296CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96CDu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96CDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296CD INX
    cpu.inc('X');
    goto L_8296CE;
L_8296CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96CEu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96CEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296CE INX
    cpu.inc('X');
    goto L_8296CF;
L_8296CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96CFu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96CFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296CF INX
    cpu.inc('X');
    goto L_8296D0;
L_8296D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96D0u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96D0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296D0 INX
    cpu.inc('X');
    goto L_8296D1;
L_8296D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96D1u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96D1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296D1 TXA
    cpu.transfer("TXA");
    goto L_8296D2;
L_8296D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96D2u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96D2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296D2 AND
    cpu.logicAnd(0xFFu);
    goto L_8296D5;
L_8296D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96D5u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96D5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296D5 CMP
    cpu.compareA(0x18u);
    goto L_8296D8;
L_8296D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96D8u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96D8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296D8 BCC -> $8296B2
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_8296B2; }
    goto L_8296DA;
L_8296DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96DAu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96DAu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8296DA RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8296DAu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8296DAu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_8296DB_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8296DBu: goto L_8296DB;
    case 0x8296DDu: goto L_8296DD;
    case 0x8296E0u: goto L_8296E0;
    case 0x8296E3u: goto L_8296E3;
    case 0x8296E5u: goto L_8296E5;
    case 0x8296E8u: goto L_8296E8;
    case 0x8296EBu: goto L_8296EB;
    case 0x8296ECu: goto L_8296EC;
    case 0x8296EFu: goto L_8296EF;
    case 0x8296F1u: goto L_8296F1;
    case 0x8296F4u: goto L_8296F4;
    case 0x8296F7u: goto L_8296F7;
    case 0x8296F9u: goto L_8296F9;
    case 0x8296FCu: goto L_8296FC;
    case 0x8296FDu: goto L_8296FD;
    case 0x8296FEu: goto L_8296FE;
    case 0x8296FFu: goto L_8296FF;
    case 0x829700u: goto L_829700;
    case 0x829701u: goto L_829701;
    case 0x829702u: goto L_829702;
    case 0x829703u: goto L_829703;
    case 0x829706u: goto L_829706;
    case 0x829709u: goto L_829709;
    case 0x82970Bu: goto L_82970B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8296DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96DBu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96DBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296DB LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_8296DD;
L_8296DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96DDu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96DDu, 5u + 1u, 3u, cpu.address("absx", 0x020Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296DD LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x20Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8296E0;
L_8296E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96E0u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96E0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296E0 AND
    cpu.logicAnd(0xFFF0u);
    goto L_8296E3;
L_8296E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96E3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96E3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296E3 STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_8296E5;
L_8296E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96E5u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96E5u, 5u + 1u, 3u, cpu.address("absx", 0x020Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296E5 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x20Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8296E8;
L_8296E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96E8u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96E8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296E8 AND
    cpu.logicAnd(0xFu);
    goto L_8296EB;
L_8296EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96EBu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96EBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296EB ASL
    cpu.aslA();
    goto L_8296EC;
L_8296EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96ECu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96ECu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296EC BIT
    cpu.bit(0x10u, true);
    goto L_8296EF;
L_8296EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96EFu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96EFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296EF BEQ -> $8296F7
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8296F7; }
    goto L_8296F1;
L_8296F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96F1u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96F1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296F1 AND
    cpu.logicAnd(0xFu);
    goto L_8296F4;
L_8296F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96F4u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96F4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296F4 ORA
    cpu.logicOr(0x1u);
    goto L_8296F7;
L_8296F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96F7u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96F7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296F7 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16));
    goto L_8296F9;
L_8296F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96F9u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96F9u, 6u, 3u, cpu.address("absx", 0x020Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296F9 STA
    hw.write(cpu.address("absx", 0x20Cu), cpu.a, cpu.m8?8:16);
    goto L_8296FC;
L_8296FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96FCu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96FCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296FC INX
    cpu.inc('X');
    goto L_8296FD;
L_8296FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96FDu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96FDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296FD INX
    cpu.inc('X');
    goto L_8296FE;
L_8296FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96FEu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96FEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296FE INX
    cpu.inc('X');
    goto L_8296FF;
L_8296FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96FFu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96FFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296FF INX
    cpu.inc('X');
    goto L_829700;
L_829700:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9700u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9700u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9700u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829700 INX
    cpu.inc('X');
    goto L_829701;
L_829701:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9701u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9701u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9701u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829701 INX
    cpu.inc('X');
    goto L_829702;
L_829702:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9702u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9702u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9702u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829702 TXA
    cpu.transfer("TXA");
    goto L_829703;
L_829703:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9703u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9703u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9703u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829703 AND
    cpu.logicAnd(0xFFu);
    goto L_829706;
L_829706:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9706u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9706u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9706u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829706 CMP
    cpu.compareA(0x18u);
    goto L_829709;
L_829709:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9709u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9709u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9709u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829709 BCC -> $8296DD
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_8296DD; }
    goto L_82970B;
L_82970B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x970Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x970Bu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x970Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82970B RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82970Bu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82970Bu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82A740_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82A740u: goto L_82A740;
    case 0x82A741u: goto L_82A741;
    case 0x82A743u: goto L_82A743;
    case 0x82A747u: goto L_82A747;
    case 0x82A749u: goto L_82A749;
    case 0x82A74Bu: goto L_82A74B;
    case 0x82A74Cu: goto L_82A74C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82A740:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA740u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA740u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA740u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A740 PHX
    cpu.push("PHX", hw);
    goto L_82A741;
L_82A741:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA741u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA741u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA741u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x09u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A741 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x9u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A743;
L_82A743:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA743u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA743u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA743u, 5u, 4u, ((0x9E9069u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A743 LDA
    cpu.loadA(hw.readW(((0x9E9069u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A747;
L_82A747:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA747u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA747u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA747u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A747 ORA
    cpu.logicOr(0x20u);
    goto L_82A749;
L_82A749:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA749u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA749u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA749u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x09u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A749 INC
    cpu.incMem(hw, cpu.address("dp", 0x9u), cpu.m8?8:16);
    goto L_82A74B;
L_82A74B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA74Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA74Bu,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA74Bu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A74B PLX
    cpu.pop("PLX", hw);
    goto L_82A74C;
L_82A74C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA74Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA74Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA74Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A74C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82A74Cu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82A74Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82A9BF_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82A9BFu: goto L_82A9BF;
    case 0x82A9C1u: goto L_82A9C1;
    case 0x82A9C4u: goto L_82A9C4;
    case 0x82A9C5u: goto L_82A9C5;
    case 0x82A9C7u: goto L_82A9C7;
    case 0x82A9C9u: goto L_82A9C9;
    case 0x82A9CAu: goto L_82A9CA;
    case 0x82A9CCu: goto L_82A9CC;
    case 0x82A9CDu: goto L_82A9CD;
    case 0x82A9CFu: goto L_82A9CF;
    case 0x82A9D1u: goto L_82A9D1;
    case 0x82A9D4u: goto L_82A9D4;
    case 0x82A9D6u: goto L_82A9D6;
    case 0x82A9D8u: goto L_82A9D8;
    case 0x82A9D9u: goto L_82A9D9;
    case 0x82A9DAu: goto L_82A9DA;
    case 0x82A9DCu: goto L_82A9DC;
    case 0x82A9DFu: goto L_82A9DF;
    case 0x82A9E1u: goto L_82A9E1;
    case 0x82A9E4u: goto L_82A9E4;
    case 0x82A9E6u: goto L_82A9E6;
    case 0x82A9E8u: goto L_82A9E8;
    case 0x82A9EAu: goto L_82A9EA;
    case 0x82A9ECu: goto L_82A9EC;
    case 0x82A9EFu: goto L_82A9EF;
    case 0x82A9F1u: goto L_82A9F1;
    case 0x82A9F3u: goto L_82A9F3;
    case 0x82A9F4u: goto L_82A9F4;
    case 0x82A9F5u: goto L_82A9F5;
    case 0x82A9F7u: goto L_82A9F7;
    case 0x82A9F8u: goto L_82A9F8;
    case 0x82A9F9u: goto L_82A9F9;
    case 0x82A9FBu: goto L_82A9FB;
    case 0x82A9FDu: goto L_82A9FD;
    case 0x82A9FFu: goto L_82A9FF;
    case 0x82AA01u: goto L_82AA01;
    case 0x82AA03u: goto L_82AA03;
    case 0x82AA05u: goto L_82AA05;
    case 0x82AA06u: goto L_82AA06;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82A9BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9BFu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9BFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A9BF STZ
    hw.write(cpu.address("dp", 0x0u), 0, cpu.m8?8:16);
    goto L_82A9C1;
L_82A9C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9C1u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9C1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A9C1 LDY
    cpu.setY(0x1F8u, 16);
    goto L_82A9C4;
L_82A9C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9C4u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9C4u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82A9C4 PHB
    cpu.push("PHB", hw);
    goto L_82A9C5;
L_82A9C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9C5u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9C5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A9C5 SEP
    cpu.sep(0x20u);
    goto L_82A9C7;
L_82A9C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9C7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9C7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x69u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A9C7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x69u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A9C9;
L_82A9C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9C9u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9C9u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82A9C9 PHA
    cpu.push("PHA", hw);
    goto L_82A9CA;
L_82A9CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9CAu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9CAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A9CA REP
    cpu.rep(0x20u);
    goto L_82A9CC;
L_82A9CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9CCu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9CCu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82A9CC PLB
    cpu.pop("PLB", hw);
    goto L_82A9CD;
L_82A9CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9CDu,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9CDu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82A9CD LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A9CF;
L_82A9CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9CFu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9CFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A9CF BEQ -> $82A9D8
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A9D8; }
    goto L_82A9D1;
L_82A9D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9D1u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9D1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A9D1 CMP
    cpu.compareA(0xFFFFu);
    goto L_82A9D4;
L_82A9D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9D4u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9D4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A9D4 BEQ -> $82A9D8
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A9D8; }
    goto L_82A9D6;
L_82A9D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9D6u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9D6u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A9D6 INC
    cpu.incMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_82A9D8;
L_82A9D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9D8u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9D8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A9D8 DEY
    cpu.decReg('Y');
    goto L_82A9D9;
L_82A9D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9D9u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9D9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A9D9 DEY
    cpu.decReg('Y');
    goto L_82A9DA;
L_82A9DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9DAu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9DAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A9DA BPL -> $82A9CD
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82A9CD; }
    goto L_82A9DC;
L_82A9DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9DCu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9DCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A9DC LDY
    cpu.setY(0x44u, 16);
    goto L_82A9DF;
L_82A9DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9DFu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9DFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A9DF STZ
    hw.write(cpu.address("dp", 0x2u), 0, cpu.m8?8:16);
    goto L_82A9E1;
L_82A9E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A9E1 LDA
    cpu.setA(0x4u, 16);
    goto L_82A9E4;
L_82A9E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A9E4 STA
    hw.write(cpu.address("dp", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_82A9E6;
L_82A9E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E6u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A9E6 STZ
    hw.write(cpu.address("dp", 0x4u), 0, cpu.m8?8:16);
    goto L_82A9E8;
L_82A9E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E8u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E8u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82A9E8 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A9EA;
L_82A9EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9EAu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9EAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A9EA BEQ -> $82A9F3
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A9F3; }
    goto L_82A9EC;
L_82A9EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9ECu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9ECu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A9EC CMP
    cpu.compareA(0xFFFFu);
    goto L_82A9EF;
L_82A9EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9EFu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9EFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A9EF BEQ -> $82A9F7
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A9F7; }
    goto L_82A9F1;
L_82A9F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F1u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F1u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A9F1 INC
    cpu.incMem(hw, cpu.address("dp", 0x4u), cpu.m8?8:16);
    goto L_82A9F3;
L_82A9F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F3u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A9F3 INY
    cpu.inc('Y');
    goto L_82A9F4;
L_82A9F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F4u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A9F4 INY
    cpu.inc('Y');
    goto L_82A9F5;
L_82A9F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F5u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A9F5 BRA -> $82A9E8
    goto L_82A9E8;
L_82A9F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F7u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A9F7 INY
    cpu.inc('Y');
    goto L_82A9F8;
L_82A9F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F8u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A9F8 INY
    cpu.inc('Y');
    goto L_82A9F9;
L_82A9F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A9F9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A9FB;
L_82A9FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9FBu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9FBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A9FB BNE -> $82AA03
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82AA03; }
    goto L_82A9FD;
L_82A9FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9FDu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9FDu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A9FD DEC
    cpu.decMem(hw, cpu.address("dp", 0x6u), cpu.m8?8:16);
    goto L_82A9FF;
L_82A9FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9FFu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9FFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A9FF BPL -> $82A9E8
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82A9E8; }
    goto L_82AA01;
L_82AA01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA01u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA01u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA01 BRA -> $82AA05
    goto L_82AA05;
L_82AA03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA03u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA03u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA03 INC
    cpu.incMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_82AA05;
L_82AA05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA05u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA05u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82AA05 PLB
    cpu.pop("PLB", hw);
    goto L_82AA06;
L_82AA06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA06u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA06u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AA06 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82AA06u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82AA06u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82B949_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B949u: goto L_82B949;
    case 0x82B94Cu: goto L_82B94C;
    case 0x82B94Eu: goto L_82B94E;
    case 0x82B951u: goto L_82B951;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B949:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB949u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB949u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB949u, 6u, 3u, cpu.address("abs", 0xB98Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B949 JSR -> $82B98E stack real
    { cpu.push16Value(hw,0xB94Bu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB94Cu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB98Eu), 0x82B949u); }
    goto L_82B94C;
L_82B94C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB94Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB94Cu,0x82B94Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB94Cu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB94Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B94C LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x61u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B94E;
L_82B94E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB94Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB94Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB94Eu, 6u, 3u, cpu.address("abs", 0xB9A2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B94E JSR -> $82B9A2 stack real
    { cpu.push16Value(hw,0xB950u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB951u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB9A2u), 0x82B94Eu); }
    goto L_82B951;
L_82B951:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB951u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB951u,0x82B951u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB951u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB951u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B951 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B951u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B951u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82C01D_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82C01Du: goto L_82C01D;
    case 0x82C020u: goto L_82C020;
    case 0x82C023u: goto L_82C023;
    case 0x82C025u: goto L_82C025;
    case 0x82C028u: goto L_82C028;
    case 0x82C02Au: goto L_82C02A;
    case 0x82C02Du: goto L_82C02D;
    case 0x82C030u: goto L_82C030;
    case 0x82C031u: goto L_82C031;
    case 0x82C032u: goto L_82C032;
    case 0x82C035u: goto L_82C035;
    case 0x82C03Du: goto L_82C03D;
    case 0x82C040u: goto L_82C040;
    case 0x82C043u: goto L_82C043;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82C01D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC01Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC01Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC01Du, 5u, 3u, cpu.address("abs", 0x013Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C01D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C020;
L_82C020:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC020u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC020u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC020u, 5u, 3u, cpu.address("abs", 0x0139u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C020 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x139u), cpu.m8?8:16));
    goto L_82C023;
L_82C023:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC023u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC023u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC023u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C023 BEQ -> $82C040
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C040; }
    goto L_82C025;
L_82C025:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC025u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC025u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC025u, 5u, 3u, cpu.address("abs", 0x013Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C025 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C028;
L_82C028:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC028u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC028u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC028u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C028 BEQ -> $82C03D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C03D; }
    goto L_82C02A;
L_82C02A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC02Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC02Au,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC02Au, 8u, 3u, cpu.address("abs", 0x014Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C02A INC
    cpu.incMem(hw, cpu.address("abs", 0x14Au), cpu.m8?8:16);
    goto L_82C02D;
L_82C02D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC02Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC02Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC02Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C02D AND
    cpu.logicAnd(0xFFu);
    goto L_82C030;
L_82C030:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC030u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC030u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC030u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C030 ASL
    cpu.aslA();
    goto L_82C031;
L_82C031:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC031u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC031u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC031u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C031 TAX
    cpu.transfer("TAX");
    goto L_82C032;
L_82C032:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC032u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC032u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC032u, 5u, 3u, cpu.address("abs", 0xC037u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C032 PEA
    cpu.push16Value(hw, 0xC037u);
    goto L_82C035;
L_82C035:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC035u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC035u,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC035u, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0xC044u + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $82C035 JMP (C044,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0xC044u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x82C035u); return; }
L_82C03D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC03Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC03Du,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC03Du, 8u, 3u, cpu.address("abs", 0x014Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C03D INC
    cpu.incMem(hw, cpu.address("abs", 0x14Au), cpu.m8?8:16);
    goto L_82C040;
L_82C040:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC040u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC040u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC040u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C040 LDA
    cpu.setA(0x0u, 16);
    goto L_82C043;
L_82C043:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC043u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC043u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC043u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C043 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C043u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C043u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82C01D_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82C01Du: goto L_82C01D;
    case 0x82C020u: goto L_82C020;
    case 0x82C023u: goto L_82C023;
    case 0x82C025u: goto L_82C025;
    case 0x82C028u: goto L_82C028;
    case 0x82C02Au: goto L_82C02A;
    case 0x82C02Du: goto L_82C02D;
    case 0x82C030u: goto L_82C030;
    case 0x82C031u: goto L_82C031;
    case 0x82C032u: goto L_82C032;
    case 0x82C035u: goto L_82C035;
    case 0x82C03Du: goto L_82C03D;
    case 0x82C040u: goto L_82C040;
    case 0x82C043u: goto L_82C043;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82C01D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC01Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC01Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC01Du, 5u, 3u, cpu.address("abs", 0x013Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C01D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C020;
L_82C020:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC020u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC020u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC020u, 5u, 3u, cpu.address("abs", 0x0139u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C020 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x139u), cpu.m8?8:16));
    goto L_82C023;
L_82C023:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC023u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC023u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC023u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C023 BEQ -> $82C040
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C040; }
    goto L_82C025;
L_82C025:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC025u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC025u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC025u, 5u, 3u, cpu.address("abs", 0x013Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C025 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C028;
L_82C028:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC028u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC028u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC028u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C028 BEQ -> $82C03D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C03D; }
    goto L_82C02A;
L_82C02A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC02Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC02Au,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC02Au, 8u, 3u, cpu.address("abs", 0x014Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C02A INC
    cpu.incMem(hw, cpu.address("abs", 0x14Au), cpu.m8?8:16);
    goto L_82C02D;
L_82C02D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC02Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC02Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC02Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C02D AND
    cpu.logicAnd(0xFFu);
    goto L_82C030;
L_82C030:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC030u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC030u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC030u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C030 ASL
    cpu.aslA();
    goto L_82C031;
L_82C031:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC031u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC031u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC031u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C031 TAX
    cpu.transfer("TAX");
    goto L_82C032;
L_82C032:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC032u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC032u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC032u, 5u, 3u, cpu.address("abs", 0xC037u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C032 PEA
    cpu.push16Value(hw, 0xC037u);
    goto L_82C035;
L_82C035:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC035u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC035u,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC035u, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0xC044u + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $82C035 JMP (C044,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0xC044u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x82C035u); return; }
L_82C03D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC03Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC03Du,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC03Du, 8u, 3u, cpu.address("abs", 0x014Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C03D INC
    cpu.incMem(hw, cpu.address("abs", 0x14Au), cpu.m8?8:16);
    goto L_82C040;
L_82C040:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC040u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC040u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC040u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C040 LDA
    cpu.setA(0x0u, 16);
    goto L_82C043;
L_82C043:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC043u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC043u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC043u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C043 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C043u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C043u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82C280_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82C280u: goto L_82C280;
    case 0x82C283u: goto L_82C283;
    case 0x82C287u: goto L_82C287;
    case 0x82C28Bu: goto L_82C28B;
    case 0x82C28Eu: goto L_82C28E;
    case 0x82C291u: goto L_82C291;
    case 0x82C294u: goto L_82C294;
    case 0x82C297u: goto L_82C297;
    case 0x82C299u: goto L_82C299;
    case 0x82C29Cu: goto L_82C29C;
    case 0x82C29Fu: goto L_82C29F;
    case 0x82C2A1u: goto L_82C2A1;
    case 0x82C2A3u: goto L_82C2A3;
    case 0x82C2A5u: goto L_82C2A5;
    case 0x82C2A8u: goto L_82C2A8;
    case 0x82C2ACu: goto L_82C2AC;
    case 0x82C2AEu: goto L_82C2AE;
    case 0x82C2B2u: goto L_82C2B2;
    case 0x82C2B6u: goto L_82C2B6;
    case 0x82C2B8u: goto L_82C2B8;
    case 0x82C2BCu: goto L_82C2BC;
    case 0x82C2C0u: goto L_82C2C0;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82C280:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC280u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC280u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC280u, 6u, 3u, cpu.address("abs", 0x9B0Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C280 JSR -> $829B0B stack real
    { cpu.push16Value(hw,0xC282u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC283u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9B0Bu), 0x82C280u); }
    goto L_82C283;
L_82C283:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC283u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC283u,0x82C283u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC283u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC283u, 8u, 4u, 0x809C3Au, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82C283 JSL -> $809C3A stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC286u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC287u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809C3Au, 0x82C283u); }
    goto L_82C287;
L_82C287:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC287u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC287u,0x82C287u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC287u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC287u, 8u, 4u, 0x809C69u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82C287 JSL -> $809C69 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC28Au); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC28Bu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809C69u, 0x82C287u); }
    goto L_82C28B;
L_82C28B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC28Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC28Bu,0x82C28Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC28Bu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC28Bu, 5u, 3u, cpu.address("abs", 0x0176u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C28B STZ
    hw.write(cpu.address("abs", 0x176u), 0, cpu.m8?8:16);
    goto L_82C28E;
L_82C28E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC28Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC28Eu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC28Eu, 5u, 3u, cpu.address("abs", 0x02CCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C28E STZ
    hw.write(cpu.address("abs", 0x2CCu), 0, cpu.m8?8:16);
    goto L_82C291;
L_82C291:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC291u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC291u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC291u, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C291 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C294;
L_82C294:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC294u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC294u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC294u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C294 CMP
    cpu.compareA(0x1u);
    goto L_82C297;
L_82C297:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC297u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC297u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC297u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C297 BNE -> $82C29F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C29F; }
    goto L_82C299;
L_82C299:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC299u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC299u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC299u, 5u, 3u, cpu.address("abs", 0x0804u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C299 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x804u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C29C;
L_82C29C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC29Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC29Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC29Cu, 5u, 3u, cpu.address("abs", 0x0802u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C29C STA
    hw.write(cpu.address("abs", 0x802u), cpu.a, cpu.m8?8:16);
    goto L_82C29F;
L_82C29F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC29Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC29Fu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC29Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C29F SEP
    cpu.sep(0x20u);
    goto L_82C2A1;
L_82C2A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2A1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2A1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C2A1 LDA
    cpu.setA(0x1u, 8);
    goto L_82C2A3;
L_82C2A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2A3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2A3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C2A3 STA
    hw.write(cpu.address("dp", 0x49u), cpu.a, cpu.m8?8:16);
    goto L_82C2A5;
L_82C2A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2A5u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2A5u, 5u, 3u, cpu.address("abs", 0x014Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C2A5 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x14Cu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82C2A8;
L_82C2A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2A8u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2A8u, 5u, 4u, ((0x9E9564u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C2A8 LDA
    cpu.loadA(hw.readW(((0x9E9564u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C2AC;
L_82C2AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2ACu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2ACu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C2AC BEQ -> $82C2B8
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C2B8; }
    goto L_82C2AE;
L_82C2AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2AEu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2AEu, 8u, 4u, 0x80A6BDu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82C2AE JSL -> $80A6BD stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC2B1u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC2B2u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6BDu, 0x82C2AEu); }
    goto L_82C2B2;
L_82C2B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2B2u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC2B2u,0x82C2B2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2B2u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2B2u, 8u, 4u, 0x80A6A5u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82C2B2 JSL -> $80A6A5 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC2B5u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC2B6u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6A5u, 0x82C2B2u); }
    goto L_82C2B6;
L_82C2B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2B6u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC2B6u,0x82C2B6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2B6u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2B6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C2B6 BRA -> $82C2BC
    goto L_82C2BC;
L_82C2B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2B8u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2B8u, 8u, 4u, 0x80A5D1u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82C2B8 JSL -> $80A5D1 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC2BBu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC2BCu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A5D1u, 0x82C2B8u); }
    goto L_82C2BC;
L_82C2BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2BCu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC2BCu,0x82C2BCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2BCu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2BCu, 8u, 4u, 0x808D2Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82C2BC JSL -> $808D2F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC2BFu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC2C0u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808D2Fu, 0x82C2BCu); }
    goto L_82C2C0;
L_82C2C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2C0u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC2C0u,0x82C2C0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2C0u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2C0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C2C0 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C2C0u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C2C0u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82C754_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82C754u: goto L_82C754;
    case 0x82C755u: goto L_82C755;
    case 0x82C758u: goto L_82C758;
    case 0x82C75Au: goto L_82C75A;
    case 0x82C75Du: goto L_82C75D;
    case 0x82C75Fu: goto L_82C75F;
    case 0x82C762u: goto L_82C762;
    case 0x82C764u: goto L_82C764;
    case 0x82C767u: goto L_82C767;
    case 0x82C769u: goto L_82C769;
    case 0x82C76Bu: goto L_82C76B;
    case 0x82C76Cu: goto L_82C76C;
    case 0x82C76Du: goto L_82C76D;
    case 0x82C76Fu: goto L_82C76F;
    case 0x82C772u: goto L_82C772;
    case 0x82C774u: goto L_82C774;
    case 0x82C776u: goto L_82C776;
    case 0x82C779u: goto L_82C779;
    case 0x82C77Cu: goto L_82C77C;
    case 0x82C77Eu: goto L_82C77E;
    case 0x82C77Fu: goto L_82C77F;
    case 0x82C780u: goto L_82C780;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82C754:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC754u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC754u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC754u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C754 PHY
    cpu.push("PHY", hw);
    goto L_82C755;
L_82C755:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC755u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC755u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC755u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C755 ORA
    cpu.logicOr(0xFu);
    goto L_82C758;
L_82C758:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC758u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC758u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC758u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C758 STA
    hw.write(cpu.address("dp", 0x1Eu), cpu.a, cpu.m8?8:16);
    goto L_82C75A;
L_82C75A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC75Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC75Au,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC75Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C75A LDY
    cpu.setY(0x1F8u, 16);
    goto L_82C75D;
L_82C75D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC75Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC75Du,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC75Du, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82C75D LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C75F;
L_82C75F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC75Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC75Fu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC75Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C75F CMP
    cpu.compareA(0xFFFFu);
    goto L_82C762;
L_82C762:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC762u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC762u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC762u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C762 BEQ -> $82C76B
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C76B; }
    goto L_82C764;
L_82C764:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC764u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC764u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC764u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C764 AND
    cpu.logicAnd(0x30Fu);
    goto L_82C767;
L_82C767:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC767u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC767u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC767u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C767 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x1Eu), cpu.m8?8:16));
    goto L_82C769;
L_82C769:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC769u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC769u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC769u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C769 BEQ -> $82C774
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C774; }
    goto L_82C76B;
L_82C76B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC76Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC76Bu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC76Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C76B DEY
    cpu.decReg('Y');
    goto L_82C76C;
L_82C76C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC76Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC76Cu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC76Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C76C DEY
    cpu.decReg('Y');
    goto L_82C76D;
L_82C76D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC76Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC76Du,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC76Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C76D BPL -> $82C75D
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82C75D; }
    goto L_82C76F;
L_82C76F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC76Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC76Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC76Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C76F LDA
    cpu.setA(0xFFFFu, 16);
    goto L_82C772;
L_82C772:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC772u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC772u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC772u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C772 BRA -> $82C77F
    goto L_82C77F;
L_82C774:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC774u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC774u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC774u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C774 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C776;
L_82C776:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC776u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC776u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC776u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C776 AND
    cpu.logicAnd(0x300u);
    goto L_82C779;
L_82C779:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC779u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC779u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC779u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C779 ORA
    cpu.logicOr(0x2000u);
    goto L_82C77C;
L_82C77C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC77Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC77Cu,cpu,0x91u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC77Cu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82C77C STA
    hw.write(cpu.addressDpIndirectY(hw, 0x67u), cpu.a, cpu.m8?8:16);
    goto L_82C77E;
L_82C77E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC77Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC77Eu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC77Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C77E TYA
    cpu.transfer("TYA");
    goto L_82C77F;
L_82C77F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC77Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC77Fu,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC77Fu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C77F PLY
    cpu.pop("PLY", hw);
    goto L_82C780;
L_82C780:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC780u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC780u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC780u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C780 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C780u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C780u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82CBC5_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82CBC5u: goto L_82CBC5;
    case 0x82CBC7u: goto L_82CBC7;
    case 0x82CBC9u: goto L_82CBC9;
    case 0x82CBCBu: goto L_82CBCB;
    case 0x82CBCEu: goto L_82CBCE;
    case 0x82CBD0u: goto L_82CBD0;
    case 0x82CBD3u: goto L_82CBD3;
    case 0x82CBD6u: goto L_82CBD6;
    case 0x82CBD9u: goto L_82CBD9;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82CBC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBC5u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBC5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CBC5 SEP
    cpu.sep(0x20u);
    goto L_82CBC7;
L_82CBC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBC7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBC7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CBC7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x75u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CBC9;
L_82CBC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBC9u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBC9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CBC9 BNE -> $82CBCE
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CBCE; }
    goto L_82CBCB;
L_82CBCB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBCBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBCBu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBCBu, 6u, 3u, cpu.address("abs", 0x0141u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CBCB INC
    cpu.incMem(hw, cpu.address("abs", 0x141u), cpu.m8?8:16);
    goto L_82CBCE;
L_82CBCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBCEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBCEu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBCEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CBCE REP
    cpu.rep(0x20u);
    goto L_82CBD0;
L_82CBD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBD0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBD0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBD0u, 6u, 3u, cpu.address("abs", 0xCC1Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82CBD0 JSR -> $82CC1A stack real
    { cpu.push16Value(hw,0xCBD2u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCBD3u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCC1Au), 0x82CBD0u); }
    goto L_82CBD3;
L_82CBD3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBD3u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCBD3u,0x82CBD3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBD3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBD3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CBD3 LDA
    cpu.setA(0x18u, 16);
    goto L_82CBD6;
L_82CBD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBD6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBD6u, 5u, 3u, cpu.address("abs", 0x018Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CBD6 STA
    hw.write(cpu.address("abs", 0x18Bu), cpu.a, cpu.m8?8:16);
    goto L_82CBD9;
L_82CBD9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBD9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBD9u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBD9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82CBD9 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82CBD9u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82CBD9u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82CBC5_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82CBC5u: goto L_82CBC5;
    case 0x82CBC7u: goto L_82CBC7;
    case 0x82CBC9u: goto L_82CBC9;
    case 0x82CBCBu: goto L_82CBCB;
    case 0x82CBCEu: goto L_82CBCE;
    case 0x82CBD0u: goto L_82CBD0;
    case 0x82CBD3u: goto L_82CBD3;
    case 0x82CBD6u: goto L_82CBD6;
    case 0x82CBD9u: goto L_82CBD9;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82CBC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBC5u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBC5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CBC5 SEP
    cpu.sep(0x20u);
    goto L_82CBC7;
L_82CBC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBC7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBC7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CBC7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x75u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CBC9;
L_82CBC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBC9u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBC9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CBC9 BNE -> $82CBCE
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CBCE; }
    goto L_82CBCB;
L_82CBCB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBCBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBCBu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBCBu, 6u, 3u, cpu.address("abs", 0x0141u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CBCB INC
    cpu.incMem(hw, cpu.address("abs", 0x141u), cpu.m8?8:16);
    goto L_82CBCE;
L_82CBCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBCEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBCEu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBCEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CBCE REP
    cpu.rep(0x20u);
    goto L_82CBD0;
L_82CBD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBD0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBD0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBD0u, 6u, 3u, cpu.address("abs", 0xCC1Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82CBD0 JSR -> $82CC1A stack real
    { cpu.push16Value(hw,0xCBD2u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCBD3u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCC1Au), 0x82CBD0u); }
    goto L_82CBD3;
L_82CBD3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBD3u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCBD3u,0x82CBD3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBD3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBD3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CBD3 LDA
    cpu.setA(0x18u, 16);
    goto L_82CBD6;
L_82CBD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBD6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBD6u, 5u, 3u, cpu.address("abs", 0x018Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CBD6 STA
    hw.write(cpu.address("abs", 0x18Bu), cpu.a, cpu.m8?8:16);
    goto L_82CBD9;
L_82CBD9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBD9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBD9u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBD9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82CBD9 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82CBD9u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82CBD9u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82D698_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82D698u: goto L_82D698;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82D698:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD698u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD698u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD698u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D698 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82D698u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82D698u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82E2AD_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82E2ADu: goto L_82E2AD;
    case 0x82E2AFu: goto L_82E2AF;
    case 0x82E2B2u: goto L_82E2B2;
    case 0x82E2B4u: goto L_82E2B4;
    case 0x82E2B6u: goto L_82E2B6;
    case 0x82E2B9u: goto L_82E2B9;
    case 0x82E2BBu: goto L_82E2BB;
    case 0x82E2BDu: goto L_82E2BD;
    case 0x82E2BEu: goto L_82E2BE;
    case 0x82E2C1u: goto L_82E2C1;
    case 0x82E2C3u: goto L_82E2C3;
    case 0x82E2C6u: goto L_82E2C6;
    case 0x82E2C8u: goto L_82E2C8;
    case 0x82E2CBu: goto L_82E2CB;
    case 0x82E2CDu: goto L_82E2CD;
    case 0x82E2CFu: goto L_82E2CF;
    case 0x82E2D0u: goto L_82E2D0;
    case 0x82E2D3u: goto L_82E2D3;
    case 0x82E2D5u: goto L_82E2D5;
    case 0x82E2D8u: goto L_82E2D8;
    case 0x82E2DAu: goto L_82E2DA;
    case 0x82E2DDu: goto L_82E2DD;
    case 0x82E2DFu: goto L_82E2DF;
    case 0x82E2E1u: goto L_82E2E1;
    case 0x82E2E2u: goto L_82E2E2;
    case 0x82E2E5u: goto L_82E2E5;
    case 0x82E2E7u: goto L_82E2E7;
    case 0x82E2EAu: goto L_82E2EA;
    case 0x82E2ECu: goto L_82E2EC;
    case 0x82E2EFu: goto L_82E2EF;
    case 0x82E2F1u: goto L_82E2F1;
    case 0x82E2F3u: goto L_82E2F3;
    case 0x82E2F4u: goto L_82E2F4;
    case 0x82E2F7u: goto L_82E2F7;
    case 0x82E2F9u: goto L_82E2F9;
    case 0x82E2FCu: goto L_82E2FC;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82E2AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2ADu,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2ADu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82E2AD LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E2AF;
L_82E2AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2AFu,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2AFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2AF ORA
    cpu.logicOr(0x4000u);
    goto L_82E2B2;
L_82E2B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2B2u,cpu,0x91u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2B2u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82E2B2 STA
    hw.write(cpu.addressDpIndirectY(hw, 0x67u), cpu.a, cpu.m8?8:16);
    goto L_82E2B4;
L_82E2B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2B4u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2B4u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82E2B4 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E2B6;
L_82E2B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2B6u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2B6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2B6 BIT
    cpu.bit(0x1u, true);
    goto L_82E2B9;
L_82E2B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2B9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2B9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2B9 BEQ -> $82E2C6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E2C6; }
    goto L_82E2BB;
L_82E2BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2BBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2BBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x67u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2BB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E2BD;
L_82E2BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2BDu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2BDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2BD SEC
    cpu.setFlag('C', true);
    goto L_82E2BE;
L_82E2BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2BEu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2BEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2BE SBC
    cpu.sbc(0x16u);
    goto L_82E2C1;
L_82E2C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2C1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2C1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2C1 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82E2C3;
L_82E2C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2C3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2C3u, 6u, 3u, cpu.address("abs", 0xE2FDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82E2C3 JSR -> $82E2FD stack real
    { cpu.push16Value(hw,0xE2C5u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE2C6u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xE2FDu), 0x82E2C3u); }
    goto L_82E2C6;
L_82E2C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2C6u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2C6u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2C6u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82E2C6 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E2C8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2C6u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2C6u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82E2C6 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E2C8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE2C6u,0x82E2C6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E2C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2C8u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2C8u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2C8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2C8 BIT
    cpu.bit(0x2u, true);
    goto L_82E2CB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2C8u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2C8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2C8 BIT
    cpu.bit(0x2u, true);
    goto L_82E2CB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE2C8u,0x82E2C8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E2CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2CBu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2CBu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2CBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2CB BEQ -> $82E2D8
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E2D8; }
    goto L_82E2CD;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2CBu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2CBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2CB BEQ -> $82E2D8
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E2D8; }
    goto L_82E2CD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE2CBu,0x82E2CBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E2CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2CDu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2CDu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2CDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x67u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2CD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E2CF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2CDu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2CDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x67u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2CD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E2CF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE2CDu,0x82E2CDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E2CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2CFu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2CFu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2CFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2CF SEC
    cpu.setFlag('C', true);
    goto L_82E2D0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2CFu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2CFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2CF SEC
    cpu.setFlag('C', true);
    goto L_82E2D0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE2CFu,0x82E2CFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E2D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2D0u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2D0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2D0 SBC
    cpu.sbc(0x2u);
    goto L_82E2D3;
L_82E2D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2D3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2D3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2D3 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82E2D5;
L_82E2D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2D5u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2D5u, 6u, 3u, cpu.address("abs", 0xE2FDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82E2D5 JSR -> $82E2FD stack real
    { cpu.push16Value(hw,0xE2D7u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE2D8u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xE2FDu), 0x82E2D5u); }
    goto L_82E2D8;
L_82E2D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2D8u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2D8u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2D8u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82E2D8 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E2DA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2D8u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2D8u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82E2D8 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E2DA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE2D8u,0x82E2D8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E2DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2DAu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2DAu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2DAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2DA BIT
    cpu.bit(0x4u, true);
    goto L_82E2DD;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2DAu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2DAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2DA BIT
    cpu.bit(0x4u, true);
    goto L_82E2DD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE2DAu,0x82E2DAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E2DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2DDu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2DDu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2DDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2DD BEQ -> $82E2EA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E2EA; }
    goto L_82E2DF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2DDu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2DDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2DD BEQ -> $82E2EA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E2EA; }
    goto L_82E2DF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE2DDu,0x82E2DDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E2DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2DFu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2DFu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2DFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x67u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2DF LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E2E1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2DFu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2DFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x67u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2DF LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E2E1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE2DFu,0x82E2DFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E2E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2E1u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2E1u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2E1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2E1 CLC
    cpu.setFlag('C', false);
    goto L_82E2E2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2E1u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2E1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2E1 CLC
    cpu.setFlag('C', false);
    goto L_82E2E2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE2E1u,0x82E2E1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E2E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2E2u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2E2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2E2 ADC
    cpu.adc(0x16u);
    goto L_82E2E5;
L_82E2E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2E5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2E5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2E5 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82E2E7;
L_82E2E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2E7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2E7u, 6u, 3u, cpu.address("abs", 0xE2FDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82E2E7 JSR -> $82E2FD stack real
    { cpu.push16Value(hw,0xE2E9u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE2EAu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xE2FDu), 0x82E2E7u); }
    goto L_82E2EA;
L_82E2EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2EAu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2EAu,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2EAu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82E2EA LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E2EC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2EAu,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2EAu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82E2EA LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E2EC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE2EAu,0x82E2EAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E2EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2ECu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2ECu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2ECu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2EC BIT
    cpu.bit(0x8u, true);
    goto L_82E2EF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2ECu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2ECu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2EC BIT
    cpu.bit(0x8u, true);
    goto L_82E2EF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE2ECu,0x82E2ECu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E2EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2EFu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2EFu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2EFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2EF BEQ -> $82E2FC
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E2FC; }
    goto L_82E2F1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2EFu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2EFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2EF BEQ -> $82E2FC
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E2FC; }
    goto L_82E2F1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE2EFu,0x82E2EFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E2F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2F1u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x67u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2F1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E2F3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x67u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2F1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E2F3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE2F1u,0x82E2F1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E2F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2F3u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F3u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2F3 CLC
    cpu.setFlag('C', false);
    goto L_82E2F4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F3u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2F3 CLC
    cpu.setFlag('C', false);
    goto L_82E2F4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE2F3u,0x82E2F3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E2F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F4u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2F4 ADC
    cpu.adc(0x2u);
    goto L_82E2F7;
L_82E2F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2F7 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82E2F9;
L_82E2F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F9u, 6u, 3u, cpu.address("abs", 0xE2FDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82E2F9 JSR -> $82E2FD stack real
    { cpu.push16Value(hw,0xE2FBu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE2FCu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xE2FDu), 0x82E2F9u); }
    goto L_82E2FC;
L_82E2FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2FCu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2FCu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2FCu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82E2FC RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82E2FCu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82E2FCu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2FCu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2FCu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82E2FC RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82E2FCu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82E2FCu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE2FCu,0x82E2FCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_82E2AD_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82E2ADu: goto L_82E2AD;
    case 0x82E2AFu: goto L_82E2AF;
    case 0x82E2B2u: goto L_82E2B2;
    case 0x82E2B4u: goto L_82E2B4;
    case 0x82E2B6u: goto L_82E2B6;
    case 0x82E2B9u: goto L_82E2B9;
    case 0x82E2BBu: goto L_82E2BB;
    case 0x82E2BDu: goto L_82E2BD;
    case 0x82E2BEu: goto L_82E2BE;
    case 0x82E2C1u: goto L_82E2C1;
    case 0x82E2C3u: goto L_82E2C3;
    case 0x82E2C6u: goto L_82E2C6;
    case 0x82E2C8u: goto L_82E2C8;
    case 0x82E2CBu: goto L_82E2CB;
    case 0x82E2CDu: goto L_82E2CD;
    case 0x82E2CFu: goto L_82E2CF;
    case 0x82E2D0u: goto L_82E2D0;
    case 0x82E2D3u: goto L_82E2D3;
    case 0x82E2D5u: goto L_82E2D5;
    case 0x82E2D8u: goto L_82E2D8;
    case 0x82E2DAu: goto L_82E2DA;
    case 0x82E2DDu: goto L_82E2DD;
    case 0x82E2DFu: goto L_82E2DF;
    case 0x82E2E1u: goto L_82E2E1;
    case 0x82E2E2u: goto L_82E2E2;
    case 0x82E2E5u: goto L_82E2E5;
    case 0x82E2E7u: goto L_82E2E7;
    case 0x82E2EAu: goto L_82E2EA;
    case 0x82E2ECu: goto L_82E2EC;
    case 0x82E2EFu: goto L_82E2EF;
    case 0x82E2F1u: goto L_82E2F1;
    case 0x82E2F3u: goto L_82E2F3;
    case 0x82E2F4u: goto L_82E2F4;
    case 0x82E2F7u: goto L_82E2F7;
    case 0x82E2F9u: goto L_82E2F9;
    case 0x82E2FCu: goto L_82E2FC;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82E2AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2ADu,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2ADu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82E2AD LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E2AF;
L_82E2AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2AFu,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2AFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2AF ORA
    cpu.logicOr(0x4000u);
    goto L_82E2B2;
L_82E2B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2B2u,cpu,0x91u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2B2u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82E2B2 STA
    hw.write(cpu.addressDpIndirectY(hw, 0x67u), cpu.a, cpu.m8?8:16);
    goto L_82E2B4;
L_82E2B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2B4u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2B4u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82E2B4 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E2B6;
L_82E2B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2B6u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2B6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2B6 BIT
    cpu.bit(0x1u, true);
    goto L_82E2B9;
L_82E2B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2B9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2B9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2B9 BEQ -> $82E2C6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E2C6; }
    goto L_82E2BB;
L_82E2BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2BBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2BBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x67u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2BB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E2BD;
L_82E2BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2BDu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2BDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2BD SEC
    cpu.setFlag('C', true);
    goto L_82E2BE;
L_82E2BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2BEu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2BEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2BE SBC
    cpu.sbc(0x16u);
    goto L_82E2C1;
L_82E2C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2C1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2C1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2C1 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82E2C3;
L_82E2C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2C3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2C3u, 6u, 3u, cpu.address("abs", 0xE2FDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82E2C3 JSR -> $82E2FD stack real
    { cpu.push16Value(hw,0xE2C5u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE2C6u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xE2FDu), 0x82E2C3u); }
    goto L_82E2C6;
L_82E2C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2C6u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE2C6u,0x82E2C6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2C6u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2C6u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82E2C6 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E2C8;
L_82E2C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2C8u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2C8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2C8 BIT
    cpu.bit(0x2u, true);
    goto L_82E2CB;
L_82E2CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2CBu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2CBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2CB BEQ -> $82E2D8
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E2D8; }
    goto L_82E2CD;
L_82E2CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2CDu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2CDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x67u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2CD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E2CF;
L_82E2CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2CFu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2CFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2CF SEC
    cpu.setFlag('C', true);
    goto L_82E2D0;
L_82E2D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2D0u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2D0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2D0 SBC
    cpu.sbc(0x2u);
    goto L_82E2D3;
L_82E2D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2D3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2D3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2D3 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82E2D5;
L_82E2D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2D5u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2D5u, 6u, 3u, cpu.address("abs", 0xE2FDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82E2D5 JSR -> $82E2FD stack real
    { cpu.push16Value(hw,0xE2D7u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE2D8u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xE2FDu), 0x82E2D5u); }
    goto L_82E2D8;
L_82E2D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2D8u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE2D8u,0x82E2D8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2D8u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2D8u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82E2D8 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E2DA;
L_82E2DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2DAu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2DAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2DA BIT
    cpu.bit(0x4u, true);
    goto L_82E2DD;
L_82E2DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2DDu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2DDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2DD BEQ -> $82E2EA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E2EA; }
    goto L_82E2DF;
L_82E2DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2DFu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2DFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x67u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2DF LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E2E1;
L_82E2E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2E1u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2E1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2E1 CLC
    cpu.setFlag('C', false);
    goto L_82E2E2;
L_82E2E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2E2u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2E2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2E2 ADC
    cpu.adc(0x16u);
    goto L_82E2E5;
L_82E2E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2E5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2E5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2E5 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82E2E7;
L_82E2E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2E7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2E7u, 6u, 3u, cpu.address("abs", 0xE2FDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82E2E7 JSR -> $82E2FD stack real
    { cpu.push16Value(hw,0xE2E9u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE2EAu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xE2FDu), 0x82E2E7u); }
    goto L_82E2EA;
L_82E2EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2EAu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE2EAu,0x82E2EAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2EAu,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2EAu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82E2EA LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E2EC;
L_82E2EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2ECu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2ECu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2EC BIT
    cpu.bit(0x8u, true);
    goto L_82E2EF;
L_82E2EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2EFu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2EFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2EF BEQ -> $82E2FC
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E2FC; }
    goto L_82E2F1;
L_82E2F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x67u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2F1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E2F3;
L_82E2F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F3u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2F3 CLC
    cpu.setFlag('C', false);
    goto L_82E2F4;
L_82E2F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F4u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2F4 ADC
    cpu.adc(0x2u);
    goto L_82E2F7;
L_82E2F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2F7 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82E2F9;
L_82E2F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F9u, 6u, 3u, cpu.address("abs", 0xE2FDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82E2F9 JSR -> $82E2FD stack real
    { cpu.push16Value(hw,0xE2FBu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE2FCu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xE2FDu), 0x82E2F9u); }
    goto L_82E2FC;
L_82E2FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2FCu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE2FCu,0x82E2FCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2FCu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2FCu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82E2FC RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82E2FCu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82E2FCu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_84847B_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84847Bu: goto L_84847B;
    case 0x84847Du: goto L_84847D;
    case 0x84847Fu: goto L_84847F;
    case 0x848481u: goto L_848481;
    case 0x848484u: goto L_848484;
    case 0x848485u: goto L_848485;
    case 0x848486u: goto L_848486;
    case 0x848489u: goto L_848489;
    case 0x84848Cu: goto L_84848C;
    case 0x84848Eu: goto L_84848E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84847B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x847Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x847Bu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x847Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84847B SEP
    cpu.sep(0x20u);
    goto L_84847D;
L_84847D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x847Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x847Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x847Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84847D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x49u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84847F;
L_84847F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x847Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x847Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x847Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84847F REP
    cpu.rep(0x20u);
    goto L_848481;
L_848481:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8481u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8481u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8481u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848481 AND
    cpu.logicAnd(0xFFu);
    goto L_848484;
L_848484:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8484u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8484u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8484u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848484 ASL
    cpu.aslA();
    goto L_848485;
L_848485:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8485u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8485u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8485u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848485 TAX
    cpu.transfer("TAX");
    goto L_848486;
L_848486:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8486u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8486u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8486u, 5u, 3u, cpu.address("abs", 0x848Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848486 PEA
    cpu.push16Value(hw, 0x848Bu);
    goto L_848489;
L_848489:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8489u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8489u,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8489u, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x848Fu + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $848489 JMP (848F,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x848Fu+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x848489u); return; }
L_84848C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x848Cu))return;
  // 4 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x848Cu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x848Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84848C REP
    cpu.rep(0x20u);
    goto L_84848E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x848Cu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x848Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84848C REP
    cpu.rep(0x20u);
    goto L_84848E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x848Cu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x848Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84848C REP
    cpu.rep(0x20u);
    goto L_84848E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x848Cu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x848Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84848C REP
    cpu.rep(0x20u);
    goto L_84848E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x848Cu,0x84848Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84848E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x848Eu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x848Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x848Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84848E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84848Eu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84848Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x848Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x848Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84848E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84848Eu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84848Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x848Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x848Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84848E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84848Eu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84848Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x848Eu,0x84848Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_84847B_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84847Bu: goto L_84847B;
    case 0x84847Du: goto L_84847D;
    case 0x84847Fu: goto L_84847F;
    case 0x848481u: goto L_848481;
    case 0x848484u: goto L_848484;
    case 0x848485u: goto L_848485;
    case 0x848486u: goto L_848486;
    case 0x848489u: goto L_848489;
    case 0x84848Cu: goto L_84848C;
    case 0x84848Eu: goto L_84848E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84847B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x847Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x847Bu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x847Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84847B SEP
    cpu.sep(0x20u);
    goto L_84847D;
L_84847D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x847Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x847Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x847Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84847D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x49u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84847F;
L_84847F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x847Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x847Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x847Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84847F REP
    cpu.rep(0x20u);
    goto L_848481;
L_848481:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8481u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8481u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8481u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848481 AND
    cpu.logicAnd(0xFFu);
    goto L_848484;
L_848484:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8484u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8484u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8484u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848484 ASL
    cpu.aslA();
    goto L_848485;
L_848485:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8485u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8485u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8485u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848485 TAX
    cpu.transfer("TAX");
    goto L_848486;
L_848486:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8486u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8486u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8486u, 5u, 3u, cpu.address("abs", 0x848Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848486 PEA
    cpu.push16Value(hw, 0x848Bu);
    goto L_848489;
L_848489:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8489u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8489u,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8489u, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x848Fu + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $848489 JMP (848F,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x848Fu+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x848489u); return; }
L_84848C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x848Cu))return;
  // 4 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x848Cu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x848Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84848C REP
    cpu.rep(0x20u);
    goto L_84848E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x848Cu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x848Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84848C REP
    cpu.rep(0x20u);
    goto L_84848E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x848Cu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x848Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84848C REP
    cpu.rep(0x20u);
    goto L_84848E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x848Cu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x848Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84848C REP
    cpu.rep(0x20u);
    goto L_84848E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x848Cu,0x84848Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84848E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x848Eu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x848Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x848Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84848E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84848Eu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84848Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x848Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x848Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84848E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84848Eu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84848Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x848Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x848Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84848E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84848Eu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84848Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x848Eu,0x84848Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_8485B7_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8485B7u: goto L_8485B7;
    case 0x8485B9u: goto L_8485B9;
    case 0x8485BCu: goto L_8485BC;
    case 0x8485BEu: goto L_8485BE;
    case 0x8485C0u: goto L_8485C0;
    case 0x8485C3u: goto L_8485C3;
    case 0x8485C5u: goto L_8485C5;
    case 0x8485C7u: goto L_8485C7;
    case 0x8485CAu: goto L_8485CA;
    case 0x8485CCu: goto L_8485CC;
    case 0x8485CEu: goto L_8485CE;
    case 0x8485D0u: goto L_8485D0;
    case 0x8485D2u: goto L_8485D2;
    case 0x8485D4u: goto L_8485D4;
    case 0x8485D6u: goto L_8485D6;
    case 0x8485D8u: goto L_8485D8;
    case 0x8485DAu: goto L_8485DA;
    case 0x8485DCu: goto L_8485DC;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8485B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85B7u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85B7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8485B7 SEP
    cpu.sep(0x20u);
    goto L_8485B9;
L_8485B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85B9u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85B9u, 4u, 3u, cpu.address("abs", 0x062Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8485B9 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8485BC;
L_8485BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85BCu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85BCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8485BC BIT
    cpu.bit(0x1u, true);
    goto L_8485BE;
L_8485BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85BEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85BEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8485BE BNE -> $8485D6
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8485D6; }
    goto L_8485C0;
L_8485C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85C0u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85C0u, 4u, 3u, cpu.address("abs", 0x0629u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8485C0 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x629u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8485C3;
L_8485C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85C3u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85C3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8485C3 BIT
    cpu.bit(0x1u, true);
    goto L_8485C5;
L_8485C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85C5u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85C5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8485C5 BNE -> $8485CE
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8485CE; }
    goto L_8485C7;
L_8485C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85C7u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85C7u, 4u, 3u, cpu.address("abs", 0x062Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8485C7 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8485CA;
L_8485CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85CAu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85CAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8485CA BIT
    cpu.bit(0x1u, true);
    goto L_8485CC;
L_8485CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85CCu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85CCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8485CC BNE -> $8485D6
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8485D6; }
    goto L_8485CE;
L_8485CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85CEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85CEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8485CE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x75u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8485D0;
L_8485D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85D0u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85D0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8485D0 BNE -> $8485DC
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8485DC; }
    goto L_8485D2;
L_8485D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85D2u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85D2u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8485D2 INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_8485D4;
L_8485D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85D4u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85D4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8485D4 BRA -> $8485DC
    goto L_8485DC;
L_8485D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85D6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85D6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x78u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8485D6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x78u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8485D8;
L_8485D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85D8u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85D8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8485D8 BNE -> $8485DC
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8485DC; }
    goto L_8485DA;
L_8485DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85DAu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85DAu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8485DA INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_8485DC;
L_8485DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85DCu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85DCu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8485DC RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8485DCu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8485DCu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_848A57_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848A57u: goto L_848A57;
    case 0x848A59u: goto L_848A59;
    case 0x848A5Cu: goto L_848A5C;
    case 0x848A5Eu: goto L_848A5E;
    case 0x848A60u: goto L_848A60;
    case 0x848A62u: goto L_848A62;
    case 0x848A65u: goto L_848A65;
    case 0x848A68u: goto L_848A68;
    case 0x848A6Bu: goto L_848A6B;
    case 0x848A6Du: goto L_848A6D;
    case 0x848A70u: goto L_848A70;
    case 0x848A72u: goto L_848A72;
    case 0x848A75u: goto L_848A75;
    case 0x848A77u: goto L_848A77;
    case 0x848A7Bu: goto L_848A7B;
    case 0x848A7Cu: goto L_848A7C;
    case 0x848A7Eu: goto L_848A7E;
    case 0x848A81u: goto L_848A81;
    case 0x848A84u: goto L_848A84;
    case 0x848A87u: goto L_848A87;
    case 0x848A89u: goto L_848A89;
    case 0x848A8Cu: goto L_848A8C;
    case 0x848A8Eu: goto L_848A8E;
    case 0x848A91u: goto L_848A91;
    case 0x848A93u: goto L_848A93;
    case 0x848A97u: goto L_848A97;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848A57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A57u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A57u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A57 SEP
    cpu.sep(0x20u);
    goto L_848A59;
L_848A59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A59u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A59u, 4u, 3u, cpu.address("abs", 0x062Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A59 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848A5C;
L_848A5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A5Cu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A5Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A5C BIT
    cpu.bit(0x1u, true);
    goto L_848A5E;
L_848A5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A5Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A5Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A5E BNE -> $848A7C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_848A7C; }
    goto L_848A60;
L_848A60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A60u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A60u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A60 REP
    cpu.rep(0x20u);
    goto L_848A62;
L_848A62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A62u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A62u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A62u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A62 LDX
    cpu.setX(0x2u, 16);
    goto L_848A65;
L_848A65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A65u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A65u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A65 LDY
    cpu.setY(0x6u, 16);
    goto L_848A68;
L_848A68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A68u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A68u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A68 LDA
    cpu.setA(0x2C1Au, 16);
    goto L_848A6B;
L_848A6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A6Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A6Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A6B STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_848A6D;
L_848A6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A6Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A6Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A6D LDA
    cpu.setA(0x7Eu, 16);
    goto L_848A70;
L_848A70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A70u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A70u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A70 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_848A72;
L_848A72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A72u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A72u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A72 LDA
    cpu.setA(0x1800u, 16);
    goto L_848A75;
L_848A75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A75u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A75u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A75 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_848A77;
L_848A77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A77u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A77u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A77u, 8u, 4u, 0x80A839u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848A77 JSL -> $80A839 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8A7Au); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8A7Bu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A839u, 0x848A77u); }
    goto L_848A7B;
L_848A7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A7Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8A7Bu,0x848A7Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A7Bu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A7Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848A7B RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848A7Bu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848A7Bu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_848A7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A7Cu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A7Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A7C REP
    cpu.rep(0x20u);
    goto L_848A7E;
L_848A7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A7Eu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A7Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A7E LDX
    cpu.setX(0x2u, 16);
    goto L_848A81;
L_848A81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A81u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A81u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A81 LDY
    cpu.setY(0x7u, 16);
    goto L_848A84;
L_848A84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A84u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A84u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A84 LDA
    cpu.setA(0x2C2Cu, 16);
    goto L_848A87;
L_848A87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A87u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A87u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A87 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_848A89;
L_848A89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A89u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A89u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A89 LDA
    cpu.setA(0x7Eu, 16);
    goto L_848A8C;
L_848A8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A8Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A8Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A8C STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_848A8E;
L_848A8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A8Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A8Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A8E LDA
    cpu.setA(0x1800u, 16);
    goto L_848A91;
L_848A91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A91u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A91u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A91 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_848A93;
L_848A93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A93u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A93u, 8u, 4u, 0x80A839u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848A93 JSL -> $80A839 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8A96u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8A97u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A839u, 0x848A93u); }
    goto L_848A97;
L_848A97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A97u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8A97u,0x848A97u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A97u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A97u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848A97 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848A97u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848A97u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_848A57_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848A57u: goto L_848A57;
    case 0x848A59u: goto L_848A59;
    case 0x848A5Cu: goto L_848A5C;
    case 0x848A5Eu: goto L_848A5E;
    case 0x848A60u: goto L_848A60;
    case 0x848A62u: goto L_848A62;
    case 0x848A65u: goto L_848A65;
    case 0x848A68u: goto L_848A68;
    case 0x848A6Bu: goto L_848A6B;
    case 0x848A6Du: goto L_848A6D;
    case 0x848A70u: goto L_848A70;
    case 0x848A72u: goto L_848A72;
    case 0x848A75u: goto L_848A75;
    case 0x848A77u: goto L_848A77;
    case 0x848A7Bu: goto L_848A7B;
    case 0x848A7Cu: goto L_848A7C;
    case 0x848A7Eu: goto L_848A7E;
    case 0x848A81u: goto L_848A81;
    case 0x848A84u: goto L_848A84;
    case 0x848A87u: goto L_848A87;
    case 0x848A89u: goto L_848A89;
    case 0x848A8Cu: goto L_848A8C;
    case 0x848A8Eu: goto L_848A8E;
    case 0x848A91u: goto L_848A91;
    case 0x848A93u: goto L_848A93;
    case 0x848A97u: goto L_848A97;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848A57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A57u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A57u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A57 SEP
    cpu.sep(0x20u);
    goto L_848A59;
L_848A59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A59u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A59u, 4u, 3u, cpu.address("abs", 0x062Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A59 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848A5C;
L_848A5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A5Cu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A5Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A5C BIT
    cpu.bit(0x1u, true);
    goto L_848A5E;
L_848A5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A5Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A5Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A5E BNE -> $848A7C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_848A7C; }
    goto L_848A60;
L_848A60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A60u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A60u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A60 REP
    cpu.rep(0x20u);
    goto L_848A62;
L_848A62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A62u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A62u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A62u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A62 LDX
    cpu.setX(0x2u, 16);
    goto L_848A65;
L_848A65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A65u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A65u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A65 LDY
    cpu.setY(0x6u, 16);
    goto L_848A68;
L_848A68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A68u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A68u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A68 LDA
    cpu.setA(0x2C1Au, 16);
    goto L_848A6B;
L_848A6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A6Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A6Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A6B STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_848A6D;
L_848A6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A6Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A6Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A6D LDA
    cpu.setA(0x7Eu, 16);
    goto L_848A70;
L_848A70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A70u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A70u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A70 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_848A72;
L_848A72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A72u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A72u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A72 LDA
    cpu.setA(0x1800u, 16);
    goto L_848A75;
L_848A75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A75u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A75u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A75 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_848A77;
L_848A77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A77u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A77u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A77u, 8u, 4u, 0x80A839u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848A77 JSL -> $80A839 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8A7Au); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8A7Bu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A839u, 0x848A77u); }
    goto L_848A7B;
L_848A7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A7Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8A7Bu,0x848A7Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A7Bu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A7Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848A7B RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848A7Bu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848A7Bu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_848A7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A7Cu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A7Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A7C REP
    cpu.rep(0x20u);
    goto L_848A7E;
L_848A7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A7Eu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A7Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A7E LDX
    cpu.setX(0x2u, 16);
    goto L_848A81;
L_848A81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A81u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A81u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A81 LDY
    cpu.setY(0x7u, 16);
    goto L_848A84;
L_848A84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A84u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A84u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A84 LDA
    cpu.setA(0x2C2Cu, 16);
    goto L_848A87;
L_848A87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A87u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A87u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A87 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_848A89;
L_848A89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A89u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A89u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A89 LDA
    cpu.setA(0x7Eu, 16);
    goto L_848A8C;
L_848A8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A8Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A8Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A8C STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_848A8E;
L_848A8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A8Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A8Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A8E LDA
    cpu.setA(0x1800u, 16);
    goto L_848A91;
L_848A91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A91u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A91u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A91 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_848A93;
L_848A93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A93u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A93u, 8u, 4u, 0x80A839u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848A93 JSL -> $80A839 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8A96u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8A97u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A839u, 0x848A93u); }
    goto L_848A97;
L_848A97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A97u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8A97u,0x848A97u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A97u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A97u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848A97 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848A97u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848A97u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_848C34_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848C34u: goto L_848C34;
    case 0x848C36u: goto L_848C36;
    case 0x848C39u: goto L_848C39;
    case 0x848C3Bu: goto L_848C3B;
    case 0x848C3Eu: goto L_848C3E;
    case 0x848C40u: goto L_848C40;
    case 0x848C44u: goto L_848C44;
    case 0x848C47u: goto L_848C47;
    case 0x848C49u: goto L_848C49;
    case 0x848C4Cu: goto L_848C4C;
    case 0x848C4Eu: goto L_848C4E;
    case 0x848C52u: goto L_848C52;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848C34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C34u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C34u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C34 REP
    cpu.rep(0x20u);
    goto L_848C36;
L_848C36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C36u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C36u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C36 LDA
    cpu.setA(0x8C53u, 16);
    goto L_848C39;
L_848C39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C39u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C39u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C39 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_848C3B;
L_848C3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C3Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C3Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C3B LDA
    cpu.setA(0x84u, 16);
    goto L_848C3E;
L_848C3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C3Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C3Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C3E STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_848C40;
L_848C40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C40u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C40u, 8u, 4u, 0x808B4Cu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848C40 JSL -> $808B4C stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8C43u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8C44u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808B4Cu, 0x848C40u); }
    goto L_848C44;
L_848C44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C44u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C44u,0x848C44u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C44u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C44u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C44 LDA
    cpu.setA(0x8C5Bu, 16);
    goto L_848C47;
L_848C47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C47u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C47u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C47 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_848C49;
L_848C49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C49u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C49u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C49 LDA
    cpu.setA(0x84u, 16);
    goto L_848C4C;
L_848C4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C4Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C4Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C4C STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_848C4E;
L_848C4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C4Eu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C4Eu, 8u, 4u, 0x808B4Cu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848C4E JSL -> $808B4C stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8C51u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8C52u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808B4Cu, 0x848C4Eu); }
    goto L_848C52;
L_848C52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C52u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C52u,0x848C52u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C52u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C52u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848C52 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848C52u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848C52u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_848FC8_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848FC8u: goto L_848FC8;
    case 0x848FCBu: goto L_848FCB;
    case 0x848FCFu: goto L_848FCF;
    case 0x848FD1u: goto L_848FD1;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848FC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC8u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC8u, 8u, 3u, cpu.address("abs", 0xD28Fu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848FC8 DEC
    cpu.decMem(hw, cpu.address("abs", 0xD28Fu), cpu.m8?8:16);
    goto L_848FCB;
L_848FCB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FCBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FCBu,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FCBu, 6u, 4u, 0x208FD6u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848FCB STA
    hw.write(0x208FD6u, cpu.a, cpu.m8?8:16);
    goto L_848FCF;
L_848FCF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FCFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FCFu,cpu,0x43u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FCFu, 5u, 2u, cpu.addressStack(0x99u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848FCF EOR
    cpu.logicXor(hw.readW(cpu.addressStack(0x99u), cpu.m8?8:16));
    goto L_848FD1;
L_848FD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848FD1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848FD1u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848FD1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_848FC8_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848FC8u: goto L_848FC8;
    case 0x848FCBu: goto L_848FCB;
    case 0x848FCFu: goto L_848FCF;
    case 0x848FD1u: goto L_848FD1;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848FC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC8u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC8u, 8u, 3u, cpu.address("abs", 0xD28Fu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848FC8 DEC
    cpu.decMem(hw, cpu.address("abs", 0xD28Fu), cpu.m8?8:16);
    goto L_848FCB;
L_848FCB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FCBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FCBu,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FCBu, 6u, 4u, 0x208FD6u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848FCB STA
    hw.write(0x208FD6u, cpu.a, cpu.m8?8:16);
    goto L_848FCF;
L_848FCF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FCFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FCFu,cpu,0x43u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FCFu, 5u, 2u, cpu.addressStack(0x99u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848FCF EOR
    cpu.logicXor(hw.readW(cpu.addressStack(0x99u), cpu.m8?8:16));
    goto L_848FD1;
L_848FD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848FD1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848FD1u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848FD1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_849CCB_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x849CCBu: goto L_849CCB;
    case 0x849CCFu: goto L_849CCF;
    case 0x849CD1u: goto L_849CD1;
    case 0x849CD4u: goto L_849CD4;
    case 0x849CD6u: goto L_849CD6;
    case 0x849CD8u: goto L_849CD8;
    case 0x849CDBu: goto L_849CDB;
    case 0x849CDCu: goto L_849CDC;
    case 0x849CDDu: goto L_849CDD;
    case 0x849CE0u: goto L_849CE0;
    case 0x849CE3u: goto L_849CE3;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_849CCB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CCBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCBu,cpu,0xCFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCBu, 6u, 4u, 0x9D929Cu, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CCB CMP
    cpu.compareA(hw.readW(0x9D929Cu, cpu.m8?8:16));
    goto L_849CCF;
L_849CCF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CCFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCFu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CCF SEP
    cpu.sep(0x20u);
    goto L_849CD1;
L_849CD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD1u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD1u, 4u, 3u, cpu.address("abs", 0x062Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CD1 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849CD4;
L_849CD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CD4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CD4 AND
    cpu.logicAnd(0x1u);
    goto L_849CD6;
L_849CD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD6u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CD6 REP
    cpu.rep(0x20u);
    goto L_849CD8;
L_849CD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CD8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD8u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CD8 AND
    cpu.logicAnd(0xFFu);
    goto L_849CDB;
L_849CDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CDBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CDBu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CDBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CDB ASL
    cpu.aslA();
    goto L_849CDC;
L_849CDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CDCu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CDCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CDC TAX
    cpu.transfer("TAX");
    goto L_849CDD;
L_849CDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CDDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CDDu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CDDu, 5u, 3u, cpu.address("abs", 0x9CE2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849CDD PEA
    cpu.push16Value(hw, 0x9CE2u);
    goto L_849CE0;
L_849CE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CE0u,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CE0u, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x9CE4u + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $849CE0 JMP (9CE4,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x9CE4u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x849CE0u); return; }
L_849CE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CE3u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CE3u,0x849CE3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CE3u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CE3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849CE3 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x849CE3u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x849CE3u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_849CCB_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x849CCBu: goto L_849CCB;
    case 0x849CCFu: goto L_849CCF;
    case 0x849CD1u: goto L_849CD1;
    case 0x849CD4u: goto L_849CD4;
    case 0x849CD6u: goto L_849CD6;
    case 0x849CD8u: goto L_849CD8;
    case 0x849CDBu: goto L_849CDB;
    case 0x849CDCu: goto L_849CDC;
    case 0x849CDDu: goto L_849CDD;
    case 0x849CE0u: goto L_849CE0;
    case 0x849CE3u: goto L_849CE3;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_849CCB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CCBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCBu,cpu,0xCFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCBu, 6u, 4u, 0x9D929Cu, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CCB CMP
    cpu.compareA(hw.readW(0x9D929Cu, cpu.m8?8:16));
    goto L_849CCF;
L_849CCF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CCFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCFu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CCF SEP
    cpu.sep(0x20u);
    goto L_849CD1;
L_849CD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD1u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD1u, 4u, 3u, cpu.address("abs", 0x062Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CD1 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849CD4;
L_849CD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CD4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CD4 AND
    cpu.logicAnd(0x1u);
    goto L_849CD6;
L_849CD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD6u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CD6 REP
    cpu.rep(0x20u);
    goto L_849CD8;
L_849CD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CD8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD8u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CD8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CD8 AND
    cpu.logicAnd(0xFFu);
    goto L_849CDB;
L_849CDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CDBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CDBu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CDBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CDB ASL
    cpu.aslA();
    goto L_849CDC;
L_849CDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CDCu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CDCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CDC TAX
    cpu.transfer("TAX");
    goto L_849CDD;
L_849CDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CDDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CDDu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CDDu, 5u, 3u, cpu.address("abs", 0x9CE2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849CDD PEA
    cpu.push16Value(hw, 0x9CE2u);
    goto L_849CE0;
L_849CE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CE0u,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CE0u, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x9CE4u + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $849CE0 JMP (9CE4,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x9CE4u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x849CE0u); return; }
L_849CE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CE3u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CE3u,0x849CE3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CE3u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CE3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849CE3 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x849CE3u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x849CE3u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_84B357_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84B357u: goto L_84B357;
    case 0x84B359u: goto L_84B359;
    case 0x84B35Cu: goto L_84B35C;
    case 0x84B35Fu: goto L_84B35F;
    case 0x84B362u: goto L_84B362;
    case 0x84B366u: goto L_84B366;
    case 0x84B369u: goto L_84B369;
    case 0x84B36Cu: goto L_84B36C;
    case 0x84B36Fu: goto L_84B36F;
    case 0x84B372u: goto L_84B372;
    case 0x84B376u: goto L_84B376;
    case 0x84B378u: goto L_84B378;
    case 0x84B37Au: goto L_84B37A;
    case 0x84B37Bu: goto L_84B37B;
    case 0x84B37Eu: goto L_84B37E;
    case 0x84B381u: goto L_84B381;
    case 0x84B384u: goto L_84B384;
    case 0x84B388u: goto L_84B388;
    case 0x84B38Bu: goto L_84B38B;
    case 0x84B38Eu: goto L_84B38E;
    case 0x84B391u: goto L_84B391;
    case 0x84B394u: goto L_84B394;
    case 0x84B398u: goto L_84B398;
    case 0x84B39Au: goto L_84B39A;
    case 0x84B39Cu: goto L_84B39C;
    case 0x84B39Du: goto L_84B39D;
    case 0x84B3A0u: goto L_84B3A0;
    case 0x84B3A3u: goto L_84B3A3;
    case 0x84B3A6u: goto L_84B3A6;
    case 0x84B3AAu: goto L_84B3AA;
    case 0x84B3ADu: goto L_84B3AD;
    case 0x84B3B0u: goto L_84B3B0;
    case 0x84B3B3u: goto L_84B3B3;
    case 0x84B3B6u: goto L_84B3B6;
    case 0x84B3BAu: goto L_84B3BA;
    case 0x84B3BCu: goto L_84B3BC;
    case 0x84B3BEu: goto L_84B3BE;
    case 0x84B3BFu: goto L_84B3BF;
    case 0x84B3C2u: goto L_84B3C2;
    case 0x84B3C5u: goto L_84B3C5;
    case 0x84B3C8u: goto L_84B3C8;
    case 0x84B3CCu: goto L_84B3CC;
    case 0x84B3CFu: goto L_84B3CF;
    case 0x84B3D2u: goto L_84B3D2;
    case 0x84B3D5u: goto L_84B3D5;
    case 0x84B3D8u: goto L_84B3D8;
    case 0x84B3DCu: goto L_84B3DC;
    case 0x84B3DEu: goto L_84B3DE;
    case 0x84B3E0u: goto L_84B3E0;
    case 0x84B3E1u: goto L_84B3E1;
    case 0x84B3E4u: goto L_84B3E4;
    case 0x84B3E7u: goto L_84B3E7;
    case 0x84B3EAu: goto L_84B3EA;
    case 0x84B3EEu: goto L_84B3EE;
    case 0x84B3F1u: goto L_84B3F1;
    case 0x84B3F4u: goto L_84B3F4;
    case 0x84B3F7u: goto L_84B3F7;
    case 0x84B3FAu: goto L_84B3FA;
    case 0x84B3FEu: goto L_84B3FE;
    case 0x84B3FFu: goto L_84B3FF;
    case 0x84B402u: goto L_84B402;
    case 0x84B405u: goto L_84B405;
    case 0x84B407u: goto L_84B407;
    case 0x84B408u: goto L_84B408;
    case 0x84B40Bu: goto L_84B40B;
    case 0x84B40Cu: goto L_84B40C;
    case 0x84B40Fu: goto L_84B40F;
    case 0x84B412u: goto L_84B412;
    case 0x84B415u: goto L_84B415;
    case 0x84B418u: goto L_84B418;
    case 0x84B41Cu: goto L_84B41C;
    case 0x84B41Du: goto L_84B41D;
    case 0x84B420u: goto L_84B420;
    case 0x84B423u: goto L_84B423;
    case 0x84B425u: goto L_84B425;
    case 0x84B426u: goto L_84B426;
    case 0x84B429u: goto L_84B429;
    case 0x84B42Au: goto L_84B42A;
    case 0x84B42Du: goto L_84B42D;
    case 0x84B430u: goto L_84B430;
    case 0x84B433u: goto L_84B433;
    case 0x84B435u: goto L_84B435;
    case 0x84B438u: goto L_84B438;
    case 0x84B43Au: goto L_84B43A;
    case 0x84B43Du: goto L_84B43D;
    case 0x84B43Fu: goto L_84B43F;
    case 0x84B443u: goto L_84B443;
    case 0x84B446u: goto L_84B446;
    case 0x84B449u: goto L_84B449;
    case 0x84B44Cu: goto L_84B44C;
    case 0x84B44Eu: goto L_84B44E;
    case 0x84B451u: goto L_84B451;
    case 0x84B453u: goto L_84B453;
    case 0x84B456u: goto L_84B456;
    case 0x84B458u: goto L_84B458;
    case 0x84B45Cu: goto L_84B45C;
    case 0x84B45Eu: goto L_84B45E;
    case 0x84B460u: goto L_84B460;
    case 0x84B461u: goto L_84B461;
    case 0x84B464u: goto L_84B464;
    case 0x84B467u: goto L_84B467;
    case 0x84B46Au: goto L_84B46A;
    case 0x84B46Eu: goto L_84B46E;
    case 0x84B470u: goto L_84B470;
    case 0x84B472u: goto L_84B472;
    case 0x84B473u: goto L_84B473;
    case 0x84B476u: goto L_84B476;
    case 0x84B479u: goto L_84B479;
    case 0x84B47Cu: goto L_84B47C;
    case 0x84B480u: goto L_84B480;
    case 0x84B482u: goto L_84B482;
    case 0x84B484u: goto L_84B484;
    case 0x84B485u: goto L_84B485;
    case 0x84B488u: goto L_84B488;
    case 0x84B48Bu: goto L_84B48B;
    case 0x84B48Eu: goto L_84B48E;
    case 0x84B492u: goto L_84B492;
    case 0x84B495u: goto L_84B495;
    case 0x84B497u: goto L_84B497;
    case 0x84B49Au: goto L_84B49A;
    case 0x84B49Cu: goto L_84B49C;
    case 0x84B49Fu: goto L_84B49F;
    case 0x84B4A2u: goto L_84B4A2;
    case 0x84B4A6u: goto L_84B4A6;
    case 0x84B4A9u: goto L_84B4A9;
    case 0x84B4ACu: goto L_84B4AC;
    case 0x84B4AEu: goto L_84B4AE;
    case 0x84B4B0u: goto L_84B4B0;
    case 0x84B4B2u: goto L_84B4B2;
    case 0x84B4B4u: goto L_84B4B4;
    case 0x84B4B7u: goto L_84B4B7;
    case 0x84B4BAu: goto L_84B4BA;
    case 0x84B4BDu: goto L_84B4BD;
    case 0x84B4C0u: goto L_84B4C0;
    case 0x84B4C3u: goto L_84B4C3;
    case 0x84B4C6u: goto L_84B4C6;
    case 0x84B4C8u: goto L_84B4C8;
    case 0x84B4CAu: goto L_84B4CA;
    case 0x84B4CDu: goto L_84B4CD;
    case 0x84B4CFu: goto L_84B4CF;
    case 0x84B4D2u: goto L_84B4D2;
    case 0x84B4D4u: goto L_84B4D4;
    case 0x84B4D7u: goto L_84B4D7;
    case 0x84B4D9u: goto L_84B4D9;
    case 0x84B4DCu: goto L_84B4DC;
    case 0x84B4DEu: goto L_84B4DE;
    case 0x84B4DFu: goto L_84B4DF;
    case 0x84B4E1u: goto L_84B4E1;
    case 0x84B4E5u: goto L_84B4E5;
    case 0x84B4E8u: goto L_84B4E8;
    case 0x84B4EAu: goto L_84B4EA;
    case 0x84B4ECu: goto L_84B4EC;
    case 0x84B4F0u: goto L_84B4F0;
    case 0x84B4F4u: goto L_84B4F4;
    case 0x84B4F7u: goto L_84B4F7;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84B357:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB357u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB357u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB357u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B357 REP
    cpu.rep(0x20u);
    goto L_84B359;
L_84B359:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB359u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB359u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB359u, 5u, 3u, cpu.address("abs", 0x01A5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B359 STZ
    hw.write(cpu.address("abs", 0x1A5u), 0, cpu.m8?8:16);
    goto L_84B35C;
L_84B35C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB35Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB35Cu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB35Cu, 5u, 3u, cpu.address("abs", 0x01A1u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B35C STZ
    hw.write(cpu.address("abs", 0x1A1u), 0, cpu.m8?8:16);
    goto L_84B35F;
L_84B35F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB35Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB35Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB35Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B35F LDA
    cpu.setA(0x1u, 16);
    goto L_84B362;
L_84B362:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB362u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB362u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB362u, 8u, 4u, 0x808D4Au, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B362 JSL -> $808D4A stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB365u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB366u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808D4Au, 0x84B362u); }
    goto L_84B366;
L_84B366:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB366u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB366u,0x84B366u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB366u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB366u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B366 LDA
    cpu.setA(0x9F49u, 16);
    goto L_84B369;
L_84B369:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB369u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB369u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB369u, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B369 STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_84B36C;
L_84B36C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB36Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB36Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB36Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B36C LDA
    cpu.setA(0x8Eu, 16);
    goto L_84B36F;
L_84B36F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB36Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB36Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB36Fu, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B36F STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_84B372;
L_84B372:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB372u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB372u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB372u, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B372 JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB375u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB376u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x84B372u); }
    goto L_84B376;
L_84B376:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB376u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB376u,0x84B376u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB376u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB376u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B376 SEP
    cpu.sep(0x20u);
    goto L_84B378;
L_84B378:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB378u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB378u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB378u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B378 LDA
    cpu.setA(0x7Eu, 8);
    goto L_84B37A;
L_84B37A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB37Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB37Au,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB37Au, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $84B37A PHA
    cpu.push("PHA", hw);
    goto L_84B37B;
L_84B37B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB37Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB37Bu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB37Bu, 5u, 3u, cpu.address("abs", 0x8000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B37B PEA
    cpu.push16Value(hw, 0x8000u);
    goto L_84B37E;
L_84B37E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB37Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB37Eu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB37Eu, 5u, 3u, cpu.address("abs", 0x0000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B37E PEA
    cpu.push16Value(hw, 0x0u);
    goto L_84B381;
L_84B381:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB381u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB381u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB381u, 5u, 3u, cpu.address("abs", 0x2000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B381 PEA
    cpu.push16Value(hw, 0x2000u);
    goto L_84B384;
L_84B384:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB384u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB384u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB384u, 8u, 4u, 0x809B54u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B384 JSL -> $809B54 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB387u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB388u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809B54u, 0x84B384u); }
    goto L_84B388;
L_84B388:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB388u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB388u,0x84B388u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB388u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB388u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B388 LDA
    cpu.setA(0x8A29u, 16);
    goto L_84B38B;
L_84B38B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB38Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB38Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB38Bu, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B38B STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_84B38E;
L_84B38E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB38Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB38Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB38Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B38E LDA
    cpu.setA(0x8Bu, 16);
    goto L_84B391;
L_84B391:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB391u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB391u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB391u, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B391 STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_84B394;
L_84B394:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB394u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB394u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB394u, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B394 JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB397u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB398u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x84B394u); }
    goto L_84B398;
L_84B398:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB398u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB398u,0x84B398u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB398u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB398u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B398 SEP
    cpu.sep(0x20u);
    goto L_84B39A;
L_84B39A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB39Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B39A LDA
    cpu.setA(0x7Eu, 8);
    goto L_84B39C;
L_84B39C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB39Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Cu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Cu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $84B39C PHA
    cpu.push("PHA", hw);
    goto L_84B39D;
L_84B39D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB39Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Du,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Du, 5u, 3u, cpu.address("abs", 0x8000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B39D PEA
    cpu.push16Value(hw, 0x8000u);
    goto L_84B3A0;
L_84B3A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A0u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A0u, 5u, 3u, cpu.address("abs", 0x1000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B3A0 PEA
    cpu.push16Value(hw, 0x1000u);
    goto L_84B3A3;
L_84B3A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A3u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A3u, 5u, 3u, cpu.address("abs", 0x2000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B3A3 PEA
    cpu.push16Value(hw, 0x2000u);
    goto L_84B3A6;
L_84B3A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A6u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A6u, 8u, 4u, 0x809B54u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B3A6 JSL -> $809B54 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB3A9u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB3AAu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809B54u, 0x84B3A6u); }
    goto L_84B3AA;
L_84B3AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3AAu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB3AAu,0x84B3AAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3AAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3AAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B3AA LDA
    cpu.setA(0xB1C3u, 16);
    goto L_84B3AD;
L_84B3AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3ADu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3ADu, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B3AD STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_84B3B0;
L_84B3B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3B0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3B0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B3B0 LDA
    cpu.setA(0x8Eu, 16);
    goto L_84B3B3;
L_84B3B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3B3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3B3u, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B3B3 STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_84B3B6;
L_84B3B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3B6u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3B6u, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B3B6 JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB3B9u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB3BAu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x84B3B6u); }
    goto L_84B3BA;
L_84B3BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3BAu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB3BAu,0x84B3BAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3BAu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3BAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B3BA SEP
    cpu.sep(0x20u);
    goto L_84B3BC;
L_84B3BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3BCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3BCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B3BC LDA
    cpu.setA(0x7Eu, 8);
    goto L_84B3BE;
L_84B3BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3BEu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3BEu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $84B3BE PHA
    cpu.push("PHA", hw);
    goto L_84B3BF;
L_84B3BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3BFu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3BFu, 5u, 3u, cpu.address("abs", 0x8000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B3BF PEA
    cpu.push16Value(hw, 0x8000u);
    goto L_84B3C2;
L_84B3C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3C2u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3C2u, 5u, 3u, cpu.address("abs", 0x2000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B3C2 PEA
    cpu.push16Value(hw, 0x2000u);
    goto L_84B3C5;
L_84B3C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3C5u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3C5u, 5u, 3u, cpu.address("abs", 0x2000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B3C5 PEA
    cpu.push16Value(hw, 0x2000u);
    goto L_84B3C8;
L_84B3C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3C8u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3C8u, 8u, 4u, 0x809B54u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B3C8 JSL -> $809B54 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB3CBu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB3CCu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809B54u, 0x84B3C8u); }
    goto L_84B3CC;
L_84B3CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3CCu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB3CCu,0x84B3CCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3CCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3CCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B3CC LDA
    cpu.setA(0x8000u, 16);
    goto L_84B3CF;
L_84B3CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3CFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3CFu, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B3CF STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_84B3D2;
L_84B3D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3D2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3D2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B3D2 LDA
    cpu.setA(0x8Fu, 16);
    goto L_84B3D5;
L_84B3D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3D5u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3D5u, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B3D5 STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_84B3D8;
L_84B3D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3D8u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3D8u, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B3D8 JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB3DBu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB3DCu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x84B3D8u); }
    goto L_84B3DC;
L_84B3DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3DCu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB3DCu,0x84B3DCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3DCu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3DCu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B3DC SEP
    cpu.sep(0x20u);
    goto L_84B3DE;
L_84B3DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3DEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3DEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B3DE LDA
    cpu.setA(0x7Eu, 8);
    goto L_84B3E0;
L_84B3E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3E0u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3E0u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $84B3E0 PHA
    cpu.push("PHA", hw);
    goto L_84B3E1;
L_84B3E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3E1u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3E1u, 5u, 3u, cpu.address("abs", 0x8000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B3E1 PEA
    cpu.push16Value(hw, 0x8000u);
    goto L_84B3E4;
L_84B3E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3E4u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3E4u, 5u, 3u, cpu.address("abs", 0x6000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B3E4 PEA
    cpu.push16Value(hw, 0x6000u);
    goto L_84B3E7;
L_84B3E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3E7u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3E7u, 5u, 3u, cpu.address("abs", 0x4000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B3E7 PEA
    cpu.push16Value(hw, 0x4000u);
    goto L_84B3EA;
L_84B3EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3EAu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3EAu, 8u, 4u, 0x809B54u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B3EA JSL -> $809B54 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB3EDu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB3EEu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809B54u, 0x84B3EAu); }
    goto L_84B3EE;
L_84B3EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3EEu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB3EEu,0x84B3EEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3EEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3EEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B3EE LDA
    cpu.setA(0xC651u, 16);
    goto L_84B3F1;
L_84B3F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3F1u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3F1u, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B3F1 STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_84B3F4;
L_84B3F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3F4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3F4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B3F4 LDA
    cpu.setA(0x8Bu, 16);
    goto L_84B3F7;
L_84B3F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3F7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3F7u, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B3F7 STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_84B3FA;
L_84B3FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3FAu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3FAu, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B3FA JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB3FDu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB3FEu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x84B3FAu); }
    goto L_84B3FE;
L_84B3FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3FEu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB3FEu,0x84B3FEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3FEu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3FEu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $84B3FE PHB
    cpu.push("PHB", hw);
    goto L_84B3FF;
L_84B3FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3FFu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3FFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B3FF LDX
    cpu.setX(0x8000u, 16);
    goto L_84B402;
L_84B402:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB402u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB402u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB402u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B402 LDY
    cpu.setY(0x2800u, 16);
    goto L_84B405;
L_84B405:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB405u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB405u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB405u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xBDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B405 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xBDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84B407;
L_84B407:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB407u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB407u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB407u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B407 DEC
    cpu.decReg('A');
    goto L_84B408;
L_84B408:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB408u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB408u,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xB408u, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $84B408 MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_84B40B;
L_84B40B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB40Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB40Bu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB40Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $84B40B PLB
    cpu.pop("PLB", hw);
    goto L_84B40C;
L_84B40C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB40Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB40Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB40Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B40C LDA
    cpu.setA(0xC268u, 16);
    goto L_84B40F;
L_84B40F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB40Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB40Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB40Fu, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B40F STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_84B412;
L_84B412:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB412u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB412u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB412u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B412 LDA
    cpu.setA(0x8Bu, 16);
    goto L_84B415;
L_84B415:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB415u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB415u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB415u, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B415 STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_84B418;
L_84B418:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB418u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB418u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB418u, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B418 JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB41Bu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB41Cu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x84B418u); }
    goto L_84B41C;
L_84B41C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB41Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB41Cu,0x84B41Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB41Cu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB41Cu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $84B41C PHB
    cpu.push("PHB", hw);
    goto L_84B41D;
L_84B41D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB41Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB41Du,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB41Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B41D LDX
    cpu.setX(0x8000u, 16);
    goto L_84B420;
L_84B420:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB420u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB420u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB420u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B420 LDY
    cpu.setY(0x4000u, 16);
    goto L_84B423;
L_84B423:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB423u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB423u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB423u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xBDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B423 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xBDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84B425;
L_84B425:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB425u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB425u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB425u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B425 DEC
    cpu.decReg('A');
    goto L_84B426;
L_84B426:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB426u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB426u,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xB426u, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $84B426 MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_84B429;
L_84B429:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB429u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB429u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB429u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $84B429 PLB
    cpu.pop("PLB", hw);
    goto L_84B42A;
L_84B42A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB42Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB42Au,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB42Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B42A LDX
    cpu.setX(0x4u, 16);
    goto L_84B42D;
L_84B42D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB42Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB42Du,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB42Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B42D LDY
    cpu.setY(0x14u, 16);
    goto L_84B430;
L_84B430:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB430u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB430u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB430u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B430 LDA
    cpu.setA(0x288Cu, 16);
    goto L_84B433;
L_84B433:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB433u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB433u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB433u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B433 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_84B435;
L_84B435:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB435u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB435u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB435u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B435 LDA
    cpu.setA(0x7Eu, 16);
    goto L_84B438;
L_84B438:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB438u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB438u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB438u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B438 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_84B43A;
L_84B43A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB43Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB43Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB43Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B43A LDA
    cpu.setA(0x800u, 16);
    goto L_84B43D;
L_84B43D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB43Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB43Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB43Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B43D STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_84B43F;
L_84B43F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB43Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB43Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB43Fu, 8u, 4u, 0x80A839u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B43F JSL -> $80A839 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB442u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB443u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A839u, 0x84B43Fu); }
    goto L_84B443;
L_84B443:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB443u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB443u,0x84B443u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB443u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB443u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B443 LDX
    cpu.setX(0x1Au, 16);
    goto L_84B446;
L_84B446:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB446u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB446u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB446u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B446 LDY
    cpu.setY(0x1Eu, 16);
    goto L_84B449;
L_84B449:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB449u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB449u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB449u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B449 LDA
    cpu.setA(0x6042u, 16);
    goto L_84B44C;
L_84B44C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB44Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB44Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB44Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B44C STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_84B44E;
L_84B44E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB44Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB44Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB44Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B44E LDA
    cpu.setA(0x7Eu, 16);
    goto L_84B451;
L_84B451:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB451u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB451u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB451u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B451 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_84B453;
L_84B453:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB453u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB453u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB453u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B453 LDA
    cpu.setA(0x4u, 16);
    goto L_84B456;
L_84B456:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB456u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB456u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB456u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B456 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_84B458;
L_84B458:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB458u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB458u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB458u, 8u, 4u, 0x80A85Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B458 JSL -> $80A85F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB45Bu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB45Cu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A85Fu, 0x84B458u); }
    goto L_84B45C;
L_84B45C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB45Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB45Cu,0x84B45Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB45Cu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB45Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B45C SEP
    cpu.sep(0x20u);
    goto L_84B45E;
L_84B45E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB45Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB45Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB45Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B45E LDA
    cpu.setA(0x7Eu, 8);
    goto L_84B460;
L_84B460:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB460u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB460u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB460u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $84B460 PHA
    cpu.push("PHA", hw);
    goto L_84B461;
L_84B461:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB461u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB461u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB461u, 5u, 3u, cpu.address("abs", 0x2800u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B461 PEA
    cpu.push16Value(hw, 0x2800u);
    goto L_84B464;
L_84B464:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB464u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB464u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB464u, 5u, 3u, cpu.address("abs", 0x3000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B464 PEA
    cpu.push16Value(hw, 0x3000u);
    goto L_84B467;
L_84B467:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB467u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB467u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB467u, 5u, 3u, cpu.address("abs", 0x0800u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B467 PEA
    cpu.push16Value(hw, 0x800u);
    goto L_84B46A;
L_84B46A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB46Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB46Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB46Au, 8u, 4u, 0x809B54u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B46A JSL -> $809B54 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB46Du); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB46Eu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809B54u, 0x84B46Au); }
    goto L_84B46E;
L_84B46E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB46Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB46Eu,0x84B46Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB46Eu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB46Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B46E SEP
    cpu.sep(0x20u);
    goto L_84B470;
L_84B470:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB470u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB470u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB470u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B470 LDA
    cpu.setA(0x7Eu, 8);
    goto L_84B472;
L_84B472:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB472u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB472u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB472u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $84B472 PHA
    cpu.push("PHA", hw);
    goto L_84B473;
L_84B473:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB473u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB473u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB473u, 5u, 3u, cpu.address("abs", 0x4000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B473 PEA
    cpu.push16Value(hw, 0x4000u);
    goto L_84B476;
L_84B476:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB476u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB476u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB476u, 5u, 3u, cpu.address("abs", 0x5000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B476 PEA
    cpu.push16Value(hw, 0x5000u);
    goto L_84B479;
L_84B479:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB479u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB479u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB479u, 5u, 3u, cpu.address("abs", 0x2000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B479 PEA
    cpu.push16Value(hw, 0x2000u);
    goto L_84B47C;
L_84B47C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB47Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB47Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB47Cu, 8u, 4u, 0x809B54u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B47C JSL -> $809B54 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB47Fu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB480u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809B54u, 0x84B47Cu); }
    goto L_84B480;
L_84B480:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB480u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB480u,0x84B480u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB480u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB480u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B480 SEP
    cpu.sep(0x20u);
    goto L_84B482;
L_84B482:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB482u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB482u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB482u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B482 LDA
    cpu.setA(0x7Eu, 8);
    goto L_84B484;
L_84B484:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB484u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB484u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB484u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $84B484 PHA
    cpu.push("PHA", hw);
    goto L_84B485;
L_84B485:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB485u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB485u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB485u, 5u, 3u, cpu.address("abs", 0x6000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B485 PEA
    cpu.push16Value(hw, 0x6000u);
    goto L_84B488;
L_84B488:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB488u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB488u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB488u, 5u, 3u, cpu.address("abs", 0x4000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B488 PEA
    cpu.push16Value(hw, 0x4000u);
    goto L_84B48B;
L_84B48B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB48Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB48Bu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB48Bu, 5u, 3u, cpu.address("abs", 0x0800u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B48B PEA
    cpu.push16Value(hw, 0x800u);
    goto L_84B48E;
L_84B48E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB48Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB48Eu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB48Eu, 8u, 4u, 0x809B54u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B48E JSL -> $809B54 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB491u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB492u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809B54u, 0x84B48Eu); }
    goto L_84B492;
L_84B492:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB492u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB492u,0x84B492u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB492u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB492u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B492 LDA
    cpu.setA(0x9E6Cu, 16);
    goto L_84B495;
L_84B495:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB495u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB495u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB495u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B495 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_84B497;
L_84B497:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB497u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB497u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB497u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B497 LDA
    cpu.setA(0x8Au, 16);
    goto L_84B49A;
L_84B49A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB49Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB49Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB49Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B49A STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_84B49C;
L_84B49C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB49Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB49Cu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB49Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B49C LDX
    cpu.setX(0x0u, 16);
    goto L_84B49F;
L_84B49F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB49Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB49Fu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB49Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B49F LDY
    cpu.setY(0x200u, 16);
    goto L_84B4A2;
L_84B4A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4A2u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4A2u, 8u, 4u, 0x808BB9u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B4A2 JSL -> $808BB9 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB4A5u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB4A6u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808BB9u, 0x84B4A2u); }
    goto L_84B4A6;
L_84B4A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4A6u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB4A6u,0x84B4A6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4A6u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4A6u, 6u, 3u, cpu.address("abs", 0xB6EFu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B4A6 JSR -> $84B6EF stack real
    { cpu.push16Value(hw,0xB4A8u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB4A9u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB6EFu), 0x84B4A6u); }
    goto L_84B4A9;
L_84B4A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4A9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB4A9u,0x84B4A9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4A9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4A9u, 6u, 3u, cpu.address("abs", 0xB5F5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B4A9 JSR -> $84B5F5 stack real
    { cpu.push16Value(hw,0xB4ABu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB4ACu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB5F5u), 0x84B4A9u); }
    goto L_84B4AC;
L_84B4AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4ACu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB4ACu,0x84B4ACu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4ACu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4ACu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B4AC STZ
    hw.write(cpu.address("dp", 0x6Bu), 0, cpu.m8?8:16);
    goto L_84B4AE;
L_84B4AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4AEu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4AEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B4AE STZ
    hw.write(cpu.address("dp", 0x6Du), 0, cpu.m8?8:16);
    goto L_84B4B0;
L_84B4B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B0u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B4B0 STZ
    hw.write(cpu.address("dp", 0x6Fu), 0, cpu.m8?8:16);
    goto L_84B4B2;
L_84B4B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B2u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x71u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B4B2 STZ
    hw.write(cpu.address("dp", 0x71u), 0, cpu.m8?8:16);
    goto L_84B4B4;
L_84B4B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B4u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B4u, 5u, 3u, cpu.address("abs", 0x0658u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B4B4 STZ
    hw.write(cpu.address("abs", 0x658u), 0, cpu.m8?8:16);
    goto L_84B4B7;
L_84B4B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B7u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B7u, 5u, 3u, cpu.address("abs", 0x065Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B4B7 STZ
    hw.write(cpu.address("abs", 0x65Au), 0, cpu.m8?8:16);
    goto L_84B4BA;
L_84B4BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BAu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BAu, 5u, 3u, cpu.address("abs", 0x0667u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B4BA STZ
    hw.write(cpu.address("abs", 0x667u), 0, cpu.m8?8:16);
    goto L_84B4BD;
L_84B4BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BDu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BDu, 5u, 3u, cpu.address("abs", 0x0669u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B4BD STZ
    hw.write(cpu.address("abs", 0x669u), 0, cpu.m8?8:16);
    goto L_84B4C0;
L_84B4C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C0u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C0u, 5u, 3u, cpu.address("abs", 0x0082u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B4C0 STZ
    hw.write(cpu.address("abs", 0x82u), 0, cpu.m8?8:16);
    goto L_84B4C3;
L_84B4C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C3u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C3u, 5u, 3u, cpu.address("abs", 0x0084u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B4C3 STZ
    hw.write(cpu.address("abs", 0x84u), 0, cpu.m8?8:16);
    goto L_84B4C6;
L_84B4C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C6u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B4C6 SEP
    cpu.sep(0x20u);
    goto L_84B4C8;
L_84B4C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B4C8 LDA
    cpu.setA(0x53u, 8);
    goto L_84B4CA;
L_84B4CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4CAu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4CAu, 4u, 3u, cpu.address("abs", 0x2108u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B4CA STA
    hw.write(cpu.address("abs", 0x2108u), cpu.a, cpu.m8?8:16);
    goto L_84B4CD;
L_84B4CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4CDu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4CDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B4CD STZ
    hw.write(cpu.address("dp", 0x49u), 0, cpu.m8?8:16);
    goto L_84B4CF;
L_84B4CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4CFu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4CFu, 4u, 3u, cpu.address("abs", 0x0657u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B4CF STZ
    hw.write(cpu.address("abs", 0x657u), 0, cpu.m8?8:16);
    goto L_84B4D2;
L_84B4D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4D2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4D2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B4D2 LDA
    cpu.setA(0x2u, 8);
    goto L_84B4D4;
L_84B4D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4D4u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4D4u, 4u, 3u, cpu.address("abs", 0x2130u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B4D4 STA
    hw.write(cpu.address("abs", 0x2130u), cpu.a, cpu.m8?8:16);
    goto L_84B4D7;
L_84B4D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4D7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4D7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B4D7 LDA
    cpu.setA(0x82u, 8);
    goto L_84B4D9;
L_84B4D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4D9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4D9u, 4u, 3u, cpu.address("abs", 0x2131u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B4D9 STA
    hw.write(cpu.address("abs", 0x2131u), cpu.a, cpu.m8?8:16);
    goto L_84B4DC;
L_84B4DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4DCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4DCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B4DC LDA
    cpu.setA(0xC1u, 8);
    goto L_84B4DE;
L_84B4DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4DEu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4DEu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B4DE XBA
    cpu.xba();
    goto L_84B4DF;
L_84B4DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4DFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4DFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B4DF LDA
    cpu.setA(0x0u, 8);
    goto L_84B4E1;
L_84B4E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E1u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E1u, 8u, 4u, 0x8086F4u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B4E1 JSL -> $8086F4 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB4E4u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB4E5u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8086F4u, 0x84B4E1u); }
    goto L_84B4E5;
L_84B4E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4E5u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB4E5u,0x84B4E5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E5u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E5u, 4u, 3u, cpu.address("abs", 0x01BFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B4E5 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84B4E8;
L_84B4E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E8u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B4E8 BNE -> $84B4F7
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_84B4F7; }
    goto L_84B4EA;
L_84B4EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4EAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4EAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B4EA LDA
    cpu.setA(0x10u, 8);
    goto L_84B4EC;
L_84B4EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4ECu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4ECu, 8u, 4u, 0x80A6BDu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B4EC JSL -> $80A6BD stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB4EFu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB4F0u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6BDu, 0x84B4ECu); }
    goto L_84B4F0;
L_84B4F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4F0u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB4F0u,0x84B4F0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F0u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F0u, 8u, 4u, 0x80A6A5u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B4F0 JSL -> $80A6A5 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB4F3u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB4F4u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6A5u, 0x84B4F0u); }
    goto L_84B4F4;
L_84B4F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4F4u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB4F4u,0x84B4F4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F4u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F4u, 6u, 3u, cpu.address("abs", 0x01BFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B4F4 INC
    cpu.incMem(hw, cpu.address("abs", 0x1BFu), cpu.m8?8:16);
    goto L_84B4F7;
L_84B4F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F7u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B4F7 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x84B4F7u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84B4F7u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_84B357_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84B357u: goto L_84B357;
    case 0x84B359u: goto L_84B359;
    case 0x84B35Cu: goto L_84B35C;
    case 0x84B35Fu: goto L_84B35F;
    case 0x84B362u: goto L_84B362;
    case 0x84B366u: goto L_84B366;
    case 0x84B369u: goto L_84B369;
    case 0x84B36Cu: goto L_84B36C;
    case 0x84B36Fu: goto L_84B36F;
    case 0x84B372u: goto L_84B372;
    case 0x84B376u: goto L_84B376;
    case 0x84B378u: goto L_84B378;
    case 0x84B37Au: goto L_84B37A;
    case 0x84B37Bu: goto L_84B37B;
    case 0x84B37Eu: goto L_84B37E;
    case 0x84B381u: goto L_84B381;
    case 0x84B384u: goto L_84B384;
    case 0x84B388u: goto L_84B388;
    case 0x84B38Bu: goto L_84B38B;
    case 0x84B38Eu: goto L_84B38E;
    case 0x84B391u: goto L_84B391;
    case 0x84B394u: goto L_84B394;
    case 0x84B398u: goto L_84B398;
    case 0x84B39Au: goto L_84B39A;
    case 0x84B39Cu: goto L_84B39C;
    case 0x84B39Du: goto L_84B39D;
    case 0x84B3A0u: goto L_84B3A0;
    case 0x84B3A3u: goto L_84B3A3;
    case 0x84B3A6u: goto L_84B3A6;
    case 0x84B3AAu: goto L_84B3AA;
    case 0x84B3ADu: goto L_84B3AD;
    case 0x84B3B0u: goto L_84B3B0;
    case 0x84B3B3u: goto L_84B3B3;
    case 0x84B3B6u: goto L_84B3B6;
    case 0x84B3BAu: goto L_84B3BA;
    case 0x84B3BCu: goto L_84B3BC;
    case 0x84B3BEu: goto L_84B3BE;
    case 0x84B3BFu: goto L_84B3BF;
    case 0x84B3C2u: goto L_84B3C2;
    case 0x84B3C5u: goto L_84B3C5;
    case 0x84B3C8u: goto L_84B3C8;
    case 0x84B3CCu: goto L_84B3CC;
    case 0x84B3CFu: goto L_84B3CF;
    case 0x84B3D2u: goto L_84B3D2;
    case 0x84B3D5u: goto L_84B3D5;
    case 0x84B3D8u: goto L_84B3D8;
    case 0x84B3DCu: goto L_84B3DC;
    case 0x84B3DEu: goto L_84B3DE;
    case 0x84B3E0u: goto L_84B3E0;
    case 0x84B3E1u: goto L_84B3E1;
    case 0x84B3E4u: goto L_84B3E4;
    case 0x84B3E7u: goto L_84B3E7;
    case 0x84B3EAu: goto L_84B3EA;
    case 0x84B3EEu: goto L_84B3EE;
    case 0x84B3F1u: goto L_84B3F1;
    case 0x84B3F4u: goto L_84B3F4;
    case 0x84B3F7u: goto L_84B3F7;
    case 0x84B3FAu: goto L_84B3FA;
    case 0x84B3FEu: goto L_84B3FE;
    case 0x84B3FFu: goto L_84B3FF;
    case 0x84B402u: goto L_84B402;
    case 0x84B405u: goto L_84B405;
    case 0x84B407u: goto L_84B407;
    case 0x84B408u: goto L_84B408;
    case 0x84B40Bu: goto L_84B40B;
    case 0x84B40Cu: goto L_84B40C;
    case 0x84B40Fu: goto L_84B40F;
    case 0x84B412u: goto L_84B412;
    case 0x84B415u: goto L_84B415;
    case 0x84B418u: goto L_84B418;
    case 0x84B41Cu: goto L_84B41C;
    case 0x84B41Du: goto L_84B41D;
    case 0x84B420u: goto L_84B420;
    case 0x84B423u: goto L_84B423;
    case 0x84B425u: goto L_84B425;
    case 0x84B426u: goto L_84B426;
    case 0x84B429u: goto L_84B429;
    case 0x84B42Au: goto L_84B42A;
    case 0x84B42Du: goto L_84B42D;
    case 0x84B430u: goto L_84B430;
    case 0x84B433u: goto L_84B433;
    case 0x84B435u: goto L_84B435;
    case 0x84B438u: goto L_84B438;
    case 0x84B43Au: goto L_84B43A;
    case 0x84B43Du: goto L_84B43D;
    case 0x84B43Fu: goto L_84B43F;
    case 0x84B443u: goto L_84B443;
    case 0x84B446u: goto L_84B446;
    case 0x84B449u: goto L_84B449;
    case 0x84B44Cu: goto L_84B44C;
    case 0x84B44Eu: goto L_84B44E;
    case 0x84B451u: goto L_84B451;
    case 0x84B453u: goto L_84B453;
    case 0x84B456u: goto L_84B456;
    case 0x84B458u: goto L_84B458;
    case 0x84B45Cu: goto L_84B45C;
    case 0x84B45Eu: goto L_84B45E;
    case 0x84B460u: goto L_84B460;
    case 0x84B461u: goto L_84B461;
    case 0x84B464u: goto L_84B464;
    case 0x84B467u: goto L_84B467;
    case 0x84B46Au: goto L_84B46A;
    case 0x84B46Eu: goto L_84B46E;
    case 0x84B470u: goto L_84B470;
    case 0x84B472u: goto L_84B472;
    case 0x84B473u: goto L_84B473;
    case 0x84B476u: goto L_84B476;
    case 0x84B479u: goto L_84B479;
    case 0x84B47Cu: goto L_84B47C;
    case 0x84B480u: goto L_84B480;
    case 0x84B482u: goto L_84B482;
    case 0x84B484u: goto L_84B484;
    case 0x84B485u: goto L_84B485;
    case 0x84B488u: goto L_84B488;
    case 0x84B48Bu: goto L_84B48B;
    case 0x84B48Eu: goto L_84B48E;
    case 0x84B492u: goto L_84B492;
    case 0x84B495u: goto L_84B495;
    case 0x84B497u: goto L_84B497;
    case 0x84B49Au: goto L_84B49A;
    case 0x84B49Cu: goto L_84B49C;
    case 0x84B49Fu: goto L_84B49F;
    case 0x84B4A2u: goto L_84B4A2;
    case 0x84B4A6u: goto L_84B4A6;
    case 0x84B4A9u: goto L_84B4A9;
    case 0x84B4ACu: goto L_84B4AC;
    case 0x84B4AEu: goto L_84B4AE;
    case 0x84B4B0u: goto L_84B4B0;
    case 0x84B4B2u: goto L_84B4B2;
    case 0x84B4B4u: goto L_84B4B4;
    case 0x84B4B7u: goto L_84B4B7;
    case 0x84B4BAu: goto L_84B4BA;
    case 0x84B4BDu: goto L_84B4BD;
    case 0x84B4C0u: goto L_84B4C0;
    case 0x84B4C3u: goto L_84B4C3;
    case 0x84B4C6u: goto L_84B4C6;
    case 0x84B4C8u: goto L_84B4C8;
    case 0x84B4CAu: goto L_84B4CA;
    case 0x84B4CDu: goto L_84B4CD;
    case 0x84B4CFu: goto L_84B4CF;
    case 0x84B4D2u: goto L_84B4D2;
    case 0x84B4D4u: goto L_84B4D4;
    case 0x84B4D7u: goto L_84B4D7;
    case 0x84B4D9u: goto L_84B4D9;
    case 0x84B4DCu: goto L_84B4DC;
    case 0x84B4DEu: goto L_84B4DE;
    case 0x84B4DFu: goto L_84B4DF;
    case 0x84B4E1u: goto L_84B4E1;
    case 0x84B4E5u: goto L_84B4E5;
    case 0x84B4E8u: goto L_84B4E8;
    case 0x84B4EAu: goto L_84B4EA;
    case 0x84B4ECu: goto L_84B4EC;
    case 0x84B4F0u: goto L_84B4F0;
    case 0x84B4F4u: goto L_84B4F4;
    case 0x84B4F7u: goto L_84B4F7;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84B357:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB357u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB357u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB357u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B357 REP
    cpu.rep(0x20u);
    goto L_84B359;
L_84B359:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB359u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB359u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB359u, 5u, 3u, cpu.address("abs", 0x01A5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B359 STZ
    hw.write(cpu.address("abs", 0x1A5u), 0, cpu.m8?8:16);
    goto L_84B35C;
L_84B35C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB35Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB35Cu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB35Cu, 5u, 3u, cpu.address("abs", 0x01A1u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B35C STZ
    hw.write(cpu.address("abs", 0x1A1u), 0, cpu.m8?8:16);
    goto L_84B35F;
L_84B35F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB35Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB35Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB35Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B35F LDA
    cpu.setA(0x1u, 16);
    goto L_84B362;
L_84B362:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB362u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB362u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB362u, 8u, 4u, 0x808D4Au, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B362 JSL -> $808D4A stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB365u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB366u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808D4Au, 0x84B362u); }
    goto L_84B366;
L_84B366:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB366u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB366u,0x84B366u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB366u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB366u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B366 LDA
    cpu.setA(0x9F49u, 16);
    goto L_84B369;
L_84B369:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB369u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB369u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB369u, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B369 STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_84B36C;
L_84B36C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB36Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB36Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB36Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B36C LDA
    cpu.setA(0x8Eu, 16);
    goto L_84B36F;
L_84B36F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB36Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB36Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB36Fu, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B36F STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_84B372;
L_84B372:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB372u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB372u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB372u, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B372 JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB375u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB376u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x84B372u); }
    goto L_84B376;
L_84B376:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB376u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB376u,0x84B376u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB376u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB376u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B376 SEP
    cpu.sep(0x20u);
    goto L_84B378;
L_84B378:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB378u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB378u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB378u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B378 LDA
    cpu.setA(0x7Eu, 8);
    goto L_84B37A;
L_84B37A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB37Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB37Au,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB37Au, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $84B37A PHA
    cpu.push("PHA", hw);
    goto L_84B37B;
L_84B37B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB37Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB37Bu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB37Bu, 5u, 3u, cpu.address("abs", 0x8000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B37B PEA
    cpu.push16Value(hw, 0x8000u);
    goto L_84B37E;
L_84B37E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB37Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB37Eu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB37Eu, 5u, 3u, cpu.address("abs", 0x0000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B37E PEA
    cpu.push16Value(hw, 0x0u);
    goto L_84B381;
L_84B381:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB381u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB381u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB381u, 5u, 3u, cpu.address("abs", 0x2000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B381 PEA
    cpu.push16Value(hw, 0x2000u);
    goto L_84B384;
L_84B384:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB384u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB384u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB384u, 8u, 4u, 0x809B54u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B384 JSL -> $809B54 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB387u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB388u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809B54u, 0x84B384u); }
    goto L_84B388;
L_84B388:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB388u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB388u,0x84B388u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB388u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB388u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B388 LDA
    cpu.setA(0x8A29u, 16);
    goto L_84B38B;
L_84B38B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB38Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB38Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB38Bu, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B38B STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_84B38E;
L_84B38E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB38Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB38Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB38Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B38E LDA
    cpu.setA(0x8Bu, 16);
    goto L_84B391;
L_84B391:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB391u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB391u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB391u, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B391 STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_84B394;
L_84B394:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB394u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB394u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB394u, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B394 JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB397u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB398u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x84B394u); }
    goto L_84B398;
L_84B398:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB398u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB398u,0x84B398u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB398u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB398u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B398 SEP
    cpu.sep(0x20u);
    goto L_84B39A;
L_84B39A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB39Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B39A LDA
    cpu.setA(0x7Eu, 8);
    goto L_84B39C;
L_84B39C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB39Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Cu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Cu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $84B39C PHA
    cpu.push("PHA", hw);
    goto L_84B39D;
L_84B39D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB39Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Du,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Du, 5u, 3u, cpu.address("abs", 0x8000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B39D PEA
    cpu.push16Value(hw, 0x8000u);
    goto L_84B3A0;
L_84B3A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A0u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A0u, 5u, 3u, cpu.address("abs", 0x1000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B3A0 PEA
    cpu.push16Value(hw, 0x1000u);
    goto L_84B3A3;
L_84B3A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A3u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A3u, 5u, 3u, cpu.address("abs", 0x2000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B3A3 PEA
    cpu.push16Value(hw, 0x2000u);
    goto L_84B3A6;
L_84B3A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A6u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A6u, 8u, 4u, 0x809B54u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B3A6 JSL -> $809B54 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB3A9u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB3AAu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809B54u, 0x84B3A6u); }
    goto L_84B3AA;
L_84B3AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3AAu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB3AAu,0x84B3AAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3AAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3AAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B3AA LDA
    cpu.setA(0xB1C3u, 16);
    goto L_84B3AD;
L_84B3AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3ADu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3ADu, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B3AD STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_84B3B0;
L_84B3B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3B0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3B0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B3B0 LDA
    cpu.setA(0x8Eu, 16);
    goto L_84B3B3;
L_84B3B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3B3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3B3u, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B3B3 STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_84B3B6;
L_84B3B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3B6u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3B6u, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B3B6 JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB3B9u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB3BAu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x84B3B6u); }
    goto L_84B3BA;
L_84B3BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3BAu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB3BAu,0x84B3BAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3BAu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3BAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B3BA SEP
    cpu.sep(0x20u);
    goto L_84B3BC;
L_84B3BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3BCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3BCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B3BC LDA
    cpu.setA(0x7Eu, 8);
    goto L_84B3BE;
L_84B3BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3BEu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3BEu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $84B3BE PHA
    cpu.push("PHA", hw);
    goto L_84B3BF;
L_84B3BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3BFu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3BFu, 5u, 3u, cpu.address("abs", 0x8000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B3BF PEA
    cpu.push16Value(hw, 0x8000u);
    goto L_84B3C2;
L_84B3C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3C2u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3C2u, 5u, 3u, cpu.address("abs", 0x2000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B3C2 PEA
    cpu.push16Value(hw, 0x2000u);
    goto L_84B3C5;
L_84B3C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3C5u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3C5u, 5u, 3u, cpu.address("abs", 0x2000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B3C5 PEA
    cpu.push16Value(hw, 0x2000u);
    goto L_84B3C8;
L_84B3C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3C8u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3C8u, 8u, 4u, 0x809B54u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B3C8 JSL -> $809B54 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB3CBu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB3CCu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809B54u, 0x84B3C8u); }
    goto L_84B3CC;
L_84B3CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3CCu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB3CCu,0x84B3CCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3CCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3CCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B3CC LDA
    cpu.setA(0x8000u, 16);
    goto L_84B3CF;
L_84B3CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3CFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3CFu, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B3CF STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_84B3D2;
L_84B3D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3D2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3D2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B3D2 LDA
    cpu.setA(0x8Fu, 16);
    goto L_84B3D5;
L_84B3D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3D5u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3D5u, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B3D5 STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_84B3D8;
L_84B3D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3D8u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3D8u, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B3D8 JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB3DBu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB3DCu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x84B3D8u); }
    goto L_84B3DC;
L_84B3DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3DCu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB3DCu,0x84B3DCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3DCu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3DCu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B3DC SEP
    cpu.sep(0x20u);
    goto L_84B3DE;
L_84B3DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3DEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3DEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B3DE LDA
    cpu.setA(0x7Eu, 8);
    goto L_84B3E0;
L_84B3E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3E0u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3E0u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $84B3E0 PHA
    cpu.push("PHA", hw);
    goto L_84B3E1;
L_84B3E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3E1u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3E1u, 5u, 3u, cpu.address("abs", 0x8000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B3E1 PEA
    cpu.push16Value(hw, 0x8000u);
    goto L_84B3E4;
L_84B3E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3E4u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3E4u, 5u, 3u, cpu.address("abs", 0x6000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B3E4 PEA
    cpu.push16Value(hw, 0x6000u);
    goto L_84B3E7;
L_84B3E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3E7u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3E7u, 5u, 3u, cpu.address("abs", 0x4000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B3E7 PEA
    cpu.push16Value(hw, 0x4000u);
    goto L_84B3EA;
L_84B3EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3EAu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3EAu, 8u, 4u, 0x809B54u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B3EA JSL -> $809B54 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB3EDu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB3EEu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809B54u, 0x84B3EAu); }
    goto L_84B3EE;
L_84B3EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3EEu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB3EEu,0x84B3EEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3EEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3EEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B3EE LDA
    cpu.setA(0xC651u, 16);
    goto L_84B3F1;
L_84B3F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3F1u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3F1u, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B3F1 STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_84B3F4;
L_84B3F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3F4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3F4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B3F4 LDA
    cpu.setA(0x8Bu, 16);
    goto L_84B3F7;
L_84B3F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3F7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3F7u, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B3F7 STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_84B3FA;
L_84B3FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3FAu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3FAu, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B3FA JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB3FDu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB3FEu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x84B3FAu); }
    goto L_84B3FE;
L_84B3FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3FEu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB3FEu,0x84B3FEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3FEu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3FEu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $84B3FE PHB
    cpu.push("PHB", hw);
    goto L_84B3FF;
L_84B3FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3FFu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3FFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B3FF LDX
    cpu.setX(0x8000u, 16);
    goto L_84B402;
L_84B402:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB402u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB402u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB402u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B402 LDY
    cpu.setY(0x2800u, 16);
    goto L_84B405;
L_84B405:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB405u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB405u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB405u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xBDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B405 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xBDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84B407;
L_84B407:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB407u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB407u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB407u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B407 DEC
    cpu.decReg('A');
    goto L_84B408;
L_84B408:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB408u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB408u,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xB408u, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $84B408 MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_84B40B;
L_84B40B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB40Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB40Bu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB40Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $84B40B PLB
    cpu.pop("PLB", hw);
    goto L_84B40C;
L_84B40C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB40Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB40Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB40Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B40C LDA
    cpu.setA(0xC268u, 16);
    goto L_84B40F;
L_84B40F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB40Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB40Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB40Fu, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B40F STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_84B412;
L_84B412:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB412u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB412u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB412u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B412 LDA
    cpu.setA(0x8Bu, 16);
    goto L_84B415;
L_84B415:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB415u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB415u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB415u, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B415 STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_84B418;
L_84B418:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB418u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB418u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB418u, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B418 JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB41Bu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB41Cu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x84B418u); }
    goto L_84B41C;
L_84B41C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB41Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB41Cu,0x84B41Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB41Cu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB41Cu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $84B41C PHB
    cpu.push("PHB", hw);
    goto L_84B41D;
L_84B41D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB41Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB41Du,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB41Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B41D LDX
    cpu.setX(0x8000u, 16);
    goto L_84B420;
L_84B420:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB420u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB420u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB420u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B420 LDY
    cpu.setY(0x4000u, 16);
    goto L_84B423;
L_84B423:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB423u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB423u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB423u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xBDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B423 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xBDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84B425;
L_84B425:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB425u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB425u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB425u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B425 DEC
    cpu.decReg('A');
    goto L_84B426;
L_84B426:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB426u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB426u,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xB426u, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $84B426 MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_84B429;
L_84B429:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB429u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB429u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB429u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $84B429 PLB
    cpu.pop("PLB", hw);
    goto L_84B42A;
L_84B42A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB42Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB42Au,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB42Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B42A LDX
    cpu.setX(0x4u, 16);
    goto L_84B42D;
L_84B42D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB42Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB42Du,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB42Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B42D LDY
    cpu.setY(0x14u, 16);
    goto L_84B430;
L_84B430:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB430u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB430u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB430u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B430 LDA
    cpu.setA(0x288Cu, 16);
    goto L_84B433;
L_84B433:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB433u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB433u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB433u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B433 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_84B435;
L_84B435:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB435u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB435u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB435u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B435 LDA
    cpu.setA(0x7Eu, 16);
    goto L_84B438;
L_84B438:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB438u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB438u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB438u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B438 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_84B43A;
L_84B43A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB43Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB43Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB43Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B43A LDA
    cpu.setA(0x800u, 16);
    goto L_84B43D;
L_84B43D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB43Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB43Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB43Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B43D STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_84B43F;
L_84B43F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB43Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB43Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB43Fu, 8u, 4u, 0x80A839u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B43F JSL -> $80A839 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB442u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB443u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A839u, 0x84B43Fu); }
    goto L_84B443;
L_84B443:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB443u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB443u,0x84B443u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB443u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB443u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B443 LDX
    cpu.setX(0x1Au, 16);
    goto L_84B446;
L_84B446:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB446u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB446u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB446u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B446 LDY
    cpu.setY(0x1Eu, 16);
    goto L_84B449;
L_84B449:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB449u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB449u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB449u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B449 LDA
    cpu.setA(0x6042u, 16);
    goto L_84B44C;
L_84B44C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB44Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB44Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB44Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B44C STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_84B44E;
L_84B44E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB44Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB44Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB44Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B44E LDA
    cpu.setA(0x7Eu, 16);
    goto L_84B451;
L_84B451:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB451u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB451u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB451u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B451 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_84B453;
L_84B453:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB453u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB453u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB453u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B453 LDA
    cpu.setA(0x4u, 16);
    goto L_84B456;
L_84B456:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB456u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB456u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB456u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B456 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_84B458;
L_84B458:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB458u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB458u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB458u, 8u, 4u, 0x80A85Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B458 JSL -> $80A85F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB45Bu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB45Cu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A85Fu, 0x84B458u); }
    goto L_84B45C;
L_84B45C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB45Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB45Cu,0x84B45Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB45Cu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB45Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B45C SEP
    cpu.sep(0x20u);
    goto L_84B45E;
L_84B45E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB45Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB45Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB45Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B45E LDA
    cpu.setA(0x7Eu, 8);
    goto L_84B460;
L_84B460:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB460u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB460u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB460u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $84B460 PHA
    cpu.push("PHA", hw);
    goto L_84B461;
L_84B461:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB461u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB461u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB461u, 5u, 3u, cpu.address("abs", 0x2800u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B461 PEA
    cpu.push16Value(hw, 0x2800u);
    goto L_84B464;
L_84B464:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB464u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB464u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB464u, 5u, 3u, cpu.address("abs", 0x3000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B464 PEA
    cpu.push16Value(hw, 0x3000u);
    goto L_84B467;
L_84B467:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB467u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB467u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB467u, 5u, 3u, cpu.address("abs", 0x0800u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B467 PEA
    cpu.push16Value(hw, 0x800u);
    goto L_84B46A;
L_84B46A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB46Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB46Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB46Au, 8u, 4u, 0x809B54u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B46A JSL -> $809B54 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB46Du); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB46Eu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809B54u, 0x84B46Au); }
    goto L_84B46E;
L_84B46E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB46Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB46Eu,0x84B46Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB46Eu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB46Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B46E SEP
    cpu.sep(0x20u);
    goto L_84B470;
L_84B470:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB470u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB470u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB470u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B470 LDA
    cpu.setA(0x7Eu, 8);
    goto L_84B472;
L_84B472:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB472u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB472u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB472u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $84B472 PHA
    cpu.push("PHA", hw);
    goto L_84B473;
L_84B473:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB473u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB473u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB473u, 5u, 3u, cpu.address("abs", 0x4000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B473 PEA
    cpu.push16Value(hw, 0x4000u);
    goto L_84B476;
L_84B476:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB476u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB476u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB476u, 5u, 3u, cpu.address("abs", 0x5000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B476 PEA
    cpu.push16Value(hw, 0x5000u);
    goto L_84B479;
L_84B479:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB479u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB479u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB479u, 5u, 3u, cpu.address("abs", 0x2000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B479 PEA
    cpu.push16Value(hw, 0x2000u);
    goto L_84B47C;
L_84B47C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB47Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB47Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB47Cu, 8u, 4u, 0x809B54u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B47C JSL -> $809B54 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB47Fu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB480u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809B54u, 0x84B47Cu); }
    goto L_84B480;
L_84B480:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB480u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB480u,0x84B480u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB480u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB480u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B480 SEP
    cpu.sep(0x20u);
    goto L_84B482;
L_84B482:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB482u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB482u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB482u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B482 LDA
    cpu.setA(0x7Eu, 8);
    goto L_84B484;
L_84B484:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB484u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB484u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB484u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $84B484 PHA
    cpu.push("PHA", hw);
    goto L_84B485;
L_84B485:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB485u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB485u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB485u, 5u, 3u, cpu.address("abs", 0x6000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B485 PEA
    cpu.push16Value(hw, 0x6000u);
    goto L_84B488;
L_84B488:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB488u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB488u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB488u, 5u, 3u, cpu.address("abs", 0x4000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B488 PEA
    cpu.push16Value(hw, 0x4000u);
    goto L_84B48B;
L_84B48B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB48Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB48Bu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB48Bu, 5u, 3u, cpu.address("abs", 0x0800u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B48B PEA
    cpu.push16Value(hw, 0x800u);
    goto L_84B48E;
L_84B48E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB48Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB48Eu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB48Eu, 8u, 4u, 0x809B54u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B48E JSL -> $809B54 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB491u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB492u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809B54u, 0x84B48Eu); }
    goto L_84B492;
L_84B492:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB492u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB492u,0x84B492u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB492u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB492u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B492 LDA
    cpu.setA(0x9E6Cu, 16);
    goto L_84B495;
L_84B495:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB495u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB495u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB495u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B495 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_84B497;
L_84B497:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB497u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB497u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB497u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B497 LDA
    cpu.setA(0x8Au, 16);
    goto L_84B49A;
L_84B49A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB49Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB49Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB49Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B49A STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_84B49C;
L_84B49C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB49Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB49Cu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB49Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B49C LDX
    cpu.setX(0x0u, 16);
    goto L_84B49F;
L_84B49F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB49Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB49Fu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB49Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B49F LDY
    cpu.setY(0x200u, 16);
    goto L_84B4A2;
L_84B4A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4A2u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4A2u, 8u, 4u, 0x808BB9u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B4A2 JSL -> $808BB9 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB4A5u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB4A6u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808BB9u, 0x84B4A2u); }
    goto L_84B4A6;
L_84B4A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4A6u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB4A6u,0x84B4A6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4A6u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4A6u, 6u, 3u, cpu.address("abs", 0xB6EFu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B4A6 JSR -> $84B6EF stack real
    { cpu.push16Value(hw,0xB4A8u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB4A9u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB6EFu), 0x84B4A6u); }
    goto L_84B4A9;
L_84B4A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4A9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB4A9u,0x84B4A9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4A9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4A9u, 6u, 3u, cpu.address("abs", 0xB5F5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B4A9 JSR -> $84B5F5 stack real
    { cpu.push16Value(hw,0xB4ABu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB4ACu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB5F5u), 0x84B4A9u); }
    goto L_84B4AC;
L_84B4AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4ACu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB4ACu,0x84B4ACu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4ACu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4ACu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B4AC STZ
    hw.write(cpu.address("dp", 0x6Bu), 0, cpu.m8?8:16);
    goto L_84B4AE;
L_84B4AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4AEu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4AEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B4AE STZ
    hw.write(cpu.address("dp", 0x6Du), 0, cpu.m8?8:16);
    goto L_84B4B0;
L_84B4B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B0u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B4B0 STZ
    hw.write(cpu.address("dp", 0x6Fu), 0, cpu.m8?8:16);
    goto L_84B4B2;
L_84B4B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B2u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x71u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B4B2 STZ
    hw.write(cpu.address("dp", 0x71u), 0, cpu.m8?8:16);
    goto L_84B4B4;
L_84B4B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B4u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B4u, 5u, 3u, cpu.address("abs", 0x0658u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B4B4 STZ
    hw.write(cpu.address("abs", 0x658u), 0, cpu.m8?8:16);
    goto L_84B4B7;
L_84B4B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B7u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B7u, 5u, 3u, cpu.address("abs", 0x065Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B4B7 STZ
    hw.write(cpu.address("abs", 0x65Au), 0, cpu.m8?8:16);
    goto L_84B4BA;
L_84B4BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BAu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BAu, 5u, 3u, cpu.address("abs", 0x0667u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B4BA STZ
    hw.write(cpu.address("abs", 0x667u), 0, cpu.m8?8:16);
    goto L_84B4BD;
L_84B4BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BDu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BDu, 5u, 3u, cpu.address("abs", 0x0669u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B4BD STZ
    hw.write(cpu.address("abs", 0x669u), 0, cpu.m8?8:16);
    goto L_84B4C0;
L_84B4C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C0u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C0u, 5u, 3u, cpu.address("abs", 0x0082u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B4C0 STZ
    hw.write(cpu.address("abs", 0x82u), 0, cpu.m8?8:16);
    goto L_84B4C3;
L_84B4C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C3u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C3u, 5u, 3u, cpu.address("abs", 0x0084u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B4C3 STZ
    hw.write(cpu.address("abs", 0x84u), 0, cpu.m8?8:16);
    goto L_84B4C6;
L_84B4C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C6u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B4C6 SEP
    cpu.sep(0x20u);
    goto L_84B4C8;
L_84B4C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B4C8 LDA
    cpu.setA(0x53u, 8);
    goto L_84B4CA;
L_84B4CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4CAu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4CAu, 4u, 3u, cpu.address("abs", 0x2108u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B4CA STA
    hw.write(cpu.address("abs", 0x2108u), cpu.a, cpu.m8?8:16);
    goto L_84B4CD;
L_84B4CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4CDu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4CDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B4CD STZ
    hw.write(cpu.address("dp", 0x49u), 0, cpu.m8?8:16);
    goto L_84B4CF;
L_84B4CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4CFu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4CFu, 4u, 3u, cpu.address("abs", 0x0657u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B4CF STZ
    hw.write(cpu.address("abs", 0x657u), 0, cpu.m8?8:16);
    goto L_84B4D2;
L_84B4D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4D2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4D2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B4D2 LDA
    cpu.setA(0x2u, 8);
    goto L_84B4D4;
L_84B4D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4D4u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4D4u, 4u, 3u, cpu.address("abs", 0x2130u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B4D4 STA
    hw.write(cpu.address("abs", 0x2130u), cpu.a, cpu.m8?8:16);
    goto L_84B4D7;
L_84B4D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4D7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4D7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B4D7 LDA
    cpu.setA(0x82u, 8);
    goto L_84B4D9;
L_84B4D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4D9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4D9u, 4u, 3u, cpu.address("abs", 0x2131u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B4D9 STA
    hw.write(cpu.address("abs", 0x2131u), cpu.a, cpu.m8?8:16);
    goto L_84B4DC;
L_84B4DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4DCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4DCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B4DC LDA
    cpu.setA(0xC1u, 8);
    goto L_84B4DE;
L_84B4DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4DEu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4DEu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B4DE XBA
    cpu.xba();
    goto L_84B4DF;
L_84B4DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4DFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4DFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B4DF LDA
    cpu.setA(0x0u, 8);
    goto L_84B4E1;
L_84B4E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E1u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E1u, 8u, 4u, 0x8086F4u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B4E1 JSL -> $8086F4 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB4E4u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB4E5u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8086F4u, 0x84B4E1u); }
    goto L_84B4E5;
L_84B4E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4E5u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB4E5u,0x84B4E5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E5u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E5u, 4u, 3u, cpu.address("abs", 0x01BFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B4E5 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84B4E8;
L_84B4E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E8u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B4E8 BNE -> $84B4F7
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_84B4F7; }
    goto L_84B4EA;
L_84B4EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4EAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4EAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B4EA LDA
    cpu.setA(0x10u, 8);
    goto L_84B4EC;
L_84B4EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4ECu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4ECu, 8u, 4u, 0x80A6BDu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B4EC JSL -> $80A6BD stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB4EFu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB4F0u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6BDu, 0x84B4ECu); }
    goto L_84B4F0;
L_84B4F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4F0u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB4F0u,0x84B4F0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F0u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F0u, 8u, 4u, 0x80A6A5u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B4F0 JSL -> $80A6A5 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB4F3u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB4F4u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6A5u, 0x84B4F0u); }
    goto L_84B4F4;
L_84B4F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4F4u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB4F4u,0x84B4F4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F4u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F4u, 6u, 3u, cpu.address("abs", 0x01BFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B4F4 INC
    cpu.incMem(hw, cpu.address("abs", 0x1BFu), cpu.m8?8:16);
    goto L_84B4F7;
L_84B4F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F7u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B4F7 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x84B4F7u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84B4F7u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_84BEB7_E0M1X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84BEB7u: goto L_84BEB7;
    case 0x84BEB9u: goto L_84BEB9;
    case 0x84BEBAu: goto L_84BEBA;
    case 0x84BEBDu: goto L_84BEBD;
    case 0x84BEBFu: goto L_84BEBF;
    case 0x84BEC0u: goto L_84BEC0;
    case 0x84BEC4u: goto L_84BEC4;
    case 0x84BEC8u: goto L_84BEC8;
    case 0x84BECBu: goto L_84BECB;
    case 0x84BECDu: goto L_84BECD;
    case 0x84BECFu: goto L_84BECF;
    case 0x84BED1u: goto L_84BED1;
    case 0x84BED3u: goto L_84BED3;
    case 0x84BED5u: goto L_84BED5;
    case 0x84BED7u: goto L_84BED7;
    case 0x84BED9u: goto L_84BED9;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84BEB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEB7u,cpu,0xD5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEB7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xBEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEB7 CMP
    cpu.compareA(hw.readW(cpu.address("dpx", 0xBEu), cpu.m8?8:16));
    goto L_84BEB9;
L_84BEB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEB9u,cpu,0xF8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEB9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEB9 SED
    cpu.setFlag('D', true);
    goto L_84BEBA;
L_84BEBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEBAu,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEBAu, 5u + 1u, 3u, cpu.address("absy", 0xBF4Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEBA LDX
    cpu.setX(hw.readW(cpu.address("absy", 0xBF4Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_84BEBD;
L_84BEBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEBDu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEBDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xBFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEBD STZ
    hw.write(cpu.address("dp", 0xBFu), 0, cpu.m8?8:16);
    goto L_84BEBF;
L_84BEBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEBFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEBFu,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEBFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEBF TDC
    cpu.tdc();
    goto L_84BEC0;
L_84BEC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEC0u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEC0u, 5u, 4u, ((0xC7BFB3u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEC0 LDA
    cpu.loadA(hw.readW(((0xC7BFB3u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84BEC4;
L_84BEC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEC4u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEC4u, 5u, 4u, ((0x20BFE2u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEC4 LDA
    cpu.loadA(hw.readW(((0x20BFE2u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84BEC8;
L_84BEC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEC8u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEC8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEC8 CPY
    cpu.compareY(0xC031u);
    goto L_84BECB;
L_84BECB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBECBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBECBu,cpu,0x43u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBECBu, 4u, 2u, cpu.addressStack(0xC0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BECB EOR
    cpu.logicXor(hw.readW(cpu.addressStack(0xC0u), cpu.m8?8:16));
    goto L_84BECD;
L_84BECD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBECDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBECDu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBECDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BECD STZ
    hw.write(cpu.address("dp", 0xC0u), 0, cpu.m8?8:16);
    goto L_84BECF;
L_84BECF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBECFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBECFu,cpu,0x87u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBECFu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xC0u) & 0xFFFFu), 3u, 0u);
    // $84BECF STA
    hw.write(cpu.addressDpLong(hw, 0xC0u), cpu.a, cpu.m8?8:16);
    goto L_84BED1;
L_84BED1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBED1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBED1u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBED1u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BED1 DEC
    cpu.decMem(hw, cpu.address("dp", 0xC0u), cpu.m8?8:16);
    goto L_84BED3;
L_84BED3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBED3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBED3u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBED3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BED3 SEP
    cpu.sep(0xC0u);
    goto L_84BED5;
L_84BED5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBED5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBED5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBED5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BED5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x75u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84BED7;
L_84BED7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBED7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBED7u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBED7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BED7 AND
    cpu.logicAnd(0xFFu);
    goto L_84BED9;
L_84BED9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBED9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBED9u,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBED9u, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $84BED9 BRK
    hw.partial(0x84BED9u, "BRK"); return;
}

void sub_84BEB7_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84BEB7u: goto L_84BEB7;
    case 0x84BEB9u: goto L_84BEB9;
    case 0x84BEBAu: goto L_84BEBA;
    case 0x84BEBDu: goto L_84BEBD;
    case 0x84BEBFu: goto L_84BEBF;
    case 0x84BEC0u: goto L_84BEC0;
    case 0x84BEC4u: goto L_84BEC4;
    case 0x84BEC8u: goto L_84BEC8;
    case 0x84BECBu: goto L_84BECB;
    case 0x84BECDu: goto L_84BECD;
    case 0x84BECFu: goto L_84BECF;
    case 0x84BED1u: goto L_84BED1;
    case 0x84BED3u: goto L_84BED3;
    case 0x84BED5u: goto L_84BED5;
    case 0x84BED7u: goto L_84BED7;
    case 0x84BED9u: goto L_84BED9;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84BEB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEB7u,cpu,0xD5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEB7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xBEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEB7 CMP
    cpu.compareA(hw.readW(cpu.address("dpx", 0xBEu), cpu.m8?8:16));
    goto L_84BEB9;
L_84BEB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEB9u,cpu,0xF8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEB9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEB9 SED
    cpu.setFlag('D', true);
    goto L_84BEBA;
L_84BEBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEBAu,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEBAu, 5u + 1u, 3u, cpu.address("absy", 0xBF4Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEBA LDX
    cpu.setX(hw.readW(cpu.address("absy", 0xBF4Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_84BEBD;
L_84BEBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEBDu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEBDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xBFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEBD STZ
    hw.write(cpu.address("dp", 0xBFu), 0, cpu.m8?8:16);
    goto L_84BEBF;
L_84BEBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEBFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEBFu,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEBFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEBF TDC
    cpu.tdc();
    goto L_84BEC0;
L_84BEC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEC0u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEC0u, 5u, 4u, ((0xC7BFB3u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEC0 LDA
    cpu.loadA(hw.readW(((0xC7BFB3u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84BEC4;
L_84BEC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEC4u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEC4u, 5u, 4u, ((0x20BFE2u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEC4 LDA
    cpu.loadA(hw.readW(((0x20BFE2u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84BEC8;
L_84BEC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEC8u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEC8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEC8 CPY
    cpu.compareY(0xC031u);
    goto L_84BECB;
L_84BECB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBECBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBECBu,cpu,0x43u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBECBu, 4u, 2u, cpu.addressStack(0xC0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BECB EOR
    cpu.logicXor(hw.readW(cpu.addressStack(0xC0u), cpu.m8?8:16));
    goto L_84BECD;
L_84BECD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBECDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBECDu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBECDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BECD STZ
    hw.write(cpu.address("dp", 0xC0u), 0, cpu.m8?8:16);
    goto L_84BECF;
L_84BECF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBECFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBECFu,cpu,0x87u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBECFu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xC0u) & 0xFFFFu), 3u, 0u);
    // $84BECF STA
    hw.write(cpu.addressDpLong(hw, 0xC0u), cpu.a, cpu.m8?8:16);
    goto L_84BED1;
L_84BED1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBED1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBED1u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBED1u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BED1 DEC
    cpu.decMem(hw, cpu.address("dp", 0xC0u), cpu.m8?8:16);
    goto L_84BED3;
L_84BED3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBED3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBED3u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBED3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BED3 SEP
    cpu.sep(0xC0u);
    goto L_84BED5;
L_84BED5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBED5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBED5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBED5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BED5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x75u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84BED7;
L_84BED7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBED7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBED7u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBED7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BED7 AND
    cpu.logicAnd(0xFFu);
    goto L_84BED9;
L_84BED9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBED9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBED9u,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBED9u, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $84BED9 BRK
    hw.partial(0x84BED9u, "BRK"); return;
}

void sub_84C0C6_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84C0C6u: goto L_84C0C6;
    case 0x84C0C8u: goto L_84C0C8;
    case 0x84C0CAu: goto L_84C0CA;
    case 0x84C0CCu: goto L_84C0CC;
    case 0x84C0CEu: goto L_84C0CE;
    case 0x84C0D0u: goto L_84C0D0;
    case 0x84C0D2u: goto L_84C0D2;
    case 0x84C0D3u: goto L_84C0D3;
    case 0x84C0D5u: goto L_84C0D5;
    case 0x84C0D9u: goto L_84C0D9;
    case 0x84C0DBu: goto L_84C0DB;
    case 0x84C0DEu: goto L_84C0DE;
    case 0x84C0E1u: goto L_84C0E1;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84C0C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0C6u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0C6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C0C6 SEP
    cpu.sep(0x20u);
    goto L_84C0C8;
L_84C0C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0C8u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0C8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C0C8 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x75u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84C0CA;
L_84C0CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0CAu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0CAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C0CA BNE -> $84C0D9
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_84C0D9; }
    goto L_84C0CC;
L_84C0CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0CCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0CCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C0CC LDA
    cpu.setA(0x6u, 8);
    goto L_84C0CE;
L_84C0CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0CEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0CEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C0CE STA
    hw.write(cpu.address("dp", 0x49u), cpu.a, cpu.m8?8:16);
    goto L_84C0D0;
L_84C0D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0D0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0D0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C0D0 LDA
    cpu.setA(0xC1u, 8);
    goto L_84C0D2;
L_84C0D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0D2u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0D2u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C0D2 XBA
    cpu.xba();
    goto L_84C0D3;
L_84C0D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0D3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0D3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C0D3 LDA
    cpu.setA(0x0u, 8);
    goto L_84C0D5;
L_84C0D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0D5u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0D5u, 8u, 4u, 0x8086F4u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84C0D5 JSL -> $8086F4 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC0D8u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC0D9u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8086F4u, 0x84C0D5u); }
    goto L_84C0D9;
L_84C0D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0D9u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC0D9u,0x84C0D9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0D9u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0D9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C0D9 REP
    cpu.rep(0x20u);
    goto L_84C0DB;
L_84C0DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0DBu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0DBu, 6u, 3u, cpu.address("abs", 0xC228u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84C0DB JSR -> $84C228 stack real
    { cpu.push16Value(hw,0xC0DDu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC0DEu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC228u), 0x84C0DBu); }
    goto L_84C0DE;
L_84C0DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0DEu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC0DEu,0x84C0DEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0DEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0DEu, 6u, 3u, cpu.address("abs", 0xC25Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84C0DE JSR -> $84C25B stack real
    { cpu.push16Value(hw,0xC0E0u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC0E1u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC25Bu), 0x84C0DEu); }
    goto L_84C0E1;
L_84C0E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0E1u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0E1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0E1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84C0E1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84C0E1u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84C0E1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0E1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0E1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84C0E1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84C0E1u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84C0E1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC0E1u,0x84C0E1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_9F80F9_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x9F80F9u: goto L_9F80F9;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_9F80F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F9u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $9F80F9 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x9F80F9u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x9F80F9u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

