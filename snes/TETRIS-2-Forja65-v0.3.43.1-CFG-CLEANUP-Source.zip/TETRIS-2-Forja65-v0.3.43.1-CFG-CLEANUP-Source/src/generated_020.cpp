#include "generated.hpp"
void sub_6B84C9_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x6B84C9u: goto L_6B84C9;
    case 0x6B84CCu: goto L_6B84CC;
    case 0x6B84CDu: goto L_6B84CD;
    case 0x6B84CFu: goto L_6B84CF;
    case 0x6B84D1u: goto L_6B84D1;
    case 0x6B84D3u: goto L_6B84D3;
    case 0x6B84D5u: goto L_6B84D5;
    case 0x6B84D6u: goto L_6B84D6;
    case 0x6B84DAu: goto L_6B84DA;
    case 0x6B84DDu: goto L_6B84DD;
    case 0x6B84DFu: goto L_6B84DF;
    case 0x6B84E3u: goto L_6B84E3;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_6B84C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84C9u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84C9u, 8u, 3u, cpu.address("abs", 0x0110u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6B84C9 INC
    cpu.incMem(hw, cpu.address("abs", 0x110u), cpu.m8?8:16);
    goto L_6B84CC;
L_6B84CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84CCu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84CCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6B84CC INC
    cpu.inc('A');
    goto L_6B84CD;
L_6B84CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84CDu,cpu,0xF6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84CDu, 8u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x7Fu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6B84CD INC
    cpu.incMem(hw, cpu.address("dpx", 0x7Fu), cpu.m8?8:16);
    goto L_6B84CF;
L_6B84CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84CFu,cpu,0x01u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84CFu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xCEu + cpu.x) & 0xFFFFu), 2u, 0u);
    // $6B84CF ORA
    cpu.logicOr(hw.readW(cpu.addressDpIndirectX(hw, 0xCEu), cpu.m8?8:16));
    goto L_6B84D1;
L_6B84D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84D1u,cpu,0x31u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84D1u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x7Cu) & 0xFFFFu), 2u, 0u);
    // $6B84D1 AND
    cpu.logicAnd(hw.readW(cpu.addressDpIndirectY(hw, 0x7Cu), cpu.m8?8:16));
    goto L_6B84D3;
L_6B84D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84D3u,cpu,0x83u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84D3u, 5u, 2u, cpu.addressStack(0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6B84D3 STA
    hw.write(cpu.addressStack(0x6u), cpu.a, cpu.m8?8:16);
    goto L_6B84D5;
L_6B84D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84D5u,cpu,0x78u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84D5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6B84D5 SEI
    cpu.setFlag('I', true);
    goto L_6B84D6;
L_6B84D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84D6u,cpu,0x0Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84D6u, 6u, 4u, 0x039E04u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6B84D6 ORA
    cpu.logicOr(hw.readW(0x39E04u, cpu.m8?8:16));
    goto L_6B84DA;
L_6B84DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84DAu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84DAu, 6u, 3u, cpu.address("abs", 0x32CCu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $6B84DA JSR -> $6B32CC stack real
    { cpu.push16Value(hw,0x84DCu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x84DDu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x32CCu), 0x6B84DAu); }
    goto L_6B84DD;
L_6B84DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84DDu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x84DDu,0x6B84DDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84DDu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84DDu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x28u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6B84DD DEC
    cpu.decMem(hw, cpu.address("dp", 0x28u), cpu.m8?8:16);
    goto L_6B84DF;
L_6B84DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84DFu,cpu,0x0Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84DFu, 6u, 4u, 0x20050Au, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6B84DF ORA
    cpu.logicOr(hw.readW(0x20050Au, cpu.m8?8:16));
    goto L_6B84E3;
L_6B84E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84E3u,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84E3u, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x8067u + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $6B84E3 JMP (8067,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x8067u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x6B84E3u); return; }
}

void sub_80834A_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80834Au: goto L_80834A;
    case 0x80834Eu: goto L_80834E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80834A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x834Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x834Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x834Au, 8u, 4u, 0x84C3A4u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80834A JSL -> $84C3A4 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x834Du); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x834Eu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84C3A4u, 0x80834Au); }
    goto L_80834E;
L_80834E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x834Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x834Eu,0x80834Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x834Eu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x834Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80834E RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80834Eu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80834Eu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_808359_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808359u: goto L_808359;
    case 0x80835Du: goto L_80835D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808359:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8359u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8359u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8359u, 8u, 4u, 0x829000u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808359 JSL -> $829000 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x835Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x835Du,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x829000u, 0x808359u); }
    goto L_80835D;
L_80835D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x835Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x835Du,0x80835Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x835Du,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x835Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80835D RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80835Du);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80835Du,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_808359_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808359u: goto L_808359;
    case 0x80835Du: goto L_80835D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808359:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8359u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8359u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8359u, 8u, 4u, 0x829000u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808359 JSL -> $829000 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x835Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x835Du,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x829000u, 0x808359u); }
    goto L_80835D;
L_80835D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x835Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x835Du,0x80835Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x835Du,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x835Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80835D RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80835Du);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80835Du,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_8084C4_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8084C4u: goto L_8084C4;
    case 0x8084C8u: goto L_8084C8;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8084C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84C4u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84C4u, 8u, 4u, 0x829230u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8084C4 JSL -> $829230 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x84C7u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x84C8u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x829230u, 0x8084C4u); }
    goto L_8084C8;
L_8084C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84C8u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x84C8u,0x8084C8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84C8u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84C8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8084C8 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8084C8u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8084C8u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_8084C4_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8084C4u: goto L_8084C4;
    case 0x8084C8u: goto L_8084C8;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8084C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84C4u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84C4u, 8u, 4u, 0x829230u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8084C4 JSL -> $829230 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x84C7u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x84C8u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x829230u, 0x8084C4u); }
    goto L_8084C8;
L_8084C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84C8u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x84C8u,0x8084C8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84C8u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84C8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8084C8 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8084C8u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8084C8u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_8084D3_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8084D3u: goto L_8084D3;
    case 0x8084D7u: goto L_8084D7;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8084D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84D3u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84D3u, 8u, 4u, 0x848EC7u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8084D3 JSL -> $848EC7 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x84D6u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x84D7u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x848EC7u, 0x8084D3u); }
    goto L_8084D7;
L_8084D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84D7u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x84D7u,0x8084D7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84D7u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84D7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8084D7 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8084D7u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8084D7u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_8084D3_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8084D3u: goto L_8084D3;
    case 0x8084D7u: goto L_8084D7;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8084D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84D3u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84D3u, 8u, 4u, 0x848EC7u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8084D3 JSL -> $848EC7 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x84D6u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x84D7u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x848EC7u, 0x8084D3u); }
    goto L_8084D7;
L_8084D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84D7u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x84D7u,0x8084D7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84D7u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84D7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8084D7 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8084D7u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8084D7u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80935E_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80935Eu: goto L_80935E;
    case 0x80935Fu: goto L_80935F;
    case 0x809361u: goto L_809361;
    case 0x809363u: goto L_809363;
    case 0x809365u: goto L_809365;
    case 0x809367u: goto L_809367;
    case 0x809369u: goto L_809369;
    case 0x80936Au: goto L_80936A;
    case 0x80936Du: goto L_80936D;
    case 0x80936Eu: goto L_80936E;
    case 0x809370u: goto L_809370;
    case 0x809373u: goto L_809373;
    case 0x809375u: goto L_809375;
    case 0x809377u: goto L_809377;
    case 0x809379u: goto L_809379;
    case 0x80937Au: goto L_80937A;
    case 0x80937Cu: goto L_80937C;
    case 0x80937Eu: goto L_80937E;
    case 0x80937Fu: goto L_80937F;
    case 0x809381u: goto L_809381;
    case 0x809382u: goto L_809382;
    case 0x809385u: goto L_809385;
    case 0x809386u: goto L_809386;
    case 0x809388u: goto L_809388;
    case 0x80938Bu: goto L_80938B;
    case 0x80938Du: goto L_80938D;
    case 0x80938Fu: goto L_80938F;
    case 0x809391u: goto L_809391;
    case 0x809392u: goto L_809392;
    case 0x809394u: goto L_809394;
    case 0x809396u: goto L_809396;
    case 0x809397u: goto L_809397;
    case 0x809399u: goto L_809399;
    case 0x80939Au: goto L_80939A;
    case 0x80939Du: goto L_80939D;
    case 0x80939Eu: goto L_80939E;
    case 0x8093A0u: goto L_8093A0;
    case 0x8093A3u: goto L_8093A3;
    case 0x8093A5u: goto L_8093A5;
    case 0x8093A7u: goto L_8093A7;
    case 0x8093A9u: goto L_8093A9;
    case 0x8093AAu: goto L_8093AA;
    case 0x8093ACu: goto L_8093AC;
    case 0x8093AEu: goto L_8093AE;
    case 0x8093AFu: goto L_8093AF;
    case 0x8093B1u: goto L_8093B1;
    case 0x8093B2u: goto L_8093B2;
    case 0x8093B5u: goto L_8093B5;
    case 0x8093B7u: goto L_8093B7;
    case 0x8093B9u: goto L_8093B9;
    case 0x8093BBu: goto L_8093BB;
    case 0x8093BDu: goto L_8093BD;
    case 0x8093BFu: goto L_8093BF;
    case 0x8093C0u: goto L_8093C0;
    case 0x8093C3u: goto L_8093C3;
    case 0x8093C5u: goto L_8093C5;
    case 0x8093C7u: goto L_8093C7;
    case 0x8093C9u: goto L_8093C9;
    case 0x8093CBu: goto L_8093CB;
    case 0x8093CDu: goto L_8093CD;
    case 0x8093CEu: goto L_8093CE;
    case 0x8093D1u: goto L_8093D1;
    case 0x8093D3u: goto L_8093D3;
    case 0x8093D5u: goto L_8093D5;
    case 0x8093D7u: goto L_8093D7;
    case 0x8093D9u: goto L_8093D9;
    case 0x8093DBu: goto L_8093DB;
    case 0x8093DDu: goto L_8093DD;
    case 0x8093DFu: goto L_8093DF;
    case 0x8093E0u: goto L_8093E0;
    case 0x8093E2u: goto L_8093E2;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80935E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x935Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x935Eu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x935Eu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80935E PHP
    cpu.push("PHP", hw);
    goto L_80935F;
L_80935F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x935Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x935Fu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x935Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x39u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80935F STZ
    hw.write(cpu.address("dp", 0x39u), 0, cpu.m8?8:16);
    goto L_809361;
L_809361:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9361u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9361u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9361u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809361 STZ
    hw.write(cpu.address("dp", 0x3Bu), 0, cpu.m8?8:16);
    goto L_809363;
L_809363:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9363u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9363u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9363u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809363 STZ
    hw.write(cpu.address("dp", 0x3Du), 0, cpu.m8?8:16);
    goto L_809365;
L_809365:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9365u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9365u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9365u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809365 STZ
    hw.write(cpu.address("dp", 0x3Fu), 0, cpu.m8?8:16);
    goto L_809367;
L_809367:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9367u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9367u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9367u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809367 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x36u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809369;
L_809369:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9369u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9369u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9369u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809369 SEC
    cpu.setFlag('C', true);
    goto L_80936A;
L_80936A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x936Au))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x936Au,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x936Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80936A SBC
    cpu.sbc(0x4240u);
    goto L_80936D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x936Au,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x936Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80936A SBC
    cpu.sbc(0x4240u);
    goto L_80936D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x936Au,0x80936Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80936D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x936Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x936Du,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x936Du, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80936D PHA
    cpu.push("PHA", hw);
    goto L_80936E;
L_80936E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x936Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x936Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x936Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x38u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80936E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x38u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809370;
L_809370:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9370u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9370u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9370u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809370 SBC
    cpu.sbc(0xFu);
    goto L_809373;
L_809373:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9373u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9373u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9373u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809373 BCC -> $80937E
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80937E; }
    goto L_809375;
L_809375:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9375u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9375u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9375u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x40u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809375 INC
    cpu.incMem(hw, cpu.address("dp", 0x40u), cpu.m8?8:16);
    goto L_809377;
L_809377:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9377u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9377u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9377u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x38u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809377 STA
    hw.write(cpu.address("dp", 0x38u), cpu.a, cpu.m8?8:16);
    goto L_809379;
L_809379:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9379u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9379u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9379u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809379 PLA
    cpu.pop("PLA", hw);
    goto L_80937A;
L_80937A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x937Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x937Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x937Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80937A STA
    hw.write(cpu.address("dp", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_80937C;
L_80937C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x937Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x937Cu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x937Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80937C BRA -> $80936A
    goto L_80936A;
L_80937E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x937Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x937Eu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x937Eu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80937E PLA
    cpu.pop("PLA", hw);
    goto L_80937F;
L_80937F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x937Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x937Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x937Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80937F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x36u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809381;
L_809381:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9381u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9381u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9381u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809381 SEC
    cpu.setFlag('C', true);
    goto L_809382;
L_809382:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9382u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9382u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9382u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809382 SBC
    cpu.sbc(0x86A0u);
    goto L_809385;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9382u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9382u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809382 SBC
    cpu.sbc(0x86A0u);
    goto L_809385;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9382u,0x809382u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809385:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9385u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9385u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9385u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809385 PHA
    cpu.push("PHA", hw);
    goto L_809386;
L_809386:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9386u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9386u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9386u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x38u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809386 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x38u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809388;
L_809388:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9388u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9388u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9388u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809388 SBC
    cpu.sbc(0x1u);
    goto L_80938B;
L_80938B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x938Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x938Bu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x938Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80938B BCC -> $809396
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_809396; }
    goto L_80938D;
L_80938D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x938Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x938Du,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x938Du, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Fu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80938D INC
    cpu.incMem(hw, cpu.address("dp", 0x3Fu), cpu.m8?8:16);
    goto L_80938F;
L_80938F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x938Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x938Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x938Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x38u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80938F STA
    hw.write(cpu.address("dp", 0x38u), cpu.a, cpu.m8?8:16);
    goto L_809391;
L_809391:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9391u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9391u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9391u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809391 PLA
    cpu.pop("PLA", hw);
    goto L_809392;
L_809392:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9392u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9392u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9392u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809392 STA
    hw.write(cpu.address("dp", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_809394;
L_809394:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9394u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9394u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9394u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809394 BRA -> $809382
    goto L_809382;
L_809396:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9396u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9396u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9396u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809396 PLA
    cpu.pop("PLA", hw);
    goto L_809397;
L_809397:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9397u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9397u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9397u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809397 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x36u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809399;
L_809399:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9399u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9399u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9399u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809399 SEC
    cpu.setFlag('C', true);
    goto L_80939A;
L_80939A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x939Au))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x939Au,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x939Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80939A SBC
    cpu.sbc(0x2710u);
    goto L_80939D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x939Au,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x939Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80939A SBC
    cpu.sbc(0x2710u);
    goto L_80939D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x939Au,0x80939Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80939D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x939Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x939Du,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x939Du, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80939D PHA
    cpu.push("PHA", hw);
    goto L_80939E;
L_80939E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x939Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x939Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x939Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x38u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80939E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x38u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8093A0;
L_8093A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93A0u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93A0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8093A0 SBC
    cpu.sbc(0x0u);
    goto L_8093A3;
L_8093A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93A3u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93A3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8093A3 BCC -> $8093AE
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_8093AE; }
    goto L_8093A5;
L_8093A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93A5u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93A5u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Eu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8093A5 INC
    cpu.incMem(hw, cpu.address("dp", 0x3Eu), cpu.m8?8:16);
    goto L_8093A7;
L_8093A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93A7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93A7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x38u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8093A7 STA
    hw.write(cpu.address("dp", 0x38u), cpu.a, cpu.m8?8:16);
    goto L_8093A9;
L_8093A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93A9u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93A9u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8093A9 PLA
    cpu.pop("PLA", hw);
    goto L_8093AA;
L_8093AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93AAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93AAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8093AA STA
    hw.write(cpu.address("dp", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_8093AC;
L_8093AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93ACu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93ACu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8093AC BRA -> $80939A
    goto L_80939A;
L_8093AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93AEu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93AEu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8093AE PLA
    cpu.pop("PLA", hw);
    goto L_8093AF;
L_8093AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93AFu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93AFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8093AF LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x36u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8093B1;
L_8093B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93B1u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93B1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8093B1 SEC
    cpu.setFlag('C', true);
    goto L_8093B2;
L_8093B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93B2u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93B2u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93B2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8093B2 SBC
    cpu.sbc(0x3E8u);
    goto L_8093B5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93B2u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93B2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8093B2 SBC
    cpu.sbc(0x3E8u);
    goto L_8093B5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x93B2u,0x8093B2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8093B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93B5u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93B5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8093B5 BCC -> $8093BD
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_8093BD; }
    goto L_8093B7;
L_8093B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93B7u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93B7u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Du), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8093B7 INC
    cpu.incMem(hw, cpu.address("dp", 0x3Du), cpu.m8?8:16);
    goto L_8093B9;
L_8093B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93B9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93B9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8093B9 STA
    hw.write(cpu.address("dp", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_8093BB;
L_8093BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93BBu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93BBu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8093BB BRA -> $8093B2
    goto L_8093B2;
L_8093BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93BDu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93BDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8093BD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x36u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8093BF;
L_8093BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93BFu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93BFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8093BF SEC
    cpu.setFlag('C', true);
    goto L_8093C0;
L_8093C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93C0u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93C0u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93C0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8093C0 SBC
    cpu.sbc(0x64u);
    goto L_8093C3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93C0u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93C0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8093C0 SBC
    cpu.sbc(0x64u);
    goto L_8093C3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x93C0u,0x8093C0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8093C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93C3u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93C3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8093C3 BCC -> $8093CB
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_8093CB; }
    goto L_8093C5;
L_8093C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93C5u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93C5u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8093C5 INC
    cpu.incMem(hw, cpu.address("dp", 0x3Cu), cpu.m8?8:16);
    goto L_8093C7;
L_8093C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93C7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93C7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8093C7 STA
    hw.write(cpu.address("dp", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_8093C9;
L_8093C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93C9u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93C9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8093C9 BRA -> $8093C0
    goto L_8093C0;
L_8093CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93CBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93CBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8093CB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x36u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8093CD;
L_8093CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93CDu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93CDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8093CD SEC
    cpu.setFlag('C', true);
    goto L_8093CE;
L_8093CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93CEu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93CEu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93CEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8093CE SBC
    cpu.sbc(0xAu);
    goto L_8093D1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93CEu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93CEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8093CE SBC
    cpu.sbc(0xAu);
    goto L_8093D1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x93CEu,0x8093CEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8093D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93D1u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93D1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8093D1 BCC -> $8093D9
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_8093D9; }
    goto L_8093D3;
L_8093D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93D3u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93D3u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Bu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8093D3 INC
    cpu.incMem(hw, cpu.address("dp", 0x3Bu), cpu.m8?8:16);
    goto L_8093D5;
L_8093D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93D5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93D5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8093D5 STA
    hw.write(cpu.address("dp", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_8093D7;
L_8093D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93D7u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93D7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8093D7 BRA -> $8093CE
    goto L_8093CE;
L_8093D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93D9u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93D9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8093D9 SEP
    cpu.sep(0x20u);
    goto L_8093DB;
L_8093DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93DBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93DBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8093DB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x36u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8093DD;
L_8093DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93DDu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93DDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8093DD STA
    hw.write(cpu.address("dp", 0x3Au), cpu.a, cpu.m8?8:16);
    goto L_8093DF;
L_8093DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93DFu,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93DFu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8093DF PLP
    cpu.pop("PLP", hw);
    goto L_8093E0;
L_8093E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93E0u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x93E0u,0x8093E0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93E0u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93E0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8093E0 REP
    cpu.rep(0x20u);
    goto L_8093E2;
L_8093E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93E2u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93E2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8093E2 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8093E2u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8093E2u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_8096A3_E0M1X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8096A3u: goto L_8096A3;
    case 0x8096A5u: goto L_8096A5;
    case 0x8096A7u: goto L_8096A7;
    case 0x8096A8u: goto L_8096A8;
    case 0x8096AAu: goto L_8096AA;
    case 0x8096ACu: goto L_8096AC;
    case 0x8096AEu: goto L_8096AE;
    case 0x8096AFu: goto L_8096AF;
    case 0x8096B0u: goto L_8096B0;
    case 0x8096B1u: goto L_8096B1;
    case 0x8096B3u: goto L_8096B3;
    case 0x8096B5u: goto L_8096B5;
    case 0x8096B7u: goto L_8096B7;
    case 0x8096B9u: goto L_8096B9;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8096A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96A3u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96A3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096A3 SEP
    cpu.sep(0x20u);
    goto L_8096A5;
L_8096A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96A5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96A5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096A5 LDA
    cpu.setA(0xB3u, 8);
    goto L_8096A7;
L_8096A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96A7u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96A7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096A7 CLC
    cpu.setFlag('C', false);
    goto L_8096A8;
L_8096A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96A8u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96A8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x51u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096A8 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x51u), cpu.m8?8:16));
    goto L_8096AA;
L_8096AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96AAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96AAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x51u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096AA STA
    hw.write(cpu.address("dp", 0x51u), cpu.a, cpu.m8?8:16);
    goto L_8096AC;
L_8096AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96ACu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96ACu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x52u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096AC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x52u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8096AE;
L_8096AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96AEu,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96AEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096AE ROL
    cpu.rolA();
    goto L_8096AF;
L_8096AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96AFu,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96AFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096AF ROL
    cpu.rolA();
    goto L_8096B0;
L_8096B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B0u,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096B0 ROL
    cpu.rolA();
    goto L_8096B1;
L_8096B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B1u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096B1 EOR
    cpu.logicXor(0xFFu);
    goto L_8096B3;
L_8096B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B3u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x51u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096B3 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x51u), cpu.m8?8:16));
    goto L_8096B5;
L_8096B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x52u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096B5 STA
    hw.write(cpu.address("dp", 0x52u), cpu.a, cpu.m8?8:16);
    goto L_8096B7;
L_8096B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B7u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096B7 REP
    cpu.rep(0x20u);
    goto L_8096B9;
L_8096B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B9u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8096B9 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8096B9u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8096B9u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_8096A3_E0M1X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8096A3u: goto L_8096A3;
    case 0x8096A5u: goto L_8096A5;
    case 0x8096A7u: goto L_8096A7;
    case 0x8096A8u: goto L_8096A8;
    case 0x8096AAu: goto L_8096AA;
    case 0x8096ACu: goto L_8096AC;
    case 0x8096AEu: goto L_8096AE;
    case 0x8096AFu: goto L_8096AF;
    case 0x8096B0u: goto L_8096B0;
    case 0x8096B1u: goto L_8096B1;
    case 0x8096B3u: goto L_8096B3;
    case 0x8096B5u: goto L_8096B5;
    case 0x8096B7u: goto L_8096B7;
    case 0x8096B9u: goto L_8096B9;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8096A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96A3u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96A3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096A3 SEP
    cpu.sep(0x20u);
    goto L_8096A5;
L_8096A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96A5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96A5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096A5 LDA
    cpu.setA(0xB3u, 8);
    goto L_8096A7;
L_8096A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96A7u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96A7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096A7 CLC
    cpu.setFlag('C', false);
    goto L_8096A8;
L_8096A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96A8u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96A8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x51u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096A8 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x51u), cpu.m8?8:16));
    goto L_8096AA;
L_8096AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96AAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96AAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x51u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096AA STA
    hw.write(cpu.address("dp", 0x51u), cpu.a, cpu.m8?8:16);
    goto L_8096AC;
L_8096AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96ACu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96ACu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x52u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096AC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x52u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8096AE;
L_8096AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96AEu,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96AEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096AE ROL
    cpu.rolA();
    goto L_8096AF;
L_8096AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96AFu,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96AFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096AF ROL
    cpu.rolA();
    goto L_8096B0;
L_8096B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B0u,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096B0 ROL
    cpu.rolA();
    goto L_8096B1;
L_8096B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B1u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096B1 EOR
    cpu.logicXor(0xFFu);
    goto L_8096B3;
L_8096B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B3u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x51u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096B3 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x51u), cpu.m8?8:16));
    goto L_8096B5;
L_8096B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x52u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096B5 STA
    hw.write(cpu.address("dp", 0x52u), cpu.a, cpu.m8?8:16);
    goto L_8096B7;
L_8096B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B7u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096B7 REP
    cpu.rep(0x20u);
    goto L_8096B9;
L_8096B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B9u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8096B9 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8096B9u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8096B9u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_8096A3_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8096A3u: goto L_8096A3;
    case 0x8096A5u: goto L_8096A5;
    case 0x8096A7u: goto L_8096A7;
    case 0x8096A8u: goto L_8096A8;
    case 0x8096AAu: goto L_8096AA;
    case 0x8096ACu: goto L_8096AC;
    case 0x8096AEu: goto L_8096AE;
    case 0x8096AFu: goto L_8096AF;
    case 0x8096B0u: goto L_8096B0;
    case 0x8096B1u: goto L_8096B1;
    case 0x8096B3u: goto L_8096B3;
    case 0x8096B5u: goto L_8096B5;
    case 0x8096B7u: goto L_8096B7;
    case 0x8096B9u: goto L_8096B9;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8096A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96A3u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96A3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096A3 SEP
    cpu.sep(0x20u);
    goto L_8096A5;
L_8096A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96A5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96A5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096A5 LDA
    cpu.setA(0xB3u, 8);
    goto L_8096A7;
L_8096A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96A7u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96A7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096A7 CLC
    cpu.setFlag('C', false);
    goto L_8096A8;
L_8096A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96A8u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96A8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x51u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096A8 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x51u), cpu.m8?8:16));
    goto L_8096AA;
L_8096AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96AAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96AAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x51u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096AA STA
    hw.write(cpu.address("dp", 0x51u), cpu.a, cpu.m8?8:16);
    goto L_8096AC;
L_8096AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96ACu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96ACu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x52u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096AC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x52u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8096AE;
L_8096AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96AEu,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96AEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096AE ROL
    cpu.rolA();
    goto L_8096AF;
L_8096AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96AFu,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96AFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096AF ROL
    cpu.rolA();
    goto L_8096B0;
L_8096B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B0u,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096B0 ROL
    cpu.rolA();
    goto L_8096B1;
L_8096B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B1u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096B1 EOR
    cpu.logicXor(0xFFu);
    goto L_8096B3;
L_8096B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B3u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x51u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096B3 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x51u), cpu.m8?8:16));
    goto L_8096B5;
L_8096B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x52u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096B5 STA
    hw.write(cpu.address("dp", 0x52u), cpu.a, cpu.m8?8:16);
    goto L_8096B7;
L_8096B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B7u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096B7 REP
    cpu.rep(0x20u);
    goto L_8096B9;
L_8096B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B9u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8096B9 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8096B9u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8096B9u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80ACAE_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80ACAEu: goto L_80ACAE;
    case 0x80ACB1u: goto L_80ACB1;
    case 0x80ACB3u: goto L_80ACB3;
    case 0x80ACB6u: goto L_80ACB6;
    case 0x80ACB9u: goto L_80ACB9;
    case 0x80ACBBu: goto L_80ACBB;
    case 0x80ACBEu: goto L_80ACBE;
    case 0x80ACC1u: goto L_80ACC1;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80ACAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACAEu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACAEu, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACAE LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x958u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80ACB1;
L_80ACB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACB1u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACB1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACB1 BEQ -> $80ACBB
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80ACBB; }
    goto L_80ACB3;
L_80ACB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACB3u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACB3u, 5u, 3u, cpu.address("abs", 0x0900u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACB3 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x900u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80ACB6;
L_80ACB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACB6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACB6u, 5u, 3u, cpu.address("abs", 0x0998u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACB6 STA
    hw.write(cpu.address("abs", 0x998u), cpu.a, cpu.m8?8:16);
    goto L_80ACB9;
L_80ACB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACB9u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACB9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACB9 BRA -> $80ACC1
    goto L_80ACC1;
L_80ACBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACBBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACBBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACBB LDA
    cpu.setA(0x38u, 16);
    goto L_80ACBE;
L_80ACBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACBEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACBEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACBEu, 5u, 3u, cpu.address("abs", 0x0900u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACBE STA
    hw.write(cpu.address("abs", 0x900u), cpu.a, cpu.m8?8:16);
    goto L_80ACC1;
L_80ACC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACC1u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACC1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80ACC1 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80ACC1u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80ACC1u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80ACAE_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80ACAEu: goto L_80ACAE;
    case 0x80ACB1u: goto L_80ACB1;
    case 0x80ACB3u: goto L_80ACB3;
    case 0x80ACB6u: goto L_80ACB6;
    case 0x80ACB9u: goto L_80ACB9;
    case 0x80ACBBu: goto L_80ACBB;
    case 0x80ACBEu: goto L_80ACBE;
    case 0x80ACC1u: goto L_80ACC1;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80ACAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACAEu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACAEu, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACAE LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x958u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80ACB1;
L_80ACB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACB1u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACB1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACB1 BEQ -> $80ACBB
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80ACBB; }
    goto L_80ACB3;
L_80ACB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACB3u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACB3u, 5u, 3u, cpu.address("abs", 0x0900u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACB3 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x900u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80ACB6;
L_80ACB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACB6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACB6u, 5u, 3u, cpu.address("abs", 0x0998u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACB6 STA
    hw.write(cpu.address("abs", 0x998u), cpu.a, cpu.m8?8:16);
    goto L_80ACB9;
L_80ACB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACB9u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACB9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACB9 BRA -> $80ACC1
    goto L_80ACC1;
L_80ACBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACBBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACBBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACBB LDA
    cpu.setA(0x38u, 16);
    goto L_80ACBE;
L_80ACBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACBEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACBEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACBEu, 5u, 3u, cpu.address("abs", 0x0900u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ACBE STA
    hw.write(cpu.address("abs", 0x900u), cpu.a, cpu.m8?8:16);
    goto L_80ACC1;
L_80ACC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACC1u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACC1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80ACC1 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80ACC1u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80ACC1u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80B173_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B173u: goto L_80B173;
    case 0x80B176u: goto L_80B176;
    case 0x80B178u: goto L_80B178;
    case 0x80B17Bu: goto L_80B17B;
    case 0x80B17Du: goto L_80B17D;
    case 0x80B180u: goto L_80B180;
    case 0x80B183u: goto L_80B183;
    case 0x80B186u: goto L_80B186;
    case 0x80B188u: goto L_80B188;
    case 0x80B18Bu: goto L_80B18B;
    case 0x80B18Eu: goto L_80B18E;
    case 0x80B191u: goto L_80B191;
    case 0x80B194u: goto L_80B194;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B173:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB173u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB173u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB173u, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B173 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x958u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B176;
L_80B176:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB176u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB176u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB176u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B176 BEQ -> $80B18E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B18E; }
    goto L_80B178;
L_80B178:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB178u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB178u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB178u, 5u, 3u, cpu.address("abs", 0x0916u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B178 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x916u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B17B;
L_80B17B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB17Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB17Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB17Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B17B BEQ -> $80B18E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B18E; }
    goto L_80B17D;
L_80B17D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB17Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB17Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB17Du, 5u, 3u, cpu.address("abs", 0x097Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B17D STA
    hw.write(cpu.address("abs", 0x97Au), cpu.a, cpu.m8?8:16);
    goto L_80B180;
L_80B180:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB180u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB180u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB180u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B180 LDX
    cpu.setX(0x3ACu, 16);
    goto L_80B183;
L_80B183:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB183u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB183u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB183u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B183 LDA
    cpu.setA(0x2u, 16);
    goto L_80B186;
L_80B186:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB186u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB186u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB186u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B186 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80B188;
L_80B188:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB188u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB188u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB188u, 8u, 3u, cpu.address("abs", 0x0986u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B188 INC
    cpu.incMem(hw, cpu.address("abs", 0x986u), cpu.m8?8:16);
    goto L_80B18B;
L_80B18B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB18Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB18Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB18Bu, 6u, 3u, cpu.address("abs", 0xC85Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B18B JSR -> $80C85C stack real
    { cpu.push16Value(hw,0xB18Du); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB18Eu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC85Cu), 0x80B18Bu); }
    goto L_80B18E;
L_80B18E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB18Eu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB18Eu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB18Eu, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B18E STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80B191;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB18Eu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB18Eu, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B18E STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80B191;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB18Eu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB18Eu, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B18E STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80B191;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB18Eu,0x80B18Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B191:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB191u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB191u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB191u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B191 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B194;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB191u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB191u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B191 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B194;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB191u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB191u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B191 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B194;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB191u,0x80B191u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B194:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB194u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB194u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB194u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B194 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B194u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B194u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB194u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB194u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B194 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B194u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B194u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB194u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB194u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B194 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B194u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B194u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB194u,0x80B194u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80BB7F_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80BB7Fu: goto L_80BB7F;
    case 0x80BB82u: goto L_80BB82;
    case 0x80BB84u: goto L_80BB84;
    case 0x80BB87u: goto L_80BB87;
    case 0x80BB88u: goto L_80BB88;
    case 0x80BB8Bu: goto L_80BB8B;
    case 0x80BB8Du: goto L_80BB8D;
    case 0x80BB8Fu: goto L_80BB8F;
    case 0x80BB92u: goto L_80BB92;
    case 0x80BB94u: goto L_80BB94;
    case 0x80BB98u: goto L_80BB98;
    case 0x80BB9Au: goto L_80BB9A;
    case 0x80BB9Bu: goto L_80BB9B;
    case 0x80BB9Cu: goto L_80BB9C;
    case 0x80BB9Du: goto L_80BB9D;
    case 0x80BB9Eu: goto L_80BB9E;
    case 0x80BBA1u: goto L_80BBA1;
    case 0x80BBA4u: goto L_80BBA4;
    case 0x80BBA6u: goto L_80BBA6;
    case 0x80BBA7u: goto L_80BBA7;
    case 0x80BBA8u: goto L_80BBA8;
    case 0x80BBA9u: goto L_80BBA9;
    case 0x80BBACu: goto L_80BBAC;
    case 0x80BBAFu: goto L_80BBAF;
    case 0x80BBB0u: goto L_80BBB0;
    case 0x80BBB3u: goto L_80BBB3;
    case 0x80BBB6u: goto L_80BBB6;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80BB7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB7Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB7Fu, 5u, 3u, cpu.address("abs", 0x098Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB7F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x98Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BB82;
L_80BB82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB82u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB82u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB82 BEQ -> $80BBB0
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BBB0; }
    goto L_80BB84;
L_80BB84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB84u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB84u, 5u, 3u, cpu.address("abs", 0x098Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB84 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x98Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BB87;
L_80BB87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB87u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB87u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB87 SEC
    cpu.setFlag('C', true);
    goto L_80BB88;
L_80BB88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB88u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB88u,cpu,0xEDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB88u, 5u, 3u, cpu.address("abs", 0x099Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB88 SBC
    cpu.sbc(hw.readW(cpu.address("abs", 0x99Eu), cpu.m8?8:16));
    goto L_80BB8B;
L_80BB8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB8Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB8Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB8B STA
    hw.write(cpu.address("dp", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_80BB8D;
L_80BB8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB8Du,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB8Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x38u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB8D STZ
    hw.write(cpu.address("dp", 0x38u), 0, cpu.m8?8:16);
    goto L_80BB8F;
L_80BB8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB8Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB8Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB8F LDA
    cpu.setA(0x16u, 16);
    goto L_80BB92;
L_80BB92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB92u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB92u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x39u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB92 STA
    hw.write(cpu.address("dp", 0x39u), cpu.a, cpu.m8?8:16);
    goto L_80BB94;
L_80BB94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB94u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB94u, 8u, 4u, 0x809436u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BB94 JSL -> $809436 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBB97u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBB98u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809436u, 0x80BB94u); }
    goto L_80BB98;
L_80BB98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB98u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBB98u,0x80BB98u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB98u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB98u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB98 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x36u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BB9A;
L_80BB9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB9Au,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB9Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB9A ASL
    cpu.aslA();
    goto L_80BB9B;
L_80BB9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB9Bu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB9Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB9B ASL
    cpu.aslA();
    goto L_80BB9C;
L_80BB9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB9Cu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB9Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB9C ASL
    cpu.aslA();
    goto L_80BB9D;
L_80BB9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB9Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB9Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB9D CLC
    cpu.setFlag('C', false);
    goto L_80BB9E;
L_80BB9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB9Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB9Eu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB9Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB9E ADC
    cpu.adc(0x18u);
    goto L_80BBA1;
L_80BBA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBA1u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBA1u, 5u, 3u, cpu.address("abs", 0x0990u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBA1 STA
    hw.write(cpu.address("abs", 0x990u), cpu.a, cpu.m8?8:16);
    goto L_80BBA4;
L_80BBA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBA4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBA4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBA4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BBA6;
L_80BBA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBA6u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBA6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBA6 ASL
    cpu.aslA();
    goto L_80BBA7;
L_80BBA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBA7u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBA7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBA7 ASL
    cpu.aslA();
    goto L_80BBA8;
L_80BBA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBA8u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBA8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBA8 CLC
    cpu.setFlag('C', false);
    goto L_80BBA9;
L_80BBA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBA9u,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBA9u, 5u, 3u, cpu.address("abs", 0x09A0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBA9 ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x9A0u), cpu.m8?8:16));
    goto L_80BBAC;
L_80BBAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBACu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBACu, 5u, 3u, cpu.address("abs", 0x0992u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBAC STA
    hw.write(cpu.address("abs", 0x992u), cpu.a, cpu.m8?8:16);
    goto L_80BBAF;
L_80BBAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBAFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBAFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BBAF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80BBAFu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80BBAFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80BBB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBB0u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBB0u, 5u, 3u, cpu.address("abs", 0x0992u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBB0 STZ
    hw.write(cpu.address("abs", 0x992u), 0, cpu.m8?8:16);
    goto L_80BBB3;
L_80BBB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBB3u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBB3u, 5u, 3u, cpu.address("abs", 0x0990u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBB3 STZ
    hw.write(cpu.address("abs", 0x990u), 0, cpu.m8?8:16);
    goto L_80BBB6;
L_80BBB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBB6u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBB6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BBB6 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80BBB6u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80BBB6u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80C591_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80C591u: goto L_80C591;
    case 0x80C593u: goto L_80C593;
    case 0x80C597u: goto L_80C597;
    case 0x80C59Au: goto L_80C59A;
    case 0x80C59Cu: goto L_80C59C;
    case 0x80C5A0u: goto L_80C5A0;
    case 0x80C5A2u: goto L_80C5A2;
    case 0x80C5A6u: goto L_80C5A6;
    case 0x80C5A9u: goto L_80C5A9;
    case 0x80C5ABu: goto L_80C5AB;
    case 0x80C5AEu: goto L_80C5AE;
    case 0x80C5B0u: goto L_80C5B0;
    case 0x80C5B2u: goto L_80C5B2;
    case 0x80C5B3u: goto L_80C5B3;
    case 0x80C5B5u: goto L_80C5B5;
    case 0x80C5B9u: goto L_80C5B9;
    case 0x80C5BBu: goto L_80C5BB;
    case 0x80C5BFu: goto L_80C5BF;
    case 0x80C5C2u: goto L_80C5C2;
    case 0x80C5C6u: goto L_80C5C6;
    case 0x80C5C8u: goto L_80C5C8;
    case 0x80C5CAu: goto L_80C5CA;
    case 0x80C5CCu: goto L_80C5CC;
    case 0x80C5CEu: goto L_80C5CE;
    case 0x80C5D0u: goto L_80C5D0;
    case 0x80C5D2u: goto L_80C5D2;
    case 0x80C5D4u: goto L_80C5D4;
    case 0x80C5D8u: goto L_80C5D8;
    case 0x80C5DAu: goto L_80C5DA;
    case 0x80C5DEu: goto L_80C5DE;
    case 0x80C5E1u: goto L_80C5E1;
    case 0x80C5E3u: goto L_80C5E3;
    case 0x80C5E6u: goto L_80C5E6;
    case 0x80C5E8u: goto L_80C5E8;
    case 0x80C5EAu: goto L_80C5EA;
    case 0x80C5EBu: goto L_80C5EB;
    case 0x80C5EDu: goto L_80C5ED;
    case 0x80C5F1u: goto L_80C5F1;
    case 0x80C5F3u: goto L_80C5F3;
    case 0x80C5F7u: goto L_80C5F7;
    case 0x80C5FAu: goto L_80C5FA;
    case 0x80C5FEu: goto L_80C5FE;
    case 0x80C600u: goto L_80C600;
    case 0x80C602u: goto L_80C602;
    case 0x80C604u: goto L_80C604;
    case 0x80C606u: goto L_80C606;
    case 0x80C608u: goto L_80C608;
    case 0x80C60Au: goto L_80C60A;
    case 0x80C60Cu: goto L_80C60C;
    case 0x80C610u: goto L_80C610;
    case 0x80C612u: goto L_80C612;
    case 0x80C616u: goto L_80C616;
    case 0x80C619u: goto L_80C619;
    case 0x80C61Bu: goto L_80C61B;
    case 0x80C61Eu: goto L_80C61E;
    case 0x80C620u: goto L_80C620;
    case 0x80C622u: goto L_80C622;
    case 0x80C623u: goto L_80C623;
    case 0x80C625u: goto L_80C625;
    case 0x80C629u: goto L_80C629;
    case 0x80C62Bu: goto L_80C62B;
    case 0x80C62Fu: goto L_80C62F;
    case 0x80C632u: goto L_80C632;
    case 0x80C636u: goto L_80C636;
    case 0x80C638u: goto L_80C638;
    case 0x80C63Au: goto L_80C63A;
    case 0x80C63Cu: goto L_80C63C;
    case 0x80C63Eu: goto L_80C63E;
    case 0x80C640u: goto L_80C640;
    case 0x80C642u: goto L_80C642;
    case 0x80C644u: goto L_80C644;
    case 0x80C648u: goto L_80C648;
    case 0x80C64Au: goto L_80C64A;
    case 0x80C64Eu: goto L_80C64E;
    case 0x80C651u: goto L_80C651;
    case 0x80C653u: goto L_80C653;
    case 0x80C656u: goto L_80C656;
    case 0x80C658u: goto L_80C658;
    case 0x80C65Au: goto L_80C65A;
    case 0x80C65Bu: goto L_80C65B;
    case 0x80C65Cu: goto L_80C65C;
    case 0x80C65Fu: goto L_80C65F;
    case 0x80C661u: goto L_80C661;
    case 0x80C665u: goto L_80C665;
    case 0x80C667u: goto L_80C667;
    case 0x80C66Bu: goto L_80C66B;
    case 0x80C66Eu: goto L_80C66E;
    case 0x80C672u: goto L_80C672;
    case 0x80C674u: goto L_80C674;
    case 0x80C676u: goto L_80C676;
    case 0x80C678u: goto L_80C678;
    case 0x80C67Au: goto L_80C67A;
    case 0x80C67Cu: goto L_80C67C;
    case 0x80C67Eu: goto L_80C67E;
    case 0x80C680u: goto L_80C680;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80C591:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC591u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC591u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC591u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C591 STX
    hw.write(cpu.address("dp", 0x61u), cpu.x, cpu.x8?8:16);
    goto L_80C593;
L_80C593:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC593u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC593u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC593u, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C593 LDA
    cpu.loadA(hw.readW(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C597;
L_80C597:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC597u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC597u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC597u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C597 AND
    cpu.logicAnd(0x300u);
    goto L_80C59A;
L_80C59A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC59Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC59Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC59Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C59A STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_80C59C;
L_80C59C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC59Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC59Cu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC59Cu, 6u, 4u, ((0x7E1FFEu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C59C LDA
    cpu.loadA(hw.readW(((0x7E1FFEu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C5A0;
L_80C5A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5A0u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5A0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5A0 BNE -> $80C5D4
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C5D4; }
    goto L_80C5A2;
L_80C5A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5A2u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5A2u, 6u, 4u, ((0x7E1FFCu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5A2 LDA
    cpu.loadA(hw.readW(((0x7E1FFCu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C5A6;
L_80C5A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5A6u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5A6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5A6 CMP
    cpu.compareA(0xFFFFu);
    goto L_80C5A9;
L_80C5A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5A9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5A9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5A9 BEQ -> $80C5D4
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C5D4; }
    goto L_80C5AB;
L_80C5AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5ABu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5ABu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5AB AND
    cpu.logicAnd(0x300u);
    goto L_80C5AE;
L_80C5AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5AEu,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5AEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5AE CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16));
    goto L_80C5B0;
L_80C5B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5B0u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5B0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5B0 BNE -> $80C5D4
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C5D4; }
    goto L_80C5B2;
L_80C5B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5B2u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5B2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5B2 TXA
    cpu.transfer("TXA");
    goto L_80C5B3;
L_80C5B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5B3u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5B3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5B3 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C5B5;
L_80C5B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5B5u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5B5u, 6u, 4u, ((0x7E2444u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5B5 STA
    hw.write(((0x7E2444u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80C5B9;
L_80C5B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5B9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5B9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5B9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C5BB;
L_80C5BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5BBu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5BBu, 6u, 4u, ((0x7E2440u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5BB STA
    hw.write(((0x7E2440u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80C5BF;
L_80C5BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5BFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5BFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5BF LDA
    cpu.setA(0x0u, 16);
    goto L_80C5C2;
L_80C5C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5C2u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5C2u, 6u, 4u, ((0x7E2442u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5C2 STA
    hw.write(((0x7E2442u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80C5C6;
L_80C5C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5C6u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5C6u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5C6 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C5C8;
L_80C5C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5C8u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5C8u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5C8 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C5CA;
L_80C5CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5CAu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5CAu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5CA INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C5CC;
L_80C5CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5CCu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5CCu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5CC INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C5CE;
L_80C5CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5CEu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5CEu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5CE INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C5D0;
L_80C5D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5D0u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5D0u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5D0 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C5D2;
L_80C5D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5D2u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5D2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5D2 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x61u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C5D4;
L_80C5D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5D4u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5D4u, 6u, 4u, ((0x7E2002u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5D4 LDA
    cpu.loadA(hw.readW(((0x7E2002u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C5D8;
L_80C5D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5D8u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5D8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5D8 BNE -> $80C60C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C60C; }
    goto L_80C5DA;
L_80C5DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5DAu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5DAu, 6u, 4u, ((0x7E2004u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5DA LDA
    cpu.loadA(hw.readW(((0x7E2004u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C5DE;
L_80C5DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5DEu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5DEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5DE CMP
    cpu.compareA(0xFFFFu);
    goto L_80C5E1;
L_80C5E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5E1u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5E1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5E1 BEQ -> $80C60C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C60C; }
    goto L_80C5E3;
L_80C5E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5E3u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5E3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5E3 AND
    cpu.logicAnd(0x300u);
    goto L_80C5E6;
L_80C5E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5E6u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5E6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5E6 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16));
    goto L_80C5E8;
L_80C5E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5E8u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5E8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5E8 BNE -> $80C60C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C60C; }
    goto L_80C5EA;
L_80C5EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5EAu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5EAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5EA TXA
    cpu.transfer("TXA");
    goto L_80C5EB;
L_80C5EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5EBu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5EBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5EB LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C5ED;
L_80C5ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5EDu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5EDu, 6u, 4u, ((0x7E2444u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5ED STA
    hw.write(((0x7E2444u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80C5F1;
L_80C5F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5F1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5F1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5F1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C5F3;
L_80C5F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5F3u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5F3u, 6u, 4u, ((0x7E2440u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5F3 STA
    hw.write(((0x7E2440u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80C5F7;
L_80C5F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5F7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5F7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5F7 LDA
    cpu.setA(0x2u, 16);
    goto L_80C5FA;
L_80C5FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5FAu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5FAu, 6u, 4u, ((0x7E2442u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5FA STA
    hw.write(((0x7E2442u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80C5FE;
L_80C5FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5FEu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5FEu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C5FE INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C600;
L_80C600:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC600u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC600u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC600u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C600 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C602;
L_80C602:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC602u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC602u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC602u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C602 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C604;
L_80C604:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC604u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC604u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC604u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C604 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C606;
L_80C606:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC606u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC606u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC606u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C606 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C608;
L_80C608:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC608u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC608u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC608u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C608 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C60A;
L_80C60A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC60Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC60Au,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC60Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C60A LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x61u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C60C;
L_80C60C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC60Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC60Cu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC60Cu, 6u, 4u, ((0x7E2016u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C60C LDA
    cpu.loadA(hw.readW(((0x7E2016u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C610;
L_80C610:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC610u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC610u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC610u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C610 BNE -> $80C644
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C644; }
    goto L_80C612;
L_80C612:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC612u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC612u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC612u, 6u, 4u, ((0x7E202Cu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C612 LDA
    cpu.loadA(hw.readW(((0x7E202Cu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C616;
L_80C616:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC616u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC616u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC616u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C616 CMP
    cpu.compareA(0xFFFFu);
    goto L_80C619;
L_80C619:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC619u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC619u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC619u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C619 BEQ -> $80C644
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C644; }
    goto L_80C61B;
L_80C61B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC61Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC61Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC61Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C61B AND
    cpu.logicAnd(0x300u);
    goto L_80C61E;
L_80C61E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC61Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC61Eu,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC61Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C61E CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16));
    goto L_80C620;
L_80C620:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC620u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC620u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC620u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C620 BNE -> $80C644
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C644; }
    goto L_80C622;
L_80C622:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC622u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC622u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC622u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C622 TXA
    cpu.transfer("TXA");
    goto L_80C623;
L_80C623:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC623u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC623u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC623u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C623 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C625;
L_80C625:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC625u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC625u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC625u, 6u, 4u, ((0x7E2444u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C625 STA
    hw.write(((0x7E2444u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80C629;
L_80C629:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC629u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC629u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC629u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C629 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C62B;
L_80C62B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC62Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC62Bu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC62Bu, 6u, 4u, ((0x7E2440u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C62B STA
    hw.write(((0x7E2440u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80C62F;
L_80C62F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC62Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC62Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC62Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C62F LDA
    cpu.setA(0x4u, 16);
    goto L_80C632;
L_80C632:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC632u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC632u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC632u, 6u, 4u, ((0x7E2442u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C632 STA
    hw.write(((0x7E2442u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80C636;
L_80C636:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC636u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC636u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC636u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C636 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C638;
L_80C638:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC638u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC638u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC638u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C638 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C63A;
L_80C63A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC63Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC63Au,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC63Au, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C63A INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C63C;
L_80C63C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC63Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC63Cu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC63Cu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C63C INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C63E;
L_80C63E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC63Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC63Eu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC63Eu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C63E INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C640;
L_80C640:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC640u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC640u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC640u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C640 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C642;
L_80C642:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC642u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC642u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC642u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C642 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x61u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C644;
L_80C644:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC644u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC644u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC644u, 6u, 4u, ((0x7E1FEAu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C644 LDA
    cpu.loadA(hw.readW(((0x7E1FEAu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C648;
L_80C648:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC648u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC648u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC648u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C648 BNE -> $80C680
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C680; }
    goto L_80C64A;
L_80C64A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC64Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC64Au,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC64Au, 6u, 4u, ((0x7E1FD4u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C64A LDA
    cpu.loadA(hw.readW(((0x7E1FD4u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C64E;
L_80C64E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC64Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC64Eu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC64Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C64E CMP
    cpu.compareA(0xFFFFu);
    goto L_80C651;
L_80C651:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC651u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC651u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC651u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C651 BEQ -> $80C680
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C680; }
    goto L_80C653;
L_80C653:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC653u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC653u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC653u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C653 AND
    cpu.logicAnd(0x300u);
    goto L_80C656;
L_80C656:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC656u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC656u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC656u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C656 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16));
    goto L_80C658;
L_80C658:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC658u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC658u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC658u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C658 BNE -> $80C680
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C680; }
    goto L_80C65A;
L_80C65A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC65Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC65Au,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC65Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C65A TXA
    cpu.transfer("TXA");
    goto L_80C65B;
L_80C65B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC65Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC65Bu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC65Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C65B SEC
    cpu.setFlag('C', true);
    goto L_80C65C;
L_80C65C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC65Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC65Cu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC65Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C65C SBC
    cpu.sbc(0x2Cu);
    goto L_80C65F;
L_80C65F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC65Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC65Fu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC65Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C65F LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C661;
L_80C661:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC661u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC661u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC661u, 6u, 4u, ((0x7E2444u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C661 STA
    hw.write(((0x7E2444u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80C665;
L_80C665:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC665u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC665u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC665u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C665 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C667;
L_80C667:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC667u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC667u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC667u, 6u, 4u, ((0x7E2440u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C667 STA
    hw.write(((0x7E2440u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80C66B;
L_80C66B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC66Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC66Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC66Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C66B LDA
    cpu.setA(0x4u, 16);
    goto L_80C66E;
L_80C66E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC66Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC66Eu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC66Eu, 6u, 4u, ((0x7E2442u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C66E STA
    hw.write(((0x7E2442u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80C672;
L_80C672:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC672u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC672u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC672u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C672 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C674;
L_80C674:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC674u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC674u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC674u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C674 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C676;
L_80C676:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC676u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC676u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC676u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C676 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C678;
L_80C678:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC678u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC678u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC678u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C678 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C67A;
L_80C67A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC67Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC67Au,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC67Au, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C67A INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C67C;
L_80C67C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC67Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC67Cu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC67Cu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C67C INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C67E;
L_80C67E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC67Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC67Eu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC67Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C67E LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x61u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C680;
L_80C680:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC680u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC680u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC680u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80C680 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80C680u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80C680u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80CA6E_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80CA6Eu: goto L_80CA6E;
    case 0x80CA71u: goto L_80CA71;
    case 0x80CA74u: goto L_80CA74;
    case 0x80CA76u: goto L_80CA76;
    case 0x80CA79u: goto L_80CA79;
    case 0x80CA7Bu: goto L_80CA7B;
    case 0x80CA7Du: goto L_80CA7D;
    case 0x80CA7Fu: goto L_80CA7F;
    case 0x80CA81u: goto L_80CA81;
    case 0x80CA82u: goto L_80CA82;
    case 0x80CA83u: goto L_80CA83;
    case 0x80CA87u: goto L_80CA87;
    case 0x80CA89u: goto L_80CA89;
    case 0x80CA8Cu: goto L_80CA8C;
    case 0x80CA8Eu: goto L_80CA8E;
    case 0x80CA91u: goto L_80CA91;
    case 0x80CA94u: goto L_80CA94;
    case 0x80CA96u: goto L_80CA96;
    case 0x80CA98u: goto L_80CA98;
    case 0x80CA9Bu: goto L_80CA9B;
    case 0x80CA9Du: goto L_80CA9D;
    case 0x80CAA1u: goto L_80CAA1;
    case 0x80CAA3u: goto L_80CAA3;
    case 0x80CAA5u: goto L_80CAA5;
    case 0x80CAA6u: goto L_80CAA6;
    case 0x80CAA8u: goto L_80CAA8;
    case 0x80CAACu: goto L_80CAAC;
    case 0x80CAAEu: goto L_80CAAE;
    case 0x80CAB2u: goto L_80CAB2;
    case 0x80CAB5u: goto L_80CAB5;
    case 0x80CAB9u: goto L_80CAB9;
    case 0x80CABBu: goto L_80CABB;
    case 0x80CABDu: goto L_80CABD;
    case 0x80CABFu: goto L_80CABF;
    case 0x80CAC1u: goto L_80CAC1;
    case 0x80CAC3u: goto L_80CAC3;
    case 0x80CAC5u: goto L_80CAC5;
    case 0x80CAC7u: goto L_80CAC7;
    case 0x80CAC9u: goto L_80CAC9;
    case 0x80CACBu: goto L_80CACB;
    case 0x80CACDu: goto L_80CACD;
    case 0x80CACFu: goto L_80CACF;
    case 0x80CAD2u: goto L_80CAD2;
    case 0x80CAD6u: goto L_80CAD6;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80CA6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA6Eu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA6Eu, 5u, 3u, cpu.address("abs", 0x096Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CA6E LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x96Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80CA71;
L_80CA71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA71u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA71u, 5u, 3u, cpu.address("abs", 0x0970u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CA71 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x970u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80CA74;
L_80CA74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA74u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA74u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CA74 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80CA76;
L_80CA76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA76u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA76u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CA76 LDA
    cpu.setA(0x1Eu, 16);
    goto L_80CA79;
L_80CA79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA79u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA79u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CA79 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_80CA7B;
L_80CA7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA7Bu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA7Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CA7B STZ
    hw.write(cpu.address("dp", 0x63u), 0, cpu.m8?8:16);
    goto L_80CA7D;
L_80CA7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA7Du))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA7Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA7Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CA7D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80CA7F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA7Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA7Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CA7D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80CA7F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCA7Du,0x80CA7Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80CA7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA7Fu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA7Fu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA7Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CA7F BMI -> $80CACD
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_80CACD; }
    goto L_80CA81;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA7Fu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA7Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CA7F BMI -> $80CACD
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_80CACD; }
    goto L_80CA81;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCA7Fu,0x80CA7Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80CA81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA81u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA81u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA81u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CA81 INX
    cpu.inc('X');
    goto L_80CA82;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA81u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA81u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CA81 INX
    cpu.inc('X');
    goto L_80CA82;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCA81u,0x80CA81u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80CA82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA82u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA82u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA82u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CA82 INX
    cpu.inc('X');
    goto L_80CA83;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA82u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA82u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CA82 INX
    cpu.inc('X');
    goto L_80CA83;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCA82u,0x80CA82u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80CA83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA83u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA83u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA83u, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CA83 LDA
    cpu.loadA(hw.readW(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80CA87;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA83u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA83u, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CA83 LDA
    cpu.loadA(hw.readW(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80CA87;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCA83u,0x80CA83u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80CA87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA87u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA87u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA87u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CA87 BEQ -> $80CA7D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80CA7D; }
    goto L_80CA89;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA87u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA87u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CA87 BEQ -> $80CA7D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80CA7D; }
    goto L_80CA89;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCA87u,0x80CA87u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80CA89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA89u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA89u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA89u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CA89 CMP
    cpu.compareA(0xFFFFu);
    goto L_80CA8C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA89u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA89u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CA89 CMP
    cpu.compareA(0xFFFFu);
    goto L_80CA8C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCA89u,0x80CA89u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80CA8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA8Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA8Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CA8C BEQ -> $80CAC9
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80CAC9; }
    goto L_80CA8E;
L_80CA8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA8Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA8Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CA8E AND
    cpu.logicAnd(0xFu);
    goto L_80CA91;
L_80CA91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA91u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA91u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CA91 CMP
    cpu.compareA(0xFu);
    goto L_80CA94;
L_80CA94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA94u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA94u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CA94 BNE -> $80CAC9
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80CAC9; }
    goto L_80CA96;
L_80CA96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA96u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA96u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CA96 DEC
    cpu.decMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_80CA98;
L_80CA98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA98u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA98u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CA98 AND
    cpu.logicAnd(0x300u);
    goto L_80CA9B;
L_80CA9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA9Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA9Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CA9B STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_80CA9D;
L_80CA9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA9Du,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA9Du, 6u, 4u, ((0x7E1FEAu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CA9D LDA
    cpu.loadA(hw.readW(((0x7E1FEAu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80CAA1;
L_80CAA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA1u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CAA1 BNE -> $80CA7D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80CA7D; }
    goto L_80CAA3;
L_80CAA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA3u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CAA3 STX
    hw.write(cpu.address("dp", 0x61u), cpu.x, cpu.x8?8:16);
    goto L_80CAA5;
L_80CAA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA5u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CAA5 TXA
    cpu.transfer("TXA");
    goto L_80CAA6;
L_80CAA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA6u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CAA6 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80CAA8;
L_80CAA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA8u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA8u, 6u, 4u, ((0x7E2444u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CAA8 STA
    hw.write(((0x7E2444u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80CAAC;
L_80CAAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAACu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAACu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CAAC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80CAAE;
L_80CAAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAAEu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAAEu, 6u, 4u, ((0x7E2440u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CAAE STA
    hw.write(((0x7E2440u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80CAB2;
L_80CAB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CAB2 LDA
    cpu.setA(0x4u, 16);
    goto L_80CAB5;
L_80CAB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB5u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB5u, 6u, 4u, ((0x7E2442u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CAB5 STA
    hw.write(((0x7E2442u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80CAB9;
L_80CAB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB9u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB9u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CAB9 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80CABB;
L_80CABB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCABBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCABBu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCABBu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CABB INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80CABD;
L_80CABD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCABDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCABDu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCABDu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CABD INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80CABF;
L_80CABF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCABFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCABFu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCABFu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CABF INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80CAC1;
L_80CAC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC1u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC1u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CAC1 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80CAC3;
L_80CAC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC3u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC3u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CAC3 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80CAC5;
L_80CAC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC5u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CAC5 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x61u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80CAC7;
L_80CAC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC7u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CAC7 BRA -> $80CA7D
    goto L_80CA7D;
L_80CAC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC9u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC9u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CAC9 DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_80CACB;
L_80CACB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCACBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCACBu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCACBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CACB BNE -> $80CA7D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80CA7D; }
    goto L_80CACD;
L_80CACD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCACDu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCACDu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCACDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CACD LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80CACF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCACDu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCACDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CACD LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80CACF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCACDu,0x80CACDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80CACF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCACFu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCACFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCACFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CACF LDA
    cpu.setA(0xFFFFu, 16);
    goto L_80CAD2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCACFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCACFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CACF LDA
    cpu.setA(0xFFFFu, 16);
    goto L_80CAD2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCACFu,0x80CACFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80CAD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAD2u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAD2u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAD2u, 6u, 4u, ((0x7E2440u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CAD2 STA
    hw.write(((0x7E2440u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80CAD6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAD2u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAD2u, 6u, 4u, ((0x7E2440u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CAD2 STA
    hw.write(((0x7E2440u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80CAD6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCAD2u,0x80CAD2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80CAD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAD6u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAD6u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAD6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80CAD6 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80CAD6u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80CAD6u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAD6u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAD6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80CAD6 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80CAD6u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80CAD6u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCAD6u,0x80CAD6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80D088_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80D088u: goto L_80D088;
    case 0x80D08Bu: goto L_80D08B;
    case 0x80D08Eu: goto L_80D08E;
    case 0x80D090u: goto L_80D090;
    case 0x80D092u: goto L_80D092;
    case 0x80D093u: goto L_80D093;
    case 0x80D094u: goto L_80D094;
    case 0x80D098u: goto L_80D098;
    case 0x80D09Au: goto L_80D09A;
    case 0x80D09Du: goto L_80D09D;
    case 0x80D09Fu: goto L_80D09F;
    case 0x80D0A2u: goto L_80D0A2;
    case 0x80D0A4u: goto L_80D0A4;
    case 0x80D0A6u: goto L_80D0A6;
    case 0x80D0A8u: goto L_80D0A8;
    case 0x80D0AAu: goto L_80D0AA;
    case 0x80D0ADu: goto L_80D0AD;
    case 0x80D0B1u: goto L_80D0B1;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80D088:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD088u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD088u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD088u, 5u, 3u, cpu.address("abs", 0x096Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D088 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x96Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80D08B;
L_80D08B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD08Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD08Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD08Bu, 5u, 3u, cpu.address("abs", 0x0970u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D08B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x970u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D08E;
L_80D08E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD08Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD08Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD08Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D08E STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80D090;
L_80D090:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD090u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD090u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD090u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D090 STZ
    hw.write(cpu.address("dp", 0x63u), 0, cpu.m8?8:16);
    goto L_80D092;
L_80D092:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD092u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD092u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD092u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D092 INX
    cpu.inc('X');
    goto L_80D093;
L_80D093:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD093u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD093u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD093u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D093 INX
    cpu.inc('X');
    goto L_80D094;
L_80D094:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD094u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD094u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD094u, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D094 LDA
    cpu.loadA(hw.readW(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D098;
L_80D098:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD098u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD098u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD098u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D098 BEQ -> $80D092
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D092; }
    goto L_80D09A;
L_80D09A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD09Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD09Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD09Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D09A CMP
    cpu.compareA(0xFFFFu);
    goto L_80D09D;
L_80D09D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD09Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD09Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD09Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D09D BEQ -> $80D0A4
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D0A4; }
    goto L_80D09F;
L_80D09F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD09Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD09Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD09Fu, 6u, 3u, cpu.address("abs", 0xD0B2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D09F JSR -> $80D0B2 stack real
    { cpu.push16Value(hw,0xD0A1u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD0A2u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD0B2u), 0x80D09Fu); }
    goto L_80D0A2;
L_80D0A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0A2u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0A2u,0x80D0A2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0A2u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0A2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0A2 BRA -> $80D092
    goto L_80D092;
L_80D0A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0A4u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0A4u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0A4 DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_80D0A6;
L_80D0A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0A6u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0A6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0A6 BNE -> $80D092
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D092; }
    goto L_80D0A8;
L_80D0A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0A8u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0A8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0A8 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80D0AA;
L_80D0AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0AAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0AAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0AA LDA
    cpu.setA(0xFFFFu, 16);
    goto L_80D0AD;
L_80D0AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0ADu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0ADu, 6u, 4u, ((0x7E2440u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D0AD STA
    hw.write(((0x7E2440u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80D0B1;
L_80D0B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0B1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0B1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D0B1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80D0B1u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80D0B1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82928D_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82928Du: goto L_82928D;
    case 0x829290u: goto L_829290;
    case 0x829292u: goto L_829292;
    case 0x829295u: goto L_829295;
    case 0x829298u: goto L_829298;
    case 0x82929Bu: goto L_82929B;
    case 0x82929Du: goto L_82929D;
    case 0x82929Fu: goto L_82929F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82928D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x928Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x928Du,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x928Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82928D LDX
    cpu.setX(0x0u, 16);
    goto L_829290;
L_829290:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9290u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9290u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9290u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829290 STX
    hw.write(cpu.address("dp", 0x5Bu), cpu.x, cpu.x8?8:16);
    goto L_829292;
L_829292:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9292u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9292u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9292u, 6u, 3u, cpu.address("abs", 0xBD2Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829292 JSR -> $82BD2B stack real
    { cpu.push16Value(hw,0x9294u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9295u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBD2Bu), 0x829292u); }
    goto L_829295;
L_829295:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9295u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9295u,0x829295u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9295u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9295u, 6u, 3u, cpu.address("abs", 0xA84Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829295 JSR -> $82A84E stack real
    { cpu.push16Value(hw,0x9297u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9298u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA84Eu), 0x829295u); }
    goto L_829298;
L_829298:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9298u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9298u,0x829298u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9298u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9298u, 6u, 3u, cpu.address("abs", 0xBDADu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829298 JSR -> $82BDAD stack real
    { cpu.push16Value(hw,0x929Au); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x929Bu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBDADu), 0x829298u); }
    goto L_82929B;
L_82929B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x929Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x929Bu,0x82929Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x929Bu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x929Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82929B SEP
    cpu.sep(0x20u);
    goto L_82929D;
L_82929D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x929Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x929Du,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x929Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82929D INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_82929F;
L_82929F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x929Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x929Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x929Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82929F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82929Fu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82929Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82A043_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82A043u: goto L_82A043;
    case 0x82A045u: goto L_82A045;
    case 0x82A047u: goto L_82A047;
    case 0x82A049u: goto L_82A049;
    case 0x82A04Cu: goto L_82A04C;
    case 0x82A04Eu: goto L_82A04E;
    case 0x82A050u: goto L_82A050;
    case 0x82A052u: goto L_82A052;
    case 0x82A054u: goto L_82A054;
    case 0x82A057u: goto L_82A057;
    case 0x82A058u: goto L_82A058;
    case 0x82A05Bu: goto L_82A05B;
    case 0x82A05Du: goto L_82A05D;
    case 0x82A05Fu: goto L_82A05F;
    case 0x82A061u: goto L_82A061;
    case 0x82A062u: goto L_82A062;
    case 0x82A063u: goto L_82A063;
    case 0x82A064u: goto L_82A064;
    case 0x82A065u: goto L_82A065;
    case 0x82A066u: goto L_82A066;
    case 0x82A067u: goto L_82A067;
    case 0x82A069u: goto L_82A069;
    case 0x82A06Bu: goto L_82A06B;
    case 0x82A06Du: goto L_82A06D;
    case 0x82A06Fu: goto L_82A06F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82A043:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA043u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA043u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA043u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A043 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A045;
L_82A045:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA045u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA045u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA045u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A045 STZ
    hw.write(cpu.address("dp", 0xAu), 0, cpu.m8?8:16);
    goto L_82A047;
L_82A047:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA047u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA047u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA047u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A047 SEP
    cpu.sep(0x20u);
    goto L_82A049;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA047u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA047u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A047 SEP
    cpu.sep(0x20u);
    goto L_82A049;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA047u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA047u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A047 SEP
    cpu.sep(0x20u);
    goto L_82A049;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA047u,0x82A047u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82A049:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA049u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA049u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA049u, 4u + 1u, 3u, cpu.address("absx", 0x0208u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A049 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x208u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A04C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA049u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA049u, 4u + 1u, 3u, cpu.address("absx", 0x0208u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A049 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x208u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A04C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA049u,0x82A049u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82A04C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA04Cu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA04Cu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA04Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A04C BPL -> $82A058
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82A058; }
    goto L_82A04E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA04Cu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA04Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A04C BPL -> $82A058
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82A058; }
    goto L_82A04E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA04Cu,0x82A04Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82A04E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA04Eu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA04Eu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA04Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A04E CMP
    cpu.compareA(0x80u);
    goto L_82A050;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA04Eu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA04Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A04E CMP
    cpu.compareA(0x80u);
    goto L_82A050;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA04Eu,0x82A04Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82A050:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA050u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA050u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA050u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A050 BNE -> $82A061
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A061; }
    goto L_82A052;
L_82A052:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA052u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA052u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA052u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A052 REP
    cpu.rep(0x20u);
    goto L_82A054;
L_82A054:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA054u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA054u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA054u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A054 LDA
    cpu.setA(0x0u, 16);
    goto L_82A057;
L_82A057:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA057u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA057u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA057u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A057 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82A057u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82A057u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82A058:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA058u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA058u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA058u, 6u, 3u, cpu.address("abs", 0xA0E6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A058 JSR -> $82A0E6 stack real
    { cpu.push16Value(hw,0xA05Au); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA05Bu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA0E6u), 0x82A058u); }
    goto L_82A05B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA058u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA058u, 6u, 3u, cpu.address("abs", 0xA0E6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A058 JSR -> $82A0E6 stack real
    { cpu.push16Value(hw,0xA05Au); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA05Bu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA0E6u), 0x82A058u); }
    goto L_82A05B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA058u,0x82A058u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82A05B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA05Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA05Bu,0x82A05Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA05Bu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA05Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A05B LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xCu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A05D;
L_82A05D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA05Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA05Du,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA05Du, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 3u, 0u);
    // $82A05D LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A05F;
L_82A05F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA05Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA05Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA05Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A05F BNE -> $82A06B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A06B; }
    goto L_82A061;
L_82A061:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA061u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA061u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA061u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A061 INX
    cpu.inc('X');
    goto L_82A062;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA061u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA061u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A061 INX
    cpu.inc('X');
    goto L_82A062;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA061u,0x82A061u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82A062:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA062u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA062u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA062u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A062 INX
    cpu.inc('X');
    goto L_82A063;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA062u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA062u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A062 INX
    cpu.inc('X');
    goto L_82A063;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA062u,0x82A062u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82A063:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA063u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA063u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA063u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A063 INX
    cpu.inc('X');
    goto L_82A064;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA063u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA063u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A063 INX
    cpu.inc('X');
    goto L_82A064;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA063u,0x82A063u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82A064:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA064u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA064u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA064u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A064 INX
    cpu.inc('X');
    goto L_82A065;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA064u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA064u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A064 INX
    cpu.inc('X');
    goto L_82A065;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA064u,0x82A064u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82A065:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA065u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA065u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA065u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A065 INX
    cpu.inc('X');
    goto L_82A066;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA065u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA065u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A065 INX
    cpu.inc('X');
    goto L_82A066;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA065u,0x82A065u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82A066:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA066u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA066u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA066u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A066 INX
    cpu.inc('X');
    goto L_82A067;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA066u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA066u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A066 INX
    cpu.inc('X');
    goto L_82A067;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA066u,0x82A066u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82A067:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA067u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA067u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA067u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A067 INC
    cpu.incMem(hw, cpu.address("dp", 0xAu), cpu.m8?8:16);
    goto L_82A069;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA067u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA067u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A067 INC
    cpu.incMem(hw, cpu.address("dp", 0xAu), cpu.m8?8:16);
    goto L_82A069;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA067u,0x82A067u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82A069:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA069u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA069u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA069u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A069 BRA -> $82A047
    goto L_82A047;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA069u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA069u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A069 BRA -> $82A047
    goto L_82A047;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA069u,0x82A069u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82A06B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA06Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA06Bu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA06Bu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A06B INC
    cpu.incMem(hw, cpu.address("dp", 0xAu), cpu.m8?8:16);
    goto L_82A06D;
L_82A06D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA06Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA06Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA06Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A06D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A06F;
L_82A06F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA06Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA06Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA06Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A06F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82A06Fu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82A06Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82A043_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82A043u: goto L_82A043;
    case 0x82A045u: goto L_82A045;
    case 0x82A047u: goto L_82A047;
    case 0x82A049u: goto L_82A049;
    case 0x82A04Cu: goto L_82A04C;
    case 0x82A04Eu: goto L_82A04E;
    case 0x82A050u: goto L_82A050;
    case 0x82A052u: goto L_82A052;
    case 0x82A054u: goto L_82A054;
    case 0x82A057u: goto L_82A057;
    case 0x82A058u: goto L_82A058;
    case 0x82A05Bu: goto L_82A05B;
    case 0x82A05Du: goto L_82A05D;
    case 0x82A05Fu: goto L_82A05F;
    case 0x82A061u: goto L_82A061;
    case 0x82A062u: goto L_82A062;
    case 0x82A063u: goto L_82A063;
    case 0x82A064u: goto L_82A064;
    case 0x82A065u: goto L_82A065;
    case 0x82A066u: goto L_82A066;
    case 0x82A067u: goto L_82A067;
    case 0x82A069u: goto L_82A069;
    case 0x82A06Bu: goto L_82A06B;
    case 0x82A06Du: goto L_82A06D;
    case 0x82A06Fu: goto L_82A06F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82A043:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA043u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA043u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA043u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A043 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A045;
L_82A045:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA045u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA045u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA045u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A045 STZ
    hw.write(cpu.address("dp", 0xAu), 0, cpu.m8?8:16);
    goto L_82A047;
L_82A047:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA047u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA047u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA047u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A047 SEP
    cpu.sep(0x20u);
    goto L_82A049;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA047u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA047u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A047 SEP
    cpu.sep(0x20u);
    goto L_82A049;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA047u,0x82A047u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82A049:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA049u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA049u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA049u, 4u + 1u, 3u, cpu.address("absx", 0x0208u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A049 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x208u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A04C;
L_82A04C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA04Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA04Cu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA04Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A04C BPL -> $82A058
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82A058; }
    goto L_82A04E;
L_82A04E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA04Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA04Eu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA04Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A04E CMP
    cpu.compareA(0x80u);
    goto L_82A050;
L_82A050:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA050u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA050u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA050u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A050 BNE -> $82A061
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A061; }
    goto L_82A052;
L_82A052:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA052u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA052u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA052u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A052 REP
    cpu.rep(0x20u);
    goto L_82A054;
L_82A054:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA054u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA054u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA054u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A054 LDA
    cpu.setA(0x0u, 16);
    goto L_82A057;
L_82A057:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA057u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA057u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA057u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A057 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82A057u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82A057u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82A058:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA058u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA058u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA058u, 6u, 3u, cpu.address("abs", 0xA0E6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A058 JSR -> $82A0E6 stack real
    { cpu.push16Value(hw,0xA05Au); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA05Bu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA0E6u), 0x82A058u); }
    goto L_82A05B;
L_82A05B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA05Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA05Bu,0x82A05Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA05Bu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA05Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A05B LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xCu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A05D;
L_82A05D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA05Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA05Du,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA05Du, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 3u, 0u);
    // $82A05D LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A05F;
L_82A05F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA05Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA05Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA05Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A05F BNE -> $82A06B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A06B; }
    goto L_82A061;
L_82A061:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA061u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA061u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA061u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A061 INX
    cpu.inc('X');
    goto L_82A062;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA061u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA061u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A061 INX
    cpu.inc('X');
    goto L_82A062;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA061u,0x82A061u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82A062:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA062u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA062u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA062u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A062 INX
    cpu.inc('X');
    goto L_82A063;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA062u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA062u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A062 INX
    cpu.inc('X');
    goto L_82A063;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA062u,0x82A062u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82A063:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA063u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA063u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA063u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A063 INX
    cpu.inc('X');
    goto L_82A064;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA063u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA063u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A063 INX
    cpu.inc('X');
    goto L_82A064;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA063u,0x82A063u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82A064:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA064u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA064u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA064u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A064 INX
    cpu.inc('X');
    goto L_82A065;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA064u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA064u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A064 INX
    cpu.inc('X');
    goto L_82A065;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA064u,0x82A064u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82A065:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA065u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA065u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA065u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A065 INX
    cpu.inc('X');
    goto L_82A066;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA065u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA065u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A065 INX
    cpu.inc('X');
    goto L_82A066;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA065u,0x82A065u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82A066:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA066u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA066u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA066u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A066 INX
    cpu.inc('X');
    goto L_82A067;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA066u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA066u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A066 INX
    cpu.inc('X');
    goto L_82A067;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA066u,0x82A066u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82A067:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA067u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA067u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA067u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A067 INC
    cpu.incMem(hw, cpu.address("dp", 0xAu), cpu.m8?8:16);
    goto L_82A069;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA067u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA067u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A067 INC
    cpu.incMem(hw, cpu.address("dp", 0xAu), cpu.m8?8:16);
    goto L_82A069;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA067u,0x82A067u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82A069:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA069u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA069u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA069u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A069 BRA -> $82A047
    goto L_82A047;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA069u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA069u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A069 BRA -> $82A047
    goto L_82A047;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA069u,0x82A069u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82A06B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA06Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA06Bu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA06Bu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A06B INC
    cpu.incMem(hw, cpu.address("dp", 0xAu), cpu.m8?8:16);
    goto L_82A06D;
L_82A06D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA06Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA06Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA06Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A06D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A06F;
L_82A06F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA06Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA06Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA06Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A06F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82A06Fu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82A06Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82A22B_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82A22Bu: goto L_82A22B;
    case 0x82A22Cu: goto L_82A22C;
    case 0x82A22Du: goto L_82A22D;
    case 0x82A22Fu: goto L_82A22F;
    case 0x82A230u: goto L_82A230;
    case 0x82A232u: goto L_82A232;
    case 0x82A235u: goto L_82A235;
    case 0x82A237u: goto L_82A237;
    case 0x82A238u: goto L_82A238;
    case 0x82A23Bu: goto L_82A23B;
    case 0x82A23Eu: goto L_82A23E;
    case 0x82A240u: goto L_82A240;
    case 0x82A242u: goto L_82A242;
    case 0x82A244u: goto L_82A244;
    case 0x82A246u: goto L_82A246;
    case 0x82A249u: goto L_82A249;
    case 0x82A24Bu: goto L_82A24B;
    case 0x82A24Du: goto L_82A24D;
    case 0x82A24Fu: goto L_82A24F;
    case 0x82A251u: goto L_82A251;
    case 0x82A252u: goto L_82A252;
    case 0x82A254u: goto L_82A254;
    case 0x82A255u: goto L_82A255;
    case 0x82A256u: goto L_82A256;
    case 0x82A257u: goto L_82A257;
    case 0x82A259u: goto L_82A259;
    case 0x82A25Bu: goto L_82A25B;
    case 0x82A25Du: goto L_82A25D;
    case 0x82A25Eu: goto L_82A25E;
    case 0x82A260u: goto L_82A260;
    case 0x82A263u: goto L_82A263;
    case 0x82A265u: goto L_82A265;
    case 0x82A267u: goto L_82A267;
    case 0x82A269u: goto L_82A269;
    case 0x82A26Cu: goto L_82A26C;
    case 0x82A26Eu: goto L_82A26E;
    case 0x82A271u: goto L_82A271;
    case 0x82A274u: goto L_82A274;
    case 0x82A276u: goto L_82A276;
    case 0x82A279u: goto L_82A279;
    case 0x82A27Cu: goto L_82A27C;
    case 0x82A27Fu: goto L_82A27F;
    case 0x82A282u: goto L_82A282;
    case 0x82A284u: goto L_82A284;
    case 0x82A286u: goto L_82A286;
    case 0x82A287u: goto L_82A287;
    case 0x82A28Au: goto L_82A28A;
    case 0x82A28Du: goto L_82A28D;
    case 0x82A290u: goto L_82A290;
    case 0x82A293u: goto L_82A293;
    case 0x82A296u: goto L_82A296;
    case 0x82A297u: goto L_82A297;
    case 0x82A298u: goto L_82A298;
    case 0x82A299u: goto L_82A299;
    case 0x82A29Au: goto L_82A29A;
    case 0x82A29Bu: goto L_82A29B;
    case 0x82A29Cu: goto L_82A29C;
    case 0x82A29Eu: goto L_82A29E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82A22B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA22Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA22Bu,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA22Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A22B PHX
    cpu.push("PHX", hw);
    goto L_82A22C;
L_82A22C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA22Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA22Cu,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA22Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A22C PHY
    cpu.push("PHY", hw);
    goto L_82A22D;
L_82A22D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA22Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA22Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA22Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A22D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A22F;
L_82A22F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA22Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA22Fu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA22Fu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A22F PHA
    cpu.push("PHA", hw);
    goto L_82A230;
L_82A230:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA230u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA230u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA230u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A230 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A232;
L_82A232:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA232u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA232u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA232u, 6u, 3u, cpu.address("absx", 0x02A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A232 STA
    hw.write(cpu.address("absx", 0x2A6u), cpu.a, cpu.m8?8:16);
    goto L_82A235;
L_82A235:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA235u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA235u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA235u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A235 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x5Bu), cpu.m8?8:16));
    goto L_82A237;
L_82A237:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA237u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA237u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA237u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A237 TAX
    cpu.transfer("TAX");
    goto L_82A238;
L_82A238:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA238u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA238u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA238u, 5u + 1u, 3u, cpu.address("absx", 0x0296u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A238 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x296u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A23B;
L_82A23B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA23Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA23Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA23Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A23B AND
    cpu.logicAnd(0xFFu);
    goto L_82A23E;
L_82A23E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA23Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA23Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA23Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A23E STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_82A240;
L_82A240:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA240u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA240u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA240u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A240 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A242;
L_82A242:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA242u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA242u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA242u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A242 STZ
    hw.write(cpu.address("dp", 0xAu), 0, cpu.m8?8:16);
    goto L_82A244;
L_82A244:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA244u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA244u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA244u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A244 SEP
    cpu.sep(0x20u);
    goto L_82A246;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA244u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA244u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A244 SEP
    cpu.sep(0x20u);
    goto L_82A246;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA244u,0x82A244u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82A246:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA246u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA246u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA246u, 4u + 1u, 3u, cpu.address("absx", 0x0208u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A246 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x208u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A249;
L_82A249:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA249u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA249u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA249u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A249 BPL -> $82A257
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82A257; }
    goto L_82A24B;
L_82A24B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA24Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA24Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA24Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A24B CMP
    cpu.compareA(0x80u);
    goto L_82A24D;
L_82A24D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA24Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA24Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA24Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A24D BNE -> $82A296
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A296; }
    goto L_82A24F;
L_82A24F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA24Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA24Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA24Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A24F REP
    cpu.rep(0x20u);
    goto L_82A251;
L_82A251:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA251u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA251u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA251u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A251 PLA
    cpu.pop("PLA", hw);
    goto L_82A252;
L_82A252:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA252u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA252u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA252u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A252 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_82A254;
L_82A254:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA254u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA254u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA254u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A254 PLY
    cpu.pop("PLY", hw);
    goto L_82A255;
L_82A255:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA255u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA255u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA255u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A255 PLX
    cpu.pop("PLX", hw);
    goto L_82A256;
L_82A256:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA256u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA256u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA256u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A256 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82A256u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82A256u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82A257:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA257u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA257u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA257u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A257 REP
    cpu.rep(0x20u);
    goto L_82A259;
L_82A259:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA259u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA259u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA259u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A259 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A25B;
L_82A25B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA25Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA25Bu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA25Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A25B ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x5Bu), cpu.m8?8:16));
    goto L_82A25D;
L_82A25D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA25Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA25Du,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA25Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A25D TAY
    cpu.transfer("TAY");
    goto L_82A25E;
L_82A25E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA25Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA25Eu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA25Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A25E SEP
    cpu.sep(0x20u);
    goto L_82A260;
L_82A260:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA260u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA260u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA260u, 4u + 1u, 3u, cpu.address("absy", 0x0296u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A260 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x296u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A263;
L_82A263:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA263u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA263u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA263u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A263 BMI -> $82A296
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82A296; }
    goto L_82A265;
L_82A265:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA265u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA265u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA265u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A265 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16));
    goto L_82A267;
L_82A267:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA267u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA267u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA267u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A267 BNE -> $82A296
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A296; }
    goto L_82A269;
L_82A269:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA269u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA269u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA269u, 6u, 3u, cpu.address("abs", 0xA0E6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A269 JSR -> $82A0E6 stack real
    { cpu.push16Value(hw,0xA26Bu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA26Cu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA0E6u), 0x82A269u); }
    goto L_82A26C;
L_82A26C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA26Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA26Cu,0x82A26Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA26Cu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA26Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A26C LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xEu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A26E;
L_82A26E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA26Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA26Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA26Eu, 5u + 1u, 3u, cpu.address("absx", 0x020Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A26E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x20Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A271;
L_82A271:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA271u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA271u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA271u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A271 AND
    cpu.logicAnd(0x30Fu);
    goto L_82A274;
L_82A274:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA274u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA274u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA274u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 3u, 0u);
    // $82A274 STA
    hw.write(cpu.addressDpLongY(hw, 0x67u), cpu.a, cpu.m8?8:16);
    goto L_82A276;
L_82A276:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA276u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA276u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA276u, 5u + 1u, 3u, cpu.address("absx", 0x0208u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A276 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x208u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A279;
L_82A279:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA279u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA279u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA279u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A279 ORA
    cpu.logicOr(0xFFu);
    goto L_82A27C;
L_82A27C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA27Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA27Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA27Cu, 6u, 3u, cpu.address("absx", 0x0208u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A27C STA
    hw.write(cpu.address("absx", 0x208u), cpu.a, cpu.m8?8:16);
    goto L_82A27F;
L_82A27F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA27Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA27Fu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA27Fu, 6u, 3u, cpu.address("absx", 0x0224u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A27F STA
    hw.write(cpu.address("absx", 0x224u), cpu.a, cpu.m8?8:16);
    goto L_82A282;
L_82A282:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA282u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA282u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA282u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A282 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A284;
L_82A284:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA284u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA284u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA284u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A284 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x5Bu), cpu.m8?8:16));
    goto L_82A286;
L_82A286:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA286u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA286u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA286u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A286 TAY
    cpu.transfer("TAY");
    goto L_82A287;
L_82A287:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA287u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA287u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA287u, 5u + 1u, 3u, cpu.address("absy", 0x0296u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A287 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x296u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A28A;
L_82A28A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA28Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA28Au,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA28Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A28A ORA
    cpu.logicOr(0xFFu);
    goto L_82A28D;
L_82A28D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA28Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA28Du,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA28Du, 6u, 3u, cpu.address("absy", 0x0296u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A28D STA
    hw.write(cpu.address("absy", 0x296u), cpu.a, cpu.m8?8:16);
    goto L_82A290;
L_82A290:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA290u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA290u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA290u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A290 LDA
    cpu.setA(0x8000u, 16);
    goto L_82A293;
L_82A293:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA293u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA293u,cpu,0x0Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA293u, 8u, 3u, cpu.address("abs", 0x014Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A293 TSB
    cpu.tsb(hw, cpu.address("abs", 0x14Au), cpu.m8?8:16);
    goto L_82A296;
L_82A296:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA296u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA296u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA296u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A296 INX
    cpu.inc('X');
    goto L_82A297;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA296u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA296u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A296 INX
    cpu.inc('X');
    goto L_82A297;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA296u,0x82A296u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82A297:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA297u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA297u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA297u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A297 INX
    cpu.inc('X');
    goto L_82A298;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA297u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA297u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A297 INX
    cpu.inc('X');
    goto L_82A298;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA297u,0x82A297u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82A298:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA298u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA298u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA298u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A298 INX
    cpu.inc('X');
    goto L_82A299;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA298u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA298u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A298 INX
    cpu.inc('X');
    goto L_82A299;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA298u,0x82A298u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82A299:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA299u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA299u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA299u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A299 INX
    cpu.inc('X');
    goto L_82A29A;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA299u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA299u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A299 INX
    cpu.inc('X');
    goto L_82A29A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA299u,0x82A299u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82A29A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA29Au))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA29Au,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA29Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A29A INX
    cpu.inc('X');
    goto L_82A29B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA29Au,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA29Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A29A INX
    cpu.inc('X');
    goto L_82A29B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA29Au,0x82A29Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82A29B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA29Bu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA29Bu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA29Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A29B INX
    cpu.inc('X');
    goto L_82A29C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA29Bu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA29Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A29B INX
    cpu.inc('X');
    goto L_82A29C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA29Bu,0x82A29Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82A29C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA29Cu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA29Cu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA29Cu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A29C INC
    cpu.incMem(hw, cpu.address("dp", 0xAu), cpu.m8?8:16);
    goto L_82A29E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA29Cu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA29Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A29C INC
    cpu.incMem(hw, cpu.address("dp", 0xAu), cpu.m8?8:16);
    goto L_82A29E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA29Cu,0x82A29Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82A29E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA29Eu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA29Eu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA29Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A29E BRA -> $82A244
    goto L_82A244;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA29Eu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA29Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A29E BRA -> $82A244
    goto L_82A244;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA29Eu,0x82A29Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_82A3A1_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82A3A1u: goto L_82A3A1;
    case 0x82A3A2u: goto L_82A3A2;
    case 0x82A3A4u: goto L_82A3A4;
    case 0x82A3A6u: goto L_82A3A6;
    case 0x82A3A7u: goto L_82A3A7;
    case 0x82A3A8u: goto L_82A3A8;
    case 0x82A3AAu: goto L_82A3AA;
    case 0x82A3ACu: goto L_82A3AC;
    case 0x82A3ADu: goto L_82A3AD;
    case 0x82A3B0u: goto L_82A3B0;
    case 0x82A3B2u: goto L_82A3B2;
    case 0x82A3B5u: goto L_82A3B5;
    case 0x82A3B7u: goto L_82A3B7;
    case 0x82A3B9u: goto L_82A3B9;
    case 0x82A3BCu: goto L_82A3BC;
    case 0x82A3BEu: goto L_82A3BE;
    case 0x82A3C0u: goto L_82A3C0;
    case 0x82A3C2u: goto L_82A3C2;
    case 0x82A3C5u: goto L_82A3C5;
    case 0x82A3C7u: goto L_82A3C7;
    case 0x82A3C8u: goto L_82A3C8;
    case 0x82A3C9u: goto L_82A3C9;
    case 0x82A3CBu: goto L_82A3CB;
    case 0x82A3CCu: goto L_82A3CC;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82A3A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A1u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A1u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82A3A1 PHB
    cpu.push("PHB", hw);
    goto L_82A3A2;
L_82A3A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A2u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A3A2 SEP
    cpu.sep(0x20u);
    goto L_82A3A4;
L_82A3A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x69u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A3A4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x69u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A3A6;
L_82A3A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A6u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A6u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82A3A6 PHA
    cpu.push("PHA", hw);
    goto L_82A3A7;
L_82A3A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A7u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A7u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82A3A7 PLB
    cpu.pop("PLB", hw);
    goto L_82A3A8;
L_82A3A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A8u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A3A8 REP
    cpu.rep(0x20u);
    goto L_82A3AA;
L_82A3AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3AAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3AAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x67u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A3AA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A3AC;
L_82A3AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3ACu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3ACu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A3AC CLC
    cpu.setFlag('C', false);
    goto L_82A3AD;
L_82A3AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3ADu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3ADu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A3AD ADC
    cpu.adc(0x16u);
    goto L_82A3B0;
L_82A3B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A3B0 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82A3B2;
L_82A3B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B2u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A3B2 LDY
    cpu.setY(0x1F8u, 16);
    goto L_82A3B5;
L_82A3B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B5u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B5u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82A3B5 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A3B7;
L_82A3B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B7u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A3B7 BPL -> $82A3C7
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82A3C7; }
    goto L_82A3B9;
L_82A3B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B9u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A3B9 CMP
    cpu.compareA(0xFFFFu);
    goto L_82A3BC;
L_82A3BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3BCu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3BCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A3BC BEQ -> $82A3C7
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A3C7; }
    goto L_82A3BE;
L_82A3BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3BEu,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3BEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A3BE STY
    hw.write(cpu.address("dp", 0x63u), cpu.y, cpu.x8?8:16);
    goto L_82A3C0;
L_82A3C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A3C0 STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_82A3C2;
L_82A3C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C2u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C2u, 6u, 3u, cpu.address("abs", 0xA3CDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A3C2 JSR -> $82A3CD stack real
    { cpu.push16Value(hw,0xA3C4u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA3C5u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA3CDu), 0x82A3C2u); }
    goto L_82A3C5;
L_82A3C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3C5u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA3C5u,0x82A3C5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C5u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A3C5 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A3C7;
L_82A3C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C7u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A3C7 DEY
    cpu.decReg('Y');
    goto L_82A3C8;
L_82A3C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C8u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A3C8 DEY
    cpu.decReg('Y');
    goto L_82A3C9;
L_82A3C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C9u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A3C9 BNE -> $82A3B5
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A3B5; }
    goto L_82A3CB;
L_82A3CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3CBu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3CBu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82A3CB PLB
    cpu.pop("PLB", hw);
    goto L_82A3CC;
L_82A3CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3CCu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3CCu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A3CC RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82A3CCu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82A3CCu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82B32C_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B32Cu: goto L_82B32C;
    case 0x82B32Eu: goto L_82B32E;
    case 0x82B330u: goto L_82B330;
    case 0x82B333u: goto L_82B333;
    case 0x82B334u: goto L_82B334;
    case 0x82B337u: goto L_82B337;
    case 0x82B339u: goto L_82B339;
    case 0x82B33Au: goto L_82B33A;
    case 0x82B33Cu: goto L_82B33C;
    case 0x82B33Fu: goto L_82B33F;
    case 0x82B342u: goto L_82B342;
    case 0x82B344u: goto L_82B344;
    case 0x82B347u: goto L_82B347;
    case 0x82B349u: goto L_82B349;
    case 0x82B34Bu: goto L_82B34B;
    case 0x82B34Du: goto L_82B34D;
    case 0x82B34Eu: goto L_82B34E;
    case 0x82B34Fu: goto L_82B34F;
    case 0x82B350u: goto L_82B350;
    case 0x82B351u: goto L_82B351;
    case 0x82B352u: goto L_82B352;
    case 0x82B353u: goto L_82B353;
    case 0x82B354u: goto L_82B354;
    case 0x82B355u: goto L_82B355;
    case 0x82B356u: goto L_82B356;
    case 0x82B359u: goto L_82B359;
    case 0x82B35Cu: goto L_82B35C;
    case 0x82B35Fu: goto L_82B35F;
    case 0x82B361u: goto L_82B361;
    case 0x82B363u: goto L_82B363;
    case 0x82B365u: goto L_82B365;
    case 0x82B367u: goto L_82B367;
    case 0x82B369u: goto L_82B369;
    case 0x82B36Cu: goto L_82B36C;
    case 0x82B36Eu: goto L_82B36E;
    case 0x82B371u: goto L_82B371;
    case 0x82B373u: goto L_82B373;
    case 0x82B375u: goto L_82B375;
    case 0x82B376u: goto L_82B376;
    case 0x82B377u: goto L_82B377;
    case 0x82B378u: goto L_82B378;
    case 0x82B379u: goto L_82B379;
    case 0x82B37Au: goto L_82B37A;
    case 0x82B37Bu: goto L_82B37B;
    case 0x82B37Cu: goto L_82B37C;
    case 0x82B37Du: goto L_82B37D;
    case 0x82B380u: goto L_82B380;
    case 0x82B382u: goto L_82B382;
    case 0x82B384u: goto L_82B384;
    case 0x82B387u: goto L_82B387;
    case 0x82B38Au: goto L_82B38A;
    case 0x82B38Du: goto L_82B38D;
    case 0x82B390u: goto L_82B390;
    case 0x82B393u: goto L_82B393;
    case 0x82B395u: goto L_82B395;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B32C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB32Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB32Cu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB32Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B32C LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B32E;
L_82B32E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB32Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB32Eu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB32Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B32E LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B330;
L_82B330:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB330u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB330u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB330u, 5u + 1u, 3u, cpu.address("absx", 0x02A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B330 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x2A6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B333;
L_82B333:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB333u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB333u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB333u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B333 ASL
    cpu.aslA();
    goto L_82B334;
L_82B334:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB334u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB334u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB334u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B334 AND
    cpu.logicAnd(0xFFu);
    goto L_82B337;
L_82B337:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB337u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB337u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB337u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B337 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x5Bu), cpu.m8?8:16));
    goto L_82B339;
L_82B339:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB339u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB339u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB339u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B339 TAX
    cpu.transfer("TAX");
    goto L_82B33A;
L_82B33A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB33Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB33Au,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB33Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B33A SEP
    cpu.sep(0x20u);
    goto L_82B33C;
L_82B33C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB33Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB33Cu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB33Cu, 4u + 1u, 3u, cpu.address("absx", 0x0276u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B33C LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x276u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B33F;
L_82B33F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB33Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB33Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB33Fu, 4u, 3u, cpu.address("abs", 0x0147u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B33F STA
    hw.write(cpu.address("abs", 0x147u), cpu.a, cpu.m8?8:16);
    goto L_82B342;
L_82B342:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB342u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB342u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB342u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B342 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B344;
L_82B344:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB344u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB344u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB344u, 4u + 1u, 3u, cpu.address("absy", 0x0208u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B344 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x208u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B347;
L_82B347:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB347u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB347u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB347u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B347 BEQ -> $82B359
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B359; }
    goto L_82B349;
L_82B349:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB349u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB349u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB349u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B349 CMP
    cpu.compareA(0x80u);
    goto L_82B34B;
L_82B34B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB34Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B34B BNE -> $82B34E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B34E; }
    goto L_82B34D;
L_82B34D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB34Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B34D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B34Du);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B34Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82B34E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB34Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Eu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B34E INY
    cpu.inc('Y');
    goto L_82B34F;
L_82B34F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB34Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Fu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B34F INY
    cpu.inc('Y');
    goto L_82B350;
L_82B350:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB350u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB350u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB350u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B350 INY
    cpu.inc('Y');
    goto L_82B351;
L_82B351:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB351u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB351u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB351u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B351 INY
    cpu.inc('Y');
    goto L_82B352;
L_82B352:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB352u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB352u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB352u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B352 INY
    cpu.inc('Y');
    goto L_82B353;
L_82B353:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB353u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB353u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB353u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B353 INY
    cpu.inc('Y');
    goto L_82B354;
L_82B354:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB354u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB354u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB354u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B354 INX
    cpu.inc('X');
    goto L_82B355;
L_82B355:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB355u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB355u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB355u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B355 INX
    cpu.inc('X');
    goto L_82B356;
L_82B356:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB356u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB356u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB356u, 3u, 3u, cpu.address("abs", 0xB344u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B356 JMP -> $82B344
    goto L_82B344;
L_82B359:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB359u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB359u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB359u, 4u, 3u, cpu.address("abs", 0x0147u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B359 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x147u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B35C;
L_82B35C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB35Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB35Cu,cpu,0xDDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB35Cu, 4u + 1u, 3u, cpu.address("absx", 0x0276u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B35C CMP
    cpu.compareA(hw.readW(cpu.address("absx", 0x276u), cpu.m8?8:16));
    goto L_82B35F;
L_82B35F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB35Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB35Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB35Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B35F BNE -> $82B34E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B34E; }
    goto L_82B361;
L_82B361:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB361u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB361u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB361u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B361 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B363;
L_82B363:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB363u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB363u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB363u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B363 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B365;
L_82B365:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB365u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB365u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB365u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B365 LDA
    cpu.setA(0x0u, 8);
    goto L_82B367;
L_82B367:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB367u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB367u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB367u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B367 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82B369;
L_82B369:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB369u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB369u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB369u, 4u + 1u, 3u, cpu.address("absy", 0x0208u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B369 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x208u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B36C;
L_82B36C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB36Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB36Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB36Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B36C BEQ -> $82B380
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B380; }
    goto L_82B36E;
L_82B36E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB36Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB36Eu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB36Eu, 4u + 1u, 3u, cpu.address("absy", 0x0208u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B36E LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x208u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B371;
L_82B371:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB371u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB371u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB371u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B371 CMP
    cpu.compareA(0x80u);
    goto L_82B373;
L_82B373:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB373u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB373u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB373u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B373 BEQ -> $82B393
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B393; }
    goto L_82B375;
L_82B375:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB375u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB375u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB375u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B375 INY
    cpu.inc('Y');
    goto L_82B376;
L_82B376:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB376u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB376u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB376u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B376 INY
    cpu.inc('Y');
    goto L_82B377;
L_82B377:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB377u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB377u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB377u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B377 INY
    cpu.inc('Y');
    goto L_82B378;
L_82B378:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB378u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB378u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB378u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B378 INY
    cpu.inc('Y');
    goto L_82B379;
L_82B379:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB379u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB379u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB379u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B379 INY
    cpu.inc('Y');
    goto L_82B37A;
L_82B37A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB37Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB37Au,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB37Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B37A INY
    cpu.inc('Y');
    goto L_82B37B;
L_82B37B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB37Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB37Bu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB37Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B37B INX
    cpu.inc('X');
    goto L_82B37C;
L_82B37C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB37Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB37Cu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB37Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B37C INX
    cpu.inc('X');
    goto L_82B37D;
L_82B37D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB37Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB37Du,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB37Du, 3u, 3u, cpu.address("abs", 0xB369u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B37D JMP -> $82B369
    goto L_82B369;
L_82B380:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB380u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB380u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB380u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B380 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B382;
L_82B382:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB382u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB382u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB382u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B382 BNE -> $82B38A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B38A; }
    goto L_82B384;
L_82B384:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB384u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB384u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB384u, 6u, 3u, cpu.address("abs", 0xB508u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B384 JSR -> $82B508 stack real
    { cpu.push16Value(hw,0xB386u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB387u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB508u), 0x82B384u); }
    goto L_82B387;
L_82B387:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB387u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB387u,0x82B387u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB387u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB387u, 3u, 3u, cpu.address("abs", 0xB36Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B387 JMP -> $82B36E
    goto L_82B36E;
L_82B38A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB38Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB38Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB38Au, 6u, 3u, cpu.address("abs", 0xB525u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B38A JSR -> $82B525 stack real
    { cpu.push16Value(hw,0xB38Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB38Du,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB525u), 0x82B38Au); }
    goto L_82B38D;
L_82B38D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB38Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB38Du,0x82B38Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB38Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB38Du, 6u, 3u, cpu.address("abs", 0xB544u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B38D JSR -> $82B544 stack real
    { cpu.push16Value(hw,0xB38Fu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB390u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB544u), 0x82B38Du); }
    goto L_82B390;
L_82B390:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB390u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB390u,0x82B390u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB390u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB390u, 6u, 3u, cpu.address("abs", 0xB4F0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B390 JSR -> $82B4F0 stack real
    { cpu.push16Value(hw,0xB392u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB393u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB4F0u), 0x82B390u); }
    goto L_82B393;
L_82B393:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB393u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB393u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB393u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B393 REP
    cpu.rep(0x20u);
    goto L_82B395;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB393u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB393u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B393 REP
    cpu.rep(0x20u);
    goto L_82B395;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB393u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB393u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B393 REP
    cpu.rep(0x20u);
    goto L_82B395;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB393u,0x82B393u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B395:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB395u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB395u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB395u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B395 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B395u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B395u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB395u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB395u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B395 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B395u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B395u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB395u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB395u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B395 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B395u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B395u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB395u,0x82B395u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_82B525_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B525u: goto L_82B525;
    case 0x82B527u: goto L_82B527;
    case 0x82B529u: goto L_82B529;
    case 0x82B52Bu: goto L_82B52B;
    case 0x82B52Du: goto L_82B52D;
    case 0x82B52Fu: goto L_82B52F;
    case 0x82B532u: goto L_82B532;
    case 0x82B534u: goto L_82B534;
    case 0x82B535u: goto L_82B535;
    case 0x82B538u: goto L_82B538;
    case 0x82B539u: goto L_82B539;
    case 0x82B53Bu: goto L_82B53B;
    case 0x82B53Du: goto L_82B53D;
    case 0x82B53Fu: goto L_82B53F;
    case 0x82B541u: goto L_82B541;
    case 0x82B543u: goto L_82B543;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B525:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB525u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB525u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB525u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B525 LDA
    cpu.setA(0x0u, 8);
    goto L_82B527;
L_82B527:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB527u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB527u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB527u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B527 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_82B529;
L_82B529:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB529u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB529u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB529u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B529 STA
    hw.write(cpu.address("dp", 0x5u), cpu.a, cpu.m8?8:16);
    goto L_82B52B;
L_82B52B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB52Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB52Bu,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB52Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B52B STX
    hw.write(cpu.address("dp", 0x14u), cpu.x, cpu.x8?8:16);
    goto L_82B52D;
L_82B52D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB52Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB52Du,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB52Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B52D STY
    hw.write(cpu.address("dp", 0x16u), cpu.y, cpu.x8?8:16);
    goto L_82B52F;
L_82B52F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB52Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB52Fu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB52Fu, 4u + 1u, 3u, cpu.address("absy", 0x020Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B52F LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x20Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B532;
L_82B532:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB532u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB532u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB532u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B532 STA
    hw.write(cpu.address("dp", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_82B534;
L_82B534:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB534u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB534u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB534u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B534 CLC
    cpu.setFlag('C', false);
    goto L_82B535;
L_82B535:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB535u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB535u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB535u, 4u + 1u, 3u, cpu.address("absx", 0x0276u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B535 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x276u), cpu.m8?8:16));
    goto L_82B538;
L_82B538:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB538u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB538u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB538u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B538 CLC
    cpu.setFlag('C', false);
    goto L_82B539;
L_82B539:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB539u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB539u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB539u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B539 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16));
    goto L_82B53B;
L_82B53B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB53Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB53Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB53Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B53B STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_82B53D;
L_82B53D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB53Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB53Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB53Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B53D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B53F;
L_82B53F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB53Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB53Fu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB53Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B53F ADC
    cpu.adc(0x0u);
    goto L_82B541;
L_82B541:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB541u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB541u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB541u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B541 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_82B543;
L_82B543:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB543u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB543u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB543u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B543 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B543u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B543u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82B980_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B980u: goto L_82B980;
    case 0x82B983u: goto L_82B983;
    case 0x82B985u: goto L_82B985;
    case 0x82B988u: goto L_82B988;
    case 0x82B98Au: goto L_82B98A;
    case 0x82B98Du: goto L_82B98D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B980:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB980u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB980u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB980u, 6u, 3u, cpu.address("abs", 0xB98Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B980 JSR -> $82B98E stack real
    { cpu.push16Value(hw,0xB982u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB983u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB98Eu), 0x82B980u); }
    goto L_82B983;
L_82B983:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB983u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB983u,0x82B983u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB983u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB983u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B983 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x61u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B985;
L_82B985:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB985u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB985u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB985u, 6u, 3u, cpu.address("abs", 0xB9B0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B985 JSR -> $82B9B0 stack real
    { cpu.push16Value(hw,0xB987u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB988u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB9B0u), 0x82B985u); }
    goto L_82B988;
L_82B988:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB988u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB988u,0x82B988u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB988u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB988u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B988 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x61u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B98A;
L_82B98A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB98Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB98Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB98Au, 6u, 3u, cpu.address("abs", 0xB998u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B98A JSR -> $82B998 stack real
    { cpu.push16Value(hw,0xB98Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB98Du,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB998u), 0x82B98Au); }
    goto L_82B98D;
L_82B98D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB98Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB98Du,0x82B98Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB98Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB98Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B98D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B98Du);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B98Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82E02E_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82E02Eu: goto L_82E02E;
    case 0x82E030u: goto L_82E030;
    case 0x82E031u: goto L_82E031;
    case 0x82E033u: goto L_82E033;
    case 0x82E034u: goto L_82E034;
    case 0x82E035u: goto L_82E035;
    case 0x82E037u: goto L_82E037;
    case 0x82E03Au: goto L_82E03A;
    case 0x82E03Cu: goto L_82E03C;
    case 0x82E03Eu: goto L_82E03E;
    case 0x82E041u: goto L_82E041;
    case 0x82E043u: goto L_82E043;
    case 0x82E046u: goto L_82E046;
    case 0x82E048u: goto L_82E048;
    case 0x82E049u: goto L_82E049;
    case 0x82E04Au: goto L_82E04A;
    case 0x82E04Cu: goto L_82E04C;
    case 0x82E04Du: goto L_82E04D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82E02E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE02Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE02Eu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE02Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E02E SEP
    cpu.sep(0x20u);
    goto L_82E030;
L_82E030:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE030u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE030u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE030u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82E030 PHB
    cpu.push("PHB", hw);
    goto L_82E031;
L_82E031:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE031u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE031u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE031u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x69u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E031 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x69u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E033;
L_82E033:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE033u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE033u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE033u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82E033 PHA
    cpu.push("PHA", hw);
    goto L_82E034;
L_82E034:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE034u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE034u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE034u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82E034 PLB
    cpu.pop("PLB", hw);
    goto L_82E035;
L_82E035:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE035u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE035u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE035u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E035 REP
    cpu.rep(0x20u);
    goto L_82E037;
L_82E037:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE037u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE037u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE037u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E037 LDY
    cpu.setY(0x1F8u, 16);
    goto L_82E03A;
L_82E03A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE03Au))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE03Au,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE03Au, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82E03A LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E03C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE03Au,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE03Au, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82E03A LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E03C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE03Au,0x82E03Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E03C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE03Cu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE03Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE03Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E03C BEQ -> $82E048
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E048; }
    goto L_82E03E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE03Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE03Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E03C BEQ -> $82E048
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E048; }
    goto L_82E03E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE03Cu,0x82E03Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E03E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE03Eu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE03Eu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE03Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E03E CMP
    cpu.compareA(0xFFFFu);
    goto L_82E041;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE03Eu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE03Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E03E CMP
    cpu.compareA(0xFFFFu);
    goto L_82E041;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE03Eu,0x82E03Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E041:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE041u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE041u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE041u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E041 BEQ -> $82E048
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E048; }
    goto L_82E043;
L_82E043:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE043u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE043u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE043u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E043 AND
    cpu.logicAnd(0x3FFFu);
    goto L_82E046;
L_82E046:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE046u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE046u,cpu,0x91u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE046u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82E046 STA
    hw.write(cpu.addressDpIndirectY(hw, 0x67u), cpu.a, cpu.m8?8:16);
    goto L_82E048;
L_82E048:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE048u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE048u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE048u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E048 DEY
    cpu.decReg('Y');
    goto L_82E049;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE048u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE048u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E048 DEY
    cpu.decReg('Y');
    goto L_82E049;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE048u,0x82E048u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E049:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE049u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE049u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE049u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E049 DEY
    cpu.decReg('Y');
    goto L_82E04A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE049u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE049u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E049 DEY
    cpu.decReg('Y');
    goto L_82E04A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE049u,0x82E049u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E04A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE04Au))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE04Au,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE04Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E04A BPL -> $82E03A
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82E03A; }
    goto L_82E04C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE04Au,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE04Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E04A BPL -> $82E03A
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82E03A; }
    goto L_82E04C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE04Au,0x82E04Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E04C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE04Cu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE04Cu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE04Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82E04C PLB
    cpu.pop("PLB", hw);
    goto L_82E04D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE04Cu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE04Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82E04C PLB
    cpu.pop("PLB", hw);
    goto L_82E04D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE04Cu,0x82E04Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E04D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE04Du))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE04Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE04Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82E04D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82E04Du);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82E04Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE04Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE04Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82E04D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82E04Du);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82E04Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE04Du,0x82E04Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_82E02E_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82E02Eu: goto L_82E02E;
    case 0x82E030u: goto L_82E030;
    case 0x82E031u: goto L_82E031;
    case 0x82E033u: goto L_82E033;
    case 0x82E034u: goto L_82E034;
    case 0x82E035u: goto L_82E035;
    case 0x82E037u: goto L_82E037;
    case 0x82E03Au: goto L_82E03A;
    case 0x82E03Cu: goto L_82E03C;
    case 0x82E03Eu: goto L_82E03E;
    case 0x82E041u: goto L_82E041;
    case 0x82E043u: goto L_82E043;
    case 0x82E046u: goto L_82E046;
    case 0x82E048u: goto L_82E048;
    case 0x82E049u: goto L_82E049;
    case 0x82E04Au: goto L_82E04A;
    case 0x82E04Cu: goto L_82E04C;
    case 0x82E04Du: goto L_82E04D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82E02E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE02Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE02Eu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE02Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E02E SEP
    cpu.sep(0x20u);
    goto L_82E030;
L_82E030:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE030u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE030u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE030u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82E030 PHB
    cpu.push("PHB", hw);
    goto L_82E031;
L_82E031:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE031u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE031u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE031u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x69u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E031 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x69u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E033;
L_82E033:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE033u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE033u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE033u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82E033 PHA
    cpu.push("PHA", hw);
    goto L_82E034;
L_82E034:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE034u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE034u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE034u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82E034 PLB
    cpu.pop("PLB", hw);
    goto L_82E035;
L_82E035:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE035u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE035u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE035u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E035 REP
    cpu.rep(0x20u);
    goto L_82E037;
L_82E037:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE037u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE037u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE037u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E037 LDY
    cpu.setY(0x1F8u, 16);
    goto L_82E03A;
L_82E03A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE03Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE03Au,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE03Au, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82E03A LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E03C;
L_82E03C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE03Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE03Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE03Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E03C BEQ -> $82E048
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E048; }
    goto L_82E03E;
L_82E03E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE03Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE03Eu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE03Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E03E CMP
    cpu.compareA(0xFFFFu);
    goto L_82E041;
L_82E041:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE041u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE041u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE041u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E041 BEQ -> $82E048
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E048; }
    goto L_82E043;
L_82E043:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE043u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE043u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE043u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E043 AND
    cpu.logicAnd(0x3FFFu);
    goto L_82E046;
L_82E046:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE046u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE046u,cpu,0x91u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE046u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82E046 STA
    hw.write(cpu.addressDpIndirectY(hw, 0x67u), cpu.a, cpu.m8?8:16);
    goto L_82E048;
L_82E048:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE048u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE048u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE048u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E048 DEY
    cpu.decReg('Y');
    goto L_82E049;
L_82E049:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE049u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE049u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE049u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E049 DEY
    cpu.decReg('Y');
    goto L_82E04A;
L_82E04A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE04Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE04Au,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE04Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E04A BPL -> $82E03A
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82E03A; }
    goto L_82E04C;
L_82E04C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE04Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE04Cu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE04Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82E04C PLB
    cpu.pop("PLB", hw);
    goto L_82E04D;
L_82E04D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE04Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE04Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE04Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82E04D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82E04Du);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82E04Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_8480E2_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8480E2u: goto L_8480E2;
    case 0x8480E3u: goto L_8480E3;
    case 0x8480E5u: goto L_8480E5;
    case 0x8480E6u: goto L_8480E6;
    case 0x8480E8u: goto L_8480E8;
    case 0x8480E9u: goto L_8480E9;
    case 0x8480EAu: goto L_8480EA;
    case 0x8480EBu: goto L_8480EB;
    case 0x8480EDu: goto L_8480ED;
    case 0x8480EFu: goto L_8480EF;
    case 0x8480F1u: goto L_8480F1;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8480E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E2u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8480E2 ASL
    cpu.aslA();
    goto L_8480E3;
L_8480E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8480E3 STA
    hw.write(cpu.address("dp", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_8480E5;
L_8480E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E5u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8480E5 ASL
    cpu.aslA();
    goto L_8480E6;
L_8480E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x38u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8480E6 STA
    hw.write(cpu.address("dp", 0x38u), cpu.a, cpu.m8?8:16);
    goto L_8480E8;
L_8480E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E8u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8480E8 ASL
    cpu.aslA();
    goto L_8480E9;
L_8480E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E9u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8480E9 ASL
    cpu.aslA();
    goto L_8480EA;
L_8480EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80EAu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80EAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8480EA CLC
    cpu.setFlag('C', false);
    goto L_8480EB;
L_8480EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80EBu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80EBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8480EB ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x36u), cpu.m8?8:16));
    goto L_8480ED;
L_8480ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80EDu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80EDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x38u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8480ED ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x38u), cpu.m8?8:16));
    goto L_8480EF;
L_8480EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80EFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80EFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8480EF STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_8480F1;
L_8480F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8480F1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8480F1u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8480F1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_8481E2_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8481E2u: goto L_8481E2;
    case 0x8481E5u: goto L_8481E5;
    case 0x8481E8u: goto L_8481E8;
    case 0x8481EAu: goto L_8481EA;
    case 0x8481EDu: goto L_8481ED;
    case 0x8481F0u: goto L_8481F0;
    case 0x8481F2u: goto L_8481F2;
    case 0x8481F5u: goto L_8481F5;
    case 0x8481F7u: goto L_8481F7;
    case 0x8481FAu: goto L_8481FA;
    case 0x8481FDu: goto L_8481FD;
    case 0x8481FFu: goto L_8481FF;
    case 0x848202u: goto L_848202;
    case 0x848204u: goto L_848204;
    case 0x848207u: goto L_848207;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8481E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81E2u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81E2u, 5u, 3u, cpu.address("abs", 0x0606u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8481E2 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x606u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8481E5;
L_8481E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81E5u,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81E5u, 5u, 3u, cpu.address("abs", 0x0604u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8481E5 CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x604u), cpu.m8?8:16));
    goto L_8481E8;
L_8481E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81E8u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81E8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8481E8 BCC -> $8481F7
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_8481F7; }
    goto L_8481EA;
L_8481EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81EAu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81EAu, 5u, 3u, cpu.address("abs", 0x0608u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8481EA LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x608u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8481ED;
L_8481ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81EDu,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81EDu, 5u, 3u, cpu.address("abs", 0x0604u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8481ED CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x604u), cpu.m8?8:16));
    goto L_8481F0;
L_8481F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81F0u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81F0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8481F0 BCC -> $848204
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_848204; }
    goto L_8481F2;
L_8481F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81F2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81F2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8481F2 LDA
    cpu.setA(0x0u, 16);
    goto L_8481F5;
L_8481F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81F5u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81F5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8481F5 BRA -> $848207
    goto L_848207;
L_8481F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81F7u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81F7u, 5u, 3u, cpu.address("abs", 0x0608u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8481F7 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x608u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8481FA;
L_8481FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81FAu,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81FAu, 5u, 3u, cpu.address("abs", 0x0606u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8481FA CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x606u), cpu.m8?8:16));
    goto L_8481FD;
L_8481FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81FDu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81FDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8481FD BCC -> $848204
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_848204; }
    goto L_8481FF;
L_8481FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81FFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81FFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8481FF LDA
    cpu.setA(0x2u, 16);
    goto L_848202;
L_848202:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8202u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8202u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8202u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848202 BRA -> $848207
    goto L_848207;
L_848204:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8204u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8204u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8204u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848204 LDA
    cpu.setA(0x4u, 16);
    goto L_848207;
L_848207:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8207u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8207u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8207u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848207 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848207u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848207u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_848682_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848682u: goto L_848682;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848682:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8682u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8682u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8682u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848682 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848682u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848682u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_848682_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848682u: goto L_848682;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848682:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8682u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8682u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8682u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848682 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848682u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848682u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_848AF6_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848AF6u: goto L_848AF6;
    case 0x848AF8u: goto L_848AF8;
    case 0x848AFAu: goto L_848AFA;
    case 0x848AFDu: goto L_848AFD;
    case 0x848AFFu: goto L_848AFF;
    case 0x848B02u: goto L_848B02;
    case 0x848B04u: goto L_848B04;
    case 0x848B07u: goto L_848B07;
    case 0x848B09u: goto L_848B09;
    case 0x848B0Au: goto L_848B0A;
    case 0x848B0Cu: goto L_848B0C;
    case 0x848B0Eu: goto L_848B0E;
    case 0x848B11u: goto L_848B11;
    case 0x848B13u: goto L_848B13;
    case 0x848B15u: goto L_848B15;
    case 0x848B18u: goto L_848B18;
    case 0x848B1Au: goto L_848B1A;
    case 0x848B1Cu: goto L_848B1C;
    case 0x848B1Fu: goto L_848B1F;
    case 0x848B21u: goto L_848B21;
    case 0x848B24u: goto L_848B24;
    case 0x848B26u: goto L_848B26;
    case 0x848B28u: goto L_848B28;
    case 0x848B2Bu: goto L_848B2B;
    case 0x848B2Du: goto L_848B2D;
    case 0x848B30u: goto L_848B30;
    case 0x848B32u: goto L_848B32;
    case 0x848B35u: goto L_848B35;
    case 0x848B37u: goto L_848B37;
    case 0x848B39u: goto L_848B39;
    case 0x848B3Cu: goto L_848B3C;
    case 0x848B3Eu: goto L_848B3E;
    case 0x848B40u: goto L_848B40;
    case 0x848B42u: goto L_848B42;
    case 0x848B43u: goto L_848B43;
    case 0x848B45u: goto L_848B45;
    case 0x848B49u: goto L_848B49;
    case 0x848B4Bu: goto L_848B4B;
    case 0x848B4Cu: goto L_848B4C;
    case 0x848B4Eu: goto L_848B4E;
    case 0x848B52u: goto L_848B52;
    case 0x848B54u: goto L_848B54;
    case 0x848B56u: goto L_848B56;
    case 0x848B59u: goto L_848B59;
    case 0x848B5Du: goto L_848B5D;
    case 0x848B5Fu: goto L_848B5F;
    case 0x848B61u: goto L_848B61;
    case 0x848B62u: goto L_848B62;
    case 0x848B64u: goto L_848B64;
    case 0x848B68u: goto L_848B68;
    case 0x848B6Au: goto L_848B6A;
    case 0x848B6Bu: goto L_848B6B;
    case 0x848B6Du: goto L_848B6D;
    case 0x848B71u: goto L_848B71;
    case 0x848B73u: goto L_848B73;
    case 0x848B75u: goto L_848B75;
    case 0x848B78u: goto L_848B78;
    case 0x848B7Cu: goto L_848B7C;
    case 0x848B7Du: goto L_848B7D;
    case 0x848B7Fu: goto L_848B7F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848AF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AF6u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AF6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AF6 REP
    cpu.rep(0x20u);
    goto L_848AF8;
L_848AF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AF8u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AF8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AF8 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848AFA;
L_848AFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AFAu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AFAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AFA BIT
    cpu.bit(0x1080u, true);
    goto L_848AFD;
L_848AFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AFDu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AFDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AFD BNE -> $848B13
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_848B13; }
    goto L_848AFF;
L_848AFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AFFu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AFFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AFF BIT
    cpu.bit(0x2000u, true);
    goto L_848B02;
L_848B02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B02u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B02u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B02 BNE -> $848B0C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_848B0C; }
    goto L_848B04;
L_848B04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B04u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B04u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B04 BIT
    cpu.bit(0x8000u, true);
    goto L_848B07;
L_848B07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B07u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B07u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B07 BNE -> $848B0C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_848B0C; }
    goto L_848B09;
L_848B09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B09u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B09u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B09 CLC
    cpu.setFlag('C', false);
    goto L_848B0A;
L_848B0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B0Au,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B0Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B0A BRA -> $848B7D
    goto L_848B7D;
L_848B0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B0Cu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B0Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B0C SEP
    cpu.sep(0x20u);
    goto L_848B0E;
L_848B0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B0Eu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B0Eu, 6u, 3u, cpu.address("abs", 0x0657u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B0E INC
    cpu.incMem(hw, cpu.address("abs", 0x657u), cpu.m8?8:16);
    goto L_848B11;
L_848B11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B11u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B11u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B11 BRA -> $848B1C
    goto L_848B1C;
L_848B13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B13u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B13u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B13 SEP
    cpu.sep(0x20u);
    goto L_848B15;
L_848B15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B15u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B15u, 4u, 3u, cpu.address("abs", 0x0629u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B15 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x629u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848B18;
L_848B18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B18u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B18u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B18 CMP
    cpu.compareA(0x2u);
    goto L_848B1A;
L_848B1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B1Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B1Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B1A BEQ -> $848B7D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_848B7D; }
    goto L_848B1C;
L_848B1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B1Cu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B1Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B1Cu, 4u, 3u, cpu.address("abs", 0x062Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B1C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848B1F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B1Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B1Cu, 4u, 3u, cpu.address("abs", 0x062Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B1C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848B1F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B1Cu,0x848B1Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848B1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B1Fu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B1Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B1Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B1F BEQ -> $848B2D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_848B2D; }
    goto L_848B21;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B1Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B1Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B1F BEQ -> $848B2D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_848B2D; }
    goto L_848B21;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B1Fu,0x848B1Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848B21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B21u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B21u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B21u, 4u, 3u, cpu.address("abs", 0x0657u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B21 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x657u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848B24;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B21u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B21u, 4u, 3u, cpu.address("abs", 0x0657u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B21 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x657u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848B24;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B21u,0x848B21u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848B24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B24u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B24u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B24u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B24 BEQ -> $848B40
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_848B40; }
    goto L_848B26;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B24u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B24u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B24 BEQ -> $848B40
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_848B40; }
    goto L_848B26;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B24u,0x848B24u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848B26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B26u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B26u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B26u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B26 LDA
    cpu.setA(0x1u, 8);
    goto L_848B28;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B26u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B26u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B26 LDA
    cpu.setA(0x1u, 8);
    goto L_848B28;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B26u,0x848B26u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848B28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B28u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B28u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B28u, 4u, 3u, cpu.address("abs", 0x062Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B28 STA
    hw.write(cpu.address("abs", 0x62Au), cpu.a, cpu.m8?8:16);
    goto L_848B2B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B28u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B28u, 4u, 3u, cpu.address("abs", 0x062Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B28 STA
    hw.write(cpu.address("abs", 0x62Au), cpu.a, cpu.m8?8:16);
    goto L_848B2B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B28u,0x848B28u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848B2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B2Bu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B2Bu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B2Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B2B BRA -> $848B68
    goto L_848B68;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B2Bu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B2Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B2B BRA -> $848B68
    goto L_848B68;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B2Bu,0x848B2Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848B2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B2Du))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B2Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B2Du, 4u, 3u, cpu.address("abs", 0x0657u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B2D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x657u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848B30;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B2Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B2Du, 4u, 3u, cpu.address("abs", 0x0657u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B2D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x657u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848B30;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B2Du,0x848B2Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848B30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B30u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B30u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B30u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B30 BNE -> $848B5F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_848B5F; }
    goto L_848B32;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B30u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B30u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B30 BNE -> $848B5F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_848B5F; }
    goto L_848B32;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B30u,0x848B30u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848B32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B32u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B32u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B32u, 4u, 3u, cpu.address("abs", 0x0629u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B32 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x629u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848B35;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B32u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B32u, 4u, 3u, cpu.address("abs", 0x0629u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B32 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x629u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848B35;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B32u,0x848B32u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848B35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B35u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B35u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B35u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B35 BIT
    cpu.bit(0x1u, true);
    goto L_848B37;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B35u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B35u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B35 BIT
    cpu.bit(0x1u, true);
    goto L_848B37;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B35u,0x848B35u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848B37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B37u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B37u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B37u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B37 BNE -> $848B40
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_848B40; }
    goto L_848B39;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B37u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B37u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B37 BNE -> $848B40
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_848B40; }
    goto L_848B39;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B37u,0x848B37u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848B39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B39u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B39u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B39u, 4u, 3u, cpu.address("abs", 0x062Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B39 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848B3C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B39u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B39u, 4u, 3u, cpu.address("abs", 0x062Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B39 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848B3C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B39u,0x848B39u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848B3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B3Cu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B3Cu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B3Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B3C BIT
    cpu.bit(0x1u, true);
    goto L_848B3E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B3Cu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B3Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B3C BIT
    cpu.bit(0x1u, true);
    goto L_848B3E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B3Cu,0x848B3Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848B3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B3Eu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B3Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B3Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B3E BNE -> $848B49
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_848B49; }
    goto L_848B40;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B3Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B3Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B3E BNE -> $848B49
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_848B49; }
    goto L_848B40;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B3Eu,0x848B3Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848B40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B40u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B40u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B40u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B40 LDA
    cpu.setA(0x81u, 8);
    goto L_848B42;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B40u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B40u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B40 LDA
    cpu.setA(0x81u, 8);
    goto L_848B42;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B40u,0x848B40u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848B42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B42u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B42u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B42u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B42 XBA
    cpu.xba();
    goto L_848B43;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B42u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B42u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B42 XBA
    cpu.xba();
    goto L_848B43;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B42u,0x848B42u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848B43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B43u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B43u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B43u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B43 LDA
    cpu.setA(0xFu, 8);
    goto L_848B45;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B43u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B43u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B43 LDA
    cpu.setA(0xFu, 8);
    goto L_848B45;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B43u,0x848B43u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848B45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B45u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B45u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B45u, 8u, 4u, 0x8086F4u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848B45 JSL -> $8086F4 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8B48u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8B49u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8086F4u, 0x848B45u); }
    goto L_848B49;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B45u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B45u, 8u, 4u, 0x8086F4u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848B45 JSL -> $8086F4 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8B48u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8B49u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8086F4u, 0x848B45u); }
    goto L_848B49;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B45u,0x848B45u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848B49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B49u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B49u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B49u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B49 LDA
    cpu.setA(0x81u, 8);
    goto L_848B4B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B49u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B49u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B49 LDA
    cpu.setA(0x81u, 8);
    goto L_848B4B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B49u,0x848B49u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848B4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B4Bu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B4Bu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B4Bu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B4B XBA
    cpu.xba();
    goto L_848B4C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B4Bu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B4Bu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B4B XBA
    cpu.xba();
    goto L_848B4C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B4Bu,0x848B4Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848B4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B4Cu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B4Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B4Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B4C LDA
    cpu.setA(0x5u, 8);
    goto L_848B4E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B4Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B4Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B4C LDA
    cpu.setA(0x5u, 8);
    goto L_848B4E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B4Cu,0x848B4Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848B4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B4Eu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B4Eu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B4Eu, 8u, 4u, 0x808700u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848B4E JSL -> $808700 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8B51u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8B52u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808700u, 0x848B4Eu); }
    goto L_848B52;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B4Eu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B4Eu, 8u, 4u, 0x808700u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848B4E JSL -> $808700 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8B51u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8B52u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808700u, 0x848B4Eu); }
    goto L_848B52;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B4Eu,0x848B4Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848B52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B52u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B52u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B52u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B52 INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_848B54;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B52u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B52u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B52 INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_848B54;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B52u,0x848B52u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848B54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B54u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B54u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B54u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B54 REP
    cpu.rep(0x20u);
    goto L_848B56;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B54u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B54u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B54 REP
    cpu.rep(0x20u);
    goto L_848B56;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B54u,0x848B54u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848B56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B56u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B56u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B56u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B56 LDA
    cpu.setA(0x4u, 16);
    goto L_848B59;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B56u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B56u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B56 LDA
    cpu.setA(0x4u, 16);
    goto L_848B59;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B56u,0x848B56u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848B59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B59u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B59u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B59u, 8u, 4u, 0x80A6FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848B59 JSL -> $80A6FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8B5Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8B5Du,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6FBu, 0x848B59u); }
    goto L_848B5D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B59u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B59u, 8u, 4u, 0x80A6FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848B59 JSL -> $80A6FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8B5Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8B5Du,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6FBu, 0x848B59u); }
    goto L_848B5D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B59u,0x848B59u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848B5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B5Du))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B5Du,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B5Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B5D BRA -> $848B7C
    goto L_848B7C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B5Du,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B5Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B5D BRA -> $848B7C
    goto L_848B7C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B5Du,0x848B5Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848B5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B5Fu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B5Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B5Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B5F LDA
    cpu.setA(0x81u, 8);
    goto L_848B61;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B5Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B5Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B5F LDA
    cpu.setA(0x81u, 8);
    goto L_848B61;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B5Fu,0x848B5Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848B61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B61u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B61u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B61u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B61 XBA
    cpu.xba();
    goto L_848B62;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B61u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B61u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B61 XBA
    cpu.xba();
    goto L_848B62;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B61u,0x848B61u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848B62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B62u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B62u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B62u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B62 LDA
    cpu.setA(0xFu, 8);
    goto L_848B64;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B62u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B62u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B62 LDA
    cpu.setA(0xFu, 8);
    goto L_848B64;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B62u,0x848B62u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848B64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B64u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B64u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B64u, 8u, 4u, 0x8086F4u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848B64 JSL -> $8086F4 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8B67u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8B68u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8086F4u, 0x848B64u); }
    goto L_848B68;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B64u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B64u, 8u, 4u, 0x8086F4u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848B64 JSL -> $8086F4 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8B67u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8B68u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8086F4u, 0x848B64u); }
    goto L_848B68;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B64u,0x848B64u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848B68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B68u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B68u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B68u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B68 LDA
    cpu.setA(0x81u, 8);
    goto L_848B6A;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B68u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B68u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B68 LDA
    cpu.setA(0x81u, 8);
    goto L_848B6A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B68u,0x848B68u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848B6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B6Au))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B6Au,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B6Au, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B6A XBA
    cpu.xba();
    goto L_848B6B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B6Au,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B6Au, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B6A XBA
    cpu.xba();
    goto L_848B6B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B6Au,0x848B6Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848B6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B6Bu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B6Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B6Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B6B LDA
    cpu.setA(0x5u, 8);
    goto L_848B6D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B6Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B6Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B6B LDA
    cpu.setA(0x5u, 8);
    goto L_848B6D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B6Bu,0x848B6Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848B6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B6Du))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B6Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B6Du, 8u, 4u, 0x808700u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848B6D JSL -> $808700 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8B70u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8B71u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808700u, 0x848B6Du); }
    goto L_848B71;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B6Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B6Du, 8u, 4u, 0x808700u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848B6D JSL -> $808700 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8B70u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8B71u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808700u, 0x848B6Du); }
    goto L_848B71;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B6Du,0x848B6Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848B71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B71u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B71u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B71u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B71 INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_848B73;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B71u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B71u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B71 INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_848B73;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B71u,0x848B71u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848B73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B73u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B73u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B73u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B73 REP
    cpu.rep(0x20u);
    goto L_848B75;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B73u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B73u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B73 REP
    cpu.rep(0x20u);
    goto L_848B75;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B73u,0x848B73u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848B75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B75u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B75u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B75u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B75 LDA
    cpu.setA(0x5u, 16);
    goto L_848B78;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B75u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B75u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B75 LDA
    cpu.setA(0x5u, 16);
    goto L_848B78;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B75u,0x848B75u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848B78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B78u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B78u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B78u, 8u, 4u, 0x80A6FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848B78 JSL -> $80A6FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8B7Bu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8B7Cu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6FBu, 0x848B78u); }
    goto L_848B7C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B78u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B78u, 8u, 4u, 0x80A6FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848B78 JSL -> $80A6FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8B7Bu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8B7Cu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6FBu, 0x848B78u); }
    goto L_848B7C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B78u,0x848B78u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848B7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B7Cu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B7Cu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B7Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B7C SEC
    cpu.setFlag('C', true);
    goto L_848B7D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B7Cu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B7Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B7C SEC
    cpu.setFlag('C', true);
    goto L_848B7D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B7Cu,0x848B7Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848B7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B7Du))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B7Du,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B7Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B7D REP
    cpu.rep(0x20u);
    goto L_848B7F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B7Du,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B7Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B7D REP
    cpu.rep(0x20u);
    goto L_848B7F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B7Du,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B7Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B7D REP
    cpu.rep(0x20u);
    goto L_848B7F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B7Du,0x848B7Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848B7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B7Fu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B7Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B7Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848B7F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848B7Fu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848B7Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B7Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B7Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848B7F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848B7Fu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848B7Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B7Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B7Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848B7F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848B7Fu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848B7Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B7Fu,0x848B7Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_848AF6_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848AF6u: goto L_848AF6;
    case 0x848AF8u: goto L_848AF8;
    case 0x848AFAu: goto L_848AFA;
    case 0x848AFDu: goto L_848AFD;
    case 0x848AFFu: goto L_848AFF;
    case 0x848B02u: goto L_848B02;
    case 0x848B04u: goto L_848B04;
    case 0x848B07u: goto L_848B07;
    case 0x848B09u: goto L_848B09;
    case 0x848B0Au: goto L_848B0A;
    case 0x848B0Cu: goto L_848B0C;
    case 0x848B0Eu: goto L_848B0E;
    case 0x848B11u: goto L_848B11;
    case 0x848B13u: goto L_848B13;
    case 0x848B15u: goto L_848B15;
    case 0x848B18u: goto L_848B18;
    case 0x848B1Au: goto L_848B1A;
    case 0x848B1Cu: goto L_848B1C;
    case 0x848B1Fu: goto L_848B1F;
    case 0x848B21u: goto L_848B21;
    case 0x848B24u: goto L_848B24;
    case 0x848B26u: goto L_848B26;
    case 0x848B28u: goto L_848B28;
    case 0x848B2Bu: goto L_848B2B;
    case 0x848B2Du: goto L_848B2D;
    case 0x848B30u: goto L_848B30;
    case 0x848B32u: goto L_848B32;
    case 0x848B35u: goto L_848B35;
    case 0x848B37u: goto L_848B37;
    case 0x848B39u: goto L_848B39;
    case 0x848B3Cu: goto L_848B3C;
    case 0x848B3Eu: goto L_848B3E;
    case 0x848B40u: goto L_848B40;
    case 0x848B42u: goto L_848B42;
    case 0x848B43u: goto L_848B43;
    case 0x848B45u: goto L_848B45;
    case 0x848B49u: goto L_848B49;
    case 0x848B4Bu: goto L_848B4B;
    case 0x848B4Cu: goto L_848B4C;
    case 0x848B4Eu: goto L_848B4E;
    case 0x848B52u: goto L_848B52;
    case 0x848B54u: goto L_848B54;
    case 0x848B56u: goto L_848B56;
    case 0x848B59u: goto L_848B59;
    case 0x848B5Du: goto L_848B5D;
    case 0x848B5Fu: goto L_848B5F;
    case 0x848B61u: goto L_848B61;
    case 0x848B62u: goto L_848B62;
    case 0x848B64u: goto L_848B64;
    case 0x848B68u: goto L_848B68;
    case 0x848B6Au: goto L_848B6A;
    case 0x848B6Bu: goto L_848B6B;
    case 0x848B6Du: goto L_848B6D;
    case 0x848B71u: goto L_848B71;
    case 0x848B73u: goto L_848B73;
    case 0x848B75u: goto L_848B75;
    case 0x848B78u: goto L_848B78;
    case 0x848B7Cu: goto L_848B7C;
    case 0x848B7Du: goto L_848B7D;
    case 0x848B7Fu: goto L_848B7F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848AF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AF6u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AF6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AF6 REP
    cpu.rep(0x20u);
    goto L_848AF8;
L_848AF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AF8u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AF8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AF8 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848AFA;
L_848AFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AFAu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AFAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AFA BIT
    cpu.bit(0x1080u, true);
    goto L_848AFD;
L_848AFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AFDu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AFDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AFD BNE -> $848B13
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_848B13; }
    goto L_848AFF;
L_848AFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AFFu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AFFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AFF BIT
    cpu.bit(0x2000u, true);
    goto L_848B02;
L_848B02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B02u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B02u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B02 BNE -> $848B0C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_848B0C; }
    goto L_848B04;
L_848B04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B04u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B04u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B04 BIT
    cpu.bit(0x8000u, true);
    goto L_848B07;
L_848B07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B07u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B07u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B07 BNE -> $848B0C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_848B0C; }
    goto L_848B09;
L_848B09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B09u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B09u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B09 CLC
    cpu.setFlag('C', false);
    goto L_848B0A;
L_848B0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B0Au,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B0Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B0A BRA -> $848B7D
    goto L_848B7D;
L_848B0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B0Cu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B0Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B0C SEP
    cpu.sep(0x20u);
    goto L_848B0E;
L_848B0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B0Eu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B0Eu, 6u, 3u, cpu.address("abs", 0x0657u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B0E INC
    cpu.incMem(hw, cpu.address("abs", 0x657u), cpu.m8?8:16);
    goto L_848B11;
L_848B11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B11u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B11u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B11 BRA -> $848B1C
    goto L_848B1C;
L_848B13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B13u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B13u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B13 SEP
    cpu.sep(0x20u);
    goto L_848B15;
L_848B15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B15u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B15u, 4u, 3u, cpu.address("abs", 0x0629u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B15 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x629u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848B18;
L_848B18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B18u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B18u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B18 CMP
    cpu.compareA(0x2u);
    goto L_848B1A;
L_848B1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B1Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B1Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B1A BEQ -> $848B7D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_848B7D; }
    goto L_848B1C;
L_848B1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B1Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B1Cu, 4u, 3u, cpu.address("abs", 0x062Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B1C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848B1F;
L_848B1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B1Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B1Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B1F BEQ -> $848B2D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_848B2D; }
    goto L_848B21;
L_848B21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B21u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B21u, 4u, 3u, cpu.address("abs", 0x0657u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B21 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x657u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848B24;
L_848B24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B24u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B24u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B24 BEQ -> $848B40
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_848B40; }
    goto L_848B26;
L_848B26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B26u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B26u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B26 LDA
    cpu.setA(0x1u, 8);
    goto L_848B28;
L_848B28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B28u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B28u, 4u, 3u, cpu.address("abs", 0x062Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B28 STA
    hw.write(cpu.address("abs", 0x62Au), cpu.a, cpu.m8?8:16);
    goto L_848B2B;
L_848B2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B2Bu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B2Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B2B BRA -> $848B68
    goto L_848B68;
L_848B2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B2Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B2Du, 4u, 3u, cpu.address("abs", 0x0657u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B2D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x657u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848B30;
L_848B30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B30u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B30u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B30 BNE -> $848B5F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_848B5F; }
    goto L_848B32;
L_848B32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B32u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B32u, 4u, 3u, cpu.address("abs", 0x0629u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B32 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x629u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848B35;
L_848B35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B35u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B35u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B35 BIT
    cpu.bit(0x1u, true);
    goto L_848B37;
L_848B37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B37u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B37u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B37 BNE -> $848B40
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_848B40; }
    goto L_848B39;
L_848B39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B39u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B39u, 4u, 3u, cpu.address("abs", 0x062Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B39 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848B3C;
L_848B3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B3Cu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B3Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B3C BIT
    cpu.bit(0x1u, true);
    goto L_848B3E;
L_848B3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B3Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B3Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B3E BNE -> $848B49
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_848B49; }
    goto L_848B40;
L_848B40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B40u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B40u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B40 LDA
    cpu.setA(0x81u, 8);
    goto L_848B42;
L_848B42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B42u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B42u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B42 XBA
    cpu.xba();
    goto L_848B43;
L_848B43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B43u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B43u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B43 LDA
    cpu.setA(0xFu, 8);
    goto L_848B45;
L_848B45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B45u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B45u, 8u, 4u, 0x8086F4u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848B45 JSL -> $8086F4 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8B48u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8B49u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8086F4u, 0x848B45u); }
    goto L_848B49;
L_848B49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B49u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B49u,0x848B49u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B49u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B49u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B49 LDA
    cpu.setA(0x81u, 8);
    goto L_848B4B;
L_848B4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B4Bu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B4Bu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B4B XBA
    cpu.xba();
    goto L_848B4C;
L_848B4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B4Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B4Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B4C LDA
    cpu.setA(0x5u, 8);
    goto L_848B4E;
L_848B4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B4Eu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B4Eu, 8u, 4u, 0x808700u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848B4E JSL -> $808700 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8B51u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8B52u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808700u, 0x848B4Eu); }
    goto L_848B52;
L_848B52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B52u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B52u,0x848B52u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B52u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B52u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B52 INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_848B54;
L_848B54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B54u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B54u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B54 REP
    cpu.rep(0x20u);
    goto L_848B56;
L_848B56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B56u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B56u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B56u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B56 LDA
    cpu.setA(0x4u, 16);
    goto L_848B59;
L_848B59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B59u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B59u, 8u, 4u, 0x80A6FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848B59 JSL -> $80A6FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8B5Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8B5Du,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6FBu, 0x848B59u); }
    goto L_848B5D;
L_848B5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B5Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B5Du,0x848B5Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B5Du,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B5Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B5D BRA -> $848B7C
    goto L_848B7C;
L_848B5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B5Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B5Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B5Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B5F LDA
    cpu.setA(0x81u, 8);
    goto L_848B61;
L_848B61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B61u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B61u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B61 XBA
    cpu.xba();
    goto L_848B62;
L_848B62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B62u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B62u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B62u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B62 LDA
    cpu.setA(0xFu, 8);
    goto L_848B64;
L_848B64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B64u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B64u, 8u, 4u, 0x8086F4u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848B64 JSL -> $8086F4 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8B67u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8B68u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8086F4u, 0x848B64u); }
    goto L_848B68;
L_848B68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B68u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B68u,0x848B68u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B68u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B68u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B68 LDA
    cpu.setA(0x81u, 8);
    goto L_848B6A;
L_848B6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B6Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B6Au,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B6Au, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B6A XBA
    cpu.xba();
    goto L_848B6B;
L_848B6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B6Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B6Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B6B LDA
    cpu.setA(0x5u, 8);
    goto L_848B6D;
L_848B6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B6Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B6Du, 8u, 4u, 0x808700u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848B6D JSL -> $808700 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8B70u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8B71u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808700u, 0x848B6Du); }
    goto L_848B71;
L_848B71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B71u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B71u,0x848B71u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B71u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B71u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B71 INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_848B73;
L_848B73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B73u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B73u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B73 REP
    cpu.rep(0x20u);
    goto L_848B75;
L_848B75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B75u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B75u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B75 LDA
    cpu.setA(0x5u, 16);
    goto L_848B78;
L_848B78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B78u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B78u, 8u, 4u, 0x80A6FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848B78 JSL -> $80A6FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8B7Bu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8B7Cu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6FBu, 0x848B78u); }
    goto L_848B7C;
L_848B7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B7Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B7Cu,0x848B7Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B7Cu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B7Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B7C SEC
    cpu.setFlag('C', true);
    goto L_848B7D;
L_848B7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B7Du))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B7Du,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B7Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B7D REP
    cpu.rep(0x20u);
    goto L_848B7F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B7Du,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B7Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B7D REP
    cpu.rep(0x20u);
    goto L_848B7F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B7Du,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B7Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B7D REP
    cpu.rep(0x20u);
    goto L_848B7F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B7Du,0x848B7Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848B7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B7Fu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B7Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B7Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848B7F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848B7Fu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848B7Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B7Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B7Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848B7F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848B7Fu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848B7Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B7Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B7Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848B7F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848B7Fu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848B7Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B7Fu,0x848B7Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_849DA6_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x849DA6u: goto L_849DA6;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_849DA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DA6u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DA6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849DA6 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x849DA6u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x849DA6u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_849DA6_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x849DA6u: goto L_849DA6;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_849DA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DA6u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DA6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849DA6 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x849DA6u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x849DA6u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_849EC3_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x849EC3u: goto L_849EC3;
    case 0x849EC5u: goto L_849EC5;
    case 0x849EC6u: goto L_849EC6;
    case 0x849EC7u: goto L_849EC7;
    case 0x849ECBu: goto L_849ECB;
    case 0x849ECDu: goto L_849ECD;
    case 0x849ED0u: goto L_849ED0;
    case 0x849ED2u: goto L_849ED2;
    case 0x849ED4u: goto L_849ED4;
    case 0x849ED6u: goto L_849ED6;
    case 0x849EDAu: goto L_849EDA;
    case 0x849EDCu: goto L_849EDC;
    case 0x849EDEu: goto L_849EDE;
    case 0x849EE2u: goto L_849EE2;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_849EC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC3u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849EC3 REP
    cpu.rep(0x20u);
    goto L_849EC5;
L_849EC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC5u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849EC5 ASL
    cpu.aslA();
    goto L_849EC6;
L_849EC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC6u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849EC6 TAX
    cpu.transfer("TAX");
    goto L_849EC7;
L_849EC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC7u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC7u, 6u, 4u, ((0x938000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849EC7 LDA
    cpu.loadA(hw.readW(((0x938000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849ECB;
L_849ECB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ECBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849ECB STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_849ECD;
L_849ECD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ECDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849ECD LDA
    cpu.setA(0x93u, 16);
    goto L_849ED0;
L_849ED0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ED0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849ED0 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_849ED2;
L_849ED2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ED2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED2u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849ED2 STZ
    hw.write(cpu.address("dp", 0x3u), 0, cpu.m8?8:16);
    goto L_849ED4;
L_849ED4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ED4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED4u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849ED4 STZ
    hw.write(cpu.address("dp", 0x4u), 0, cpu.m8?8:16);
    goto L_849ED6;
L_849ED6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ED6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED6u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED6u, 6u, 4u, ((0x849EE3u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849ED6 LDA
    cpu.loadA(hw.readW(((0x849EE3u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849EDA;
L_849EDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849EDA STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_849EDC;
L_849EDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDCu,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849EDC STY
    hw.write(cpu.address("dp", 0xCu), cpu.y, cpu.x8?8:16);
    goto L_849EDE;
L_849EDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDEu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDEu, 8u, 4u, 0x80887Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849EDE JSL -> $80887E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9EE1u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9EE2u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80887Eu, 0x849EDEu); }
    goto L_849EE2;
L_849EE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EE2u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EE2u,0x849EE2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE2u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849EE2 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x849EE2u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x849EE2u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_84B513_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84B513u: goto L_84B513;
    case 0x84B516u: goto L_84B516;
    case 0x84B518u: goto L_84B518;
    case 0x84B51Au: goto L_84B51A;
    case 0x84B51Cu: goto L_84B51C;
    case 0x84B51Eu: goto L_84B51E;
    case 0x84B521u: goto L_84B521;
    case 0x84B523u: goto L_84B523;
    case 0x84B525u: goto L_84B525;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84B513:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB513u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB513u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB513u, 5u + 1u, 3u, cpu.address("absx", 0x26B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B513 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x26B5u), cpu.m8?8:16));
    goto L_84B516;
L_84B516:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB516u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB516u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB516u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x34u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B516 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x34u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84B518;
L_84B518:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB518u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB518u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB518u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x97u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B518 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x97u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84B51A;
L_84B51A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB51Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB51Au,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB51Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B51A LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84B51C;
L_84B51C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB51Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB51Cu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB51Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B51C LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xE2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84B51E;
L_84B51E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB51Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB51Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB51Eu, 6u, 3u, cpu.address("abs", 0x75A5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B51E JSR -> $8475A5 stack real
    { cpu.push16Value(hw,0xB520u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB521u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x75A5u), 0x84B51Eu); }
    goto L_84B521;
L_84B521:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB521u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB521u,0x84B521u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB521u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB521u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B521 BNE -> $84B525
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_84B525; }
    goto L_84B523;
L_84B523:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB523u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB523u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB523u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B523 INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_84B525;
L_84B525:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB525u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB525u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB525u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B525 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84B525u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84B525u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_84B6B9_E0M1X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84B6B9u: goto L_84B6B9;
    case 0x84B6BBu: goto L_84B6BB;
    case 0x84B6BEu: goto L_84B6BE;
    case 0x84B6C0u: goto L_84B6C0;
    case 0x84B6C3u: goto L_84B6C3;
    case 0x84B6C5u: goto L_84B6C5;
    case 0x84B6C8u: goto L_84B6C8;
    case 0x84B6CAu: goto L_84B6CA;
    case 0x84B6CDu: goto L_84B6CD;
    case 0x84B6CFu: goto L_84B6CF;
    case 0x84B6D2u: goto L_84B6D2;
    case 0x84B6D5u: goto L_84B6D5;
    case 0x84B6D6u: goto L_84B6D6;
    case 0x84B6D7u: goto L_84B6D7;
    case 0x84B6DBu: goto L_84B6DB;
    case 0x84B6DDu: goto L_84B6DD;
    case 0x84B6DFu: goto L_84B6DF;
    case 0x84B6E2u: goto L_84B6E2;
    case 0x84B6E3u: goto L_84B6E3;
    case 0x84B6E4u: goto L_84B6E4;
    case 0x84B6E8u: goto L_84B6E8;
    case 0x84B6EAu: goto L_84B6EA;
    case 0x84B6EEu: goto L_84B6EE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84B6B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B9u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6B9 REP
    cpu.rep(0x20u);
    goto L_84B6BB;
L_84B6BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6BB LDA
    cpu.setA(0x9Eu, 16);
    goto L_84B6BE;
L_84B6BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6BE STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_84B6C0;
L_84B6C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6C0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6C0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6C0 LDA
    cpu.setA(0x89u, 16);
    goto L_84B6C3;
L_84B6C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6C3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6C3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6C3 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_84B6C5;
L_84B6C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6C5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6C5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6C5 LDA
    cpu.setA(0x80u, 16);
    goto L_84B6C8;
L_84B6C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6C8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6C8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6C8 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_84B6CA;
L_84B6CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6CAu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6CAu, 5u, 3u, cpu.address("abs", 0x01A5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6CA LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1A5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84B6CD;
L_84B6CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6CDu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6CDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6CD BNE -> $84B6DF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_84B6DF; }
    goto L_84B6CF;
L_84B6CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6CFu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6CFu, 5u, 3u, cpu.address("abs", 0x062Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6CF LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84B6D2;
L_84B6D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D2u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6D2 AND
    cpu.logicAnd(0xFFu);
    goto L_84B6D5;
L_84B6D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D5u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6D5 ASL
    cpu.aslA();
    goto L_84B6D6;
L_84B6D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D6u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6D6 TAX
    cpu.transfer("TAX");
    goto L_84B6D7;
L_84B6D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D7u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D7u, 6u, 4u, ((0x9E8868u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6D7 LDA
    cpu.loadA(hw.readW(((0x9E8868u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84B6DB;
L_84B6DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6DB STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_84B6DD;
L_84B6DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DDu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6DD BRA -> $84B6EA
    goto L_84B6EA;
L_84B6DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DFu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DFu, 5u, 3u, cpu.address("abs", 0x01A9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6DF LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1A9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84B6E2;
L_84B6E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E2u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6E2 ASL
    cpu.aslA();
    goto L_84B6E3;
L_84B6E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E3u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6E3 TAX
    cpu.transfer("TAX");
    goto L_84B6E4;
L_84B6E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E4u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E4u, 6u, 4u, ((0x9E8868u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6E4 LDA
    cpu.loadA(hw.readW(((0x9E8868u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84B6E8;
L_84B6E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6E8 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_84B6EA;
L_84B6EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EAu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EAu, 8u, 4u, 0x80887Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B6EA JSL -> $80887E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB6EDu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB6EEu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80887Eu, 0x84B6EAu); }
    goto L_84B6EE;
L_84B6EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6EEu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB6EEu,0x84B6EEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B6EE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84B6EEu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84B6EEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_84B6B9_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84B6B9u: goto L_84B6B9;
    case 0x84B6BBu: goto L_84B6BB;
    case 0x84B6BEu: goto L_84B6BE;
    case 0x84B6C0u: goto L_84B6C0;
    case 0x84B6C3u: goto L_84B6C3;
    case 0x84B6C5u: goto L_84B6C5;
    case 0x84B6C8u: goto L_84B6C8;
    case 0x84B6CAu: goto L_84B6CA;
    case 0x84B6CDu: goto L_84B6CD;
    case 0x84B6CFu: goto L_84B6CF;
    case 0x84B6D2u: goto L_84B6D2;
    case 0x84B6D5u: goto L_84B6D5;
    case 0x84B6D6u: goto L_84B6D6;
    case 0x84B6D7u: goto L_84B6D7;
    case 0x84B6DBu: goto L_84B6DB;
    case 0x84B6DDu: goto L_84B6DD;
    case 0x84B6DFu: goto L_84B6DF;
    case 0x84B6E2u: goto L_84B6E2;
    case 0x84B6E3u: goto L_84B6E3;
    case 0x84B6E4u: goto L_84B6E4;
    case 0x84B6E8u: goto L_84B6E8;
    case 0x84B6EAu: goto L_84B6EA;
    case 0x84B6EEu: goto L_84B6EE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84B6B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B9u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6B9 REP
    cpu.rep(0x20u);
    goto L_84B6BB;
L_84B6BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6BB LDA
    cpu.setA(0x9Eu, 16);
    goto L_84B6BE;
L_84B6BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6BE STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_84B6C0;
L_84B6C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6C0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6C0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6C0 LDA
    cpu.setA(0x89u, 16);
    goto L_84B6C3;
L_84B6C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6C3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6C3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6C3 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_84B6C5;
L_84B6C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6C5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6C5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6C5 LDA
    cpu.setA(0x80u, 16);
    goto L_84B6C8;
L_84B6C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6C8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6C8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6C8 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_84B6CA;
L_84B6CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6CAu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6CAu, 5u, 3u, cpu.address("abs", 0x01A5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6CA LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1A5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84B6CD;
L_84B6CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6CDu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6CDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6CD BNE -> $84B6DF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_84B6DF; }
    goto L_84B6CF;
L_84B6CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6CFu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6CFu, 5u, 3u, cpu.address("abs", 0x062Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6CF LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84B6D2;
L_84B6D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D2u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6D2 AND
    cpu.logicAnd(0xFFu);
    goto L_84B6D5;
L_84B6D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D5u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6D5 ASL
    cpu.aslA();
    goto L_84B6D6;
L_84B6D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D6u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6D6 TAX
    cpu.transfer("TAX");
    goto L_84B6D7;
L_84B6D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D7u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D7u, 6u, 4u, ((0x9E8868u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6D7 LDA
    cpu.loadA(hw.readW(((0x9E8868u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84B6DB;
L_84B6DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6DB STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_84B6DD;
L_84B6DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DDu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6DD BRA -> $84B6EA
    goto L_84B6EA;
L_84B6DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DFu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DFu, 5u, 3u, cpu.address("abs", 0x01A9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6DF LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1A9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84B6E2;
L_84B6E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E2u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6E2 ASL
    cpu.aslA();
    goto L_84B6E3;
L_84B6E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E3u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6E3 TAX
    cpu.transfer("TAX");
    goto L_84B6E4;
L_84B6E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E4u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E4u, 6u, 4u, ((0x9E8868u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6E4 LDA
    cpu.loadA(hw.readW(((0x9E8868u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84B6E8;
L_84B6E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6E8 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_84B6EA;
L_84B6EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EAu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EAu, 8u, 4u, 0x80887Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B6EA JSL -> $80887E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB6EDu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB6EEu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80887Eu, 0x84B6EAu); }
    goto L_84B6EE;
L_84B6EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6EEu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB6EEu,0x84B6EEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B6EE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84B6EEu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84B6EEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_84BC5D_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84BC5Du: goto L_84BC5D;
    case 0x84BC5Fu: goto L_84BC5F;
    case 0x84BC60u: goto L_84BC60;
    case 0x84BC63u: goto L_84BC63;
    case 0x84BC66u: goto L_84BC66;
    case 0x84BC69u: goto L_84BC69;
    case 0x84BC6Cu: goto L_84BC6C;
    case 0x84BC6Fu: goto L_84BC6F;
    case 0x84BC72u: goto L_84BC72;
    case 0x84BC75u: goto L_84BC75;
    case 0x84BC78u: goto L_84BC78;
    case 0x84BC79u: goto L_84BC79;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84BC5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC5Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC5Du,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC5Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BC5D REP
    cpu.rep(0x20u);
    goto L_84BC5F;
L_84BC5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC5Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC5Fu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC5Fu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $84BC5F PHB
    cpu.push("PHB", hw);
    goto L_84BC60;
L_84BC60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC60u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC60u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BC60 LDX
    cpu.setX(0x19C0u, 16);
    goto L_84BC63;
L_84BC63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC63u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC63u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC63u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BC63 LDY
    cpu.setY(0x1AC0u, 16);
    goto L_84BC66;
L_84BC66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC66u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC66u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC66u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BC66 LDA
    cpu.setA(0x1Fu, 16);
    goto L_84BC69;
L_84BC69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC69u,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xBC69u, (std::uint32_t(cpu.a)+1u), 0x84u, 0x84u);
    // $84BC69 MVN
    cpu.blockMove(hw, 0x84u, 0x84u, false);
    goto L_84BC6C;
L_84BC6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC6Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC6Cu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC6Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BC6C LDX
    cpu.setX(0x19E0u, 16);
    goto L_84BC6F;
L_84BC6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC6Fu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC6Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BC6F LDY
    cpu.setY(0x1AE0u, 16);
    goto L_84BC72;
L_84BC72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC72u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC72u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BC72 LDA
    cpu.setA(0x1Fu, 16);
    goto L_84BC75;
L_84BC75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC75u,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xBC75u, (std::uint32_t(cpu.a)+1u), 0x84u, 0x84u);
    // $84BC75 MVN
    cpu.blockMove(hw, 0x84u, 0x84u, false);
    goto L_84BC78;
L_84BC78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC78u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC78u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $84BC78 PLB
    cpu.pop("PLB", hw);
    goto L_84BC79;
L_84BC79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC79u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC79u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84BC79 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x84BC79u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84BC79u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_84F870_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84F870u: goto L_84F870;
    case 0x84F871u: goto L_84F871;
    case 0x84F872u: goto L_84F872;
    case 0x84F873u: goto L_84F873;
    case 0x84F876u: goto L_84F876;
    case 0x84F878u: goto L_84F878;
    case 0x84F87Cu: goto L_84F87C;
    case 0x84F87Eu: goto L_84F87E;
    case 0x84F881u: goto L_84F881;
    case 0x84F882u: goto L_84F882;
    case 0x84F883u: goto L_84F883;
    case 0x84F886u: goto L_84F886;
    case 0x84F888u: goto L_84F888;
    case 0x84F88Au: goto L_84F88A;
    case 0x84F88Du: goto L_84F88D;
    case 0x84F88Eu: goto L_84F88E;
    case 0x84F88Fu: goto L_84F88F;
    case 0x84F892u: goto L_84F892;
    case 0x84F894u: goto L_84F894;
    case 0x84F896u: goto L_84F896;
    case 0x84F899u: goto L_84F899;
    case 0x84F89Au: goto L_84F89A;
    case 0x84F89Bu: goto L_84F89B;
    case 0x84F89Eu: goto L_84F89E;
    case 0x84F8A0u: goto L_84F8A0;
    case 0x84F8A3u: goto L_84F8A3;
    case 0x84F8A5u: goto L_84F8A5;
    case 0x84F8A8u: goto L_84F8A8;
    case 0x84F8AAu: goto L_84F8AA;
    case 0x84F8ADu: goto L_84F8AD;
    case 0x84F8B0u: goto L_84F8B0;
    case 0x84F8B2u: goto L_84F8B2;
    case 0x84F8B4u: goto L_84F8B4;
    case 0x84F8B7u: goto L_84F8B7;
    case 0x84F8BAu: goto L_84F8BA;
    case 0x84F8BCu: goto L_84F8BC;
    case 0x84F8BFu: goto L_84F8BF;
    case 0x84F8C1u: goto L_84F8C1;
    case 0x84F8C4u: goto L_84F8C4;
    case 0x84F8C6u: goto L_84F8C6;
    case 0x84F8C9u: goto L_84F8C9;
    case 0x84F8CCu: goto L_84F8CC;
    case 0x84F8CEu: goto L_84F8CE;
    case 0x84F8D1u: goto L_84F8D1;
    case 0x84F8D3u: goto L_84F8D3;
    case 0x84F8D6u: goto L_84F8D6;
    case 0x84F8D8u: goto L_84F8D8;
    case 0x84F8DBu: goto L_84F8DB;
    case 0x84F8DDu: goto L_84F8DD;
    case 0x84F8E0u: goto L_84F8E0;
    case 0x84F8E2u: goto L_84F8E2;
    case 0x84F8E5u: goto L_84F8E5;
    case 0x84F8E8u: goto L_84F8E8;
    case 0x84F8EAu: goto L_84F8EA;
    case 0x84F8EDu: goto L_84F8ED;
    case 0x84F8EFu: goto L_84F8EF;
    case 0x84F8F2u: goto L_84F8F2;
    case 0x84F8F4u: goto L_84F8F4;
    case 0x84F8F7u: goto L_84F8F7;
    case 0x84F8F9u: goto L_84F8F9;
    case 0x84F8FCu: goto L_84F8FC;
    case 0x84F8FEu: goto L_84F8FE;
    case 0x84F901u: goto L_84F901;
    case 0x84F903u: goto L_84F903;
    case 0x84F905u: goto L_84F905;
    case 0x84F908u: goto L_84F908;
    case 0x84F90Au: goto L_84F90A;
    case 0x84F90Du: goto L_84F90D;
    case 0x84F90Fu: goto L_84F90F;
    case 0x84F912u: goto L_84F912;
    case 0x84F913u: goto L_84F913;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84F870:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF870u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF870u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF870u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $84F870 PHB
    cpu.push("PHB", hw);
    goto L_84F871;
L_84F871:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF871u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF871u,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF871u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $84F871 PHK
    cpu.push("PHK", hw);
    goto L_84F872;
L_84F872:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF872u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF872u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF872u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $84F872 PLB
    cpu.pop("PLB", hw);
    goto L_84F873;
L_84F873:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF873u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF873u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF873u, 5u, 3u, cpu.address("abs", 0x02CEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F873 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2CEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84F876;
L_84F876:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF876u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF876u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF876u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F876 STA
    hw.write(cpu.address("dp", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_84F878;
L_84F878:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF878u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF878u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF878u, 8u, 4u, 0x809315u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84F878 JSL -> $809315 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF87Bu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF87Cu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809315u, 0x84F878u); }
    goto L_84F87C;
L_84F87C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF87Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF87Cu,0x84F87Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF87Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF87Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F87C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84F87E;
L_84F87E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF87Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF87Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF87Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F87E AND
    cpu.logicAnd(0xFFu);
    goto L_84F881;
L_84F881:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF881u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF881u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF881u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F881 ASL
    cpu.aslA();
    goto L_84F882;
L_84F882:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF882u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF882u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF882u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F882 TAX
    cpu.transfer("TAX");
    goto L_84F883;
L_84F883:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF883u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF883u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF883u, 5u + 1u, 3u, cpu.address("absx", 0xF95Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F883 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xF95Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84F886;
L_84F886:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF886u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF886u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF886u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F886 STA
    hw.write(cpu.address("dp", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_84F888;
L_84F888:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF888u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF888u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF888u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F888 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84F88A;
L_84F88A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF88Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF88Au,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF88Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F88A AND
    cpu.logicAnd(0xFFu);
    goto L_84F88D;
L_84F88D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF88Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF88Du,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF88Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F88D ASL
    cpu.aslA();
    goto L_84F88E;
L_84F88E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF88Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF88Eu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF88Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F88E TAX
    cpu.transfer("TAX");
    goto L_84F88F;
L_84F88F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF88Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF88Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF88Fu, 5u + 1u, 3u, cpu.address("absx", 0xF95Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F88F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xF95Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84F892;
L_84F892:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF892u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF892u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF892u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F892 STA
    hw.write(cpu.address("dp", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_84F894;
L_84F894:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF894u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF894u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF894u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F894 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84F896;
L_84F896:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF896u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF896u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF896u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F896 AND
    cpu.logicAnd(0xFFu);
    goto L_84F899;
L_84F899:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF899u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF899u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF899u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F899 ASL
    cpu.aslA();
    goto L_84F89A;
L_84F89A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF89Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF89Au,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF89Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F89A TAX
    cpu.transfer("TAX");
    goto L_84F89B;
L_84F89B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF89Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF89Bu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF89Bu, 5u + 1u, 3u, cpu.address("absx", 0xF95Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F89B LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xF95Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84F89E;
L_84F89E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF89Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF89Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF89Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F89E STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_84F8A0;
L_84F8A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8A0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8A0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F8A0 LDA
    cpu.setA(0xFFFFu, 16);
    goto L_84F8A3;
L_84F8A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8A3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8A3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F8A3 STA
    hw.write(cpu.address("dp", 0x16u), cpu.a, cpu.m8?8:16);
    goto L_84F8A5;
L_84F8A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8A5u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8A5u, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F8A5 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84F8A8;
L_84F8A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8A8u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8A8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F8A8 BNE -> $84F8B4
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_84F8B4; }
    goto L_84F8AA;
L_84F8AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8AAu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8AAu, 5u, 3u, cpu.address("abs", 0x02CEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F8AA LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2CEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84F8AD;
L_84F8AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8ADu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8ADu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F8AD CMP
    cpu.compareA(0x4Fu);
    goto L_84F8B0;
L_84F8B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8B0u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8B0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F8B0 BCS -> $84F8D8
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_84F8D8; }
    goto L_84F8B2;
L_84F8B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8B2u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8B2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F8B2 BRA -> $84F8BC
    goto L_84F8BC;
L_84F8B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8B4u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8B4u, 5u, 3u, cpu.address("abs", 0x02CEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F8B4 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2CEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84F8B7;
L_84F8B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8B7u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8B7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F8B7 CMP
    cpu.compareA(0x63u);
    goto L_84F8BA;
L_84F8BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8BAu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8BAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F8BA BCS -> $84F8D8
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_84F8D8; }
    goto L_84F8BC;
L_84F8BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8BCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8BCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F8BC LDA
    cpu.setA(0x38Eu, 16);
    goto L_84F8BF;
L_84F8BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8BFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8BFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F8BF STA
    hw.write(cpu.address("dp", 0x61u), cpu.a, cpu.m8?8:16);
    goto L_84F8C1;
L_84F8C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8C1u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8C1u, 5u, 3u, cpu.address("abs", 0xF914u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F8C1 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xF914u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84F8C4;
L_84F8C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8C4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8C4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F8C4 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_84F8C6;
L_84F8C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8C6u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8C6u, 6u, 3u, cpu.address("abs", 0xF970u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84F8C6 JSR -> $84F970 stack real
    { cpu.push16Value(hw,0xF8C8u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF8C9u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF970u), 0x84F8C6u); }
    goto L_84F8C9;
L_84F8C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8C9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF8C9u,0x84F8C9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8C9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8C9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F8C9 LDA
    cpu.setA(0x39Cu, 16);
    goto L_84F8CC;
L_84F8CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8CCu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8CCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F8CC STA
    hw.write(cpu.address("dp", 0x61u), cpu.a, cpu.m8?8:16);
    goto L_84F8CE;
L_84F8CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8CEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8CEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F8CE LDA
    cpu.setA(0x12u, 16);
    goto L_84F8D1;
L_84F8D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8D1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8D1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F8D1 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_84F8D3;
L_84F8D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8D3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8D3u, 6u, 3u, cpu.address("abs", 0xF970u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84F8D3 JSR -> $84F970 stack real
    { cpu.push16Value(hw,0xF8D5u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF8D6u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF970u), 0x84F8D3u); }
    goto L_84F8D6;
L_84F8D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8D6u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF8D6u,0x84F8D6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8D6u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8D6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F8D6 BRA -> $84F912
    goto L_84F912;
L_84F8D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8D8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8D8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F8D8 LDA
    cpu.setA(0x30Eu, 16);
    goto L_84F8DB;
L_84F8DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8DBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8DBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F8DB STA
    hw.write(cpu.address("dp", 0x61u), cpu.a, cpu.m8?8:16);
    goto L_84F8DD;
L_84F8DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8DDu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8DDu, 5u, 3u, cpu.address("abs", 0xF916u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F8DD LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xF916u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84F8E0;
L_84F8E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8E0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8E0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F8E0 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_84F8E2;
L_84F8E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8E2u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8E2u, 6u, 3u, cpu.address("abs", 0xF970u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84F8E2 JSR -> $84F970 stack real
    { cpu.push16Value(hw,0xF8E4u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF8E5u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF970u), 0x84F8E2u); }
    goto L_84F8E5;
L_84F8E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8E5u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF8E5u,0x84F8E5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8E5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8E5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F8E5 LDA
    cpu.setA(0x3CEu, 16);
    goto L_84F8E8;
L_84F8E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8E8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8E8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F8E8 STA
    hw.write(cpu.address("dp", 0x61u), cpu.a, cpu.m8?8:16);
    goto L_84F8EA;
L_84F8EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8EAu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8EAu, 5u, 3u, cpu.address("abs", 0xF914u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F8EA LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xF914u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84F8ED;
L_84F8ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8EDu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8EDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F8ED STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_84F8EF;
L_84F8EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8EFu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8EFu, 6u, 3u, cpu.address("abs", 0xF970u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84F8EF JSR -> $84F970 stack real
    { cpu.push16Value(hw,0xF8F1u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF8F2u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF970u), 0x84F8EFu); }
    goto L_84F8F2;
L_84F8F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8F2u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF8F2u,0x84F8F2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8F2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8F2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F8F2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84F8F4;
L_84F8F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8F4u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8F4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F8F4 CMP
    cpu.compareA(0xAAu);
    goto L_84F8F7;
L_84F8F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8F7u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8F7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F8F7 BNE -> $84F905
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_84F905; }
    goto L_84F8F9;
L_84F8F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8F9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8F9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F8F9 LDA
    cpu.setA(0x3DCu, 16);
    goto L_84F8FC;
L_84F8FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8FCu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8FCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F8FC STA
    hw.write(cpu.address("dp", 0x61u), cpu.a, cpu.m8?8:16);
    goto L_84F8FE;
L_84F8FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8FEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8FEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F8FE LDA
    cpu.setA(0x12u, 16);
    goto L_84F901;
L_84F901:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF901u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF901u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF901u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F901 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_84F903;
L_84F903:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF903u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF903u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF903u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F903 BRA -> $84F90F
    goto L_84F90F;
L_84F905:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF905u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF905u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF905u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F905 LDA
    cpu.setA(0x3DAu, 16);
    goto L_84F908;
L_84F908:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF908u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF908u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF908u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F908 STA
    hw.write(cpu.address("dp", 0x61u), cpu.a, cpu.m8?8:16);
    goto L_84F90A;
L_84F90A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF90Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF90Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF90Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F90A LDA
    cpu.setA(0x10u, 16);
    goto L_84F90D;
L_84F90D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF90Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF90Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF90Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F90D STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_84F90F;
L_84F90F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF90Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF90Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF90Fu, 6u, 3u, cpu.address("abs", 0xF970u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84F90F JSR -> $84F970 stack real
    { cpu.push16Value(hw,0xF911u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF912u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF970u), 0x84F90Fu); }
    goto L_84F912;
L_84F912:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF912u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF912u,0x84F912u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF912u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF912u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $84F912 PLB
    cpu.pop("PLB", hw);
    goto L_84F913;
L_84F913:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF913u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF913u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF913u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84F913 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84F913u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84F913u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_84F970_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84F970u: goto L_84F970;
    case 0x84F973u: goto L_84F973;
    case 0x84F975u: goto L_84F975;
    case 0x84F977u: goto L_84F977;
    case 0x84F979u: goto L_84F979;
    case 0x84F97Cu: goto L_84F97C;
    case 0x84F97Eu: goto L_84F97E;
    case 0x84F981u: goto L_84F981;
    case 0x84F985u: goto L_84F985;
    case 0x84F986u: goto L_84F986;
    case 0x84F989u: goto L_84F989;
    case 0x84F98Du: goto L_84F98D;
    case 0x84F98Eu: goto L_84F98E;
    case 0x84F98Fu: goto L_84F98F;
    case 0x84F990u: goto L_84F990;
    case 0x84F991u: goto L_84F991;
    case 0x84F993u: goto L_84F993;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84F970:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF970u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF970u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF970u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F970 LDY
    cpu.setY(0x0u, 16);
    goto L_84F973;
L_84F973:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF973u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF973u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF973u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F973 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x61u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_84F975;
L_84F975:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF975u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF975u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF975u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 2u, 0u);
    // $84F975 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84F977;
L_84F977:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF977u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF977u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF977u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F977 BEQ -> $84F98D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_84F98D; }
    goto L_84F979;
L_84F979:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF979u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF979u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF979u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F979 CMP
    cpu.compareA(0xFFFFu);
    goto L_84F97C;
L_84F97C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF97Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF97Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF97Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F97C BEQ -> $84F993
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_84F993; }
    goto L_84F97E;
L_84F97E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF97Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF97Eu,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF97Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F97E ORA
    cpu.logicOr(0x2400u);
    goto L_84F981;
L_84F981:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF981u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF981u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF981u, 6u, 4u, ((0x7E2800u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F981 STA
    hw.write(((0x7E2800u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_84F985;
L_84F985:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF985u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF985u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF985u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F985 CLC
    cpu.setFlag('C', false);
    goto L_84F986;
L_84F986:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF986u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF986u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF986u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F986 ADC
    cpu.adc(0x10u);
    goto L_84F989;
L_84F989:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF989u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF989u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF989u, 6u, 4u, ((0x7E2840u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F989 STA
    hw.write(((0x7E2840u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_84F98D;
L_84F98D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF98Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF98Du,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF98Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F98D INY
    cpu.inc('Y');
    goto L_84F98E;
L_84F98E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF98Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF98Eu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF98Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F98E INY
    cpu.inc('Y');
    goto L_84F98F;
L_84F98F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF98Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF98Fu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF98Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F98F INX
    cpu.inc('X');
    goto L_84F990;
L_84F990:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF990u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF990u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF990u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F990 INX
    cpu.inc('X');
    goto L_84F991;
L_84F991:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF991u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF991u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF991u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F991 BRA -> $84F975
    goto L_84F975;
L_84F993:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF993u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF993u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF993u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84F993 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84F993u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84F993u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_9F8FB2_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x9F8FB2u: goto L_9F8FB2;
    case 0x9F8FB4u: goto L_9F8FB4;
    case 0x9F8FB6u: goto L_9F8FB6;
    case 0x9F8FB8u: goto L_9F8FB8;
    case 0x9F8FBAu: goto L_9F8FBA;
    case 0x9F8FBCu: goto L_9F8FBC;
    case 0x9F8FBEu: goto L_9F8FBE;
    case 0x9F8FC1u: goto L_9F8FC1;
    case 0x9F8FC2u: goto L_9F8FC2;
    case 0x9F8FC3u: goto L_9F8FC3;
    case 0x9F8FC6u: goto L_9F8FC6;
    case 0x9F8FC9u: goto L_9F8FC9;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_9F8FB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB2u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $9F8FB2 SEP
    cpu.sep(0x20u);
    goto L_9F8FB4;
L_9F8FB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x47u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $9F8FB4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x47u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_9F8FB6;
L_9F8FB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB6u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $9F8FB6 BPL -> $9F8FC9
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_9F8FC9; }
    goto L_9F8FB8;
L_9F8FB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FB8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB8u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $9F8FB8 AND
    cpu.logicAnd(0x7Fu);
    goto L_9F8FBA;
L_9F8FBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FBAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FBAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x47u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $9F8FBA STA
    hw.write(cpu.address("dp", 0x47u), cpu.a, cpu.m8?8:16);
    goto L_9F8FBC;
L_9F8FBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FBCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FBCu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FBCu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $9F8FBC REP
    cpu.rep(0x20u);
    goto L_9F8FBE;
L_9F8FBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FBEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FBEu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FBEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $9F8FBE AND
    cpu.logicAnd(0xFFu);
    goto L_9F8FC1;
L_9F8FC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC1u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $9F8FC1 ASL
    cpu.aslA();
    goto L_9F8FC2;
L_9F8FC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC2u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $9F8FC2 TAX
    cpu.transfer("TAX");
    goto L_9F8FC3;
L_9F8FC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC3u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC3u, 5u, 3u, cpu.address("abs", 0x8FC8u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $9F8FC3 PEA
    cpu.push16Value(hw, 0x8FC8u);
    goto L_9F8FC6;
L_9F8FC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC6u,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC6u, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x8FCAu + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $9F8FC6 JMP (8FCA,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x8FCAu+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x9F8FC6u); return; }
L_9F8FC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC9u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $9F8FC9 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x9F8FC9u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x9F8FC9u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

