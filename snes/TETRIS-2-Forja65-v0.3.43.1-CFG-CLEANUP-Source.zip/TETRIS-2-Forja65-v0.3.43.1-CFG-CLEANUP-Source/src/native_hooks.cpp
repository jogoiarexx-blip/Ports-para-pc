#include "generated.hpp"
void forja65_register_native_hooks(SnesRuntime&hw){(void)hw;}
