#include "generated.hpp"
void sub_6080A7_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x60802Cu: goto L_60802C;
    case 0x60802Fu: goto L_60802F;
    case 0x608030u: goto L_608030;
    case 0x608031u: goto L_608031;
    case 0x608033u: goto L_608033;
    case 0x608036u: goto L_608036;
    case 0x608039u: goto L_608039;
    case 0x60803Au: goto L_60803A;
    case 0x60803Bu: goto L_60803B;
    case 0x60803Du: goto L_60803D;
    case 0x608040u: goto L_608040;
    case 0x608041u: goto L_608041;
    case 0x608043u: goto L_608043;
    case 0x608046u: goto L_608046;
    case 0x608049u: goto L_608049;
    case 0x60804Bu: goto L_60804B;
    case 0x60804Eu: goto L_60804E;
    case 0x608050u: goto L_608050;
    case 0x608053u: goto L_608053;
    case 0x608055u: goto L_608055;
    case 0x608057u: goto L_608057;
    case 0x608059u: goto L_608059;
    case 0x60805Bu: goto L_60805B;
    case 0x60805Fu: goto L_60805F;
    case 0x608061u: goto L_608061;
    case 0x608065u: goto L_608065;
    case 0x608069u: goto L_608069;
    case 0x60806Bu: goto L_60806B;
    case 0x60806Fu: goto L_60806F;
    case 0x608073u: goto L_608073;
    case 0x608076u: goto L_608076;
    case 0x608078u: goto L_608078;
    case 0x60807Bu: goto L_60807B;
    case 0x60807Cu: goto L_60807C;
    case 0x60807Eu: goto L_60807E;
    case 0x608080u: goto L_608080;
    case 0x608083u: goto L_608083;
    case 0x608085u: goto L_608085;
    case 0x608089u: goto L_608089;
    case 0x60808Du: goto L_60808D;
    case 0x608090u: goto L_608090;
    case 0x608093u: goto L_608093;
    case 0x608095u: goto L_608095;
    case 0x608099u: goto L_608099;
    case 0x60809Du: goto L_60809D;
    case 0x6080A1u: goto L_6080A1;
    case 0x6080A3u: goto L_6080A3;
    case 0x6080A6u: goto L_6080A6;
    case 0x6080A7u: goto L_6080A7;
    case 0x6080A8u: goto L_6080A8;
    case 0x6080A9u: goto L_6080A9;
    case 0x6080AAu: goto L_6080AA;
    case 0x6080ADu: goto L_6080AD;
    case 0x6080AEu: goto L_6080AE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_60802C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x802Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x802Cu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x802Cu, 6u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60802C STZ
    hw.write(cpu.address("absx", 0x0u), 0, cpu.m8?8:16);
    goto L_60802F;
L_60802F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x802Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x802Fu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x802Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60802F DEX
    cpu.decReg('X');
    goto L_608030;
L_608030:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8030u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8030u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8030u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608030 DEX
    cpu.decReg('X');
    goto L_608031;
L_608031:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8031u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8031u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8031u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608031 BPL -> $60802C
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_60802C; }
    goto L_608033;
L_608033:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8033u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8033u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8033u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608033 LDX
    cpu.setX(0x7FEu, 16);
    goto L_608036;
L_608036:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8036u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8036u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8036u, 6u, 3u, cpu.address("absx", 0x1800u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608036 STZ
    hw.write(cpu.address("absx", 0x1800u), 0, cpu.m8?8:16);
    goto L_608039;
L_608039:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8039u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8039u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8039u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608039 DEX
    cpu.decReg('X');
    goto L_60803A;
L_60803A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x803Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x803Au,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x803Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60803A DEX
    cpu.decReg('X');
    goto L_60803B;
L_60803B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x803Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x803Bu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x803Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60803B BPL -> $608036
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_608036; }
    goto L_60803D;
L_60803D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x803Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x803Du,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x803Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60803D LDX
    cpu.setX(0x1FF0u, 16);
    goto L_608040;
L_608040:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8040u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8040u,cpu,0x9Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8040u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608040 TXS
    cpu.transfer("TXS");
    goto L_608041;
L_608041:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8041u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8041u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8041u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608041 REP
    cpu.rep(0x20u);
    goto L_608043;
L_608043:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8043u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8043u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8043u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608043 LDA
    cpu.setA(0x1u, 16);
    goto L_608046;
L_608046:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8046u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8046u,cpu,0x0Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8046u, 8u, 3u, cpu.address("abs", 0x019Fu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608046 TSB
    cpu.tsb(hw, cpu.address("abs", 0x19Fu), cpu.m8?8:16);
    goto L_608049;
L_608049:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8049u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8049u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8049u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608049 SEP
    cpu.sep(0x20u);
    goto L_60804B;
L_60804B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x804Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x804Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x804Bu, 6u, 3u, cpu.address("abs", 0x8111u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $60804B JSR -> $608111 stack real
    { cpu.push16Value(hw,0x804Du); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x804Eu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8111u), 0x60804Bu); }
    goto L_60804E;
L_60804E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x804Eu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x804Eu,0x60804Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x804Eu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x804Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60804E SEP
    cpu.sep(0x20u);
    goto L_608050;
L_608050:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8050u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8050u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8050u, 4u, 3u, cpu.address("abs", 0x213Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608050 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x213Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_608053;
L_608053:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8053u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8053u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8053u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608053 BIT
    cpu.bit(0x10u, true);
    goto L_608055;
L_608055:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8055u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8055u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8055u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608055 BEQ -> $60805B
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_60805B; }
    goto L_608057;
L_608057:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8057u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8057u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8057u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608057 LDA
    cpu.setA(0x83u, 8);
    goto L_608059;
L_608059:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8059u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8059u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8059u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608059 BRA -> $60805F
    goto L_60805F;
L_60805B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x805Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x805Bu,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x805Bu, 5u, 4u, 0x808000u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60805B LDA
    cpu.loadA(hw.readW(0x808000u, cpu.m8?8:16), cpu.m8?8:16);
    goto L_60805F;
L_60805F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x805Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x805Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x805Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x46u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60805F STA
    hw.write(cpu.address("dp", 0x46u), cpu.a, cpu.m8?8:16);
    goto L_608061;
L_608061:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8061u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8061u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8061u, 8u, 4u, 0x808580u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $608061 JSL -> $808580 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8064u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8065u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808580u, 0x608061u); }
    goto L_608065;
L_608065:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8065u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8065u,0x608065u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8065u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8065u, 8u, 4u, 0x82BB9Au, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $608065 JSL -> $82BB9A stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8068u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8069u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82BB9Au, 0x608065u); }
    goto L_608069;
L_608069:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8069u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8069u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8069u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608069 SEP
    cpu.sep(0x24u);
    goto L_60806B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8069u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8069u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608069 SEP
    cpu.sep(0x24u);
    goto L_60806B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8069u,0x608069u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_60806B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x806Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x806Bu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x806Bu, 8u, 4u, 0x808556u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $60806B JSL -> $808556 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x806Eu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x806Fu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808556u, 0x60806Bu); }
    goto L_60806F;
L_60806F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x806Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x806Fu,0x60806Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x806Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x806Fu, 8u, 4u, 0x808572u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $60806F JSL -> $808572 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8072u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8073u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808572u, 0x60806Fu); }
    goto L_608073;
L_608073:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8073u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8073u,0x608073u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8073u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8073u, 4u, 3u, cpu.address("abs", 0x420Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608073 STZ
    hw.write(cpu.address("abs", 0x420Cu), 0, cpu.m8?8:16);
    goto L_608076;
L_608076:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8076u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8076u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8076u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xB4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608076 STZ
    hw.write(cpu.address("dp", 0xB4u), 0, cpu.m8?8:16);
    goto L_608078;
L_608078:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8078u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8078u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8078u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608078 LDX
    cpu.setX(0x1FF0u, 16);
    goto L_60807B;
L_60807B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x807Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x807Bu,cpu,0x9Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x807Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60807B TXS
    cpu.transfer("TXS");
    goto L_60807C;
L_60807C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x807Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x807Cu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x807Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60807C STZ
    hw.write(cpu.address("dp", 0x96u), 0, cpu.m8?8:16);
    goto L_60807E;
L_60807E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x807Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x807Eu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x807Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x97u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60807E STZ
    hw.write(cpu.address("dp", 0x97u), 0, cpu.m8?8:16);
    goto L_608080;
L_608080:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8080u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8080u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8080u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608080 LDX
    cpu.setX(0x200u, 16);
    goto L_608083;
L_608083:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8083u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8083u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8083u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x98u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608083 STX
    hw.write(cpu.address("dp", 0x98u), cpu.x, cpu.x8?8:16);
    goto L_608085;
L_608085:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8085u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8085u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8085u, 8u, 4u, 0x808ADEu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $608085 JSL -> $808ADE stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8088u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8089u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808ADEu, 0x608085u); }
    goto L_608089;
L_608089:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8089u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8089u,0x608089u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8089u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8089u, 8u, 4u, 0x808B92u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $608089 JSL -> $808B92 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x808Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x808Du,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808B92u, 0x608089u); }
    goto L_60808D;
L_60808D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x808Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x808Du,0x60808Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x808Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x808Du, 6u, 3u, cpu.address("abs", 0x82A7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $60808D JSR -> $6082A7 stack real
    { cpu.push16Value(hw,0x808Fu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8090u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x82A7u), 0x60808Du); }
    goto L_608090;
L_608090:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8090u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8090u,0x608090u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8090u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8090u, 6u, 3u, cpu.address("abs", 0x85ADu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $608090 JSR -> $6085AD stack real
    { cpu.push16Value(hw,0x8092u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8093u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x85ADu), 0x608090u); }
    goto L_608093;
L_608093:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8093u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8093u,0x608093u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8093u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8093u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608093 STZ
    hw.write(cpu.address("dp", 0x4Bu), 0, cpu.m8?8:16);
    goto L_608095;
L_608095:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8095u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8095u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8095u, 8u, 4u, 0x808547u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $608095 JSL -> $808547 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8098u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8099u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808547u, 0x608095u); }
    goto L_608099;
L_608099:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8099u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8099u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8099u, 8u, 4u, 0x808D03u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $608099 JSL -> $808D03 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x809Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x809Du,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808D03u, 0x608099u); }
    goto L_60809D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8099u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8099u, 8u, 4u, 0x808D03u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $608099 JSL -> $808D03 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x809Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x809Du,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808D03u, 0x608099u); }
    goto L_60809D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8099u,0x608099u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_60809D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x809Du))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x809Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x809Du, 8u, 4u, 0x8096A3u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $60809D JSL -> $8096A3 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80A0u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80A1u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8096A3u, 0x60809Du); }
    goto L_6080A1;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x809Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x809Du, 8u, 4u, 0x8096A3u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $60809D JSL -> $8096A3 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80A0u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80A1u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8096A3u, 0x60809Du); }
    goto L_6080A1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x809Du,0x60809Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_6080A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A1u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80A1u,0x6080A1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A1u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6080A1 SEP
    cpu.sep(0x20u);
    goto L_6080A3;
L_6080A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A3u, 6u, 3u, cpu.address("abs", 0x83A4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $6080A3 JSR -> $6083A4 stack real
    { cpu.push16Value(hw,0x80A5u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80A6u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x83A4u), 0x6080A3u); }
    goto L_6080A6;
L_6080A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A6u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x46u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6080A6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x46u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_6080A8;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x46u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6080A6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x46u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_6080A8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80A6u,0x6080A6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_6080A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A7u,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A7u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6080A7 LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x10u), cpu.m8?8:16);
    goto L_6080A9;
L_6080A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A8u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A8u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6080A8 BPL -> $608099
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_608099; }
    goto L_6080AA;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A8u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6080A8 BPL -> $608099
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_608099; }
    goto L_6080AA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80A8u,0x6080A8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_6080A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A9u,cpu,0xEFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A9u, 6u, 4u, 0x855622u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6080A9 SBC
    cpu.sbc(hw.readW(0x855622u, cpu.m8?8:16));
    goto L_6080AD;
L_6080AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80AAu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80AAu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80AAu, 8u, 4u, 0x808556u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $6080AA JSL -> $808556 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80ADu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80AEu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808556u, 0x6080AAu); }
    goto L_6080AE;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80AAu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80AAu, 8u, 4u, 0x808556u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $6080AA JSL -> $808556 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80ADu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80AEu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808556u, 0x6080AAu); }
    goto L_6080AE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80AAu,0x6080AAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_6080AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80ADu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80ADu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6080AD BRA -> $60802F
    goto L_60802F;
L_6080AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80AEu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80AEu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80AEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6080AE BRA -> $608069
    goto L_608069;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80AEu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80AEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6080AE BRA -> $608069
    goto L_608069;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80AEu,0x6080AEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_808EBF_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808EBFu: goto L_808EBF;
    case 0x808EC0u: goto L_808EC0;
    case 0x808EC1u: goto L_808EC1;
    case 0x808EC2u: goto L_808EC2;
    case 0x808EC3u: goto L_808EC3;
    case 0x808EC7u: goto L_808EC7;
    case 0x808ECAu: goto L_808ECA;
    case 0x808ECDu: goto L_808ECD;
    case 0x808ED0u: goto L_808ED0;
    case 0x808ED3u: goto L_808ED3;
    case 0x808ED4u: goto L_808ED4;
    case 0x808ED7u: goto L_808ED7;
    case 0x808ED8u: goto L_808ED8;
    case 0x808EDBu: goto L_808EDB;
    case 0x808EDCu: goto L_808EDC;
    case 0x808EDFu: goto L_808EDF;
    case 0x808EE0u: goto L_808EE0;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808EBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EBFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EBFu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EBFu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808EBF PHP
    cpu.push("PHP", hw);
    goto L_808EC0;
L_808EC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC0u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC0u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808EC0 PHA
    cpu.push("PHA", hw);
    goto L_808EC1;
L_808EC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC1u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC1u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808EC1 PHX
    cpu.push("PHX", hw);
    goto L_808EC2;
L_808EC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC2u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC2u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808EC2 PHY
    cpu.push("PHY", hw);
    goto L_808EC3;
L_808EC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC3u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC3u, 8u, 4u, 0x808B7Cu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808EC3 JSL -> $808B7C stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8EC6u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8EC7u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808B7Cu, 0x808EC3u); }
    goto L_808EC7;
L_808EC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EC7u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8EC7u,0x808EC7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808EC7 LDA
    cpu.setA(0x7Eu, 16);
    goto L_808ECA;
L_808ECA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ECAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ECAu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ECAu, 6u, 3u, cpu.address("absx", 0x1805u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808ECA STA
    hw.write(cpu.address("absx", 0x1805u), cpu.a, cpu.m8?8:16);
    goto L_808ECD;
L_808ECD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ECDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ECDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ECDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808ECD LDA
    cpu.setA(0x80u, 16);
    goto L_808ED0;
L_808ED0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ED0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED0u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED0u, 6u, 3u, cpu.address("absx", 0x1800u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808ED0 STA
    hw.write(cpu.address("absx", 0x1800u), cpu.a, cpu.m8?8:16);
    goto L_808ED3;
L_808ED3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ED3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED3u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED3u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808ED3 PLA
    cpu.pop("PLA", hw);
    goto L_808ED4;
L_808ED4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ED4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED4u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED4u, 6u, 3u, cpu.address("absx", 0x1801u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808ED4 STA
    hw.write(cpu.address("absx", 0x1801u), cpu.a, cpu.m8?8:16);
    goto L_808ED7;
L_808ED7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ED7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED7u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED7u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808ED7 PLA
    cpu.pop("PLA", hw);
    goto L_808ED8;
L_808ED8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ED8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED8u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED8u, 6u, 3u, cpu.address("absx", 0x1803u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808ED8 STA
    hw.write(cpu.address("absx", 0x1803u), cpu.a, cpu.m8?8:16);
    goto L_808EDB;
L_808EDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EDBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDBu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDBu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808EDB PLA
    cpu.pop("PLA", hw);
    goto L_808EDC;
L_808EDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDCu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDCu, 6u, 3u, cpu.address("absx", 0x1806u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808EDC STA
    hw.write(cpu.address("absx", 0x1806u), cpu.a, cpu.m8?8:16);
    goto L_808EDF;
L_808EDF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EDFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDFu,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDFu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808EDF PLP
    cpu.pop("PLP", hw);
    goto L_808EE0;
L_808EE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EE0u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8EE0u,0x808EE0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE0u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808EE0 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808EE0u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x808EE0u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_808EBF_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808EBFu: goto L_808EBF;
    case 0x808EC0u: goto L_808EC0;
    case 0x808EC1u: goto L_808EC1;
    case 0x808EC2u: goto L_808EC2;
    case 0x808EC3u: goto L_808EC3;
    case 0x808EC7u: goto L_808EC7;
    case 0x808ECAu: goto L_808ECA;
    case 0x808ECDu: goto L_808ECD;
    case 0x808ED0u: goto L_808ED0;
    case 0x808ED3u: goto L_808ED3;
    case 0x808ED4u: goto L_808ED4;
    case 0x808ED7u: goto L_808ED7;
    case 0x808ED8u: goto L_808ED8;
    case 0x808EDBu: goto L_808EDB;
    case 0x808EDCu: goto L_808EDC;
    case 0x808EDFu: goto L_808EDF;
    case 0x808EE0u: goto L_808EE0;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808EBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EBFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EBFu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EBFu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808EBF PHP
    cpu.push("PHP", hw);
    goto L_808EC0;
L_808EC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC0u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC0u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808EC0 PHA
    cpu.push("PHA", hw);
    goto L_808EC1;
L_808EC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC1u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC1u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808EC1 PHX
    cpu.push("PHX", hw);
    goto L_808EC2;
L_808EC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC2u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC2u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808EC2 PHY
    cpu.push("PHY", hw);
    goto L_808EC3;
L_808EC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC3u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC3u, 8u, 4u, 0x808B7Cu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808EC3 JSL -> $808B7C stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8EC6u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8EC7u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808B7Cu, 0x808EC3u); }
    goto L_808EC7;
L_808EC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EC7u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8EC7u,0x808EC7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808EC7 LDA
    cpu.setA(0x7Eu, 16);
    goto L_808ECA;
L_808ECA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ECAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ECAu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ECAu, 6u, 3u, cpu.address("absx", 0x1805u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808ECA STA
    hw.write(cpu.address("absx", 0x1805u), cpu.a, cpu.m8?8:16);
    goto L_808ECD;
L_808ECD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ECDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ECDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ECDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808ECD LDA
    cpu.setA(0x80u, 16);
    goto L_808ED0;
L_808ED0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ED0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED0u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED0u, 6u, 3u, cpu.address("absx", 0x1800u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808ED0 STA
    hw.write(cpu.address("absx", 0x1800u), cpu.a, cpu.m8?8:16);
    goto L_808ED3;
L_808ED3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ED3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED3u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED3u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808ED3 PLA
    cpu.pop("PLA", hw);
    goto L_808ED4;
L_808ED4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ED4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED4u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED4u, 6u, 3u, cpu.address("absx", 0x1801u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808ED4 STA
    hw.write(cpu.address("absx", 0x1801u), cpu.a, cpu.m8?8:16);
    goto L_808ED7;
L_808ED7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ED7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED7u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED7u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808ED7 PLA
    cpu.pop("PLA", hw);
    goto L_808ED8;
L_808ED8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ED8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED8u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED8u, 6u, 3u, cpu.address("absx", 0x1803u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808ED8 STA
    hw.write(cpu.address("absx", 0x1803u), cpu.a, cpu.m8?8:16);
    goto L_808EDB;
L_808EDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EDBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDBu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDBu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808EDB PLA
    cpu.pop("PLA", hw);
    goto L_808EDC;
L_808EDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDCu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDCu, 6u, 3u, cpu.address("absx", 0x1806u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808EDC STA
    hw.write(cpu.address("absx", 0x1806u), cpu.a, cpu.m8?8:16);
    goto L_808EDF;
L_808EDF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EDFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDFu,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDFu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808EDF PLP
    cpu.pop("PLP", hw);
    goto L_808EE0;
L_808EE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EE0u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8EE0u,0x808EE0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE0u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808EE0 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808EE0u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x808EE0u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_808EBF_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808EBFu: goto L_808EBF;
    case 0x808EC0u: goto L_808EC0;
    case 0x808EC1u: goto L_808EC1;
    case 0x808EC2u: goto L_808EC2;
    case 0x808EC3u: goto L_808EC3;
    case 0x808EC7u: goto L_808EC7;
    case 0x808ECAu: goto L_808ECA;
    case 0x808ECDu: goto L_808ECD;
    case 0x808ED0u: goto L_808ED0;
    case 0x808ED3u: goto L_808ED3;
    case 0x808ED4u: goto L_808ED4;
    case 0x808ED7u: goto L_808ED7;
    case 0x808ED8u: goto L_808ED8;
    case 0x808EDBu: goto L_808EDB;
    case 0x808EDCu: goto L_808EDC;
    case 0x808EDFu: goto L_808EDF;
    case 0x808EE0u: goto L_808EE0;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808EBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EBFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EBFu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EBFu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808EBF PHP
    cpu.push("PHP", hw);
    goto L_808EC0;
L_808EC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC0u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC0u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808EC0 PHA
    cpu.push("PHA", hw);
    goto L_808EC1;
L_808EC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC1u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC1u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808EC1 PHX
    cpu.push("PHX", hw);
    goto L_808EC2;
L_808EC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC2u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC2u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808EC2 PHY
    cpu.push("PHY", hw);
    goto L_808EC3;
L_808EC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC3u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC3u, 8u, 4u, 0x808B7Cu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808EC3 JSL -> $808B7C stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8EC6u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8EC7u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808B7Cu, 0x808EC3u); }
    goto L_808EC7;
L_808EC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EC7u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8EC7u,0x808EC7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808EC7 LDA
    cpu.setA(0x7Eu, 16);
    goto L_808ECA;
L_808ECA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ECAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ECAu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ECAu, 6u, 3u, cpu.address("absx", 0x1805u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808ECA STA
    hw.write(cpu.address("absx", 0x1805u), cpu.a, cpu.m8?8:16);
    goto L_808ECD;
L_808ECD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ECDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ECDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ECDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808ECD LDA
    cpu.setA(0x80u, 16);
    goto L_808ED0;
L_808ED0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ED0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED0u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED0u, 6u, 3u, cpu.address("absx", 0x1800u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808ED0 STA
    hw.write(cpu.address("absx", 0x1800u), cpu.a, cpu.m8?8:16);
    goto L_808ED3;
L_808ED3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ED3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED3u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED3u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808ED3 PLA
    cpu.pop("PLA", hw);
    goto L_808ED4;
L_808ED4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ED4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED4u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED4u, 6u, 3u, cpu.address("absx", 0x1801u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808ED4 STA
    hw.write(cpu.address("absx", 0x1801u), cpu.a, cpu.m8?8:16);
    goto L_808ED7;
L_808ED7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ED7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED7u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED7u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808ED7 PLA
    cpu.pop("PLA", hw);
    goto L_808ED8;
L_808ED8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ED8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED8u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED8u, 6u, 3u, cpu.address("absx", 0x1803u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808ED8 STA
    hw.write(cpu.address("absx", 0x1803u), cpu.a, cpu.m8?8:16);
    goto L_808EDB;
L_808EDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EDBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDBu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDBu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808EDB PLA
    cpu.pop("PLA", hw);
    goto L_808EDC;
L_808EDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDCu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDCu, 6u, 3u, cpu.address("absx", 0x1806u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808EDC STA
    hw.write(cpu.address("absx", 0x1806u), cpu.a, cpu.m8?8:16);
    goto L_808EDF;
L_808EDF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EDFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDFu,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDFu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808EDF PLP
    cpu.pop("PLP", hw);
    goto L_808EE0;
L_808EE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EE0u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8EE0u,0x808EE0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE0u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808EE0 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808EE0u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x808EE0u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_809022_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809022u: goto L_809022;
    case 0x809023u: goto L_809023;
    case 0x809024u: goto L_809024;
    case 0x809026u: goto L_809026;
    case 0x809029u: goto L_809029;
    case 0x80902Bu: goto L_80902B;
    case 0x80902Du: goto L_80902D;
    case 0x80902Fu: goto L_80902F;
    case 0x809031u: goto L_809031;
    case 0x809033u: goto L_809033;
    case 0x809034u: goto L_809034;
    case 0x809035u: goto L_809035;
    case 0x809038u: goto L_809038;
    case 0x80903Au: goto L_80903A;
    case 0x80903Bu: goto L_80903B;
    case 0x80903Cu: goto L_80903C;
    case 0x80903Fu: goto L_80903F;
    case 0x809041u: goto L_809041;
    case 0x809043u: goto L_809043;
    case 0x809045u: goto L_809045;
    case 0x809048u: goto L_809048;
    case 0x80904Au: goto L_80904A;
    case 0x80904Bu: goto L_80904B;
    case 0x80904Du: goto L_80904D;
    case 0x80904Fu: goto L_80904F;
    case 0x809051u: goto L_809051;
    case 0x809053u: goto L_809053;
    case 0x809055u: goto L_809055;
    case 0x809058u: goto L_809058;
    case 0x80905Cu: goto L_80905C;
    case 0x80905Du: goto L_80905D;
    case 0x80905Eu: goto L_80905E;
    case 0x809060u: goto L_809060;
    case 0x809063u: goto L_809063;
    case 0x809065u: goto L_809065;
    case 0x809066u: goto L_809066;
    case 0x809067u: goto L_809067;
    case 0x809069u: goto L_809069;
    case 0x80906Bu: goto L_80906B;
    case 0x80906Eu: goto L_80906E;
    case 0x80906Fu: goto L_80906F;
    case 0x809070u: goto L_809070;
    case 0x809071u: goto L_809071;
    case 0x809072u: goto L_809072;
    case 0x809073u: goto L_809073;
    case 0x809074u: goto L_809074;
    case 0x809075u: goto L_809075;
    case 0x809077u: goto L_809077;
    case 0x809078u: goto L_809078;
    case 0x809079u: goto L_809079;
    case 0x80907Bu: goto L_80907B;
    case 0x80907Du: goto L_80907D;
    case 0x80907Fu: goto L_80907F;
    case 0x809081u: goto L_809081;
    case 0x809083u: goto L_809083;
    case 0x809085u: goto L_809085;
    case 0x809089u: goto L_809089;
    case 0x80908Au: goto L_80908A;
    case 0x80908Cu: goto L_80908C;
    case 0x80908Eu: goto L_80908E;
    case 0x809090u: goto L_809090;
    case 0x809092u: goto L_809092;
    case 0x809095u: goto L_809095;
    case 0x809097u: goto L_809097;
    case 0x809098u: goto L_809098;
    case 0x80909Au: goto L_80909A;
    case 0x80909Bu: goto L_80909B;
    case 0x80909Du: goto L_80909D;
    case 0x80909Eu: goto L_80909E;
    case 0x80909Fu: goto L_80909F;
    case 0x8090A2u: goto L_8090A2;
    case 0x8090A5u: goto L_8090A5;
    case 0x8090A6u: goto L_8090A6;
    case 0x8090A7u: goto L_8090A7;
    case 0x8090A9u: goto L_8090A9;
    case 0x8090ABu: goto L_8090AB;
    case 0x8090ACu: goto L_8090AC;
    case 0x8090ADu: goto L_8090AD;
    case 0x8090AFu: goto L_8090AF;
    case 0x8090B1u: goto L_8090B1;
    case 0x8090B2u: goto L_8090B2;
    case 0x8090B3u: goto L_8090B3;
    case 0x8090B5u: goto L_8090B5;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809022:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9022u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9022u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9022u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809022 PHP
    cpu.push("PHP", hw);
    goto L_809023;
L_809023:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9023u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9023u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9023u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809023 PHB
    cpu.push("PHB", hw);
    goto L_809024;
L_809024:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9024u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9024u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9024u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809024 SEP
    cpu.sep(0x20u);
    goto L_809026;
L_809026:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9026u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9026u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9026u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809026 LDX
    cpu.setX(0x8000u, 16);
    goto L_809029;
L_809029:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9029u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9029u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9029u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xB9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809029 STX
    hw.write(cpu.address("dp", 0xB9u), cpu.x, cpu.x8?8:16);
    goto L_80902B;
L_80902B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x902Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x902Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x902Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80902B LDA
    cpu.setA(0x7Eu, 8);
    goto L_80902D;
L_80902D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x902Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x902Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x902Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xBBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80902D STA
    hw.write(cpu.address("dp", 0xBBu), cpu.a, cpu.m8?8:16);
    goto L_80902F;
L_80902F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x902Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x902Fu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x902Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xB5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80902F LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xB5u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_809031;
L_809031:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9031u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9031u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9031u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xB7u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809031 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xB7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809033;
L_809033:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9033u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9033u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9033u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809033 PHA
    cpu.push("PHA", hw);
    goto L_809034;
L_809034:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9034u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9034u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9034u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809034 PLB
    cpu.pop("PLB", hw);
    goto L_809035;
L_809035:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9035u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9035u,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9035u, 5u + 1u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809035 LDX
    cpu.setX(hw.readW(cpu.address("absy", 0x0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_809038;
L_809038:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9038u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9038u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9038u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xBDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809038 STX
    hw.write(cpu.address("dp", 0xBDu), cpu.x, cpu.x8?8:16);
    goto L_80903A;
L_80903A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x903Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x903Au,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x903Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80903A INY
    cpu.inc('Y');
    goto L_80903B;
L_80903B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x903Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x903Bu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x903Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80903B INY
    cpu.inc('Y');
    goto L_80903C;
L_80903C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x903Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x903Cu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x903Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80903C LDX
    cpu.setX(0x0u, 16);
    goto L_80903F;
L_80903F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x903Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x903Fu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x903Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80903F STZ
    hw.write(cpu.address("dp", 0xC0u), 0, cpu.m8?8:16);
    goto L_809041;
L_809041:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9041u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9041u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9041u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809041 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xC0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809043;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9041u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9041u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809041 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xC0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809043;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9041u,0x809041u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809043:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9043u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9043u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9043u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809043 BNE -> $80904F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80904F; }
    goto L_809045;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9043u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9043u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809043 BNE -> $80904F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80904F; }
    goto L_809045;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9043u,0x809043u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809045:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9045u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9045u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9045u, 4u + 1u, 3u, cpu.address("absy", 0x0000u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809045 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809048;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9045u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9045u, 4u + 1u, 3u, cpu.address("absy", 0x0000u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809045 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809048;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9045u,0x809045u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809048:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9048u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9048u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9048u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xBFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809048 STA
    hw.write(cpu.address("dp", 0xBFu), cpu.a, cpu.m8?8:16);
    goto L_80904A;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9048u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9048u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xBFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809048 STA
    hw.write(cpu.address("dp", 0xBFu), cpu.a, cpu.m8?8:16);
    goto L_80904A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9048u,0x809048u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80904A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x904Au))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x904Au,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x904Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80904A INY
    cpu.inc('Y');
    goto L_80904B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x904Au,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x904Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80904A INY
    cpu.inc('Y');
    goto L_80904B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x904Au,0x80904Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80904B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x904Bu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x904Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x904Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80904B LDA
    cpu.setA(0x8u, 8);
    goto L_80904D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x904Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x904Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80904B LDA
    cpu.setA(0x8u, 8);
    goto L_80904D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x904Bu,0x80904Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80904D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x904Du))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x904Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x904Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80904D STA
    hw.write(cpu.address("dp", 0xC0u), cpu.a, cpu.m8?8:16);
    goto L_80904F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x904Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x904Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80904D STA
    hw.write(cpu.address("dp", 0xC0u), cpu.a, cpu.m8?8:16);
    goto L_80904F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x904Du,0x80904Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80904F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x904Fu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x904Fu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x904Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80904F DEC
    cpu.decMem(hw, cpu.address("dp", 0xC0u), cpu.m8?8:16);
    goto L_809051;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x904Fu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x904Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80904F DEC
    cpu.decMem(hw, cpu.address("dp", 0xC0u), cpu.m8?8:16);
    goto L_809051;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x904Fu,0x80904Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809051:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9051u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9051u,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9051u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xBFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809051 LSR
    cpu.lsrMem(hw, cpu.address("dp", 0xBFu), cpu.m8?8:16);
    goto L_809053;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9051u,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9051u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xBFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809051 LSR
    cpu.lsrMem(hw, cpu.address("dp", 0xBFu), cpu.m8?8:16);
    goto L_809053;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9051u,0x809051u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809053:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9053u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9053u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9053u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809053 BCC -> $809060
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_809060; }
    goto L_809055;
L_809055:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9055u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9055u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9055u, 4u + 1u, 3u, cpu.address("absy", 0x0000u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809055 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809058;
L_809058:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9058u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9058u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9058u, 5u, 4u, ((0x7E8000u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809058 STA
    hw.write(((0x7E8000u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80905C;
L_80905C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x905Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x905Cu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x905Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80905C INY
    cpu.inc('Y');
    goto L_80905D;
L_80905D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x905Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x905Du,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x905Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80905D INX
    cpu.inc('X');
    goto L_80905E;
L_80905E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x905Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x905Eu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x905Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80905E BRA -> $8090AD
    goto L_8090AD;
L_809060:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9060u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9060u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9060u, 4u + 1u, 3u, cpu.address("absy", 0x0000u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809060 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809063;
L_809063:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9063u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9063u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9063u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809063 AND
    cpu.logicAnd(0xFu);
    goto L_809065;
L_809065:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9065u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9065u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9065u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809065 INC
    cpu.inc('A');
    goto L_809066;
L_809066:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9066u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9066u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9066u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809066 INC
    cpu.inc('A');
    goto L_809067;
L_809067:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9067u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9067u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9067u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809067 STA
    hw.write(cpu.address("dp", 0xC1u), cpu.a, cpu.m8?8:16);
    goto L_809069;
L_809069:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9069u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9069u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9069u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809069 REP
    cpu.rep(0x20u);
    goto L_80906B;
L_80906B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x906Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x906Bu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x906Bu, 5u + 1u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80906B LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80906E;
L_80906E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x906Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x906Eu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x906Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80906E INY
    cpu.inc('Y');
    goto L_80906F;
L_80906F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x906Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x906Fu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x906Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80906F INY
    cpu.inc('Y');
    goto L_809070;
L_809070:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9070u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9070u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9070u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809070 PHY
    cpu.push("PHY", hw);
    goto L_809071;
L_809071:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9071u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9071u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9071u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809071 LSR
    cpu.lsrA();
    goto L_809072;
L_809072:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9072u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9072u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9072u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809072 LSR
    cpu.lsrA();
    goto L_809073;
L_809073:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9073u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9073u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9073u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809073 LSR
    cpu.lsrA();
    goto L_809074;
L_809074:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9074u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9074u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9074u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809074 LSR
    cpu.lsrA();
    goto L_809075;
L_809075:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9075u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9075u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9075u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC3u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809075 STA
    hw.write(cpu.address("dp", 0xC3u), cpu.a, cpu.m8?8:16);
    goto L_809077;
L_809077:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9077u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9077u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9077u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809077 TXA
    cpu.transfer("TXA");
    goto L_809078;
L_809078:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9078u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9078u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9078u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809078 SEC
    cpu.setFlag('C', true);
    goto L_809079;
L_809079:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9079u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9079u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9079u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC3u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809079 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0xC3u), cpu.m8?8:16));
    goto L_80907B;
L_80907B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x907Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x907Bu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x907Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80907B BPL -> $809097
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_809097; }
    goto L_80907D;
L_80907D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x907Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x907Du,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x907Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80907D SEP
    cpu.sep(0x20u);
    goto L_80907F;
L_80907F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x907Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x907Fu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x907Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80907F EOR
    cpu.logicXor(0xFFu);
    goto L_809081;
L_809081:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9081u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9081u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9081u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809081 STA
    hw.write(cpu.address("dp", 0xC3u), cpu.a, cpu.m8?8:16);
    goto L_809083;
L_809083:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9083u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9083u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9083u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809083 LDA
    cpu.setA(0x0u, 8);
    goto L_809085;
L_809085:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9085u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9085u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9085u, 5u, 4u, ((0x7E8000u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809085 STA
    hw.write(((0x7E8000u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_809089;
L_809089:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9089u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9089u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9089u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809089 INX
    cpu.inc('X');
    goto L_80908A;
L_80908A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x908Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x908Au,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x908Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC1u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80908A DEC
    cpu.decMem(hw, cpu.address("dp", 0xC1u), cpu.m8?8:16);
    goto L_80908C;
L_80908C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x908Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x908Cu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x908Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80908C BMI -> $8090AC
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_8090AC; }
    goto L_80908E;
L_80908E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x908Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x908Eu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x908Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC3u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80908E DEC
    cpu.decMem(hw, cpu.address("dp", 0xC3u), cpu.m8?8:16);
    goto L_809090;
L_809090:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9090u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9090u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9090u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809090 BPL -> $809085
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_809085; }
    goto L_809092;
L_809092:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9092u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9092u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9092u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809092 LDY
    cpu.setY(0x0u, 16);
    goto L_809095;
L_809095:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9095u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9095u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9095u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809095 BRA -> $80909A
    goto L_80909A;
L_809097:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9097u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9097u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9097u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809097 TAY
    cpu.transfer("TAY");
    goto L_809098;
L_809098:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9098u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9098u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9098u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809098 SEP
    cpu.sep(0x20u);
    goto L_80909A;
L_80909A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x909Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x909Au,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x909Au, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80909A PHB
    cpu.push("PHB", hw);
    goto L_80909B;
L_80909B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x909Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x909Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x909Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80909B LDA
    cpu.setA(0x7Eu, 8);
    goto L_80909D;
L_80909D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x909Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x909Du,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x909Du, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80909D PHA
    cpu.push("PHA", hw);
    goto L_80909E;
L_80909E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x909Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x909Eu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x909Eu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80909E PLB
    cpu.pop("PLB", hw);
    goto L_80909F;
L_80909F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x909Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x909Fu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x909Fu, 4u + 1u, 3u, cpu.address("absy", 0x8000u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80909F LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x8000u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8090A2;
L_8090A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90A2u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90A2u, 5u, 3u, cpu.address("absx", 0x8000u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8090A2 STA
    hw.write(cpu.address("absx", 0x8000u), cpu.a, cpu.m8?8:16);
    goto L_8090A5;
L_8090A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90A5u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90A5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8090A5 INX
    cpu.inc('X');
    goto L_8090A6;
L_8090A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90A6u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90A6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8090A6 INY
    cpu.inc('Y');
    goto L_8090A7;
L_8090A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90A7u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90A7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC1u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8090A7 DEC
    cpu.decMem(hw, cpu.address("dp", 0xC1u), cpu.m8?8:16);
    goto L_8090A9;
L_8090A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90A9u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90A9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8090A9 BPL -> $80909F
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80909F; }
    goto L_8090AB;
L_8090AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90ABu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90ABu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8090AB PLB
    cpu.pop("PLB", hw);
    goto L_8090AC;
L_8090AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90ACu,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90ACu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8090AC PLY
    cpu.pop("PLY", hw);
    goto L_8090AD;
L_8090AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90ADu,cpu,0xE4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90ADu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xBDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8090AD CPX
    cpu.compareX(hw.readW(cpu.address("dp", 0xBDu), cpu.x8?8:16));
    goto L_8090AF;
L_8090AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90AFu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90AFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8090AF BCC -> $809041
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_809041; }
    goto L_8090B1;
L_8090B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90B1u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90B1u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8090B1 PLB
    cpu.pop("PLB", hw);
    goto L_8090B2;
L_8090B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90B2u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90B2u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8090B2 PLP
    cpu.pop("PLP", hw);
    goto L_8090B3;
L_8090B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90B3u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x90B3u,0x8090B3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90B3u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90B3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8090B3 REP
    cpu.rep(0x20u);
    goto L_8090B5;
L_8090B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90B5u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90B5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8090B5 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8090B5u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8090B5u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_809022_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809022u: goto L_809022;
    case 0x809023u: goto L_809023;
    case 0x809024u: goto L_809024;
    case 0x809026u: goto L_809026;
    case 0x809029u: goto L_809029;
    case 0x80902Bu: goto L_80902B;
    case 0x80902Du: goto L_80902D;
    case 0x80902Fu: goto L_80902F;
    case 0x809031u: goto L_809031;
    case 0x809033u: goto L_809033;
    case 0x809034u: goto L_809034;
    case 0x809035u: goto L_809035;
    case 0x809038u: goto L_809038;
    case 0x80903Au: goto L_80903A;
    case 0x80903Bu: goto L_80903B;
    case 0x80903Cu: goto L_80903C;
    case 0x80903Fu: goto L_80903F;
    case 0x809041u: goto L_809041;
    case 0x809043u: goto L_809043;
    case 0x809045u: goto L_809045;
    case 0x809048u: goto L_809048;
    case 0x80904Au: goto L_80904A;
    case 0x80904Bu: goto L_80904B;
    case 0x80904Du: goto L_80904D;
    case 0x80904Fu: goto L_80904F;
    case 0x809051u: goto L_809051;
    case 0x809053u: goto L_809053;
    case 0x809055u: goto L_809055;
    case 0x809058u: goto L_809058;
    case 0x80905Cu: goto L_80905C;
    case 0x80905Du: goto L_80905D;
    case 0x80905Eu: goto L_80905E;
    case 0x809060u: goto L_809060;
    case 0x809063u: goto L_809063;
    case 0x809065u: goto L_809065;
    case 0x809066u: goto L_809066;
    case 0x809067u: goto L_809067;
    case 0x809069u: goto L_809069;
    case 0x80906Bu: goto L_80906B;
    case 0x80906Eu: goto L_80906E;
    case 0x80906Fu: goto L_80906F;
    case 0x809070u: goto L_809070;
    case 0x809071u: goto L_809071;
    case 0x809072u: goto L_809072;
    case 0x809073u: goto L_809073;
    case 0x809074u: goto L_809074;
    case 0x809075u: goto L_809075;
    case 0x809077u: goto L_809077;
    case 0x809078u: goto L_809078;
    case 0x809079u: goto L_809079;
    case 0x80907Bu: goto L_80907B;
    case 0x80907Du: goto L_80907D;
    case 0x80907Fu: goto L_80907F;
    case 0x809081u: goto L_809081;
    case 0x809083u: goto L_809083;
    case 0x809085u: goto L_809085;
    case 0x809089u: goto L_809089;
    case 0x80908Au: goto L_80908A;
    case 0x80908Cu: goto L_80908C;
    case 0x80908Eu: goto L_80908E;
    case 0x809090u: goto L_809090;
    case 0x809092u: goto L_809092;
    case 0x809095u: goto L_809095;
    case 0x809097u: goto L_809097;
    case 0x809098u: goto L_809098;
    case 0x80909Au: goto L_80909A;
    case 0x80909Bu: goto L_80909B;
    case 0x80909Du: goto L_80909D;
    case 0x80909Eu: goto L_80909E;
    case 0x80909Fu: goto L_80909F;
    case 0x8090A2u: goto L_8090A2;
    case 0x8090A5u: goto L_8090A5;
    case 0x8090A6u: goto L_8090A6;
    case 0x8090A7u: goto L_8090A7;
    case 0x8090A9u: goto L_8090A9;
    case 0x8090ABu: goto L_8090AB;
    case 0x8090ACu: goto L_8090AC;
    case 0x8090ADu: goto L_8090AD;
    case 0x8090AFu: goto L_8090AF;
    case 0x8090B1u: goto L_8090B1;
    case 0x8090B2u: goto L_8090B2;
    case 0x8090B3u: goto L_8090B3;
    case 0x8090B5u: goto L_8090B5;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809022:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9022u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9022u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9022u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809022 PHP
    cpu.push("PHP", hw);
    goto L_809023;
L_809023:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9023u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9023u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9023u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809023 PHB
    cpu.push("PHB", hw);
    goto L_809024;
L_809024:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9024u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9024u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9024u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809024 SEP
    cpu.sep(0x20u);
    goto L_809026;
L_809026:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9026u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9026u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9026u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809026 LDX
    cpu.setX(0x8000u, 16);
    goto L_809029;
L_809029:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9029u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9029u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9029u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xB9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809029 STX
    hw.write(cpu.address("dp", 0xB9u), cpu.x, cpu.x8?8:16);
    goto L_80902B;
L_80902B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x902Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x902Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x902Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80902B LDA
    cpu.setA(0x7Eu, 8);
    goto L_80902D;
L_80902D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x902Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x902Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x902Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xBBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80902D STA
    hw.write(cpu.address("dp", 0xBBu), cpu.a, cpu.m8?8:16);
    goto L_80902F;
L_80902F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x902Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x902Fu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x902Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xB5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80902F LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xB5u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_809031;
L_809031:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9031u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9031u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9031u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xB7u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809031 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xB7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809033;
L_809033:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9033u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9033u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9033u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809033 PHA
    cpu.push("PHA", hw);
    goto L_809034;
L_809034:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9034u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9034u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9034u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809034 PLB
    cpu.pop("PLB", hw);
    goto L_809035;
L_809035:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9035u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9035u,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9035u, 5u + 1u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809035 LDX
    cpu.setX(hw.readW(cpu.address("absy", 0x0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_809038;
L_809038:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9038u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9038u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9038u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xBDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809038 STX
    hw.write(cpu.address("dp", 0xBDu), cpu.x, cpu.x8?8:16);
    goto L_80903A;
L_80903A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x903Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x903Au,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x903Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80903A INY
    cpu.inc('Y');
    goto L_80903B;
L_80903B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x903Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x903Bu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x903Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80903B INY
    cpu.inc('Y');
    goto L_80903C;
L_80903C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x903Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x903Cu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x903Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80903C LDX
    cpu.setX(0x0u, 16);
    goto L_80903F;
L_80903F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x903Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x903Fu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x903Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80903F STZ
    hw.write(cpu.address("dp", 0xC0u), 0, cpu.m8?8:16);
    goto L_809041;
L_809041:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9041u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9041u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9041u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809041 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xC0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809043;
L_809043:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9043u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9043u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9043u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809043 BNE -> $80904F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80904F; }
    goto L_809045;
L_809045:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9045u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9045u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9045u, 4u + 1u, 3u, cpu.address("absy", 0x0000u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809045 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809048;
L_809048:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9048u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9048u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9048u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xBFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809048 STA
    hw.write(cpu.address("dp", 0xBFu), cpu.a, cpu.m8?8:16);
    goto L_80904A;
L_80904A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x904Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x904Au,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x904Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80904A INY
    cpu.inc('Y');
    goto L_80904B;
L_80904B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x904Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x904Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x904Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80904B LDA
    cpu.setA(0x8u, 8);
    goto L_80904D;
L_80904D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x904Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x904Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x904Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80904D STA
    hw.write(cpu.address("dp", 0xC0u), cpu.a, cpu.m8?8:16);
    goto L_80904F;
L_80904F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x904Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x904Fu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x904Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80904F DEC
    cpu.decMem(hw, cpu.address("dp", 0xC0u), cpu.m8?8:16);
    goto L_809051;
L_809051:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9051u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9051u,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9051u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xBFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809051 LSR
    cpu.lsrMem(hw, cpu.address("dp", 0xBFu), cpu.m8?8:16);
    goto L_809053;
L_809053:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9053u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9053u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9053u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809053 BCC -> $809060
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_809060; }
    goto L_809055;
L_809055:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9055u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9055u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9055u, 4u + 1u, 3u, cpu.address("absy", 0x0000u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809055 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809058;
L_809058:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9058u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9058u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9058u, 5u, 4u, ((0x7E8000u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809058 STA
    hw.write(((0x7E8000u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80905C;
L_80905C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x905Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x905Cu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x905Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80905C INY
    cpu.inc('Y');
    goto L_80905D;
L_80905D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x905Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x905Du,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x905Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80905D INX
    cpu.inc('X');
    goto L_80905E;
L_80905E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x905Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x905Eu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x905Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80905E BRA -> $8090AD
    goto L_8090AD;
L_809060:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9060u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9060u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9060u, 4u + 1u, 3u, cpu.address("absy", 0x0000u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809060 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809063;
L_809063:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9063u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9063u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9063u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809063 AND
    cpu.logicAnd(0xFu);
    goto L_809065;
L_809065:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9065u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9065u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9065u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809065 INC
    cpu.inc('A');
    goto L_809066;
L_809066:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9066u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9066u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9066u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809066 INC
    cpu.inc('A');
    goto L_809067;
L_809067:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9067u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9067u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9067u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809067 STA
    hw.write(cpu.address("dp", 0xC1u), cpu.a, cpu.m8?8:16);
    goto L_809069;
L_809069:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9069u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9069u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9069u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809069 REP
    cpu.rep(0x20u);
    goto L_80906B;
L_80906B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x906Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x906Bu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x906Bu, 5u + 1u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80906B LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80906E;
L_80906E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x906Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x906Eu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x906Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80906E INY
    cpu.inc('Y');
    goto L_80906F;
L_80906F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x906Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x906Fu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x906Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80906F INY
    cpu.inc('Y');
    goto L_809070;
L_809070:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9070u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9070u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9070u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809070 PHY
    cpu.push("PHY", hw);
    goto L_809071;
L_809071:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9071u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9071u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9071u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809071 LSR
    cpu.lsrA();
    goto L_809072;
L_809072:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9072u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9072u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9072u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809072 LSR
    cpu.lsrA();
    goto L_809073;
L_809073:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9073u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9073u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9073u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809073 LSR
    cpu.lsrA();
    goto L_809074;
L_809074:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9074u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9074u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9074u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809074 LSR
    cpu.lsrA();
    goto L_809075;
L_809075:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9075u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9075u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9075u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC3u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809075 STA
    hw.write(cpu.address("dp", 0xC3u), cpu.a, cpu.m8?8:16);
    goto L_809077;
L_809077:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9077u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9077u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9077u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809077 TXA
    cpu.transfer("TXA");
    goto L_809078;
L_809078:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9078u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9078u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9078u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809078 SEC
    cpu.setFlag('C', true);
    goto L_809079;
L_809079:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9079u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9079u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9079u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC3u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809079 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0xC3u), cpu.m8?8:16));
    goto L_80907B;
L_80907B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x907Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x907Bu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x907Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80907B BPL -> $809097
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_809097; }
    goto L_80907D;
L_80907D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x907Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x907Du,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x907Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80907D SEP
    cpu.sep(0x20u);
    goto L_80907F;
L_80907F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x907Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x907Fu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x907Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80907F EOR
    cpu.logicXor(0xFFu);
    goto L_809081;
L_809081:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9081u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9081u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9081u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809081 STA
    hw.write(cpu.address("dp", 0xC3u), cpu.a, cpu.m8?8:16);
    goto L_809083;
L_809083:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9083u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9083u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9083u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809083 LDA
    cpu.setA(0x0u, 8);
    goto L_809085;
L_809085:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9085u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9085u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9085u, 5u, 4u, ((0x7E8000u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809085 STA
    hw.write(((0x7E8000u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_809089;
L_809089:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9089u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9089u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9089u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809089 INX
    cpu.inc('X');
    goto L_80908A;
L_80908A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x908Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x908Au,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x908Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC1u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80908A DEC
    cpu.decMem(hw, cpu.address("dp", 0xC1u), cpu.m8?8:16);
    goto L_80908C;
L_80908C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x908Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x908Cu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x908Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80908C BMI -> $8090AC
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_8090AC; }
    goto L_80908E;
L_80908E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x908Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x908Eu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x908Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC3u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80908E DEC
    cpu.decMem(hw, cpu.address("dp", 0xC3u), cpu.m8?8:16);
    goto L_809090;
L_809090:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9090u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9090u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9090u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809090 BPL -> $809085
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_809085; }
    goto L_809092;
L_809092:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9092u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9092u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9092u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809092 LDY
    cpu.setY(0x0u, 16);
    goto L_809095;
L_809095:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9095u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9095u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9095u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809095 BRA -> $80909A
    goto L_80909A;
L_809097:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9097u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9097u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9097u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809097 TAY
    cpu.transfer("TAY");
    goto L_809098;
L_809098:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9098u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9098u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9098u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809098 SEP
    cpu.sep(0x20u);
    goto L_80909A;
L_80909A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x909Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x909Au,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x909Au, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80909A PHB
    cpu.push("PHB", hw);
    goto L_80909B;
L_80909B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x909Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x909Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x909Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80909B LDA
    cpu.setA(0x7Eu, 8);
    goto L_80909D;
L_80909D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x909Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x909Du,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x909Du, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80909D PHA
    cpu.push("PHA", hw);
    goto L_80909E;
L_80909E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x909Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x909Eu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x909Eu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80909E PLB
    cpu.pop("PLB", hw);
    goto L_80909F;
L_80909F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x909Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x909Fu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x909Fu, 4u + 1u, 3u, cpu.address("absy", 0x8000u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80909F LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x8000u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8090A2;
L_8090A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90A2u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90A2u, 5u, 3u, cpu.address("absx", 0x8000u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8090A2 STA
    hw.write(cpu.address("absx", 0x8000u), cpu.a, cpu.m8?8:16);
    goto L_8090A5;
L_8090A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90A5u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90A5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8090A5 INX
    cpu.inc('X');
    goto L_8090A6;
L_8090A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90A6u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90A6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8090A6 INY
    cpu.inc('Y');
    goto L_8090A7;
L_8090A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90A7u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90A7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC1u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8090A7 DEC
    cpu.decMem(hw, cpu.address("dp", 0xC1u), cpu.m8?8:16);
    goto L_8090A9;
L_8090A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90A9u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90A9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8090A9 BPL -> $80909F
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80909F; }
    goto L_8090AB;
L_8090AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90ABu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90ABu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8090AB PLB
    cpu.pop("PLB", hw);
    goto L_8090AC;
L_8090AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90ACu,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90ACu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8090AC PLY
    cpu.pop("PLY", hw);
    goto L_8090AD;
L_8090AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90ADu,cpu,0xE4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90ADu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xBDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8090AD CPX
    cpu.compareX(hw.readW(cpu.address("dp", 0xBDu), cpu.x8?8:16));
    goto L_8090AF;
L_8090AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90AFu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90AFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8090AF BCC -> $809041
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_809041; }
    goto L_8090B1;
L_8090B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90B1u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90B1u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8090B1 PLB
    cpu.pop("PLB", hw);
    goto L_8090B2;
L_8090B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90B2u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90B2u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8090B2 PLP
    cpu.pop("PLP", hw);
    goto L_8090B3;
L_8090B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90B3u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x90B3u,0x8090B3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90B3u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90B3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8090B3 REP
    cpu.rep(0x20u);
    goto L_8090B5;
L_8090B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90B5u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90B5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8090B5 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8090B5u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8090B5u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80B043_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B043u: goto L_80B043;
    case 0x80B046u: goto L_80B046;
    case 0x80B048u: goto L_80B048;
    case 0x80B04Bu: goto L_80B04B;
    case 0x80B04Eu: goto L_80B04E;
    case 0x80B050u: goto L_80B050;
    case 0x80B053u: goto L_80B053;
    case 0x80B056u: goto L_80B056;
    case 0x80B059u: goto L_80B059;
    case 0x80B05Cu: goto L_80B05C;
    case 0x80B05Fu: goto L_80B05F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B043:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB043u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB043u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB043u, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B043 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x958u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B046;
L_80B046:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB046u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB046u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB046u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B046 BEQ -> $80B059
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B059; }
    goto L_80B048;
L_80B048:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB048u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB048u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB048u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B048 LDX
    cpu.setX(0x3D8u, 16);
    goto L_80B04B;
L_80B04B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB04Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB04Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB04Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B04B LDA
    cpu.setA(0x2u, 16);
    goto L_80B04E;
L_80B04E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB04Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB04Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB04Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B04E STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80B050;
L_80B050:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB050u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB050u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB050u, 8u, 3u, cpu.address("abs", 0x0986u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B050 INC
    cpu.incMem(hw, cpu.address("abs", 0x986u), cpu.m8?8:16);
    goto L_80B053;
L_80B053:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB053u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB053u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB053u, 6u, 3u, cpu.address("abs", 0xC829u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B053 JSR -> $80C829 stack real
    { cpu.push16Value(hw,0xB055u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB056u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC829u), 0x80B053u); }
    goto L_80B056;
L_80B056:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB056u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB056u,0x80B056u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB056u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB056u, 6u, 3u, cpu.address("abs", 0xBBFAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B056 JSR -> $80BBFA stack real
    { cpu.push16Value(hw,0xB058u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB059u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBBFAu), 0x80B056u); }
    goto L_80B059;
L_80B059:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB059u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB059u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB059u, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B059 STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80B05C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB059u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB059u, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B059 STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80B05C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB059u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB059u, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B059 STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80B05C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB059u,0x80B059u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B05C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB05Cu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB05Cu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB05Cu, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B05C INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B05F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB05Cu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB05Cu, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B05C INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B05F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB05Cu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB05Cu, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B05C INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B05F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB05Cu,0x80B05Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B05F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB05Fu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB05Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB05Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B05F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B05Fu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B05Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB05Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB05Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B05F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B05Fu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B05Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB05Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB05Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B05F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B05Fu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B05Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB05Fu,0x80B05Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80B131_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B131u: goto L_80B131;
    case 0x80B134u: goto L_80B134;
    case 0x80B136u: goto L_80B136;
    case 0x80B139u: goto L_80B139;
    case 0x80B13Cu: goto L_80B13C;
    case 0x80B13Eu: goto L_80B13E;
    case 0x80B141u: goto L_80B141;
    case 0x80B144u: goto L_80B144;
    case 0x80B147u: goto L_80B147;
    case 0x80B14Au: goto L_80B14A;
    case 0x80B14Du: goto L_80B14D;
    case 0x80B150u: goto L_80B150;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B131:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB131u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB131u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB131u, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B131 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x958u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B134;
L_80B134:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB134u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB134u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB134u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B134 BEQ -> $80B14A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B14A; }
    goto L_80B136;
L_80B136:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB136u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB136u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB136u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B136 LDX
    cpu.setX(0x380u, 16);
    goto L_80B139;
L_80B139:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB139u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB139u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB139u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B139 LDA
    cpu.setA(0x2u, 16);
    goto L_80B13C;
L_80B13C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB13Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB13Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB13Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B13C STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80B13E;
L_80B13E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB13Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB13Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB13Eu, 5u, 3u, cpu.address("abs", 0x0914u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B13E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x914u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B141;
L_80B141:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB141u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB141u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB141u, 5u, 3u, cpu.address("abs", 0x097Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B141 STA
    hw.write(cpu.address("abs", 0x97Au), cpu.a, cpu.m8?8:16);
    goto L_80B144;
L_80B144:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB144u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB144u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB144u, 8u, 3u, cpu.address("abs", 0x0986u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B144 INC
    cpu.incMem(hw, cpu.address("abs", 0x986u), cpu.m8?8:16);
    goto L_80B147;
L_80B147:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB147u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB147u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB147u, 6u, 3u, cpu.address("abs", 0xC85Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B147 JSR -> $80C85C stack real
    { cpu.push16Value(hw,0xB149u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB14Au,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC85Cu), 0x80B147u); }
    goto L_80B14A;
L_80B14A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB14Au))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB14Au,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB14Au, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B14A STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80B14D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB14Au,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB14Au, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B14A STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80B14D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB14Au,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB14Au, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B14A STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80B14D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB14Au,0x80B14Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B14D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB14Du))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB14Du,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB14Du, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B14D INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B150;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB14Du,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB14Du, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B14D INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B150;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB14Du,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB14Du, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B14D INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B150;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB14Du,0x80B14Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B150:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB150u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB150u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB150u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B150 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B150u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B150u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB150u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB150u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B150 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B150u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B150u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB150u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB150u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B150 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B150u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B150u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB150u,0x80B150u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80B682_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B682u: goto L_80B682;
    case 0x80B684u: goto L_80B684;
    case 0x80B688u: goto L_80B688;
    case 0x80B68Au: goto L_80B68A;
    case 0x80B68Bu: goto L_80B68B;
    case 0x80B68Cu: goto L_80B68C;
    case 0x80B68Fu: goto L_80B68F;
    case 0x80B690u: goto L_80B690;
    case 0x80B692u: goto L_80B692;
    case 0x80B695u: goto L_80B695;
    case 0x80B697u: goto L_80B697;
    case 0x80B69Au: goto L_80B69A;
    case 0x80B69Cu: goto L_80B69C;
    case 0x80B69Fu: goto L_80B69F;
    case 0x80B6A2u: goto L_80B6A2;
    case 0x80B6A4u: goto L_80B6A4;
    case 0x80B6A7u: goto L_80B6A7;
    case 0x80B6AAu: goto L_80B6AA;
    case 0x80B6ACu: goto L_80B6AC;
    case 0x80B6AFu: goto L_80B6AF;
    case 0x80B6B2u: goto L_80B6B2;
    case 0x80B6B4u: goto L_80B6B4;
    case 0x80B6B7u: goto L_80B6B7;
    case 0x80B6BAu: goto L_80B6BA;
    case 0x80B6BCu: goto L_80B6BC;
    case 0x80B6BEu: goto L_80B6BE;
    case 0x80B6C2u: goto L_80B6C2;
    case 0x80B6C5u: goto L_80B6C5;
    case 0x80B6C7u: goto L_80B6C7;
    case 0x80B6CAu: goto L_80B6CA;
    case 0x80B6CDu: goto L_80B6CD;
    case 0x80B6CFu: goto L_80B6CF;
    case 0x80B6D3u: goto L_80B6D3;
    case 0x80B6D6u: goto L_80B6D6;
    case 0x80B6D8u: goto L_80B6D8;
    case 0x80B6DBu: goto L_80B6DB;
    case 0x80B6DEu: goto L_80B6DE;
    case 0x80B6E0u: goto L_80B6E0;
    case 0x80B6E4u: goto L_80B6E4;
    case 0x80B6E7u: goto L_80B6E7;
    case 0x80B6E9u: goto L_80B6E9;
    case 0x80B6ECu: goto L_80B6EC;
    case 0x80B6EFu: goto L_80B6EF;
    case 0x80B6F1u: goto L_80B6F1;
    case 0x80B6F2u: goto L_80B6F2;
    case 0x80B6F4u: goto L_80B6F4;
    case 0x80B6F5u: goto L_80B6F5;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B682:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB682u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB682u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB682u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B682 STX
    hw.write(cpu.address("dp", 0x61u), cpu.x, cpu.x8?8:16);
    goto L_80B684;
L_80B684:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB684u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB684u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB684u, 6u, 4u, ((0x7E2016u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B684 LDA
    cpu.loadA(hw.readW(((0x7E2016u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B688;
L_80B688:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB688u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB688u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB688u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B688 BNE -> $80B692
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B692; }
    goto L_80B68A;
L_80B68A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB68Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB68Au,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB68Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B68A TXA
    cpu.transfer("TXA");
    goto L_80B68B;
L_80B68B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB68Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB68Bu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB68Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B68B CLC
    cpu.setFlag('C', false);
    goto L_80B68C;
L_80B68C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB68Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB68Cu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB68Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B68C ADC
    cpu.adc(0x16u);
    goto L_80B68F;
L_80B68F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB68Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB68Fu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB68Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B68F TAX
    cpu.transfer("TAX");
    goto L_80B690;
L_80B690:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB690u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB690u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB690u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B690 BRA -> $80B684
    goto L_80B684;
L_80B692:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB692u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB692u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB692u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B692 CMP
    cpu.compareA(0xFFFFu);
    goto L_80B695;
L_80B695:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB695u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB695u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB695u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B695 BEQ -> $80B6BC
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B6BC; }
    goto L_80B697;
L_80B697:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB697u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB697u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB697u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B697 BIT
    cpu.bit(0x2000u, true);
    goto L_80B69A;
L_80B69A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB69Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB69Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB69Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B69A BEQ -> $80B6B4
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B6B4; }
    goto L_80B69C;
L_80B69C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB69Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB69Cu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB69Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B69C AND
    cpu.logicAnd(0x300u);
    goto L_80B69F;
L_80B69F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB69Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB69Fu,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB69Fu, 5u, 3u, cpu.address("abs", 0x097Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B69F CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x97Au), cpu.m8?8:16));
    goto L_80B6A2;
L_80B6A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6A2u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6A2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6A2 BNE -> $80B6BC
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B6BC; }
    goto L_80B6A4;
L_80B6A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6A4u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6A4u, 5u, 3u, cpu.address("abs", 0x0137u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6A4 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x137u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B6A7;
L_80B6A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6A7u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6A7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6A7 CMP
    cpu.compareA(0x2u);
    goto L_80B6AA;
L_80B6AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6AAu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6AAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6AA BCC -> $80B6F4
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B6F4; }
    goto L_80B6AC;
L_80B6AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6ACu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6ACu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6AC LDA
    cpu.setA(0x400u, 16);
    goto L_80B6AF;
L_80B6AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6AFu,cpu,0x0Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6AFu, 8u, 3u, cpu.address("abs", 0x0922u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6AF TSB
    cpu.tsb(hw, cpu.address("abs", 0x922u), cpu.m8?8:16);
    goto L_80B6B2;
L_80B6B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B2u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6B2 BRA -> $80B6F4
    goto L_80B6F4;
L_80B6B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6B4 AND
    cpu.logicAnd(0x300u);
    goto L_80B6B7;
L_80B6B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B7u,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B7u, 5u, 3u, cpu.address("abs", 0x097Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6B7 CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x97Au), cpu.m8?8:16));
    goto L_80B6BA;
L_80B6BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BAu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6BA BEQ -> $80B6F4
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B6F4; }
    goto L_80B6BC;
L_80B6BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BCu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6BC LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x61u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80B6BE;
L_80B6BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BEu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BEu, 6u, 4u, ((0x7E2002u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6BE LDA
    cpu.loadA(hw.readW(((0x7E2002u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B6C2;
L_80B6C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6C2u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6C2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6C2 CMP
    cpu.compareA(0xFFFFu);
    goto L_80B6C5;
L_80B6C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6C5u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6C5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6C5 BEQ -> $80B6CF
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B6CF; }
    goto L_80B6C7;
L_80B6C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6C7u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6C7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6C7 AND
    cpu.logicAnd(0x300u);
    goto L_80B6CA;
L_80B6CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6CAu,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6CAu, 5u, 3u, cpu.address("abs", 0x097Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6CA CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x97Au), cpu.m8?8:16));
    goto L_80B6CD;
L_80B6CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6CDu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6CDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6CD BEQ -> $80B6F4
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B6F4; }
    goto L_80B6CF;
L_80B6CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6CFu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6CFu, 6u, 4u, ((0x7E1FFEu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6CF LDA
    cpu.loadA(hw.readW(((0x7E1FFEu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B6D3;
L_80B6D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D3u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6D3 CMP
    cpu.compareA(0xFFFFu);
    goto L_80B6D6;
L_80B6D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6D6 BEQ -> $80B6E0
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B6E0; }
    goto L_80B6D8;
L_80B6D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D8u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6D8 AND
    cpu.logicAnd(0x300u);
    goto L_80B6DB;
L_80B6DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DBu,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DBu, 5u, 3u, cpu.address("abs", 0x097Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6DB CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x97Au), cpu.m8?8:16));
    goto L_80B6DE;
L_80B6DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DEu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6DE BEQ -> $80B6F4
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B6F4; }
    goto L_80B6E0;
L_80B6E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E0u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E0u, 6u, 4u, ((0x7E1FEAu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6E0 LDA
    cpu.loadA(hw.readW(((0x7E1FEAu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B6E4;
L_80B6E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E4u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6E4 CMP
    cpu.compareA(0xFFFFu);
    goto L_80B6E7;
L_80B6E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6E7 BEQ -> $80B6F1
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B6F1; }
    goto L_80B6E9;
L_80B6E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E9u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6E9 AND
    cpu.logicAnd(0x300u);
    goto L_80B6EC;
L_80B6EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6ECu,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6ECu, 5u, 3u, cpu.address("abs", 0x097Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6EC CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x97Au), cpu.m8?8:16));
    goto L_80B6EF;
L_80B6EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EFu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6EF BEQ -> $80B6F4
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B6F4; }
    goto L_80B6F1;
L_80B6F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F1u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6F1 SEC
    cpu.setFlag('C', true);
    goto L_80B6F2;
L_80B6F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F2u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6F2 BRA -> $80B6F5
    goto L_80B6F5;
L_80B6F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F4u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6F4 CLC
    cpu.setFlag('C', false);
    goto L_80B6F5;
L_80B6F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6F5u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F5u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B6F5 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B6F5u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B6F5u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F5u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B6F5 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B6F5u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B6F5u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB6F5u,0x80B6F5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80D706_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80D706u: goto L_80D706;
    case 0x80D70Au: goto L_80D70A;
    case 0x80D70Cu: goto L_80D70C;
    case 0x80D70Fu: goto L_80D70F;
    case 0x80D711u: goto L_80D711;
    case 0x80D714u: goto L_80D714;
    case 0x80D716u: goto L_80D716;
    case 0x80D71Au: goto L_80D71A;
    case 0x80D71Cu: goto L_80D71C;
    case 0x80D71Fu: goto L_80D71F;
    case 0x80D721u: goto L_80D721;
    case 0x80D724u: goto L_80D724;
    case 0x80D726u: goto L_80D726;
    case 0x80D728u: goto L_80D728;
    case 0x80D72Cu: goto L_80D72C;
    case 0x80D72Eu: goto L_80D72E;
    case 0x80D730u: goto L_80D730;
    case 0x80D731u: goto L_80D731;
    case 0x80D732u: goto L_80D732;
    case 0x80D733u: goto L_80D733;
    case 0x80D734u: goto L_80D734;
    case 0x80D735u: goto L_80D735;
    case 0x80D736u: goto L_80D736;
    case 0x80D738u: goto L_80D738;
    case 0x80D73Cu: goto L_80D73C;
    case 0x80D73Eu: goto L_80D73E;
    case 0x80D742u: goto L_80D742;
    case 0x80D745u: goto L_80D745;
    case 0x80D749u: goto L_80D749;
    case 0x80D74Bu: goto L_80D74B;
    case 0x80D74Du: goto L_80D74D;
    case 0x80D74Fu: goto L_80D74F;
    case 0x80D751u: goto L_80D751;
    case 0x80D753u: goto L_80D753;
    case 0x80D755u: goto L_80D755;
    case 0x80D757u: goto L_80D757;
    case 0x80D75Bu: goto L_80D75B;
    case 0x80D75Du: goto L_80D75D;
    case 0x80D760u: goto L_80D760;
    case 0x80D762u: goto L_80D762;
    case 0x80D764u: goto L_80D764;
    case 0x80D768u: goto L_80D768;
    case 0x80D76Au: goto L_80D76A;
    case 0x80D76Bu: goto L_80D76B;
    case 0x80D76Cu: goto L_80D76C;
    case 0x80D76Fu: goto L_80D76F;
    case 0x80D771u: goto L_80D771;
    case 0x80D775u: goto L_80D775;
    case 0x80D777u: goto L_80D777;
    case 0x80D77Bu: goto L_80D77B;
    case 0x80D77Eu: goto L_80D77E;
    case 0x80D782u: goto L_80D782;
    case 0x80D784u: goto L_80D784;
    case 0x80D786u: goto L_80D786;
    case 0x80D788u: goto L_80D788;
    case 0x80D78Au: goto L_80D78A;
    case 0x80D78Cu: goto L_80D78C;
    case 0x80D78Eu: goto L_80D78E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80D706:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD706u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD706u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD706u, 6u, 4u, ((0x7E2002u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D706 LDA
    cpu.loadA(hw.readW(((0x7E2002u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D70A;
L_80D70A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD70Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD70Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD70Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D70A BEQ -> $80D730
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D730; }
    goto L_80D70C;
L_80D70C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD70Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD70Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD70Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D70C CMP
    cpu.compareA(0xFFFFu);
    goto L_80D70F;
L_80D70F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD70Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD70Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD70Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D70F BEQ -> $80D730
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D730; }
    goto L_80D711;
L_80D711:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD711u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD711u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD711u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D711 AND
    cpu.logicAnd(0x300u);
    goto L_80D714;
L_80D714:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD714u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD714u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD714u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D714 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_80D716;
L_80D716:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD716u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD716u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD716u, 6u, 4u, ((0x7E2004u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D716 LDA
    cpu.loadA(hw.readW(((0x7E2004u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D71A;
L_80D71A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD71Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD71Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD71Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D71A BEQ -> $80D755
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D755; }
    goto L_80D71C;
L_80D71C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD71Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD71Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD71Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D71C CMP
    cpu.compareA(0xFFFFu);
    goto L_80D71F;
L_80D71F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD71Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD71Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD71Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D71F BEQ -> $80D755
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D755; }
    goto L_80D721;
L_80D721:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD721u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD721u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD721u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D721 AND
    cpu.logicAnd(0x300u);
    goto L_80D724;
L_80D724:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD724u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD724u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD724u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D724 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16));
    goto L_80D726;
L_80D726:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD726u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD726u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD726u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D726 BNE -> $80D755
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D755; }
    goto L_80D728;
L_80D728:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD728u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD728u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD728u, 6u, 4u, ((0x7E2006u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D728 LDA
    cpu.loadA(hw.readW(((0x7E2006u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D72C;
L_80D72C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD72Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD72Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD72Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D72C BNE -> $80D755
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D755; }
    goto L_80D72E;
L_80D72E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD72Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD72Eu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD72Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D72E BRA -> $80D731
    goto L_80D731;
L_80D730:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD730u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD730u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD730u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D730 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80D730u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80D730u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80D731:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD731u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD731u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD731u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D731 TXA
    cpu.transfer("TXA");
    goto L_80D732;
L_80D732:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD732u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD732u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD732u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D732 INC
    cpu.inc('A');
    goto L_80D733;
L_80D733:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD733u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD733u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD733u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D733 INC
    cpu.inc('A');
    goto L_80D734;
L_80D734:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD734u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD734u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD734u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D734 INC
    cpu.inc('A');
    goto L_80D735;
L_80D735:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD735u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD735u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD735u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D735 INC
    cpu.inc('A');
    goto L_80D736;
L_80D736:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD736u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD736u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD736u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D736 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80D738;
L_80D738:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD738u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD738u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD738u, 6u, 4u, ((0x7E2444u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D738 STA
    hw.write(((0x7E2444u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80D73C;
L_80D73C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD73Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD73Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD73Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D73C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D73E;
L_80D73E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD73Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD73Eu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD73Eu, 6u, 4u, ((0x7E2440u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D73E STA
    hw.write(((0x7E2440u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80D742;
L_80D742:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD742u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD742u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD742u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D742 LDA
    cpu.setA(0x2u, 16);
    goto L_80D745;
L_80D745:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD745u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD745u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD745u, 6u, 4u, ((0x7E2442u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D745 STA
    hw.write(((0x7E2442u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80D749;
L_80D749:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD749u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD749u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD749u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D749 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D74B;
L_80D74B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD74Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD74Bu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD74Bu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D74B INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D74D;
L_80D74D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD74Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD74Du,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD74Du, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D74D INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D74F;
L_80D74F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD74Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD74Fu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD74Fu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D74F INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D751;
L_80D751:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD751u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD751u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD751u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D751 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D753;
L_80D753:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD753u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD753u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD753u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D753 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D755;
L_80D755:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD755u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD755u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD755u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x65u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D755 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x65u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80D757;
L_80D757:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD757u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD757u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD757u, 6u, 4u, ((0x7E1FECu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D757 LDA
    cpu.loadA(hw.readW(((0x7E1FECu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D75B;
L_80D75B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD75Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD75Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD75Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D75B BEQ -> $80D730
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D730; }
    goto L_80D75D;
L_80D75D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD75Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD75Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD75Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D75D AND
    cpu.logicAnd(0x300u);
    goto L_80D760;
L_80D760:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD760u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD760u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD760u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D760 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16));
    goto L_80D762;
L_80D762:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD762u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD762u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD762u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D762 BNE -> $80D730
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D730; }
    goto L_80D764;
L_80D764:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD764u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD764u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD764u, 6u, 4u, ((0x7E1FD2u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D764 LDA
    cpu.loadA(hw.readW(((0x7E1FD2u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D768;
L_80D768:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD768u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD768u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD768u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D768 BNE -> $80D730
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D730; }
    goto L_80D76A;
L_80D76A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD76Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD76Au,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD76Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D76A TXA
    cpu.transfer("TXA");
    goto L_80D76B;
L_80D76B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD76Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD76Bu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD76Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D76B SEC
    cpu.setFlag('C', true);
    goto L_80D76C;
L_80D76C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD76Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD76Cu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD76Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D76C SBC
    cpu.sbc(0x14u);
    goto L_80D76F;
L_80D76F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD76Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD76Fu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD76Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D76F LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80D771;
L_80D771:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD771u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD771u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD771u, 6u, 4u, ((0x7E2444u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D771 STA
    hw.write(((0x7E2444u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80D775;
L_80D775:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD775u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD775u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD775u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D775 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D777;
L_80D777:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD777u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD777u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD777u, 6u, 4u, ((0x7E2440u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D777 STA
    hw.write(((0x7E2440u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80D77B;
L_80D77B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD77Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD77Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD77Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D77B LDA
    cpu.setA(0x4u, 16);
    goto L_80D77E;
L_80D77E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD77Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD77Eu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD77Eu, 6u, 4u, ((0x7E2442u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D77E STA
    hw.write(((0x7E2442u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80D782;
L_80D782:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD782u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD782u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD782u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D782 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D784;
L_80D784:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD784u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD784u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD784u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D784 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D786;
L_80D786:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD786u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD786u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD786u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D786 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D788;
L_80D788:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD788u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD788u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD788u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D788 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D78A;
L_80D78A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD78Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Au,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Au, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D78A INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D78C;
L_80D78C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD78Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Cu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Cu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D78C INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D78E;
L_80D78E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD78Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Eu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D78E BRA -> $80D730
    goto L_80D730;
}

void sub_829461_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x829461u: goto L_829461;
    case 0x829463u: goto L_829463;
    case 0x829465u: goto L_829465;
    case 0x829468u: goto L_829468;
    case 0x82946Bu: goto L_82946B;
    case 0x82946Eu: goto L_82946E;
    case 0x829471u: goto L_829471;
    case 0x829474u: goto L_829474;
    case 0x829477u: goto L_829477;
    case 0x82947Au: goto L_82947A;
    case 0x82947Cu: goto L_82947C;
    case 0x82947Eu: goto L_82947E;
    case 0x829480u: goto L_829480;
    case 0x829482u: goto L_829482;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_829461:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9461u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9461u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9461u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829461 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x75u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829463;
L_829463:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9463u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9463u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9463u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829463 BNE -> $829482
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_829482; }
    goto L_829465;
L_829465:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9465u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9465u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9465u, 5u, 3u, cpu.address("abs", 0x0193u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829465 STZ
    hw.write(cpu.address("abs", 0x193u), 0, cpu.m8?8:16);
    goto L_829468;
L_829468:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9468u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9468u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9468u, 5u, 3u, cpu.address("abs", 0x0197u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829468 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x197u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82946B;
L_82946B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x946Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x946Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x946Bu, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82946B STA
    hw.write(cpu.address("abs", 0x135u), cpu.a, cpu.m8?8:16);
    goto L_82946E;
L_82946E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x946Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x946Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x946Eu, 5u, 3u, cpu.address("abs", 0x0199u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82946E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x199u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829471;
L_829471:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9471u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9471u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9471u, 5u, 3u, cpu.address("abs", 0x0137u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829471 STA
    hw.write(cpu.address("abs", 0x137u), cpu.a, cpu.m8?8:16);
    goto L_829474;
L_829474:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9474u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9474u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9474u, 5u, 3u, cpu.address("abs", 0x019Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829474 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x19Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829477;
L_829477:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9477u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9477u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9477u, 5u, 3u, cpu.address("abs", 0x02CEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829477 STA
    hw.write(cpu.address("abs", 0x2CEu), cpu.a, cpu.m8?8:16);
    goto L_82947A;
L_82947A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x947Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x947Au,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x947Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82947A SEP
    cpu.sep(0x20u);
    goto L_82947C;
L_82947C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x947Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x947Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x947Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82947C LDA
    cpu.setA(0x81u, 8);
    goto L_82947E;
L_82947E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x947Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x947Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x947Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x46u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82947E STA
    hw.write(cpu.address("dp", 0x46u), cpu.a, cpu.m8?8:16);
    goto L_829480;
L_829480:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9480u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9480u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9480u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829480 REP
    cpu.rep(0x20u);
    goto L_829482;
L_829482:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9482u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9482u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9482u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829482 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x829482u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829482u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82A16F_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82A16Fu: goto L_82A16F;
    case 0x82A171u: goto L_82A171;
    case 0x82A173u: goto L_82A173;
    case 0x82A175u: goto L_82A175;
    case 0x82A178u: goto L_82A178;
    case 0x82A17Au: goto L_82A17A;
    case 0x82A17Cu: goto L_82A17C;
    case 0x82A17Eu: goto L_82A17E;
    case 0x82A180u: goto L_82A180;
    case 0x82A181u: goto L_82A181;
    case 0x82A183u: goto L_82A183;
    case 0x82A184u: goto L_82A184;
    case 0x82A187u: goto L_82A187;
    case 0x82A188u: goto L_82A188;
    case 0x82A18Au: goto L_82A18A;
    case 0x82A18Cu: goto L_82A18C;
    case 0x82A18Fu: goto L_82A18F;
    case 0x82A192u: goto L_82A192;
    case 0x82A194u: goto L_82A194;
    case 0x82A197u: goto L_82A197;
    case 0x82A198u: goto L_82A198;
    case 0x82A199u: goto L_82A199;
    case 0x82A19Au: goto L_82A19A;
    case 0x82A19Bu: goto L_82A19B;
    case 0x82A19Cu: goto L_82A19C;
    case 0x82A19Du: goto L_82A19D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82A16F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA16Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA16Fu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA16Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A16F SEP
    cpu.sep(0x20u);
    goto L_82A171;
L_82A171:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA171u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA171u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA171u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A171 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A173;
L_82A173:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA173u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA173u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA173u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A173 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A175;
L_82A175:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA175u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA175u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA175u, 4u + 1u, 3u, cpu.address("absy", 0x0208u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A175 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x208u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A178;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA175u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA175u, 4u + 1u, 3u, cpu.address("absy", 0x0208u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A175 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x208u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A178;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA175u,0x82A175u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82A178:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA178u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA178u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA178u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A178 BPL -> $82A181
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82A181; }
    goto L_82A17A;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA178u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA178u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A178 BPL -> $82A181
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82A181; }
    goto L_82A17A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA178u,0x82A178u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82A17A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA17Au))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA17Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA17Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A17A CMP
    cpu.compareA(0x80u);
    goto L_82A17C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA17Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA17Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A17A CMP
    cpu.compareA(0x80u);
    goto L_82A17C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA17Au,0x82A17Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82A17C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA17Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA17Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA17Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A17C BNE -> $82A197
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A197; }
    goto L_82A17E;
L_82A17E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA17Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA17Eu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA17Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A17E REP
    cpu.rep(0x20u);
    goto L_82A180;
L_82A180:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA180u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA180u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA180u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A180 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82A180u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82A180u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82A181:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA181u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA181u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA181u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A181 LDA
    cpu.setA(0x0u, 8);
    goto L_82A183;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA181u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA181u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A181 LDA
    cpu.setA(0x0u, 8);
    goto L_82A183;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA181u,0x82A181u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82A183:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA183u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA183u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA183u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A183 SEC
    cpu.setFlag('C', true);
    goto L_82A184;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA183u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA183u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A183 SEC
    cpu.setFlag('C', true);
    goto L_82A184;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA183u,0x82A183u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82A184:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA184u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA184u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA184u, 4u + 1u, 3u, cpu.address("absy", 0x020Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A184 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x20Bu), cpu.m8?8:16));
    goto L_82A187;
L_82A187:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA187u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA187u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA187u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A187 SEC
    cpu.setFlag('C', true);
    goto L_82A188;
L_82A188:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA188u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA188u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA188u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A188 SBC
    cpu.sbc(0x8u);
    goto L_82A18A;
L_82A18A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA18Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A18A STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82A18C;
L_82A18C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA18Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Cu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Cu, 4u + 1u, 3u, cpu.address("absy", 0x020Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A18C LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x20Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A18F;
L_82A18F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA18Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Fu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Fu, 5u, 3u, cpu.address("absy", 0x020Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A18F STA
    hw.write(cpu.address("absy", 0x20Bu), cpu.a, cpu.m8?8:16);
    goto L_82A192;
L_82A192:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA192u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA192u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA192u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A192 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A194;
L_82A194:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA194u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA194u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA194u, 5u, 3u, cpu.address("absy", 0x020Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A194 STA
    hw.write(cpu.address("absy", 0x20Au), cpu.a, cpu.m8?8:16);
    goto L_82A197;
L_82A197:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA197u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA197u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA197u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A197 INY
    cpu.inc('Y');
    goto L_82A198;
L_82A198:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA198u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA198u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA198u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A198 INY
    cpu.inc('Y');
    goto L_82A199;
L_82A199:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA199u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA199u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA199u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A199 INY
    cpu.inc('Y');
    goto L_82A19A;
L_82A19A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA19Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA19Au,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA19Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A19A INY
    cpu.inc('Y');
    goto L_82A19B;
L_82A19B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA19Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA19Bu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA19Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A19B INY
    cpu.inc('Y');
    goto L_82A19C;
L_82A19C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA19Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA19Cu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA19Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A19C INY
    cpu.inc('Y');
    goto L_82A19D;
L_82A19D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA19Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA19Du,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA19Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A19D BRA -> $82A175
    goto L_82A175;
}

void sub_82A16F_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82A16Fu: goto L_82A16F;
    case 0x82A171u: goto L_82A171;
    case 0x82A173u: goto L_82A173;
    case 0x82A175u: goto L_82A175;
    case 0x82A178u: goto L_82A178;
    case 0x82A17Au: goto L_82A17A;
    case 0x82A17Cu: goto L_82A17C;
    case 0x82A17Eu: goto L_82A17E;
    case 0x82A180u: goto L_82A180;
    case 0x82A181u: goto L_82A181;
    case 0x82A183u: goto L_82A183;
    case 0x82A184u: goto L_82A184;
    case 0x82A187u: goto L_82A187;
    case 0x82A188u: goto L_82A188;
    case 0x82A18Au: goto L_82A18A;
    case 0x82A18Cu: goto L_82A18C;
    case 0x82A18Fu: goto L_82A18F;
    case 0x82A192u: goto L_82A192;
    case 0x82A194u: goto L_82A194;
    case 0x82A197u: goto L_82A197;
    case 0x82A198u: goto L_82A198;
    case 0x82A199u: goto L_82A199;
    case 0x82A19Au: goto L_82A19A;
    case 0x82A19Bu: goto L_82A19B;
    case 0x82A19Cu: goto L_82A19C;
    case 0x82A19Du: goto L_82A19D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82A16F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA16Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA16Fu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA16Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A16F SEP
    cpu.sep(0x20u);
    goto L_82A171;
L_82A171:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA171u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA171u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA171u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A171 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A173;
L_82A173:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA173u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA173u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA173u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A173 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A175;
L_82A175:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA175u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA175u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA175u, 4u + 1u, 3u, cpu.address("absy", 0x0208u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A175 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x208u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A178;
L_82A178:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA178u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA178u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA178u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A178 BPL -> $82A181
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82A181; }
    goto L_82A17A;
L_82A17A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA17Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA17Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA17Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A17A CMP
    cpu.compareA(0x80u);
    goto L_82A17C;
L_82A17C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA17Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA17Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA17Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A17C BNE -> $82A197
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A197; }
    goto L_82A17E;
L_82A17E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA17Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA17Eu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA17Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A17E REP
    cpu.rep(0x20u);
    goto L_82A180;
L_82A180:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA180u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA180u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA180u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A180 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82A180u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82A180u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82A181:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA181u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA181u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA181u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A181 LDA
    cpu.setA(0x0u, 8);
    goto L_82A183;
L_82A183:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA183u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA183u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA183u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A183 SEC
    cpu.setFlag('C', true);
    goto L_82A184;
L_82A184:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA184u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA184u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA184u, 4u + 1u, 3u, cpu.address("absy", 0x020Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A184 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x20Bu), cpu.m8?8:16));
    goto L_82A187;
L_82A187:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA187u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA187u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA187u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A187 SEC
    cpu.setFlag('C', true);
    goto L_82A188;
L_82A188:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA188u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA188u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA188u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A188 SBC
    cpu.sbc(0x8u);
    goto L_82A18A;
L_82A18A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA18Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A18A STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82A18C;
L_82A18C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA18Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Cu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Cu, 4u + 1u, 3u, cpu.address("absy", 0x020Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A18C LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x20Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A18F;
L_82A18F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA18Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Fu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Fu, 5u, 3u, cpu.address("absy", 0x020Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A18F STA
    hw.write(cpu.address("absy", 0x20Bu), cpu.a, cpu.m8?8:16);
    goto L_82A192;
L_82A192:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA192u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA192u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA192u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A192 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A194;
L_82A194:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA194u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA194u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA194u, 5u, 3u, cpu.address("absy", 0x020Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A194 STA
    hw.write(cpu.address("absy", 0x20Au), cpu.a, cpu.m8?8:16);
    goto L_82A197;
L_82A197:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA197u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA197u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA197u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A197 INY
    cpu.inc('Y');
    goto L_82A198;
L_82A198:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA198u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA198u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA198u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A198 INY
    cpu.inc('Y');
    goto L_82A199;
L_82A199:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA199u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA199u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA199u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A199 INY
    cpu.inc('Y');
    goto L_82A19A;
L_82A19A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA19Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA19Au,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA19Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A19A INY
    cpu.inc('Y');
    goto L_82A19B;
L_82A19B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA19Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA19Bu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA19Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A19B INY
    cpu.inc('Y');
    goto L_82A19C;
L_82A19C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA19Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA19Cu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA19Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A19C INY
    cpu.inc('Y');
    goto L_82A19D;
L_82A19D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA19Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA19Du,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA19Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A19D BRA -> $82A175
    goto L_82A175;
}

void sub_82A1FB_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82A1FBu: goto L_82A1FB;
    case 0x82A1FDu: goto L_82A1FD;
    case 0x82A1FFu: goto L_82A1FF;
    case 0x82A201u: goto L_82A201;
    case 0x82A204u: goto L_82A204;
    case 0x82A206u: goto L_82A206;
    case 0x82A208u: goto L_82A208;
    case 0x82A20Au: goto L_82A20A;
    case 0x82A20Cu: goto L_82A20C;
    case 0x82A20Du: goto L_82A20D;
    case 0x82A210u: goto L_82A210;
    case 0x82A212u: goto L_82A212;
    case 0x82A214u: goto L_82A214;
    case 0x82A215u: goto L_82A215;
    case 0x82A218u: goto L_82A218;
    case 0x82A219u: goto L_82A219;
    case 0x82A21Bu: goto L_82A21B;
    case 0x82A21Eu: goto L_82A21E;
    case 0x82A220u: goto L_82A220;
    case 0x82A223u: goto L_82A223;
    case 0x82A224u: goto L_82A224;
    case 0x82A225u: goto L_82A225;
    case 0x82A226u: goto L_82A226;
    case 0x82A227u: goto L_82A227;
    case 0x82A228u: goto L_82A228;
    case 0x82A229u: goto L_82A229;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82A1FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1FBu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1FBu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1FB SEP
    cpu.sep(0x20u);
    goto L_82A1FD;
L_82A1FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1FDu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1FDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1FD LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A1FF;
L_82A1FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1FFu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1FFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1FF LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A201;
L_82A201:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA201u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA201u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA201u, 4u + 1u, 3u, cpu.address("absy", 0x0224u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A201 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x224u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A204;
L_82A204:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA204u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA204u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA204u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A204 BPL -> $82A20D
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82A20D; }
    goto L_82A206;
L_82A206:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA206u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA206u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA206u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A206 CMP
    cpu.compareA(0x80u);
    goto L_82A208;
L_82A208:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA208u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA208u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA208u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A208 BNE -> $82A223
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A223; }
    goto L_82A20A;
L_82A20A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA20Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA20Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA20Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A20A REP
    cpu.rep(0x20u);
    goto L_82A20C;
L_82A20C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA20Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA20Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA20Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A20C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82A20Cu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82A20Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82A20D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA20Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA20Du,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA20Du, 4u + 1u, 3u, cpu.address("absy", 0x0227u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A20D LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x227u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A210;
L_82A210:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA210u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA210u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA210u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A210 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82A212;
L_82A212:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA212u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA212u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA212u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A212 LDA
    cpu.setA(0x0u, 8);
    goto L_82A214;
L_82A214:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA214u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA214u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA214u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A214 SEC
    cpu.setFlag('C', true);
    goto L_82A215;
L_82A215:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA215u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA215u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA215u, 4u + 1u, 3u, cpu.address("absy", 0x0226u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A215 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x226u), cpu.m8?8:16));
    goto L_82A218;
L_82A218:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA218u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA218u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA218u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A218 SEC
    cpu.setFlag('C', true);
    goto L_82A219;
L_82A219:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA219u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA219u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA219u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A219 SBC
    cpu.sbc(0x8u);
    goto L_82A21B;
L_82A21B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA21Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA21Bu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA21Bu, 5u, 3u, cpu.address("absy", 0x0227u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A21B STA
    hw.write(cpu.address("absy", 0x227u), cpu.a, cpu.m8?8:16);
    goto L_82A21E;
L_82A21E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA21Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA21Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA21Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A21E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A220;
L_82A220:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA220u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA220u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA220u, 5u, 3u, cpu.address("absy", 0x0226u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A220 STA
    hw.write(cpu.address("absy", 0x226u), cpu.a, cpu.m8?8:16);
    goto L_82A223;
L_82A223:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA223u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA223u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA223u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A223 INY
    cpu.inc('Y');
    goto L_82A224;
L_82A224:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA224u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA224u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA224u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A224 INY
    cpu.inc('Y');
    goto L_82A225;
L_82A225:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA225u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA225u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA225u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A225 INY
    cpu.inc('Y');
    goto L_82A226;
L_82A226:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA226u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA226u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA226u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A226 INY
    cpu.inc('Y');
    goto L_82A227;
L_82A227:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA227u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA227u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA227u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A227 INY
    cpu.inc('Y');
    goto L_82A228;
L_82A228:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA228u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA228u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA228u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A228 INY
    cpu.inc('Y');
    goto L_82A229;
L_82A229:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA229u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA229u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA229u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A229 BRA -> $82A201
    goto L_82A201;
}

void sub_82A53C_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82A53Cu: goto L_82A53C;
    case 0x82A53Du: goto L_82A53D;
    case 0x82A53Fu: goto L_82A53F;
    case 0x82A541u: goto L_82A541;
    case 0x82A542u: goto L_82A542;
    case 0x82A543u: goto L_82A543;
    case 0x82A545u: goto L_82A545;
    case 0x82A548u: goto L_82A548;
    case 0x82A54Au: goto L_82A54A;
    case 0x82A54Cu: goto L_82A54C;
    case 0x82A54Fu: goto L_82A54F;
    case 0x82A551u: goto L_82A551;
    case 0x82A554u: goto L_82A554;
    case 0x82A556u: goto L_82A556;
    case 0x82A557u: goto L_82A557;
    case 0x82A558u: goto L_82A558;
    case 0x82A55Au: goto L_82A55A;
    case 0x82A55Bu: goto L_82A55B;
    case 0x82A55Cu: goto L_82A55C;
    case 0x82A55Du: goto L_82A55D;
    case 0x82A55Eu: goto L_82A55E;
    case 0x82A55Fu: goto L_82A55F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82A53C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA53Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA53Cu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA53Cu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82A53C PHB
    cpu.push("PHB", hw);
    goto L_82A53D;
L_82A53D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA53Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA53Du,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA53Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A53D SEP
    cpu.sep(0x20u);
    goto L_82A53F;
L_82A53F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA53Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA53Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA53Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x69u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A53F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x69u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A541;
L_82A541:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA541u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA541u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA541u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82A541 PHA
    cpu.push("PHA", hw);
    goto L_82A542;
L_82A542:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA542u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA542u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA542u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82A542 PLB
    cpu.pop("PLB", hw);
    goto L_82A543;
L_82A543:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA543u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA543u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA543u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A543 REP
    cpu.rep(0x20u);
    goto L_82A545;
L_82A545:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA545u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA545u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA545u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A545 LDY
    cpu.setY(0x1F8u, 16);
    goto L_82A548;
L_82A548:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA548u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA548u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA548u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82A548 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A54A;
L_82A54A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA54Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA54Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA54Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A54A BEQ -> $82A556
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A556; }
    goto L_82A54C;
L_82A54C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA54Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA54Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA54Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A54C CMP
    cpu.compareA(0xFFFFu);
    goto L_82A54F;
L_82A54F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA54Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA54Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA54Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A54F BEQ -> $82A556
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A556; }
    goto L_82A551;
L_82A551:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA551u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA551u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA551u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A551 BIT
    cpu.bit(0x8000u, true);
    goto L_82A554;
L_82A554:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA554u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA554u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA554u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A554 BNE -> $82A55D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A55D; }
    goto L_82A556;
L_82A556:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA556u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA556u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA556u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A556 DEY
    cpu.decReg('Y');
    goto L_82A557;
L_82A557:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA557u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA557u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA557u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A557 DEY
    cpu.decReg('Y');
    goto L_82A558;
L_82A558:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA558u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA558u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA558u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A558 BPL -> $82A548
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82A548; }
    goto L_82A55A;
L_82A55A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA55Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA55Au,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA55Au, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82A55A PLB
    cpu.pop("PLB", hw);
    goto L_82A55B;
L_82A55B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA55Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA55Bu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA55Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A55B CLC
    cpu.setFlag('C', false);
    goto L_82A55C;
L_82A55C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA55Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA55Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA55Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A55C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82A55Cu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82A55Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82A55D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA55Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA55Du,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA55Du, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82A55D PLB
    cpu.pop("PLB", hw);
    goto L_82A55E;
L_82A55E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA55Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA55Eu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA55Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A55E SEC
    cpu.setFlag('C', true);
    goto L_82A55F;
L_82A55F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA55Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA55Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA55Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A55F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82A55Fu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82A55Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82C038_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82C038u: goto L_82C038;
    case 0x82C03Bu: goto L_82C03B;
    case 0x82C043u: goto L_82C043;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82C038:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC038u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC038u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC038u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C038 LDA
    cpu.setA(0xFFFFu, 16);
    goto L_82C03B;
L_82C03B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC03Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC03Bu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC03Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C03B BRA -> $82C043
    goto L_82C043;
L_82C043:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC043u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC043u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC043u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C043 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C043u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C043u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82C038_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82C038u: goto L_82C038;
    case 0x82C03Bu: goto L_82C03B;
    case 0x82C043u: goto L_82C043;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82C038:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC038u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC038u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC038u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C038 LDA
    cpu.setA(0xFFFFu, 16);
    goto L_82C03B;
L_82C03B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC03Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC03Bu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC03Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C03B BRA -> $82C043
    goto L_82C043;
L_82C043:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC043u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC043u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC043u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C043 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C043u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C043u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82D6A3_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82D6A3u: goto L_82D6A3;
    case 0x82D6A5u: goto L_82D6A5;
    case 0x82D6A8u: goto L_82D6A8;
    case 0x82D6AAu: goto L_82D6AA;
    case 0x82D6ADu: goto L_82D6AD;
    case 0x82D6AFu: goto L_82D6AF;
    case 0x82D6B2u: goto L_82D6B2;
    case 0x82D6B4u: goto L_82D6B4;
    case 0x82D6B7u: goto L_82D6B7;
    case 0x82D6B9u: goto L_82D6B9;
    case 0x82D6BAu: goto L_82D6BA;
    case 0x82D6BBu: goto L_82D6BB;
    case 0x82D6BEu: goto L_82D6BE;
    case 0x82D6C0u: goto L_82D6C0;
    case 0x82D6C3u: goto L_82D6C3;
    case 0x82D6C6u: goto L_82D6C6;
    case 0x82D6C8u: goto L_82D6C8;
    case 0x82D6C9u: goto L_82D6C9;
    case 0x82D6CAu: goto L_82D6CA;
    case 0x82D6CCu: goto L_82D6CC;
    case 0x82D6CEu: goto L_82D6CE;
    case 0x82D6D1u: goto L_82D6D1;
    case 0x82D6D3u: goto L_82D6D3;
    case 0x82D6D7u: goto L_82D6D7;
    case 0x82D6D9u: goto L_82D6D9;
    case 0x82D6DCu: goto L_82D6DC;
    case 0x82D6DEu: goto L_82D6DE;
    case 0x82D6E2u: goto L_82D6E2;
    case 0x82D6E4u: goto L_82D6E4;
    case 0x82D6E7u: goto L_82D6E7;
    case 0x82D6EAu: goto L_82D6EA;
    case 0x82D6EEu: goto L_82D6EE;
    case 0x82D6F0u: goto L_82D6F0;
    case 0x82D6F3u: goto L_82D6F3;
    case 0x82D6F4u: goto L_82D6F4;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82D6A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6A3u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6A3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D6A3 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82D6A5;
L_82D6A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6A5u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6A5u, 5u + 1u, 3u, cpu.address("absx", 0x0404u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D6A5 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x404u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D6A8;
L_82D6A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6A8u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6A8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D6A8 BNE -> $82D6BB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82D6BB; }
    goto L_82D6AA;
L_82D6AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6AAu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6AAu, 5u + 1u, 3u, cpu.address("absx", 0x0402u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D6AA LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x402u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D6AD;
L_82D6AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6ADu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6ADu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D6AD BPL -> $82D6BB
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82D6BB; }
    goto L_82D6AF;
L_82D6AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6AFu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6AFu, 5u + 1u, 3u, cpu.address("absx", 0x0400u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D6AF LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x400u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D6B2;
L_82D6B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6B2u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6B2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D6B2 BEQ -> $82D6B9
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82D6B9; }
    goto L_82D6B4;
L_82D6B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6B4u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6B4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D6B4 CMP
    cpu.compareA(0x14u);
    goto L_82D6B7;
L_82D6B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6B7u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6B7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D6B7 BNE -> $82D6BB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82D6BB; }
    goto L_82D6B9;
L_82D6B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6B9u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6B9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D6B9 CLC
    cpu.setFlag('C', false);
    goto L_82D6BA;
L_82D6BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6BAu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6BAu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D6BA RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82D6BAu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82D6BAu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82D6BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6BBu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6BBu, 5u + 1u, 3u, cpu.address("absx", 0x0402u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D6BB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x402u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D6BE;
L_82D6BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6BEu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6BEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D6BE BMI -> $82D6E7
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82D6E7; }
    goto L_82D6C0;
L_82D6C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6C0u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6C0u, 5u + 1u, 3u, cpu.address("absx", 0x0400u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D6C0 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x400u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D6C3;
L_82D6C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6C3u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6C3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D6C3 CMP
    cpu.compareA(0x14u);
    goto L_82D6C6;
L_82D6C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6C6u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6C6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D6C6 BCS -> $82D6B9
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_82D6B9; }
    goto L_82D6C8;
L_82D6C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6C8u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6C8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D6C8 ASL
    cpu.aslA();
    goto L_82D6C9;
L_82D6C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6C9u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6C9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D6C9 TAX
    cpu.transfer("TAX");
    goto L_82D6CA;
L_82D6CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6CAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6CAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D6CA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D6CC;
L_82D6CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6CCu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6CCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D6CC BNE -> $82D6D9
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82D6D9; }
    goto L_82D6CE;
L_82D6CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6CEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6CEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D6CE LDA
    cpu.setA(0x2u, 16);
    goto L_82D6D1;
L_82D6D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6D1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6D1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D6D1 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_82D6D3;
L_82D6D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6D3u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6D3u, 6u, 4u, ((0x9E956Eu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D6D3 LDA
    cpu.loadA(hw.readW(((0x9E956Eu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D6D7;
L_82D6D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6D7u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6D7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D6D7 BRA -> $82D6E2
    goto L_82D6E2;
L_82D6D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6D9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6D9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D6D9 LDA
    cpu.setA(0xFFFEu, 16);
    goto L_82D6DC;
L_82D6DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6DCu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6DCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D6DC STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_82D6DE;
L_82D6DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6DEu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6DEu, 6u, 4u, ((0x9E9598u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D6DE LDA
    cpu.loadA(hw.readW(((0x9E9598u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D6E2;
L_82D6E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6E2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6E2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D6E2 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82D6E4;
L_82D6E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6E4u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6E4u, 6u, 3u, cpu.address("abs", 0xD793u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D6E4 JSR -> $82D793 stack real
    { cpu.push16Value(hw,0xD6E6u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD6E7u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD793u), 0x82D6E4u); }
    goto L_82D6E7;
L_82D6E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6E7u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD6E7u,0x82D6E7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6E7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6E7u, 6u, 3u, cpu.address("abs", 0xD7C1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D6E7 JSR -> $82D7C1 stack real
    { cpu.push16Value(hw,0xD6E9u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD6EAu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD7C1u), 0x82D6E7u); }
    goto L_82D6EA;
L_82D6EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6EAu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD6EAu,0x82D6EAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6EAu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6EAu, 8u, 4u, 0x808EE1u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82D6EA JSL -> $808EE1 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD6EDu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD6EEu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808EE1u, 0x82D6EAu); }
    goto L_82D6EE;
L_82D6EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6EEu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD6EEu,0x82D6EEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6EEu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6EEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D6EE LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82D6F0;
L_82D6F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6F0u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6F0u, 9u, 3u, cpu.address("absx", 0x0404u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D6F0 INC
    cpu.incMem(hw, cpu.address("absx", 0x404u), cpu.m8?8:16);
    goto L_82D6F3;
L_82D6F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6F3u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6F3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D6F3 SEC
    cpu.setFlag('C', true);
    goto L_82D6F4;
L_82D6F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6F4u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6F4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D6F4 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82D6F4u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82D6F4u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_8488CF_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8488CFu: goto L_8488CF;
    case 0x8488D1u: goto L_8488D1;
    case 0x8488D3u: goto L_8488D3;
    case 0x8488D6u: goto L_8488D6;
    case 0x8488D9u: goto L_8488D9;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8488CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88CFu,cpu,0xD5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88CFu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8488CF CMP
    cpu.compareA(hw.readW(cpu.address("dpx", 0x88u), cpu.m8?8:16));
    goto L_8488D1;
L_8488D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88D1u,cpu,0xF1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88D1u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x88u) & 0xFFFFu), 2u, 0u);
    // $8488D1 SBC
    cpu.sbc(hw.readW(cpu.addressDpIndirectY(hw, 0x88u), cpu.m8?8:16));
    goto L_8488D3;
L_8488D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88D3u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88D3u, 5u, 3u, cpu.address("abs", 0xC289u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8488D3 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xC289u), cpu.m8?8:16));
    goto L_8488D6;
L_8488D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88D6u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88D6u, 6u, 3u, cpu.address("abs", 0x02A2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8488D6 JSR -> $8402A2 stack real
    { cpu.push16Value(hw,0x88D8u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x88D9u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x02A2u), 0x8488D6u); }
    goto L_8488D9;
L_8488D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88D9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88D9u,0x8488D9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88D9u,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88D9u, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $8488D9 BRK
    hw.partial(0x8488D9u, "BRK"); return;
}

void sub_8488CF_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8488CFu: goto L_8488CF;
    case 0x8488D1u: goto L_8488D1;
    case 0x8488D3u: goto L_8488D3;
    case 0x8488D6u: goto L_8488D6;
    case 0x8488D9u: goto L_8488D9;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8488CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88CFu,cpu,0xD5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88CFu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8488CF CMP
    cpu.compareA(hw.readW(cpu.address("dpx", 0x88u), cpu.m8?8:16));
    goto L_8488D1;
L_8488D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88D1u,cpu,0xF1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88D1u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x88u) & 0xFFFFu), 2u, 0u);
    // $8488D1 SBC
    cpu.sbc(hw.readW(cpu.addressDpIndirectY(hw, 0x88u), cpu.m8?8:16));
    goto L_8488D3;
L_8488D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88D3u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88D3u, 5u, 3u, cpu.address("abs", 0xC289u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8488D3 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xC289u), cpu.m8?8:16));
    goto L_8488D6;
L_8488D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88D6u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88D6u, 6u, 3u, cpu.address("abs", 0x02A2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8488D6 JSR -> $8402A2 stack real
    { cpu.push16Value(hw,0x88D8u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x88D9u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x02A2u), 0x8488D6u); }
    goto L_8488D9;
L_8488D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88D9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88D9u,0x8488D9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88D9u,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88D9u, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $8488D9 BRK
    hw.partial(0x8488D9u, "BRK"); return;
}

void sub_848BF8_E0M1X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848BF8u: goto L_848BF8;
    case 0x848BFAu: goto L_848BFA;
    case 0x848BFCu: goto L_848BFC;
    case 0x848BFFu: goto L_848BFF;
    case 0x848C01u: goto L_848C01;
    case 0x848C04u: goto L_848C04;
    case 0x848C06u: goto L_848C06;
    case 0x848C07u: goto L_848C07;
    case 0x848C09u: goto L_848C09;
    case 0x848C0Bu: goto L_848C0B;
    case 0x848C0Eu: goto L_848C0E;
    case 0x848C10u: goto L_848C10;
    case 0x848C13u: goto L_848C13;
    case 0x848C15u: goto L_848C15;
    case 0x848C17u: goto L_848C17;
    case 0x848C1Au: goto L_848C1A;
    case 0x848C1Cu: goto L_848C1C;
    case 0x848C1Eu: goto L_848C1E;
    case 0x848C21u: goto L_848C21;
    case 0x848C23u: goto L_848C23;
    case 0x848C26u: goto L_848C26;
    case 0x848C29u: goto L_848C29;
    case 0x848C2Cu: goto L_848C2C;
    case 0x848C2Fu: goto L_848C2F;
    case 0x848C33u: goto L_848C33;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848BF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF8u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848BF8 REP
    cpu.rep(0x20u);
    goto L_848BFA;
L_848BFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848BFA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848BFC;
L_848BFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFCu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848BFC BIT
    cpu.bit(0x200u, true);
    goto L_848BFF;
L_848BFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFFu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848BFF BNE -> $848C09
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_848C09; }
    goto L_848C01;
L_848C01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C01u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C01u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C01 BIT
    cpu.bit(0x100u, true);
    goto L_848C04;
L_848C04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C04u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C04u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C04 BNE -> $848C15
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_848C15; }
    goto L_848C06;
L_848C06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C06u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C06u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C06 CLC
    cpu.setFlag('C', false);
    goto L_848C07;
L_848C07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C07u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C07u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C07 BRA -> $848C33
    goto L_848C33;
L_848C09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C09u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C09u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C09 SEP
    cpu.sep(0x20u);
    goto L_848C0B;
L_848C0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C0Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C0Bu, 4u, 3u, cpu.address("abs", 0x062Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C0B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848C0E;
L_848C0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C0Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C0Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C0E BEQ -> $848C33
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_848C33; }
    goto L_848C10;
L_848C10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C10u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C10u, 4u, 3u, cpu.address("abs", 0x062Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C10 STZ
    hw.write(cpu.address("abs", 0x62Eu), 0, cpu.m8?8:16);
    goto L_848C13;
L_848C13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C13u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C13u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C13 BRA -> $848C21
    goto L_848C21;
L_848C15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C15u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C15u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C15 SEP
    cpu.sep(0x20u);
    goto L_848C17;
L_848C17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C17u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C17u, 4u, 3u, cpu.address("abs", 0x062Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C17 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848C1A;
L_848C1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C1Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C1Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C1A BNE -> $848C33
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_848C33; }
    goto L_848C1C;
L_848C1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C1Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C1Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C1C LDA
    cpu.setA(0x1u, 8);
    goto L_848C1E;
L_848C1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C1Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C1Eu, 4u, 3u, cpu.address("abs", 0x062Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C1E STA
    hw.write(cpu.address("abs", 0x62Eu), cpu.a, cpu.m8?8:16);
    goto L_848C21;
L_848C21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C21u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C21u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C21 REP
    cpu.rep(0x20u);
    goto L_848C23;
L_848C23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C23u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C23u, 5u, 3u, cpu.address("abs", 0x065Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C23 STZ
    hw.write(cpu.address("abs", 0x65Au), 0, cpu.m8?8:16);
    goto L_848C26;
L_848C26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C26u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C26u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C26 LDA
    cpu.setA(0x1u, 16);
    goto L_848C29;
L_848C29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C29u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C29u, 5u, 3u, cpu.address("abs", 0x06E9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C29 STA
    hw.write(cpu.address("abs", 0x6E9u), cpu.a, cpu.m8?8:16);
    goto L_848C2C;
L_848C2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C2Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C2Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C2C LDA
    cpu.setA(0x7u, 16);
    goto L_848C2F;
L_848C2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C2Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C2Fu, 8u, 4u, 0x80A6FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848C2F JSL -> $80A6FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8C32u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8C33u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6FBu, 0x848C2Fu); }
    goto L_848C33;
L_848C33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C33u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C33u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C33u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848C33 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848C33u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848C33u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C33u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C33u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848C33 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848C33u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848C33u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C33u,0x848C33u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_848BF8_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848BF8u: goto L_848BF8;
    case 0x848BFAu: goto L_848BFA;
    case 0x848BFCu: goto L_848BFC;
    case 0x848BFFu: goto L_848BFF;
    case 0x848C01u: goto L_848C01;
    case 0x848C04u: goto L_848C04;
    case 0x848C06u: goto L_848C06;
    case 0x848C07u: goto L_848C07;
    case 0x848C09u: goto L_848C09;
    case 0x848C0Bu: goto L_848C0B;
    case 0x848C0Eu: goto L_848C0E;
    case 0x848C10u: goto L_848C10;
    case 0x848C13u: goto L_848C13;
    case 0x848C15u: goto L_848C15;
    case 0x848C17u: goto L_848C17;
    case 0x848C1Au: goto L_848C1A;
    case 0x848C1Cu: goto L_848C1C;
    case 0x848C1Eu: goto L_848C1E;
    case 0x848C21u: goto L_848C21;
    case 0x848C23u: goto L_848C23;
    case 0x848C26u: goto L_848C26;
    case 0x848C29u: goto L_848C29;
    case 0x848C2Cu: goto L_848C2C;
    case 0x848C2Fu: goto L_848C2F;
    case 0x848C33u: goto L_848C33;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848BF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF8u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848BF8 REP
    cpu.rep(0x20u);
    goto L_848BFA;
L_848BFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848BFA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848BFC;
L_848BFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFCu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848BFC BIT
    cpu.bit(0x200u, true);
    goto L_848BFF;
L_848BFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFFu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848BFF BNE -> $848C09
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_848C09; }
    goto L_848C01;
L_848C01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C01u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C01u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C01 BIT
    cpu.bit(0x100u, true);
    goto L_848C04;
L_848C04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C04u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C04u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C04 BNE -> $848C15
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_848C15; }
    goto L_848C06;
L_848C06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C06u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C06u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C06 CLC
    cpu.setFlag('C', false);
    goto L_848C07;
L_848C07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C07u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C07u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C07 BRA -> $848C33
    goto L_848C33;
L_848C09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C09u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C09u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C09 SEP
    cpu.sep(0x20u);
    goto L_848C0B;
L_848C0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C0Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C0Bu, 4u, 3u, cpu.address("abs", 0x062Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C0B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848C0E;
L_848C0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C0Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C0Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C0E BEQ -> $848C33
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_848C33; }
    goto L_848C10;
L_848C10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C10u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C10u, 4u, 3u, cpu.address("abs", 0x062Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C10 STZ
    hw.write(cpu.address("abs", 0x62Eu), 0, cpu.m8?8:16);
    goto L_848C13;
L_848C13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C13u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C13u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C13 BRA -> $848C21
    goto L_848C21;
L_848C15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C15u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C15u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C15 SEP
    cpu.sep(0x20u);
    goto L_848C17;
L_848C17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C17u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C17u, 4u, 3u, cpu.address("abs", 0x062Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C17 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848C1A;
L_848C1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C1Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C1Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C1A BNE -> $848C33
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_848C33; }
    goto L_848C1C;
L_848C1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C1Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C1Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C1C LDA
    cpu.setA(0x1u, 8);
    goto L_848C1E;
L_848C1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C1Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C1Eu, 4u, 3u, cpu.address("abs", 0x062Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C1E STA
    hw.write(cpu.address("abs", 0x62Eu), cpu.a, cpu.m8?8:16);
    goto L_848C21;
L_848C21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C21u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C21u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C21 REP
    cpu.rep(0x20u);
    goto L_848C23;
L_848C23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C23u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C23u, 5u, 3u, cpu.address("abs", 0x065Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C23 STZ
    hw.write(cpu.address("abs", 0x65Au), 0, cpu.m8?8:16);
    goto L_848C26;
L_848C26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C26u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C26u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C26 LDA
    cpu.setA(0x1u, 16);
    goto L_848C29;
L_848C29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C29u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C29u, 5u, 3u, cpu.address("abs", 0x06E9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C29 STA
    hw.write(cpu.address("abs", 0x6E9u), cpu.a, cpu.m8?8:16);
    goto L_848C2C;
L_848C2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C2Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C2Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C2C LDA
    cpu.setA(0x7u, 16);
    goto L_848C2F;
L_848C2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C2Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C2Fu, 8u, 4u, 0x80A6FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848C2F JSL -> $80A6FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8C32u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8C33u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6FBu, 0x848C2Fu); }
    goto L_848C33;
L_848C33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C33u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C33u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C33u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848C33 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848C33u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848C33u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C33u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C33u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848C33 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848C33u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848C33u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C33u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C33u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848C33 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848C33u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848C33u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C33u,0x848C33u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_84C1B3_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84C1B3u: goto L_84C1B3;
    case 0x84C1B6u: goto L_84C1B6;
    case 0x84C1B9u: goto L_84C1B9;
    case 0x84C1BBu: goto L_84C1BB;
    case 0x84C1BEu: goto L_84C1BE;
    case 0x84C1C1u: goto L_84C1C1;
    case 0x84C1C3u: goto L_84C1C3;
    case 0x84C1C6u: goto L_84C1C6;
    case 0x84C1C9u: goto L_84C1C9;
    case 0x84C1CCu: goto L_84C1CC;
    case 0x84C1CEu: goto L_84C1CE;
    case 0x84C1D1u: goto L_84C1D1;
    case 0x84C1D4u: goto L_84C1D4;
    case 0x84C1D8u: goto L_84C1D8;
    case 0x84C1DAu: goto L_84C1DA;
    case 0x84C1DDu: goto L_84C1DD;
    case 0x84C1E0u: goto L_84C1E0;
    case 0x84C1E2u: goto L_84C1E2;
    case 0x84C1E5u: goto L_84C1E5;
    case 0x84C1E7u: goto L_84C1E7;
    case 0x84C1E8u: goto L_84C1E8;
    case 0x84C1E9u: goto L_84C1E9;
    case 0x84C1ECu: goto L_84C1EC;
    case 0x84C1EEu: goto L_84C1EE;
    case 0x84C1F0u: goto L_84C1F0;
    case 0x84C1F2u: goto L_84C1F2;
    case 0x84C1F4u: goto L_84C1F4;
    case 0x84C1F7u: goto L_84C1F7;
    case 0x84C1FBu: goto L_84C1FB;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84C1B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1B3u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1B3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C1B3 LDX
    cpu.setX(0x0u, 16);
    goto L_84C1B6;
L_84C1B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1B6u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1B6u, 5u + 1u, 3u, cpu.address("absx", 0x01B3u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C1B6 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1B3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84C1B9;
L_84C1B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1B9u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1B9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C1B9 BNE -> $84C1DA
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_84C1DA; }
    goto L_84C1BB;
L_84C1BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1BBu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1BBu, 5u + 1u, 3u, cpu.address("absx", 0x075Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C1BB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x75Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84C1BE;
L_84C1BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1BEu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1BEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C1BE CMP
    cpu.compareA(0x84u);
    goto L_84C1C1;
L_84C1C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1C1u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1C1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C1C1 BCS -> $84C1CE
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_84C1CE; }
    goto L_84C1C3;
L_84C1C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1C3u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1C3u, 9u, 3u, cpu.address("absx", 0x075Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C1C3 INC
    cpu.incMem(hw, cpu.address("absx", 0x75Cu), cpu.m8?8:16);
    goto L_84C1C6;
L_84C1C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1C6u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1C6u, 9u, 3u, cpu.address("absx", 0x075Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C1C6 INC
    cpu.incMem(hw, cpu.address("absx", 0x75Cu), cpu.m8?8:16);
    goto L_84C1C9;
L_84C1C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1C9u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1C9u, 9u, 3u, cpu.address("absx", 0x075Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C1C9 INC
    cpu.incMem(hw, cpu.address("absx", 0x75Cu), cpu.m8?8:16);
    goto L_84C1CC;
L_84C1CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1CCu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1CCu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C1CC BRA -> $84C1FB
    goto L_84C1FB;
L_84C1CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1CEu,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1CEu, 9u, 3u, cpu.address("absx", 0x01B3u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C1CE INC
    cpu.incMem(hw, cpu.address("absx", 0x1B3u), cpu.m8?8:16);
    goto L_84C1D1;
L_84C1D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1D1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1D1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C1D1 LDA
    cpu.setA(0x3Fu, 16);
    goto L_84C1D4;
L_84C1D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1D4u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1D4u, 8u, 4u, 0x80A6FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84C1D4 JSL -> $80A6FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC1D7u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC1D8u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6FBu, 0x84C1D4u); }
    goto L_84C1D8;
L_84C1D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1D8u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC1D8u,0x84C1D8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1D8u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1D8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C1D8 BRA -> $84C1FB
    goto L_84C1FB;
L_84C1DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1DAu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1DAu, 5u + 1u, 3u, cpu.address("absx", 0x075Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C1DA LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x75Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84C1DD;
L_84C1DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1DDu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1DDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C1DD CMP
    cpu.compareA(0x81u);
    goto L_84C1E0;
L_84C1E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1E0u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1E0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C1E0 BCC -> $84C1E7
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_84C1E7; }
    goto L_84C1E2;
L_84C1E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1E2u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1E2u, 9u, 3u, cpu.address("absx", 0x075Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C1E2 DEC
    cpu.decMem(hw, cpu.address("absx", 0x75Cu), cpu.m8?8:16);
    goto L_84C1E5;
L_84C1E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1E5u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1E5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C1E5 BRA -> $84C1FB
    goto L_84C1FB;
L_84C1E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1E7u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1E7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C1E7 INX
    cpu.inc('X');
    goto L_84C1E8;
L_84C1E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1E8u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1E8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C1E8 INX
    cpu.inc('X');
    goto L_84C1E9;
L_84C1E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1E9u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1E9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C1E9 CPX
    cpu.compareX(0xCu);
    goto L_84C1EC;
L_84C1EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1ECu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1ECu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C1EC BCC -> $84C1B6
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_84C1B6; }
    goto L_84C1EE;
L_84C1EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1EEu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1EEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C1EE SEP
    cpu.sep(0x20u);
    goto L_84C1F0;
L_84C1F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1F0u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1F0u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C1F0 INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_84C1F2;
L_84C1F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1F2u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1F2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C1F2 REP
    cpu.rep(0x20u);
    goto L_84C1F4;
L_84C1F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1F4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1F4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C1F4 LDA
    cpu.setA(0x3Du, 16);
    goto L_84C1F7;
L_84C1F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1F7u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1F7u, 8u, 4u, 0x80A6FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84C1F7 JSL -> $80A6FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC1FAu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC1FBu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6FBu, 0x84C1F7u); }
    goto L_84C1FB;
L_84C1FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1FBu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC1FBu,0x84C1FBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1FBu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1FBu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84C1FB RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84C1FBu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84C1FBu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_84C228_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84C228u: goto L_84C228;
    case 0x84C22Au: goto L_84C22A;
    case 0x84C22Du: goto L_84C22D;
    case 0x84C22Fu: goto L_84C22F;
    case 0x84C232u: goto L_84C232;
    case 0x84C234u: goto L_84C234;
    case 0x84C237u: goto L_84C237;
    case 0x84C23Bu: goto L_84C23B;
    case 0x84C23Du: goto L_84C23D;
    case 0x84C240u: goto L_84C240;
    case 0x84C242u: goto L_84C242;
    case 0x84C246u: goto L_84C246;
    case 0x84C248u: goto L_84C248;
    case 0x84C24Bu: goto L_84C24B;
    case 0x84C24Fu: goto L_84C24F;
    case 0x84C251u: goto L_84C251;
    case 0x84C254u: goto L_84C254;
    case 0x84C256u: goto L_84C256;
    case 0x84C25Au: goto L_84C25A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84C228:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC228u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC228u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC228u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C228 REP
    cpu.rep(0x20u);
    goto L_84C22A;
L_84C22A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC22Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC22Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC22Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C22A LDA
    cpu.setA(0x93u, 16);
    goto L_84C22D;
L_84C22D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC22Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC22Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC22Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C22D STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_84C22F;
L_84C22F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC22Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC22Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC22Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C22F LDA
    cpu.setA(0x80u, 16);
    goto L_84C232;
L_84C232:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC232u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC232u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC232u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C232 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_84C234;
L_84C234:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC234u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC234u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC234u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C234 LDX
    cpu.setX(0xCu, 16);
    goto L_84C237;
L_84C237:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC237u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC237u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC237u, 6u, 4u, ((0x93835Au + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C237 LDA
    cpu.loadA(hw.readW(((0x93835Au + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84C23B;
L_84C23B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC23Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC23Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC23Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C23B STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_84C23D;
L_84C23D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC23Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC23Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC23Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C23D LDA
    cpu.setA(0x88u, 16);
    goto L_84C240;
L_84C240:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC240u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC240u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC240u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C240 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_84C242;
L_84C242:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC242u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC242u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC242u, 8u, 4u, 0x80887Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84C242 JSL -> $80887E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC245u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC246u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80887Eu, 0x84C242u); }
    goto L_84C246;
L_84C246:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC246u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC246u,0x84C246u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC246u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC246u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C246 REP
    cpu.rep(0x20u);
    goto L_84C248;
L_84C248:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC248u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC248u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC248u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C248 LDX
    cpu.setX(0xEu, 16);
    goto L_84C24B;
L_84C24B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC24Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC24Bu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC24Bu, 6u, 4u, ((0x93835Au + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C24B LDA
    cpu.loadA(hw.readW(((0x93835Au + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84C24F;
L_84C24F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC24Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC24Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC24Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C24F STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_84C251;
L_84C251:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC251u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC251u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC251u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C251 LDA
    cpu.setA(0x80u, 16);
    goto L_84C254;
L_84C254:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC254u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC254u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC254u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C254 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_84C256;
L_84C256:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC256u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC256u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC256u, 8u, 4u, 0x80887Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84C256 JSL -> $80887E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC259u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC25Au,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80887Eu, 0x84C256u); }
    goto L_84C25A;
L_84C25A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC25Au))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC25Au,0x84C25Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC25Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC25Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84C25A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84C25Au);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84C25Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_84C228_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84C228u: goto L_84C228;
    case 0x84C22Au: goto L_84C22A;
    case 0x84C22Du: goto L_84C22D;
    case 0x84C22Fu: goto L_84C22F;
    case 0x84C232u: goto L_84C232;
    case 0x84C234u: goto L_84C234;
    case 0x84C237u: goto L_84C237;
    case 0x84C23Bu: goto L_84C23B;
    case 0x84C23Du: goto L_84C23D;
    case 0x84C240u: goto L_84C240;
    case 0x84C242u: goto L_84C242;
    case 0x84C246u: goto L_84C246;
    case 0x84C248u: goto L_84C248;
    case 0x84C24Bu: goto L_84C24B;
    case 0x84C24Fu: goto L_84C24F;
    case 0x84C251u: goto L_84C251;
    case 0x84C254u: goto L_84C254;
    case 0x84C256u: goto L_84C256;
    case 0x84C25Au: goto L_84C25A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84C228:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC228u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC228u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC228u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C228 REP
    cpu.rep(0x20u);
    goto L_84C22A;
L_84C22A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC22Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC22Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC22Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C22A LDA
    cpu.setA(0x93u, 16);
    goto L_84C22D;
L_84C22D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC22Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC22Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC22Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C22D STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_84C22F;
L_84C22F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC22Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC22Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC22Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C22F LDA
    cpu.setA(0x80u, 16);
    goto L_84C232;
L_84C232:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC232u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC232u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC232u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C232 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_84C234;
L_84C234:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC234u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC234u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC234u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C234 LDX
    cpu.setX(0xCu, 16);
    goto L_84C237;
L_84C237:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC237u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC237u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC237u, 6u, 4u, ((0x93835Au + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C237 LDA
    cpu.loadA(hw.readW(((0x93835Au + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84C23B;
L_84C23B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC23Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC23Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC23Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C23B STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_84C23D;
L_84C23D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC23Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC23Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC23Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C23D LDA
    cpu.setA(0x88u, 16);
    goto L_84C240;
L_84C240:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC240u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC240u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC240u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C240 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_84C242;
L_84C242:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC242u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC242u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC242u, 8u, 4u, 0x80887Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84C242 JSL -> $80887E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC245u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC246u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80887Eu, 0x84C242u); }
    goto L_84C246;
L_84C246:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC246u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC246u,0x84C246u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC246u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC246u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C246 REP
    cpu.rep(0x20u);
    goto L_84C248;
L_84C248:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC248u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC248u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC248u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C248 LDX
    cpu.setX(0xEu, 16);
    goto L_84C24B;
L_84C24B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC24Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC24Bu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC24Bu, 6u, 4u, ((0x93835Au + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C24B LDA
    cpu.loadA(hw.readW(((0x93835Au + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84C24F;
L_84C24F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC24Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC24Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC24Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C24F STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_84C251;
L_84C251:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC251u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC251u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC251u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C251 LDA
    cpu.setA(0x80u, 16);
    goto L_84C254;
L_84C254:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC254u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC254u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC254u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C254 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_84C256;
L_84C256:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC256u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC256u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC256u, 8u, 4u, 0x80887Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84C256 JSL -> $80887E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC259u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC25Au,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80887Eu, 0x84C256u); }
    goto L_84C25A;
L_84C25A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC25Au))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC25Au,0x84C25Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC25Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC25Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84C25A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84C25Au);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84C25Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

