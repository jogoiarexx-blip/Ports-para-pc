#include "generated.hpp"
void sub_80840F_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80840Fu: goto L_80840F;
    case 0x808413u: goto L_808413;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80840F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x840Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x840Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x840Fu, 8u, 4u, 0x80AB15u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80840F JSL -> $80AB15 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8412u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8413u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80AB15u, 0x80840Fu); }
    goto L_808413;
L_808413:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8413u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8413u,0x808413u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8413u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8413u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808413 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808413u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x808413u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80840F_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80840Fu: goto L_80840F;
    case 0x808413u: goto L_808413;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80840F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x840Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x840Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x840Fu, 8u, 4u, 0x80AB15u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80840F JSL -> $80AB15 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8412u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8413u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80AB15u, 0x80840Fu); }
    goto L_808413;
L_808413:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8413u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8413u,0x808413u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8413u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8413u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808413 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808413u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x808413u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_808572_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808572u: goto L_808572;
    case 0x808573u: goto L_808573;
    case 0x808575u: goto L_808575;
    case 0x808577u: goto L_808577;
    case 0x808579u: goto L_808579;
    case 0x80857Bu: goto L_80857B;
    case 0x80857Eu: goto L_80857E;
    case 0x80857Fu: goto L_80857F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808572:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8572u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8572u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8572u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808572 PHP
    cpu.push("PHP", hw);
    goto L_808573;
L_808573:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8573u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8573u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8573u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808573 SEP
    cpu.sep(0x20u);
    goto L_808575;
L_808575:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8575u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8575u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8575u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808575 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x74u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808577;
L_808577:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8577u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8577u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8577u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808577 ORA
    cpu.logicOr(0x80u);
    goto L_808579;
L_808579:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8579u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8579u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8579u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808579 STA
    hw.write(cpu.address("dp", 0x74u), cpu.a, cpu.m8?8:16);
    goto L_80857B;
L_80857B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x857Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x857Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x857Bu, 4u, 3u, cpu.address("abs", 0x2100u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80857B STA
    hw.write(cpu.address("abs", 0x2100u), cpu.a, cpu.m8?8:16);
    goto L_80857E;
L_80857E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x857Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x857Eu,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x857Eu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80857E PLP
    cpu.pop("PLP", hw);
    goto L_80857F;
L_80857F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x857Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x857Fu,0x80857Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x857Fu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x857Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80857F RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80857Fu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80857Fu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_809C3A_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809C3Au: goto L_809C3A;
    case 0x809C3Du: goto L_809C3D;
    case 0x809C41u: goto L_809C41;
    case 0x809C45u: goto L_809C45;
    case 0x809C46u: goto L_809C46;
    case 0x809C47u: goto L_809C47;
    case 0x809C49u: goto L_809C49;
    case 0x809C4Cu: goto L_809C4C;
    case 0x809C4Fu: goto L_809C4F;
    case 0x809C51u: goto L_809C51;
    case 0x809C53u: goto L_809C53;
    case 0x809C55u: goto L_809C55;
    case 0x809C58u: goto L_809C58;
    case 0x809C5Au: goto L_809C5A;
    case 0x809C5Du: goto L_809C5D;
    case 0x809C5Fu: goto L_809C5F;
    case 0x809C61u: goto L_809C61;
    case 0x809C63u: goto L_809C63;
    case 0x809C65u: goto L_809C65;
    case 0x809C66u: goto L_809C66;
    case 0x809C68u: goto L_809C68;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809C3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C3Au,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C3Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C3A LDX
    cpu.setX(0x1F8u, 16);
    goto L_809C3D;
L_809C3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C3Du,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C3Du, 6u, 4u, ((0x7E2220u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C3D LDA
    cpu.loadA(hw.readW(((0x7E2220u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809C41;
L_809C41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C41u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C41u, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C41 STA
    hw.write(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_809C45;
L_809C45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C45u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C45u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C45 DEX
    cpu.decReg('X');
    goto L_809C46;
L_809C46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C46u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C46u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C46 DEX
    cpu.decReg('X');
    goto L_809C47;
L_809C47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C47u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C47u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C47 BPL -> $809C3D
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_809C3D; }
    goto L_809C49;
L_809C49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C49u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C49u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C49 LDY
    cpu.setY(0x8u, 16);
    goto L_809C4C;
L_809C4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C4Cu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C4Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C4C LDX
    cpu.setX(0x100u, 16);
    goto L_809C4F;
L_809C4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C4Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C4Fu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C4Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C4F STZ
    hw.write(cpu.address("dp", 0x0u), 0, cpu.m8?8:16);
    goto L_809C51;
L_809C51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C51u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C51u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C51 STX
    hw.write(cpu.address("dp", 0x2u), cpu.x, cpu.x8?8:16);
    goto L_809C53;
L_809C53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C53u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C53u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C53u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C53 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x2u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_809C55;
L_809C55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C55u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C55u, 5u + 1u, 3u, cpu.address("absx", 0x02AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C55 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x2AAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809C58;
L_809C58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C58u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C58u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C58 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_809C5A;
L_809C5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C5Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C5Au,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C5Au, 6u, 3u, cpu.address("absx", 0x02AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C5A STA
    hw.write(cpu.address("absx", 0x2AAu), cpu.a, cpu.m8?8:16);
    goto L_809C5D;
L_809C5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C5Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C5Du,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C5Du, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C5D INC
    cpu.incMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_809C5F;
L_809C5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C5Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C5Fu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C5Fu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C5F INC
    cpu.incMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_809C61;
L_809C61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C61u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C61u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C61 INC
    cpu.incMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_809C63;
L_809C63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C63u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C63u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C63u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C63 INC
    cpu.incMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_809C65;
L_809C65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C65u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C65u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C65 DEY
    cpu.decReg('Y');
    goto L_809C66;
L_809C66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C66u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C66u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C66u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C66 BPL -> $809C53
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_809C53; }
    goto L_809C68;
L_809C68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C68u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C68u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $809C68 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x809C68u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x809C68u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80AB4C_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80AB4Cu: goto L_80AB4C;
    case 0x80AB4Eu: goto L_80AB4E;
    case 0x80AB50u: goto L_80AB50;
    case 0x80AB52u: goto L_80AB52;
    case 0x80AB55u: goto L_80AB55;
    case 0x80AB56u: goto L_80AB56;
    case 0x80AB57u: goto L_80AB57;
    case 0x80AB5Au: goto L_80AB5A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80AB4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB4Cu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB4Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB4C SEP
    cpu.sep(0x20u);
    goto L_80AB4E;
L_80AB4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB4Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB4Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB4E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x49u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AB50;
L_80AB50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB50u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB50u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB50 REP
    cpu.rep(0x20u);
    goto L_80AB52;
L_80AB52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB52u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB52u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB52 AND
    cpu.logicAnd(0xFFu);
    goto L_80AB55;
L_80AB55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB55u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB55u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB55 ASL
    cpu.aslA();
    goto L_80AB56;
L_80AB56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB56u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB56u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB56u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB56 TAX
    cpu.transfer("TAX");
    goto L_80AB57;
L_80AB57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB57u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB57u, 5u, 3u, cpu.address("abs", 0xAB5Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AB57 PEA
    cpu.push16Value(hw, 0xAB5Cu);
    goto L_80AB5A;
L_80AB5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB5Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB5Au,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB5Au, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0xAB5Eu + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $80AB5A JMP (AB5E,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0xAB5Eu+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x80AB5Au); return; }
}

void sub_80AB4C_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80AB4Cu: goto L_80AB4C;
    case 0x80AB4Eu: goto L_80AB4E;
    case 0x80AB50u: goto L_80AB50;
    case 0x80AB52u: goto L_80AB52;
    case 0x80AB55u: goto L_80AB55;
    case 0x80AB56u: goto L_80AB56;
    case 0x80AB57u: goto L_80AB57;
    case 0x80AB5Au: goto L_80AB5A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80AB4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB4Cu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB4Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB4C SEP
    cpu.sep(0x20u);
    goto L_80AB4E;
L_80AB4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB4Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB4Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB4E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x49u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AB50;
L_80AB50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB50u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB50u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB50 REP
    cpu.rep(0x20u);
    goto L_80AB52;
L_80AB52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB52u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB52u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB52 AND
    cpu.logicAnd(0xFFu);
    goto L_80AB55;
L_80AB55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB55u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB55u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB55 ASL
    cpu.aslA();
    goto L_80AB56;
L_80AB56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB56u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB56u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB56u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB56 TAX
    cpu.transfer("TAX");
    goto L_80AB57;
L_80AB57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB57u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB57u, 5u, 3u, cpu.address("abs", 0xAB5Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AB57 PEA
    cpu.push16Value(hw, 0xAB5Cu);
    goto L_80AB5A;
L_80AB5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB5Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB5Au,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB5Au, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0xAB5Eu + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $80AB5A JMP (AB5E,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0xAB5Eu+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x80AB5Au); return; }
}

void sub_80B1C6_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B1C6u: goto L_80B1C6;
    case 0x80B1C9u: goto L_80B1C9;
    case 0x80B1CBu: goto L_80B1CB;
    case 0x80B1CEu: goto L_80B1CE;
    case 0x80B1D1u: goto L_80B1D1;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B1C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1C6u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1C6u, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B1C6 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x958u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B1C9;
L_80B1C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1C9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1C9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B1C9 BEQ -> $80B1CE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B1CE; }
    goto L_80B1CB;
L_80B1CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1CBu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1CBu, 6u, 3u, cpu.address("abs", 0xCD63u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B1CB JSR -> $80CD63 stack real
    { cpu.push16Value(hw,0xB1CDu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB1CEu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCD63u), 0x80B1CBu); }
    goto L_80B1CE;
L_80B1CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1CEu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1CEu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1CEu, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B1CE INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B1D1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1CEu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1CEu, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B1CE INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B1D1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB1CEu,0x80B1CEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B1D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1D1u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1D1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1D1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B1D1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B1D1u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B1D1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1D1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1D1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B1D1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B1D1u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B1D1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB1D1u,0x80B1D1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80B496_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B496u: goto L_80B496;
    case 0x80B498u: goto L_80B498;
    case 0x80B49Bu: goto L_80B49B;
    case 0x80B49Du: goto L_80B49D;
    case 0x80B49Fu: goto L_80B49F;
    case 0x80B4A0u: goto L_80B4A0;
    case 0x80B4A1u: goto L_80B4A1;
    case 0x80B4A2u: goto L_80B4A2;
    case 0x80B4A3u: goto L_80B4A3;
    case 0x80B4A4u: goto L_80B4A4;
    case 0x80B4A5u: goto L_80B4A5;
    case 0x80B4A7u: goto L_80B4A7;
    case 0x80B4A9u: goto L_80B4A9;
    case 0x80B4ABu: goto L_80B4AB;
    case 0x80B4AEu: goto L_80B4AE;
    case 0x80B4B0u: goto L_80B4B0;
    case 0x80B4B2u: goto L_80B4B2;
    case 0x80B4B5u: goto L_80B4B5;
    case 0x80B4B8u: goto L_80B4B8;
    case 0x80B4BAu: goto L_80B4BA;
    case 0x80B4BDu: goto L_80B4BD;
    case 0x80B4BEu: goto L_80B4BE;
    case 0x80B4C0u: goto L_80B4C0;
    case 0x80B4C1u: goto L_80B4C1;
    case 0x80B4C5u: goto L_80B4C5;
    case 0x80B4C7u: goto L_80B4C7;
    case 0x80B4C9u: goto L_80B4C9;
    case 0x80B4CBu: goto L_80B4CB;
    case 0x80B4CDu: goto L_80B4CD;
    case 0x80B4CFu: goto L_80B4CF;
    case 0x80B4D1u: goto L_80B4D1;
    case 0x80B4D4u: goto L_80B4D4;
    case 0x80B4D6u: goto L_80B4D6;
    case 0x80B4D9u: goto L_80B4D9;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B496:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB496u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB496u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB496u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B496 STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_80B498;
L_80B498:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB498u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB498u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB498u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B498 LDA
    cpu.setA(0x6u, 16);
    goto L_80B49B;
L_80B49B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB49Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB49Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB49Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B49B STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80B49D;
L_80B49D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB49Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB49Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB49Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xB2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B49D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xB2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B49F;
L_80B49F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB49Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB49Fu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB49Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B49F INC
    cpu.inc('A');
    goto L_80B4A0;
L_80B4A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4A0u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4A0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4A0 INC
    cpu.inc('A');
    goto L_80B4A1;
L_80B4A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4A1u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4A1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4A1 INC
    cpu.inc('A');
    goto L_80B4A2;
L_80B4A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4A2u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4A2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4A2 INC
    cpu.inc('A');
    goto L_80B4A3;
L_80B4A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4A3u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4A3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4A3 INC
    cpu.inc('A');
    goto L_80B4A4;
L_80B4A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4A4u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4A4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4A4 INC
    cpu.inc('A');
    goto L_80B4A5;
L_80B4A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4A5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4A5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4A5 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_80B4A7;
L_80B4A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4A7u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4A7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4A7 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x2u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80B4A9;
L_80B4A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4A9u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4A9u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xAEu) & 0xFFFFu), 3u, 0u);
    // $80B4A9 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0xAEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B4AB;
L_80B4AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4ABu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4ABu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4AB CMP
    cpu.compareA(0xFFFFu);
    goto L_80B4AE;
L_80B4AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4AEu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4AEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4AE BEQ -> $80B4C7
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B4C7; }
    goto L_80B4B0;
L_80B4B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B0u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4B0 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80B4B2;
L_80B4B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B2u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B2u, 5u + 1u, 3u, cpu.address("absy", 0x097Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4B2 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x97Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B4B5;
L_80B4B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B5u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4B5 CMP
    cpu.compareA(0xFFu);
    goto L_80B4B8;
L_80B4B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B8u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4B8 BEQ -> $80B4C7
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B4C7; }
    goto L_80B4BA;
L_80B4BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BAu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BAu, 5u + 1u, 3u, cpu.address("absy", 0x093Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4BA LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x93Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B4BD;
L_80B4BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BDu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4BD CLC
    cpu.setFlag('C', false);
    goto L_80B4BE;
L_80B4BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BEu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4BE ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16));
    goto L_80B4C0;
L_80B4C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C0u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4C0 TAX
    cpu.transfer("TAX");
    goto L_80B4C1;
L_80B4C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C1u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C1u, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4C1 LDA
    cpu.loadA(hw.readW(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B4C5;
L_80B4C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C5u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4C5 BNE -> $80B4D6
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B4D6; }
    goto L_80B4C7;
L_80B4C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C7u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C7u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4C7 DEC
    cpu.decMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_80B4C9;
L_80B4C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C9u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C9u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4C9 DEC
    cpu.decMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_80B4CB;
L_80B4CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4CBu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4CBu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4CB DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_80B4CD;
L_80B4CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4CDu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4CDu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4CD DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_80B4CF;
L_80B4CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4CFu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4CFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4CF BPL -> $80B4A7
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80B4A7; }
    goto L_80B4D1;
L_80B4D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4D1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4D1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4D1 LDA
    cpu.setA(0x0u, 16);
    goto L_80B4D4;
L_80B4D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4D4u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4D4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4D4 BRA -> $80B4D9
    goto L_80B4D9;
L_80B4D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4D6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4D6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4D6 LDA
    cpu.setA(0xFFFFu, 16);
    goto L_80B4D9;
L_80B4D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4D9u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4D9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B4D9 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B4D9u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B4D9u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80BA05_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80BA05u: goto L_80BA05;
    case 0x80BA08u: goto L_80BA08;
    case 0x80BA0Bu: goto L_80BA0B;
    case 0x80BA0Du: goto L_80BA0D;
    case 0x80BA10u: goto L_80BA10;
    case 0x80BA12u: goto L_80BA12;
    case 0x80BA15u: goto L_80BA15;
    case 0x80BA17u: goto L_80BA17;
    case 0x80BA1Au: goto L_80BA1A;
    case 0x80BA1Cu: goto L_80BA1C;
    case 0x80BA1Fu: goto L_80BA1F;
    case 0x80BA21u: goto L_80BA21;
    case 0x80BA24u: goto L_80BA24;
    case 0x80BA25u: goto L_80BA25;
    case 0x80BA28u: goto L_80BA28;
    case 0x80BA2Au: goto L_80BA2A;
    case 0x80BA2Du: goto L_80BA2D;
    case 0x80BA2Fu: goto L_80BA2F;
    case 0x80BA32u: goto L_80BA32;
    case 0x80BA34u: goto L_80BA34;
    case 0x80BA37u: goto L_80BA37;
    case 0x80BA3Au: goto L_80BA3A;
    case 0x80BA3Cu: goto L_80BA3C;
    case 0x80BA3Fu: goto L_80BA3F;
    case 0x80BA41u: goto L_80BA41;
    case 0x80BA43u: goto L_80BA43;
    case 0x80BA45u: goto L_80BA45;
    case 0x80BA46u: goto L_80BA46;
    case 0x80BA47u: goto L_80BA47;
    case 0x80BA49u: goto L_80BA49;
    case 0x80BA4Cu: goto L_80BA4C;
    case 0x80BA4Du: goto L_80BA4D;
    case 0x80BA50u: goto L_80BA50;
    case 0x80BA52u: goto L_80BA52;
    case 0x80BA55u: goto L_80BA55;
    case 0x80BA57u: goto L_80BA57;
    case 0x80BA5Au: goto L_80BA5A;
    case 0x80BA5Cu: goto L_80BA5C;
    case 0x80BA5Eu: goto L_80BA5E;
    case 0x80BA60u: goto L_80BA60;
    case 0x80BA62u: goto L_80BA62;
    case 0x80BA66u: goto L_80BA66;
    case 0x80BA68u: goto L_80BA68;
    case 0x80BA6Cu: goto L_80BA6C;
    case 0x80BA6Eu: goto L_80BA6E;
    case 0x80BA70u: goto L_80BA70;
    case 0x80BA72u: goto L_80BA72;
    case 0x80BA74u: goto L_80BA74;
    case 0x80BA76u: goto L_80BA76;
    case 0x80BA7Au: goto L_80BA7A;
    case 0x80BA7Cu: goto L_80BA7C;
    case 0x80BA80u: goto L_80BA80;
    case 0x80BA82u: goto L_80BA82;
    case 0x80BA85u: goto L_80BA85;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80BA05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA05u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA05u, 5u, 3u, cpu.address("abs", 0x0904u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA05 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x904u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BA08;
L_80BA08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA08u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA08u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA08 CMP
    cpu.compareA(0x7u);
    goto L_80BA0B;
L_80BA0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA0Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA0Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA0B BNE -> $80BA25
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BA25; }
    goto L_80BA0D;
L_80BA0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA0Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA0Du, 5u, 3u, cpu.address("abs", 0x091Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA0D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x91Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BA10;
L_80BA10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA10u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA10u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA10 BNE -> $80BA17
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BA17; }
    goto L_80BA12;
L_80BA12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA12u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA12u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA12 LDA
    cpu.setA(0x0u, 16);
    goto L_80BA15;
L_80BA15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA15u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA15u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA15 BRA -> $80BA24
    goto L_80BA24;
L_80BA17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA17u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA17u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA17 CMP
    cpu.compareA(0x2u);
    goto L_80BA1A;
L_80BA1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA1Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA1Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA1A BNE -> $80BA21
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BA21; }
    goto L_80BA1C;
L_80BA1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA1Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA1Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA1C LDA
    cpu.setA(0x2u, 16);
    goto L_80BA1F;
L_80BA1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA1Fu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA1Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA1F BRA -> $80BA24
    goto L_80BA24;
L_80BA21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA21u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA21u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA21 LDA
    cpu.setA(0x3u, 16);
    goto L_80BA24;
L_80BA24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA24u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA24u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BA24 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80BA24u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80BA24u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80BA25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA25u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA25u, 5u + 1u, 3u, cpu.address("absx", 0x0932u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA25 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x932u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BA28;
L_80BA28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA28u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA28u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA28 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80BA2A;
L_80BA2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA2Au,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA2Au, 5u + 1u, 3u, cpu.address("absx", 0x092Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA2A LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x92Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BA2D;
L_80BA2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA2Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA2Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA2D STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_80BA2F;
L_80BA2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA2Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA2Fu, 5u + 1u, 3u, cpu.address("absx", 0x0906u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA2F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x906u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BA32;
L_80BA32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA32u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA32u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA32 STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_80BA34;
L_80BA34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA34u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA34u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA34 LDX
    cpu.setX(0x6u, 16);
    goto L_80BA37;
L_80BA37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA37u,cpu,0xECu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA37u, 5u, 3u, cpu.address("abs", 0x091Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA37 CPX
    cpu.compareX(hw.readW(cpu.address("abs", 0x91Eu), cpu.x8?8:16));
    goto L_80BA3A;
L_80BA3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA3Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA3Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA3A BEQ -> $80BA45
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BA45; }
    goto L_80BA3C;
L_80BA3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA3Cu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA3Cu, 5u + 1u, 3u, cpu.address("absx", 0x0906u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA3C LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x906u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BA3F;
L_80BA3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA3Fu,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA3Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA3F CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16));
    goto L_80BA41;
L_80BA41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA41u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA41u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA41 BNE -> $80BA45
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BA45; }
    goto L_80BA43;
L_80BA43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA43u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA43u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA43 BRA -> $80BA4D
    goto L_80BA4D;
L_80BA45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA45u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA45u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA45 DEX
    cpu.decReg('X');
    goto L_80BA46;
L_80BA46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA46u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA46u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA46 DEX
    cpu.decReg('X');
    goto L_80BA47;
L_80BA47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA47u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA47u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA47 BPL -> $80BA37
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80BA37; }
    goto L_80BA49;
L_80BA49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA49u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA49u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA49 LDA
    cpu.setA(0x0u, 16);
    goto L_80BA4C;
L_80BA4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA4Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA4Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BA4C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80BA4Cu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80BA4Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80BA4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA4Du,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA4Du, 5u + 1u, 3u, cpu.address("absx", 0x0932u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA4D LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x932u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BA50;
L_80BA50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA50u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA50u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA50 STA
    hw.write(cpu.address("dp", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_80BA52;
L_80BA52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA52u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA52u, 5u + 1u, 3u, cpu.address("absx", 0x092Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA52 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x92Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BA55;
L_80BA55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA55u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA55u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA55 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80BA57;
L_80BA57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA57u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA57u, 5u, 3u, cpu.address("abs", 0x0920u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA57 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x920u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BA5A;
L_80BA5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA5Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA5Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA5Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA5A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BA5C;
L_80BA5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA5Cu,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA5Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA5C CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x6u), cpu.m8?8:16));
    goto L_80BA5E;
L_80BA5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA5Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA5Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA5E BEQ -> $80BA6E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BA6E; }
    goto L_80BA60;
L_80BA60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA60u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA60u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA60 BCC -> $80BA68
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80BA68; }
    goto L_80BA62;
L_80BA62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA62u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA62u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA62u, 6u, 4u, ((0x80BA93u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA62 LDA
    cpu.loadA(hw.readW(((0x80BA93u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BA66;
L_80BA66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA66u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA66u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA66u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA66 BRA -> $80BA4C
    goto L_80BA4C;
L_80BA68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA68u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA68u, 6u, 4u, ((0x80BA99u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA68 LDA
    cpu.loadA(hw.readW(((0x80BA99u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BA6C;
L_80BA6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA6Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA6Cu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA6Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA6C BRA -> $80BA4C
    goto L_80BA4C;
L_80BA6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA6Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA6Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA6E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BA70;
L_80BA70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA70u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA70u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA70 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_80BA72;
L_80BA72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA72u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA72u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA72 BEQ -> $80BA82
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BA82; }
    goto L_80BA74;
L_80BA74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA74u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA74u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA74 BCS -> $80BA7C
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80BA7C; }
    goto L_80BA76;
L_80BA76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA76u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA76u, 6u, 4u, ((0x80BA8Du + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA76 LDA
    cpu.loadA(hw.readW(((0x80BA8Du + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BA7A;
L_80BA7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA7Au,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA7Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA7A BRA -> $80BA4C
    goto L_80BA4C;
L_80BA7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA7Cu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA7Cu, 6u, 4u, ((0x80BA87u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA7C LDA
    cpu.loadA(hw.readW(((0x80BA87u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BA80;
L_80BA80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA80u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA80u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA80u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA80 BRA -> $80BA4C
    goto L_80BA4C;
L_80BA82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA82u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA82u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA82 LDA
    cpu.setA(0x0u, 16);
    goto L_80BA85;
L_80BA85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA85u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA85u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA85 BRA -> $80BA4C
    goto L_80BA4C;
}

void sub_80BBFA_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80BBFAu: goto L_80BBFA;
    case 0x80BBFBu: goto L_80BBFB;
    case 0x80BBFCu: goto L_80BBFC;
    case 0x80BBFDu: goto L_80BBFD;
    case 0x80BBFFu: goto L_80BBFF;
    case 0x80BC01u: goto L_80BC01;
    case 0x80BC04u: goto L_80BC04;
    case 0x80BC06u: goto L_80BC06;
    case 0x80BC0Au: goto L_80BC0A;
    case 0x80BC0Du: goto L_80BC0D;
    case 0x80BC0Fu: goto L_80BC0F;
    case 0x80BC12u: goto L_80BC12;
    case 0x80BC14u: goto L_80BC14;
    case 0x80BC18u: goto L_80BC18;
    case 0x80BC1Au: goto L_80BC1A;
    case 0x80BC1Eu: goto L_80BC1E;
    case 0x80BC20u: goto L_80BC20;
    case 0x80BC22u: goto L_80BC22;
    case 0x80BC24u: goto L_80BC24;
    case 0x80BC26u: goto L_80BC26;
    case 0x80BC28u: goto L_80BC28;
    case 0x80BC2Au: goto L_80BC2A;
    case 0x80BC2Cu: goto L_80BC2C;
    case 0x80BC2Eu: goto L_80BC2E;
    case 0x80BC31u: goto L_80BC31;
    case 0x80BC32u: goto L_80BC32;
    case 0x80BC34u: goto L_80BC34;
    case 0x80BC37u: goto L_80BC37;
    case 0x80BC39u: goto L_80BC39;
    case 0x80BC3Au: goto L_80BC3A;
    case 0x80BC3Bu: goto L_80BC3B;
    case 0x80BC3Cu: goto L_80BC3C;
    case 0x80BC40u: goto L_80BC40;
    case 0x80BC42u: goto L_80BC42;
    case 0x80BC45u: goto L_80BC45;
    case 0x80BC48u: goto L_80BC48;
    case 0x80BC4Au: goto L_80BC4A;
    case 0x80BC4Du: goto L_80BC4D;
    case 0x80BC50u: goto L_80BC50;
    case 0x80BC52u: goto L_80BC52;
    case 0x80BC55u: goto L_80BC55;
    case 0x80BC57u: goto L_80BC57;
    case 0x80BC58u: goto L_80BC58;
    case 0x80BC59u: goto L_80BC59;
    case 0x80BC5Bu: goto L_80BC5B;
    case 0x80BC5Du: goto L_80BC5D;
    case 0x80BC60u: goto L_80BC60;
    case 0x80BC63u: goto L_80BC63;
    case 0x80BC66u: goto L_80BC66;
    case 0x80BC69u: goto L_80BC69;
    case 0x80BC6Cu: goto L_80BC6C;
    case 0x80BC6Eu: goto L_80BC6E;
    case 0x80BC71u: goto L_80BC71;
    case 0x80BC74u: goto L_80BC74;
    case 0x80BC76u: goto L_80BC76;
    case 0x80BC79u: goto L_80BC79;
    case 0x80BC7Cu: goto L_80BC7C;
    case 0x80BC7Eu: goto L_80BC7E;
    case 0x80BC81u: goto L_80BC81;
    case 0x80BC82u: goto L_80BC82;
    case 0x80BC84u: goto L_80BC84;
    case 0x80BC87u: goto L_80BC87;
    case 0x80BC88u: goto L_80BC88;
    case 0x80BC89u: goto L_80BC89;
    case 0x80BC8Au: goto L_80BC8A;
    case 0x80BC8Bu: goto L_80BC8B;
    case 0x80BC8Du: goto L_80BC8D;
    case 0x80BC8Fu: goto L_80BC8F;
    case 0x80BC92u: goto L_80BC92;
    case 0x80BC94u: goto L_80BC94;
    case 0x80BC97u: goto L_80BC97;
    case 0x80BC99u: goto L_80BC99;
    case 0x80BC9Cu: goto L_80BC9C;
    case 0x80BC9Eu: goto L_80BC9E;
    case 0x80BCA0u: goto L_80BCA0;
    case 0x80BCA2u: goto L_80BCA2;
    case 0x80BCA5u: goto L_80BCA5;
    case 0x80BCA7u: goto L_80BCA7;
    case 0x80BCAAu: goto L_80BCAA;
    case 0x80BCADu: goto L_80BCAD;
    case 0x80BCAFu: goto L_80BCAF;
    case 0x80BCB2u: goto L_80BCB2;
    case 0x80BCB5u: goto L_80BCB5;
    case 0x80BCB7u: goto L_80BCB7;
    case 0x80BCBAu: goto L_80BCBA;
    case 0x80BCBDu: goto L_80BCBD;
    case 0x80BCC0u: goto L_80BCC0;
    case 0x80BCC1u: goto L_80BCC1;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80BBFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBFAu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBFAu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80BBFA PHB
    cpu.push("PHB", hw);
    goto L_80BBFB;
L_80BBFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBFBu,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBFBu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80BBFB PHK
    cpu.push("PHK", hw);
    goto L_80BBFC;
L_80BBFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBFCu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBFCu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80BBFC PLB
    cpu.pop("PLB", hw);
    goto L_80BBFD;
L_80BBFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBFDu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBFDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBFD STZ
    hw.write(cpu.address("dp", 0x61u), 0, cpu.m8?8:16);
    goto L_80BBFF;
L_80BBFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBFFu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBFFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBFF STZ
    hw.write(cpu.address("dp", 0x63u), 0, cpu.m8?8:16);
    goto L_80BC01;
L_80BC01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC01u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC01u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC01u, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC01 STZ
    hw.write(cpu.address("abs", 0x958u), 0, cpu.m8?8:16);
    goto L_80BC04;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC01u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC01u, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC01 STZ
    hw.write(cpu.address("abs", 0x958u), 0, cpu.m8?8:16);
    goto L_80BC04;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC01u,0x80BC01u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BC04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC04u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC04u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC04u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC04 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BC06;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC04u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC04u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC04 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BC06;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC04u,0x80BC04u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BC06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC06u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC06u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC06u, 6u, 4u, ((0x7E2440u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC06 LDA
    cpu.loadA(hw.readW(((0x7E2440u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BC0A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC06u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC06u, 6u, 4u, ((0x7E2440u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC06 LDA
    cpu.loadA(hw.readW(((0x7E2440u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BC0A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC06u,0x80BC06u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BC0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC0Au))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC0Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC0Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC0A CMP
    cpu.compareA(0xFFFFu);
    goto L_80BC0D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC0Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC0Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC0A CMP
    cpu.compareA(0xFFFFu);
    goto L_80BC0D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC0Au,0x80BC0Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BC0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC0Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC0Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC0D BNE -> $80BC12
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BC12; }
    goto L_80BC0F;
L_80BC0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC0Fu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC0Fu, 3u, 3u, cpu.address("abs", 0xBCBAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC0F JMP -> $80BCBA
    goto L_80BCBA;
L_80BC12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC12u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC12u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC12 STA
    hw.write(cpu.address("dp", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_80BC14;
L_80BC14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC14u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC14u, 6u, 4u, ((0x7E2442u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC14 LDA
    cpu.loadA(hw.readW(((0x7E2442u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BC18;
L_80BC18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC18u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC18u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC18 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_80BC1A;
L_80BC1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC1Au,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC1Au, 6u, 4u, ((0x7E2444u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC1A LDA
    cpu.loadA(hw.readW(((0x7E2444u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BC1E;
L_80BC1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC1Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC1Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC1E STA
    hw.write(cpu.address("dp", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_80BC20;
L_80BC20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC20u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC20u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC20 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80BC22;
L_80BC22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC22u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC22u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC22 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80BC24;
L_80BC24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC24u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC24u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC24 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80BC26;
L_80BC26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC26u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC26u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC26 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80BC28;
L_80BC28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC28u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC28u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC28 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80BC2A;
L_80BC2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC2Au,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC2Au, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC2A INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80BC2C;
L_80BC2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC2Cu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC2Cu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC2Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC2C LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x10u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BC2E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC2Cu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC2Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC2C LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x10u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BC2E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC2Cu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC2Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC2C LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x10u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BC2E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC2Cu,0x80BC2Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BC2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC2Eu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC2Eu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC2Eu, 5u + 1u, 3u, cpu.address("absy", 0xBDEBu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC2E LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xBDEBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BC31;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC2Eu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC2Eu, 5u + 1u, 3u, cpu.address("absy", 0xBDEBu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC2E LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xBDEBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BC31;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC2Eu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC2Eu, 5u + 1u, 3u, cpu.address("absy", 0xBDEBu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC2E LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xBDEBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BC31;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC2Eu,0x80BC2Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BC31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC31u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC31u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC31u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC31 CLC
    cpu.setFlag('C', false);
    goto L_80BC32;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC31u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC31u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC31 CLC
    cpu.setFlag('C', false);
    goto L_80BC32;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC31u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC31u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC31 CLC
    cpu.setFlag('C', false);
    goto L_80BC32;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC31u,0x80BC31u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BC32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC32u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC32u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC32 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x14u), cpu.m8?8:16));
    goto L_80BC34;
L_80BC34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC34u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC34u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC34 CPY
    cpu.compareY(0x2u);
    goto L_80BC37;
L_80BC37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC37u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC37u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC37 BNE -> $80BC3B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BC3B; }
    goto L_80BC39;
L_80BC39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC39u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC39u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC39 INC
    cpu.inc('A');
    goto L_80BC3A;
L_80BC3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC3Au,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC3Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC3A INC
    cpu.inc('A');
    goto L_80BC3B;
L_80BC3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC3Bu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC3Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC3B TAX
    cpu.transfer("TAX");
    goto L_80BC3C;
L_80BC3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC3Cu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC3Cu, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC3C LDA
    cpu.loadA(hw.readW(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BC40;
L_80BC40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC40u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC40u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC40 BNE -> $80BC9E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BC9E; }
    goto L_80BC42;
L_80BC42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC42u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC42u, 5u, 3u, cpu.address("abs", 0x0918u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC42 STX
    hw.write(cpu.address("abs", 0x918u), cpu.x, cpu.x8?8:16);
    goto L_80BC45;
L_80BC45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC45u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC45u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC45 LDX
    cpu.setX(0x6u, 16);
    goto L_80BC48;
L_80BC48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC48u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC48u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC48 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x10u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BC4A;
L_80BC4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC4Au,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC4Au, 5u + 1u, 3u, cpu.address("absy", 0xBDF3u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC4A LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xBDF3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BC4D;
L_80BC4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC4Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC4Du, 5u, 3u, cpu.address("abs", 0x0920u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC4D STA
    hw.write(cpu.address("abs", 0x920u), cpu.a, cpu.m8?8:16);
    goto L_80BC50;
L_80BC50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC50u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC50u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC50u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC50 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x12u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BC52;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC50u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC50u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC50 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x12u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BC52;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC50u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC50u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC50 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x12u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BC52;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC50u,0x80BC50u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BC52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC52u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC52u,cpu,0xDDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC52u, 5u + 1u, 3u, cpu.address("absx", 0x0906u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC52 CMP
    cpu.compareA(hw.readW(cpu.address("absx", 0x906u), cpu.m8?8:16));
    goto L_80BC55;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC52u,cpu,0xDDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC52u, 5u + 1u, 3u, cpu.address("absx", 0x0906u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC52 CMP
    cpu.compareA(hw.readW(cpu.address("absx", 0x906u), cpu.m8?8:16));
    goto L_80BC55;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC52u,cpu,0xDDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC52u, 5u + 1u, 3u, cpu.address("absx", 0x0906u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC52 CMP
    cpu.compareA(hw.readW(cpu.address("absx", 0x906u), cpu.m8?8:16));
    goto L_80BC55;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC52u,0x80BC52u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BC55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC55u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC55u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC55 BEQ -> $80BC5D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BC5D; }
    goto L_80BC57;
L_80BC57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC57u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC57u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC57u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC57 DEX
    cpu.decReg('X');
    goto L_80BC58;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC57u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC57u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC57 DEX
    cpu.decReg('X');
    goto L_80BC58;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC57u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC57u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC57 DEX
    cpu.decReg('X');
    goto L_80BC58;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC57u,0x80BC57u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BC58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC58u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC58u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC58u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC58 DEX
    cpu.decReg('X');
    goto L_80BC59;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC58u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC58u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC58 DEX
    cpu.decReg('X');
    goto L_80BC59;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC58u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC58u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC58 DEX
    cpu.decReg('X');
    goto L_80BC59;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC58u,0x80BC58u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BC59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC59u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC59u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC59u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC59 BPL -> $80BC50
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80BC50; }
    goto L_80BC5B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC59u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC59u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC59 BPL -> $80BC50
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80BC50; }
    goto L_80BC5B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC59u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC59u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC59 BPL -> $80BC50
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80BC50; }
    goto L_80BC5B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC59u,0x80BC59u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BC5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC5Bu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC5Bu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC5Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC5B BRA -> $80BC9E
    goto L_80BC9E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC5Bu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC5Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC5B BRA -> $80BC9E
    goto L_80BC9E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC5Bu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC5Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC5B BRA -> $80BC9E
    goto L_80BC9E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC5Bu,0x80BC5Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BC5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC5Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC5Du,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC5Du, 5u, 3u, cpu.address("abs", 0x091Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC5D STX
    hw.write(cpu.address("abs", 0x91Eu), cpu.x, cpu.x8?8:16);
    goto L_80BC60;
L_80BC60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC60u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC60u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC60 LDA
    cpu.setA(0x3u, 16);
    goto L_80BC63;
L_80BC63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC63u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC63u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC63u, 5u, 3u, cpu.address("abs", 0x0926u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC63 STA
    hw.write(cpu.address("abs", 0x926u), cpu.a, cpu.m8?8:16);
    goto L_80BC66;
L_80BC66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC66u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC66u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC66u, 5u, 3u, cpu.address("abs", 0x0904u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC66 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x904u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BC69;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC66u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC66u, 5u, 3u, cpu.address("abs", 0x0904u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC66 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x904u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BC69;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC66u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC66u, 5u, 3u, cpu.address("abs", 0x0904u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC66 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x904u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BC69;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC66u,0x80BC66u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BC69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC69u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC69u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC69u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC69 CMP
    cpu.compareA(0x7u);
    goto L_80BC6C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC69u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC69u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC69 CMP
    cpu.compareA(0x7u);
    goto L_80BC6C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC69u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC69u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC69 CMP
    cpu.compareA(0x7u);
    goto L_80BC6C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC69u,0x80BC69u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BC6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC6Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC6Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC6Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC6C BNE -> $80BC7E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BC7E; }
    goto L_80BC6E;
L_80BC6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC6Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC6Eu, 5u, 3u, cpu.address("abs", 0x091Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC6E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x91Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BC71;
L_80BC71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC71u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC71u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC71 CMP
    cpu.compareA(0x4u);
    goto L_80BC74;
L_80BC74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC74u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC74u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC74 BCS -> $80BC7E
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80BC7E; }
    goto L_80BC76;
L_80BC76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC76u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC76u, 5u, 3u, cpu.address("abs", 0x0926u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC76 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x926u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BC79;
L_80BC79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC79u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC79u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC79 CMP
    cpu.compareA(0x3u);
    goto L_80BC7C;
L_80BC7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC7Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC7Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC7C BNE -> $80BC94
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BC94; }
    goto L_80BC7E;
L_80BC7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC7Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC7Eu, 5u, 3u, cpu.address("abs", 0x0926u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC7E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x926u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BC81;
L_80BC81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC81u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC81u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC81 ASL
    cpu.aslA();
    goto L_80BC82;
L_80BC82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC82u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC82u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC82 STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_80BC84;
L_80BC84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC84u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC84u, 5u, 3u, cpu.address("abs", 0x0904u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC84 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x904u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BC87;
L_80BC87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC87u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC87u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC87 ASL
    cpu.aslA();
    goto L_80BC88;
L_80BC88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC88u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC88u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC88u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC88 ASL
    cpu.aslA();
    goto L_80BC89;
L_80BC89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC89u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC89u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC89 ASL
    cpu.aslA();
    goto L_80BC8A;
L_80BC8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC8Au,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC8Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC8A CLC
    cpu.setFlag('C', false);
    goto L_80BC8B;
L_80BC8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC8Bu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC8Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC8B ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16));
    goto L_80BC8D;
L_80BC8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC8Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC8Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC8D STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_80BC8F;
L_80BC8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC8Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC8Fu, 6u, 3u, cpu.address("abs", 0xBECBu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BC8F JSR -> $80BECB stack real
    { cpu.push16Value(hw,0xBC91u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBC92u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBECBu), 0x80BC8Fu); }
    goto L_80BC92;
L_80BC92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC92u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC92u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC92u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC92 BCC -> $80BCC0
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80BCC0; }
    goto L_80BC94;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC92u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC92u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC92 BCC -> $80BCC0
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80BCC0; }
    goto L_80BC94;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC92u,0x80BC92u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BC94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC94u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC94u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC94u, 8u, 3u, cpu.address("abs", 0x0926u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC94 DEC
    cpu.decMem(hw, cpu.address("abs", 0x926u), cpu.m8?8:16);
    goto L_80BC97;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC94u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC94u, 8u, 3u, cpu.address("abs", 0x0926u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC94 DEC
    cpu.decMem(hw, cpu.address("abs", 0x926u), cpu.m8?8:16);
    goto L_80BC97;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC94u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC94u, 8u, 3u, cpu.address("abs", 0x0926u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC94 DEC
    cpu.decMem(hw, cpu.address("abs", 0x926u), cpu.m8?8:16);
    goto L_80BC97;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC94u,0x80BC94u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BC97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC97u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC97u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC97u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC97 BPL -> $80BC66
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80BC66; }
    goto L_80BC99;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC97u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC97u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC97 BPL -> $80BC66
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80BC66; }
    goto L_80BC99;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC97u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC97u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC97 BPL -> $80BC66
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80BC66; }
    goto L_80BC99;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC97u,0x80BC97u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BC99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC99u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC99u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC99u, 5u, 3u, cpu.address("abs", 0x091Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC99 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x91Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BC9C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC99u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC99u, 5u, 3u, cpu.address("abs", 0x091Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC99 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x91Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BC9C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC99u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC99u, 5u, 3u, cpu.address("abs", 0x091Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC99 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x91Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BC9C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC99u,0x80BC99u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BC9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC9Cu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC9Cu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC9Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC9C BRA -> $80BC57
    goto L_80BC57;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC9Cu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC9Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC9C BRA -> $80BC57
    goto L_80BC57;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC9Cu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC9Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC9C BRA -> $80BC57
    goto L_80BC57;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC9Cu,0x80BC9Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BC9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC9Eu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC9Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC9Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC9E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BCA0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC9Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC9Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC9E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BCA0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC9Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC9Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC9E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BCA0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC9Eu,0x80BC9Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BCA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCA0u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA0u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCA0 BEQ -> $80BCAA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BCAA; }
    goto L_80BCA2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA0u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCA0 BEQ -> $80BCAA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BCAA; }
    goto L_80BCA2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA0u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCA0 BEQ -> $80BCAA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BCAA; }
    goto L_80BCA2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBCA0u,0x80BCA0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BCA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCA2u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA2u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCA2 CMP
    cpu.compareA(0x4u);
    goto L_80BCA5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA2u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCA2 CMP
    cpu.compareA(0x4u);
    goto L_80BCA5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA2u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCA2 CMP
    cpu.compareA(0x4u);
    goto L_80BCA5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBCA2u,0x80BCA2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BCA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA5u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCA5 BEQ -> $80BCB2
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BCB2; }
    goto L_80BCA7;
L_80BCA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA7u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA7u, 3u, 3u, cpu.address("abs", 0xBC01u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCA7 JMP -> $80BC01
    goto L_80BC01;
L_80BCAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCAAu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCAAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCAAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCAA LDA
    cpu.setA(0x2u, 16);
    goto L_80BCAD;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCAAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCAAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCAA LDA
    cpu.setA(0x2u, 16);
    goto L_80BCAD;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCAAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCAAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCAA LDA
    cpu.setA(0x2u, 16);
    goto L_80BCAD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBCAAu,0x80BCAAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BCAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCADu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCADu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCADu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCAD STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_80BCAF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCADu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCADu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCAD STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_80BCAF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCADu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCADu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCAD STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_80BCAF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBCADu,0x80BCADu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BCAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCAFu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCAFu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCAFu, 3u, 3u, cpu.address("abs", 0xBC2Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCAF JMP -> $80BC2C
    goto L_80BC2C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCAFu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCAFu, 3u, 3u, cpu.address("abs", 0xBC2Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCAF JMP -> $80BC2C
    goto L_80BC2C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCAFu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCAFu, 3u, 3u, cpu.address("abs", 0xBC2Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCAF JMP -> $80BC2C
    goto L_80BC2C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBCAFu,0x80BCAFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BCB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCB2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCB2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCB2 LDA
    cpu.setA(0x6u, 16);
    goto L_80BCB5;
L_80BCB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCB5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCB5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCB5 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_80BCB7;
L_80BCB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCB7u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCB7u, 3u, 3u, cpu.address("abs", 0xBC2Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCB7 JMP -> $80BC2C
    goto L_80BC2C;
L_80BCBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCBAu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCBAu, 8u, 3u, cpu.address("abs", 0x0958u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCBA INC
    cpu.incMem(hw, cpu.address("abs", 0x958u), cpu.m8?8:16);
    goto L_80BCBD;
L_80BCBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCBDu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCBDu, 5u, 3u, cpu.address("abs", 0x0926u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCBD STZ
    hw.write(cpu.address("abs", 0x926u), 0, cpu.m8?8:16);
    goto L_80BCC0;
L_80BCC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCC0u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC0u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC0u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80BCC0 PLB
    cpu.pop("PLB", hw);
    goto L_80BCC1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC0u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC0u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80BCC0 PLB
    cpu.pop("PLB", hw);
    goto L_80BCC1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC0u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC0u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80BCC0 PLB
    cpu.pop("PLB", hw);
    goto L_80BCC1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBCC0u,0x80BCC0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BCC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCC1u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BCC1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80BCC1u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80BCC1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BCC1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80BCC1u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80BCC1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BCC1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80BCC1u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80BCC1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBCC1u,0x80BCC1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80BBFA_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80BBFAu: goto L_80BBFA;
    case 0x80BBFBu: goto L_80BBFB;
    case 0x80BBFCu: goto L_80BBFC;
    case 0x80BBFDu: goto L_80BBFD;
    case 0x80BBFFu: goto L_80BBFF;
    case 0x80BC01u: goto L_80BC01;
    case 0x80BC04u: goto L_80BC04;
    case 0x80BC06u: goto L_80BC06;
    case 0x80BC0Au: goto L_80BC0A;
    case 0x80BC0Du: goto L_80BC0D;
    case 0x80BC0Fu: goto L_80BC0F;
    case 0x80BC12u: goto L_80BC12;
    case 0x80BC14u: goto L_80BC14;
    case 0x80BC18u: goto L_80BC18;
    case 0x80BC1Au: goto L_80BC1A;
    case 0x80BC1Eu: goto L_80BC1E;
    case 0x80BC20u: goto L_80BC20;
    case 0x80BC22u: goto L_80BC22;
    case 0x80BC24u: goto L_80BC24;
    case 0x80BC26u: goto L_80BC26;
    case 0x80BC28u: goto L_80BC28;
    case 0x80BC2Au: goto L_80BC2A;
    case 0x80BC2Cu: goto L_80BC2C;
    case 0x80BC2Eu: goto L_80BC2E;
    case 0x80BC31u: goto L_80BC31;
    case 0x80BC32u: goto L_80BC32;
    case 0x80BC34u: goto L_80BC34;
    case 0x80BC37u: goto L_80BC37;
    case 0x80BC39u: goto L_80BC39;
    case 0x80BC3Au: goto L_80BC3A;
    case 0x80BC3Bu: goto L_80BC3B;
    case 0x80BC3Cu: goto L_80BC3C;
    case 0x80BC40u: goto L_80BC40;
    case 0x80BC42u: goto L_80BC42;
    case 0x80BC45u: goto L_80BC45;
    case 0x80BC48u: goto L_80BC48;
    case 0x80BC4Au: goto L_80BC4A;
    case 0x80BC4Du: goto L_80BC4D;
    case 0x80BC50u: goto L_80BC50;
    case 0x80BC52u: goto L_80BC52;
    case 0x80BC55u: goto L_80BC55;
    case 0x80BC57u: goto L_80BC57;
    case 0x80BC58u: goto L_80BC58;
    case 0x80BC59u: goto L_80BC59;
    case 0x80BC5Bu: goto L_80BC5B;
    case 0x80BC5Du: goto L_80BC5D;
    case 0x80BC60u: goto L_80BC60;
    case 0x80BC63u: goto L_80BC63;
    case 0x80BC66u: goto L_80BC66;
    case 0x80BC69u: goto L_80BC69;
    case 0x80BC6Cu: goto L_80BC6C;
    case 0x80BC6Eu: goto L_80BC6E;
    case 0x80BC71u: goto L_80BC71;
    case 0x80BC74u: goto L_80BC74;
    case 0x80BC76u: goto L_80BC76;
    case 0x80BC79u: goto L_80BC79;
    case 0x80BC7Cu: goto L_80BC7C;
    case 0x80BC7Eu: goto L_80BC7E;
    case 0x80BC81u: goto L_80BC81;
    case 0x80BC82u: goto L_80BC82;
    case 0x80BC84u: goto L_80BC84;
    case 0x80BC87u: goto L_80BC87;
    case 0x80BC88u: goto L_80BC88;
    case 0x80BC89u: goto L_80BC89;
    case 0x80BC8Au: goto L_80BC8A;
    case 0x80BC8Bu: goto L_80BC8B;
    case 0x80BC8Du: goto L_80BC8D;
    case 0x80BC8Fu: goto L_80BC8F;
    case 0x80BC92u: goto L_80BC92;
    case 0x80BC94u: goto L_80BC94;
    case 0x80BC97u: goto L_80BC97;
    case 0x80BC99u: goto L_80BC99;
    case 0x80BC9Cu: goto L_80BC9C;
    case 0x80BC9Eu: goto L_80BC9E;
    case 0x80BCA0u: goto L_80BCA0;
    case 0x80BCA2u: goto L_80BCA2;
    case 0x80BCA5u: goto L_80BCA5;
    case 0x80BCA7u: goto L_80BCA7;
    case 0x80BCAAu: goto L_80BCAA;
    case 0x80BCADu: goto L_80BCAD;
    case 0x80BCAFu: goto L_80BCAF;
    case 0x80BCB2u: goto L_80BCB2;
    case 0x80BCB5u: goto L_80BCB5;
    case 0x80BCB7u: goto L_80BCB7;
    case 0x80BCBAu: goto L_80BCBA;
    case 0x80BCBDu: goto L_80BCBD;
    case 0x80BCC0u: goto L_80BCC0;
    case 0x80BCC1u: goto L_80BCC1;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80BBFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBFAu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBFAu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80BBFA PHB
    cpu.push("PHB", hw);
    goto L_80BBFB;
L_80BBFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBFBu,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBFBu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80BBFB PHK
    cpu.push("PHK", hw);
    goto L_80BBFC;
L_80BBFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBFCu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBFCu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80BBFC PLB
    cpu.pop("PLB", hw);
    goto L_80BBFD;
L_80BBFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBFDu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBFDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBFD STZ
    hw.write(cpu.address("dp", 0x61u), 0, cpu.m8?8:16);
    goto L_80BBFF;
L_80BBFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBFFu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBFFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBFF STZ
    hw.write(cpu.address("dp", 0x63u), 0, cpu.m8?8:16);
    goto L_80BC01;
L_80BC01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC01u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC01u, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC01 STZ
    hw.write(cpu.address("abs", 0x958u), 0, cpu.m8?8:16);
    goto L_80BC04;
L_80BC04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC04u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC04u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC04 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BC06;
L_80BC06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC06u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC06u, 6u, 4u, ((0x7E2440u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC06 LDA
    cpu.loadA(hw.readW(((0x7E2440u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BC0A;
L_80BC0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC0Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC0Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC0A CMP
    cpu.compareA(0xFFFFu);
    goto L_80BC0D;
L_80BC0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC0Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC0Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC0D BNE -> $80BC12
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BC12; }
    goto L_80BC0F;
L_80BC0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC0Fu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC0Fu, 3u, 3u, cpu.address("abs", 0xBCBAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC0F JMP -> $80BCBA
    goto L_80BCBA;
L_80BC12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC12u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC12u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC12 STA
    hw.write(cpu.address("dp", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_80BC14;
L_80BC14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC14u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC14u, 6u, 4u, ((0x7E2442u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC14 LDA
    cpu.loadA(hw.readW(((0x7E2442u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BC18;
L_80BC18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC18u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC18u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC18 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_80BC1A;
L_80BC1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC1Au,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC1Au, 6u, 4u, ((0x7E2444u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC1A LDA
    cpu.loadA(hw.readW(((0x7E2444u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BC1E;
L_80BC1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC1Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC1Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC1E STA
    hw.write(cpu.address("dp", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_80BC20;
L_80BC20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC20u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC20u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC20 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80BC22;
L_80BC22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC22u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC22u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC22 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80BC24;
L_80BC24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC24u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC24u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC24 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80BC26;
L_80BC26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC26u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC26u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC26 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80BC28;
L_80BC28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC28u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC28u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC28 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80BC2A;
L_80BC2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC2Au,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC2Au, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC2A INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80BC2C;
L_80BC2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC2Cu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC2Cu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC2Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC2C LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x10u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BC2E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC2Cu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC2Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC2C LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x10u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BC2E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC2Cu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC2Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC2C LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x10u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BC2E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC2Cu,0x80BC2Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BC2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC2Eu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC2Eu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC2Eu, 5u + 1u, 3u, cpu.address("absy", 0xBDEBu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC2E LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xBDEBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BC31;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC2Eu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC2Eu, 5u + 1u, 3u, cpu.address("absy", 0xBDEBu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC2E LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xBDEBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BC31;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC2Eu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC2Eu, 5u + 1u, 3u, cpu.address("absy", 0xBDEBu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC2E LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xBDEBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BC31;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC2Eu,0x80BC2Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BC31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC31u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC31u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC31u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC31 CLC
    cpu.setFlag('C', false);
    goto L_80BC32;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC31u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC31u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC31 CLC
    cpu.setFlag('C', false);
    goto L_80BC32;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC31u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC31u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC31 CLC
    cpu.setFlag('C', false);
    goto L_80BC32;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC31u,0x80BC31u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BC32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC32u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC32u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC32 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x14u), cpu.m8?8:16));
    goto L_80BC34;
L_80BC34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC34u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC34u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC34 CPY
    cpu.compareY(0x2u);
    goto L_80BC37;
L_80BC37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC37u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC37u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC37 BNE -> $80BC3B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BC3B; }
    goto L_80BC39;
L_80BC39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC39u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC39u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC39 INC
    cpu.inc('A');
    goto L_80BC3A;
L_80BC3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC3Au,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC3Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC3A INC
    cpu.inc('A');
    goto L_80BC3B;
L_80BC3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC3Bu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC3Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC3B TAX
    cpu.transfer("TAX");
    goto L_80BC3C;
L_80BC3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC3Cu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC3Cu, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC3C LDA
    cpu.loadA(hw.readW(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BC40;
L_80BC40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC40u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC40u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC40 BNE -> $80BC9E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BC9E; }
    goto L_80BC42;
L_80BC42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC42u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC42u, 5u, 3u, cpu.address("abs", 0x0918u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC42 STX
    hw.write(cpu.address("abs", 0x918u), cpu.x, cpu.x8?8:16);
    goto L_80BC45;
L_80BC45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC45u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC45u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC45 LDX
    cpu.setX(0x6u, 16);
    goto L_80BC48;
L_80BC48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC48u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC48u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC48 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x10u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BC4A;
L_80BC4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC4Au,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC4Au, 5u + 1u, 3u, cpu.address("absy", 0xBDF3u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC4A LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xBDF3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BC4D;
L_80BC4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC4Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC4Du, 5u, 3u, cpu.address("abs", 0x0920u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC4D STA
    hw.write(cpu.address("abs", 0x920u), cpu.a, cpu.m8?8:16);
    goto L_80BC50;
L_80BC50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC50u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC50u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC50u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC50 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x12u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BC52;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC50u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC50u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC50 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x12u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BC52;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC50u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC50u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC50 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x12u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BC52;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC50u,0x80BC50u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BC52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC52u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC52u,cpu,0xDDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC52u, 5u + 1u, 3u, cpu.address("absx", 0x0906u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC52 CMP
    cpu.compareA(hw.readW(cpu.address("absx", 0x906u), cpu.m8?8:16));
    goto L_80BC55;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC52u,cpu,0xDDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC52u, 5u + 1u, 3u, cpu.address("absx", 0x0906u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC52 CMP
    cpu.compareA(hw.readW(cpu.address("absx", 0x906u), cpu.m8?8:16));
    goto L_80BC55;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC52u,cpu,0xDDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC52u, 5u + 1u, 3u, cpu.address("absx", 0x0906u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC52 CMP
    cpu.compareA(hw.readW(cpu.address("absx", 0x906u), cpu.m8?8:16));
    goto L_80BC55;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC52u,0x80BC52u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BC55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC55u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC55u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC55 BEQ -> $80BC5D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BC5D; }
    goto L_80BC57;
L_80BC57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC57u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC57u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC57u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC57 DEX
    cpu.decReg('X');
    goto L_80BC58;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC57u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC57u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC57 DEX
    cpu.decReg('X');
    goto L_80BC58;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC57u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC57u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC57 DEX
    cpu.decReg('X');
    goto L_80BC58;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC57u,0x80BC57u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BC58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC58u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC58u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC58u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC58 DEX
    cpu.decReg('X');
    goto L_80BC59;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC58u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC58u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC58 DEX
    cpu.decReg('X');
    goto L_80BC59;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC58u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC58u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC58 DEX
    cpu.decReg('X');
    goto L_80BC59;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC58u,0x80BC58u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BC59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC59u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC59u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC59u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC59 BPL -> $80BC50
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80BC50; }
    goto L_80BC5B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC59u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC59u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC59 BPL -> $80BC50
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80BC50; }
    goto L_80BC5B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC59u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC59u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC59 BPL -> $80BC50
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80BC50; }
    goto L_80BC5B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC59u,0x80BC59u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BC5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC5Bu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC5Bu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC5Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC5B BRA -> $80BC9E
    goto L_80BC9E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC5Bu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC5Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC5B BRA -> $80BC9E
    goto L_80BC9E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC5Bu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC5Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC5B BRA -> $80BC9E
    goto L_80BC9E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC5Bu,0x80BC5Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BC5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC5Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC5Du,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC5Du, 5u, 3u, cpu.address("abs", 0x091Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC5D STX
    hw.write(cpu.address("abs", 0x91Eu), cpu.x, cpu.x8?8:16);
    goto L_80BC60;
L_80BC60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC60u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC60u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC60 LDA
    cpu.setA(0x3u, 16);
    goto L_80BC63;
L_80BC63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC63u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC63u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC63u, 5u, 3u, cpu.address("abs", 0x0926u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC63 STA
    hw.write(cpu.address("abs", 0x926u), cpu.a, cpu.m8?8:16);
    goto L_80BC66;
L_80BC66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC66u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC66u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC66u, 5u, 3u, cpu.address("abs", 0x0904u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC66 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x904u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BC69;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC66u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC66u, 5u, 3u, cpu.address("abs", 0x0904u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC66 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x904u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BC69;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC66u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC66u, 5u, 3u, cpu.address("abs", 0x0904u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC66 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x904u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BC69;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC66u,0x80BC66u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BC69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC69u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC69u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC69u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC69 CMP
    cpu.compareA(0x7u);
    goto L_80BC6C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC69u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC69u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC69 CMP
    cpu.compareA(0x7u);
    goto L_80BC6C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC69u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC69u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC69 CMP
    cpu.compareA(0x7u);
    goto L_80BC6C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC69u,0x80BC69u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BC6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC6Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC6Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC6Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC6C BNE -> $80BC7E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BC7E; }
    goto L_80BC6E;
L_80BC6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC6Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC6Eu, 5u, 3u, cpu.address("abs", 0x091Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC6E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x91Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BC71;
L_80BC71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC71u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC71u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC71 CMP
    cpu.compareA(0x4u);
    goto L_80BC74;
L_80BC74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC74u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC74u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC74 BCS -> $80BC7E
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80BC7E; }
    goto L_80BC76;
L_80BC76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC76u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC76u, 5u, 3u, cpu.address("abs", 0x0926u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC76 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x926u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BC79;
L_80BC79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC79u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC79u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC79 CMP
    cpu.compareA(0x3u);
    goto L_80BC7C;
L_80BC7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC7Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC7Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC7C BNE -> $80BC94
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BC94; }
    goto L_80BC7E;
L_80BC7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC7Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC7Eu, 5u, 3u, cpu.address("abs", 0x0926u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC7E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x926u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BC81;
L_80BC81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC81u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC81u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC81 ASL
    cpu.aslA();
    goto L_80BC82;
L_80BC82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC82u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC82u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC82 STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_80BC84;
L_80BC84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC84u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC84u, 5u, 3u, cpu.address("abs", 0x0904u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC84 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x904u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BC87;
L_80BC87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC87u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC87u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC87 ASL
    cpu.aslA();
    goto L_80BC88;
L_80BC88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC88u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC88u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC88u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC88 ASL
    cpu.aslA();
    goto L_80BC89;
L_80BC89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC89u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC89u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC89 ASL
    cpu.aslA();
    goto L_80BC8A;
L_80BC8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC8Au,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC8Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC8A CLC
    cpu.setFlag('C', false);
    goto L_80BC8B;
L_80BC8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC8Bu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC8Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC8B ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16));
    goto L_80BC8D;
L_80BC8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC8Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC8Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC8D STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_80BC8F;
L_80BC8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC8Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC8Fu, 6u, 3u, cpu.address("abs", 0xBECBu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BC8F JSR -> $80BECB stack real
    { cpu.push16Value(hw,0xBC91u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBC92u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBECBu), 0x80BC8Fu); }
    goto L_80BC92;
L_80BC92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC92u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC92u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC92u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC92 BCC -> $80BCC0
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80BCC0; }
    goto L_80BC94;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC92u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC92u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC92 BCC -> $80BCC0
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80BCC0; }
    goto L_80BC94;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC92u,0x80BC92u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BC94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC94u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC94u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC94u, 8u, 3u, cpu.address("abs", 0x0926u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC94 DEC
    cpu.decMem(hw, cpu.address("abs", 0x926u), cpu.m8?8:16);
    goto L_80BC97;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC94u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC94u, 8u, 3u, cpu.address("abs", 0x0926u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC94 DEC
    cpu.decMem(hw, cpu.address("abs", 0x926u), cpu.m8?8:16);
    goto L_80BC97;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC94u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC94u, 8u, 3u, cpu.address("abs", 0x0926u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC94 DEC
    cpu.decMem(hw, cpu.address("abs", 0x926u), cpu.m8?8:16);
    goto L_80BC97;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC94u,0x80BC94u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BC97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC97u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC97u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC97u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC97 BPL -> $80BC66
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80BC66; }
    goto L_80BC99;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC97u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC97u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC97 BPL -> $80BC66
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80BC66; }
    goto L_80BC99;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC97u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC97u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC97 BPL -> $80BC66
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80BC66; }
    goto L_80BC99;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC97u,0x80BC97u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BC99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC99u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC99u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC99u, 5u, 3u, cpu.address("abs", 0x091Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC99 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x91Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BC9C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC99u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC99u, 5u, 3u, cpu.address("abs", 0x091Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC99 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x91Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BC9C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC99u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC99u, 5u, 3u, cpu.address("abs", 0x091Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC99 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x91Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BC9C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC99u,0x80BC99u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BC9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC9Cu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC9Cu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC9Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC9C BRA -> $80BC57
    goto L_80BC57;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC9Cu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC9Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC9C BRA -> $80BC57
    goto L_80BC57;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC9Cu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC9Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC9C BRA -> $80BC57
    goto L_80BC57;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC9Cu,0x80BC9Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BC9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC9Eu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC9Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC9Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC9E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BCA0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC9Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC9Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC9E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BCA0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC9Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC9Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC9E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BCA0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC9Eu,0x80BC9Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BCA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCA0u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA0u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCA0 BEQ -> $80BCAA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BCAA; }
    goto L_80BCA2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA0u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCA0 BEQ -> $80BCAA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BCAA; }
    goto L_80BCA2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA0u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCA0 BEQ -> $80BCAA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BCAA; }
    goto L_80BCA2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBCA0u,0x80BCA0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BCA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCA2u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA2u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCA2 CMP
    cpu.compareA(0x4u);
    goto L_80BCA5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA2u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCA2 CMP
    cpu.compareA(0x4u);
    goto L_80BCA5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA2u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCA2 CMP
    cpu.compareA(0x4u);
    goto L_80BCA5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBCA2u,0x80BCA2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BCA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA5u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCA5 BEQ -> $80BCB2
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BCB2; }
    goto L_80BCA7;
L_80BCA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA7u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA7u, 3u, 3u, cpu.address("abs", 0xBC01u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCA7 JMP -> $80BC01
    goto L_80BC01;
L_80BCAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCAAu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCAAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCAAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCAA LDA
    cpu.setA(0x2u, 16);
    goto L_80BCAD;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCAAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCAAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCAA LDA
    cpu.setA(0x2u, 16);
    goto L_80BCAD;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCAAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCAAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCAA LDA
    cpu.setA(0x2u, 16);
    goto L_80BCAD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBCAAu,0x80BCAAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BCAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCADu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCADu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCADu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCAD STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_80BCAF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCADu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCADu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCAD STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_80BCAF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCADu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCADu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCAD STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_80BCAF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBCADu,0x80BCADu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BCAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCAFu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCAFu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCAFu, 3u, 3u, cpu.address("abs", 0xBC2Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCAF JMP -> $80BC2C
    goto L_80BC2C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCAFu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCAFu, 3u, 3u, cpu.address("abs", 0xBC2Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCAF JMP -> $80BC2C
    goto L_80BC2C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCAFu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCAFu, 3u, 3u, cpu.address("abs", 0xBC2Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCAF JMP -> $80BC2C
    goto L_80BC2C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBCAFu,0x80BCAFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BCB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCB2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCB2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCB2 LDA
    cpu.setA(0x6u, 16);
    goto L_80BCB5;
L_80BCB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCB5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCB5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCB5 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_80BCB7;
L_80BCB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCB7u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCB7u, 3u, 3u, cpu.address("abs", 0xBC2Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCB7 JMP -> $80BC2C
    goto L_80BC2C;
L_80BCBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCBAu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCBAu, 8u, 3u, cpu.address("abs", 0x0958u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCBA INC
    cpu.incMem(hw, cpu.address("abs", 0x958u), cpu.m8?8:16);
    goto L_80BCBD;
L_80BCBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCBDu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCBDu, 5u, 3u, cpu.address("abs", 0x0926u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCBD STZ
    hw.write(cpu.address("abs", 0x926u), 0, cpu.m8?8:16);
    goto L_80BCC0;
L_80BCC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCC0u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC0u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC0u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80BCC0 PLB
    cpu.pop("PLB", hw);
    goto L_80BCC1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC0u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC0u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80BCC0 PLB
    cpu.pop("PLB", hw);
    goto L_80BCC1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC0u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC0u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80BCC0 PLB
    cpu.pop("PLB", hw);
    goto L_80BCC1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBCC0u,0x80BCC0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BCC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCC1u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BCC1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80BCC1u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80BCC1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BCC1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80BCC1u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80BCC1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BCC1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80BCC1u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80BCC1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBCC1u,0x80BCC1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_829241_E0M1X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x829241u: goto L_829241;
    case 0x829243u: goto L_829243;
    case 0x829247u: goto L_829247;
    case 0x82924Au: goto L_82924A;
    case 0x82924Du: goto L_82924D;
    case 0x829250u: goto L_829250;
    case 0x829254u: goto L_829254;
    case 0x829257u: goto L_829257;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_829241:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9241u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9241u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9241u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829241 REP
    cpu.rep(0x20u);
    goto L_829243;
L_829243:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9243u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9243u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9243u, 8u, 4u, 0x809D16u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829243 JSL -> $809D16 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9246u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9247u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809D16u, 0x829243u); }
    goto L_829247;
L_829247:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9247u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9247u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9247u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829247 LDA
    cpu.setA(0x800u, 16);
    goto L_82924A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9247u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9247u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829247 LDA
    cpu.setA(0x800u, 16);
    goto L_82924A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9247u,0x829247u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82924A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x924Au))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x924Au,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x924Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82924A LDX
    cpu.setX(0x2800u, 16);
    goto L_82924D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x924Au,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x924Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82924A LDX
    cpu.setX(0x2800u, 16);
    goto L_82924D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x924Au,0x82924Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82924D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x924Du))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x924Du,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x924Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82924D LDY
    cpu.setY(0x5000u, 16);
    goto L_829250;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x924Du,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x924Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82924D LDY
    cpu.setY(0x5000u, 16);
    goto L_829250;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x924Du,0x82924Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829250:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9250u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9250u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9250u, 8u, 4u, 0x808EBFu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829250 JSL -> $808EBF stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9253u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9254u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808EBFu, 0x829250u); }
    goto L_829254;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9250u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9250u, 8u, 4u, 0x808EBFu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829250 JSL -> $808EBF stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9253u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9254u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808EBFu, 0x829250u); }
    goto L_829254;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9250u,0x829250u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829254:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9254u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9254u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9254u, 6u, 3u, cpu.address("abs", 0xC326u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829254 JSR -> $82C326 stack real
    { cpu.push16Value(hw,0x9256u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9257u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC326u), 0x829254u); }
    goto L_829257;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9254u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9254u, 6u, 3u, cpu.address("abs", 0xC326u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829254 JSR -> $82C326 stack real
    { cpu.push16Value(hw,0x9256u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9257u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC326u), 0x829254u); }
    goto L_829257;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9254u,0x829254u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829257:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9257u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9257u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9257u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829257 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x829257u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829257u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9257u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9257u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829257 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x829257u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829257u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9257u,0x829257u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_829241_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x829241u: goto L_829241;
    case 0x829243u: goto L_829243;
    case 0x829247u: goto L_829247;
    case 0x82924Au: goto L_82924A;
    case 0x82924Du: goto L_82924D;
    case 0x829250u: goto L_829250;
    case 0x829254u: goto L_829254;
    case 0x829257u: goto L_829257;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_829241:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9241u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9241u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9241u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829241 REP
    cpu.rep(0x20u);
    goto L_829243;
L_829243:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9243u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9243u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9243u, 8u, 4u, 0x809D16u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829243 JSL -> $809D16 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9246u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9247u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809D16u, 0x829243u); }
    goto L_829247;
L_829247:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9247u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9247u,0x829247u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9247u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9247u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829247 LDA
    cpu.setA(0x800u, 16);
    goto L_82924A;
L_82924A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x924Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x924Au,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x924Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82924A LDX
    cpu.setX(0x2800u, 16);
    goto L_82924D;
L_82924D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x924Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x924Du,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x924Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82924D LDY
    cpu.setY(0x5000u, 16);
    goto L_829250;
L_829250:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9250u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9250u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9250u, 8u, 4u, 0x808EBFu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829250 JSL -> $808EBF stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9253u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9254u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808EBFu, 0x829250u); }
    goto L_829254;
L_829254:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9254u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9254u,0x829254u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9254u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9254u, 6u, 3u, cpu.address("abs", 0xC326u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829254 JSR -> $82C326 stack real
    { cpu.push16Value(hw,0x9256u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9257u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC326u), 0x829254u); }
    goto L_829257;
L_829257:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9257u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9257u,0x829257u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9257u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9257u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829257 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x829257u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829257u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_829F0F_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x829F0Fu: goto L_829F0F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_829F0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829F0F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x829F0Fu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829F0Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_829F0F_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x829F0Fu: goto L_829F0F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_829F0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829F0F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x829F0Fu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829F0Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82A7A1_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82A7A1u: goto L_82A7A1;
    case 0x82A7A3u: goto L_82A7A3;
    case 0x82A7A6u: goto L_82A7A6;
    case 0x82A7A7u: goto L_82A7A7;
    case 0x82A7A8u: goto L_82A7A8;
    case 0x82A7A9u: goto L_82A7A9;
    case 0x82A7ACu: goto L_82A7AC;
    case 0x82A7AEu: goto L_82A7AE;
    case 0x82A7B0u: goto L_82A7B0;
    case 0x82A7B4u: goto L_82A7B4;
    case 0x82A7B7u: goto L_82A7B7;
    case 0x82A7B8u: goto L_82A7B8;
    case 0x82A7B9u: goto L_82A7B9;
    case 0x82A7BBu: goto L_82A7BB;
    case 0x82A7BDu: goto L_82A7BD;
    case 0x82A7BFu: goto L_82A7BF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82A7A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7A1u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7A1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7A1 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A7A3;
L_82A7A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7A3u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7A3u, 5u + 1u, 3u, cpu.address("absy", 0x0206u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7A3 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x206u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A7A6;
L_82A7A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7A6u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7A6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7A6 ASL
    cpu.aslA();
    goto L_82A7A7;
L_82A7A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7A7u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7A7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7A7 ASL
    cpu.aslA();
    goto L_82A7A8;
L_82A7A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7A8u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7A8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7A8 TAX
    cpu.transfer("TAX");
    goto L_82A7A9;
L_82A7A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7A9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7A9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7A9 LDA
    cpu.setA(0x3u, 16);
    goto L_82A7AC;
L_82A7AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7ACu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7ACu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7AC STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82A7AE;
L_82A7AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7AEu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7AEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7AE SEP
    cpu.sep(0x20u);
    goto L_82A7B0;
L_82A7B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7B0u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7B0u, 5u, 4u, ((0x9E92E5u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7B0 LDA
    cpu.loadA(hw.readW(((0x9E92E5u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A7B4;
L_82A7B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7B4u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7B4u, 5u, 3u, cpu.address("absy", 0x0296u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7B4 STA
    hw.write(cpu.address("absy", 0x296u), cpu.a, cpu.m8?8:16);
    goto L_82A7B7;
L_82A7B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7B7u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7B7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7B7 INY
    cpu.inc('Y');
    goto L_82A7B8;
L_82A7B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7B8u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7B8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7B8 INX
    cpu.inc('X');
    goto L_82A7B9;
L_82A7B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7B9u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7B9u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7B9 DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_82A7BB;
L_82A7BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7BBu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7BBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7BB BPL -> $82A7B0
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82A7B0; }
    goto L_82A7BD;
L_82A7BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7BDu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7BDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7BD REP
    cpu.rep(0x20u);
    goto L_82A7BF;
L_82A7BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7BFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7BFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A7BF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82A7BFu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82A7BFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82AFEC_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82AFECu: goto L_82AFEC;
    case 0x82AFEEu: goto L_82AFEE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82AFEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFECu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFECu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFEC REP
    cpu.rep(0x20u);
    goto L_82AFEE;
L_82AFEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFEEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFEEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AFEE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82AFEEu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82AFEEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82AFEC_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82AFECu: goto L_82AFEC;
    case 0x82AFEEu: goto L_82AFEE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82AFEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFECu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFECu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFEC REP
    cpu.rep(0x20u);
    goto L_82AFEE;
L_82AFEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFEEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFEEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AFEE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82AFEEu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82AFEEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82B0ED_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B0EDu: goto L_82B0ED;
    case 0x82B0F0u: goto L_82B0F0;
    case 0x82B0F3u: goto L_82B0F3;
    case 0x82B0F4u: goto L_82B0F4;
    case 0x82B0F5u: goto L_82B0F5;
    case 0x82B0F8u: goto L_82B0F8;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B0ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0EDu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0EDu, 5u, 3u, cpu.address("abs", 0x0185u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0ED LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x185u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B0F0;
L_82B0F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0F0u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0F0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0F0 AND
    cpu.logicAnd(0xFFu);
    goto L_82B0F3;
L_82B0F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0F3u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0F3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0F3 ASL
    cpu.aslA();
    goto L_82B0F4;
L_82B0F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0F4u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0F4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0F4 TAX
    cpu.transfer("TAX");
    goto L_82B0F5;
L_82B0F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0F5u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0F5u, 5u, 3u, cpu.address("abs", 0xB0FAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B0F5 PEA
    cpu.push16Value(hw, 0xB0FAu);
    goto L_82B0F8;
L_82B0F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0F8u,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0F8u, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0xB104u + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $82B0F8 JMP (B104,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0xB104u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x82B0F8u); return; }
}

void sub_82B6BE_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B6BEu: goto L_82B6BE;
    case 0x82B6C0u: goto L_82B6C0;
    case 0x82B6C3u: goto L_82B6C3;
    case 0x82B6C5u: goto L_82B6C5;
    case 0x82B6C8u: goto L_82B6C8;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B6BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6BE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B6C0;
L_82B6C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6C0u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6C0u, 5u, 3u, cpu.address("absx", 0x0276u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6C0 STA
    hw.write(cpu.address("absx", 0x276u), cpu.a, cpu.m8?8:16);
    goto L_82B6C3;
L_82B6C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6C3u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6C3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6C3 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B6C5;
L_82B6C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6C5u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6C5u, 5u, 3u, cpu.address("absx", 0x027Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6C5 STA
    hw.write(cpu.address("absx", 0x27Eu), cpu.a, cpu.m8?8:16);
    goto L_82B6C8;
L_82B6C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6C8u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6C8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B6C8 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B6C8u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B6C8u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82B945_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B945u: goto L_82B945;
    case 0x82B948u: goto L_82B948;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B945:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB945u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB945u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB945u, 6u, 3u, cpu.address("abs", 0xB98Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B945 JSR -> $82B98E stack real
    { cpu.push16Value(hw,0xB947u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB948u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB98Eu), 0x82B945u); }
    goto L_82B948;
L_82B948:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB948u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB948u,0x82B948u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB948u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB948u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B948 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B948u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B948u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82C1A8_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82C1A8u: goto L_82C1A8;
    case 0x82C1ABu: goto L_82C1AB;
    case 0x82C1AEu: goto L_82C1AE;
    case 0x82C1B1u: goto L_82C1B1;
    case 0x82C1B3u: goto L_82C1B3;
    case 0x82C1B7u: goto L_82C1B7;
    case 0x82C1BAu: goto L_82C1BA;
    case 0x82C1BCu: goto L_82C1BC;
    case 0x82C1BFu: goto L_82C1BF;
    case 0x82C1C2u: goto L_82C1C2;
    case 0x82C1C4u: goto L_82C1C4;
    case 0x82C1C7u: goto L_82C1C7;
    case 0x82C1CAu: goto L_82C1CA;
    case 0x82C1CDu: goto L_82C1CD;
    case 0x82C1CFu: goto L_82C1CF;
    case 0x82C1D2u: goto L_82C1D2;
    case 0x82C1D5u: goto L_82C1D5;
    case 0x82C1D8u: goto L_82C1D8;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82C1A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1A8u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1A8u, 8u, 3u, cpu.address("abs", 0x014Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C1A8 INC
    cpu.incMem(hw, cpu.address("abs", 0x14Au), cpu.m8?8:16);
    goto L_82C1AB;
L_82C1AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1ABu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1ABu, 8u, 3u, cpu.address("abs", 0x01AFu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C1AB INC
    cpu.incMem(hw, cpu.address("abs", 0x1AFu), cpu.m8?8:16);
    goto L_82C1AE;
L_82C1AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1AEu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1AEu, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C1AE LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C1B1;
L_82C1B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1B1u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1B1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C1B1 BEQ -> $82C1C4
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C1C4; }
    goto L_82C1B3;
L_82C1B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1B3u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1B3u, 8u, 4u, 0x84B9B8u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82C1B3 JSL -> $84B9B8 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC1B6u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC1B7u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84B9B8u, 0x82C1B3u); }
    goto L_82C1B7;
L_82C1B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1B7u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1B7u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1B7u, 5u, 3u, cpu.address("abs", 0x06C6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C1B7 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x6C6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C1BA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1B7u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1B7u, 5u, 3u, cpu.address("abs", 0x06C6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C1B7 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x6C6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C1BA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1B7u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1B7u, 5u, 3u, cpu.address("abs", 0x06C6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C1B7 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x6C6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C1BA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC1B7u,0x82C1B7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82C1BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1BAu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1BAu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1BAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C1BA BMI -> $82C1C4
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82C1C4; }
    goto L_82C1BC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1BAu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1BAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C1BA BMI -> $82C1C4
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82C1C4; }
    goto L_82C1BC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1BAu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1BAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C1BA BMI -> $82C1C4
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82C1C4; }
    goto L_82C1BC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC1BAu,0x82C1BAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82C1BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1BCu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1BCu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1BCu, 6u, 3u, cpu.address("abs", 0xC3A5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C1BC JSR -> $82C3A5 stack real
    { cpu.push16Value(hw,0xC1BEu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC1BFu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC3A5u), 0x82C1BCu); }
    goto L_82C1BF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1BCu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1BCu, 6u, 3u, cpu.address("abs", 0xC3A5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C1BC JSR -> $82C3A5 stack real
    { cpu.push16Value(hw,0xC1BEu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC1BFu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC3A5u), 0x82C1BCu); }
    goto L_82C1BF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1BCu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1BCu, 6u, 3u, cpu.address("abs", 0xC3A5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C1BC JSR -> $82C3A5 stack real
    { cpu.push16Value(hw,0xC1BEu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC1BFu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC3A5u), 0x82C1BCu); }
    goto L_82C1BF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC1BCu,0x82C1BCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82C1BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1BFu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1BFu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1BFu, 6u, 3u, cpu.address("abs", 0xC423u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C1BF JSR -> $82C423 stack real
    { cpu.push16Value(hw,0xC1C1u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC1C2u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC423u), 0x82C1BFu); }
    goto L_82C1C2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1BFu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1BFu, 6u, 3u, cpu.address("abs", 0xC423u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C1BF JSR -> $82C423 stack real
    { cpu.push16Value(hw,0xC1C1u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC1C2u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC423u), 0x82C1BFu); }
    goto L_82C1C2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1BFu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1BFu, 6u, 3u, cpu.address("abs", 0xC423u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C1BF JSR -> $82C423 stack real
    { cpu.push16Value(hw,0xC1C1u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC1C2u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC423u), 0x82C1BFu); }
    goto L_82C1C2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC1BFu,0x82C1BFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82C1C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1C2u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC1C2u,0x82C1C2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1C2u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1C2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C1C2 BRA -> $82C1D5
    goto L_82C1D5;
L_82C1C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1C4u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1C4u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1C4u, 6u, 3u, cpu.address("abs", 0xC461u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C1C4 JSR -> $82C461 stack real
    { cpu.push16Value(hw,0xC1C6u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC1C7u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC461u), 0x82C1C4u); }
    goto L_82C1C7;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1C4u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1C4u, 6u, 3u, cpu.address("abs", 0xC461u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C1C4 JSR -> $82C461 stack real
    { cpu.push16Value(hw,0xC1C6u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC1C7u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC461u), 0x82C1C4u); }
    goto L_82C1C7;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1C4u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1C4u, 6u, 3u, cpu.address("abs", 0xC461u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C1C4 JSR -> $82C461 stack real
    { cpu.push16Value(hw,0xC1C6u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC1C7u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC461u), 0x82C1C4u); }
    goto L_82C1C7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC1C4u,0x82C1C4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82C1C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1C7u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC1C7u,0x82C1C7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1C7u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1C7u, 5u, 3u, cpu.address("abs", 0x02CEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C1C7 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2CEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C1CA;
L_82C1CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1CAu,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1CAu, 5u, 3u, cpu.address("abs", 0x01ADu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C1CA CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x1ADu), cpu.m8?8:16));
    goto L_82C1CD;
L_82C1CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1CDu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1CDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C1CD BEQ -> $82C1D5
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C1D5; }
    goto L_82C1CF;
L_82C1CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1CFu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1CFu, 6u, 3u, cpu.address("abs", 0xC3A5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C1CF JSR -> $82C3A5 stack real
    { cpu.push16Value(hw,0xC1D1u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC1D2u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC3A5u), 0x82C1CFu); }
    goto L_82C1D2;
L_82C1D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1D2u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC1D2u,0x82C1D2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1D2u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1D2u, 6u, 3u, cpu.address("abs", 0xC485u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C1D2 JSR -> $82C485 stack real
    { cpu.push16Value(hw,0xC1D4u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC1D5u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC485u), 0x82C1D2u); }
    goto L_82C1D5;
L_82C1D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1D5u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC1D5u,0x82C1D5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1D5u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1D5u, 8u, 3u, cpu.address("abs", 0x0176u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C1D5 INC
    cpu.incMem(hw, cpu.address("abs", 0x176u), cpu.m8?8:16);
    goto L_82C1D8;
L_82C1D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1D8u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1D8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C1D8 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C1D8u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C1D8u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82C485_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82C485u: goto L_82C485;
    case 0x82C488u: goto L_82C488;
    case 0x82C489u: goto L_82C489;
    case 0x82C48Bu: goto L_82C48B;
    case 0x82C48Fu: goto L_82C48F;
    case 0x82C491u: goto L_82C491;
    case 0x82C494u: goto L_82C494;
    case 0x82C495u: goto L_82C495;
    case 0x82C496u: goto L_82C496;
    case 0x82C49Au: goto L_82C49A;
    case 0x82C49Cu: goto L_82C49C;
    case 0x82C49Eu: goto L_82C49E;
    case 0x82C4A1u: goto L_82C4A1;
    case 0x82C4A2u: goto L_82C4A2;
    case 0x82C4A3u: goto L_82C4A3;
    case 0x82C4A7u: goto L_82C4A7;
    case 0x82C4A9u: goto L_82C4A9;
    case 0x82C4ACu: goto L_82C4AC;
    case 0x82C4AFu: goto L_82C4AF;
    case 0x82C4B2u: goto L_82C4B2;
    case 0x82C4B6u: goto L_82C4B6;
    case 0x82C4B7u: goto L_82C4B7;
    case 0x82C4BAu: goto L_82C4BA;
    case 0x82C4BEu: goto L_82C4BE;
    case 0x82C4BFu: goto L_82C4BF;
    case 0x82C4C0u: goto L_82C4C0;
    case 0x82C4C1u: goto L_82C4C1;
    case 0x82C4C2u: goto L_82C4C2;
    case 0x82C4C4u: goto L_82C4C4;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82C485:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC485u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC485u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC485u, 5u, 3u, cpu.address("abs", 0x01ADu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C485 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1ADu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C488;
L_82C488:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC488u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC488u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC488u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C488 INC
    cpu.inc('A');
    goto L_82C489;
L_82C489:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC489u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC489u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC489u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C489 STA
    hw.write(cpu.address("dp", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_82C48B;
L_82C48B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC48Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC48Bu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC48Bu, 8u, 4u, 0x809315u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82C48B JSL -> $809315 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC48Eu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC48Fu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809315u, 0x82C48Bu); }
    goto L_82C48F;
L_82C48F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC48Fu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC48Fu,0x82C48Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC48Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC48Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C48F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C491;
L_82C491:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC491u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC491u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC491u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C491 AND
    cpu.logicAnd(0xFFu);
    goto L_82C494;
L_82C494:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC494u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC494u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC494u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C494 ASL
    cpu.aslA();
    goto L_82C495;
L_82C495:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC495u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC495u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC495u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C495 TAX
    cpu.transfer("TAX");
    goto L_82C496;
L_82C496:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC496u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC496u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC496u, 6u, 4u, ((0x82C4C5u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C496 LDA
    cpu.loadA(hw.readW(((0x82C4C5u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C49A;
L_82C49A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC49Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC49Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC49Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C49A STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82C49C;
L_82C49C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC49Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC49Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC49Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C49C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C49E;
L_82C49E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC49Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC49Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC49Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C49E AND
    cpu.logicAnd(0xFFu);
    goto L_82C4A1;
L_82C4A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4A1u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4A1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C4A1 ASL
    cpu.aslA();
    goto L_82C4A2;
L_82C4A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4A2u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4A2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C4A2 TAX
    cpu.transfer("TAX");
    goto L_82C4A3;
L_82C4A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4A3u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4A3u, 6u, 4u, ((0x82C4C5u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C4A3 LDA
    cpu.loadA(hw.readW(((0x82C4C5u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C4A7;
L_82C4A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4A7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4A7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C4A7 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_82C4A9;
L_82C4A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4A9u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4A9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C4A9 LDX
    cpu.setX(0x55Eu, 16);
    goto L_82C4AC;
L_82C4AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4ACu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4ACu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C4AC LDY
    cpu.setY(0x2u, 16);
    goto L_82C4AF;
L_82C4AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4AFu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4AFu, 5u + 1u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C4AF LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C4B2;
L_82C4B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B2u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B2u, 6u, 4u, ((0x7E2800u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C4B2 STA
    hw.write(((0x7E2800u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_82C4B6;
L_82C4B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B6u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C4B6 CLC
    cpu.setFlag('C', false);
    goto L_82C4B7;
L_82C4B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B7u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C4B7 ADC
    cpu.adc(0x10u);
    goto L_82C4BA;
L_82C4BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4BAu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4BAu, 6u, 4u, ((0x7E2840u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C4BA STA
    hw.write(((0x7E2840u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_82C4BE;
L_82C4BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4BEu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4BEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C4BE INX
    cpu.inc('X');
    goto L_82C4BF;
L_82C4BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4BFu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4BFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C4BF INX
    cpu.inc('X');
    goto L_82C4C0;
L_82C4C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4C0u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4C0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C4C0 DEY
    cpu.decReg('Y');
    goto L_82C4C1;
L_82C4C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4C1u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4C1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C4C1 DEY
    cpu.decReg('Y');
    goto L_82C4C2;
L_82C4C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4C2u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4C2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C4C2 BPL -> $82C4AF
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82C4AF; }
    goto L_82C4C4;
L_82C4C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4C4u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4C4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C4C4 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C4C4u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C4C4u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82CA00_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82CA00u: goto L_82CA00;
    case 0x82CA02u: goto L_82CA02;
    case 0x82CA05u: goto L_82CA05;
    case 0x82CA08u: goto L_82CA08;
    case 0x82CA0Au: goto L_82CA0A;
    case 0x82CA0Du: goto L_82CA0D;
    case 0x82CA0Fu: goto L_82CA0F;
    case 0x82CA12u: goto L_82CA12;
    case 0x82CA14u: goto L_82CA14;
    case 0x82CA17u: goto L_82CA17;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82CA00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA00u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA00u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CA00 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x61u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82CA02;
L_82CA02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA02u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA02u, 9u, 3u, cpu.address("absx", 0x0414u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CA02 INC
    cpu.incMem(hw, cpu.address("absx", 0x414u), cpu.m8?8:16);
    goto L_82CA05;
L_82CA05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA05u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA05u, 5u + 1u, 3u, cpu.address("absx", 0x0410u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CA05 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x410u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CA08;
L_82CA08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA08u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA08u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CA08 BNE -> $82CA0F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CA0F; }
    goto L_82CA0A;
L_82CA0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA0Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA0Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CA0A LDA
    cpu.setA(0xCA52u, 16);
    goto L_82CA0D;
L_82CA0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA0Du,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA0Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CA0D BRA -> $82CA12
    goto L_82CA12;
L_82CA0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA0Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA0Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CA0F LDA
    cpu.setA(0xCA4Au, 16);
    goto L_82CA12;
L_82CA12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA12u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA12u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CA12 STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_82CA14;
L_82CA14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA14u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA14u, 6u, 3u, cpu.address("abs", 0xCA1Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82CA14 JSR -> $82CA1E stack real
    { cpu.push16Value(hw,0xCA16u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCA17u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCA1Eu), 0x82CA14u); }
    goto L_82CA17;
L_82CA17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA17u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCA17u,0x82CA17u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA17u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA17u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82CA17 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82CA17u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82CA17u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82CA1E_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82CA1Eu: goto L_82CA1E;
    case 0x82CA21u: goto L_82CA21;
    case 0x82CA23u: goto L_82CA23;
    case 0x82CA25u: goto L_82CA25;
    case 0x82CA29u: goto L_82CA29;
    case 0x82CA2Au: goto L_82CA2A;
    case 0x82CA2Bu: goto L_82CA2B;
    case 0x82CA2Du: goto L_82CA2D;
    case 0x82CA31u: goto L_82CA31;
    case 0x82CA32u: goto L_82CA32;
    case 0x82CA33u: goto L_82CA33;
    case 0x82CA35u: goto L_82CA35;
    case 0x82CA39u: goto L_82CA39;
    case 0x82CA3Au: goto L_82CA3A;
    case 0x82CA3Bu: goto L_82CA3B;
    case 0x82CA3Du: goto L_82CA3D;
    case 0x82CA41u: goto L_82CA41;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82CA1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA1Eu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA1Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CA1E LDY
    cpu.setY(0x0u, 16);
    goto L_82CA21;
L_82CA21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA21u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA21u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CA21 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x2u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82CA23;
L_82CA23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA23u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA23u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x04u) & 0xFFFFu), 2u, 0u);
    // $82CA23 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CA25;
L_82CA25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA25u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA25u, 6u, 4u, ((0x7E6008u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CA25 STA
    hw.write(((0x7E6008u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_82CA29;
L_82CA29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA29u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA29u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CA29 INY
    cpu.inc('Y');
    goto L_82CA2A;
L_82CA2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA2Au,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA2Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CA2A INY
    cpu.inc('Y');
    goto L_82CA2B;
L_82CA2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA2Bu,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA2Bu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x04u) & 0xFFFFu), 2u, 0u);
    // $82CA2B LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CA2D;
L_82CA2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA2Du,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA2Du, 6u, 4u, ((0x7E600Au + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CA2D STA
    hw.write(((0x7E600Au + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_82CA31;
L_82CA31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA31u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA31u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CA31 INY
    cpu.inc('Y');
    goto L_82CA32;
L_82CA32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA32u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA32u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CA32 INY
    cpu.inc('Y');
    goto L_82CA33;
L_82CA33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA33u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA33u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x04u) & 0xFFFFu), 2u, 0u);
    // $82CA33 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CA35;
L_82CA35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA35u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA35u, 6u, 4u, ((0x7E6048u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CA35 STA
    hw.write(((0x7E6048u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_82CA39;
L_82CA39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA39u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA39u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CA39 INY
    cpu.inc('Y');
    goto L_82CA3A;
L_82CA3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA3Au,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA3Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CA3A INY
    cpu.inc('Y');
    goto L_82CA3B;
L_82CA3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA3Bu,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA3Bu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x04u) & 0xFFFFu), 2u, 0u);
    // $82CA3B LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CA3D;
L_82CA3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA3Du,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA3Du, 6u, 4u, ((0x7E604Au + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CA3D STA
    hw.write(((0x7E604Au + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_82CA41;
L_82CA41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA41u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA41u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82CA41 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82CA41u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82CA41u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82CA1E_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82CA1Eu: goto L_82CA1E;
    case 0x82CA21u: goto L_82CA21;
    case 0x82CA23u: goto L_82CA23;
    case 0x82CA25u: goto L_82CA25;
    case 0x82CA29u: goto L_82CA29;
    case 0x82CA2Au: goto L_82CA2A;
    case 0x82CA2Bu: goto L_82CA2B;
    case 0x82CA2Du: goto L_82CA2D;
    case 0x82CA31u: goto L_82CA31;
    case 0x82CA32u: goto L_82CA32;
    case 0x82CA33u: goto L_82CA33;
    case 0x82CA35u: goto L_82CA35;
    case 0x82CA39u: goto L_82CA39;
    case 0x82CA3Au: goto L_82CA3A;
    case 0x82CA3Bu: goto L_82CA3B;
    case 0x82CA3Du: goto L_82CA3D;
    case 0x82CA41u: goto L_82CA41;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82CA1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA1Eu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA1Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CA1E LDY
    cpu.setY(0x0u, 16);
    goto L_82CA21;
L_82CA21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA21u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA21u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CA21 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x2u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82CA23;
L_82CA23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA23u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA23u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x04u) & 0xFFFFu), 2u, 0u);
    // $82CA23 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CA25;
L_82CA25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA25u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA25u, 6u, 4u, ((0x7E6008u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CA25 STA
    hw.write(((0x7E6008u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_82CA29;
L_82CA29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA29u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA29u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CA29 INY
    cpu.inc('Y');
    goto L_82CA2A;
L_82CA2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA2Au,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA2Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CA2A INY
    cpu.inc('Y');
    goto L_82CA2B;
L_82CA2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA2Bu,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA2Bu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x04u) & 0xFFFFu), 2u, 0u);
    // $82CA2B LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CA2D;
L_82CA2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA2Du,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA2Du, 6u, 4u, ((0x7E600Au + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CA2D STA
    hw.write(((0x7E600Au + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_82CA31;
L_82CA31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA31u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA31u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CA31 INY
    cpu.inc('Y');
    goto L_82CA32;
L_82CA32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA32u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA32u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CA32 INY
    cpu.inc('Y');
    goto L_82CA33;
L_82CA33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA33u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA33u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x04u) & 0xFFFFu), 2u, 0u);
    // $82CA33 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CA35;
L_82CA35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA35u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA35u, 6u, 4u, ((0x7E6048u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CA35 STA
    hw.write(((0x7E6048u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_82CA39;
L_82CA39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA39u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA39u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CA39 INY
    cpu.inc('Y');
    goto L_82CA3A;
L_82CA3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA3Au,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA3Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CA3A INY
    cpu.inc('Y');
    goto L_82CA3B;
L_82CA3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA3Bu,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA3Bu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x04u) & 0xFFFFu), 2u, 0u);
    // $82CA3B LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CA3D;
L_82CA3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA3Du,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA3Du, 6u, 4u, ((0x7E604Au + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CA3D STA
    hw.write(((0x7E604Au + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_82CA41;
L_82CA41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA41u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA41u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82CA41 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82CA41u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82CA41u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82CBF4_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82CBF4u: goto L_82CBF4;
    case 0x82CBF6u: goto L_82CBF6;
    case 0x82CBF8u: goto L_82CBF8;
    case 0x82CBFAu: goto L_82CBFA;
    case 0x82CBFDu: goto L_82CBFD;
    case 0x82CBFFu: goto L_82CBFF;
    case 0x82CC01u: goto L_82CC01;
    case 0x82CC03u: goto L_82CC03;
    case 0x82CC04u: goto L_82CC04;
    case 0x82CC06u: goto L_82CC06;
    case 0x82CC0Au: goto L_82CC0A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82CBF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBF4u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBF4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CBF4 SEP
    cpu.sep(0x20u);
    goto L_82CBF6;
L_82CBF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBF6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBF6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CBF6 LDA
    cpu.setA(0x13u, 8);
    goto L_82CBF8;
L_82CBF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBF8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBF8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CBF8 STA
    hw.write(cpu.address("dp", 0x7Au), cpu.a, cpu.m8?8:16);
    goto L_82CBFA;
L_82CBFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBFAu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBFAu, 6u, 3u, cpu.address("abs", 0x0141u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CBFA INC
    cpu.incMem(hw, cpu.address("abs", 0x141u), cpu.m8?8:16);
    goto L_82CBFD;
L_82CBFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBFDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBFDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CBFD LDA
    cpu.setA(0x4u, 8);
    goto L_82CBFF;
L_82CBFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBFFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBFFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CBFF STA
    hw.write(cpu.address("dp", 0x7Bu), cpu.a, cpu.m8?8:16);
    goto L_82CC01;
L_82CC01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC01u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC01u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CC01 LDA
    cpu.setA(0xC3u, 8);
    goto L_82CC03;
L_82CC03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC03u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC03u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CC03 XBA
    cpu.xba();
    goto L_82CC04;
L_82CC04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC04u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC04u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CC04 LDA
    cpu.setA(0xF1u, 8);
    goto L_82CC06;
L_82CC06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC06u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC06u, 8u, 4u, 0x808700u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82CC06 JSL -> $808700 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xCC09u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCC0Au,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808700u, 0x82CC06u); }
    goto L_82CC0A;
L_82CC0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC0Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCC0Au,0x82CC0Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC0Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC0Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82CC0A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82CC0Au);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82CC0Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82D29A_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82D29Au: goto L_82D29A;
    case 0x82D29Cu: goto L_82D29C;
    case 0x82D29Fu: goto L_82D29F;
    case 0x82D2A1u: goto L_82D2A1;
    case 0x82D2A4u: goto L_82D2A4;
    case 0x82D2A7u: goto L_82D2A7;
    case 0x82D2AAu: goto L_82D2AA;
    case 0x82D2ACu: goto L_82D2AC;
    case 0x82D2AFu: goto L_82D2AF;
    case 0x82D2B3u: goto L_82D2B3;
    case 0x82D2B5u: goto L_82D2B5;
    case 0x82D2B8u: goto L_82D2B8;
    case 0x82D2BAu: goto L_82D2BA;
    case 0x82D2BDu: goto L_82D2BD;
    case 0x82D2BFu: goto L_82D2BF;
    case 0x82D2C2u: goto L_82D2C2;
    case 0x82D2C4u: goto L_82D2C4;
    case 0x82D2C8u: goto L_82D2C8;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82D29A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD29Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD29Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD29Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D29A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D29C;
L_82D29C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD29Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD29Cu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD29Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D29C AND
    cpu.logicAnd(0x1Fu);
    goto L_82D29F;
L_82D29F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD29Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD29Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD29Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D29F BNE -> $82D2A4
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82D2A4; }
    goto L_82D2A1;
L_82D2A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2A1u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2A1u, 8u, 3u, cpu.address("abs", 0x0818u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D2A1 INC
    cpu.incMem(hw, cpu.address("abs", 0x818u), cpu.m8?8:16);
    goto L_82D2A4;
L_82D2A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2A4u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2A4u, 5u, 3u, cpu.address("abs", 0x0818u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D2A4 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x818u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D2A7;
L_82D2A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2A7u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2A7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D2A7 BIT
    cpu.bit(0x1u, true);
    goto L_82D2AA;
L_82D2AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2AAu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2AAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D2AA BNE -> $82D2C8
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82D2C8; }
    goto L_82D2AC;
L_82D2AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2ACu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2ACu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D2AC LDX
    cpu.setX(0x22u, 16);
    goto L_82D2AF;
L_82D2AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2AFu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2AFu, 6u, 4u, ((0x9E8232u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D2AF LDA
    cpu.loadA(hw.readW(((0x9E8232u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D2B3;
L_82D2B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2B3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2B3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D2B3 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82D2B5;
L_82D2B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2B5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2B5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D2B5 LDA
    cpu.setA(0x9Eu, 16);
    goto L_82D2B8;
L_82D2B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2B8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2B8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D2B8 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_82D2BA;
L_82D2BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2BAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2BAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D2BA LDA
    cpu.setA(0x18u, 16);
    goto L_82D2BD;
L_82D2BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2BDu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2BDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D2BD STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_82D2BF;
L_82D2BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2BFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2BFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D2BF LDA
    cpu.setA(0x80u, 16);
    goto L_82D2C2;
L_82D2C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2C2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2C2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D2C2 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_82D2C4;
L_82D2C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2C4u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2C4u, 8u, 4u, 0x80887Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82D2C4 JSL -> $80887E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD2C7u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD2C8u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80887Eu, 0x82D2C4u); }
    goto L_82D2C8;
L_82D2C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2C8u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD2C8u,0x82D2C8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2C8u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2C8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D2C8 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82D2C8u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82D2C8u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82D528_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82D528u: goto L_82D528;
    case 0x82D529u: goto L_82D529;
    case 0x82D52Bu: goto L_82D52B;
    case 0x82D52Du: goto L_82D52D;
    case 0x82D52Eu: goto L_82D52E;
    case 0x82D530u: goto L_82D530;
    case 0x82D531u: goto L_82D531;
    case 0x82D534u: goto L_82D534;
    case 0x82D537u: goto L_82D537;
    case 0x82D539u: goto L_82D539;
    case 0x82D53Cu: goto L_82D53C;
    case 0x82D53Eu: goto L_82D53E;
    case 0x82D540u: goto L_82D540;
    case 0x82D543u: goto L_82D543;
    case 0x82D544u: goto L_82D544;
    case 0x82D545u: goto L_82D545;
    case 0x82D547u: goto L_82D547;
    case 0x82D548u: goto L_82D548;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82D528:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD528u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD528u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD528u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82D528 PHB
    cpu.push("PHB", hw);
    goto L_82D529;
L_82D529:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD529u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD529u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD529u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D529 SEP
    cpu.sep(0x20u);
    goto L_82D52B;
L_82D52B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD52Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD52Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD52Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D52B LDA
    cpu.setA(0x7Eu, 8);
    goto L_82D52D;
L_82D52D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD52Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD52Du,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD52Du, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82D52D PHA
    cpu.push("PHA", hw);
    goto L_82D52E;
L_82D52E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD52Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD52Eu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD52Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D52E REP
    cpu.rep(0x20u);
    goto L_82D530;
L_82D530:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD530u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD530u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD530u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82D530 PLB
    cpu.pop("PLB", hw);
    goto L_82D531;
L_82D531:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD531u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD531u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD531u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D531 LDY
    cpu.setY(0x418u, 16);
    goto L_82D534;
L_82D534:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD534u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD534u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD534u, 5u + 1u, 3u, cpu.address("absy", 0x2000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D534 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x2000u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D537;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD534u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD534u, 5u + 1u, 3u, cpu.address("absy", 0x2000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D534 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x2000u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D537;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD534u,0x82D534u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82D537:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD537u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD537u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD537u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D537 BEQ -> $82D543
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82D543; }
    goto L_82D539;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD537u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD537u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D537 BEQ -> $82D543
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82D543; }
    goto L_82D539;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD537u,0x82D537u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82D539:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD539u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD539u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD539u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D539 CMP
    cpu.compareA(0xFFFFu);
    goto L_82D53C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD539u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD539u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D539 CMP
    cpu.compareA(0xFFFFu);
    goto L_82D53C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD539u,0x82D539u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82D53C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD53Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD53Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD53Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D53C BEQ -> $82D543
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82D543; }
    goto L_82D53E;
L_82D53E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD53Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD53Eu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD53Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D53E ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16));
    goto L_82D540;
L_82D540:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD540u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD540u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD540u, 6u, 3u, cpu.address("absy", 0x2000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D540 STA
    hw.write(cpu.address("absy", 0x2000u), cpu.a, cpu.m8?8:16);
    goto L_82D543;
L_82D543:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD543u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD543u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD543u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D543 DEY
    cpu.decReg('Y');
    goto L_82D544;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD543u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD543u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D543 DEY
    cpu.decReg('Y');
    goto L_82D544;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD543u,0x82D543u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82D544:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD544u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD544u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD544u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D544 DEY
    cpu.decReg('Y');
    goto L_82D545;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD544u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD544u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D544 DEY
    cpu.decReg('Y');
    goto L_82D545;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD544u,0x82D544u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82D545:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD545u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD545u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD545u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D545 BPL -> $82D534
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82D534; }
    goto L_82D547;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD545u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD545u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D545 BPL -> $82D534
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82D534; }
    goto L_82D547;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD545u,0x82D545u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82D547:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD547u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD547u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD547u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82D547 PLB
    cpu.pop("PLB", hw);
    goto L_82D548;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD547u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD547u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82D547 PLB
    cpu.pop("PLB", hw);
    goto L_82D548;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD547u,0x82D547u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82D548:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD548u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD548u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD548u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D548 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82D548u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82D548u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD548u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD548u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D548 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82D548u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82D548u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD548u,0x82D548u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_82D528_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82D528u: goto L_82D528;
    case 0x82D529u: goto L_82D529;
    case 0x82D52Bu: goto L_82D52B;
    case 0x82D52Du: goto L_82D52D;
    case 0x82D52Eu: goto L_82D52E;
    case 0x82D530u: goto L_82D530;
    case 0x82D531u: goto L_82D531;
    case 0x82D534u: goto L_82D534;
    case 0x82D537u: goto L_82D537;
    case 0x82D539u: goto L_82D539;
    case 0x82D53Cu: goto L_82D53C;
    case 0x82D53Eu: goto L_82D53E;
    case 0x82D540u: goto L_82D540;
    case 0x82D543u: goto L_82D543;
    case 0x82D544u: goto L_82D544;
    case 0x82D545u: goto L_82D545;
    case 0x82D547u: goto L_82D547;
    case 0x82D548u: goto L_82D548;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82D528:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD528u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD528u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD528u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82D528 PHB
    cpu.push("PHB", hw);
    goto L_82D529;
L_82D529:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD529u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD529u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD529u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D529 SEP
    cpu.sep(0x20u);
    goto L_82D52B;
L_82D52B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD52Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD52Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD52Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D52B LDA
    cpu.setA(0x7Eu, 8);
    goto L_82D52D;
L_82D52D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD52Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD52Du,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD52Du, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82D52D PHA
    cpu.push("PHA", hw);
    goto L_82D52E;
L_82D52E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD52Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD52Eu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD52Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D52E REP
    cpu.rep(0x20u);
    goto L_82D530;
L_82D530:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD530u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD530u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD530u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82D530 PLB
    cpu.pop("PLB", hw);
    goto L_82D531;
L_82D531:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD531u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD531u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD531u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D531 LDY
    cpu.setY(0x418u, 16);
    goto L_82D534;
L_82D534:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD534u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD534u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD534u, 5u + 1u, 3u, cpu.address("absy", 0x2000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D534 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x2000u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D537;
L_82D537:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD537u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD537u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD537u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D537 BEQ -> $82D543
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82D543; }
    goto L_82D539;
L_82D539:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD539u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD539u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD539u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D539 CMP
    cpu.compareA(0xFFFFu);
    goto L_82D53C;
L_82D53C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD53Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD53Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD53Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D53C BEQ -> $82D543
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82D543; }
    goto L_82D53E;
L_82D53E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD53Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD53Eu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD53Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D53E ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16));
    goto L_82D540;
L_82D540:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD540u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD540u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD540u, 6u, 3u, cpu.address("absy", 0x2000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D540 STA
    hw.write(cpu.address("absy", 0x2000u), cpu.a, cpu.m8?8:16);
    goto L_82D543;
L_82D543:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD543u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD543u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD543u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D543 DEY
    cpu.decReg('Y');
    goto L_82D544;
L_82D544:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD544u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD544u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD544u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D544 DEY
    cpu.decReg('Y');
    goto L_82D545;
L_82D545:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD545u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD545u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD545u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D545 BPL -> $82D534
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82D534; }
    goto L_82D547;
L_82D547:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD547u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD547u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD547u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82D547 PLB
    cpu.pop("PLB", hw);
    goto L_82D548;
L_82D548:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD548u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD548u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD548u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D548 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82D548u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82D548u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82D711_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82D711u: goto L_82D711;
    case 0x82D713u: goto L_82D713;
    case 0x82D716u: goto L_82D716;
    case 0x82D718u: goto L_82D718;
    case 0x82D71Bu: goto L_82D71B;
    case 0x82D71Cu: goto L_82D71C;
    case 0x82D71Du: goto L_82D71D;
    case 0x82D71Fu: goto L_82D71F;
    case 0x82D721u: goto L_82D721;
    case 0x82D724u: goto L_82D724;
    case 0x82D726u: goto L_82D726;
    case 0x82D72Au: goto L_82D72A;
    case 0x82D72Cu: goto L_82D72C;
    case 0x82D72Fu: goto L_82D72F;
    case 0x82D731u: goto L_82D731;
    case 0x82D735u: goto L_82D735;
    case 0x82D737u: goto L_82D737;
    case 0x82D73Au: goto L_82D73A;
    case 0x82D73Du: goto L_82D73D;
    case 0x82D741u: goto L_82D741;
    case 0x82D743u: goto L_82D743;
    case 0x82D746u: goto L_82D746;
    case 0x82D748u: goto L_82D748;
    case 0x82D74Bu: goto L_82D74B;
    case 0x82D74Du: goto L_82D74D;
    case 0x82D750u: goto L_82D750;
    case 0x82D753u: goto L_82D753;
    case 0x82D754u: goto L_82D754;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82D711:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD711u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD711u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD711u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D711 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82D713;
L_82D713:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD713u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD713u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD713u, 5u + 1u, 3u, cpu.address("absx", 0x0402u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D713 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x402u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D716;
L_82D716:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD716u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD716u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD716u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D716 BPL -> $82D73A
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82D73A; }
    goto L_82D718;
L_82D718:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD718u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD718u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD718u, 5u + 1u, 3u, cpu.address("absx", 0x0400u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D718 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x400u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D71B;
L_82D71B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD71Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD71Bu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD71Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D71B ASL
    cpu.aslA();
    goto L_82D71C;
L_82D71C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD71Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD71Cu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD71Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D71C TAX
    cpu.transfer("TAX");
    goto L_82D71D;
L_82D71D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD71Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD71Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD71Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D71D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D71F;
L_82D71F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD71Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD71Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD71Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D71F BNE -> $82D72C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82D72C; }
    goto L_82D721;
L_82D721:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD721u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD721u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD721u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D721 LDA
    cpu.setA(0x2u, 16);
    goto L_82D724;
L_82D724:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD724u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD724u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD724u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D724 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_82D726;
L_82D726:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD726u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD726u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD726u, 6u, 4u, ((0x9E956Eu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D726 LDA
    cpu.loadA(hw.readW(((0x9E956Eu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D72A;
L_82D72A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD72Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD72Au,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD72Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D72A BRA -> $82D735
    goto L_82D735;
L_82D72C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD72Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD72Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD72Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D72C LDA
    cpu.setA(0xFFFEu, 16);
    goto L_82D72F;
L_82D72F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD72Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD72Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD72Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D72F STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_82D731;
L_82D731:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD731u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD731u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD731u, 6u, 4u, ((0x9E9598u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D731 LDA
    cpu.loadA(hw.readW(((0x9E9598u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D735;
L_82D735:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD735u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD735u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD735u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D735 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82D737;
L_82D737:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD737u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD737u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD737u, 6u, 3u, cpu.address("abs", 0xD769u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D737 JSR -> $82D769 stack real
    { cpu.push16Value(hw,0xD739u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD73Au,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD769u), 0x82D737u); }
    goto L_82D73A;
L_82D73A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD73Au))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD73Au,0x82D73Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD73Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD73Au, 6u, 3u, cpu.address("abs", 0xD7C1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D73A JSR -> $82D7C1 stack real
    { cpu.push16Value(hw,0xD73Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD73Du,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD7C1u), 0x82D73Au); }
    goto L_82D73D;
L_82D73D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD73Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD73Du,0x82D73Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD73Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD73Du, 8u, 4u, 0x808EE1u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82D73D JSL -> $808EE1 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD740u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD741u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808EE1u, 0x82D73Du); }
    goto L_82D741;
L_82D741:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD741u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD741u,0x82D741u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD741u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD741u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D741 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82D743;
L_82D743:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD743u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD743u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD743u, 5u + 1u, 3u, cpu.address("absx", 0x0402u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D743 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x402u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D746;
L_82D746:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD746u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD746u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD746u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D746 BPL -> $82D74D
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82D74D; }
    goto L_82D748;
L_82D748:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD748u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD748u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD748u, 9u, 3u, cpu.address("absx", 0x0402u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D748 INC
    cpu.incMem(hw, cpu.address("absx", 0x402u), cpu.m8?8:16);
    goto L_82D74B;
L_82D74B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD74Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD74Bu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD74Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D74B BRA -> $82D750
    goto L_82D750;
L_82D74D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD74Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD74Du,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD74Du, 9u, 3u, cpu.address("absx", 0x0402u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D74D DEC
    cpu.decMem(hw, cpu.address("absx", 0x402u), cpu.m8?8:16);
    goto L_82D750;
L_82D750:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD750u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD750u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD750u, 6u, 3u, cpu.address("absx", 0x0404u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D750 STZ
    hw.write(cpu.address("absx", 0x404u), 0, cpu.m8?8:16);
    goto L_82D753;
L_82D753:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD753u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD753u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD753u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D753 SEC
    cpu.setFlag('C', true);
    goto L_82D754;
L_82D754:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD754u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD754u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD754u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D754 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82D754u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82D754u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82E22F_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82E22Fu: goto L_82E22F;
    case 0x82E230u: goto L_82E230;
    case 0x82E232u: goto L_82E232;
    case 0x82E234u: goto L_82E234;
    case 0x82E235u: goto L_82E235;
    case 0x82E236u: goto L_82E236;
    case 0x82E238u: goto L_82E238;
    case 0x82E23Bu: goto L_82E23B;
    case 0x82E23Du: goto L_82E23D;
    case 0x82E23Fu: goto L_82E23F;
    case 0x82E241u: goto L_82E241;
    case 0x82E244u: goto L_82E244;
    case 0x82E246u: goto L_82E246;
    case 0x82E249u: goto L_82E249;
    case 0x82E24Bu: goto L_82E24B;
    case 0x82E24Du: goto L_82E24D;
    case 0x82E24Eu: goto L_82E24E;
    case 0x82E251u: goto L_82E251;
    case 0x82E253u: goto L_82E253;
    case 0x82E255u: goto L_82E255;
    case 0x82E258u: goto L_82E258;
    case 0x82E25Au: goto L_82E25A;
    case 0x82E25Du: goto L_82E25D;
    case 0x82E25Fu: goto L_82E25F;
    case 0x82E261u: goto L_82E261;
    case 0x82E263u: goto L_82E263;
    case 0x82E266u: goto L_82E266;
    case 0x82E268u: goto L_82E268;
    case 0x82E26Au: goto L_82E26A;
    case 0x82E26Du: goto L_82E26D;
    case 0x82E26Fu: goto L_82E26F;
    case 0x82E271u: goto L_82E271;
    case 0x82E273u: goto L_82E273;
    case 0x82E276u: goto L_82E276;
    case 0x82E278u: goto L_82E278;
    case 0x82E279u: goto L_82E279;
    case 0x82E27Au: goto L_82E27A;
    case 0x82E27Cu: goto L_82E27C;
    case 0x82E27Du: goto L_82E27D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82E22F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE22Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE22Fu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE22Fu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82E22F PHB
    cpu.push("PHB", hw);
    goto L_82E230;
L_82E230:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE230u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE230u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE230u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E230 SEP
    cpu.sep(0x20u);
    goto L_82E232;
L_82E232:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE232u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE232u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE232u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x69u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E232 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x69u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E234;
L_82E234:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE234u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE234u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE234u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82E234 PHA
    cpu.push("PHA", hw);
    goto L_82E235;
L_82E235:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE235u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE235u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE235u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82E235 PLB
    cpu.pop("PLB", hw);
    goto L_82E236;
L_82E236:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE236u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE236u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE236u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E236 REP
    cpu.rep(0x20u);
    goto L_82E238;
L_82E238:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE238u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE238u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE238u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E238 LDY
    cpu.setY(0x1F8u, 16);
    goto L_82E23B;
L_82E23B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE23Bu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE23Bu,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE23Bu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82E23B LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E23D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE23Bu,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE23Bu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82E23B LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E23D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE23Bu,0x82E23Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E23D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE23Du))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE23Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE23Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E23D STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_82E23F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE23Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE23Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E23D STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_82E23F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE23Du,0x82E23Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E23F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE23Fu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE23Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE23Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E23F BEQ -> $82E278
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E278; }
    goto L_82E241;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE23Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE23Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E23F BEQ -> $82E278
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E278; }
    goto L_82E241;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE23Fu,0x82E23Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E241:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE241u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE241u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE241u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E241 CMP
    cpu.compareA(0xFFFFu);
    goto L_82E244;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE241u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE241u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E241 CMP
    cpu.compareA(0xFFFFu);
    goto L_82E244;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE241u,0x82E241u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E244:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE244u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE244u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE244u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E244 BEQ -> $82E278
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E278; }
    goto L_82E246;
L_82E246:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE246u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE246u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE246u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E246 BIT
    cpu.bit(0x4000u, true);
    goto L_82E249;
L_82E249:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE249u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE249u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE249u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E249 BNE -> $82E278
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E278; }
    goto L_82E24B;
L_82E24B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE24Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE24Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE24Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x67u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E24B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E24D;
L_82E24D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE24Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE24Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE24Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E24D CLC
    cpu.setFlag('C', false);
    goto L_82E24E;
L_82E24E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE24Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE24Eu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE24Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E24E ADC
    cpu.adc(0x16u);
    goto L_82E251;
L_82E251:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE251u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE251u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE251u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E251 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82E253;
L_82E253:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE253u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE253u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE253u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 2u, 0u);
    // $82E253 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E255;
L_82E255:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE255u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE255u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE255u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E255 BIT
    cpu.bit(0x4000u, true);
    goto L_82E258;
L_82E258:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE258u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE258u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE258u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E258 BNE -> $82E261
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E261; }
    goto L_82E25A;
L_82E25A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE25Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE25Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE25Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E25A CMP
    cpu.compareA(0xFFFFu);
    goto L_82E25D;
L_82E25D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE25Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE25Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE25Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E25D BEQ -> $82E261
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E261; }
    goto L_82E25F;
L_82E25F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE25Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE25Fu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE25Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E25F BRA -> $82E278
    goto L_82E278;
L_82E261:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE261u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE261u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE261u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E261 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E263;
L_82E263:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE263u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE263u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE263u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E263 BIT
    cpu.bit(0xFu, true);
    goto L_82E266;
L_82E266:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE266u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE266u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE266u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E266 BEQ -> $82E271
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E271; }
    goto L_82E268;
L_82E268:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE268u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE268u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE268u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E268 STY
    hw.write(cpu.address("dp", 0x63u), cpu.y, cpu.x8?8:16);
    goto L_82E26A;
L_82E26A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE26Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE26Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE26Au, 6u, 3u, cpu.address("abs", 0xE2ADu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82E26A JSR -> $82E2AD stack real
    { cpu.push16Value(hw,0xE26Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE26Du,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xE2ADu), 0x82E26Au); }
    goto L_82E26D;
L_82E26D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE26Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE26Du,0x82E26Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE26Du,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE26Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E26D LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82E26F;
L_82E26F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE26Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE26Fu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE26Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E26F BRA -> $82E278
    goto L_82E278;
L_82E271:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE271u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE271u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE271u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82E271 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E273;
L_82E273:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE273u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE273u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE273u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E273 ORA
    cpu.logicOr(0x4000u);
    goto L_82E276;
L_82E276:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE276u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE276u,cpu,0x91u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE276u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82E276 STA
    hw.write(cpu.addressDpIndirectY(hw, 0x67u), cpu.a, cpu.m8?8:16);
    goto L_82E278;
L_82E278:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE278u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE278u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE278u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E278 DEY
    cpu.decReg('Y');
    goto L_82E279;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE278u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE278u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E278 DEY
    cpu.decReg('Y');
    goto L_82E279;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE278u,0x82E278u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E279:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE279u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE279u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE279u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E279 DEY
    cpu.decReg('Y');
    goto L_82E27A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE279u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE279u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E279 DEY
    cpu.decReg('Y');
    goto L_82E27A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE279u,0x82E279u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E27A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE27Au))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE27Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE27Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E27A BNE -> $82E23B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E23B; }
    goto L_82E27C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE27Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE27Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E27A BNE -> $82E23B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E23B; }
    goto L_82E27C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE27Au,0x82E27Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E27C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE27Cu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE27Cu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE27Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82E27C PLB
    cpu.pop("PLB", hw);
    goto L_82E27D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE27Cu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE27Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82E27C PLB
    cpu.pop("PLB", hw);
    goto L_82E27D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE27Cu,0x82E27Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E27D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE27Du))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE27Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE27Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82E27D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82E27Du);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82E27Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE27Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE27Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82E27D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82E27Du);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82E27Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE27Du,0x82E27Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_848C63_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848C63u: goto L_848C63;
    case 0x848C65u: goto L_848C65;
    case 0x848C68u: goto L_848C68;
    case 0x848C6Bu: goto L_848C6B;
    case 0x848C6Eu: goto L_848C6E;
    case 0x848C70u: goto L_848C70;
    case 0x848C73u: goto L_848C73;
    case 0x848C75u: goto L_848C75;
    case 0x848C78u: goto L_848C78;
    case 0x848C7Au: goto L_848C7A;
    case 0x848C7Du: goto L_848C7D;
    case 0x848C81u: goto L_848C81;
    case 0x848C84u: goto L_848C84;
    case 0x848C87u: goto L_848C87;
    case 0x848C8Au: goto L_848C8A;
    case 0x848C8Du: goto L_848C8D;
    case 0x848C91u: goto L_848C91;
    case 0x848C93u: goto L_848C93;
    case 0x848C95u: goto L_848C95;
    case 0x848C96u: goto L_848C96;
    case 0x848C99u: goto L_848C99;
    case 0x848C9Cu: goto L_848C9C;
    case 0x848C9Fu: goto L_848C9F;
    case 0x848CA3u: goto L_848CA3;
    case 0x848CA6u: goto L_848CA6;
    case 0x848CA9u: goto L_848CA9;
    case 0x848CACu: goto L_848CAC;
    case 0x848CAFu: goto L_848CAF;
    case 0x848CB3u: goto L_848CB3;
    case 0x848CB5u: goto L_848CB5;
    case 0x848CB7u: goto L_848CB7;
    case 0x848CB8u: goto L_848CB8;
    case 0x848CBBu: goto L_848CBB;
    case 0x848CBEu: goto L_848CBE;
    case 0x848CC1u: goto L_848CC1;
    case 0x848CC5u: goto L_848CC5;
    case 0x848CC8u: goto L_848CC8;
    case 0x848CCBu: goto L_848CCB;
    case 0x848CCEu: goto L_848CCE;
    case 0x848CD1u: goto L_848CD1;
    case 0x848CD5u: goto L_848CD5;
    case 0x848CD7u: goto L_848CD7;
    case 0x848CD9u: goto L_848CD9;
    case 0x848CDAu: goto L_848CDA;
    case 0x848CDDu: goto L_848CDD;
    case 0x848CE0u: goto L_848CE0;
    case 0x848CE3u: goto L_848CE3;
    case 0x848CE7u: goto L_848CE7;
    case 0x848CEAu: goto L_848CEA;
    case 0x848CEDu: goto L_848CED;
    case 0x848CF0u: goto L_848CF0;
    case 0x848CF3u: goto L_848CF3;
    case 0x848CF7u: goto L_848CF7;
    case 0x848CF9u: goto L_848CF9;
    case 0x848CFBu: goto L_848CFB;
    case 0x848CFCu: goto L_848CFC;
    case 0x848CFFu: goto L_848CFF;
    case 0x848D02u: goto L_848D02;
    case 0x848D05u: goto L_848D05;
    case 0x848D09u: goto L_848D09;
    case 0x848D0Cu: goto L_848D0C;
    case 0x848D0Fu: goto L_848D0F;
    case 0x848D12u: goto L_848D12;
    case 0x848D15u: goto L_848D15;
    case 0x848D19u: goto L_848D19;
    case 0x848D1Au: goto L_848D1A;
    case 0x848D1Du: goto L_848D1D;
    case 0x848D20u: goto L_848D20;
    case 0x848D22u: goto L_848D22;
    case 0x848D23u: goto L_848D23;
    case 0x848D26u: goto L_848D26;
    case 0x848D27u: goto L_848D27;
    case 0x848D2Au: goto L_848D2A;
    case 0x848D2Du: goto L_848D2D;
    case 0x848D30u: goto L_848D30;
    case 0x848D33u: goto L_848D33;
    case 0x848D37u: goto L_848D37;
    case 0x848D38u: goto L_848D38;
    case 0x848D3Bu: goto L_848D3B;
    case 0x848D3Eu: goto L_848D3E;
    case 0x848D40u: goto L_848D40;
    case 0x848D41u: goto L_848D41;
    case 0x848D44u: goto L_848D44;
    case 0x848D45u: goto L_848D45;
    case 0x848D48u: goto L_848D48;
    case 0x848D4Bu: goto L_848D4B;
    case 0x848D4Eu: goto L_848D4E;
    case 0x848D51u: goto L_848D51;
    case 0x848D55u: goto L_848D55;
    case 0x848D56u: goto L_848D56;
    case 0x848D59u: goto L_848D59;
    case 0x848D5Cu: goto L_848D5C;
    case 0x848D5Eu: goto L_848D5E;
    case 0x848D5Fu: goto L_848D5F;
    case 0x848D62u: goto L_848D62;
    case 0x848D63u: goto L_848D63;
    case 0x848D66u: goto L_848D66;
    case 0x848D69u: goto L_848D69;
    case 0x848D6Cu: goto L_848D6C;
    case 0x848D6Fu: goto L_848D6F;
    case 0x848D72u: goto L_848D72;
    case 0x848D74u: goto L_848D74;
    case 0x848D77u: goto L_848D77;
    case 0x848D7Au: goto L_848D7A;
    case 0x848D7Du: goto L_848D7D;
    case 0x848D7Fu: goto L_848D7F;
    case 0x848D82u: goto L_848D82;
    case 0x848D84u: goto L_848D84;
    case 0x848D87u: goto L_848D87;
    case 0x848D8Au: goto L_848D8A;
    case 0x848D8Cu: goto L_848D8C;
    case 0x848D8Fu: goto L_848D8F;
    case 0x848D92u: goto L_848D92;
    case 0x848D95u: goto L_848D95;
    case 0x848D97u: goto L_848D97;
    case 0x848D99u: goto L_848D99;
    case 0x848D9Au: goto L_848D9A;
    case 0x848D9Du: goto L_848D9D;
    case 0x848DA0u: goto L_848DA0;
    case 0x848DA3u: goto L_848DA3;
    case 0x848DA7u: goto L_848DA7;
    case 0x848DA9u: goto L_848DA9;
    case 0x848DABu: goto L_848DAB;
    case 0x848DACu: goto L_848DAC;
    case 0x848DAFu: goto L_848DAF;
    case 0x848DB2u: goto L_848DB2;
    case 0x848DB5u: goto L_848DB5;
    case 0x848DB9u: goto L_848DB9;
    case 0x848DBBu: goto L_848DBB;
    case 0x848DBDu: goto L_848DBD;
    case 0x848DBEu: goto L_848DBE;
    case 0x848DC1u: goto L_848DC1;
    case 0x848DC4u: goto L_848DC4;
    case 0x848DC7u: goto L_848DC7;
    case 0x848DCBu: goto L_848DCB;
    case 0x848DCEu: goto L_848DCE;
    case 0x848DD0u: goto L_848DD0;
    case 0x848DD3u: goto L_848DD3;
    case 0x848DD5u: goto L_848DD5;
    case 0x848DD8u: goto L_848DD8;
    case 0x848DDBu: goto L_848DDB;
    case 0x848DDFu: goto L_848DDF;
    case 0x848DE2u: goto L_848DE2;
    case 0x848DE5u: goto L_848DE5;
    case 0x848DE8u: goto L_848DE8;
    case 0x848DEBu: goto L_848DEB;
    case 0x848DEEu: goto L_848DEE;
    case 0x848DF0u: goto L_848DF0;
    case 0x848DF2u: goto L_848DF2;
    case 0x848DF4u: goto L_848DF4;
    case 0x848DF6u: goto L_848DF6;
    case 0x848DF9u: goto L_848DF9;
    case 0x848DFCu: goto L_848DFC;
    case 0x848DFFu: goto L_848DFF;
    case 0x848E02u: goto L_848E02;
    case 0x848E05u: goto L_848E05;
    case 0x848E08u: goto L_848E08;
    case 0x848E0Bu: goto L_848E0B;
    case 0x848E0Eu: goto L_848E0E;
    case 0x848E12u: goto L_848E12;
    case 0x848E15u: goto L_848E15;
    case 0x848E18u: goto L_848E18;
    case 0x848E1Bu: goto L_848E1B;
    case 0x848E1Eu: goto L_848E1E;
    case 0x848E21u: goto L_848E21;
    case 0x848E23u: goto L_848E23;
    case 0x848E26u: goto L_848E26;
    case 0x848E29u: goto L_848E29;
    case 0x848E2Au: goto L_848E2A;
    case 0x848E2Cu: goto L_848E2C;
    case 0x848E2Du: goto L_848E2D;
    case 0x848E30u: goto L_848E30;
    case 0x848E32u: goto L_848E32;
    case 0x848E35u: goto L_848E35;
    case 0x848E38u: goto L_848E38;
    case 0x848E39u: goto L_848E39;
    case 0x848E3Cu: goto L_848E3C;
    case 0x848E3Du: goto L_848E3D;
    case 0x848E3Fu: goto L_848E3F;
    case 0x848E40u: goto L_848E40;
    case 0x848E43u: goto L_848E43;
    case 0x848E44u: goto L_848E44;
    case 0x848E45u: goto L_848E45;
    case 0x848E48u: goto L_848E48;
    case 0x848E49u: goto L_848E49;
    case 0x848E4Cu: goto L_848E4C;
    case 0x848E4Eu: goto L_848E4E;
    case 0x848E51u: goto L_848E51;
    case 0x848E52u: goto L_848E52;
    case 0x848E54u: goto L_848E54;
    case 0x848E57u: goto L_848E57;
    case 0x848E59u: goto L_848E59;
    case 0x848E5Bu: goto L_848E5B;
    case 0x848E5Fu: goto L_848E5F;
    case 0x848E61u: goto L_848E61;
    case 0x848E65u: goto L_848E65;
    case 0x848E69u: goto L_848E69;
    case 0x848E6Bu: goto L_848E6B;
    case 0x848E6Fu: goto L_848E6F;
    case 0x848E71u: goto L_848E71;
    case 0x848E75u: goto L_848E75;
    case 0x848E79u: goto L_848E79;
    case 0x848E7Bu: goto L_848E7B;
    case 0x848E7Fu: goto L_848E7F;
    case 0x848E81u: goto L_848E81;
    case 0x848E83u: goto L_848E83;
    case 0x848E86u: goto L_848E86;
    case 0x848E88u: goto L_848E88;
    case 0x848E8Bu: goto L_848E8B;
    case 0x848E8Du: goto L_848E8D;
    case 0x848E90u: goto L_848E90;
    case 0x848E92u: goto L_848E92;
    case 0x848E95u: goto L_848E95;
    case 0x848E98u: goto L_848E98;
    case 0x848E9Bu: goto L_848E9B;
    case 0x848E9Du: goto L_848E9D;
    case 0x848EA0u: goto L_848EA0;
    case 0x848EA2u: goto L_848EA2;
    case 0x848EA5u: goto L_848EA5;
    case 0x848EA7u: goto L_848EA7;
    case 0x848EA8u: goto L_848EA8;
    case 0x848EAAu: goto L_848EAA;
    case 0x848EAEu: goto L_848EAE;
    case 0x848EB0u: goto L_848EB0;
    case 0x848EB1u: goto L_848EB1;
    case 0x848EB3u: goto L_848EB3;
    case 0x848EB7u: goto L_848EB7;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848C63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C63u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C63u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C63u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C63 REP
    cpu.rep(0x20u);
    goto L_848C65;
L_848C65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C65u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C65u, 5u, 3u, cpu.address("abs", 0x01BFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C65 STZ
    hw.write(cpu.address("abs", 0x1BFu), 0, cpu.m8?8:16);
    goto L_848C68;
L_848C68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C68u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C68u, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C68 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848C6B;
L_848C6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C6Bu,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C6Bu, 5u, 3u, cpu.address("abs", 0x0631u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C6B CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x631u), cpu.m8?8:16));
    goto L_848C6E;
L_848C6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C6Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C6Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C6E BEQ -> $848C7A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_848C7A; }
    goto L_848C70;
L_848C70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C70u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C70u, 5u, 3u, cpu.address("abs", 0x0631u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C70 STA
    hw.write(cpu.address("abs", 0x631u), cpu.a, cpu.m8?8:16);
    goto L_848C73;
L_848C73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C73u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C73u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C73 SEP
    cpu.sep(0x20u);
    goto L_848C75;
L_848C75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C75u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C75u, 4u, 3u, cpu.address("abs", 0x062Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C75 STZ
    hw.write(cpu.address("abs", 0x62Cu), 0, cpu.m8?8:16);
    goto L_848C78;
L_848C78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C78u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C78u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C78 REP
    cpu.rep(0x20u);
    goto L_848C7A;
L_848C7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C7Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C7Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C7A LDA
    cpu.setA(0x1u, 16);
    goto L_848C7D;
L_848C7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C7Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C7Du, 8u, 4u, 0x808D4Au, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848C7D JSL -> $808D4A stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8C80u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8C81u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808D4Au, 0x848C7Du); }
    goto L_848C81;
L_848C81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C81u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C81u,0x848C81u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C81u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C81u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C81 LDA
    cpu.setA(0x9F49u, 16);
    goto L_848C84;
L_848C84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C84u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C84u, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C84 STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_848C87;
L_848C87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C87u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C87u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C87 LDA
    cpu.setA(0x8Eu, 16);
    goto L_848C8A;
L_848C8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Au, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C8A STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_848C8D;
L_848C8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Du, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848C8D JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8C90u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8C91u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x848C8Du); }
    goto L_848C91;
L_848C91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C91u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C91u,0x848C91u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C91u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C91u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C91 SEP
    cpu.sep(0x20u);
    goto L_848C93;
L_848C93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C93u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C93u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848C93 LDA
    cpu.setA(0x7Eu, 8);
    goto L_848C95;
L_848C95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C95u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C95u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $848C95 PHA
    cpu.push("PHA", hw);
    goto L_848C96;
L_848C96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C96u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C96u, 5u, 3u, cpu.address("abs", 0x8000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848C96 PEA
    cpu.push16Value(hw, 0x8000u);
    goto L_848C99;
L_848C99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C99u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C99u, 5u, 3u, cpu.address("abs", 0x0000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848C99 PEA
    cpu.push16Value(hw, 0x0u);
    goto L_848C9C;
L_848C9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C9Cu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C9Cu, 5u, 3u, cpu.address("abs", 0x2000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848C9C PEA
    cpu.push16Value(hw, 0x2000u);
    goto L_848C9F;
L_848C9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C9Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C9Fu, 8u, 4u, 0x809B54u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848C9F JSL -> $809B54 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8CA2u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8CA3u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809B54u, 0x848C9Fu); }
    goto L_848CA3;
L_848CA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA3u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8CA3u,0x848CA3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848CA3 LDA
    cpu.setA(0x83EFu, 16);
    goto L_848CA6;
L_848CA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA6u, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848CA6 STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_848CA9;
L_848CA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848CA9 LDA
    cpu.setA(0x8Bu, 16);
    goto L_848CAC;
L_848CAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CACu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CACu, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848CAC STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_848CAF;
L_848CAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CAFu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CAFu, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848CAF JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8CB2u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8CB3u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x848CAFu); }
    goto L_848CB3;
L_848CB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CB3u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8CB3u,0x848CB3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB3u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848CB3 SEP
    cpu.sep(0x20u);
    goto L_848CB5;
L_848CB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848CB5 LDA
    cpu.setA(0x7Eu, 8);
    goto L_848CB7;
L_848CB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB7u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB7u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $848CB7 PHA
    cpu.push("PHA", hw);
    goto L_848CB8;
L_848CB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CB8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB8u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB8u, 5u, 3u, cpu.address("abs", 0x8000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848CB8 PEA
    cpu.push16Value(hw, 0x8000u);
    goto L_848CBB;
L_848CBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CBBu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CBBu, 5u, 3u, cpu.address("abs", 0x1000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848CBB PEA
    cpu.push16Value(hw, 0x1000u);
    goto L_848CBE;
L_848CBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CBEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CBEu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CBEu, 5u, 3u, cpu.address("abs", 0x2000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848CBE PEA
    cpu.push16Value(hw, 0x2000u);
    goto L_848CC1;
L_848CC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CC1u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CC1u, 8u, 4u, 0x809B54u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848CC1 JSL -> $809B54 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8CC4u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8CC5u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809B54u, 0x848CC1u); }
    goto L_848CC5;
L_848CC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CC5u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8CC5u,0x848CC5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CC5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CC5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848CC5 LDA
    cpu.setA(0xD714u, 16);
    goto L_848CC8;
L_848CC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CC8u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CC8u, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848CC8 STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_848CCB;
L_848CCB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CCBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CCBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CCBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848CCB LDA
    cpu.setA(0x8Du, 16);
    goto L_848CCE;
L_848CCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CCEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CCEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CCEu, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848CCE STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_848CD1;
L_848CD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CD1u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CD1u, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848CD1 JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8CD4u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8CD5u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x848CD1u); }
    goto L_848CD5;
L_848CD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CD5u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8CD5u,0x848CD5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CD5u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CD5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848CD5 SEP
    cpu.sep(0x20u);
    goto L_848CD7;
L_848CD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CD7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CD7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CD7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848CD7 LDA
    cpu.setA(0x7Eu, 8);
    goto L_848CD9;
L_848CD9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CD9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CD9u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CD9u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $848CD9 PHA
    cpu.push("PHA", hw);
    goto L_848CDA;
L_848CDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CDAu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CDAu, 5u, 3u, cpu.address("abs", 0x8000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848CDA PEA
    cpu.push16Value(hw, 0x8000u);
    goto L_848CDD;
L_848CDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CDDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CDDu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CDDu, 5u, 3u, cpu.address("abs", 0x6000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848CDD PEA
    cpu.push16Value(hw, 0x6000u);
    goto L_848CE0;
L_848CE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CE0u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CE0u, 5u, 3u, cpu.address("abs", 0x2000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848CE0 PEA
    cpu.push16Value(hw, 0x2000u);
    goto L_848CE3;
L_848CE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CE3u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CE3u, 8u, 4u, 0x809B54u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848CE3 JSL -> $809B54 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8CE6u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8CE7u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809B54u, 0x848CE3u); }
    goto L_848CE7;
L_848CE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CE7u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8CE7u,0x848CE7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CE7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CE7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848CE7 LDA
    cpu.setA(0x9F49u, 16);
    goto L_848CEA;
L_848CEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CEAu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CEAu, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848CEA STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_848CED;
L_848CED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CEDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CEDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848CED LDA
    cpu.setA(0x8Eu, 16);
    goto L_848CF0;
L_848CF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CF0u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CF0u, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848CF0 STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_848CF3;
L_848CF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CF3u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CF3u, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848CF3 JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8CF6u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8CF7u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x848CF3u); }
    goto L_848CF7;
L_848CF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CF7u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8CF7u,0x848CF7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CF7u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CF7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848CF7 SEP
    cpu.sep(0x20u);
    goto L_848CF9;
L_848CF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CF9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CF9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848CF9 LDA
    cpu.setA(0x7Eu, 8);
    goto L_848CFB;
L_848CFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CFBu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CFBu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $848CFB PHA
    cpu.push("PHA", hw);
    goto L_848CFC;
L_848CFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CFCu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CFCu, 5u, 3u, cpu.address("abs", 0x8000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848CFC PEA
    cpu.push16Value(hw, 0x8000u);
    goto L_848CFF;
L_848CFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CFFu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CFFu, 5u, 3u, cpu.address("abs", 0x0000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848CFF PEA
    cpu.push16Value(hw, 0x0u);
    goto L_848D02;
L_848D02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D02u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D02u, 5u, 3u, cpu.address("abs", 0x2000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848D02 PEA
    cpu.push16Value(hw, 0x2000u);
    goto L_848D05;
L_848D05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D05u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D05u, 8u, 4u, 0x809B54u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848D05 JSL -> $809B54 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8D08u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8D09u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809B54u, 0x848D05u); }
    goto L_848D09;
L_848D09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D09u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D09u,0x848D09u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D09u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D09u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D09 LDA
    cpu.setA(0xC107u, 16);
    goto L_848D0C;
L_848D0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Cu, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D0C STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_848D0F;
L_848D0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D0F LDA
    cpu.setA(0x8Au, 16);
    goto L_848D12;
L_848D12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D12u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D12u, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D12 STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_848D15;
L_848D15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D15u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D15u, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848D15 JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8D18u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8D19u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x848D15u); }
    goto L_848D19;
L_848D19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D19u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D19u,0x848D19u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D19u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D19u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $848D19 PHB
    cpu.push("PHB", hw);
    goto L_848D1A;
L_848D1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Au,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D1A LDX
    cpu.setX(0x8000u, 16);
    goto L_848D1D;
L_848D1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Du,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D1D LDY
    cpu.setY(0x2800u, 16);
    goto L_848D20;
L_848D20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D20u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D20u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xBDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D20 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xBDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848D22;
L_848D22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D22u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D22u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D22 DEC
    cpu.decReg('A');
    goto L_848D23;
L_848D23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D23u,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0x8D23u, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $848D23 MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_848D26;
L_848D26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D26u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D26u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $848D26 PLB
    cpu.pop("PLB", hw);
    goto L_848D27;
L_848D27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D27u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D27u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D27 LDA
    cpu.setA(0xC268u, 16);
    goto L_848D2A;
L_848D2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Au, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D2A STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_848D2D;
L_848D2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D2D LDA
    cpu.setA(0x8Bu, 16);
    goto L_848D30;
L_848D30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D30u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D30u, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D30 STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_848D33;
L_848D33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D33u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D33u, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848D33 JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8D36u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8D37u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x848D33u); }
    goto L_848D37;
L_848D37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D37u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D37u,0x848D37u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D37u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D37u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $848D37 PHB
    cpu.push("PHB", hw);
    goto L_848D38;
L_848D38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D38u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D38u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D38 LDX
    cpu.setX(0x8000u, 16);
    goto L_848D3B;
L_848D3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D3Bu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D3Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D3B LDY
    cpu.setY(0x4000u, 16);
    goto L_848D3E;
L_848D3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D3Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D3Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xBDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D3E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xBDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848D40;
L_848D40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D40u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D40u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D40 DEC
    cpu.decReg('A');
    goto L_848D41;
L_848D41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D41u,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0x8D41u, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $848D41 MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_848D44;
L_848D44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D44u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D44u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $848D44 PLB
    cpu.pop("PLB", hw);
    goto L_848D45;
L_848D45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D45u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D45u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D45 LDA
    cpu.setA(0x9064u, 16);
    goto L_848D48;
L_848D48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D48u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D48u, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D48 STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_848D4B;
L_848D4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D4Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D4Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D4B LDA
    cpu.setA(0x89u, 16);
    goto L_848D4E;
L_848D4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D4Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D4Eu, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D4E STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_848D51;
L_848D51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D51u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D51u, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848D51 JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8D54u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8D55u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x848D51u); }
    goto L_848D55;
L_848D55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D55u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D55u,0x848D55u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D55u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D55u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $848D55 PHB
    cpu.push("PHB", hw);
    goto L_848D56;
L_848D56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D56u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D56u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D56u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D56 LDX
    cpu.setX(0x8000u, 16);
    goto L_848D59;
L_848D59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D59u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D59u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D59 LDY
    cpu.setY(0x6000u, 16);
    goto L_848D5C;
L_848D5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D5Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D5Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xBDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D5C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xBDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848D5E;
L_848D5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D5Eu,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D5Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D5E DEC
    cpu.decReg('A');
    goto L_848D5F;
L_848D5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D5Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D5Fu,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0x8D5Fu, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $848D5F MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_848D62;
L_848D62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D62u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D62u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D62u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $848D62 PLB
    cpu.pop("PLB", hw);
    goto L_848D63;
L_848D63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D63u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D63u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D63u, 6u, 3u, cpu.address("abs", 0x94D7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848D63 JSR -> $8494D7 stack real
    { cpu.push16Value(hw,0x8D65u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8D66u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x94D7u), 0x848D63u); }
    goto L_848D66;
L_848D66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D66u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D66u,0x848D66u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D66u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D66u, 6u, 3u, cpu.address("abs", 0x958Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848D66 JSR -> $84958B stack real
    { cpu.push16Value(hw,0x8D68u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8D69u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x958Bu), 0x848D66u); }
    goto L_848D69;
L_848D69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D69u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D69u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D69u, 6u, 3u, cpu.address("abs", 0x977Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848D69 JSR -> $84977C stack real
    { cpu.push16Value(hw,0x8D6Bu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8D6Cu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x977Cu), 0x848D69u); }
    goto L_848D6C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D69u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D69u, 6u, 3u, cpu.address("abs", 0x977Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848D69 JSR -> $84977C stack real
    { cpu.push16Value(hw,0x8D6Bu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8D6Cu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x977Cu), 0x848D69u); }
    goto L_848D6C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D69u,0x848D69u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848D6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D6Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D6Cu,0x848D6Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D6Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D6Cu, 5u, 3u, cpu.address("abs", 0x0629u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D6C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x629u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848D6F;
L_848D6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D6Fu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D6Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D6F BIT
    cpu.bit(0x1u, true);
    goto L_848D72;
L_848D72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D72u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D72u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D72 BEQ -> $848D77
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_848D77; }
    goto L_848D74;
L_848D74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D74u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D74u, 6u, 3u, cpu.address("abs", 0x9691u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848D74 JSR -> $849691 stack real
    { cpu.push16Value(hw,0x8D76u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8D77u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9691u), 0x848D74u); }
    goto L_848D77;
L_848D77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D77u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D77u,0x848D77u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D77u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D77u, 5u, 3u, cpu.address("abs", 0x062Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D77 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848D7A;
L_848D7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Au,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D7A BIT
    cpu.bit(0x1u, true);
    goto L_848D7D;
L_848D7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D7D BNE -> $848D84
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_848D84; }
    goto L_848D7F;
L_848D7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Fu, 6u, 3u, cpu.address("abs", 0x91A6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848D7F JSR -> $8491A6 stack real
    { cpu.push16Value(hw,0x8D81u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8D82u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x91A6u), 0x848D7Fu); }
    goto L_848D82;
L_848D82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D82u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D82u,0x848D82u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D82u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D82u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D82 BRA -> $848D92
    goto L_848D92;
L_848D84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D84u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D84u, 5u, 3u, cpu.address("abs", 0x06FDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D84 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x6FDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848D87;
L_848D87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D87u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D87u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D87 BIT
    cpu.bit(0x1u, true);
    goto L_848D8A;
L_848D8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D8A BEQ -> $848D8F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_848D8F; }
    goto L_848D8C;
L_848D8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Cu, 6u, 3u, cpu.address("abs", 0x96F7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848D8C JSR -> $8496F7 stack real
    { cpu.push16Value(hw,0x8D8Eu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8D8Fu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x96F7u), 0x848D8Cu); }
    goto L_848D8F;
L_848D8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D8Fu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D8Fu,0x848D8Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Fu, 6u, 3u, cpu.address("abs", 0x934Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848D8F JSR -> $84934B stack real
    { cpu.push16Value(hw,0x8D91u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8D92u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x934Bu), 0x848D8Fu); }
    goto L_848D92;
L_848D92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D92u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D92u,0x848D92u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D92u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D92u, 6u, 3u, cpu.address("abs", 0x93D2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848D92 JSR -> $8493D2 stack real
    { cpu.push16Value(hw,0x8D94u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8D95u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x93D2u), 0x848D92u); }
    goto L_848D95;
L_848D95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D95u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D95u,0x848D95u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D95u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D95u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D95 SEP
    cpu.sep(0x20u);
    goto L_848D97;
L_848D97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D97u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D97u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848D97 LDA
    cpu.setA(0x7Eu, 8);
    goto L_848D99;
L_848D99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D99u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D99u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $848D99 PHA
    cpu.push("PHA", hw);
    goto L_848D9A;
L_848D9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D9Au,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D9Au, 5u, 3u, cpu.address("abs", 0x2800u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848D9A PEA
    cpu.push16Value(hw, 0x2800u);
    goto L_848D9D;
L_848D9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D9Du,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D9Du, 5u, 3u, cpu.address("abs", 0x3000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848D9D PEA
    cpu.push16Value(hw, 0x3000u);
    goto L_848DA0;
L_848DA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DA0u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DA0u, 5u, 3u, cpu.address("abs", 0x0800u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848DA0 PEA
    cpu.push16Value(hw, 0x800u);
    goto L_848DA3;
L_848DA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DA3u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DA3u, 8u, 4u, 0x809B54u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848DA3 JSL -> $809B54 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8DA6u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8DA7u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809B54u, 0x848DA3u); }
    goto L_848DA7;
L_848DA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DA7u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8DA7u,0x848DA7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DA7u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DA7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848DA7 SEP
    cpu.sep(0x20u);
    goto L_848DA9;
L_848DA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DA9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DA9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848DA9 LDA
    cpu.setA(0x7Eu, 8);
    goto L_848DAB;
L_848DAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DABu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DABu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $848DAB PHA
    cpu.push("PHA", hw);
    goto L_848DAC;
L_848DAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DACu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DACu, 5u, 3u, cpu.address("abs", 0x4000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848DAC PEA
    cpu.push16Value(hw, 0x4000u);
    goto L_848DAF;
L_848DAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DAFu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DAFu, 5u, 3u, cpu.address("abs", 0x5000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848DAF PEA
    cpu.push16Value(hw, 0x5000u);
    goto L_848DB2;
L_848DB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB2u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB2u, 5u, 3u, cpu.address("abs", 0x2000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848DB2 PEA
    cpu.push16Value(hw, 0x2000u);
    goto L_848DB5;
L_848DB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB5u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB5u, 8u, 4u, 0x809B54u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848DB5 JSL -> $809B54 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8DB8u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8DB9u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809B54u, 0x848DB5u); }
    goto L_848DB9;
L_848DB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DB9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8DB9u,0x848DB9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB9u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848DB9 SEP
    cpu.sep(0x20u);
    goto L_848DBB;
L_848DBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DBBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DBBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848DBB LDA
    cpu.setA(0x7Eu, 8);
    goto L_848DBD;
L_848DBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DBDu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DBDu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $848DBD PHA
    cpu.push("PHA", hw);
    goto L_848DBE;
L_848DBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DBEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DBEu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DBEu, 5u, 3u, cpu.address("abs", 0x6000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848DBE PEA
    cpu.push16Value(hw, 0x6000u);
    goto L_848DC1;
L_848DC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC1u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC1u, 5u, 3u, cpu.address("abs", 0x4000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848DC1 PEA
    cpu.push16Value(hw, 0x4000u);
    goto L_848DC4;
L_848DC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC4u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC4u, 5u, 3u, cpu.address("abs", 0x0800u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848DC4 PEA
    cpu.push16Value(hw, 0x800u);
    goto L_848DC7;
L_848DC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC7u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC7u, 8u, 4u, 0x809B54u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848DC7 JSL -> $809B54 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8DCAu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8DCBu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809B54u, 0x848DC7u); }
    goto L_848DCB;
L_848DCB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DCBu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8DCBu,0x848DCBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DCBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DCBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848DCB LDA
    cpu.setA(0xAC6Cu, 16);
    goto L_848DCE;
L_848DCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DCEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DCEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DCEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848DCE STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_848DD0;
L_848DD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DD0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848DD0 LDA
    cpu.setA(0x8Au, 16);
    goto L_848DD3;
L_848DD3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DD3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848DD3 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_848DD5;
L_848DD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD5u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848DD5 LDX
    cpu.setX(0x0u, 16);
    goto L_848DD8;
L_848DD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DD8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD8u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848DD8 LDY
    cpu.setY(0x200u, 16);
    goto L_848DDB;
L_848DDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DDBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DDBu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DDBu, 8u, 4u, 0x808BB9u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848DDB JSL -> $808BB9 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8DDEu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8DDFu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808BB9u, 0x848DDBu); }
    goto L_848DDF;
L_848DDF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DDFu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8DDFu,0x848DDFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DDFu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DDFu, 6u, 3u, cpu.address("abs", 0x94B4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848DDF JSR -> $8494B4 stack real
    { cpu.push16Value(hw,0x8DE1u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8DE2u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x94B4u), 0x848DDFu); }
    goto L_848DE2;
L_848DE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DE2u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8DE2u,0x848DE2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848DE2 LDA
    cpu.setA(0x1u, 16);
    goto L_848DE5;
L_848DE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE5u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE5u, 5u, 3u, cpu.address("abs", 0x06E9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848DE5 STA
    hw.write(cpu.address("abs", 0x6E9u), cpu.a, cpu.m8?8:16);
    goto L_848DE8;
L_848DE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE8u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE8u, 5u, 3u, cpu.address("abs", 0x06EBu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848DE8 STZ
    hw.write(cpu.address("abs", 0x6EBu), 0, cpu.m8?8:16);
    goto L_848DEB;
L_848DEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DEBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DEBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DEBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848DEB LDA
    cpu.setA(0x10u, 16);
    goto L_848DEE;
L_848DEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DEEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DEEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848DEE STA
    hw.write(cpu.address("dp", 0x6Fu), cpu.a, cpu.m8?8:16);
    goto L_848DF0;
L_848DF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x71u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848DF0 STA
    hw.write(cpu.address("dp", 0x71u), cpu.a, cpu.m8?8:16);
    goto L_848DF2;
L_848DF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF2u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848DF2 STZ
    hw.write(cpu.address("dp", 0x6Bu), 0, cpu.m8?8:16);
    goto L_848DF4;
L_848DF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF4u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848DF4 STZ
    hw.write(cpu.address("dp", 0x6Du), 0, cpu.m8?8:16);
    goto L_848DF6;
L_848DF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF6u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF6u, 5u, 3u, cpu.address("abs", 0x0658u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848DF6 STZ
    hw.write(cpu.address("abs", 0x658u), 0, cpu.m8?8:16);
    goto L_848DF9;
L_848DF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF9u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF9u, 5u, 3u, cpu.address("abs", 0x065Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848DF9 STZ
    hw.write(cpu.address("abs", 0x65Au), 0, cpu.m8?8:16);
    goto L_848DFC;
L_848DFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DFCu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DFCu, 5u, 3u, cpu.address("abs", 0x065Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848DFC STZ
    hw.write(cpu.address("abs", 0x65Cu), 0, cpu.m8?8:16);
    goto L_848DFF;
L_848DFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DFFu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DFFu, 5u, 3u, cpu.address("abs", 0x065Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848DFF STZ
    hw.write(cpu.address("abs", 0x65Eu), 0, cpu.m8?8:16);
    goto L_848E02;
L_848E02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E02u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E02u, 5u, 3u, cpu.address("abs", 0x0667u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848E02 STZ
    hw.write(cpu.address("abs", 0x667u), 0, cpu.m8?8:16);
    goto L_848E05;
L_848E05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E05u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E05u, 5u, 3u, cpu.address("abs", 0x0669u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848E05 STZ
    hw.write(cpu.address("abs", 0x669u), 0, cpu.m8?8:16);
    goto L_848E08;
L_848E08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E08u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E08u, 5u, 3u, cpu.address("abs", 0x0082u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848E08 STZ
    hw.write(cpu.address("abs", 0x82u), 0, cpu.m8?8:16);
    goto L_848E0B;
L_848E0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E0Bu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E0Bu, 5u, 3u, cpu.address("abs", 0x0084u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848E0B STZ
    hw.write(cpu.address("abs", 0x84u), 0, cpu.m8?8:16);
    goto L_848E0E;
L_848E0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E0Eu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E0Eu, 8u, 4u, 0x84BC5Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848E0E JSL -> $84BC5D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8E11u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8E12u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84BC5Du, 0x848E0Eu); }
    goto L_848E12;
L_848E12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E12u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8E12u,0x848E12u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E12u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E12u, 5u, 3u, cpu.address("abs", 0x062Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848E12 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848E15;
L_848E15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E15u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E15u, 6u, 3u, cpu.address("abs", 0x90E7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848E15 JSR -> $8490E7 stack real
    { cpu.push16Value(hw,0x8E17u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8E18u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x90E7u), 0x848E15u); }
    goto L_848E18;
L_848E18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E18u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8E18u,0x848E18u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E18u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E18u, 6u, 3u, cpu.address("abs", 0x9145u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848E18 JSR -> $849145 stack real
    { cpu.push16Value(hw,0x8E1Au); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8E1Bu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9145u), 0x848E18u); }
    goto L_848E1B;
L_848E1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E1Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8E1Bu,0x848E1Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E1Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E1Bu, 5u, 3u, cpu.address("abs", 0x0629u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848E1B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x629u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848E1E;
L_848E1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E1Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E1Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848E1E AND
    cpu.logicAnd(0x1u);
    goto L_848E21;
L_848E21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E21u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E21u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848E21 BNE -> $848E32
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_848E32; }
    goto L_848E23;
L_848E23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E23u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E23u, 5u, 3u, cpu.address("abs", 0x062Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848E23 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848E26;
L_848E26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E26u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E26u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848E26 AND
    cpu.logicAnd(0x1u);
    goto L_848E29;
L_848E29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E29u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E29u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848E29 ASL
    cpu.aslA();
    goto L_848E2A;
L_848E2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E2Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E2Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848E2A STA
    hw.write(cpu.address("dp", 0x61u), cpu.a, cpu.m8?8:16);
    goto L_848E2C;
L_848E2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E2Cu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E2Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848E2C TAX
    cpu.transfer("TAX");
    goto L_848E2D;
L_848E2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E2Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E2Du, 6u, 3u, cpu.address("abs", 0x8EB8u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848E2D JSR -> $848EB8 stack real
    { cpu.push16Value(hw,0x8E2Fu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8E30u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8EB8u), 0x848E2Du); }
    goto L_848E30;
L_848E30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E30u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8E30u,0x848E30u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E30u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E30u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848E30 BRA -> $848E4C
    goto L_848E4C;
L_848E32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E32u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E32u, 5u, 3u, cpu.address("abs", 0x062Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848E32 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848E35;
L_848E35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E35u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E35u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848E35 AND
    cpu.logicAnd(0x1u);
    goto L_848E38;
L_848E38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E38u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E38u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848E38 CLC
    cpu.setFlag('C', false);
    goto L_848E39;
L_848E39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E39u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E39u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848E39 ADC
    cpu.adc(0x2u);
    goto L_848E3C;
L_848E3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E3Cu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E3Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848E3C ASL
    cpu.aslA();
    goto L_848E3D;
L_848E3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E3Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E3Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848E3D STA
    hw.write(cpu.address("dp", 0x61u), cpu.a, cpu.m8?8:16);
    goto L_848E3F;
L_848E3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E3Fu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E3Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848E3F TAX
    cpu.transfer("TAX");
    goto L_848E40;
L_848E40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E40u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E40u, 6u, 3u, cpu.address("abs", 0x8EB8u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848E40 JSR -> $848EB8 stack real
    { cpu.push16Value(hw,0x8E42u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8E43u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8EB8u), 0x848E40u); }
    goto L_848E43;
L_848E43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E43u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8E43u,0x848E43u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E43u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E43u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848E43 TXA
    cpu.transfer("TXA");
    goto L_848E44;
L_848E44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E44u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E44u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848E44 CLC
    cpu.setFlag('C', false);
    goto L_848E45;
L_848E45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E45u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E45u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848E45 ADC
    cpu.adc(0x4u);
    goto L_848E48;
L_848E48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E48u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E48u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848E48 TAX
    cpu.transfer("TAX");
    goto L_848E49;
L_848E49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E49u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E49u, 6u, 3u, cpu.address("abs", 0x8EB8u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848E49 JSR -> $848EB8 stack real
    { cpu.push16Value(hw,0x8E4Bu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8E4Cu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8EB8u), 0x848E49u); }
    goto L_848E4C;
L_848E4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E4Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8E4Cu,0x848E4Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E4Cu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E4Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848E4C LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x61u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_848E4E;
L_848E4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E4Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E4Eu, 5u + 1u, 3u, cpu.address("absx", 0x064Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848E4E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x64Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848E51;
L_848E51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E51u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E51u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848E51 TAX
    cpu.transfer("TAX");
    goto L_848E52;
L_848E52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E52u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E52u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848E52 SEP
    cpu.sep(0x20u);
    goto L_848E54;
L_848E54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E54u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E54u, 4u, 3u, cpu.address("abs", 0x0629u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848E54 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x629u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848E57;
L_848E57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E57u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E57u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848E57 BIT
    cpu.bit(0x1u, true);
    goto L_848E59;
L_848E59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E59u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E59u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848E59 BNE -> $848E6B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_848E6B; }
    goto L_848E5B;
L_848E5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E5Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E5Bu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E5Bu, 5u, 4u, ((0x9E9564u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848E5B LDA
    cpu.loadA(hw.readW(((0x9E9564u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848E5F;
L_848E5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E5Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E5Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E5Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848E5F BEQ -> $848E7B
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_848E7B; }
    goto L_848E61;
L_848E61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E61u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E61u, 8u, 4u, 0x80A6BDu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848E61 JSL -> $80A6BD stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8E64u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8E65u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6BDu, 0x848E61u); }
    goto L_848E65;
L_848E65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E65u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8E65u,0x848E65u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E65u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E65u, 8u, 4u, 0x80A6A5u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848E65 JSL -> $80A6A5 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8E68u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8E69u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6A5u, 0x848E65u); }
    goto L_848E69;
L_848E69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E69u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8E69u,0x848E69u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E69u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E69u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848E69 BRA -> $848E7F
    goto L_848E7F;
L_848E6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E6Bu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E6Bu, 5u, 4u, ((0x9E9569u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848E6B LDA
    cpu.loadA(hw.readW(((0x9E9569u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848E6F;
L_848E6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E6Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E6Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848E6F BEQ -> $848E7B
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_848E7B; }
    goto L_848E71;
L_848E71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E71u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E71u, 8u, 4u, 0x80A6BDu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848E71 JSL -> $80A6BD stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8E74u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8E75u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6BDu, 0x848E71u); }
    goto L_848E75;
L_848E75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E75u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8E75u,0x848E75u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E75u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E75u, 8u, 4u, 0x80A6A5u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848E75 JSL -> $80A6A5 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8E78u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8E79u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6A5u, 0x848E75u); }
    goto L_848E79;
L_848E79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E79u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8E79u,0x848E79u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E79u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E79u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848E79 BRA -> $848E7F
    goto L_848E7F;
L_848E7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E7Bu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E7Bu, 8u, 4u, 0x80A5D1u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848E7B JSL -> $80A5D1 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8E7Eu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8E7Fu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A5D1u, 0x848E7Bu); }
    goto L_848E7F;
L_848E7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E7Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8E7Fu,0x848E7Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E7Fu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E7Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848E7F SEP
    cpu.sep(0x20u);
    goto L_848E81;
L_848E81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E81u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E81u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848E81 LDA
    cpu.setA(0x13u, 8);
    goto L_848E83;
L_848E83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E83u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E83u, 4u, 3u, cpu.address("abs", 0x2101u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848E83 STA
    hw.write(cpu.address("abs", 0x2101u), cpu.a, cpu.m8?8:16);
    goto L_848E86;
L_848E86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E86u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E86u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848E86 LDA
    cpu.setA(0x53u, 8);
    goto L_848E88;
L_848E88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E88u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E88u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E88u, 4u, 3u, cpu.address("abs", 0x2108u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848E88 STA
    hw.write(cpu.address("abs", 0x2108u), cpu.a, cpu.m8?8:16);
    goto L_848E8B;
L_848E8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E8Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E8Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848E8B LDA
    cpu.setA(0x1u, 8);
    goto L_848E8D;
L_848E8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E8Du,cpu,0x0Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E8Du, 6u, 3u, cpu.address("abs", 0x018Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848E8D TSB
    cpu.tsb(hw, cpu.address("abs", 0x18Du), cpu.m8?8:16);
    goto L_848E90;
L_848E90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E90u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E90u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E90u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848E90 STZ
    hw.write(cpu.address("dp", 0x49u), 0, cpu.m8?8:16);
    goto L_848E92;
L_848E92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E92u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E92u, 4u, 3u, cpu.address("abs", 0x0660u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848E92 STZ
    hw.write(cpu.address("abs", 0x660u), 0, cpu.m8?8:16);
    goto L_848E95;
L_848E95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E95u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E95u, 4u, 3u, cpu.address("abs", 0x0662u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848E95 STZ
    hw.write(cpu.address("abs", 0x662u), 0, cpu.m8?8:16);
    goto L_848E98;
L_848E98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E98u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E98u, 4u, 3u, cpu.address("abs", 0x0657u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848E98 STZ
    hw.write(cpu.address("abs", 0x657u), 0, cpu.m8?8:16);
    goto L_848E9B;
L_848E9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E9Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E9Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848E9B LDA
    cpu.setA(0x2u, 8);
    goto L_848E9D;
L_848E9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E9Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E9Du, 4u, 3u, cpu.address("abs", 0x2130u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848E9D STA
    hw.write(cpu.address("abs", 0x2130u), cpu.a, cpu.m8?8:16);
    goto L_848EA0;
L_848EA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EA0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EA0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848EA0 LDA
    cpu.setA(0x82u, 8);
    goto L_848EA2;
L_848EA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EA2u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EA2u, 4u, 3u, cpu.address("abs", 0x2131u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848EA2 STA
    hw.write(cpu.address("abs", 0x2131u), cpu.a, cpu.m8?8:16);
    goto L_848EA5;
L_848EA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EA5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EA5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848EA5 LDA
    cpu.setA(0xC1u, 8);
    goto L_848EA7;
L_848EA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EA7u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EA7u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848EA7 XBA
    cpu.xba();
    goto L_848EA8;
L_848EA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EA8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EA8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848EA8 LDA
    cpu.setA(0x0u, 8);
    goto L_848EAA;
L_848EAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EAAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EAAu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EAAu, 8u, 4u, 0x8086F4u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848EAA JSL -> $8086F4 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8EADu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8EAEu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8086F4u, 0x848EAAu); }
    goto L_848EAE;
L_848EAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EAEu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8EAEu,0x848EAEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EAEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EAEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848EAE LDA
    cpu.setA(0xC1u, 8);
    goto L_848EB0;
L_848EB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EB0u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EB0u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848EB0 XBA
    cpu.xba();
    goto L_848EB1;
L_848EB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EB1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EB1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848EB1 LDA
    cpu.setA(0xF5u, 8);
    goto L_848EB3;
L_848EB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EB3u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EB3u, 8u, 4u, 0x808700u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848EB3 JSL -> $808700 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8EB6u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8EB7u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808700u, 0x848EB3u); }
    goto L_848EB7;
L_848EB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EB7u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8EB7u,0x848EB7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EB7u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EB7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848EB7 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x848EB7u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848EB7u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_8497E4_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8497E4u: goto L_8497E4;
    case 0x8497E6u: goto L_8497E6;
    case 0x8497E9u: goto L_8497E9;
    case 0x8497ECu: goto L_8497EC;
    case 0x8497EFu: goto L_8497EF;
    case 0x8497F1u: goto L_8497F1;
    case 0x8497F4u: goto L_8497F4;
    case 0x8497F6u: goto L_8497F6;
    case 0x8497F9u: goto L_8497F9;
    case 0x8497FBu: goto L_8497FB;
    case 0x8497FFu: goto L_8497FF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8497E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97E4u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97E4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497E4 REP
    cpu.rep(0x20u);
    goto L_8497E6;
L_8497E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97E6u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97E6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497E6 LDX
    cpu.setX(0x2u, 16);
    goto L_8497E9;
L_8497E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97E9u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97E9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497E9 LDY
    cpu.setY(0x5u, 16);
    goto L_8497EC;
L_8497EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97ECu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97ECu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497EC LDA
    cpu.setA(0x2A88u, 16);
    goto L_8497EF;
L_8497EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97EFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97EFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497EF STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_8497F1;
L_8497F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97F1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97F1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497F1 LDA
    cpu.setA(0x7Eu, 16);
    goto L_8497F4;
L_8497F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97F4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97F4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497F4 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_8497F6;
L_8497F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97F6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97F6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497F6 LDA
    cpu.setA(0x1C00u, 16);
    goto L_8497F9;
L_8497F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97F9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97F9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497F9 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_8497FB;
L_8497FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97FBu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97FBu, 8u, 4u, 0x80A839u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8497FB JSL -> $80A839 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x97FEu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x97FFu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A839u, 0x8497FBu); }
    goto L_8497FF;
L_8497FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97FFu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x97FFu,0x8497FFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97FFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97FFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8497FF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8497FFu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8497FFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_8497E4_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8497E4u: goto L_8497E4;
    case 0x8497E6u: goto L_8497E6;
    case 0x8497E9u: goto L_8497E9;
    case 0x8497ECu: goto L_8497EC;
    case 0x8497EFu: goto L_8497EF;
    case 0x8497F1u: goto L_8497F1;
    case 0x8497F4u: goto L_8497F4;
    case 0x8497F6u: goto L_8497F6;
    case 0x8497F9u: goto L_8497F9;
    case 0x8497FBu: goto L_8497FB;
    case 0x8497FFu: goto L_8497FF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8497E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97E4u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97E4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497E4 REP
    cpu.rep(0x20u);
    goto L_8497E6;
L_8497E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97E6u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97E6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497E6 LDX
    cpu.setX(0x2u, 16);
    goto L_8497E9;
L_8497E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97E9u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97E9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497E9 LDY
    cpu.setY(0x5u, 16);
    goto L_8497EC;
L_8497EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97ECu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97ECu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497EC LDA
    cpu.setA(0x2A88u, 16);
    goto L_8497EF;
L_8497EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97EFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97EFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497EF STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_8497F1;
L_8497F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97F1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97F1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497F1 LDA
    cpu.setA(0x7Eu, 16);
    goto L_8497F4;
L_8497F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97F4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97F4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497F4 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_8497F6;
L_8497F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97F6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97F6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497F6 LDA
    cpu.setA(0x1C00u, 16);
    goto L_8497F9;
L_8497F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97F9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97F9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497F9 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_8497FB;
L_8497FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97FBu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97FBu, 8u, 4u, 0x80A839u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8497FB JSL -> $80A839 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x97FEu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x97FFu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A839u, 0x8497FBu); }
    goto L_8497FF;
L_8497FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97FFu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x97FFu,0x8497FFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97FFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97FFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8497FF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8497FFu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8497FFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_8498AA_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8498AAu: goto L_8498AA;
    case 0x8498ACu: goto L_8498AC;
    case 0x8498AEu: goto L_8498AE;
    case 0x8498B1u: goto L_8498B1;
    case 0x8498B3u: goto L_8498B3;
    case 0x8498B5u: goto L_8498B5;
    case 0x8498B8u: goto L_8498B8;
    case 0x8498BAu: goto L_8498BA;
    case 0x8498BDu: goto L_8498BD;
    case 0x8498BFu: goto L_8498BF;
    case 0x8498C1u: goto L_8498C1;
    case 0x8498C3u: goto L_8498C3;
    case 0x8498C6u: goto L_8498C6;
    case 0x8498C9u: goto L_8498C9;
    case 0x8498CBu: goto L_8498CB;
    case 0x8498CDu: goto L_8498CD;
    case 0x8498CFu: goto L_8498CF;
    case 0x8498D2u: goto L_8498D2;
    case 0x8498D4u: goto L_8498D4;
    case 0x8498D6u: goto L_8498D6;
    case 0x8498D9u: goto L_8498D9;
    case 0x8498DCu: goto L_8498DC;
    case 0x8498DEu: goto L_8498DE;
    case 0x8498E1u: goto L_8498E1;
    case 0x8498E3u: goto L_8498E3;
    case 0x8498E5u: goto L_8498E5;
    case 0x8498E8u: goto L_8498E8;
    case 0x8498EBu: goto L_8498EB;
    case 0x8498EEu: goto L_8498EE;
    case 0x8498F2u: goto L_8498F2;
    case 0x8498F3u: goto L_8498F3;
    case 0x8498F5u: goto L_8498F5;
    case 0x8498F7u: goto L_8498F7;
    case 0x8498F8u: goto L_8498F8;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8498AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98AAu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98AAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498AA REP
    cpu.rep(0x20u);
    goto L_8498AC;
L_8498AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98ACu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98ACu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498AC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8498AE;
L_8498AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98AEu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98AEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498AE BIT
    cpu.bit(0x300u, true);
    goto L_8498B1;
L_8498B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98B1u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98B1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498B1 BNE -> $8498F5
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8498F5; }
    goto L_8498B3;
L_8498B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98B3u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98B3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498B3 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8498B5;
L_8498B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98B5u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98B5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498B5 BIT
    cpu.bit(0x400u, true);
    goto L_8498B8;
L_8498B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98B8u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98B8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498B8 BNE -> $8498C1
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8498C1; }
    goto L_8498BA;
L_8498BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98BAu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98BAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498BA BIT
    cpu.bit(0x800u, true);
    goto L_8498BD;
L_8498BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98BDu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98BDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498BD BNE -> $8498D4
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8498D4; }
    goto L_8498BF;
L_8498BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98BFu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98BFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498BF BRA -> $8498F5
    goto L_8498F5;
L_8498C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98C1u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98C1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498C1 SEP
    cpu.sep(0x20u);
    goto L_8498C3;
L_8498C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98C3u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98C3u, 6u, 3u, cpu.address("abs", 0x062Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498C3 INC
    cpu.incMem(hw, cpu.address("abs", 0x62Cu), cpu.m8?8:16);
    goto L_8498C6;
L_8498C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98C6u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98C6u, 4u, 3u, cpu.address("abs", 0x062Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498C6 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8498C9;
L_8498C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98C9u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98C9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498C9 CMP
    cpu.compareA(0x3u);
    goto L_8498CB;
L_8498CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98CBu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98CBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498CB BCC -> $8498E3
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_8498E3; }
    goto L_8498CD;
L_8498CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98CDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98CDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498CD LDA
    cpu.setA(0x2u, 8);
    goto L_8498CF;
L_8498CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98CFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98CFu, 4u, 3u, cpu.address("abs", 0x062Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498CF STA
    hw.write(cpu.address("abs", 0x62Cu), cpu.a, cpu.m8?8:16);
    goto L_8498D2;
L_8498D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98D2u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98D2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498D2 BRA -> $8498F5
    goto L_8498F5;
L_8498D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98D4u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98D4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498D4 SEP
    cpu.sep(0x20u);
    goto L_8498D6;
L_8498D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98D6u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98D6u, 6u, 3u, cpu.address("abs", 0x062Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498D6 DEC
    cpu.decMem(hw, cpu.address("abs", 0x62Cu), cpu.m8?8:16);
    goto L_8498D9;
L_8498D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98D9u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98D9u, 4u, 3u, cpu.address("abs", 0x062Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498D9 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8498DC;
L_8498DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98DCu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98DCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498DC BPL -> $8498E3
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_8498E3; }
    goto L_8498DE;
L_8498DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98DEu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98DEu, 4u, 3u, cpu.address("abs", 0x062Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498DE STZ
    hw.write(cpu.address("abs", 0x62Cu), 0, cpu.m8?8:16);
    goto L_8498E1;
L_8498E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98E1u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98E1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498E1 BRA -> $8498F5
    goto L_8498F5;
L_8498E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98E3u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98E3u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98E3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498E3 REP
    cpu.rep(0x20u);
    goto L_8498E5;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98E3u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98E3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498E3 REP
    cpu.rep(0x20u);
    goto L_8498E5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x98E3u,0x8498E3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8498E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98E5u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98E5u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98E5u, 5u, 3u, cpu.address("abs", 0x065Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498E5 STZ
    hw.write(cpu.address("abs", 0x65Eu), 0, cpu.m8?8:16);
    goto L_8498E8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98E5u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98E5u, 5u, 3u, cpu.address("abs", 0x065Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498E5 STZ
    hw.write(cpu.address("abs", 0x65Eu), 0, cpu.m8?8:16);
    goto L_8498E8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x98E5u,0x8498E5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8498E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98E8u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98E8u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98E8u, 5u, 3u, cpu.address("abs", 0x06EBu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498E8 STZ
    hw.write(cpu.address("abs", 0x6EBu), 0, cpu.m8?8:16);
    goto L_8498EB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98E8u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98E8u, 5u, 3u, cpu.address("abs", 0x06EBu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498E8 STZ
    hw.write(cpu.address("abs", 0x6EBu), 0, cpu.m8?8:16);
    goto L_8498EB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x98E8u,0x8498E8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8498EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98EBu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98EBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98EBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498EB LDA
    cpu.setA(0x6u, 16);
    goto L_8498EE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98EBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98EBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498EB LDA
    cpu.setA(0x6u, 16);
    goto L_8498EE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x98EBu,0x8498EBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8498EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98EEu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98EEu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98EEu, 8u, 4u, 0x80A6FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8498EE JSL -> $80A6FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x98F1u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x98F2u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6FBu, 0x8498EEu); }
    goto L_8498F2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98EEu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98EEu, 8u, 4u, 0x80A6FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8498EE JSL -> $80A6FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x98F1u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x98F2u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6FBu, 0x8498EEu); }
    goto L_8498F2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x98EEu,0x8498EEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8498F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98F2u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98F2u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98F2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498F2 SEC
    cpu.setFlag('C', true);
    goto L_8498F3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98F2u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98F2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498F2 SEC
    cpu.setFlag('C', true);
    goto L_8498F3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x98F2u,0x8498F2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8498F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98F3u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98F3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498F3 BRA -> $8498F8
    goto L_8498F8;
L_8498F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98F5u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98F5u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98F5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498F5 REP
    cpu.rep(0x20u);
    goto L_8498F7;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98F5u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98F5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498F5 REP
    cpu.rep(0x20u);
    goto L_8498F7;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98F5u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98F5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498F5 REP
    cpu.rep(0x20u);
    goto L_8498F7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x98F5u,0x8498F5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8498F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98F7u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98F7u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98F7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498F7 CLC
    cpu.setFlag('C', false);
    goto L_8498F8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98F7u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98F7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498F7 CLC
    cpu.setFlag('C', false);
    goto L_8498F8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x98F7u,0x8498F7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8498F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98F8u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98F8u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98F8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8498F8 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8498F8u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8498F8u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98F8u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98F8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8498F8 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8498F8u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8498F8u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x98F8u,0x8498F8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_8498AA_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8498AAu: goto L_8498AA;
    case 0x8498ACu: goto L_8498AC;
    case 0x8498AEu: goto L_8498AE;
    case 0x8498B1u: goto L_8498B1;
    case 0x8498B3u: goto L_8498B3;
    case 0x8498B5u: goto L_8498B5;
    case 0x8498B8u: goto L_8498B8;
    case 0x8498BAu: goto L_8498BA;
    case 0x8498BDu: goto L_8498BD;
    case 0x8498BFu: goto L_8498BF;
    case 0x8498C1u: goto L_8498C1;
    case 0x8498C3u: goto L_8498C3;
    case 0x8498C6u: goto L_8498C6;
    case 0x8498C9u: goto L_8498C9;
    case 0x8498CBu: goto L_8498CB;
    case 0x8498CDu: goto L_8498CD;
    case 0x8498CFu: goto L_8498CF;
    case 0x8498D2u: goto L_8498D2;
    case 0x8498D4u: goto L_8498D4;
    case 0x8498D6u: goto L_8498D6;
    case 0x8498D9u: goto L_8498D9;
    case 0x8498DCu: goto L_8498DC;
    case 0x8498DEu: goto L_8498DE;
    case 0x8498E1u: goto L_8498E1;
    case 0x8498E3u: goto L_8498E3;
    case 0x8498E5u: goto L_8498E5;
    case 0x8498E8u: goto L_8498E8;
    case 0x8498EBu: goto L_8498EB;
    case 0x8498EEu: goto L_8498EE;
    case 0x8498F2u: goto L_8498F2;
    case 0x8498F3u: goto L_8498F3;
    case 0x8498F5u: goto L_8498F5;
    case 0x8498F7u: goto L_8498F7;
    case 0x8498F8u: goto L_8498F8;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8498AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98AAu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98AAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498AA REP
    cpu.rep(0x20u);
    goto L_8498AC;
L_8498AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98ACu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98ACu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498AC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8498AE;
L_8498AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98AEu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98AEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498AE BIT
    cpu.bit(0x300u, true);
    goto L_8498B1;
L_8498B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98B1u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98B1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498B1 BNE -> $8498F5
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8498F5; }
    goto L_8498B3;
L_8498B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98B3u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98B3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498B3 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8498B5;
L_8498B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98B5u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98B5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498B5 BIT
    cpu.bit(0x400u, true);
    goto L_8498B8;
L_8498B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98B8u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98B8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498B8 BNE -> $8498C1
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8498C1; }
    goto L_8498BA;
L_8498BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98BAu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98BAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498BA BIT
    cpu.bit(0x800u, true);
    goto L_8498BD;
L_8498BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98BDu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98BDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498BD BNE -> $8498D4
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8498D4; }
    goto L_8498BF;
L_8498BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98BFu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98BFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498BF BRA -> $8498F5
    goto L_8498F5;
L_8498C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98C1u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98C1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498C1 SEP
    cpu.sep(0x20u);
    goto L_8498C3;
L_8498C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98C3u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98C3u, 6u, 3u, cpu.address("abs", 0x062Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498C3 INC
    cpu.incMem(hw, cpu.address("abs", 0x62Cu), cpu.m8?8:16);
    goto L_8498C6;
L_8498C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98C6u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98C6u, 4u, 3u, cpu.address("abs", 0x062Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498C6 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8498C9;
L_8498C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98C9u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98C9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498C9 CMP
    cpu.compareA(0x3u);
    goto L_8498CB;
L_8498CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98CBu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98CBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498CB BCC -> $8498E3
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_8498E3; }
    goto L_8498CD;
L_8498CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98CDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98CDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498CD LDA
    cpu.setA(0x2u, 8);
    goto L_8498CF;
L_8498CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98CFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98CFu, 4u, 3u, cpu.address("abs", 0x062Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498CF STA
    hw.write(cpu.address("abs", 0x62Cu), cpu.a, cpu.m8?8:16);
    goto L_8498D2;
L_8498D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98D2u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98D2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498D2 BRA -> $8498F5
    goto L_8498F5;
L_8498D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98D4u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98D4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498D4 SEP
    cpu.sep(0x20u);
    goto L_8498D6;
L_8498D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98D6u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98D6u, 6u, 3u, cpu.address("abs", 0x062Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498D6 DEC
    cpu.decMem(hw, cpu.address("abs", 0x62Cu), cpu.m8?8:16);
    goto L_8498D9;
L_8498D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98D9u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98D9u, 4u, 3u, cpu.address("abs", 0x062Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498D9 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8498DC;
L_8498DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98DCu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98DCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498DC BPL -> $8498E3
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_8498E3; }
    goto L_8498DE;
L_8498DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98DEu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98DEu, 4u, 3u, cpu.address("abs", 0x062Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498DE STZ
    hw.write(cpu.address("abs", 0x62Cu), 0, cpu.m8?8:16);
    goto L_8498E1;
L_8498E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98E1u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98E1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498E1 BRA -> $8498F5
    goto L_8498F5;
L_8498E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98E3u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98E3u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98E3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498E3 REP
    cpu.rep(0x20u);
    goto L_8498E5;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98E3u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98E3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498E3 REP
    cpu.rep(0x20u);
    goto L_8498E5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x98E3u,0x8498E3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8498E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98E5u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98E5u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98E5u, 5u, 3u, cpu.address("abs", 0x065Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498E5 STZ
    hw.write(cpu.address("abs", 0x65Eu), 0, cpu.m8?8:16);
    goto L_8498E8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98E5u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98E5u, 5u, 3u, cpu.address("abs", 0x065Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498E5 STZ
    hw.write(cpu.address("abs", 0x65Eu), 0, cpu.m8?8:16);
    goto L_8498E8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x98E5u,0x8498E5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8498E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98E8u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98E8u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98E8u, 5u, 3u, cpu.address("abs", 0x06EBu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498E8 STZ
    hw.write(cpu.address("abs", 0x6EBu), 0, cpu.m8?8:16);
    goto L_8498EB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98E8u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98E8u, 5u, 3u, cpu.address("abs", 0x06EBu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498E8 STZ
    hw.write(cpu.address("abs", 0x6EBu), 0, cpu.m8?8:16);
    goto L_8498EB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x98E8u,0x8498E8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8498EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98EBu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98EBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98EBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498EB LDA
    cpu.setA(0x6u, 16);
    goto L_8498EE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98EBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98EBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498EB LDA
    cpu.setA(0x6u, 16);
    goto L_8498EE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x98EBu,0x8498EBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8498EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98EEu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98EEu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98EEu, 8u, 4u, 0x80A6FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8498EE JSL -> $80A6FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x98F1u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x98F2u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6FBu, 0x8498EEu); }
    goto L_8498F2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98EEu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98EEu, 8u, 4u, 0x80A6FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8498EE JSL -> $80A6FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x98F1u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x98F2u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6FBu, 0x8498EEu); }
    goto L_8498F2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x98EEu,0x8498EEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8498F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98F2u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98F2u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98F2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498F2 SEC
    cpu.setFlag('C', true);
    goto L_8498F3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98F2u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98F2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498F2 SEC
    cpu.setFlag('C', true);
    goto L_8498F3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x98F2u,0x8498F2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8498F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98F3u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98F3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498F3 BRA -> $8498F8
    goto L_8498F8;
L_8498F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98F5u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98F5u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98F5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498F5 REP
    cpu.rep(0x20u);
    goto L_8498F7;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98F5u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98F5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498F5 REP
    cpu.rep(0x20u);
    goto L_8498F7;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98F5u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98F5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498F5 REP
    cpu.rep(0x20u);
    goto L_8498F7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x98F5u,0x8498F5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8498F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98F7u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98F7u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98F7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498F7 CLC
    cpu.setFlag('C', false);
    goto L_8498F8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98F7u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98F7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498F7 CLC
    cpu.setFlag('C', false);
    goto L_8498F8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x98F7u,0x8498F7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8498F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98F8u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98F8u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98F8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8498F8 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8498F8u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8498F8u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98F8u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98F8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8498F8 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8498F8u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8498F8u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x98F8u,0x8498F8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_849C88_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x849C88u: goto L_849C88;
    case 0x849C8Au: goto L_849C8A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_849C88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C88u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C88u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C88u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849C88 REP
    cpu.rep(0x20u);
    goto L_849C8A;
L_849C8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C8Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C8Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849C8A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x849C8Au);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x849C8Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_CA2207_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xCA2207u: goto L_CA2207;
    case 0xCA2209u: goto L_CA2209;
    case 0xCA220Bu: goto L_CA220B;
    case 0xCA220Du: goto L_CA220D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_CA2207:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x2207u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x2207u,cpu,0x71u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x2207u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x80u) & 0xFFFFu), 2u, 0u);
    // $CA2207 ADC
    cpu.adc(hw.readW(cpu.addressDpIndirectY(hw, 0x80u), cpu.m8?8:16));
    goto L_CA2209;
L_CA2209:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x2209u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x2209u,cpu,0x71u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x2209u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x80u) & 0xFFFFu), 2u, 0u);
    // $CA2209 ADC
    cpu.adc(hw.readW(cpu.addressDpIndirectY(hw, 0x80u), cpu.m8?8:16));
    goto L_CA220B;
L_CA220B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x220Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x220Bu,cpu,0x71u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x220Bu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 2u, 0u);
    // $CA220B ADC
    cpu.adc(hw.readW(cpu.addressDpIndirectY(hw, 0x0u), cpu.m8?8:16));
    goto L_CA220D;
L_CA220D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x220Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x220Du,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x220Du, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $CA220D BRK
    hw.partial(0xCA220Du, "BRK"); return;
}

