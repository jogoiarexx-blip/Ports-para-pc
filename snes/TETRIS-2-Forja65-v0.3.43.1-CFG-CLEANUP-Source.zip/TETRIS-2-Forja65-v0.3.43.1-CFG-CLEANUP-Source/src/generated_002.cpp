#include "generated.hpp"
void sub_5F9FDC_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x5F9FDCu: goto L_5F9FDC;
    case 0x5F9FDEu: goto L_5F9FDE;
    case 0x5F9FE1u: goto L_5F9FE1;
    case 0x5F9FE3u: goto L_5F9FE3;
    case 0x5F9FE5u: goto L_5F9FE5;
    case 0x5F9FE9u: goto L_5F9FE9;
    case 0x5F9FEDu: goto L_5F9FED;
    case 0x5F9FF0u: goto L_5F9FF0;
    case 0x5F9FF1u: goto L_5F9FF1;
    case 0x5F9FF5u: goto L_5F9FF5;
    case 0x5F9FF8u: goto L_5F9FF8;
    case 0x5F9FFAu: goto L_5F9FFA;
    case 0x5F9FFCu: goto L_5F9FFC;
    case 0x5F9FFDu: goto L_5F9FFD;
    case 0x5F9FFFu: goto L_5F9FFF;
    case 0x5FA000u: goto L_5FA000;
    case 0x5FA001u: goto L_5FA001;
    case 0x5FA003u: goto L_5FA003;
    case 0x5FA004u: goto L_5FA004;
    case 0x5FA005u: goto L_5FA005;
    case 0x5FA007u: goto L_5FA007;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_5F9FDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FDCu,cpu,0xA3u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FDCu, 5u, 2u, cpu.addressStack(0x11u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $5F9FDC LDA
    cpu.loadA(hw.readW(cpu.addressStack(0x11u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_5F9FDE;
L_5F9FDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FDEu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FDEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $5F9FDE CPY
    cpu.compareY(0x1C0u);
    goto L_5F9FE1;
L_5F9FE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FE1u,cpu,0x06u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FE1u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $5F9FE1 ASL
    cpu.aslMem(hw, cpu.address("dp", 0x1u), cpu.m8?8:16);
    goto L_5F9FE3;
L_5F9FE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FE3u,cpu,0x25u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FE3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $5F9FE3 AND
    cpu.logicAnd(hw.readW(cpu.address("dp", 0x1Bu), cpu.m8?8:16));
    goto L_5F9FE5;
L_5F9FE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FE5u,cpu,0x3Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FE5u, 6u, 4u, ((0x24E73Fu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $5F9FE5 AND
    cpu.logicAnd(hw.readW(((0x24E73Fu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_5F9FE9;
L_5F9FE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FE9u,cpu,0x1Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FE9u, 6u, 4u, ((0x060F1Fu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $5F9FE9 ORA
    cpu.logicOr(hw.readW(((0x60F1Fu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_5F9FED;
L_5F9FED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FEDu,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FEDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $5F9FED ORA
    cpu.logicOr(0x106u);
    goto L_5F9FF0;
L_5F9FF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FF0u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FF0u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $5F9FF0 PLP
    cpu.pop("PLP", hw);
    goto L_5F9FF1;
L_5F9FF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FF1u))return;
  // 4 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FF1u,cpu,0x3Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FF1u, 6u, 4u, ((0x3CECECu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $5F9FF1 AND
    cpu.logicAnd(hw.readW(((0x3CECECu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_5F9FF5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FF1u,cpu,0x3Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FF1u, 6u, 4u, ((0x3CECECu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $5F9FF1 AND
    cpu.logicAnd(hw.readW(((0x3CECECu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_5F9FF5;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FF1u,cpu,0x3Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FF1u, 5u, 4u, ((0x3CECECu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $5F9FF1 AND
    cpu.logicAnd(hw.readW(((0x3CECECu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_5F9FF5;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FF1u,cpu,0x3Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FF1u, 5u, 4u, ((0x3CECECu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $5F9FF1 AND
    cpu.logicAnd(hw.readW(((0x3CECECu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_5F9FF5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9FF1u,0x5F9FF1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_5F9FF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FF5u))return;
  // 4 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FF5u,cpu,0x3Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FF5u, 5u + 1u, 3u, cpu.address("absx", 0x1C1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $5F9FF5 BIT
    cpu.bit(hw.readW(cpu.address("absx", 0x1C1Cu), cpu.m8?8:16), false);
    goto L_5F9FF8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FF5u,cpu,0x3Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FF5u, 5u + ((((0x1C1Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1C1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $5F9FF5 BIT
    cpu.bit(hw.readW(cpu.address("absx", 0x1C1Cu), cpu.m8?8:16), false);
    goto L_5F9FF8;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FF5u,cpu,0x3Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FF5u, 4u + 1u, 3u, cpu.address("absx", 0x1C1Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $5F9FF5 BIT
    cpu.bit(hw.readW(cpu.address("absx", 0x1C1Cu), cpu.m8?8:16), false);
    goto L_5F9FF8;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FF5u,cpu,0x3Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FF5u, 4u + ((((0x1C1Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1C1Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $5F9FF5 BIT
    cpu.bit(hw.readW(cpu.address("absx", 0x1C1Cu), cpu.m8?8:16), false);
    goto L_5F9FF8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9FF5u,0x5F9FF5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_5F9FF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FF8u))return;
  // 4 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FF8u,cpu,0xA1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FF8u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x05u + cpu.x) & 0xFFFFu), 2u, 0u);
    // $5F9FF8 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectX(hw, 0x5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_5F9FFA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FF8u,cpu,0xA1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FF8u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x05u + cpu.x) & 0xFFFFu), 2u, 0u);
    // $5F9FF8 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectX(hw, 0x5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_5F9FFA;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FF8u,cpu,0xA1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FF8u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x05u + cpu.x) & 0xFFFFu), 2u, 0u);
    // $5F9FF8 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectX(hw, 0x5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_5F9FFA;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FF8u,cpu,0xA1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FF8u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x05u + cpu.x) & 0xFFFFu), 2u, 0u);
    // $5F9FF8 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectX(hw, 0x5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_5F9FFA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9FF8u,0x5F9FF8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_5F9FFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FFAu))return;
  // 4 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FFAu,cpu,0xE3u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FFAu, 5u, 2u, cpu.addressStack(0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $5F9FFA SBC
    cpu.sbc(hw.readW(cpu.addressStack(0x1Au), cpu.m8?8:16));
    goto L_5F9FFC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FFAu,cpu,0xE3u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FFAu, 5u, 2u, cpu.addressStack(0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $5F9FFA SBC
    cpu.sbc(hw.readW(cpu.addressStack(0x1Au), cpu.m8?8:16));
    goto L_5F9FFC;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FFAu,cpu,0xE3u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FFAu, 4u, 2u, cpu.addressStack(0x1Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $5F9FFA SBC
    cpu.sbc(hw.readW(cpu.addressStack(0x1Au), cpu.m8?8:16));
    goto L_5F9FFC;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FFAu,cpu,0xE3u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FFAu, 4u, 2u, cpu.addressStack(0x1Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $5F9FFA SBC
    cpu.sbc(hw.readW(cpu.addressStack(0x1Au), cpu.m8?8:16));
    goto L_5F9FFC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9FFAu,0x5F9FFAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_5F9FFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FFCu))return;
  // 4 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FFCu,cpu,0xD8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FFCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $5F9FFC CLD
    cpu.setFlag('D', false);
    goto L_5F9FFD;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FFCu,cpu,0xD8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FFCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $5F9FFC CLD
    cpu.setFlag('D', false);
    goto L_5F9FFD;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FFCu,cpu,0xD8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FFCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $5F9FFC CLD
    cpu.setFlag('D', false);
    goto L_5F9FFD;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FFCu,cpu,0xD8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FFCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $5F9FFC CLD
    cpu.setFlag('D', false);
    goto L_5F9FFD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9FFCu,0x5F9FFCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_5F9FFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FFDu))return;
  // 4 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FFDu,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FFDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $5F9FFD ORA
    cpu.logicOr(0xF04u);
    goto L_5FA000;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FFDu,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FFDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $5F9FFD ORA
    cpu.logicOr(0xF04u);
    goto L_5FA000;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FFDu,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FFDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $5F9FFD ORA
    cpu.logicOr(0x4u);
    goto L_5F9FFF;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FFDu,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FFDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $5F9FFD ORA
    cpu.logicOr(0x4u);
    goto L_5F9FFF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9FFDu,0x5F9FFDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_5F9FFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FFFu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FFFu,cpu,0x0Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FFFu, 5u, 4u, 0x060F08u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $5F9FFF ORA
    cpu.logicOr(hw.readW(0x60F08u, cpu.m8?8:16));
    goto L_5FA003;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FFFu,cpu,0x0Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FFFu, 5u, 4u, 0x060F08u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $5F9FFF ORA
    cpu.logicOr(hw.readW(0x60F08u, cpu.m8?8:16));
    goto L_5FA003;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9FFFu,0x5F9FFFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_5FA000:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA000u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA000u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA000u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $5FA000 PHP
    cpu.push("PHP", hw);
    goto L_5FA001;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA000u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA000u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $5FA000 PHP
    cpu.push("PHP", hw);
    goto L_5FA001;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA000u,0x5FA000u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_5FA001:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA001u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA001u,cpu,0x0Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA001u, 6u, 4u, 0xF8F806u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $5FA001 ORA
    cpu.logicOr(hw.readW(0xF8F806u, cpu.m8?8:16));
    goto L_5FA005;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA001u,cpu,0x0Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA001u, 6u, 4u, 0xF8F806u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $5FA001 ORA
    cpu.logicOr(hw.readW(0xF8F806u, cpu.m8?8:16));
    goto L_5FA005;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA001u,0x5FA001u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_5FA003:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA003u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA003u,cpu,0xF8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA003u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $5FA003 SED
    cpu.setFlag('D', true);
    goto L_5FA004;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA003u,cpu,0xF8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA003u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $5FA003 SED
    cpu.setFlag('D', true);
    goto L_5FA004;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA003u,0x5FA003u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_5FA004:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA004u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA004u,cpu,0xF8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA004u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $5FA004 SED
    cpu.setFlag('D', true);
    goto L_5FA005;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA004u,cpu,0xF8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA004u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $5FA004 SED
    cpu.setFlag('D', true);
    goto L_5FA005;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA004u,0x5FA004u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_5FA005:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA005u))return;
  // 4 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA005u,cpu,0x83u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA005u, 5u, 2u, cpu.addressStack(0x2Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $5FA005 STA
    hw.write(cpu.addressStack(0x2Bu), cpu.a, cpu.m8?8:16);
    goto L_5FA007;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA005u,cpu,0x83u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA005u, 5u, 2u, cpu.addressStack(0x2Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $5FA005 STA
    hw.write(cpu.addressStack(0x2Bu), cpu.a, cpu.m8?8:16);
    goto L_5FA007;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA005u,cpu,0x83u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA005u, 4u, 2u, cpu.addressStack(0x2Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $5FA005 STA
    hw.write(cpu.addressStack(0x2Bu), cpu.a, cpu.m8?8:16);
    goto L_5FA007;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA005u,cpu,0x83u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA005u, 4u, 2u, cpu.addressStack(0x2Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $5FA005 STA
    hw.write(cpu.addressStack(0x2Bu), cpu.a, cpu.m8?8:16);
    goto L_5FA007;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA005u,0x5FA005u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_5FA007:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA007u))return;
  // 4 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA007u,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA007u, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $5FA007 BRK
    hw.partial(0x5FA007u, "BRK"); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA007u,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA007u, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $5FA007 BRK
    hw.partial(0x5FA007u, "BRK"); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA007u,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA007u, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $5FA007 BRK
    hw.partial(0x5FA007u, "BRK"); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA007u,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA007u, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $5FA007 BRK
    hw.partial(0x5FA007u, "BRK"); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA007u,0x5FA007u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_8082A7_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8082A7u: goto L_8082A7;
    case 0x8082A8u: goto L_8082A8;
    case 0x8082AAu: goto L_8082AA;
    case 0x8082ACu: goto L_8082AC;
    case 0x8082AEu: goto L_8082AE;
    case 0x8082B0u: goto L_8082B0;
    case 0x8082B2u: goto L_8082B2;
    case 0x8082B4u: goto L_8082B4;
    case 0x8082B6u: goto L_8082B6;
    case 0x8082B8u: goto L_8082B8;
    case 0x8082BAu: goto L_8082BA;
    case 0x8082BCu: goto L_8082BC;
    case 0x8082BEu: goto L_8082BE;
    case 0x8082C0u: goto L_8082C0;
    case 0x8082C2u: goto L_8082C2;
    case 0x8082C4u: goto L_8082C4;
    case 0x8082C6u: goto L_8082C6;
    case 0x8082C9u: goto L_8082C9;
    case 0x8082CCu: goto L_8082CC;
    case 0x8082CEu: goto L_8082CE;
    case 0x8082D0u: goto L_8082D0;
    case 0x8082D2u: goto L_8082D2;
    case 0x8082D4u: goto L_8082D4;
    case 0x8082D6u: goto L_8082D6;
    case 0x8082D8u: goto L_8082D8;
    case 0x8082DAu: goto L_8082DA;
    case 0x8082DBu: goto L_8082DB;
    case 0x8082DEu: goto L_8082DE;
    case 0x8082E0u: goto L_8082E0;
    case 0x8082E3u: goto L_8082E3;
    case 0x8082E4u: goto L_8082E4;
    case 0x8082E5u: goto L_8082E5;
    case 0x8082E7u: goto L_8082E7;
    case 0x8082E8u: goto L_8082E8;
    case 0x8082E9u: goto L_8082E9;
    case 0x8082EBu: goto L_8082EB;
    case 0x8082EFu: goto L_8082EF;
    case 0x8082F0u: goto L_8082F0;
    case 0x8082F2u: goto L_8082F2;
    case 0x8082F6u: goto L_8082F6;
    case 0x8082F7u: goto L_8082F7;
    case 0x8082F8u: goto L_8082F8;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8082A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82A7u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82A7u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8082A7 PHP
    cpu.push("PHP", hw);
    goto L_8082A8;
L_8082A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82A8u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82A8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082A8 REP
    cpu.rep(0x20u);
    goto L_8082AA;
L_8082AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82AAu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82AAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082AA STZ
    hw.write(cpu.address("dp", 0x7Au), 0, cpu.m8?8:16);
    goto L_8082AC;
L_8082AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82ACu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82ACu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082AC STZ
    hw.write(cpu.address("dp", 0x7Cu), 0, cpu.m8?8:16);
    goto L_8082AE;
L_8082AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82AEu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82AEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082AE STZ
    hw.write(cpu.address("dp", 0x7Eu), 0, cpu.m8?8:16);
    goto L_8082B0;
L_8082B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82B0u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82B0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x80u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082B0 STZ
    hw.write(cpu.address("dp", 0x80u), 0, cpu.m8?8:16);
    goto L_8082B2;
L_8082B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82B2u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82B2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x82u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082B2 STZ
    hw.write(cpu.address("dp", 0x82u), 0, cpu.m8?8:16);
    goto L_8082B4;
L_8082B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82B4u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82B4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x84u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082B4 STZ
    hw.write(cpu.address("dp", 0x84u), 0, cpu.m8?8:16);
    goto L_8082B6;
L_8082B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82B6u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82B6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x86u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082B6 STZ
    hw.write(cpu.address("dp", 0x86u), 0, cpu.m8?8:16);
    goto L_8082B8;
L_8082B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82B8u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82B8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082B8 STZ
    hw.write(cpu.address("dp", 0x88u), 0, cpu.m8?8:16);
    goto L_8082BA;
L_8082BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82BAu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82BAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x92u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082BA STZ
    hw.write(cpu.address("dp", 0x92u), 0, cpu.m8?8:16);
    goto L_8082BC;
L_8082BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82BCu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82BCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082BC STZ
    hw.write(cpu.address("dp", 0x94u), 0, cpu.m8?8:16);
    goto L_8082BE;
L_8082BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82BEu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82BEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082BE SEP
    cpu.sep(0x20u);
    goto L_8082C0;
L_8082C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82C0u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82C0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x78u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082C0 STZ
    hw.write(cpu.address("dp", 0x78u), 0, cpu.m8?8:16);
    goto L_8082C2;
L_8082C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82C2u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82C2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082C2 STZ
    hw.write(cpu.address("dp", 0x77u), 0, cpu.m8?8:16);
    goto L_8082C4;
L_8082C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82C4u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82C4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082C4 STZ
    hw.write(cpu.address("dp", 0x75u), 0, cpu.m8?8:16);
    goto L_8082C6;
L_8082C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82C6u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82C6u, 4u, 3u, cpu.address("abs", 0x0128u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082C6 STZ
    hw.write(cpu.address("abs", 0x128u), 0, cpu.m8?8:16);
    goto L_8082C9;
L_8082C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82C9u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82C9u, 4u, 3u, cpu.address("abs", 0x012Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082C9 STZ
    hw.write(cpu.address("abs", 0x12Eu), 0, cpu.m8?8:16);
    goto L_8082CC;
L_8082CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82CCu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82CCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082CC STZ
    hw.write(cpu.address("dp", 0x49u), 0, cpu.m8?8:16);
    goto L_8082CE;
L_8082CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82CEu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82CEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x47u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082CE STZ
    hw.write(cpu.address("dp", 0x47u), 0, cpu.m8?8:16);
    goto L_8082D0;
L_8082D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82D0u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82D0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082D0 STZ
    hw.write(cpu.address("dp", 0x4Au), 0, cpu.m8?8:16);
    goto L_8082D2;
L_8082D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82D2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82D2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x46u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082D2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x46u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8082D4;
L_8082D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82D4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82D4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082D4 AND
    cpu.logicAnd(0x7Fu);
    goto L_8082D6;
L_8082D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82D6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82D6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x46u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082D6 STA
    hw.write(cpu.address("dp", 0x46u), cpu.a, cpu.m8?8:16);
    goto L_8082D8;
L_8082D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82D8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82D8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x48u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082D8 STA
    hw.write(cpu.address("dp", 0x48u), cpu.a, cpu.m8?8:16);
    goto L_8082DA;
L_8082DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82DAu,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82DAu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8082DA PHK
    cpu.push("PHK", hw);
    goto L_8082DB;
L_8082DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82DBu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82DBu, 5u, 3u, cpu.address("abs", 0x82F8u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8082DB PEA
    cpu.push16Value(hw, 0x82F8u);
    goto L_8082DE;
L_8082DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82DEu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82DEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082DE REP
    cpu.rep(0x20u);
    goto L_8082E0;
L_8082E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82E0u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82E0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082E0 AND
    cpu.logicAnd(0xFFu);
    goto L_8082E3;
L_8082E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82E3u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82E3u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8082E3 PHA
    cpu.push("PHA", hw);
    goto L_8082E4;
L_8082E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82E4u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82E4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082E4 ASL
    cpu.aslA();
    goto L_8082E5;
L_8082E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82E5u,cpu,0x63u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82E5u, 5u, 2u, cpu.addressStack(0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082E5 ADC
    cpu.adc(hw.readW(cpu.addressStack(0x1u), cpu.m8?8:16));
    goto L_8082E7;
L_8082E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82E7u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82E7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082E7 TAX
    cpu.transfer("TAX");
    goto L_8082E8;
L_8082E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82E8u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82E8u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8082E8 PLA
    cpu.pop("PLA", hw);
    goto L_8082E9;
L_8082E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82E9u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82E9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082E9 SEP
    cpu.sep(0x20u);
    goto L_8082EB;
L_8082EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82EBu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82EBu, 5u, 4u, ((0x8082FDu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082EB LDA
    cpu.loadA(hw.readW(((0x8082FDu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8082EF;
L_8082EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82EFu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82EFu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8082EF PHA
    cpu.push("PHA", hw);
    goto L_8082F0;
L_8082F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82F0u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82F0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082F0 REP
    cpu.rep(0x20u);
    goto L_8082F2;
L_8082F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82F2u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82F2u, 6u, 4u, ((0x8082FBu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082F2 LDA
    cpu.loadA(hw.readW(((0x8082FBu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8082F6;
L_8082F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82F6u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82F6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082F6 DEC
    cpu.decReg('A');
    goto L_8082F7;
L_8082F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82F7u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82F7u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8082F7 PHA
    cpu.push("PHA", hw);
    goto L_8082F8;
L_8082F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82F8u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82F8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8082F8 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8082F8u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8082F8u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80846E_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80842Au: goto L_80842A;
    case 0x80846Eu: goto L_80846E;
    case 0x808470u: goto L_808470;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80842A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x842Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x842Au,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x842Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80842A RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80842Au);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80842Au,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80846E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x846Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x846Eu,cpu,0xB3u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x846Eu, 7u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.s + 0x84u) & 0xFFFFu), 2u, 0u);
    // $80846E LDA
    cpu.loadA(hw.readW(cpu.addressStackIndirectY(hw, 0x84u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808470;
L_808470:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8470u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8470u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8470u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808470 BRA -> $80842A
    goto L_80842A;
}

void sub_8084B4_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80802Cu: goto L_80802C;
    case 0x80802Fu: goto L_80802F;
    case 0x808030u: goto L_808030;
    case 0x808031u: goto L_808031;
    case 0x808033u: goto L_808033;
    case 0x808036u: goto L_808036;
    case 0x808039u: goto L_808039;
    case 0x80803Au: goto L_80803A;
    case 0x80803Bu: goto L_80803B;
    case 0x80803Du: goto L_80803D;
    case 0x808040u: goto L_808040;
    case 0x808041u: goto L_808041;
    case 0x808043u: goto L_808043;
    case 0x808046u: goto L_808046;
    case 0x808049u: goto L_808049;
    case 0x80804Bu: goto L_80804B;
    case 0x80804Eu: goto L_80804E;
    case 0x808050u: goto L_808050;
    case 0x808053u: goto L_808053;
    case 0x808055u: goto L_808055;
    case 0x808057u: goto L_808057;
    case 0x808059u: goto L_808059;
    case 0x80805Bu: goto L_80805B;
    case 0x80805Fu: goto L_80805F;
    case 0x808061u: goto L_808061;
    case 0x808065u: goto L_808065;
    case 0x808069u: goto L_808069;
    case 0x80806Bu: goto L_80806B;
    case 0x80806Fu: goto L_80806F;
    case 0x808073u: goto L_808073;
    case 0x808076u: goto L_808076;
    case 0x808078u: goto L_808078;
    case 0x80807Bu: goto L_80807B;
    case 0x80807Cu: goto L_80807C;
    case 0x80807Eu: goto L_80807E;
    case 0x808080u: goto L_808080;
    case 0x808083u: goto L_808083;
    case 0x808085u: goto L_808085;
    case 0x808089u: goto L_808089;
    case 0x80808Du: goto L_80808D;
    case 0x808090u: goto L_808090;
    case 0x808093u: goto L_808093;
    case 0x808095u: goto L_808095;
    case 0x808099u: goto L_808099;
    case 0x80809Du: goto L_80809D;
    case 0x8080A1u: goto L_8080A1;
    case 0x8080A3u: goto L_8080A3;
    case 0x8080A6u: goto L_8080A6;
    case 0x8080A8u: goto L_8080A8;
    case 0x8080AAu: goto L_8080AA;
    case 0x8080ABu: goto L_8080AB;
    case 0x8080ADu: goto L_8080AD;
    case 0x8080AEu: goto L_8080AE;
    case 0x8084B4u: goto L_8084B4;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80802C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x802Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x802Cu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x802Cu, 6u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80802C STZ
    hw.write(cpu.address("absx", 0x0u), 0, cpu.m8?8:16);
    goto L_80802F;
L_80802F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x802Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x802Fu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x802Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80802F DEX
    cpu.decReg('X');
    goto L_808030;
L_808030:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8030u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8030u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8030u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808030 DEX
    cpu.decReg('X');
    goto L_808031;
L_808031:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8031u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8031u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8031u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808031 BPL -> $80802C
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80802C; }
    goto L_808033;
L_808033:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8033u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8033u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8033u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808033 LDX
    cpu.setX(0x7FEu, 16);
    goto L_808036;
L_808036:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8036u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8036u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8036u, 6u, 3u, cpu.address("absx", 0x1800u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808036 STZ
    hw.write(cpu.address("absx", 0x1800u), 0, cpu.m8?8:16);
    goto L_808039;
L_808039:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8039u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8039u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8039u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808039 DEX
    cpu.decReg('X');
    goto L_80803A;
L_80803A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x803Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x803Au,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x803Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80803A DEX
    cpu.decReg('X');
    goto L_80803B;
L_80803B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x803Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x803Bu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x803Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80803B BPL -> $808036
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_808036; }
    goto L_80803D;
L_80803D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x803Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x803Du,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x803Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80803D LDX
    cpu.setX(0x1FF0u, 16);
    goto L_808040;
L_808040:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8040u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8040u,cpu,0x9Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8040u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808040 TXS
    cpu.transfer("TXS");
    goto L_808041;
L_808041:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8041u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8041u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8041u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808041 REP
    cpu.rep(0x20u);
    goto L_808043;
L_808043:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8043u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8043u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8043u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808043 LDA
    cpu.setA(0x1u, 16);
    goto L_808046;
L_808046:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8046u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8046u,cpu,0x0Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8046u, 8u, 3u, cpu.address("abs", 0x019Fu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808046 TSB
    cpu.tsb(hw, cpu.address("abs", 0x19Fu), cpu.m8?8:16);
    goto L_808049;
L_808049:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8049u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8049u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8049u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808049 SEP
    cpu.sep(0x20u);
    goto L_80804B;
L_80804B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x804Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x804Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x804Bu, 6u, 3u, cpu.address("abs", 0x8111u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80804B JSR -> $808111 stack real
    { cpu.push16Value(hw,0x804Du); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x804Eu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8111u), 0x80804Bu); }
    goto L_80804E;
L_80804E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x804Eu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x804Eu,0x80804Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x804Eu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x804Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80804E SEP
    cpu.sep(0x20u);
    goto L_808050;
L_808050:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8050u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8050u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8050u, 4u, 3u, cpu.address("abs", 0x213Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808050 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x213Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808053;
L_808053:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8053u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8053u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8053u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808053 BIT
    cpu.bit(0x10u, true);
    goto L_808055;
L_808055:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8055u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8055u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8055u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808055 BEQ -> $80805B
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80805B; }
    goto L_808057;
L_808057:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8057u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8057u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8057u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808057 LDA
    cpu.setA(0x83u, 8);
    goto L_808059;
L_808059:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8059u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8059u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8059u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808059 BRA -> $80805F
    goto L_80805F;
L_80805B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x805Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x805Bu,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x805Bu, 5u, 4u, 0x808000u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80805B LDA
    cpu.loadA(hw.readW(0x808000u, cpu.m8?8:16), cpu.m8?8:16);
    goto L_80805F;
L_80805F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x805Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x805Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x805Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x46u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80805F STA
    hw.write(cpu.address("dp", 0x46u), cpu.a, cpu.m8?8:16);
    goto L_808061;
L_808061:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8061u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8061u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8061u, 8u, 4u, 0x808580u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808061 JSL -> $808580 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8064u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8065u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808580u, 0x808061u); }
    goto L_808065;
L_808065:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8065u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8065u,0x808065u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8065u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8065u, 8u, 4u, 0x82BB9Au, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808065 JSL -> $82BB9A stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8068u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8069u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82BB9Au, 0x808065u); }
    goto L_808069;
L_808069:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8069u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8069u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8069u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808069 SEP
    cpu.sep(0x24u);
    goto L_80806B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8069u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8069u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808069 SEP
    cpu.sep(0x24u);
    goto L_80806B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8069u,0x808069u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80806B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x806Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x806Bu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x806Bu, 8u, 4u, 0x808556u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80806B JSL -> $808556 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x806Eu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x806Fu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808556u, 0x80806Bu); }
    goto L_80806F;
L_80806F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x806Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x806Fu,0x80806Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x806Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x806Fu, 8u, 4u, 0x808572u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80806F JSL -> $808572 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8072u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8073u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808572u, 0x80806Fu); }
    goto L_808073;
L_808073:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8073u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8073u,0x808073u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8073u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8073u, 4u, 3u, cpu.address("abs", 0x420Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808073 STZ
    hw.write(cpu.address("abs", 0x420Cu), 0, cpu.m8?8:16);
    goto L_808076;
L_808076:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8076u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8076u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8076u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xB4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808076 STZ
    hw.write(cpu.address("dp", 0xB4u), 0, cpu.m8?8:16);
    goto L_808078;
L_808078:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8078u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8078u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8078u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808078 LDX
    cpu.setX(0x1FF0u, 16);
    goto L_80807B;
L_80807B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x807Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x807Bu,cpu,0x9Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x807Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80807B TXS
    cpu.transfer("TXS");
    goto L_80807C;
L_80807C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x807Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x807Cu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x807Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80807C STZ
    hw.write(cpu.address("dp", 0x96u), 0, cpu.m8?8:16);
    goto L_80807E;
L_80807E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x807Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x807Eu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x807Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x97u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80807E STZ
    hw.write(cpu.address("dp", 0x97u), 0, cpu.m8?8:16);
    goto L_808080;
L_808080:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8080u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8080u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8080u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808080 LDX
    cpu.setX(0x200u, 16);
    goto L_808083;
L_808083:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8083u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8083u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8083u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x98u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808083 STX
    hw.write(cpu.address("dp", 0x98u), cpu.x, cpu.x8?8:16);
    goto L_808085;
L_808085:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8085u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8085u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8085u, 8u, 4u, 0x808ADEu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808085 JSL -> $808ADE stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8088u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8089u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808ADEu, 0x808085u); }
    goto L_808089;
L_808089:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8089u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8089u,0x808089u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8089u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8089u, 8u, 4u, 0x808B92u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808089 JSL -> $808B92 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x808Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x808Du,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808B92u, 0x808089u); }
    goto L_80808D;
L_80808D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x808Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x808Du,0x80808Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x808Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x808Du, 6u, 3u, cpu.address("abs", 0x82A7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80808D JSR -> $8082A7 stack real
    { cpu.push16Value(hw,0x808Fu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8090u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x82A7u), 0x80808Du); }
    goto L_808090;
L_808090:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8090u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8090u,0x808090u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8090u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8090u, 6u, 3u, cpu.address("abs", 0x85ADu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808090 JSR -> $8085AD stack real
    { cpu.push16Value(hw,0x8092u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8093u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x85ADu), 0x808090u); }
    goto L_808093;
L_808093:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8093u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8093u,0x808093u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8093u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8093u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808093 STZ
    hw.write(cpu.address("dp", 0x4Bu), 0, cpu.m8?8:16);
    goto L_808095;
L_808095:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8095u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8095u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8095u, 8u, 4u, 0x808547u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808095 JSL -> $808547 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8098u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8099u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808547u, 0x808095u); }
    goto L_808099;
L_808099:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8099u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8099u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8099u, 8u, 4u, 0x808D03u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808099 JSL -> $808D03 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x809Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x809Du,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808D03u, 0x808099u); }
    goto L_80809D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8099u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8099u, 8u, 4u, 0x808D03u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808099 JSL -> $808D03 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x809Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x809Du,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808D03u, 0x808099u); }
    goto L_80809D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8099u,0x808099u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80809D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x809Du))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x809Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x809Du, 8u, 4u, 0x8096A3u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80809D JSL -> $8096A3 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80A0u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80A1u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8096A3u, 0x80809Du); }
    goto L_8080A1;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x809Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x809Du, 8u, 4u, 0x8096A3u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80809D JSL -> $8096A3 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80A0u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80A1u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8096A3u, 0x80809Du); }
    goto L_8080A1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x809Du,0x80809Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8080A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A1u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80A1u,0x8080A1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A1u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080A1 SEP
    cpu.sep(0x20u);
    goto L_8080A3;
L_8080A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A3u, 6u, 3u, cpu.address("abs", 0x83A4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8080A3 JSR -> $8083A4 stack real
    { cpu.push16Value(hw,0x80A5u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80A6u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x83A4u), 0x8080A3u); }
    goto L_8080A6;
L_8080A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A6u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x46u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080A6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x46u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8080A8;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x46u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080A6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x46u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8080A8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80A6u,0x8080A6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8080A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A8u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A8u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080A8 BPL -> $808099
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_808099; }
    goto L_8080AA;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A8u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080A8 BPL -> $808099
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_808099; }
    goto L_8080AA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80A8u,0x8080A8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8080AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80AAu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80AAu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80AAu, 8u, 4u, 0x808556u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8080AA JSL -> $808556 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80ADu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80AEu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808556u, 0x8080AAu); }
    goto L_8080AE;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80AAu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80AAu, 8u, 4u, 0x808556u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8080AA JSL -> $808556 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80ADu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80AEu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808556u, 0x8080AAu); }
    goto L_8080AE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80AAu,0x8080AAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8080AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80ABu,cpu,0x56u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80ABu, 8u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x85u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080AB LSR
    cpu.lsrMem(hw, cpu.address("dpx", 0x85u), cpu.m8?8:16);
    goto L_8080AD;
L_8080AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80ADu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80ADu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080AD BRA -> $80802F
    goto L_80802F;
L_8080AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80AEu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80AEu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80AEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080AE BRA -> $808069
    goto L_808069;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80AEu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80AEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080AE BRA -> $808069
    goto L_808069;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80AEu,0x8080AEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8084B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84B4u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84B4u, 3u, 3u, cpu.address("abs", 0x80ABu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8084B4 JMP -> $8080AB
    goto L_8080AB;
}

void sub_808556_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808556u: goto L_808556;
    case 0x808557u: goto L_808557;
    case 0x808559u: goto L_808559;
    case 0x80855Bu: goto L_80855B;
    case 0x80855Du: goto L_80855D;
    case 0x808560u: goto L_808560;
    case 0x808562u: goto L_808562;
    case 0x808563u: goto L_808563;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808556:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8556u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8556u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8556u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808556 PHP
    cpu.push("PHP", hw);
    goto L_808557;
L_808557:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8557u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8557u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8557u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808557 SEP
    cpu.sep(0x24u);
    goto L_808559;
L_808559:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8559u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8559u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8559u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x73u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808559 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x73u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80855B;
L_80855B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x855Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x855Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x855Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80855B AND
    cpu.logicAnd(0xEu);
    goto L_80855D;
L_80855D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x855Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x855Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x855Du, 4u, 3u, cpu.address("abs", 0x4200u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80855D STA
    hw.write(cpu.address("abs", 0x4200u), cpu.a, cpu.m8?8:16);
    goto L_808560;
L_808560:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8560u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8560u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8560u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x73u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808560 STA
    hw.write(cpu.address("dp", 0x73u), cpu.a, cpu.m8?8:16);
    goto L_808562;
L_808562:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8562u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8562u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8562u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808562 PLP
    cpu.pop("PLP", hw);
    goto L_808563;
L_808563:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8563u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8563u,0x808563u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8563u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8563u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808563 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808563u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x808563u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80870C_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80870Cu: goto L_80870C;
    case 0x80870Eu: goto L_80870E;
    case 0x808710u: goto L_808710;
    case 0x808712u: goto L_808712;
    case 0x808714u: goto L_808714;
    case 0x808716u: goto L_808716;
    case 0x808718u: goto L_808718;
    case 0x80871Au: goto L_80871A;
    case 0x80871Bu: goto L_80871B;
    case 0x80871Du: goto L_80871D;
    case 0x80871Fu: goto L_80871F;
    case 0x808720u: goto L_808720;
    case 0x808722u: goto L_808722;
    case 0x808724u: goto L_808724;
    case 0x808726u: goto L_808726;
    case 0x808728u: goto L_808728;
    case 0x80872Au: goto L_80872A;
    case 0x80872Cu: goto L_80872C;
    case 0x80872Eu: goto L_80872E;
    case 0x808730u: goto L_808730;
    case 0x808732u: goto L_808732;
    case 0x808734u: goto L_808734;
    case 0x808736u: goto L_808736;
    case 0x808738u: goto L_808738;
    case 0x80873Au: goto L_80873A;
    case 0x80873Bu: goto L_80873B;
    case 0x80873Du: goto L_80873D;
    case 0x80873Fu: goto L_80873F;
    case 0x808741u: goto L_808741;
    case 0x808743u: goto L_808743;
    case 0x808745u: goto L_808745;
    case 0x808747u: goto L_808747;
    case 0x808748u: goto L_808748;
    case 0x80874Au: goto L_80874A;
    case 0x80874Cu: goto L_80874C;
    case 0x80874Eu: goto L_80874E;
    case 0x808750u: goto L_808750;
    case 0x808752u: goto L_808752;
    case 0x808754u: goto L_808754;
    case 0x808756u: goto L_808756;
    case 0x808758u: goto L_808758;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80870C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x870Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x870Cu,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x870Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80870C BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x75u), cpu.m8?8:16), false);
    goto L_80870E;
L_80870E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x870Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x870Eu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x870Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80870E BPL -> $80872E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80872E; }
    goto L_808710;
L_808710:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8710u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8710u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8710u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808710 DEC
    cpu.decMem(hw, cpu.address("dp", 0x76u), cpu.m8?8:16);
    goto L_808712;
L_808712:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8712u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8712u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8712u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808712 BPL -> $80872E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80872E; }
    goto L_808714;
L_808714:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8714u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8714u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8714u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808714 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x74u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808716;
L_808716:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8716u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8716u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8716u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808716 AND
    cpu.logicAnd(0xFu);
    goto L_808718;
L_808718:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8718u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8718u,cpu,0x70u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8718u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808718 BVS -> $80871F
    if (cpu.v) { hw.addCpuInternalCycles(1u); goto L_80871F; }
    goto L_80871A;
L_80871A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x871Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x871Au,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x871Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80871A DEC
    cpu.decReg('A');
    goto L_80871B;
L_80871B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x871Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x871Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x871Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80871B BNE -> $808726
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_808726; }
    goto L_80871D;
L_80871D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x871Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x871Du,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x871Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80871D BRA -> $808724
    goto L_808724;
L_80871F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x871Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x871Fu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x871Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80871F INC
    cpu.inc('A');
    goto L_808720;
L_808720:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8720u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8720u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8720u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808720 CMP
    cpu.compareA(0xFu);
    goto L_808722;
L_808722:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8722u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8722u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8722u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808722 BCC -> $808726
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_808726; }
    goto L_808724;
L_808724:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8724u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8724u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8724u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808724 STZ
    hw.write(cpu.address("dp", 0x75u), 0, cpu.m8?8:16);
    goto L_808726;
L_808726:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8726u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8726u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8726u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808726 STA
    hw.write(cpu.address("dp", 0x74u), cpu.a, cpu.m8?8:16);
    goto L_808728;
L_808728:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8728u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8728u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8728u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808728 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x75u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80872A;
L_80872A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x872Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x872Au,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x872Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80872A AND
    cpu.logicAnd(0x3Fu);
    goto L_80872C;
L_80872C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x872Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x872Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x872Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80872C STA
    hw.write(cpu.address("dp", 0x76u), cpu.a, cpu.m8?8:16);
    goto L_80872E;
L_80872E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x872Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x872Eu,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x872Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x78u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80872E BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x78u), cpu.m8?8:16), false);
    goto L_808730;
L_808730:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8730u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8730u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8730u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808730 BPL -> $808758
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_808758; }
    goto L_808732;
L_808732:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8732u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8732u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8732u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x79u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808732 DEC
    cpu.decMem(hw, cpu.address("dp", 0x79u), cpu.m8?8:16);
    goto L_808734;
L_808734:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8734u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8734u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8734u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808734 BPL -> $808758
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_808758; }
    goto L_808736;
L_808736:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8736u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8736u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8736u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808736 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x77u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808738;
L_808738:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8738u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8738u,cpu,0x70u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8738u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808738 BVS -> $808747
    if (cpu.v) { hw.addCpuInternalCycles(1u); goto L_808747; }
    goto L_80873A;
L_80873A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x873Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x873Au,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x873Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80873A CLC
    cpu.setFlag('C', false);
    goto L_80873B;
L_80873B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x873Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x873Bu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x873Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80873B ADC
    cpu.adc(0x10u);
    goto L_80873D;
L_80873D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x873Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x873Du,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x873Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80873D CMP
    cpu.compareA(0xF0u);
    goto L_80873F;
L_80873F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x873Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x873Fu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x873Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80873F BCC -> $808750
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_808750; }
    goto L_808741;
L_808741:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8741u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8741u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8741u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808741 AND
    cpu.logicAnd(0xFu);
    goto L_808743;
L_808743:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8743u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8743u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8743u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808743 ORA
    cpu.logicOr(0xF0u);
    goto L_808745;
L_808745:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8745u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8745u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8745u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808745 BRA -> $80874E
    goto L_80874E;
L_808747:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8747u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8747u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8747u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808747 SEC
    cpu.setFlag('C', true);
    goto L_808748;
L_808748:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8748u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8748u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8748u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808748 SBC
    cpu.sbc(0x10u);
    goto L_80874A;
L_80874A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x874Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x874Au,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x874Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80874A BCS -> $808750
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_808750; }
    goto L_80874C;
L_80874C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x874Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x874Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x874Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80874C LDA
    cpu.setA(0x0u, 8);
    goto L_80874E;
L_80874E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x874Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x874Eu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x874Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x78u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80874E STZ
    hw.write(cpu.address("dp", 0x78u), 0, cpu.m8?8:16);
    goto L_808750;
L_808750:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8750u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8750u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8750u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808750 STA
    hw.write(cpu.address("dp", 0x77u), cpu.a, cpu.m8?8:16);
    goto L_808752;
L_808752:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8752u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8752u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8752u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x78u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808752 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x78u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808754;
L_808754:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8754u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8754u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8754u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808754 AND
    cpu.logicAnd(0x3Fu);
    goto L_808756;
L_808756:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8756u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8756u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8756u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x79u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808756 STA
    hw.write(cpu.address("dp", 0x79u), cpu.a, cpu.m8?8:16);
    goto L_808758;
L_808758:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8758u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8758u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8758u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808758 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808758u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x808758u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_808BEA_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808BEAu: goto L_808BEA;
    case 0x808BEBu: goto L_808BEB;
    case 0x808BEDu: goto L_808BED;
    case 0x808BEFu: goto L_808BEF;
    case 0x808BF1u: goto L_808BF1;
    case 0x808BF4u: goto L_808BF4;
    case 0x808BF6u: goto L_808BF6;
    case 0x808BF8u: goto L_808BF8;
    case 0x808BFAu: goto L_808BFA;
    case 0x808BFBu: goto L_808BFB;
    case 0x808BFCu: goto L_808BFC;
    case 0x808BFEu: goto L_808BFE;
    case 0x808BFFu: goto L_808BFF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808BEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEAu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEAu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808BEA PHP
    cpu.push("PHP", hw);
    goto L_808BEB;
L_808BEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BEBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEBu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEBu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BEB REP
    cpu.rep(0x20u);
    goto L_808BED;
L_808BED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEDu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEDu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Bu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BED INC
    cpu.incMem(hw, cpu.address("dp", 0x6Bu), cpu.m8?8:16);
    goto L_808BEF;
L_808BEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEFu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEFu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Du), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BEF INC
    cpu.incMem(hw, cpu.address("dp", 0x6Du), cpu.m8?8:16);
    goto L_808BF1;
L_808BF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF1u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BF1 LDX
    cpu.setX(0x2u, 16);
    goto L_808BF4;
L_808BF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF4u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF4u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x6Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BF4 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x6Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808BF6;
L_808BF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BF6 BEQ -> $808BFA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_808BFA; }
    goto L_808BF8;
L_808BF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF8u,cpu,0xD6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF8u, 8u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x6Fu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BF8 DEC
    cpu.decMem(hw, cpu.address("dpx", 0x6Fu), cpu.m8?8:16);
    goto L_808BFA;
L_808BFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFAu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BFA DEX
    cpu.decReg('X');
    goto L_808BFB;
L_808BFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFBu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BFB DEX
    cpu.decReg('X');
    goto L_808BFC;
L_808BFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFCu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BFC BPL -> $808BF4
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_808BF4; }
    goto L_808BFE;
L_808BFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFEu,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFEu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808BFE PLP
    cpu.pop("PLP", hw);
    goto L_808BFF;
L_808BFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BFFu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BFFu,0x808BFFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFFu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808BFF RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808BFFu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x808BFFu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_809B04_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809B04u: goto L_809B04;
    case 0x809B05u: goto L_809B05;
    case 0x809B07u: goto L_809B07;
    case 0x809B09u: goto L_809B09;
    case 0x809B0Cu: goto L_809B0C;
    case 0x809B0Eu: goto L_809B0E;
    case 0x809B11u: goto L_809B11;
    case 0x809B13u: goto L_809B13;
    case 0x809B16u: goto L_809B16;
    case 0x809B19u: goto L_809B19;
    case 0x809B1Bu: goto L_809B1B;
    case 0x809B1Du: goto L_809B1D;
    case 0x809B20u: goto L_809B20;
    case 0x809B22u: goto L_809B22;
    case 0x809B23u: goto L_809B23;
    case 0x809B26u: goto L_809B26;
    case 0x809B28u: goto L_809B28;
    case 0x809B2Au: goto L_809B2A;
    case 0x809B2Du: goto L_809B2D;
    case 0x809B2Fu: goto L_809B2F;
    case 0x809B30u: goto L_809B30;
    case 0x809B33u: goto L_809B33;
    case 0x809B35u: goto L_809B35;
    case 0x809B37u: goto L_809B37;
    case 0x809B39u: goto L_809B39;
    case 0x809B3Bu: goto L_809B3B;
    case 0x809B3Du: goto L_809B3D;
    case 0x809B40u: goto L_809B40;
    case 0x809B42u: goto L_809B42;
    case 0x809B45u: goto L_809B45;
    case 0x809B47u: goto L_809B47;
    case 0x809B49u: goto L_809B49;
    case 0x809B4Cu: goto L_809B4C;
    case 0x809B4Eu: goto L_809B4E;
    case 0x809B50u: goto L_809B50;
    case 0x809B52u: goto L_809B52;
    case 0x809B53u: goto L_809B53;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809B04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B04u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B04u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809B04 PHP
    cpu.push("PHP", hw);
    goto L_809B05;
L_809B05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B05u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B05u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B05 SEP
    cpu.sep(0x20u);
    goto L_809B07;
L_809B07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B07u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B07u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B07 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809B09;
L_809B09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B09u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B09u, 4u, 3u, cpu.address("abs", 0x4202u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B09 STA
    hw.write(cpu.address("abs", 0x4202u), cpu.a, cpu.m8?8:16);
    goto L_809B0C;
L_809B0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B0Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B0Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B0C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809B0E;
L_809B0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B0Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B0Eu, 4u, 3u, cpu.address("abs", 0x4203u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B0E STA
    hw.write(cpu.address("abs", 0x4203u), cpu.a, cpu.m8?8:16);
    goto L_809B11;
L_809B11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B11u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B11u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B11 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809B13;
L_809B13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B13u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B13u, 4u, 3u, cpu.address("abs", 0x4202u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B13 STA
    hw.write(cpu.address("abs", 0x4202u), cpu.a, cpu.m8?8:16);
    goto L_809B16;
L_809B16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B16u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B16u, 5u, 3u, cpu.address("abs", 0x4216u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B16 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x4216u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_809B19;
L_809B19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B19u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B19u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B19 STY
    hw.write(cpu.address("dp", 0x10u), cpu.y, cpu.x8?8:16);
    goto L_809B1B;
L_809B1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B1Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B1Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B1B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809B1D;
L_809B1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B1Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B1Du, 4u, 3u, cpu.address("abs", 0x4203u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B1D STA
    hw.write(cpu.address("abs", 0x4203u), cpu.a, cpu.m8?8:16);
    goto L_809B20;
L_809B20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B20u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B20u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B20 REP
    cpu.rep(0x20u);
    goto L_809B22;
L_809B22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B22u,cpu,0xEAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B22u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B22 NOP
    ;
    goto L_809B23;
L_809B23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B23u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B23u, 5u, 3u, cpu.address("abs", 0x4216u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B23 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x4216u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809B26;
L_809B26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B26u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B26u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B26 STA
    hw.write(cpu.address("dp", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_809B28;
L_809B28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B28u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B28u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B28 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809B2A;
L_809B2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B2Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B2Au, 5u, 3u, cpu.address("abs", 0x4202u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B2A STA
    hw.write(cpu.address("abs", 0x4202u), cpu.a, cpu.m8?8:16);
    goto L_809B2D;
L_809B2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B2Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B2Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B2D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x11u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809B2F;
L_809B2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B2Fu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B2Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B2F CLC
    cpu.setFlag('C', false);
    goto L_809B30;
L_809B30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B30u,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B30u, 5u, 3u, cpu.address("abs", 0x4216u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B30 ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x4216u), cpu.m8?8:16));
    goto L_809B33;
L_809B33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B33u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B33u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B33 STA
    hw.write(cpu.address("dp", 0x11u), cpu.a, cpu.m8?8:16);
    goto L_809B35;
L_809B35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B35u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B35u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B35 BCC -> $809B39
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_809B39; }
    goto L_809B37;
L_809B37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B37u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B37u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B37 INC
    cpu.incMem(hw, cpu.address("dp", 0x13u), cpu.m8?8:16);
    goto L_809B39;
L_809B39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B39u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B39u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B39 SEP
    cpu.sep(0x20u);
    goto L_809B3B;
L_809B3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B3Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B3Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B3B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809B3D;
L_809B3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B3Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B3Du, 4u, 3u, cpu.address("abs", 0x4202u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B3D STA
    hw.write(cpu.address("abs", 0x4202u), cpu.a, cpu.m8?8:16);
    goto L_809B40;
L_809B40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B40u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B40u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B40 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809B42;
L_809B42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B42u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B42u, 4u, 3u, cpu.address("abs", 0x4203u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B42 STA
    hw.write(cpu.address("abs", 0x4203u), cpu.a, cpu.m8?8:16);
    goto L_809B45;
L_809B45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B45u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B45u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B45 REP
    cpu.rep(0x21u);
    goto L_809B47;
L_809B47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B47u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B47u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B47 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x11u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809B49;
L_809B49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B49u,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B49u, 5u, 3u, cpu.address("abs", 0x4216u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B49 ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x4216u), cpu.m8?8:16));
    goto L_809B4C;
L_809B4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B4Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B4Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B4C STA
    hw.write(cpu.address("dp", 0x11u), cpu.a, cpu.m8?8:16);
    goto L_809B4E;
L_809B4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B4Eu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B4Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B4E BCC -> $809B52
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_809B52; }
    goto L_809B50;
L_809B50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B50u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B50u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B50 INC
    cpu.incMem(hw, cpu.address("dp", 0x13u), cpu.m8?8:16);
    goto L_809B52;
L_809B52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B52u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B52u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809B52 PLP
    cpu.pop("PLP", hw);
    goto L_809B53;
L_809B53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B53u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9B53u,0x809B53u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B53u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B53u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $809B53 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x809B53u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x809B53u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_809B04_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809B04u: goto L_809B04;
    case 0x809B05u: goto L_809B05;
    case 0x809B07u: goto L_809B07;
    case 0x809B09u: goto L_809B09;
    case 0x809B0Cu: goto L_809B0C;
    case 0x809B0Eu: goto L_809B0E;
    case 0x809B11u: goto L_809B11;
    case 0x809B13u: goto L_809B13;
    case 0x809B16u: goto L_809B16;
    case 0x809B19u: goto L_809B19;
    case 0x809B1Bu: goto L_809B1B;
    case 0x809B1Du: goto L_809B1D;
    case 0x809B20u: goto L_809B20;
    case 0x809B22u: goto L_809B22;
    case 0x809B23u: goto L_809B23;
    case 0x809B26u: goto L_809B26;
    case 0x809B28u: goto L_809B28;
    case 0x809B2Au: goto L_809B2A;
    case 0x809B2Du: goto L_809B2D;
    case 0x809B2Fu: goto L_809B2F;
    case 0x809B30u: goto L_809B30;
    case 0x809B33u: goto L_809B33;
    case 0x809B35u: goto L_809B35;
    case 0x809B37u: goto L_809B37;
    case 0x809B39u: goto L_809B39;
    case 0x809B3Bu: goto L_809B3B;
    case 0x809B3Du: goto L_809B3D;
    case 0x809B40u: goto L_809B40;
    case 0x809B42u: goto L_809B42;
    case 0x809B45u: goto L_809B45;
    case 0x809B47u: goto L_809B47;
    case 0x809B49u: goto L_809B49;
    case 0x809B4Cu: goto L_809B4C;
    case 0x809B4Eu: goto L_809B4E;
    case 0x809B50u: goto L_809B50;
    case 0x809B52u: goto L_809B52;
    case 0x809B53u: goto L_809B53;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809B04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B04u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B04u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809B04 PHP
    cpu.push("PHP", hw);
    goto L_809B05;
L_809B05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B05u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B05u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B05 SEP
    cpu.sep(0x20u);
    goto L_809B07;
L_809B07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B07u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B07u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B07 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809B09;
L_809B09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B09u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B09u, 4u, 3u, cpu.address("abs", 0x4202u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B09 STA
    hw.write(cpu.address("abs", 0x4202u), cpu.a, cpu.m8?8:16);
    goto L_809B0C;
L_809B0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B0Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B0Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B0C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809B0E;
L_809B0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B0Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B0Eu, 4u, 3u, cpu.address("abs", 0x4203u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B0E STA
    hw.write(cpu.address("abs", 0x4203u), cpu.a, cpu.m8?8:16);
    goto L_809B11;
L_809B11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B11u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B11u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B11 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809B13;
L_809B13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B13u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B13u, 4u, 3u, cpu.address("abs", 0x4202u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B13 STA
    hw.write(cpu.address("abs", 0x4202u), cpu.a, cpu.m8?8:16);
    goto L_809B16;
L_809B16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B16u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B16u, 5u, 3u, cpu.address("abs", 0x4216u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B16 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x4216u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_809B19;
L_809B19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B19u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B19u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B19 STY
    hw.write(cpu.address("dp", 0x10u), cpu.y, cpu.x8?8:16);
    goto L_809B1B;
L_809B1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B1Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B1Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B1B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809B1D;
L_809B1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B1Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B1Du, 4u, 3u, cpu.address("abs", 0x4203u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B1D STA
    hw.write(cpu.address("abs", 0x4203u), cpu.a, cpu.m8?8:16);
    goto L_809B20;
L_809B20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B20u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B20u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B20 REP
    cpu.rep(0x20u);
    goto L_809B22;
L_809B22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B22u,cpu,0xEAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B22u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B22 NOP
    ;
    goto L_809B23;
L_809B23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B23u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B23u, 5u, 3u, cpu.address("abs", 0x4216u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B23 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x4216u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809B26;
L_809B26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B26u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B26u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B26 STA
    hw.write(cpu.address("dp", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_809B28;
L_809B28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B28u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B28u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B28 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809B2A;
L_809B2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B2Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B2Au, 5u, 3u, cpu.address("abs", 0x4202u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B2A STA
    hw.write(cpu.address("abs", 0x4202u), cpu.a, cpu.m8?8:16);
    goto L_809B2D;
L_809B2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B2Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B2Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B2D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x11u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809B2F;
L_809B2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B2Fu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B2Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B2F CLC
    cpu.setFlag('C', false);
    goto L_809B30;
L_809B30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B30u,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B30u, 5u, 3u, cpu.address("abs", 0x4216u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B30 ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x4216u), cpu.m8?8:16));
    goto L_809B33;
L_809B33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B33u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B33u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B33 STA
    hw.write(cpu.address("dp", 0x11u), cpu.a, cpu.m8?8:16);
    goto L_809B35;
L_809B35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B35u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B35u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B35 BCC -> $809B39
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_809B39; }
    goto L_809B37;
L_809B37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B37u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B37u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B37 INC
    cpu.incMem(hw, cpu.address("dp", 0x13u), cpu.m8?8:16);
    goto L_809B39;
L_809B39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B39u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B39u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B39 SEP
    cpu.sep(0x20u);
    goto L_809B3B;
L_809B3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B3Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B3Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B3B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809B3D;
L_809B3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B3Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B3Du, 4u, 3u, cpu.address("abs", 0x4202u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B3D STA
    hw.write(cpu.address("abs", 0x4202u), cpu.a, cpu.m8?8:16);
    goto L_809B40;
L_809B40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B40u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B40u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B40 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809B42;
L_809B42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B42u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B42u, 4u, 3u, cpu.address("abs", 0x4203u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B42 STA
    hw.write(cpu.address("abs", 0x4203u), cpu.a, cpu.m8?8:16);
    goto L_809B45;
L_809B45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B45u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B45u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B45 REP
    cpu.rep(0x21u);
    goto L_809B47;
L_809B47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B47u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B47u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B47 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x11u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809B49;
L_809B49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B49u,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B49u, 5u, 3u, cpu.address("abs", 0x4216u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B49 ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x4216u), cpu.m8?8:16));
    goto L_809B4C;
L_809B4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B4Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B4Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B4C STA
    hw.write(cpu.address("dp", 0x11u), cpu.a, cpu.m8?8:16);
    goto L_809B4E;
L_809B4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B4Eu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B4Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B4E BCC -> $809B52
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_809B52; }
    goto L_809B50;
L_809B50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B50u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B50u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B50 INC
    cpu.incMem(hw, cpu.address("dp", 0x13u), cpu.m8?8:16);
    goto L_809B52;
L_809B52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B52u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B52u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809B52 PLP
    cpu.pop("PLP", hw);
    goto L_809B53;
L_809B53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B53u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9B53u,0x809B53u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B53u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B53u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $809B53 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x809B53u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x809B53u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_809B04_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809B04u: goto L_809B04;
    case 0x809B05u: goto L_809B05;
    case 0x809B07u: goto L_809B07;
    case 0x809B09u: goto L_809B09;
    case 0x809B0Cu: goto L_809B0C;
    case 0x809B0Eu: goto L_809B0E;
    case 0x809B11u: goto L_809B11;
    case 0x809B13u: goto L_809B13;
    case 0x809B16u: goto L_809B16;
    case 0x809B19u: goto L_809B19;
    case 0x809B1Bu: goto L_809B1B;
    case 0x809B1Du: goto L_809B1D;
    case 0x809B20u: goto L_809B20;
    case 0x809B22u: goto L_809B22;
    case 0x809B23u: goto L_809B23;
    case 0x809B26u: goto L_809B26;
    case 0x809B28u: goto L_809B28;
    case 0x809B2Au: goto L_809B2A;
    case 0x809B2Du: goto L_809B2D;
    case 0x809B2Fu: goto L_809B2F;
    case 0x809B30u: goto L_809B30;
    case 0x809B33u: goto L_809B33;
    case 0x809B35u: goto L_809B35;
    case 0x809B37u: goto L_809B37;
    case 0x809B39u: goto L_809B39;
    case 0x809B3Bu: goto L_809B3B;
    case 0x809B3Du: goto L_809B3D;
    case 0x809B40u: goto L_809B40;
    case 0x809B42u: goto L_809B42;
    case 0x809B45u: goto L_809B45;
    case 0x809B47u: goto L_809B47;
    case 0x809B49u: goto L_809B49;
    case 0x809B4Cu: goto L_809B4C;
    case 0x809B4Eu: goto L_809B4E;
    case 0x809B50u: goto L_809B50;
    case 0x809B52u: goto L_809B52;
    case 0x809B53u: goto L_809B53;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809B04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B04u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B04u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809B04 PHP
    cpu.push("PHP", hw);
    goto L_809B05;
L_809B05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B05u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B05u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B05 SEP
    cpu.sep(0x20u);
    goto L_809B07;
L_809B07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B07u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B07u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B07 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809B09;
L_809B09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B09u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B09u, 4u, 3u, cpu.address("abs", 0x4202u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B09 STA
    hw.write(cpu.address("abs", 0x4202u), cpu.a, cpu.m8?8:16);
    goto L_809B0C;
L_809B0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B0Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B0Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B0C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809B0E;
L_809B0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B0Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B0Eu, 4u, 3u, cpu.address("abs", 0x4203u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B0E STA
    hw.write(cpu.address("abs", 0x4203u), cpu.a, cpu.m8?8:16);
    goto L_809B11;
L_809B11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B11u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B11u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B11 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809B13;
L_809B13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B13u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B13u, 4u, 3u, cpu.address("abs", 0x4202u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B13 STA
    hw.write(cpu.address("abs", 0x4202u), cpu.a, cpu.m8?8:16);
    goto L_809B16;
L_809B16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B16u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B16u, 5u, 3u, cpu.address("abs", 0x4216u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B16 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x4216u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_809B19;
L_809B19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B19u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B19u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B19 STY
    hw.write(cpu.address("dp", 0x10u), cpu.y, cpu.x8?8:16);
    goto L_809B1B;
L_809B1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B1Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B1Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B1B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809B1D;
L_809B1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B1Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B1Du, 4u, 3u, cpu.address("abs", 0x4203u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B1D STA
    hw.write(cpu.address("abs", 0x4203u), cpu.a, cpu.m8?8:16);
    goto L_809B20;
L_809B20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B20u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B20u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B20 REP
    cpu.rep(0x20u);
    goto L_809B22;
L_809B22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B22u,cpu,0xEAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B22u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B22 NOP
    ;
    goto L_809B23;
L_809B23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B23u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B23u, 5u, 3u, cpu.address("abs", 0x4216u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B23 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x4216u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809B26;
L_809B26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B26u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B26u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B26 STA
    hw.write(cpu.address("dp", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_809B28;
L_809B28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B28u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B28u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B28 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809B2A;
L_809B2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B2Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B2Au, 5u, 3u, cpu.address("abs", 0x4202u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B2A STA
    hw.write(cpu.address("abs", 0x4202u), cpu.a, cpu.m8?8:16);
    goto L_809B2D;
L_809B2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B2Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B2Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B2D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x11u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809B2F;
L_809B2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B2Fu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B2Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B2F CLC
    cpu.setFlag('C', false);
    goto L_809B30;
L_809B30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B30u,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B30u, 5u, 3u, cpu.address("abs", 0x4216u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B30 ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x4216u), cpu.m8?8:16));
    goto L_809B33;
L_809B33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B33u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B33u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B33 STA
    hw.write(cpu.address("dp", 0x11u), cpu.a, cpu.m8?8:16);
    goto L_809B35;
L_809B35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B35u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B35u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B35 BCC -> $809B39
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_809B39; }
    goto L_809B37;
L_809B37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B37u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B37u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B37 INC
    cpu.incMem(hw, cpu.address("dp", 0x13u), cpu.m8?8:16);
    goto L_809B39;
L_809B39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B39u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B39u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B39 SEP
    cpu.sep(0x20u);
    goto L_809B3B;
L_809B3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B3Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B3Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B3B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809B3D;
L_809B3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B3Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B3Du, 4u, 3u, cpu.address("abs", 0x4202u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B3D STA
    hw.write(cpu.address("abs", 0x4202u), cpu.a, cpu.m8?8:16);
    goto L_809B40;
L_809B40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B40u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B40u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B40 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809B42;
L_809B42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B42u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B42u, 4u, 3u, cpu.address("abs", 0x4203u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B42 STA
    hw.write(cpu.address("abs", 0x4203u), cpu.a, cpu.m8?8:16);
    goto L_809B45;
L_809B45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B45u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B45u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B45 REP
    cpu.rep(0x21u);
    goto L_809B47;
L_809B47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B47u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B47u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B47 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x11u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809B49;
L_809B49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B49u,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B49u, 5u, 3u, cpu.address("abs", 0x4216u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B49 ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x4216u), cpu.m8?8:16));
    goto L_809B4C;
L_809B4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B4Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B4Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B4C STA
    hw.write(cpu.address("dp", 0x11u), cpu.a, cpu.m8?8:16);
    goto L_809B4E;
L_809B4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B4Eu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B4Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B4E BCC -> $809B52
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_809B52; }
    goto L_809B50;
L_809B50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B50u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B50u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B50 INC
    cpu.incMem(hw, cpu.address("dp", 0x13u), cpu.m8?8:16);
    goto L_809B52;
L_809B52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B52u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B52u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809B52 PLP
    cpu.pop("PLP", hw);
    goto L_809B53;
L_809B53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B53u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9B53u,0x809B53u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B53u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B53u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $809B53 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x809B53u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x809B53u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_809E97_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809E97u: goto L_809E97;
    case 0x809E9Au: goto L_809E9A;
    case 0x809E9Du: goto L_809E9D;
    case 0x809EA0u: goto L_809EA0;
    case 0x809EA3u: goto L_809EA3;
    case 0x809EA7u: goto L_809EA7;
    case 0x809EA9u: goto L_809EA9;
    case 0x809EABu: goto L_809EAB;
    case 0x809EACu: goto L_809EAC;
    case 0x809EAFu: goto L_809EAF;
    case 0x809EB2u: goto L_809EB2;
    case 0x809EB5u: goto L_809EB5;
    case 0x809EB9u: goto L_809EB9;
    case 0x809EBCu: goto L_809EBC;
    case 0x809EBFu: goto L_809EBF;
    case 0x809EC2u: goto L_809EC2;
    case 0x809EC5u: goto L_809EC5;
    case 0x809EC9u: goto L_809EC9;
    case 0x809ECBu: goto L_809ECB;
    case 0x809ECDu: goto L_809ECD;
    case 0x809ECEu: goto L_809ECE;
    case 0x809ED1u: goto L_809ED1;
    case 0x809ED4u: goto L_809ED4;
    case 0x809ED7u: goto L_809ED7;
    case 0x809EDBu: goto L_809EDB;
    case 0x809EDEu: goto L_809EDE;
    case 0x809EE1u: goto L_809EE1;
    case 0x809EE3u: goto L_809EE3;
    case 0x809EE6u: goto L_809EE6;
    case 0x809EE8u: goto L_809EE8;
    case 0x809EECu: goto L_809EEC;
    case 0x809EEEu: goto L_809EEE;
    case 0x809EF1u: goto L_809EF1;
    case 0x809EF4u: goto L_809EF4;
    case 0x809EF6u: goto L_809EF6;
    case 0x809EF8u: goto L_809EF8;
    case 0x809EFBu: goto L_809EFB;
    case 0x809EFDu: goto L_809EFD;
    case 0x809F00u: goto L_809F00;
    case 0x809F04u: goto L_809F04;
    case 0x809F07u: goto L_809F07;
    case 0x809F09u: goto L_809F09;
    case 0x809F0Bu: goto L_809F0B;
    case 0x809F0Eu: goto L_809F0E;
    case 0x809F10u: goto L_809F10;
    case 0x809F13u: goto L_809F13;
    case 0x809F15u: goto L_809F15;
    case 0x809F19u: goto L_809F19;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809E97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E97u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E97u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E97 LDA
    cpu.setA(0x83EFu, 16);
    goto L_809E9A;
L_809E9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E9Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E9Au, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E9A STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_809E9D;
L_809E9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E9Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E9Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E9D LDA
    cpu.setA(0x8Bu, 16);
    goto L_809EA0;
L_809EA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA0u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA0u, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EA0 STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_809EA3;
L_809EA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA3u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA3u, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $809EA3 JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9EA6u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9EA7u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x809EA3u); }
    goto L_809EA7;
L_809EA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EA7u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EA7u,0x809EA7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA7u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EA7 SEP
    cpu.sep(0x20u);
    goto L_809EA9;
L_809EA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EA9 LDA
    cpu.setA(0x7Eu, 8);
    goto L_809EAB;
L_809EAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EABu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EABu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809EAB PHA
    cpu.push("PHA", hw);
    goto L_809EAC;
L_809EAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EACu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EACu, 5u, 3u, cpu.address("abs", 0x8000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809EAC PEA
    cpu.push16Value(hw, 0x8000u);
    goto L_809EAF;
L_809EAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EAFu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EAFu, 5u, 3u, cpu.address("abs", 0x7000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809EAF PEA
    cpu.push16Value(hw, 0x7000u);
    goto L_809EB2;
L_809EB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB2u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB2u, 5u, 3u, cpu.address("abs", 0x2000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809EB2 PEA
    cpu.push16Value(hw, 0x2000u);
    goto L_809EB5;
L_809EB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB5u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB5u, 8u, 4u, 0x809B54u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $809EB5 JSL -> $809B54 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9EB8u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9EB9u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809B54u, 0x809EB5u); }
    goto L_809EB9;
L_809EB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EB9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EB9u,0x809EB9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EB9 LDA
    cpu.setA(0x8000u, 16);
    goto L_809EBC;
L_809EBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EBCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EBCu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EBCu, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EBC STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_809EBF;
L_809EBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EBFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EBFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EBFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EBF LDA
    cpu.setA(0x8Cu, 16);
    goto L_809EC2;
L_809EC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC2u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC2u, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EC2 STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_809EC5;
L_809EC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC5u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC5u, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $809EC5 JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9EC8u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9EC9u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x809EC5u); }
    goto L_809EC9;
L_809EC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EC9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EC9u,0x809EC9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC9u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EC9 SEP
    cpu.sep(0x20u);
    goto L_809ECB;
L_809ECB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ECBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809ECB LDA
    cpu.setA(0x7Eu, 8);
    goto L_809ECD;
L_809ECD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ECDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECDu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECDu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809ECD PHA
    cpu.push("PHA", hw);
    goto L_809ECE;
L_809ECE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ECEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECEu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECEu, 5u, 3u, cpu.address("abs", 0x8000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809ECE PEA
    cpu.push16Value(hw, 0x8000u);
    goto L_809ED1;
L_809ED1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ED1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED1u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED1u, 5u, 3u, cpu.address("abs", 0x0000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809ED1 PEA
    cpu.push16Value(hw, 0x0u);
    goto L_809ED4;
L_809ED4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ED4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED4u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED4u, 5u, 3u, cpu.address("abs", 0x2000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809ED4 PEA
    cpu.push16Value(hw, 0x2000u);
    goto L_809ED7;
L_809ED7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ED7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED7u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED7u, 8u, 4u, 0x809B54u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $809ED7 JSL -> $809B54 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9EDAu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9EDBu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809B54u, 0x809ED7u); }
    goto L_809EDB;
L_809EDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EDBu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EDBu,0x809EDBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDBu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDBu, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EDB LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809EDE;
L_809EDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDEu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EDE CMP
    cpu.compareA(0x1u);
    goto L_809EE1;
L_809EE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE1u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EE1 BEQ -> $809EFD
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_809EFD; }
    goto L_809EE3;
L_809EE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE3u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE3u, 5u, 3u, cpu.address("abs", 0x02CEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EE3 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2CEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809EE6;
L_809EE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EE6 STA
    hw.write(cpu.address("dp", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_809EE8;
L_809EE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE8u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE8u, 8u, 4u, 0x809315u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $809EE8 JSL -> $809315 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9EEBu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9EECu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809315u, 0x809EE8u); }
    goto L_809EEC;
L_809EEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EECu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EECu,0x809EECu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EECu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EECu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EEC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809EEE;
L_809EEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EEEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EEEu, 5u, 3u, cpu.address("abs", 0x0179u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EEE STA
    hw.write(cpu.address("abs", 0x179u), cpu.a, cpu.m8?8:16);
    goto L_809EF1;
L_809EF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF1u, 6u, 3u, cpu.address("abs", 0x9F1Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809EF1 JSR -> $809F1A stack real
    { cpu.push16Value(hw,0x9EF3u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9EF4u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9F1Au), 0x809EF1u); }
    goto L_809EF4;
L_809EF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EF4u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EF4u,0x809EF4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF4u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EF4 SEP
    cpu.sep(0x20u);
    goto L_809EF6;
L_809EF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EF6 LDA
    cpu.setA(0x82u, 8);
    goto L_809EF8;
L_809EF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF8u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF8u, 4u, 3u, cpu.address("abs", 0x2131u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EF8 STA
    hw.write(cpu.address("abs", 0x2131u), cpu.a, cpu.m8?8:16);
    goto L_809EFB;
L_809EFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EFBu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EFBu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EFB BRA -> $809F0E
    goto L_809F0E;
L_809EFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EFDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EFDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EFD LDA
    cpu.setA(0xFFFFu, 16);
    goto L_809F00;
L_809F00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F00u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F00u, 8u, 4u, 0x80A460u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $809F00 JSL -> $80A460 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9F03u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9F04u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A460u, 0x809F00u); }
    goto L_809F04;
L_809F04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F04u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F04u,0x809F04u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F04u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F04u, 6u, 3u, cpu.address("abs", 0xA392u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809F04 JSR -> $80A392 stack real
    { cpu.push16Value(hw,0x9F06u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9F07u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA392u), 0x809F04u); }
    goto L_809F07;
L_809F07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F07u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F07u,0x809F07u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F07u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F07u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F07 SEP
    cpu.sep(0x20u);
    goto L_809F09;
L_809F09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F09u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F09u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F09 LDA
    cpu.setA(0x42u, 8);
    goto L_809F0B;
L_809F0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Bu, 4u, 3u, cpu.address("abs", 0x2131u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F0B STA
    hw.write(cpu.address("abs", 0x2131u), cpu.a, cpu.m8?8:16);
    goto L_809F0E;
L_809F0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F0E LDA
    cpu.setA(0x2u, 8);
    goto L_809F10;
L_809F10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F10u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F10u, 4u, 3u, cpu.address("abs", 0x2130u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F10 STA
    hw.write(cpu.address("abs", 0x2130u), cpu.a, cpu.m8?8:16);
    goto L_809F13;
L_809F13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F13u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F13u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F13 REP
    cpu.rep(0x20u);
    goto L_809F15;
L_809F15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F15u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F15u, 8u, 4u, 0x80A4A3u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $809F15 JSL -> $80A4A3 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9F18u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9F19u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A4A3u, 0x809F15u); }
    goto L_809F19;
L_809F19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F19u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F19u,0x809F19u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F19u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F19u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $809F19 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x809F19u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x809F19u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_809E97_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809E97u: goto L_809E97;
    case 0x809E9Au: goto L_809E9A;
    case 0x809E9Du: goto L_809E9D;
    case 0x809EA0u: goto L_809EA0;
    case 0x809EA3u: goto L_809EA3;
    case 0x809EA7u: goto L_809EA7;
    case 0x809EA9u: goto L_809EA9;
    case 0x809EABu: goto L_809EAB;
    case 0x809EACu: goto L_809EAC;
    case 0x809EAFu: goto L_809EAF;
    case 0x809EB2u: goto L_809EB2;
    case 0x809EB5u: goto L_809EB5;
    case 0x809EB9u: goto L_809EB9;
    case 0x809EBCu: goto L_809EBC;
    case 0x809EBFu: goto L_809EBF;
    case 0x809EC2u: goto L_809EC2;
    case 0x809EC5u: goto L_809EC5;
    case 0x809EC9u: goto L_809EC9;
    case 0x809ECBu: goto L_809ECB;
    case 0x809ECDu: goto L_809ECD;
    case 0x809ECEu: goto L_809ECE;
    case 0x809ED1u: goto L_809ED1;
    case 0x809ED4u: goto L_809ED4;
    case 0x809ED7u: goto L_809ED7;
    case 0x809EDBu: goto L_809EDB;
    case 0x809EDEu: goto L_809EDE;
    case 0x809EE1u: goto L_809EE1;
    case 0x809EE3u: goto L_809EE3;
    case 0x809EE6u: goto L_809EE6;
    case 0x809EE8u: goto L_809EE8;
    case 0x809EECu: goto L_809EEC;
    case 0x809EEEu: goto L_809EEE;
    case 0x809EF1u: goto L_809EF1;
    case 0x809EF4u: goto L_809EF4;
    case 0x809EF6u: goto L_809EF6;
    case 0x809EF8u: goto L_809EF8;
    case 0x809EFBu: goto L_809EFB;
    case 0x809EFDu: goto L_809EFD;
    case 0x809F00u: goto L_809F00;
    case 0x809F04u: goto L_809F04;
    case 0x809F07u: goto L_809F07;
    case 0x809F09u: goto L_809F09;
    case 0x809F0Bu: goto L_809F0B;
    case 0x809F0Eu: goto L_809F0E;
    case 0x809F10u: goto L_809F10;
    case 0x809F13u: goto L_809F13;
    case 0x809F15u: goto L_809F15;
    case 0x809F19u: goto L_809F19;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809E97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E97u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E97u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E97 LDA
    cpu.setA(0x83EFu, 16);
    goto L_809E9A;
L_809E9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E9Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E9Au, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E9A STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_809E9D;
L_809E9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E9Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E9Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E9D LDA
    cpu.setA(0x8Bu, 16);
    goto L_809EA0;
L_809EA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA0u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA0u, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EA0 STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_809EA3;
L_809EA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA3u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA3u, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $809EA3 JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9EA6u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9EA7u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x809EA3u); }
    goto L_809EA7;
L_809EA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EA7u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EA7u,0x809EA7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA7u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EA7 SEP
    cpu.sep(0x20u);
    goto L_809EA9;
L_809EA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EA9 LDA
    cpu.setA(0x7Eu, 8);
    goto L_809EAB;
L_809EAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EABu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EABu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809EAB PHA
    cpu.push("PHA", hw);
    goto L_809EAC;
L_809EAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EACu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EACu, 5u, 3u, cpu.address("abs", 0x8000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809EAC PEA
    cpu.push16Value(hw, 0x8000u);
    goto L_809EAF;
L_809EAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EAFu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EAFu, 5u, 3u, cpu.address("abs", 0x7000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809EAF PEA
    cpu.push16Value(hw, 0x7000u);
    goto L_809EB2;
L_809EB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB2u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB2u, 5u, 3u, cpu.address("abs", 0x2000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809EB2 PEA
    cpu.push16Value(hw, 0x2000u);
    goto L_809EB5;
L_809EB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB5u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB5u, 8u, 4u, 0x809B54u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $809EB5 JSL -> $809B54 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9EB8u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9EB9u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809B54u, 0x809EB5u); }
    goto L_809EB9;
L_809EB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EB9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EB9u,0x809EB9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EB9 LDA
    cpu.setA(0x8000u, 16);
    goto L_809EBC;
L_809EBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EBCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EBCu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EBCu, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EBC STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_809EBF;
L_809EBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EBFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EBFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EBFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EBF LDA
    cpu.setA(0x8Cu, 16);
    goto L_809EC2;
L_809EC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC2u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC2u, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EC2 STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_809EC5;
L_809EC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC5u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC5u, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $809EC5 JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9EC8u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9EC9u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x809EC5u); }
    goto L_809EC9;
L_809EC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EC9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EC9u,0x809EC9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC9u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EC9 SEP
    cpu.sep(0x20u);
    goto L_809ECB;
L_809ECB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ECBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809ECB LDA
    cpu.setA(0x7Eu, 8);
    goto L_809ECD;
L_809ECD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ECDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECDu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECDu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809ECD PHA
    cpu.push("PHA", hw);
    goto L_809ECE;
L_809ECE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ECEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECEu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECEu, 5u, 3u, cpu.address("abs", 0x8000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809ECE PEA
    cpu.push16Value(hw, 0x8000u);
    goto L_809ED1;
L_809ED1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ED1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED1u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED1u, 5u, 3u, cpu.address("abs", 0x0000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809ED1 PEA
    cpu.push16Value(hw, 0x0u);
    goto L_809ED4;
L_809ED4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ED4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED4u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED4u, 5u, 3u, cpu.address("abs", 0x2000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809ED4 PEA
    cpu.push16Value(hw, 0x2000u);
    goto L_809ED7;
L_809ED7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ED7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED7u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED7u, 8u, 4u, 0x809B54u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $809ED7 JSL -> $809B54 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9EDAu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9EDBu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809B54u, 0x809ED7u); }
    goto L_809EDB;
L_809EDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EDBu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EDBu,0x809EDBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDBu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDBu, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EDB LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809EDE;
L_809EDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDEu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EDE CMP
    cpu.compareA(0x1u);
    goto L_809EE1;
L_809EE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE1u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EE1 BEQ -> $809EFD
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_809EFD; }
    goto L_809EE3;
L_809EE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE3u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE3u, 5u, 3u, cpu.address("abs", 0x02CEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EE3 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2CEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809EE6;
L_809EE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EE6 STA
    hw.write(cpu.address("dp", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_809EE8;
L_809EE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE8u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE8u, 8u, 4u, 0x809315u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $809EE8 JSL -> $809315 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9EEBu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9EECu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809315u, 0x809EE8u); }
    goto L_809EEC;
L_809EEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EECu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EECu,0x809EECu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EECu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EECu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EEC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809EEE;
L_809EEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EEEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EEEu, 5u, 3u, cpu.address("abs", 0x0179u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EEE STA
    hw.write(cpu.address("abs", 0x179u), cpu.a, cpu.m8?8:16);
    goto L_809EF1;
L_809EF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF1u, 6u, 3u, cpu.address("abs", 0x9F1Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809EF1 JSR -> $809F1A stack real
    { cpu.push16Value(hw,0x9EF3u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9EF4u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9F1Au), 0x809EF1u); }
    goto L_809EF4;
L_809EF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EF4u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EF4u,0x809EF4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF4u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EF4 SEP
    cpu.sep(0x20u);
    goto L_809EF6;
L_809EF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EF6 LDA
    cpu.setA(0x82u, 8);
    goto L_809EF8;
L_809EF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF8u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF8u, 4u, 3u, cpu.address("abs", 0x2131u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EF8 STA
    hw.write(cpu.address("abs", 0x2131u), cpu.a, cpu.m8?8:16);
    goto L_809EFB;
L_809EFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EFBu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EFBu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EFB BRA -> $809F0E
    goto L_809F0E;
L_809EFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EFDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EFDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EFD LDA
    cpu.setA(0xFFFFu, 16);
    goto L_809F00;
L_809F00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F00u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F00u, 8u, 4u, 0x80A460u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $809F00 JSL -> $80A460 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9F03u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9F04u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A460u, 0x809F00u); }
    goto L_809F04;
L_809F04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F04u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F04u,0x809F04u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F04u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F04u, 6u, 3u, cpu.address("abs", 0xA392u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809F04 JSR -> $80A392 stack real
    { cpu.push16Value(hw,0x9F06u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9F07u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA392u), 0x809F04u); }
    goto L_809F07;
L_809F07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F07u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F07u,0x809F07u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F07u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F07u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F07 SEP
    cpu.sep(0x20u);
    goto L_809F09;
L_809F09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F09u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F09u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F09 LDA
    cpu.setA(0x42u, 8);
    goto L_809F0B;
L_809F0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Bu, 4u, 3u, cpu.address("abs", 0x2131u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F0B STA
    hw.write(cpu.address("abs", 0x2131u), cpu.a, cpu.m8?8:16);
    goto L_809F0E;
L_809F0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F0E LDA
    cpu.setA(0x2u, 8);
    goto L_809F10;
L_809F10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F10u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F10u, 4u, 3u, cpu.address("abs", 0x2130u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F10 STA
    hw.write(cpu.address("abs", 0x2130u), cpu.a, cpu.m8?8:16);
    goto L_809F13;
L_809F13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F13u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F13u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F13 REP
    cpu.rep(0x20u);
    goto L_809F15;
L_809F15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F15u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F15u, 8u, 4u, 0x80A4A3u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $809F15 JSL -> $80A4A3 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9F18u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9F19u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A4A3u, 0x809F15u); }
    goto L_809F19;
L_809F19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F19u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F19u,0x809F19u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F19u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F19u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $809F19 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x809F19u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x809F19u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80A6FB_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80A6FBu: goto L_80A6FB;
    case 0x80A6FCu: goto L_80A6FC;
    case 0x80A6FDu: goto L_80A6FD;
    case 0x80A6FFu: goto L_80A6FF;
    case 0x80A700u: goto L_80A700;
    case 0x80A703u: goto L_80A703;
    case 0x80A705u: goto L_80A705;
    case 0x80A707u: goto L_80A707;
    case 0x80A709u: goto L_80A709;
    case 0x80A70Au: goto L_80A70A;
    case 0x80A70Du: goto L_80A70D;
    case 0x80A70Fu: goto L_80A70F;
    case 0x80A711u: goto L_80A711;
    case 0x80A713u: goto L_80A713;
    case 0x80A715u: goto L_80A715;
    case 0x80A717u: goto L_80A717;
    case 0x80A719u: goto L_80A719;
    case 0x80A71Bu: goto L_80A71B;
    case 0x80A71Eu: goto L_80A71E;
    case 0x80A71Fu: goto L_80A71F;
    case 0x80A721u: goto L_80A721;
    case 0x80A722u: goto L_80A722;
    case 0x80A723u: goto L_80A723;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80A6FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FBu,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FBu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80A6FB PHX
    cpu.push("PHX", hw);
    goto L_80A6FC;
L_80A6FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FCu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FCu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A6FC PHP
    cpu.push("PHP", hw);
    goto L_80A6FD;
L_80A6FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FDu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A6FD SEP
    cpu.sep(0x20u);
    goto L_80A6FF;
L_80A6FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FFu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FFu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A6FF PHA
    cpu.push("PHA", hw);
    goto L_80A700;
L_80A700:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA700u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA700u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA700u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A700 LDX
    cpu.setX(0x0u, 16);
    goto L_80A703;
L_80A703:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA703u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA703u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA703u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xDDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A703 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xDDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A705;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA703u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA703u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xDDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A703 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xDDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A705;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA703u,0x80A703u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A705:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA705u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA705u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA705u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A705 CMP
    cpu.compareA(0xFFu);
    goto L_80A707;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA705u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA705u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A705 CMP
    cpu.compareA(0xFFu);
    goto L_80A707;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA705u,0x80A705u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A707:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA707u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA707u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA707u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A707 BEQ -> $80A71E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80A71E; }
    goto L_80A709;
L_80A709:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA709u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA709u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA709u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A709 INX
    cpu.inc('X');
    goto L_80A70A;
L_80A70A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA70Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Au,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A70A CPX
    cpu.compareX(0x4u);
    goto L_80A70D;
L_80A70D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA70Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Du,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A70D BCC -> $80A703
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80A703; }
    goto L_80A70F;
L_80A70F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA70Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A70F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A711;
L_80A711:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA711u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA711u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA711u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A711 STA
    hw.write(cpu.address("dp", 0xDDu), cpu.a, cpu.m8?8:16);
    goto L_80A713;
L_80A713:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA713u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA713u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA713u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A713 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A715;
L_80A715:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA715u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA715u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA715u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A715 STA
    hw.write(cpu.address("dp", 0xDEu), cpu.a, cpu.m8?8:16);
    goto L_80A717;
L_80A717:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA717u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA717u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA717u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xE0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A717 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xE0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A719;
L_80A719:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA719u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA719u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA719u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A719 STA
    hw.write(cpu.address("dp", 0xDFu), cpu.a, cpu.m8?8:16);
    goto L_80A71B;
L_80A71B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA71Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA71Bu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA71Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A71B LDX
    cpu.setX(0x3u, 16);
    goto L_80A71E;
L_80A71E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA71Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA71Eu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA71Eu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A71E PLA
    cpu.pop("PLA", hw);
    goto L_80A71F;
L_80A71F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA71Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA71Fu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA71Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xDDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A71F STA
    hw.write(cpu.address("dpx", 0xDDu), cpu.a, cpu.m8?8:16);
    goto L_80A721;
L_80A721:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA721u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA721u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA721u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A721 PLP
    cpu.pop("PLP", hw);
    goto L_80A722;
L_80A722:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA722u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA722u,0x80A722u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA722u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA722u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80A722 PLX
    cpu.pop("PLX", hw);
    goto L_80A723;
L_80A723:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA723u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA723u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA723u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A723 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80A723u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80A723u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80A6FB_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80A6FBu: goto L_80A6FB;
    case 0x80A6FCu: goto L_80A6FC;
    case 0x80A6FDu: goto L_80A6FD;
    case 0x80A6FFu: goto L_80A6FF;
    case 0x80A700u: goto L_80A700;
    case 0x80A703u: goto L_80A703;
    case 0x80A705u: goto L_80A705;
    case 0x80A707u: goto L_80A707;
    case 0x80A709u: goto L_80A709;
    case 0x80A70Au: goto L_80A70A;
    case 0x80A70Du: goto L_80A70D;
    case 0x80A70Fu: goto L_80A70F;
    case 0x80A711u: goto L_80A711;
    case 0x80A713u: goto L_80A713;
    case 0x80A715u: goto L_80A715;
    case 0x80A717u: goto L_80A717;
    case 0x80A719u: goto L_80A719;
    case 0x80A71Bu: goto L_80A71B;
    case 0x80A71Eu: goto L_80A71E;
    case 0x80A71Fu: goto L_80A71F;
    case 0x80A721u: goto L_80A721;
    case 0x80A722u: goto L_80A722;
    case 0x80A723u: goto L_80A723;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80A6FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FBu,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FBu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80A6FB PHX
    cpu.push("PHX", hw);
    goto L_80A6FC;
L_80A6FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FCu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FCu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A6FC PHP
    cpu.push("PHP", hw);
    goto L_80A6FD;
L_80A6FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FDu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A6FD SEP
    cpu.sep(0x20u);
    goto L_80A6FF;
L_80A6FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FFu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FFu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A6FF PHA
    cpu.push("PHA", hw);
    goto L_80A700;
L_80A700:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA700u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA700u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA700u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A700 LDX
    cpu.setX(0x0u, 16);
    goto L_80A703;
L_80A703:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA703u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA703u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA703u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xDDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A703 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xDDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A705;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA703u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA703u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xDDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A703 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xDDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A705;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA703u,0x80A703u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A705:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA705u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA705u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA705u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A705 CMP
    cpu.compareA(0xFFu);
    goto L_80A707;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA705u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA705u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A705 CMP
    cpu.compareA(0xFFu);
    goto L_80A707;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA705u,0x80A705u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A707:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA707u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA707u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA707u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A707 BEQ -> $80A71E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80A71E; }
    goto L_80A709;
L_80A709:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA709u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA709u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA709u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A709 INX
    cpu.inc('X');
    goto L_80A70A;
L_80A70A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA70Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Au,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A70A CPX
    cpu.compareX(0x4u);
    goto L_80A70D;
L_80A70D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA70Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Du,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A70D BCC -> $80A703
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80A703; }
    goto L_80A70F;
L_80A70F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA70Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A70F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A711;
L_80A711:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA711u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA711u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA711u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A711 STA
    hw.write(cpu.address("dp", 0xDDu), cpu.a, cpu.m8?8:16);
    goto L_80A713;
L_80A713:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA713u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA713u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA713u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A713 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A715;
L_80A715:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA715u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA715u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA715u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A715 STA
    hw.write(cpu.address("dp", 0xDEu), cpu.a, cpu.m8?8:16);
    goto L_80A717;
L_80A717:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA717u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA717u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA717u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xE0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A717 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xE0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A719;
L_80A719:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA719u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA719u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA719u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A719 STA
    hw.write(cpu.address("dp", 0xDFu), cpu.a, cpu.m8?8:16);
    goto L_80A71B;
L_80A71B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA71Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA71Bu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA71Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A71B LDX
    cpu.setX(0x3u, 16);
    goto L_80A71E;
L_80A71E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA71Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA71Eu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA71Eu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A71E PLA
    cpu.pop("PLA", hw);
    goto L_80A71F;
L_80A71F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA71Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA71Fu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA71Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xDDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A71F STA
    hw.write(cpu.address("dpx", 0xDDu), cpu.a, cpu.m8?8:16);
    goto L_80A721;
L_80A721:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA721u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA721u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA721u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A721 PLP
    cpu.pop("PLP", hw);
    goto L_80A722;
L_80A722:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA722u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA722u,0x80A722u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA722u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA722u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80A722 PLX
    cpu.pop("PLX", hw);
    goto L_80A723;
L_80A723:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA723u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA723u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA723u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A723 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80A723u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80A723u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80A6FB_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80A6FBu: goto L_80A6FB;
    case 0x80A6FCu: goto L_80A6FC;
    case 0x80A6FDu: goto L_80A6FD;
    case 0x80A6FFu: goto L_80A6FF;
    case 0x80A700u: goto L_80A700;
    case 0x80A703u: goto L_80A703;
    case 0x80A705u: goto L_80A705;
    case 0x80A707u: goto L_80A707;
    case 0x80A709u: goto L_80A709;
    case 0x80A70Au: goto L_80A70A;
    case 0x80A70Du: goto L_80A70D;
    case 0x80A70Fu: goto L_80A70F;
    case 0x80A711u: goto L_80A711;
    case 0x80A713u: goto L_80A713;
    case 0x80A715u: goto L_80A715;
    case 0x80A717u: goto L_80A717;
    case 0x80A719u: goto L_80A719;
    case 0x80A71Bu: goto L_80A71B;
    case 0x80A71Eu: goto L_80A71E;
    case 0x80A71Fu: goto L_80A71F;
    case 0x80A721u: goto L_80A721;
    case 0x80A722u: goto L_80A722;
    case 0x80A723u: goto L_80A723;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80A6FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FBu,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FBu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80A6FB PHX
    cpu.push("PHX", hw);
    goto L_80A6FC;
L_80A6FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FCu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FCu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A6FC PHP
    cpu.push("PHP", hw);
    goto L_80A6FD;
L_80A6FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FDu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A6FD SEP
    cpu.sep(0x20u);
    goto L_80A6FF;
L_80A6FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FFu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FFu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A6FF PHA
    cpu.push("PHA", hw);
    goto L_80A700;
L_80A700:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA700u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA700u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA700u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A700 LDX
    cpu.setX(0x0u, 16);
    goto L_80A703;
L_80A703:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA703u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA703u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA703u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xDDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A703 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xDDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A705;
L_80A705:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA705u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA705u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA705u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A705 CMP
    cpu.compareA(0xFFu);
    goto L_80A707;
L_80A707:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA707u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA707u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA707u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A707 BEQ -> $80A71E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80A71E; }
    goto L_80A709;
L_80A709:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA709u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA709u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA709u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A709 INX
    cpu.inc('X');
    goto L_80A70A;
L_80A70A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA70Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Au,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A70A CPX
    cpu.compareX(0x4u);
    goto L_80A70D;
L_80A70D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA70Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Du,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A70D BCC -> $80A703
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80A703; }
    goto L_80A70F;
L_80A70F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA70Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A70F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A711;
L_80A711:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA711u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA711u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA711u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A711 STA
    hw.write(cpu.address("dp", 0xDDu), cpu.a, cpu.m8?8:16);
    goto L_80A713;
L_80A713:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA713u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA713u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA713u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A713 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A715;
L_80A715:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA715u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA715u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA715u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A715 STA
    hw.write(cpu.address("dp", 0xDEu), cpu.a, cpu.m8?8:16);
    goto L_80A717;
L_80A717:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA717u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA717u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA717u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xE0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A717 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xE0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A719;
L_80A719:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA719u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA719u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA719u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A719 STA
    hw.write(cpu.address("dp", 0xDFu), cpu.a, cpu.m8?8:16);
    goto L_80A71B;
L_80A71B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA71Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA71Bu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA71Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A71B LDX
    cpu.setX(0x3u, 16);
    goto L_80A71E;
L_80A71E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA71Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA71Eu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA71Eu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A71E PLA
    cpu.pop("PLA", hw);
    goto L_80A71F;
L_80A71F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA71Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA71Fu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA71Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xDDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A71F STA
    hw.write(cpu.address("dpx", 0xDDu), cpu.a, cpu.m8?8:16);
    goto L_80A721;
L_80A721:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA721u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA721u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA721u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A721 PLP
    cpu.pop("PLP", hw);
    goto L_80A722;
L_80A722:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA722u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA722u,0x80A722u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA722u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA722u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80A722 PLX
    cpu.pop("PLX", hw);
    goto L_80A723;
L_80A723:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA723u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA723u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA723u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A723 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80A723u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80A723u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80AB6F_E0M1X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80AB6Fu: goto L_80AB6F;
    case 0x80AB71u: goto L_80AB71;
    case 0x80AB73u: goto L_80AB73;
    case 0x80AB75u: goto L_80AB75;
    case 0x80AB76u: goto L_80AB76;
    case 0x80AB78u: goto L_80AB78;
    case 0x80AB7Cu: goto L_80AB7C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80AB6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB6Fu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB6Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB6F SEP
    cpu.sep(0x20u);
    goto L_80AB71;
L_80AB71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB71u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB71u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB71 INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_80AB73;
L_80AB73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB73u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB73u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB73 LDA
    cpu.setA(0x82u, 8);
    goto L_80AB75;
L_80AB75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB75u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB75u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB75 XBA
    cpu.xba();
    goto L_80AB76;
L_80AB76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB76u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB76u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB76 LDA
    cpu.setA(0xFu, 8);
    goto L_80AB78;
L_80AB78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB78u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB78u, 8u, 4u, 0x8086F4u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AB78 JSL -> $8086F4 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAB7Bu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAB7Cu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8086F4u, 0x80AB78u); }
    goto L_80AB7C;
L_80AB7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB7Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAB7Cu,0x80AB7Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB7Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB7Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AB7C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80AB7Cu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80AB7Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80AB6F_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80AB6Fu: goto L_80AB6F;
    case 0x80AB71u: goto L_80AB71;
    case 0x80AB73u: goto L_80AB73;
    case 0x80AB75u: goto L_80AB75;
    case 0x80AB76u: goto L_80AB76;
    case 0x80AB78u: goto L_80AB78;
    case 0x80AB7Cu: goto L_80AB7C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80AB6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB6Fu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB6Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB6F SEP
    cpu.sep(0x20u);
    goto L_80AB71;
L_80AB71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB71u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB71u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB71 INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_80AB73;
L_80AB73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB73u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB73u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB73 LDA
    cpu.setA(0x82u, 8);
    goto L_80AB75;
L_80AB75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB75u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB75u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB75 XBA
    cpu.xba();
    goto L_80AB76;
L_80AB76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB76u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB76u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB76 LDA
    cpu.setA(0xFu, 8);
    goto L_80AB78;
L_80AB78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB78u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB78u, 8u, 4u, 0x8086F4u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AB78 JSL -> $8086F4 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAB7Bu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAB7Cu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8086F4u, 0x80AB78u); }
    goto L_80AB7C;
L_80AB7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB7Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAB7Cu,0x80AB7Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB7Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB7Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AB7C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80AB7Cu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80AB7Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80B246_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B246u: goto L_80B246;
    case 0x80B249u: goto L_80B249;
    case 0x80B24Bu: goto L_80B24B;
    case 0x80B24Eu: goto L_80B24E;
    case 0x80B250u: goto L_80B250;
    case 0x80B253u: goto L_80B253;
    case 0x80B255u: goto L_80B255;
    case 0x80B258u: goto L_80B258;
    case 0x80B25Bu: goto L_80B25B;
    case 0x80B25Eu: goto L_80B25E;
    case 0x80B261u: goto L_80B261;
    case 0x80B264u: goto L_80B264;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B246:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB246u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB246u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB246u, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B246 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x958u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B249;
L_80B249:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB249u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB249u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB249u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B249 BEQ -> $80B25E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B25E; }
    goto L_80B24B;
L_80B24B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB24Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB24Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB24Bu, 5u, 3u, cpu.address("abs", 0x098Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B24B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x98Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B24E;
L_80B24E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB24Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB24Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB24Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B24E BEQ -> $80B25E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B25E; }
    goto L_80B250;
L_80B250:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB250u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB250u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB250u, 5u, 3u, cpu.address("abs", 0x0916u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B250 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x916u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B253;
L_80B253:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB253u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB253u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB253u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B253 BEQ -> $80B25E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B25E; }
    goto L_80B255;
L_80B255:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB255u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB255u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB255u, 5u, 3u, cpu.address("abs", 0x097Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B255 STA
    hw.write(cpu.address("abs", 0x97Au), cpu.a, cpu.m8?8:16);
    goto L_80B258;
L_80B258:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB258u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB258u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB258u, 8u, 3u, cpu.address("abs", 0x0986u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B258 INC
    cpu.incMem(hw, cpu.address("abs", 0x986u), cpu.m8?8:16);
    goto L_80B25B;
L_80B25B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB25Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB25Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB25Bu, 6u, 3u, cpu.address("abs", 0xCE62u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B25B JSR -> $80CE62 stack real
    { cpu.push16Value(hw,0xB25Du); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB25Eu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCE62u), 0x80B25Bu); }
    goto L_80B25E;
L_80B25E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB25Eu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB25Eu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB25Eu, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B25E STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80B261;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB25Eu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB25Eu, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B25E STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80B261;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB25Eu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB25Eu, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B25E STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80B261;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB25Eu,0x80B25Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B261:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB261u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB261u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB261u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B261 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B264;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB261u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB261u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B261 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B264;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB261u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB261u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B261 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B264;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB261u,0x80B261u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B264:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB264u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB264u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB264u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B264 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B264u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B264u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB264u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB264u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B264 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B264u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B264u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB264u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB264u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B264 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B264u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B264u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB264u,0x80B264u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80B7A9_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B7A9u: goto L_80B7A9;
    case 0x80B7ACu: goto L_80B7AC;
    case 0x80B7AFu: goto L_80B7AF;
    case 0x80B7B2u: goto L_80B7B2;
    case 0x80B7B5u: goto L_80B7B5;
    case 0x80B7B6u: goto L_80B7B6;
    case 0x80B7B7u: goto L_80B7B7;
    case 0x80B7BAu: goto L_80B7BA;
    case 0x80B7BBu: goto L_80B7BB;
    case 0x80B7BEu: goto L_80B7BE;
    case 0x80B7BFu: goto L_80B7BF;
    case 0x80B7C2u: goto L_80B7C2;
    case 0x80B7C5u: goto L_80B7C5;
    case 0x80B7C7u: goto L_80B7C7;
    case 0x80B7CAu: goto L_80B7CA;
    case 0x80B7CBu: goto L_80B7CB;
    case 0x80B7CEu: goto L_80B7CE;
    case 0x80B7D1u: goto L_80B7D1;
    case 0x80B7D3u: goto L_80B7D3;
    case 0x80B7D6u: goto L_80B7D6;
    case 0x80B7D8u: goto L_80B7D8;
    case 0x80B7DAu: goto L_80B7DA;
    case 0x80B7DDu: goto L_80B7DD;
    case 0x80B7E0u: goto L_80B7E0;
    case 0x80B7E2u: goto L_80B7E2;
    case 0x80B7E5u: goto L_80B7E5;
    case 0x80B7E8u: goto L_80B7E8;
    case 0x80B7EBu: goto L_80B7EB;
    case 0x80B7EEu: goto L_80B7EE;
    case 0x80B7F1u: goto L_80B7F1;
    case 0x80B7F4u: goto L_80B7F4;
    case 0x80B7F6u: goto L_80B7F6;
    case 0x80B7F9u: goto L_80B7F9;
    case 0x80B7FBu: goto L_80B7FB;
    case 0x80B7FEu: goto L_80B7FE;
    case 0x80B801u: goto L_80B801;
    case 0x80B803u: goto L_80B803;
    case 0x80B806u: goto L_80B806;
    case 0x80B808u: goto L_80B808;
    case 0x80B80Au: goto L_80B80A;
    case 0x80B80Cu: goto L_80B80C;
    case 0x80B80Fu: goto L_80B80F;
    case 0x80B811u: goto L_80B811;
    case 0x80B814u: goto L_80B814;
    case 0x80B817u: goto L_80B817;
    case 0x80B818u: goto L_80B818;
    case 0x80B81Bu: goto L_80B81B;
    case 0x80B81Eu: goto L_80B81E;
    case 0x80B81Fu: goto L_80B81F;
    case 0x80B822u: goto L_80B822;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B7A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7A9u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7A9u, 5u, 3u, cpu.address("abs", 0x0922u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B7A9 STZ
    hw.write(cpu.address("abs", 0x922u), 0, cpu.m8?8:16);
    goto L_80B7AC;
L_80B7AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7ACu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7ACu, 5u, 3u, cpu.address("abs", 0x0924u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B7AC STZ
    hw.write(cpu.address("abs", 0x924u), 0, cpu.m8?8:16);
    goto L_80B7AF;
L_80B7AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7AFu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7AFu, 5u, 3u, cpu.address("abs", 0x091Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B7AF LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x91Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80B7B2;
L_80B7B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7B2u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7B2u, 5u, 3u, cpu.address("abs", 0x091Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B7B2 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x91Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B7B5;
L_80B7B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7B5u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7B5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B7B5 ASL
    cpu.aslA();
    goto L_80B7B6;
L_80B7B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7B6u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7B6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B7B6 CLC
    cpu.setFlag('C', false);
    goto L_80B7B7;
L_80B7B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7B7u,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7B7u, 5u, 3u, cpu.address("abs", 0x091Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B7B7 ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x91Eu), cpu.m8?8:16));
    goto L_80B7BA;
L_80B7BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7BAu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7BAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B7BA TAY
    cpu.transfer("TAY");
    goto L_80B7BB;
L_80B7BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7BBu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7BBu, 5u + 1u, 3u, cpu.address("absy", 0x030Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B7BB LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x30Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B7BE;
L_80B7BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7BEu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7BEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B7BE CLC
    cpu.setFlag('C', false);
    goto L_80B7BF;
L_80B7BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7BFu,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7BFu, 5u + 1u, 3u, cpu.address("absx", 0x0376u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B7BF ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x376u), cpu.m8?8:16));
    goto L_80B7C2;
L_80B7C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7C2u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7C2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B7C2 AND
    cpu.logicAnd(0xFFu);
    goto L_80B7C5;
L_80B7C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7C5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7C5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B7C5 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80B7C7;
L_80B7C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7C7u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7C7u, 5u + 1u, 3u, cpu.address("absy", 0x030Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B7C7 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x30Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B7CA;
L_80B7CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7CAu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7CAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B7CA CLC
    cpu.setFlag('C', false);
    goto L_80B7CB;
L_80B7CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7CBu,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7CBu, 5u + 1u, 3u, cpu.address("absx", 0x037Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B7CB ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x37Eu), cpu.m8?8:16));
    goto L_80B7CE;
L_80B7CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7CEu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7CEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B7CE AND
    cpu.logicAnd(0xFFu);
    goto L_80B7D1;
L_80B7D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7D1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7D1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B7D1 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_80B7D3;
L_80B7D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7D3u,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7D3u, 5u, 3u, cpu.address("abs", 0x091Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B7D3 CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x91Cu), cpu.m8?8:16));
    goto L_80B7D6;
L_80B7D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7D6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7D6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B7D6 BEQ -> $80B7DD
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B7DD; }
    goto L_80B7D8;
L_80B7D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7D8u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7D8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B7D8 BCC -> $80B7DD
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B7DD; }
    goto L_80B7DA;
L_80B7DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7DAu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7DAu, 6u, 3u, cpu.address("abs", 0xB9D9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B7DA JSR -> $80B9D9 stack real
    { cpu.push16Value(hw,0xB7DCu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB7DDu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB9D9u), 0x80B7DAu); }
    goto L_80B7DD;
L_80B7DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7DDu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB7DDu,0x80B7DDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7DDu,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7DDu, 5u, 3u, cpu.address("abs", 0x094Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B7DD CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x94Cu), cpu.m8?8:16));
    goto L_80B7E0;
L_80B7E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7E0u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7E0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B7E0 BEQ -> $80B7F1
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B7F1; }
    goto L_80B7E2;
L_80B7E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7E2u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7E2u, 5u, 3u, cpu.address("abs", 0x094Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B7E2 STZ
    hw.write(cpu.address("abs", 0x94Au), 0, cpu.m8?8:16);
    goto L_80B7E5;
L_80B7E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7E5u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7E5u, 5u, 3u, cpu.address("abs", 0x0948u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B7E5 STZ
    hw.write(cpu.address("abs", 0x948u), 0, cpu.m8?8:16);
    goto L_80B7E8;
L_80B7E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7E8u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7E8u, 5u, 3u, cpu.address("abs", 0x0950u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B7E8 STZ
    hw.write(cpu.address("abs", 0x950u), 0, cpu.m8?8:16);
    goto L_80B7EB;
L_80B7EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7EBu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7EBu, 5u, 3u, cpu.address("abs", 0x0994u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B7EB STZ
    hw.write(cpu.address("abs", 0x994u), 0, cpu.m8?8:16);
    goto L_80B7EE;
L_80B7EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7EEu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7EEu, 5u, 3u, cpu.address("abs", 0x0996u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B7EE STZ
    hw.write(cpu.address("abs", 0x996u), 0, cpu.m8?8:16);
    goto L_80B7F1;
L_80B7F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7F1u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7F1u, 5u, 3u, cpu.address("abs", 0x094Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B7F1 STA
    hw.write(cpu.address("abs", 0x94Cu), cpu.a, cpu.m8?8:16);
    goto L_80B7F4;
L_80B7F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7F4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7F4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B7F4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B7F6;
L_80B7F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7F6u,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7F6u, 5u, 3u, cpu.address("abs", 0x091Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B7F6 CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x91Au), cpu.m8?8:16));
    goto L_80B7F9;
L_80B7F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7F9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7F9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B7F9 BEQ -> $80B81F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B81F; }
    goto L_80B7FB;
L_80B7FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7FBu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7FBu, 5u, 3u, cpu.address("abs", 0x0994u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B7FB LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x994u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B7FE;
L_80B7FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7FEu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7FEu, 5u, 3u, cpu.address("abs", 0x0996u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B7FE ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x996u), cpu.m8?8:16));
    goto L_80B801;
L_80B801:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB801u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB801u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB801u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B801 BEQ -> $80B80A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B80A; }
    goto L_80B803;
L_80B803:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB803u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB803u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB803u, 5u, 3u, cpu.address("abs", 0x0994u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B803 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x994u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B806;
L_80B806:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB806u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB806u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB806u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B806 BEQ -> $80B818
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B818; }
    goto L_80B808;
L_80B808:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB808u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB808u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB808u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B808 BRA -> $80B811
    goto L_80B811;
L_80B80A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB80Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB80Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB80Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B80A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B80C;
L_80B80C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB80Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB80Cu,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB80Cu, 5u, 3u, cpu.address("abs", 0x091Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B80C CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x91Au), cpu.m8?8:16));
    goto L_80B80F;
L_80B80F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB80Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB80Fu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB80Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B80F BCS -> $80B818
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B818; }
    goto L_80B811;
L_80B811:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB811u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB811u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB811u, 8u, 3u, cpu.address("abs", 0x0994u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B811 INC
    cpu.incMem(hw, cpu.address("abs", 0x994u), cpu.m8?8:16);
    goto L_80B814;
L_80B814:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB814u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB814u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB814u, 6u, 3u, cpu.address("abs", 0xB882u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B814 JSR -> $80B882 stack real
    { cpu.push16Value(hw,0xB816u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB817u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB882u), 0x80B814u); }
    goto L_80B817;
L_80B817:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB817u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB817u,0x80B817u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB817u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB817u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B817 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B817u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B817u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80B818:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB818u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB818u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB818u, 8u, 3u, cpu.address("abs", 0x0996u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B818 INC
    cpu.incMem(hw, cpu.address("abs", 0x996u), cpu.m8?8:16);
    goto L_80B81B;
L_80B81B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB81Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB81Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB81Bu, 6u, 3u, cpu.address("abs", 0xB855u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B81B JSR -> $80B855 stack real
    { cpu.push16Value(hw,0xB81Du); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB81Eu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB855u), 0x80B81Bu); }
    goto L_80B81E;
L_80B81E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB81Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB81Eu,0x80B81Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB81Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB81Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B81E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B81Eu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B81Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80B81F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB81Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB81Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB81Fu, 6u, 3u, cpu.address("abs", 0xB8AFu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B81F JSR -> $80B8AF stack real
    { cpu.push16Value(hw,0xB821u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB822u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB8AFu), 0x80B81Fu); }
    goto L_80B822;
L_80B822:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB822u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB822u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB822u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B822 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B822u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B822u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB822u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB822u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B822 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B822u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B822u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB822u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB822u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B822 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B822u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B822u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB822u,0x80B822u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80BA9F_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80BA9Fu: goto L_80BA9F;
    case 0x80BAA2u: goto L_80BAA2;
    case 0x80BAA5u: goto L_80BAA5;
    case 0x80BAA7u: goto L_80BAA7;
    case 0x80BAAAu: goto L_80BAAA;
    case 0x80BAACu: goto L_80BAAC;
    case 0x80BAAFu: goto L_80BAAF;
    case 0x80BAB0u: goto L_80BAB0;
    case 0x80BAB3u: goto L_80BAB3;
    case 0x80BAB6u: goto L_80BAB6;
    case 0x80BAB7u: goto L_80BAB7;
    case 0x80BAB9u: goto L_80BAB9;
    case 0x80BABCu: goto L_80BABC;
    case 0x80BABFu: goto L_80BABF;
    case 0x80BAC0u: goto L_80BAC0;
    case 0x80BAC2u: goto L_80BAC2;
    case 0x80BAC4u: goto L_80BAC4;
    case 0x80BAC5u: goto L_80BAC5;
    case 0x80BAC7u: goto L_80BAC7;
    case 0x80BAC9u: goto L_80BAC9;
    case 0x80BACAu: goto L_80BACA;
    case 0x80BACDu: goto L_80BACD;
    case 0x80BAD0u: goto L_80BAD0;
    case 0x80BAD2u: goto L_80BAD2;
    case 0x80BAD3u: goto L_80BAD3;
    case 0x80BAD6u: goto L_80BAD6;
    case 0x80BAD9u: goto L_80BAD9;
    case 0x80BADCu: goto L_80BADC;
    case 0x80BADFu: goto L_80BADF;
    case 0x80BAE0u: goto L_80BAE0;
    case 0x80BAE3u: goto L_80BAE3;
    case 0x80BAE6u: goto L_80BAE6;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80BA9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA9Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA9Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA9F LDA
    cpu.setA(0x30u, 16);
    goto L_80BAA2;
L_80BAA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAA2u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAA2u, 5u, 3u, cpu.address("abs", 0x0972u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAA2 STA
    hw.write(cpu.address("abs", 0x972u), cpu.a, cpu.m8?8:16);
    goto L_80BAA5;
L_80BAA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAA5u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAA5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAA5 STZ
    hw.write(cpu.address("dp", 0x5Fu), 0, cpu.m8?8:16);
    goto L_80BAA7;
L_80BAA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAA7u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAA7u, 5u, 3u, cpu.address("abs", 0x0500u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAA7 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x500u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BAAA;
L_80BAAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAAAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAAAu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAAAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAAA BEQ -> $80BAC7
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BAC7; }
    goto L_80BAAC;
L_80BAAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAACu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAACu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAACu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAAC LDA
    cpu.setA(0x8u, 16);
    goto L_80BAAF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAACu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAACu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAAC LDA
    cpu.setA(0x8u, 16);
    goto L_80BAAF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBAACu,0x80BAACu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BAAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAAFu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAAFu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAAFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAAF CLC
    cpu.setFlag('C', false);
    goto L_80BAB0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAAFu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAAFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAAF CLC
    cpu.setFlag('C', false);
    goto L_80BAB0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBAAFu,0x80BAAFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BAB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAB0u,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAB0u, 5u, 3u, cpu.address("abs", 0x0972u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAB0 ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x972u), cpu.m8?8:16));
    goto L_80BAB3;
L_80BAB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAB3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAB3u, 5u, 3u, cpu.address("abs", 0x0972u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAB3 STA
    hw.write(cpu.address("abs", 0x972u), cpu.a, cpu.m8?8:16);
    goto L_80BAB6;
L_80BAB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAB6u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAB6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAB6 DEX
    cpu.decReg('X');
    goto L_80BAB7;
L_80BAB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAB7u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAB7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAB7 BNE -> $80BAAC
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BAAC; }
    goto L_80BAB9;
L_80BAB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAB9u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAB9u, 5u, 3u, cpu.address("abs", 0x0500u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAB9 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x500u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BABC;
L_80BABC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBABCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBABCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBABCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BABC LDA
    cpu.setA(0x16u, 16);
    goto L_80BABF;
L_80BABF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBABFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBABFu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBABFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BABF CLC
    cpu.setFlag('C', false);
    goto L_80BAC0;
L_80BAC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAC0u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAC0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAC0 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16));
    goto L_80BAC2;
L_80BAC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAC2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAC2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAC2 STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_80BAC4;
L_80BAC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAC4u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAC4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAC4 DEX
    cpu.decReg('X');
    goto L_80BAC5;
L_80BAC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAC5u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAC5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAC5 BNE -> $80BABC
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BABC; }
    goto L_80BAC7;
L_80BAC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAC7u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAC7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAC7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAC7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BAC9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAC7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAC7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAC7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BAC9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBAC7u,0x80BAC7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BAC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAC9u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAC9u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAC9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAC9 CLC
    cpu.setFlag('C', false);
    goto L_80BACA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAC9u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAC9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAC9 CLC
    cpu.setFlag('C', false);
    goto L_80BACA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBAC9u,0x80BAC9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BACA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBACAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBACAu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBACAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BACA ADC
    cpu.adc(0x26Cu);
    goto L_80BACD;
L_80BACD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBACDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBACDu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBACDu, 5u, 3u, cpu.address("abs", 0x096Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BACD STA
    hw.write(cpu.address("abs", 0x96Cu), cpu.a, cpu.m8?8:16);
    goto L_80BAD0;
L_80BAD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAD0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAD0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAD0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAD0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BAD2;
L_80BAD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAD2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAD2u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAD2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAD2 CLC
    cpu.setFlag('C', false);
    goto L_80BAD3;
L_80BAD3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAD3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAD3u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAD3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAD3 ADC
    cpu.adc(0x262u);
    goto L_80BAD6;
L_80BAD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAD6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAD6u, 5u, 3u, cpu.address("abs", 0x096Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAD6 STA
    hw.write(cpu.address("abs", 0x96Eu), cpu.a, cpu.m8?8:16);
    goto L_80BAD9;
L_80BAD9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAD9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAD9u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAD9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAD9 LDX
    cpu.setX(0x100u, 16);
    goto L_80BADC;
L_80BADC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBADCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBADCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBADCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BADC LDA
    cpu.setA(0x14u, 16);
    goto L_80BADF;
L_80BADF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBADFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBADFu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBADFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BADF SEC
    cpu.setFlag('C', true);
    goto L_80BAE0;
L_80BAE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAE0u,cpu,0xFDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAE0u, 5u + 1u, 3u, cpu.address("absx", 0x0400u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAE0 SBC
    cpu.sbc(hw.readW(cpu.address("absx", 0x400u), cpu.m8?8:16));
    goto L_80BAE3;
L_80BAE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAE3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAE3u, 5u, 3u, cpu.address("abs", 0x0970u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAE3 STA
    hw.write(cpu.address("abs", 0x970u), cpu.a, cpu.m8?8:16);
    goto L_80BAE6;
L_80BAE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAE6u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAE6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BAE6 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80BAE6u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80BAE6u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80C302_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80C302u: goto L_80C302;
    case 0x80C305u: goto L_80C305;
    case 0x80C307u: goto L_80C307;
    case 0x80C30Au: goto L_80C30A;
    case 0x80C30Cu: goto L_80C30C;
    case 0x80C30Fu: goto L_80C30F;
    case 0x80C312u: goto L_80C312;
    case 0x80C315u: goto L_80C315;
    case 0x80C318u: goto L_80C318;
    case 0x80C31Bu: goto L_80C31B;
    case 0x80C31Eu: goto L_80C31E;
    case 0x80C321u: goto L_80C321;
    case 0x80C324u: goto L_80C324;
    case 0x80C327u: goto L_80C327;
    case 0x80C328u: goto L_80C328;
    case 0x80C32Bu: goto L_80C32B;
    case 0x80C32Eu: goto L_80C32E;
    case 0x80C331u: goto L_80C331;
    case 0x80C333u: goto L_80C333;
    case 0x80C336u: goto L_80C336;
    case 0x80C338u: goto L_80C338;
    case 0x80C33Bu: goto L_80C33B;
    case 0x80C33Du: goto L_80C33D;
    case 0x80C340u: goto L_80C340;
    case 0x80C343u: goto L_80C343;
    case 0x80C346u: goto L_80C346;
    case 0x80C349u: goto L_80C349;
    case 0x80C34Cu: goto L_80C34C;
    case 0x80C34Fu: goto L_80C34F;
    case 0x80C352u: goto L_80C352;
    case 0x80C355u: goto L_80C355;
    case 0x80C358u: goto L_80C358;
    case 0x80C359u: goto L_80C359;
    case 0x80C35Cu: goto L_80C35C;
    case 0x80C35Fu: goto L_80C35F;
    case 0x80C362u: goto L_80C362;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80C302:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC302u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC302u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC302u, 5u, 3u, cpu.address("abs", 0x0948u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C302 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x948u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C305;
L_80C305:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC305u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC305u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC305u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C305 BNE -> $80C333
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C333; }
    goto L_80C307;
L_80C307:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC307u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC307u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC307u, 5u, 3u, cpu.address("abs", 0x0942u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C307 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x942u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C30A;
L_80C30A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC30Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC30Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC30Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C30A BNE -> $80C333
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C333; }
    goto L_80C30C;
L_80C30C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC30Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC30Cu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC30Cu, 8u, 3u, cpu.address("abs", 0x0960u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C30C INC
    cpu.incMem(hw, cpu.address("abs", 0x960u), cpu.m8?8:16);
    goto L_80C30F;
L_80C30F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC30Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC30Fu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC30Fu, 8u, 3u, cpu.address("abs", 0x0960u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C30F INC
    cpu.incMem(hw, cpu.address("abs", 0x960u), cpu.m8?8:16);
    goto L_80C312;
L_80C312:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC312u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC312u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC312u, 8u, 3u, cpu.address("abs", 0x0962u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C312 INC
    cpu.incMem(hw, cpu.address("abs", 0x962u), cpu.m8?8:16);
    goto L_80C315;
L_80C315:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC315u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC315u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC315u, 8u, 3u, cpu.address("abs", 0x0962u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C315 INC
    cpu.incMem(hw, cpu.address("abs", 0x962u), cpu.m8?8:16);
    goto L_80C318;
L_80C318:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC318u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC318u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC318u, 8u, 3u, cpu.address("abs", 0x0964u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C318 INC
    cpu.incMem(hw, cpu.address("abs", 0x964u), cpu.m8?8:16);
    goto L_80C31B;
L_80C31B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC31Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC31Bu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC31Bu, 8u, 3u, cpu.address("abs", 0x0964u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C31B INC
    cpu.incMem(hw, cpu.address("abs", 0x964u), cpu.m8?8:16);
    goto L_80C31E;
L_80C31E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC31Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC31Eu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC31Eu, 8u, 3u, cpu.address("abs", 0x0966u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C31E INC
    cpu.incMem(hw, cpu.address("abs", 0x966u), cpu.m8?8:16);
    goto L_80C321;
L_80C321:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC321u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC321u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC321u, 8u, 3u, cpu.address("abs", 0x0966u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C321 INC
    cpu.incMem(hw, cpu.address("abs", 0x966u), cpu.m8?8:16);
    goto L_80C324;
L_80C324:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC324u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC324u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC324u, 5u, 3u, cpu.address("abs", 0x095Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C324 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x95Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C327;
L_80C327:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC327u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC327u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC327u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C327 CLC
    cpu.setFlag('C', false);
    goto L_80C328;
L_80C328:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC328u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC328u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC328u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C328 ADC
    cpu.adc(0x8u);
    goto L_80C32B;
L_80C32B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC32Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC32Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC32Bu, 5u, 3u, cpu.address("abs", 0x095Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C32B STA
    hw.write(cpu.address("abs", 0x95Cu), cpu.a, cpu.m8?8:16);
    goto L_80C32E;
L_80C32E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC32Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC32Eu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC32Eu, 8u, 3u, cpu.address("abs", 0x094Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C32E INC
    cpu.incMem(hw, cpu.address("abs", 0x94Au), cpu.m8?8:16);
    goto L_80C331;
L_80C331:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC331u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC331u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC331u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C331 BRA -> $80C362
    goto L_80C362;
L_80C333:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC333u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC333u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC333u, 5u, 3u, cpu.address("abs", 0x094Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C333 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x94Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C336;
L_80C336:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC336u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC336u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC336u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C336 BNE -> $80C362
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C362; }
    goto L_80C338;
L_80C338:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC338u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC338u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC338u, 5u, 3u, cpu.address("abs", 0x0944u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C338 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x944u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C33B;
L_80C33B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC33Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC33Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC33Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C33B BNE -> $80C362
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C362; }
    goto L_80C33D;
L_80C33D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC33Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC33Du,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC33Du, 8u, 3u, cpu.address("abs", 0x0960u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C33D DEC
    cpu.decMem(hw, cpu.address("abs", 0x960u), cpu.m8?8:16);
    goto L_80C340;
L_80C340:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC340u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC340u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC340u, 8u, 3u, cpu.address("abs", 0x0960u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C340 DEC
    cpu.decMem(hw, cpu.address("abs", 0x960u), cpu.m8?8:16);
    goto L_80C343;
L_80C343:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC343u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC343u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC343u, 8u, 3u, cpu.address("abs", 0x0962u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C343 DEC
    cpu.decMem(hw, cpu.address("abs", 0x962u), cpu.m8?8:16);
    goto L_80C346;
L_80C346:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC346u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC346u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC346u, 8u, 3u, cpu.address("abs", 0x0962u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C346 DEC
    cpu.decMem(hw, cpu.address("abs", 0x962u), cpu.m8?8:16);
    goto L_80C349;
L_80C349:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC349u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC349u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC349u, 8u, 3u, cpu.address("abs", 0x0964u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C349 DEC
    cpu.decMem(hw, cpu.address("abs", 0x964u), cpu.m8?8:16);
    goto L_80C34C;
L_80C34C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC34Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC34Cu,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC34Cu, 8u, 3u, cpu.address("abs", 0x0964u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C34C DEC
    cpu.decMem(hw, cpu.address("abs", 0x964u), cpu.m8?8:16);
    goto L_80C34F;
L_80C34F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC34Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC34Fu,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC34Fu, 8u, 3u, cpu.address("abs", 0x0966u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C34F DEC
    cpu.decMem(hw, cpu.address("abs", 0x966u), cpu.m8?8:16);
    goto L_80C352;
L_80C352:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC352u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC352u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC352u, 8u, 3u, cpu.address("abs", 0x0966u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C352 DEC
    cpu.decMem(hw, cpu.address("abs", 0x966u), cpu.m8?8:16);
    goto L_80C355;
L_80C355:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC355u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC355u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC355u, 5u, 3u, cpu.address("abs", 0x095Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C355 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x95Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C358;
L_80C358:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC358u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC358u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC358u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C358 SEC
    cpu.setFlag('C', true);
    goto L_80C359;
L_80C359:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC359u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC359u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC359u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C359 SBC
    cpu.sbc(0x8u);
    goto L_80C35C;
L_80C35C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC35Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC35Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC35Cu, 5u, 3u, cpu.address("abs", 0x095Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C35C STA
    hw.write(cpu.address("abs", 0x95Cu), cpu.a, cpu.m8?8:16);
    goto L_80C35F;
L_80C35F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC35Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC35Fu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC35Fu, 8u, 3u, cpu.address("abs", 0x0948u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C35F INC
    cpu.incMem(hw, cpu.address("abs", 0x948u), cpu.m8?8:16);
    goto L_80C362;
L_80C362:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC362u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC362u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC362u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80C362 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80C362u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80C362u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80D012_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80D012u: goto L_80D012;
    case 0x80D016u: goto L_80D016;
    case 0x80D018u: goto L_80D018;
    case 0x80D01Bu: goto L_80D01B;
    case 0x80D01Du: goto L_80D01D;
    case 0x80D01Eu: goto L_80D01E;
    case 0x80D01Fu: goto L_80D01F;
    case 0x80D021u: goto L_80D021;
    case 0x80D025u: goto L_80D025;
    case 0x80D028u: goto L_80D028;
    case 0x80D02Au: goto L_80D02A;
    case 0x80D02Bu: goto L_80D02B;
    case 0x80D02Cu: goto L_80D02C;
    case 0x80D02Du: goto L_80D02D;
    case 0x80D02Fu: goto L_80D02F;
    case 0x80D033u: goto L_80D033;
    case 0x80D035u: goto L_80D035;
    case 0x80D039u: goto L_80D039;
    case 0x80D03Cu: goto L_80D03C;
    case 0x80D040u: goto L_80D040;
    case 0x80D042u: goto L_80D042;
    case 0x80D044u: goto L_80D044;
    case 0x80D046u: goto L_80D046;
    case 0x80D048u: goto L_80D048;
    case 0x80D04Au: goto L_80D04A;
    case 0x80D04Cu: goto L_80D04C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80D012:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD012u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD012u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD012u, 6u, 4u, ((0x7E2002u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D012 LDA
    cpu.loadA(hw.readW(((0x7E2002u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D016;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD012u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD012u, 6u, 4u, ((0x7E2002u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D012 LDA
    cpu.loadA(hw.readW(((0x7E2002u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D016;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD012u,0x80D012u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D016:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD016u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD016u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD016u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D016 BEQ -> $80D021
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D021; }
    goto L_80D018;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD016u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD016u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D016 BEQ -> $80D021
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D021; }
    goto L_80D018;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD016u,0x80D016u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D018:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD018u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD018u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD018u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D018 CMP
    cpu.compareA(0xFFFFu);
    goto L_80D01B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD018u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD018u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D018 CMP
    cpu.compareA(0xFFFFu);
    goto L_80D01B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD018u,0x80D018u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D01B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD01Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD01Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD01Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D01B BEQ -> $80D04C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D04C; }
    goto L_80D01D;
L_80D01D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD01Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD01Du,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD01Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D01D INX
    cpu.inc('X');
    goto L_80D01E;
L_80D01E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD01Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD01Eu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD01Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D01E INX
    cpu.inc('X');
    goto L_80D01F;
L_80D01F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD01Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD01Fu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD01Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D01F BRA -> $80D012
    goto L_80D012;
L_80D021:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD021u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD021u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD021u, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D021 LDA
    cpu.loadA(hw.readW(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D025;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD021u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD021u, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D021 LDA
    cpu.loadA(hw.readW(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D025;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD021u,0x80D021u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D025:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD025u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD025u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD025u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D025 AND
    cpu.logicAnd(0x300u);
    goto L_80D028;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD025u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD025u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D025 AND
    cpu.logicAnd(0x300u);
    goto L_80D028;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD025u,0x80D025u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D028:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD028u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD028u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD028u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D028 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_80D02A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD028u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD028u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D028 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_80D02A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD028u,0x80D028u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D02A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD02Au))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD02Au,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD02Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D02A TXA
    cpu.transfer("TXA");
    goto L_80D02B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD02Au,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD02Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D02A TXA
    cpu.transfer("TXA");
    goto L_80D02B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD02Au,0x80D02Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D02B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD02Bu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD02Bu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD02Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D02B INC
    cpu.inc('A');
    goto L_80D02C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD02Bu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD02Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D02B INC
    cpu.inc('A');
    goto L_80D02C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD02Bu,0x80D02Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D02C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD02Cu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD02Cu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD02Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D02C INC
    cpu.inc('A');
    goto L_80D02D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD02Cu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD02Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D02C INC
    cpu.inc('A');
    goto L_80D02D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD02Cu,0x80D02Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D02D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD02Du))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD02Du,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD02Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D02D LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80D02F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD02Du,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD02Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D02D LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80D02F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD02Du,0x80D02Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D02F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD02Fu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD02Fu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD02Fu, 6u, 4u, ((0x7E2444u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D02F STA
    hw.write(((0x7E2444u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80D033;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD02Fu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD02Fu, 6u, 4u, ((0x7E2444u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D02F STA
    hw.write(((0x7E2444u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80D033;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD02Fu,0x80D02Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D033:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD033u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD033u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD033u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D033 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D035;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD033u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD033u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D033 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D035;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD033u,0x80D033u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D035:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD035u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD035u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD035u, 6u, 4u, ((0x7E2440u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D035 STA
    hw.write(((0x7E2440u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80D039;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD035u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD035u, 6u, 4u, ((0x7E2440u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D035 STA
    hw.write(((0x7E2440u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80D039;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD035u,0x80D035u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D039:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD039u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD039u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD039u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D039 LDA
    cpu.setA(0x2u, 16);
    goto L_80D03C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD039u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD039u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D039 LDA
    cpu.setA(0x2u, 16);
    goto L_80D03C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD039u,0x80D039u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D03C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD03Cu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD03Cu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD03Cu, 6u, 4u, ((0x7E2442u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D03C STA
    hw.write(((0x7E2442u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80D040;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD03Cu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD03Cu, 6u, 4u, ((0x7E2442u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D03C STA
    hw.write(((0x7E2442u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80D040;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD03Cu,0x80D03Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D040:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD040u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD040u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD040u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D040 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D042;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD040u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD040u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D040 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D042;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD040u,0x80D040u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D042:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD042u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD042u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD042u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D042 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D044;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD042u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD042u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D042 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D044;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD042u,0x80D042u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D044:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD044u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD044u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD044u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D044 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D046;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD044u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD044u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D044 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D046;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD044u,0x80D044u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D046:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD046u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD046u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD046u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D046 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D048;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD046u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD046u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D046 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D048;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD046u,0x80D046u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D048:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD048u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD048u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD048u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D048 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D04A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD048u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD048u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D048 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D04A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD048u,0x80D048u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D04A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD04Au))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD04Au,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD04Au, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D04A INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D04C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD04Au,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD04Au, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D04A INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D04C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD04Au,0x80D04Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D04C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD04Cu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD04Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD04Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D04C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80D04Cu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80D04Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD04Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD04Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D04C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80D04Cu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80D04Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD04Cu,0x80D04Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80D012_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80D012u: goto L_80D012;
    case 0x80D016u: goto L_80D016;
    case 0x80D018u: goto L_80D018;
    case 0x80D01Bu: goto L_80D01B;
    case 0x80D01Du: goto L_80D01D;
    case 0x80D01Eu: goto L_80D01E;
    case 0x80D01Fu: goto L_80D01F;
    case 0x80D021u: goto L_80D021;
    case 0x80D025u: goto L_80D025;
    case 0x80D028u: goto L_80D028;
    case 0x80D02Au: goto L_80D02A;
    case 0x80D02Bu: goto L_80D02B;
    case 0x80D02Cu: goto L_80D02C;
    case 0x80D02Du: goto L_80D02D;
    case 0x80D02Fu: goto L_80D02F;
    case 0x80D033u: goto L_80D033;
    case 0x80D035u: goto L_80D035;
    case 0x80D039u: goto L_80D039;
    case 0x80D03Cu: goto L_80D03C;
    case 0x80D040u: goto L_80D040;
    case 0x80D042u: goto L_80D042;
    case 0x80D044u: goto L_80D044;
    case 0x80D046u: goto L_80D046;
    case 0x80D048u: goto L_80D048;
    case 0x80D04Au: goto L_80D04A;
    case 0x80D04Cu: goto L_80D04C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80D012:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD012u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD012u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD012u, 6u, 4u, ((0x7E2002u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D012 LDA
    cpu.loadA(hw.readW(((0x7E2002u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D016;
L_80D016:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD016u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD016u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD016u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D016 BEQ -> $80D021
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D021; }
    goto L_80D018;
L_80D018:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD018u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD018u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD018u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D018 CMP
    cpu.compareA(0xFFFFu);
    goto L_80D01B;
L_80D01B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD01Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD01Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD01Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D01B BEQ -> $80D04C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D04C; }
    goto L_80D01D;
L_80D01D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD01Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD01Du,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD01Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D01D INX
    cpu.inc('X');
    goto L_80D01E;
L_80D01E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD01Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD01Eu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD01Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D01E INX
    cpu.inc('X');
    goto L_80D01F;
L_80D01F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD01Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD01Fu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD01Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D01F BRA -> $80D012
    goto L_80D012;
L_80D021:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD021u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD021u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD021u, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D021 LDA
    cpu.loadA(hw.readW(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D025;
L_80D025:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD025u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD025u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD025u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D025 AND
    cpu.logicAnd(0x300u);
    goto L_80D028;
L_80D028:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD028u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD028u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD028u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D028 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_80D02A;
L_80D02A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD02Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD02Au,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD02Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D02A TXA
    cpu.transfer("TXA");
    goto L_80D02B;
L_80D02B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD02Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD02Bu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD02Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D02B INC
    cpu.inc('A');
    goto L_80D02C;
L_80D02C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD02Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD02Cu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD02Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D02C INC
    cpu.inc('A');
    goto L_80D02D;
L_80D02D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD02Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD02Du,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD02Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D02D LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80D02F;
L_80D02F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD02Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD02Fu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD02Fu, 6u, 4u, ((0x7E2444u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D02F STA
    hw.write(((0x7E2444u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80D033;
L_80D033:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD033u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD033u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD033u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D033 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D035;
L_80D035:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD035u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD035u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD035u, 6u, 4u, ((0x7E2440u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D035 STA
    hw.write(((0x7E2440u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80D039;
L_80D039:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD039u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD039u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD039u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D039 LDA
    cpu.setA(0x2u, 16);
    goto L_80D03C;
L_80D03C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD03Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD03Cu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD03Cu, 6u, 4u, ((0x7E2442u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D03C STA
    hw.write(((0x7E2442u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80D040;
L_80D040:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD040u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD040u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD040u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D040 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D042;
L_80D042:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD042u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD042u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD042u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D042 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D044;
L_80D044:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD044u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD044u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD044u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D044 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D046;
L_80D046:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD046u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD046u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD046u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D046 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D048;
L_80D048:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD048u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD048u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD048u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D048 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D04A;
L_80D04A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD04Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD04Au,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD04Au, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D04A INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D04C;
L_80D04C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD04Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD04Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD04Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D04C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80D04Cu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80D04Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_8292A0_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8292A0u: goto L_8292A0;
    case 0x8292A2u: goto L_8292A2;
    case 0x8292A4u: goto L_8292A4;
    case 0x8292A6u: goto L_8292A6;
    case 0x8292A8u: goto L_8292A8;
    case 0x8292ABu: goto L_8292AB;
    case 0x8292AEu: goto L_8292AE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8292A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92A0u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92A0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292A0 SEP
    cpu.sep(0x20u);
    goto L_8292A2;
L_8292A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92A2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92A2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292A2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x75u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8292A4;
L_8292A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92A4u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92A4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292A4 BNE -> $8292AE
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8292AE; }
    goto L_8292A6;
L_8292A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92A6u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92A6u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292A6 INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_8292A8;
L_8292A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92A8u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92A8u, 4u, 3u, cpu.address("abs", 0x013Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292A8 STZ
    hw.write(cpu.address("abs", 0x13Bu), 0, cpu.m8?8:16);
    goto L_8292AB;
L_8292AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92ABu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92ABu, 4u, 3u, cpu.address("abs", 0x013Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292AB STZ
    hw.write(cpu.address("abs", 0x13Cu), 0, cpu.m8?8:16);
    goto L_8292AE;
L_8292AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92AEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92AEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8292AE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8292AEu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8292AEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_8293A0_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8293A0u: goto L_8293A0;
    case 0x8293A3u: goto L_8293A3;
    case 0x8293A6u: goto L_8293A6;
    case 0x8293A8u: goto L_8293A8;
    case 0x8293ABu: goto L_8293AB;
    case 0x8293ADu: goto L_8293AD;
    case 0x8293AFu: goto L_8293AF;
    case 0x8293B1u: goto L_8293B1;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8293A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93A0u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93A0u, 8u, 3u, cpu.address("abs", 0x014Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8293A0 INC
    cpu.incMem(hw, cpu.address("abs", 0x14Au), cpu.m8?8:16);
    goto L_8293A3;
L_8293A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93A3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93A3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8293A3 LDA
    cpu.setA(0x10u, 16);
    goto L_8293A6;
L_8293A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93A6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93A6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8293A6 STA
    hw.write(cpu.address("dp", 0x6Fu), cpu.a, cpu.m8?8:16);
    goto L_8293A8;
L_8293A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93A8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93A8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8293A8 LDA
    cpu.setA(0x8u, 16);
    goto L_8293AB;
L_8293AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93ABu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93ABu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x71u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8293AB STA
    hw.write(cpu.address("dp", 0x71u), cpu.a, cpu.m8?8:16);
    goto L_8293AD;
L_8293AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93ADu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93ADu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8293AD SEP
    cpu.sep(0x20u);
    goto L_8293AF;
L_8293AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93AFu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93AFu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8293AF INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_8293B1;
L_8293B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93B1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93B1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8293B1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8293B1u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8293B1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_8293B2_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8293B2u: goto L_8293B2;
    case 0x8293B5u: goto L_8293B5;
    case 0x8293B7u: goto L_8293B7;
    case 0x8293B9u: goto L_8293B9;
    case 0x8293BBu: goto L_8293BB;
    case 0x8293BDu: goto L_8293BD;
    case 0x8293BFu: goto L_8293BF;
    case 0x8293C1u: goto L_8293C1;
    case 0x8293C3u: goto L_8293C3;
    case 0x8293C6u: goto L_8293C6;
    case 0x8293C8u: goto L_8293C8;
    case 0x8293CBu: goto L_8293CB;
    case 0x8293CEu: goto L_8293CE;
    case 0x8293D0u: goto L_8293D0;
    case 0x8293D4u: goto L_8293D4;
    case 0x8293D7u: goto L_8293D7;
    case 0x8293D9u: goto L_8293D9;
    case 0x8293DBu: goto L_8293DB;
    case 0x8293DEu: goto L_8293DE;
    case 0x8293E1u: goto L_8293E1;
    case 0x8293E3u: goto L_8293E3;
    case 0x8293E5u: goto L_8293E5;
    case 0x8293E8u: goto L_8293E8;
    case 0x8293EAu: goto L_8293EA;
    case 0x8293ECu: goto L_8293EC;
    case 0x8293EEu: goto L_8293EE;
    case 0x8293EFu: goto L_8293EF;
    case 0x8293F1u: goto L_8293F1;
    case 0x8293F5u: goto L_8293F5;
    case 0x8293F7u: goto L_8293F7;
    case 0x8293F9u: goto L_8293F9;
    case 0x8293FAu: goto L_8293FA;
    case 0x8293FCu: goto L_8293FC;
    case 0x8293FEu: goto L_8293FE;
    case 0x829400u: goto L_829400;
    case 0x829402u: goto L_829402;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8293B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93B2u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93B2u, 8u, 3u, cpu.address("abs", 0x014Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8293B2 INC
    cpu.incMem(hw, cpu.address("abs", 0x14Au), cpu.m8?8:16);
    goto L_8293B5;
L_8293B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93B5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93B5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x71u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8293B5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x71u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8293B7;
L_8293B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93B7u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93B7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8293B7 BNE -> $8293BF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8293BF; }
    goto L_8293B9;
L_8293B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93B9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93B9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8293B9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8293BB;
L_8293BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93BBu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93BBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8293BB BEQ -> $8293BF
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8293BF; }
    goto L_8293BD;
L_8293BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93BDu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93BDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8293BD STZ
    hw.write(cpu.address("dp", 0x6Fu), 0, cpu.m8?8:16);
    goto L_8293BF;
L_8293BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93BFu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93BFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8293BF LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8293C1;
L_8293C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93C1u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93C1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8293C1 BNE -> $8293F9
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8293F9; }
    goto L_8293C3;
L_8293C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93C3u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93C3u, 5u, 3u, cpu.address("abs", 0x0177u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8293C3 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x177u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8293C6;
L_8293C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93C6u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93C6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8293C6 BNE -> $8293EA
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8293EA; }
    goto L_8293C8;
L_8293C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93C8u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93C8u, 8u, 3u, cpu.address("abs", 0x02CEu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8293C8 INC
    cpu.incMem(hw, cpu.address("abs", 0x2CEu), cpu.m8?8:16);
    goto L_8293CB;
L_8293CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93CBu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93CBu, 5u, 3u, cpu.address("abs", 0x02CEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8293CB LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2CEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8293CE;
L_8293CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93CEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93CEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8293CE STA
    hw.write(cpu.address("dp", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_8293D0;
L_8293D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93D0u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93D0u, 8u, 4u, 0x809315u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8293D0 JSL -> $809315 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x93D3u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x93D4u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809315u, 0x8293D0u); }
    goto L_8293D4;
L_8293D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93D4u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x93D4u,0x8293D4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93D4u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93D4u, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8293D4 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8293D7;
L_8293D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93D7u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93D7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8293D7 BNE -> $8293E3
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8293E3; }
    goto L_8293D9;
L_8293D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93D9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93D9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8293D9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8293DB;
L_8293DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93DBu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93DBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8293DB AND
    cpu.logicAnd(0xFFu);
    goto L_8293DE;
L_8293DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93DEu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93DEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8293DE CMP
    cpu.compareA(0x5u);
    goto L_8293E1;
L_8293E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93E1u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93E1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8293E1 BEQ -> $8293EA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8293EA; }
    goto L_8293E3;
L_8293E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93E3u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93E3u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93E3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8293E3 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8293E5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93E3u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93E3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8293E3 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8293E5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x93E3u,0x8293E3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8293E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93E5u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93E5u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93E5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8293E5 AND
    cpu.logicAnd(0xFFu);
    goto L_8293E8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93E5u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93E5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8293E5 AND
    cpu.logicAnd(0xFFu);
    goto L_8293E8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x93E5u,0x8293E5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8293E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93E8u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93E8u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93E8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8293E8 BNE -> $8293FA
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8293FA; }
    goto L_8293EA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93E8u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93E8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8293E8 BNE -> $8293FA
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8293FA; }
    goto L_8293EA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x93E8u,0x8293E8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8293EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93EAu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93EAu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93EAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8293EA SEP
    cpu.sep(0x20u);
    goto L_8293EC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93EAu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93EAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8293EA SEP
    cpu.sep(0x20u);
    goto L_8293EC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x93EAu,0x8293EAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8293EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93ECu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93ECu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93ECu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8293EC LDA
    cpu.setA(0x81u, 8);
    goto L_8293EE;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93ECu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93ECu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8293EC LDA
    cpu.setA(0x81u, 8);
    goto L_8293EE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x93ECu,0x8293ECu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8293EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93EEu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93EEu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93EEu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8293EE XBA
    cpu.xba();
    goto L_8293EF;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93EEu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93EEu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8293EE XBA
    cpu.xba();
    goto L_8293EF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x93EEu,0x8293EEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8293EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93EFu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93EFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93EFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8293EF LDA
    cpu.setA(0xFu, 8);
    goto L_8293F1;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93EFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93EFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8293EF LDA
    cpu.setA(0xFu, 8);
    goto L_8293F1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x93EFu,0x8293EFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8293F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93F1u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93F1u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93F1u, 8u, 4u, 0x8086F4u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8293F1 JSL -> $8086F4 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x93F4u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x93F5u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8086F4u, 0x8293F1u); }
    goto L_8293F5;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93F1u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93F1u, 8u, 4u, 0x8086F4u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8293F1 JSL -> $8086F4 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x93F4u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x93F5u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8086F4u, 0x8293F1u); }
    goto L_8293F5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x93F1u,0x8293F1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8293F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93F5u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93F5u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93F5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8293F5 INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_8293F7;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93F5u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93F5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8293F5 INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_8293F7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x93F5u,0x8293F5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8293F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93F7u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93F7u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93F7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8293F7 REP
    cpu.rep(0x20u);
    goto L_8293F9;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93F7u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93F7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8293F7 REP
    cpu.rep(0x20u);
    goto L_8293F9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x93F7u,0x8293F7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8293F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93F9u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93F9u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93F9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8293F9 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8293F9u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8293F9u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93F9u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93F9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8293F9 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8293F9u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8293F9u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x93F9u,0x8293F9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8293FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93FAu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93FAu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93FAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8293FA SEP
    cpu.sep(0x20u);
    goto L_8293FC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93FAu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93FAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8293FA SEP
    cpu.sep(0x20u);
    goto L_8293FC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x93FAu,0x8293FAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8293FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93FCu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93FCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93FCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8293FC LDA
    cpu.setA(0x81u, 8);
    goto L_8293FE;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93FCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93FCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8293FC LDA
    cpu.setA(0x81u, 8);
    goto L_8293FE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x93FCu,0x8293FCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8293FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93FEu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93FEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93FEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x47u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8293FE STA
    hw.write(cpu.address("dp", 0x47u), cpu.a, cpu.m8?8:16);
    goto L_829400;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93FEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93FEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x47u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8293FE STA
    hw.write(cpu.address("dp", 0x47u), cpu.a, cpu.m8?8:16);
    goto L_829400;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x93FEu,0x8293FEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829400:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9400u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9400u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9400u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829400 REP
    cpu.rep(0x20u);
    goto L_829402;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9400u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9400u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829400 REP
    cpu.rep(0x20u);
    goto L_829402;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9400u,0x829400u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829402:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9402u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9402u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9402u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829402 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x829402u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829402u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9402u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9402u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829402 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x829402u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829402u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9402u,0x829402u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_829FFA_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x829FFAu: goto L_829FFA;
    case 0x829FFBu: goto L_829FFB;
    case 0x829FFCu: goto L_829FFC;
    case 0x829FFEu: goto L_829FFE;
    case 0x829FFFu: goto L_829FFF;
    case 0x82A002u: goto L_82A002;
    case 0x82A004u: goto L_82A004;
    case 0x82A006u: goto L_82A006;
    case 0x82A008u: goto L_82A008;
    case 0x82A009u: goto L_82A009;
    case 0x82A00Bu: goto L_82A00B;
    case 0x82A00Cu: goto L_82A00C;
    case 0x82A00Du: goto L_82A00D;
    case 0x82A00Fu: goto L_82A00F;
    case 0x82A010u: goto L_82A010;
    case 0x82A012u: goto L_82A012;
    case 0x82A014u: goto L_82A014;
    case 0x82A017u: goto L_82A017;
    case 0x82A019u: goto L_82A019;
    case 0x82A01Bu: goto L_82A01B;
    case 0x82A01Du: goto L_82A01D;
    case 0x82A01Fu: goto L_82A01F;
    case 0x82A021u: goto L_82A021;
    case 0x82A023u: goto L_82A023;
    case 0x82A024u: goto L_82A024;
    case 0x82A025u: goto L_82A025;
    case 0x82A026u: goto L_82A026;
    case 0x82A027u: goto L_82A027;
    case 0x82A028u: goto L_82A028;
    case 0x82A029u: goto L_82A029;
    case 0x82A02Bu: goto L_82A02B;
    case 0x82A02Du: goto L_82A02D;
    case 0x82A02Fu: goto L_82A02F;
    case 0x82A031u: goto L_82A031;
    case 0x82A033u: goto L_82A033;
    case 0x82A036u: goto L_82A036;
    case 0x82A038u: goto L_82A038;
    case 0x82A03Bu: goto L_82A03B;
    case 0x82A03Cu: goto L_82A03C;
    case 0x82A03Eu: goto L_82A03E;
    case 0x82A03Fu: goto L_82A03F;
    case 0x82A040u: goto L_82A040;
    case 0x82A042u: goto L_82A042;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_829FFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FFAu,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FFAu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829FFA PHX
    cpu.push("PHX", hw);
    goto L_829FFB;
L_829FFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FFBu,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FFBu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829FFB PHY
    cpu.push("PHY", hw);
    goto L_829FFC;
L_829FFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FFCu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FFCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829FFC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829FFE;
L_829FFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FFEu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FFEu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $829FFE PHA
    cpu.push("PHA", hw);
    goto L_829FFF;
L_829FFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FFFu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FFFu, 4u + 1u, 3u, cpu.address("absx", 0x0208u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829FFF LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x208u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A002;
L_82A002:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA002u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA002u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA002u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A002 BPL -> $82A010
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82A010; }
    goto L_82A004;
L_82A004:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA004u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA004u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA004u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A004 CMP
    cpu.compareA(0x80u);
    goto L_82A006;
L_82A006:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA006u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA006u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA006u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A006 BNE -> $82A01F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A01F; }
    goto L_82A008;
L_82A008:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA008u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA008u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA008u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82A008 PLA
    cpu.pop("PLA", hw);
    goto L_82A009;
L_82A009:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA009u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA009u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA009u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A009 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_82A00B;
L_82A00B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA00Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA00Bu,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA00Bu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A00B PLY
    cpu.pop("PLY", hw);
    goto L_82A00C;
L_82A00C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA00Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA00Cu,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA00Cu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A00C PLX
    cpu.pop("PLX", hw);
    goto L_82A00D;
L_82A00D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA00Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA00Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA00Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A00D LDA
    cpu.setA(0x0u, 8);
    goto L_82A00F;
L_82A00F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA00Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA00Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA00Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A00F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82A00Fu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82A00Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82A010:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA010u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA010u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA010u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A010 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x1Eu), cpu.m8?8:16));
    goto L_82A012;
L_82A012:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA012u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA012u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA012u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A012 BNE -> $82A01F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A01F; }
    goto L_82A014;
L_82A014:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA014u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA014u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA014u, 6u, 3u, cpu.address("abs", 0xA0E6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A014 JSR -> $82A0E6 stack real
    { cpu.push16Value(hw,0xA016u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA017u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA0E6u), 0x82A014u); }
    goto L_82A017;
L_82A017:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA017u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA017u,0x82A017u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA017u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA017u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A017 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xCu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A019;
L_82A019:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA019u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA019u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA019u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 3u, 0u);
    // $82A019 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A01B;
L_82A01B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA01Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA01Bu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA01Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A01B SEP
    cpu.sep(0x20u);
    goto L_82A01D;
L_82A01D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA01Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA01Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA01Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A01D BNE -> $82A02D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A02D; }
    goto L_82A01F;
L_82A01F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA01Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA01Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA01Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A01F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A021;
L_82A021:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA021u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA021u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA021u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A021 BNE -> $82A008
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A008; }
    goto L_82A023;
L_82A023:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA023u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA023u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA023u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A023 INX
    cpu.inc('X');
    goto L_82A024;
L_82A024:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA024u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA024u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA024u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A024 INX
    cpu.inc('X');
    goto L_82A025;
L_82A025:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA025u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA025u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA025u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A025 INX
    cpu.inc('X');
    goto L_82A026;
L_82A026:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA026u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA026u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA026u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A026 INX
    cpu.inc('X');
    goto L_82A027;
L_82A027:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA027u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA027u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA027u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A027 INX
    cpu.inc('X');
    goto L_82A028;
L_82A028:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA028u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA028u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA028u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A028 INX
    cpu.inc('X');
    goto L_82A029;
L_82A029:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA029u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA029u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA029u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A029 INC
    cpu.incMem(hw, cpu.address("dp", 0xAu), cpu.m8?8:16);
    goto L_82A02B;
L_82A02B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA02Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA02Bu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA02Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A02B BRA -> $829FFF
    goto L_829FFF;
L_82A02D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA02Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA02Du,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA02Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A02D CMP
    cpu.compareA(0xFFu);
    goto L_82A02F;
L_82A02F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA02Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA02Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA02Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A02F BNE -> $82A03B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A03B; }
    goto L_82A031;
L_82A031:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA031u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA031u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA031u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A031 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A033;
L_82A033:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA033u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA033u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA033u, 4u + 1u, 3u, cpu.address("absx", 0x0440u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A033 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x440u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A036;
L_82A036:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA036u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA036u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA036u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A036 ORA
    cpu.logicOr(0xFFu);
    goto L_82A038;
L_82A038:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA038u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA038u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA038u, 5u, 3u, cpu.address("absx", 0x0440u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A038 STA
    hw.write(cpu.address("absx", 0x440u), cpu.a, cpu.m8?8:16);
    goto L_82A03B;
L_82A03B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA03Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA03Bu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA03Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82A03B PLA
    cpu.pop("PLA", hw);
    goto L_82A03C;
L_82A03C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA03Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA03Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA03Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A03C STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_82A03E;
L_82A03E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA03Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA03Eu,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA03Eu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A03E PLY
    cpu.pop("PLY", hw);
    goto L_82A03F;
L_82A03F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA03Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA03Fu,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA03Fu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A03F PLX
    cpu.pop("PLX", hw);
    goto L_82A040;
L_82A040:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA040u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA040u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA040u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A040 LDA
    cpu.setA(0xFFu, 8);
    goto L_82A042;
L_82A042:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA042u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA042u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA042u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A042 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82A042u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82A042u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82A64A_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82A64Au: goto L_82A64A;
    case 0x82A64Du: goto L_82A64D;
    case 0x82A650u: goto L_82A650;
    case 0x82A652u: goto L_82A652;
    case 0x82A655u: goto L_82A655;
    case 0x82A658u: goto L_82A658;
    case 0x82A659u: goto L_82A659;
    case 0x82A65Au: goto L_82A65A;
    case 0x82A65Du: goto L_82A65D;
    case 0x82A660u: goto L_82A660;
    case 0x82A662u: goto L_82A662;
    case 0x82A665u: goto L_82A665;
    case 0x82A667u: goto L_82A667;
    case 0x82A66Bu: goto L_82A66B;
    case 0x82A66Eu: goto L_82A66E;
    case 0x82A671u: goto L_82A671;
    case 0x82A673u: goto L_82A673;
    case 0x82A674u: goto L_82A674;
    case 0x82A677u: goto L_82A677;
    case 0x82A679u: goto L_82A679;
    case 0x82A67Cu: goto L_82A67C;
    case 0x82A67Eu: goto L_82A67E;
    case 0x82A681u: goto L_82A681;
    case 0x82A684u: goto L_82A684;
    case 0x82A686u: goto L_82A686;
    case 0x82A689u: goto L_82A689;
    case 0x82A68Bu: goto L_82A68B;
    case 0x82A68Eu: goto L_82A68E;
    case 0x82A690u: goto L_82A690;
    case 0x82A694u: goto L_82A694;
    case 0x82A697u: goto L_82A697;
    case 0x82A699u: goto L_82A699;
    case 0x82A69Bu: goto L_82A69B;
    case 0x82A69Cu: goto L_82A69C;
    case 0x82A69Fu: goto L_82A69F;
    case 0x82A6A1u: goto L_82A6A1;
    case 0x82A6A4u: goto L_82A6A4;
    case 0x82A6A7u: goto L_82A6A7;
    case 0x82A6A9u: goto L_82A6A9;
    case 0x82A6ACu: goto L_82A6AC;
    case 0x82A6AEu: goto L_82A6AE;
    case 0x82A6B1u: goto L_82A6B1;
    case 0x82A6B3u: goto L_82A6B3;
    case 0x82A6B7u: goto L_82A6B7;
    case 0x82A6B9u: goto L_82A6B9;
    case 0x82A6BCu: goto L_82A6BC;
    case 0x82A6BFu: goto L_82A6BF;
    case 0x82A6C1u: goto L_82A6C1;
    case 0x82A6C3u: goto L_82A6C3;
    case 0x82A6C5u: goto L_82A6C5;
    case 0x82A6C9u: goto L_82A6C9;
    case 0x82A6CCu: goto L_82A6CC;
    case 0x82A6CFu: goto L_82A6CF;
    case 0x82A6D1u: goto L_82A6D1;
    case 0x82A6D2u: goto L_82A6D2;
    case 0x82A6D5u: goto L_82A6D5;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82A64A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA64Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA64Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA64Au, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A64A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A64D;
L_82A64D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA64Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA64Du,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA64Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A64D CMP
    cpu.compareA(0x1u);
    goto L_82A650;
L_82A650:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA650u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA650u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA650u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A650 BNE -> $82A660
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A660; }
    goto L_82A652;
L_82A652:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA652u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA652u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA652u, 8u, 3u, cpu.address("abs", 0x0802u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A652 DEC
    cpu.decMem(hw, cpu.address("abs", 0x802u), cpu.m8?8:16);
    goto L_82A655;
L_82A655:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA655u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA655u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA655u, 5u, 3u, cpu.address("abs", 0x02E6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A655 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2E6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A658;
L_82A658:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA658u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA658u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA658u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A658 ASL
    cpu.aslA();
    goto L_82A659;
L_82A659:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA659u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA659u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA659u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A659 TAX
    cpu.transfer("TAX");
    goto L_82A65A;
L_82A65A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA65Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA65Au,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA65Au, 5u + 1u, 3u, cpu.address("absx", 0x0806u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A65A LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x806u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A65D;
L_82A65D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA65Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA65Du,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA65Du, 3u, 3u, cpu.address("abs", 0xA6D5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A65D JMP -> $82A6D5
    goto L_82A6D5;
L_82A660:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA660u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA660u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA660u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A660 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A662;
L_82A662:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA662u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA662u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA662u, 5u + 1u, 3u, cpu.address("absy", 0x02E4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A662 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x2E4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A665;
L_82A665:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA665u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA665u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA665u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A665 BEQ -> $82A679
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A679; }
    goto L_82A667;
L_82A667:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA667u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA667u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA667u, 8u, 4u, 0x8096A3u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82A667 JSL -> $8096A3 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA66Au); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA66Bu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8096A3u, 0x82A667u); }
    goto L_82A66B;
L_82A66B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA66Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA66Bu,0x82A66Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA66Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA66Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A66B AND
    cpu.logicAnd(0x3u);
    goto L_82A66E;
L_82A66E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA66Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA66Eu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA66Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A66E CMP
    cpu.compareA(0x3u);
    goto L_82A671;
L_82A671:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA671u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA671u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA671u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A671 BEQ -> $82A667
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A667; }
    goto L_82A673;
L_82A673:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA673u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA673u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA673u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A673 CLC
    cpu.setFlag('C', false);
    goto L_82A674;
L_82A674:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA674u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA674u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA674u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A674 ADC
    cpu.adc(0x9Cu);
    goto L_82A677;
L_82A677:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA677u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA677u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA677u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A677 BRA -> $82A6D5
    goto L_82A6D5;
L_82A679:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA679u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA679u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA679u, 5u + 1u, 3u, cpu.address("absy", 0x02E2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A679 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x2E2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A67C;
L_82A67C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA67Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA67Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA67Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A67C BNE -> $82A6A1
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A6A1; }
    goto L_82A67E;
L_82A67E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA67Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA67Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA67Eu, 5u, 3u, cpu.address("abs", 0x01CEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A67E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1CEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A681;
L_82A681:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA681u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA681u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA681u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A681 AND
    cpu.logicAnd(0xFFu);
    goto L_82A684;
L_82A684:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA684u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA684u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA684u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A684 BNE -> $82A68B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A68B; }
    goto L_82A686;
L_82A686:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA686u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA686u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA686u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A686 LDA
    cpu.setA(0x1Bu, 16);
    goto L_82A689;
L_82A689:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA689u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA689u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA689u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A689 BRA -> $82A68E
    goto L_82A68E;
L_82A68B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA68Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA68Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA68Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A68B LDA
    cpu.setA(0x1Eu, 16);
    goto L_82A68E;
L_82A68E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA68Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA68Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA68Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A68E STA
    hw.write(cpu.address("dp", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_82A690;
L_82A690:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA690u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA690u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA690u, 8u, 4u, 0x8096A3u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82A690 JSL -> $8096A3 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA693u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA694u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8096A3u, 0x82A690u); }
    goto L_82A694;
L_82A694:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA694u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA694u,0x82A694u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA694u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA694u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A694 AND
    cpu.logicAnd(0x1Fu);
    goto L_82A697;
L_82A697:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA697u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA697u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA697u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A697 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0xEu), cpu.m8?8:16));
    goto L_82A699;
L_82A699:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA699u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA699u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA699u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A699 BCS -> $82A690
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_82A690; }
    goto L_82A69B;
L_82A69B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA69Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA69Bu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA69Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A69B CLC
    cpu.setFlag('C', false);
    goto L_82A69C;
L_82A69C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA69Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA69Cu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA69Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A69C ADC
    cpu.adc(0x7Eu);
    goto L_82A69F;
L_82A69F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA69Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA69Fu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA69Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A69F BRA -> $82A6D5
    goto L_82A6D5;
L_82A6A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A1u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A1u, 5u, 3u, cpu.address("abs", 0x01CEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A6A1 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1CEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A6A4;
L_82A6A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A6A4 AND
    cpu.logicAnd(0xFFu);
    goto L_82A6A7;
L_82A6A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A7u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A6A7 BNE -> $82A6AE
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A6AE; }
    goto L_82A6A9;
L_82A6A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A6A9 LDA
    cpu.setA(0x78u, 16);
    goto L_82A6AC;
L_82A6AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6ACu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6ACu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A6AC BRA -> $82A6B1
    goto L_82A6B1;
L_82A6AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6AEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6AEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A6AE LDA
    cpu.setA(0x7Du, 16);
    goto L_82A6B1;
L_82A6B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A6B1 STA
    hw.write(cpu.address("dp", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_82A6B3;
L_82A6B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B3u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B3u, 8u, 4u, 0x8096BAu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82A6B3 JSL -> $8096BA stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA6B6u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA6B7u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8096BAu, 0x82A6B3u); }
    goto L_82A6B7;
L_82A6B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6B7u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA6B7u,0x82A6B7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x55u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A6B7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x55u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A6B9;
L_82A6B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B9u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A6B9 AND
    cpu.logicAnd(0x7Fu);
    goto L_82A6BC;
L_82A6BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6BCu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6BCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A6BC CMP
    cpu.compareA(0x7Du);
    goto L_82A6BF;
L_82A6BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6BFu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6BFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A6BF BCS -> $82A6B3
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_82A6B3; }
    goto L_82A6C1;
L_82A6C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C1u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A6C1 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0xEu), cpu.m8?8:16));
    goto L_82A6C3;
L_82A6C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C3u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A6C3 BCC -> $82A6D5
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_82A6D5; }
    goto L_82A6C5;
L_82A6C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C5u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C5u, 8u, 4u, 0x8096A3u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82A6C5 JSL -> $8096A3 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA6C8u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA6C9u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8096A3u, 0x82A6C5u); }
    goto L_82A6C9;
L_82A6C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6C9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA6C9u,0x82A6C9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C9u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A6C9 AND
    cpu.logicAnd(0x3Fu);
    goto L_82A6CC;
L_82A6CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6CCu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6CCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A6CC CMP
    cpu.compareA(0x24u);
    goto L_82A6CF;
L_82A6CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6CFu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6CFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A6CF BCS -> $82A6C5
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_82A6C5; }
    goto L_82A6D1;
L_82A6D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D1u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A6D1 CLC
    cpu.setFlag('C', false);
    goto L_82A6D2;
L_82A6D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D2u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A6D2 ADC
    cpu.adc(0x54u);
    goto L_82A6D5;
L_82A6D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D5u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A6D5 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82A6D5u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82A6D5u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82AF78_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82AF78u: goto L_82AF78;
    case 0x82AF7Au: goto L_82AF7A;
    case 0x82AF7Eu: goto L_82AF7E;
    case 0x82AF81u: goto L_82AF81;
    case 0x82AF84u: goto L_82AF84;
    case 0x82AF87u: goto L_82AF87;
    case 0x82AF8Bu: goto L_82AF8B;
    case 0x82AF8Eu: goto L_82AF8E;
    case 0x82AF91u: goto L_82AF91;
    case 0x82AF94u: goto L_82AF94;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82AF78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF78u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF78u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF78 REP
    cpu.rep(0x20u);
    goto L_82AF7A;
L_82AF7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF7Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF7Au, 8u, 4u, 0x809D16u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AF7A JSL -> $809D16 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAF7Du); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF7Eu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809D16u, 0x82AF7Au); }
    goto L_82AF7E;
L_82AF7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF7Eu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF7Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF7Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF7E LDA
    cpu.setA(0x800u, 16);
    goto L_82AF81;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF7Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF7Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF7E LDA
    cpu.setA(0x800u, 16);
    goto L_82AF81;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF7Eu,0x82AF7Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82AF81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF81u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF81u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF81u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF81 LDX
    cpu.setX(0x2800u, 16);
    goto L_82AF84;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF81u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF81u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF81 LDX
    cpu.setX(0x2800u, 16);
    goto L_82AF84;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF81u,0x82AF81u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82AF84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF84u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF84u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF84u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF84 LDY
    cpu.setY(0x5000u, 16);
    goto L_82AF87;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF84u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF84u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF84 LDY
    cpu.setY(0x5000u, 16);
    goto L_82AF87;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF84u,0x82AF84u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82AF87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF87u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF87u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF87u, 8u, 4u, 0x808EBFu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AF87 JSL -> $808EBF stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAF8Au); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF8Bu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808EBFu, 0x82AF87u); }
    goto L_82AF8B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF87u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF87u, 8u, 4u, 0x808EBFu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AF87 JSL -> $808EBF stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAF8Au); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF8Bu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808EBFu, 0x82AF87u); }
    goto L_82AF8B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF87u,0x82AF87u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82AF8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF8Bu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF8Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF8Bu, 6u, 3u, cpu.address("abs", 0xC781u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AF8B JSR -> $82C781 stack real
    { cpu.push16Value(hw,0xAF8Du); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF8Eu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC781u), 0x82AF8Bu); }
    goto L_82AF8E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF8Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF8Bu, 6u, 3u, cpu.address("abs", 0xC781u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AF8B JSR -> $82C781 stack real
    { cpu.push16Value(hw,0xAF8Du); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF8Eu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC781u), 0x82AF8Bu); }
    goto L_82AF8E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF8Bu,0x82AF8Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82AF8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF8Eu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF8Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF8Eu, 6u, 3u, cpu.address("abs", 0xDAB2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AF8E JSR -> $82DAB2 stack real
    { cpu.push16Value(hw,0xAF90u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF91u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xDAB2u), 0x82AF8Eu); }
    goto L_82AF91;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF8Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF8Eu, 6u, 3u, cpu.address("abs", 0xDAB2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AF8E JSR -> $82DAB2 stack real
    { cpu.push16Value(hw,0xAF90u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF91u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xDAB2u), 0x82AF8Eu); }
    goto L_82AF91;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF8Eu,0x82AF8Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82AF91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF91u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF91u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF91u, 6u, 3u, cpu.address("abs", 0xD7FDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AF91 JSR -> $82D7FD stack real
    { cpu.push16Value(hw,0xAF93u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF94u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD7FDu), 0x82AF91u); }
    goto L_82AF94;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF91u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF91u, 6u, 3u, cpu.address("abs", 0xD7FDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AF91 JSR -> $82D7FD stack real
    { cpu.push16Value(hw,0xAF93u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF94u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD7FDu), 0x82AF91u); }
    goto L_82AF94;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF91u,0x82AF91u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82AF94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF94u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF94u,0x82AF94u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF94u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF94u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AF94 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x82AF94u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82AF94u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_82AF78_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82AF78u: goto L_82AF78;
    case 0x82AF7Au: goto L_82AF7A;
    case 0x82AF7Eu: goto L_82AF7E;
    case 0x82AF81u: goto L_82AF81;
    case 0x82AF84u: goto L_82AF84;
    case 0x82AF87u: goto L_82AF87;
    case 0x82AF8Bu: goto L_82AF8B;
    case 0x82AF8Eu: goto L_82AF8E;
    case 0x82AF91u: goto L_82AF91;
    case 0x82AF94u: goto L_82AF94;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82AF78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF78u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF78u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF78 REP
    cpu.rep(0x20u);
    goto L_82AF7A;
L_82AF7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF7Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF7Au, 8u, 4u, 0x809D16u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AF7A JSL -> $809D16 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAF7Du); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF7Eu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809D16u, 0x82AF7Au); }
    goto L_82AF7E;
L_82AF7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF7Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF7Eu,0x82AF7Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF7Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF7Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF7E LDA
    cpu.setA(0x800u, 16);
    goto L_82AF81;
L_82AF81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF81u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF81u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF81 LDX
    cpu.setX(0x2800u, 16);
    goto L_82AF84;
L_82AF84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF84u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF84u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF84 LDY
    cpu.setY(0x5000u, 16);
    goto L_82AF87;
L_82AF87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF87u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF87u, 8u, 4u, 0x808EBFu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AF87 JSL -> $808EBF stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAF8Au); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF8Bu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808EBFu, 0x82AF87u); }
    goto L_82AF8B;
L_82AF8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF8Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF8Bu,0x82AF8Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF8Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF8Bu, 6u, 3u, cpu.address("abs", 0xC781u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AF8B JSR -> $82C781 stack real
    { cpu.push16Value(hw,0xAF8Du); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF8Eu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC781u), 0x82AF8Bu); }
    goto L_82AF8E;
L_82AF8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF8Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF8Eu,0x82AF8Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF8Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF8Eu, 6u, 3u, cpu.address("abs", 0xDAB2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AF8E JSR -> $82DAB2 stack real
    { cpu.push16Value(hw,0xAF90u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF91u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xDAB2u), 0x82AF8Eu); }
    goto L_82AF91;
L_82AF91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF91u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF91u,0x82AF91u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF91u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF91u, 6u, 3u, cpu.address("abs", 0xD7FDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AF91 JSR -> $82D7FD stack real
    { cpu.push16Value(hw,0xAF93u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF94u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD7FDu), 0x82AF91u); }
    goto L_82AF94;
L_82AF94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF94u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF94u,0x82AF94u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF94u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF94u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AF94 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x82AF94u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82AF94u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_82B544_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B544u: goto L_82B544;
    case 0x82B547u: goto L_82B547;
    case 0x82B549u: goto L_82B549;
    case 0x82B54Au: goto L_82B54A;
    case 0x82B54Du: goto L_82B54D;
    case 0x82B54Eu: goto L_82B54E;
    case 0x82B550u: goto L_82B550;
    case 0x82B552u: goto L_82B552;
    case 0x82B554u: goto L_82B554;
    case 0x82B556u: goto L_82B556;
    case 0x82B558u: goto L_82B558;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B544:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB544u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB544u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB544u, 4u + 1u, 3u, cpu.address("absy", 0x020Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B544 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x20Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B547;
L_82B547:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB547u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB547u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB547u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B547 STA
    hw.write(cpu.address("dp", 0xFu), cpu.a, cpu.m8?8:16);
    goto L_82B549;
L_82B549:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB549u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB549u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB549u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B549 CLC
    cpu.setFlag('C', false);
    goto L_82B54A;
L_82B54A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB54Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB54Au,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB54Au, 4u + 1u, 3u, cpu.address("absx", 0x027Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B54A ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x27Eu), cpu.m8?8:16));
    goto L_82B54D;
L_82B54D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB54Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB54Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB54Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B54D CLC
    cpu.setFlag('C', false);
    goto L_82B54E;
L_82B54E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB54Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB54Eu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB54Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B54E ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16));
    goto L_82B550;
L_82B550:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB550u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB550u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB550u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B550 STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_82B552;
L_82B552:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB552u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB552u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB552u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B552 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B554;
L_82B554:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB554u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB554u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB554u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B554 ADC
    cpu.adc(0x0u);
    goto L_82B556;
L_82B556:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB556u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB556u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB556u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B556 STA
    hw.write(cpu.address("dp", 0x5u), cpu.a, cpu.m8?8:16);
    goto L_82B558;
L_82B558:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB558u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB558u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB558u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B558 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B558u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B558u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82B64A_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B64Au: goto L_82B64A;
    case 0x82B64Cu: goto L_82B64C;
    case 0x82B64Eu: goto L_82B64E;
    case 0x82B650u: goto L_82B650;
    case 0x82B652u: goto L_82B652;
    case 0x82B654u: goto L_82B654;
    case 0x82B655u: goto L_82B655;
    case 0x82B657u: goto L_82B657;
    case 0x82B659u: goto L_82B659;
    case 0x82B65Bu: goto L_82B65B;
    case 0x82B65Eu: goto L_82B65E;
    case 0x82B660u: goto L_82B660;
    case 0x82B663u: goto L_82B663;
    case 0x82B666u: goto L_82B666;
    case 0x82B668u: goto L_82B668;
    case 0x82B66Au: goto L_82B66A;
    case 0x82B66Cu: goto L_82B66C;
    case 0x82B66Fu: goto L_82B66F;
    case 0x82B672u: goto L_82B672;
    case 0x82B674u: goto L_82B674;
    case 0x82B677u: goto L_82B677;
    case 0x82B679u: goto L_82B679;
    case 0x82B67Cu: goto L_82B67C;
    case 0x82B67Eu: goto L_82B67E;
    case 0x82B680u: goto L_82B680;
    case 0x82B683u: goto L_82B683;
    case 0x82B685u: goto L_82B685;
    case 0x82B688u: goto L_82B688;
    case 0x82B68Au: goto L_82B68A;
    case 0x82B68Du: goto L_82B68D;
    case 0x82B68Fu: goto L_82B68F;
    case 0x82B692u: goto L_82B692;
    case 0x82B693u: goto L_82B693;
    case 0x82B695u: goto L_82B695;
    case 0x82B697u: goto L_82B697;
    case 0x82B69Au: goto L_82B69A;
    case 0x82B69Cu: goto L_82B69C;
    case 0x82B69Fu: goto L_82B69F;
    case 0x82B6A1u: goto L_82B6A1;
    case 0x82B6A4u: goto L_82B6A4;
    case 0x82B6A6u: goto L_82B6A6;
    case 0x82B6A9u: goto L_82B6A9;
    case 0x82B6ABu: goto L_82B6AB;
    case 0x82B6ADu: goto L_82B6AD;
    case 0x82B6B0u: goto L_82B6B0;
    case 0x82B6B3u: goto L_82B6B3;
    case 0x82B6B5u: goto L_82B6B5;
    case 0x82B6B8u: goto L_82B6B8;
    case 0x82B6BAu: goto L_82B6BA;
    case 0x82B6BDu: goto L_82B6BD;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B64A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB64Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB64Au,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB64Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B64A LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x3u), cpu.m8?8:16);
    goto L_82B64C;
L_82B64C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB64Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB64Cu,cpu,0x66u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB64Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B64C ROR
    cpu.rorMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_82B64E;
L_82B64E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB64Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB64Eu,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB64Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B64E LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x5u), cpu.m8?8:16);
    goto L_82B650;
L_82B650:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB650u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB650u,cpu,0x66u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB650u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B650 ROR
    cpu.rorMem(hw, cpu.address("dp", 0x4u), cpu.m8?8:16);
    goto L_82B652;
L_82B652:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB652u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB652u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB652u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B652 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B654;
L_82B654:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB654u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB654u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB654u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B654 CLC
    cpu.setFlag('C', false);
    goto L_82B655;
L_82B655:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB655u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB655u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB655u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B655 ADC
    cpu.adc(0x4u);
    goto L_82B657;
L_82B657:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB657u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB657u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB657u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B657 STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_82B659;
L_82B659:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB659u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB659u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB659u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B659 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x10u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B65B;
L_82B65B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB65Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB65Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB65Bu, 6u, 3u, cpu.address("abs", 0xB6BEu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B65B JSR -> $82B6BE stack real
    { cpu.push16Value(hw,0xB65Du); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB65Eu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB6BEu), 0x82B65Bu); }
    goto L_82B65E;
L_82B65E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB65Eu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB65Eu,0x82B65Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB65Eu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB65Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B65E LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x14u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B660;
L_82B660:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB660u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB660u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB660u, 6u, 3u, cpu.address("abs", 0xB6BEu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B660 JSR -> $82B6BE stack real
    { cpu.push16Value(hw,0xB662u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB663u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB6BEu), 0x82B660u); }
    goto L_82B663;
L_82B663:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB663u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB663u,0x82B663u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB663u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB663u, 6u, 3u, cpu.address("abs", 0xB6E0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B663 JSR -> $82B6E0 stack real
    { cpu.push16Value(hw,0xB665u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB666u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB6E0u), 0x82B663u); }
    goto L_82B666;
L_82B666:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB666u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB666u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB666u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B666 BCS -> $82B693
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_82B693; }
    goto L_82B668;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB666u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB666u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B666 BCS -> $82B693
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_82B693; }
    goto L_82B668;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB666u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB666u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B666 BCS -> $82B693
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_82B693; }
    goto L_82B668;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB666u,0x82B666u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B668:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB668u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB668u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB668u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B668 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x12u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B66A;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB668u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB668u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B668 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x12u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B66A;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB668u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB668u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B668 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x12u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B66A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB668u,0x82B668u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B66A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB66Au))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB66Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB66Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B66A LDA
    cpu.setA(0x0u, 8);
    goto L_82B66C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB66Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB66Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B66A LDA
    cpu.setA(0x0u, 8);
    goto L_82B66C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB66Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB66Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B66A LDA
    cpu.setA(0x0u, 8);
    goto L_82B66C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB66Au,0x82B66Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B66C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB66Cu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB66Cu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB66Cu, 5u, 3u, cpu.address("absy", 0x020Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B66C STA
    hw.write(cpu.address("absy", 0x20Au), cpu.a, cpu.m8?8:16);
    goto L_82B66F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB66Cu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB66Cu, 5u, 3u, cpu.address("absy", 0x020Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B66C STA
    hw.write(cpu.address("absy", 0x20Au), cpu.a, cpu.m8?8:16);
    goto L_82B66F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB66Cu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB66Cu, 5u, 3u, cpu.address("absy", 0x020Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B66C STA
    hw.write(cpu.address("absy", 0x20Au), cpu.a, cpu.m8?8:16);
    goto L_82B66F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB66Cu,0x82B66Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B66F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB66Fu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB66Fu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB66Fu, 5u, 3u, cpu.address("absy", 0x0226u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B66F STA
    hw.write(cpu.address("absy", 0x226u), cpu.a, cpu.m8?8:16);
    goto L_82B672;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB66Fu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB66Fu, 5u, 3u, cpu.address("absy", 0x0226u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B66F STA
    hw.write(cpu.address("absy", 0x226u), cpu.a, cpu.m8?8:16);
    goto L_82B672;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB66Fu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB66Fu, 5u, 3u, cpu.address("absy", 0x0226u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B66F STA
    hw.write(cpu.address("absy", 0x226u), cpu.a, cpu.m8?8:16);
    goto L_82B672;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB66Fu,0x82B66Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B672:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB672u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB672u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB672u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B672 LDA
    cpu.setA(0xF8u, 8);
    goto L_82B674;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB672u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB672u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B672 LDA
    cpu.setA(0xF8u, 8);
    goto L_82B674;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB672u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB672u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B672 LDA
    cpu.setA(0xF8u, 8);
    goto L_82B674;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB672u,0x82B672u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B674:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB674u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB674u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB674u, 5u, 3u, cpu.address("absy", 0x020Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B674 STA
    hw.write(cpu.address("absy", 0x20Bu), cpu.a, cpu.m8?8:16);
    goto L_82B677;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB674u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB674u, 5u, 3u, cpu.address("absy", 0x020Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B674 STA
    hw.write(cpu.address("absy", 0x20Bu), cpu.a, cpu.m8?8:16);
    goto L_82B677;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB674u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB674u, 5u, 3u, cpu.address("absy", 0x020Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B674 STA
    hw.write(cpu.address("absy", 0x20Bu), cpu.a, cpu.m8?8:16);
    goto L_82B677;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB674u,0x82B674u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B677:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB677u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB677u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB677u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B677 LDA
    cpu.setA(0xFCu, 8);
    goto L_82B679;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB677u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB677u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B677 LDA
    cpu.setA(0xFCu, 8);
    goto L_82B679;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB677u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB677u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B677 LDA
    cpu.setA(0xFCu, 8);
    goto L_82B679;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB677u,0x82B677u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B679:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB679u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB679u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB679u, 5u, 3u, cpu.address("absy", 0x0227u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B679 STA
    hw.write(cpu.address("absy", 0x227u), cpu.a, cpu.m8?8:16);
    goto L_82B67C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB679u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB679u, 5u, 3u, cpu.address("absy", 0x0227u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B679 STA
    hw.write(cpu.address("absy", 0x227u), cpu.a, cpu.m8?8:16);
    goto L_82B67C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB679u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB679u, 5u, 3u, cpu.address("absy", 0x0227u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B679 STA
    hw.write(cpu.address("absy", 0x227u), cpu.a, cpu.m8?8:16);
    goto L_82B67C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB679u,0x82B679u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B67C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB67Cu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB67Cu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB67Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B67C LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x16u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B67E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB67Cu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB67Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B67C LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x16u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B67E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB67Cu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB67Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B67C LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x16u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B67E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB67Cu,0x82B67Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B67E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB67Eu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB67Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB67Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B67E LDA
    cpu.setA(0x0u, 8);
    goto L_82B680;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB67Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB67Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B67E LDA
    cpu.setA(0x0u, 8);
    goto L_82B680;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB67Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB67Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B67E LDA
    cpu.setA(0x0u, 8);
    goto L_82B680;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB67Eu,0x82B67Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B680:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB680u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB680u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB680u, 5u, 3u, cpu.address("absy", 0x020Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B680 STA
    hw.write(cpu.address("absy", 0x20Au), cpu.a, cpu.m8?8:16);
    goto L_82B683;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB680u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB680u, 5u, 3u, cpu.address("absy", 0x020Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B680 STA
    hw.write(cpu.address("absy", 0x20Au), cpu.a, cpu.m8?8:16);
    goto L_82B683;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB680u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB680u, 5u, 3u, cpu.address("absy", 0x020Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B680 STA
    hw.write(cpu.address("absy", 0x20Au), cpu.a, cpu.m8?8:16);
    goto L_82B683;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB680u,0x82B680u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B683:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB683u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB683u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB683u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B683 LDA
    cpu.setA(0xFCu, 8);
    goto L_82B685;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB683u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB683u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B683 LDA
    cpu.setA(0xFCu, 8);
    goto L_82B685;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB683u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB683u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B683 LDA
    cpu.setA(0xFCu, 8);
    goto L_82B685;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB683u,0x82B683u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B685:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB685u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB685u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB685u, 5u, 3u, cpu.address("absy", 0x0226u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B685 STA
    hw.write(cpu.address("absy", 0x226u), cpu.a, cpu.m8?8:16);
    goto L_82B688;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB685u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB685u, 5u, 3u, cpu.address("absy", 0x0226u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B685 STA
    hw.write(cpu.address("absy", 0x226u), cpu.a, cpu.m8?8:16);
    goto L_82B688;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB685u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB685u, 5u, 3u, cpu.address("absy", 0x0226u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B685 STA
    hw.write(cpu.address("absy", 0x226u), cpu.a, cpu.m8?8:16);
    goto L_82B688;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB685u,0x82B685u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B688:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB688u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB688u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB688u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B688 LDA
    cpu.setA(0x0u, 8);
    goto L_82B68A;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB688u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB688u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B688 LDA
    cpu.setA(0x0u, 8);
    goto L_82B68A;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB688u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB688u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B688 LDA
    cpu.setA(0x0u, 8);
    goto L_82B68A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB688u,0x82B688u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B68A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB68Au))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB68Au,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB68Au, 5u, 3u, cpu.address("absy", 0x020Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B68A STA
    hw.write(cpu.address("absy", 0x20Bu), cpu.a, cpu.m8?8:16);
    goto L_82B68D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB68Au,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB68Au, 5u, 3u, cpu.address("absy", 0x020Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B68A STA
    hw.write(cpu.address("absy", 0x20Bu), cpu.a, cpu.m8?8:16);
    goto L_82B68D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB68Au,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB68Au, 5u, 3u, cpu.address("absy", 0x020Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B68A STA
    hw.write(cpu.address("absy", 0x20Bu), cpu.a, cpu.m8?8:16);
    goto L_82B68D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB68Au,0x82B68Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B68D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB68Du))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB68Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB68Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B68D LDA
    cpu.setA(0xFCu, 8);
    goto L_82B68F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB68Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB68Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B68D LDA
    cpu.setA(0xFCu, 8);
    goto L_82B68F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB68Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB68Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B68D LDA
    cpu.setA(0xFCu, 8);
    goto L_82B68F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB68Du,0x82B68Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B68F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB68Fu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB68Fu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB68Fu, 5u, 3u, cpu.address("absy", 0x0227u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B68F STA
    hw.write(cpu.address("absy", 0x227u), cpu.a, cpu.m8?8:16);
    goto L_82B692;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB68Fu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB68Fu, 5u, 3u, cpu.address("absy", 0x0227u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B68F STA
    hw.write(cpu.address("absy", 0x227u), cpu.a, cpu.m8?8:16);
    goto L_82B692;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB68Fu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB68Fu, 5u, 3u, cpu.address("absy", 0x0227u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B68F STA
    hw.write(cpu.address("absy", 0x227u), cpu.a, cpu.m8?8:16);
    goto L_82B692;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB68Fu,0x82B68Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B692:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB692u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB692u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB692u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B692 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B692u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B692u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB692u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB692u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B692 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B692u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B692u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB692u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB692u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B692 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B692u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B692u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB692u,0x82B692u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B693:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB693u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB693u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB693u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B693 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x12u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B695;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB693u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB693u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B693 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x12u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B695;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB693u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB693u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B693 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x12u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B695;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB693u,0x82B693u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B695:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB695u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB695u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB695u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B695 LDA
    cpu.setA(0x0u, 8);
    goto L_82B697;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB695u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB695u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B695 LDA
    cpu.setA(0x0u, 8);
    goto L_82B697;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB695u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB695u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B695 LDA
    cpu.setA(0x0u, 8);
    goto L_82B697;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB695u,0x82B695u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B697:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB697u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB697u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB697u, 5u, 3u, cpu.address("absy", 0x020Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B697 STA
    hw.write(cpu.address("absy", 0x20Au), cpu.a, cpu.m8?8:16);
    goto L_82B69A;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB697u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB697u, 5u, 3u, cpu.address("absy", 0x020Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B697 STA
    hw.write(cpu.address("absy", 0x20Au), cpu.a, cpu.m8?8:16);
    goto L_82B69A;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB697u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB697u, 5u, 3u, cpu.address("absy", 0x020Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B697 STA
    hw.write(cpu.address("absy", 0x20Au), cpu.a, cpu.m8?8:16);
    goto L_82B69A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB697u,0x82B697u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B69A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB69Au))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB69Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB69Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B69A LDA
    cpu.setA(0xFCu, 8);
    goto L_82B69C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB69Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB69Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B69A LDA
    cpu.setA(0xFCu, 8);
    goto L_82B69C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB69Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB69Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B69A LDA
    cpu.setA(0xFCu, 8);
    goto L_82B69C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB69Au,0x82B69Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B69C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB69Cu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB69Cu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB69Cu, 5u, 3u, cpu.address("absy", 0x0226u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B69C STA
    hw.write(cpu.address("absy", 0x226u), cpu.a, cpu.m8?8:16);
    goto L_82B69F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB69Cu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB69Cu, 5u, 3u, cpu.address("absy", 0x0226u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B69C STA
    hw.write(cpu.address("absy", 0x226u), cpu.a, cpu.m8?8:16);
    goto L_82B69F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB69Cu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB69Cu, 5u, 3u, cpu.address("absy", 0x0226u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B69C STA
    hw.write(cpu.address("absy", 0x226u), cpu.a, cpu.m8?8:16);
    goto L_82B69F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB69Cu,0x82B69Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B69F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB69Fu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB69Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB69Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B69F LDA
    cpu.setA(0x0u, 8);
    goto L_82B6A1;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB69Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB69Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B69F LDA
    cpu.setA(0x0u, 8);
    goto L_82B6A1;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB69Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB69Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B69F LDA
    cpu.setA(0x0u, 8);
    goto L_82B6A1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB69Fu,0x82B69Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B6A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6A1u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6A1u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6A1u, 5u, 3u, cpu.address("absy", 0x020Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6A1 STA
    hw.write(cpu.address("absy", 0x20Bu), cpu.a, cpu.m8?8:16);
    goto L_82B6A4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6A1u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6A1u, 5u, 3u, cpu.address("absy", 0x020Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6A1 STA
    hw.write(cpu.address("absy", 0x20Bu), cpu.a, cpu.m8?8:16);
    goto L_82B6A4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6A1u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6A1u, 5u, 3u, cpu.address("absy", 0x020Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6A1 STA
    hw.write(cpu.address("absy", 0x20Bu), cpu.a, cpu.m8?8:16);
    goto L_82B6A4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB6A1u,0x82B6A1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B6A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6A4u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6A4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6A4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6A4 LDA
    cpu.setA(0xFCu, 8);
    goto L_82B6A6;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6A4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6A4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6A4 LDA
    cpu.setA(0xFCu, 8);
    goto L_82B6A6;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6A4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6A4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6A4 LDA
    cpu.setA(0xFCu, 8);
    goto L_82B6A6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB6A4u,0x82B6A4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B6A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6A6u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6A6u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6A6u, 5u, 3u, cpu.address("absy", 0x0227u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6A6 STA
    hw.write(cpu.address("absy", 0x227u), cpu.a, cpu.m8?8:16);
    goto L_82B6A9;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6A6u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6A6u, 5u, 3u, cpu.address("absy", 0x0227u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6A6 STA
    hw.write(cpu.address("absy", 0x227u), cpu.a, cpu.m8?8:16);
    goto L_82B6A9;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6A6u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6A6u, 5u, 3u, cpu.address("absy", 0x0227u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6A6 STA
    hw.write(cpu.address("absy", 0x227u), cpu.a, cpu.m8?8:16);
    goto L_82B6A9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB6A6u,0x82B6A6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B6A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6A9u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6A9u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6A9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6A9 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x16u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B6AB;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6A9u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6A9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6A9 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x16u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B6AB;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6A9u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6A9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6A9 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x16u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B6AB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB6A9u,0x82B6A9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B6AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6ABu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6ABu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6ABu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6AB LDA
    cpu.setA(0x0u, 8);
    goto L_82B6AD;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6ABu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6ABu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6AB LDA
    cpu.setA(0x0u, 8);
    goto L_82B6AD;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6ABu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6ABu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6AB LDA
    cpu.setA(0x0u, 8);
    goto L_82B6AD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB6ABu,0x82B6ABu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B6AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6ADu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6ADu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6ADu, 5u, 3u, cpu.address("absy", 0x020Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6AD STA
    hw.write(cpu.address("absy", 0x20Au), cpu.a, cpu.m8?8:16);
    goto L_82B6B0;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6ADu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6ADu, 5u, 3u, cpu.address("absy", 0x020Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6AD STA
    hw.write(cpu.address("absy", 0x20Au), cpu.a, cpu.m8?8:16);
    goto L_82B6B0;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6ADu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6ADu, 5u, 3u, cpu.address("absy", 0x020Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6AD STA
    hw.write(cpu.address("absy", 0x20Au), cpu.a, cpu.m8?8:16);
    goto L_82B6B0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB6ADu,0x82B6ADu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B6B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6B0u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B0u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B0u, 5u, 3u, cpu.address("absy", 0x0226u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6B0 STA
    hw.write(cpu.address("absy", 0x226u), cpu.a, cpu.m8?8:16);
    goto L_82B6B3;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B0u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B0u, 5u, 3u, cpu.address("absy", 0x0226u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6B0 STA
    hw.write(cpu.address("absy", 0x226u), cpu.a, cpu.m8?8:16);
    goto L_82B6B3;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B0u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B0u, 5u, 3u, cpu.address("absy", 0x0226u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6B0 STA
    hw.write(cpu.address("absy", 0x226u), cpu.a, cpu.m8?8:16);
    goto L_82B6B3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB6B0u,0x82B6B0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B6B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6B3u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6B3 LDA
    cpu.setA(0xF8u, 8);
    goto L_82B6B5;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6B3 LDA
    cpu.setA(0xF8u, 8);
    goto L_82B6B5;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6B3 LDA
    cpu.setA(0xF8u, 8);
    goto L_82B6B5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB6B3u,0x82B6B3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B6B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6B5u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B5u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B5u, 5u, 3u, cpu.address("absy", 0x020Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6B5 STA
    hw.write(cpu.address("absy", 0x20Bu), cpu.a, cpu.m8?8:16);
    goto L_82B6B8;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B5u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B5u, 5u, 3u, cpu.address("absy", 0x020Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6B5 STA
    hw.write(cpu.address("absy", 0x20Bu), cpu.a, cpu.m8?8:16);
    goto L_82B6B8;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B5u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B5u, 5u, 3u, cpu.address("absy", 0x020Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6B5 STA
    hw.write(cpu.address("absy", 0x20Bu), cpu.a, cpu.m8?8:16);
    goto L_82B6B8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB6B5u,0x82B6B5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B6B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6B8u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6B8 LDA
    cpu.setA(0xFCu, 8);
    goto L_82B6BA;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6B8 LDA
    cpu.setA(0xFCu, 8);
    goto L_82B6BA;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6B8 LDA
    cpu.setA(0xFCu, 8);
    goto L_82B6BA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB6B8u,0x82B6B8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B6BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6BAu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BAu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BAu, 5u, 3u, cpu.address("absy", 0x0227u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6BA STA
    hw.write(cpu.address("absy", 0x227u), cpu.a, cpu.m8?8:16);
    goto L_82B6BD;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BAu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BAu, 5u, 3u, cpu.address("absy", 0x0227u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6BA STA
    hw.write(cpu.address("absy", 0x227u), cpu.a, cpu.m8?8:16);
    goto L_82B6BD;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BAu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BAu, 5u, 3u, cpu.address("absy", 0x0227u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6BA STA
    hw.write(cpu.address("absy", 0x227u), cpu.a, cpu.m8?8:16);
    goto L_82B6BD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB6BAu,0x82B6BAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B6BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6BDu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BDu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BDu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B6BD RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B6BDu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B6BDu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BDu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BDu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B6BD RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B6BDu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B6BDu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BDu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BDu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B6BD RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B6BDu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B6BDu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB6BDu,0x82B6BDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_82B7BB_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B7BBu: goto L_82B7BB;
    case 0x82B7BEu: goto L_82B7BE;
    case 0x82B7C0u: goto L_82B7C0;
    case 0x82B7C3u: goto L_82B7C3;
    case 0x82B7C6u: goto L_82B7C6;
    case 0x82B7C9u: goto L_82B7C9;
    case 0x82B7CBu: goto L_82B7CB;
    case 0x82B7CDu: goto L_82B7CD;
    case 0x82B7D0u: goto L_82B7D0;
    case 0x82B7D2u: goto L_82B7D2;
    case 0x82B7D5u: goto L_82B7D5;
    case 0x82B7D8u: goto L_82B7D8;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B7BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7BBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7BBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7BB LDA
    cpu.setA(0xFFFFu, 16);
    goto L_82B7BE;
L_82B7BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7BEu,cpu,0x92u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7BEu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 2u, 0u);
    // $82B7BE STA
    hw.write(cpu.addressDpIndirect(hw, 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82B7C0;
L_82B7C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7C0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7C0u, 6u, 3u, cpu.address("abs", 0xBA82u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B7C0 JSR -> $82BA82 stack real
    { cpu.push16Value(hw,0xB7C2u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB7C3u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBA82u), 0x82B7C0u); }
    goto L_82B7C3;
L_82B7C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7C3u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB7C3u,0x82B7C3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7C3u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7C3u, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7C3 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B7C6;
L_82B7C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7C6u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7C6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7C6 CMP
    cpu.compareA(0x2u);
    goto L_82B7C9;
L_82B7C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7C9u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7C9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7C9 BCC -> $82B7D0
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_82B7D0; }
    goto L_82B7CB;
L_82B7CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7CBu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7CBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7CB LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B7CD;
L_82B7CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7CDu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7CDu, 6u, 3u, cpu.address("abs", 0xCB5Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B7CD JSR -> $82CB5F stack real
    { cpu.push16Value(hw,0xB7CFu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB7D0u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCB5Fu), 0x82B7CDu); }
    goto L_82B7D0;
L_82B7D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7D0u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB7D0u,0x82B7D0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7D0u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7D0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7D0 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B7D2;
L_82B7D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7D2u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7D2u, 9u, 3u, cpu.address("absx", 0x0200u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7D2 INC
    cpu.incMem(hw, cpu.address("absx", 0x200u), cpu.m8?8:16);
    goto L_82B7D5;
L_82B7D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7D5u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7D5u, 6u, 3u, cpu.address("absx", 0x02C8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7D5 STZ
    hw.write(cpu.address("absx", 0x2C8u), 0, cpu.m8?8:16);
    goto L_82B7D8;
L_82B7D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7D8u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7D8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B7D8 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B7D8u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B7D8u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82C152_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82C152u: goto L_82C152;
    case 0x82C154u: goto L_82C154;
    case 0x82C156u: goto L_82C156;
    case 0x82C159u: goto L_82C159;
    case 0x82C15Bu: goto L_82C15B;
    case 0x82C15Eu: goto L_82C15E;
    case 0x82C160u: goto L_82C160;
    case 0x82C163u: goto L_82C163;
    case 0x82C165u: goto L_82C165;
    case 0x82C168u: goto L_82C168;
    case 0x82C16Au: goto L_82C16A;
    case 0x82C16Du: goto L_82C16D;
    case 0x82C16Fu: goto L_82C16F;
    case 0x82C172u: goto L_82C172;
    case 0x82C175u: goto L_82C175;
    case 0x82C176u: goto L_82C176;
    case 0x82C179u: goto L_82C179;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82C152:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC152u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC152u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC152u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C152 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C154;
L_82C154:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC154u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC154u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC154u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C154 BNE -> $82C179
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C179; }
    goto L_82C156;
L_82C156:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC156u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC156u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC156u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C156 LDA
    cpu.setA(0x1u, 16);
    goto L_82C159;
L_82C159:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC159u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC159u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC159u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C159 STA
    hw.write(cpu.address("dp", 0x6Fu), cpu.a, cpu.m8?8:16);
    goto L_82C15B;
L_82C15B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC15Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC15Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC15Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C15B LDA
    cpu.setA(0x300u, 16);
    goto L_82C15E;
L_82C15E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC15Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC15Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC15Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C15E STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_82C160;
L_82C160:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC160u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC160u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC160u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C160 LDA
    cpu.setA(0xC369u, 16);
    goto L_82C163;
L_82C163:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC163u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC163u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC163u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C163 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82C165;
L_82C165:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC165u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC165u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC165u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C165 LDA
    cpu.setA(0x82u, 16);
    goto L_82C168;
L_82C168:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC168u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC168u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC168u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C168 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_82C16A;
L_82C16A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC16Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC16Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC16Au, 6u, 3u, cpu.address("abs", 0xC2E2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C16A JSR -> $82C2E2 stack real
    { cpu.push16Value(hw,0xC16Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC16Du,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC2E2u), 0x82C16Au); }
    goto L_82C16D;
L_82C16D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC16Du))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC16Du,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC16Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C16D BCC -> $82C176
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_82C176; }
    goto L_82C16F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC16Du,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC16Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C16D BCC -> $82C176
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_82C176; }
    goto L_82C16F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC16Du,0x82C16Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82C16F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC16Fu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC16Fu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC16Fu, 8u, 3u, cpu.address("abs", 0x0176u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C16F INC
    cpu.incMem(hw, cpu.address("abs", 0x176u), cpu.m8?8:16);
    goto L_82C172;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC16Fu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC16Fu, 8u, 3u, cpu.address("abs", 0x0176u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C16F INC
    cpu.incMem(hw, cpu.address("abs", 0x176u), cpu.m8?8:16);
    goto L_82C172;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC16Fu,0x82C16Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82C172:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC172u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC172u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC172u, 5u, 3u, cpu.address("abs", 0x02CCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C172 STZ
    hw.write(cpu.address("abs", 0x2CCu), 0, cpu.m8?8:16);
    goto L_82C175;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC172u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC172u, 5u, 3u, cpu.address("abs", 0x02CCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C172 STZ
    hw.write(cpu.address("abs", 0x2CCu), 0, cpu.m8?8:16);
    goto L_82C175;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC172u,0x82C172u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82C175:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC175u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC175u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC175u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C175 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C175u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C175u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC175u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC175u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C175 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C175u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C175u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC175u,0x82C175u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82C176:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC176u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC176u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC176u, 8u, 3u, cpu.address("abs", 0x02CCu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C176 INC
    cpu.incMem(hw, cpu.address("abs", 0x2CCu), cpu.m8?8:16);
    goto L_82C179;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC176u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC176u, 8u, 3u, cpu.address("abs", 0x02CCu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C176 INC
    cpu.incMem(hw, cpu.address("abs", 0x2CCu), cpu.m8?8:16);
    goto L_82C179;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC176u,0x82C176u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82C179:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC179u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC179u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC179u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C179 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C179u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C179u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC179u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC179u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C179 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C179u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C179u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC179u,0x82C179u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_82D3F0_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82D3F0u: goto L_82D3F0;
    case 0x82D3F3u: goto L_82D3F3;
    case 0x82D3F5u: goto L_82D3F5;
    case 0x82D3F7u: goto L_82D3F7;
    case 0x82D3F9u: goto L_82D3F9;
    case 0x82D3FCu: goto L_82D3FC;
    case 0x82D3FFu: goto L_82D3FF;
    case 0x82D401u: goto L_82D401;
    case 0x82D404u: goto L_82D404;
    case 0x82D405u: goto L_82D405;
    case 0x82D408u: goto L_82D408;
    case 0x82D40Bu: goto L_82D40B;
    case 0x82D40Eu: goto L_82D40E;
    case 0x82D410u: goto L_82D410;
    case 0x82D412u: goto L_82D412;
    case 0x82D415u: goto L_82D415;
    case 0x82D416u: goto L_82D416;
    case 0x82D417u: goto L_82D417;
    case 0x82D41Bu: goto L_82D41B;
    case 0x82D41Eu: goto L_82D41E;
    case 0x82D420u: goto L_82D420;
    case 0x82D424u: goto L_82D424;
    case 0x82D427u: goto L_82D427;
    case 0x82D428u: goto L_82D428;
    case 0x82D42Au: goto L_82D42A;
    case 0x82D42Bu: goto L_82D42B;
    case 0x82D42Du: goto L_82D42D;
    case 0x82D430u: goto L_82D430;
    case 0x82D432u: goto L_82D432;
    case 0x82D435u: goto L_82D435;
    case 0x82D437u: goto L_82D437;
    case 0x82D438u: goto L_82D438;
    case 0x82D439u: goto L_82D439;
    case 0x82D43Bu: goto L_82D43B;
    case 0x82D43Du: goto L_82D43D;
    case 0x82D440u: goto L_82D440;
    case 0x82D442u: goto L_82D442;
    case 0x82D444u: goto L_82D444;
    case 0x82D447u: goto L_82D447;
    case 0x82D449u: goto L_82D449;
    case 0x82D44Cu: goto L_82D44C;
    case 0x82D44Fu: goto L_82D44F;
    case 0x82D451u: goto L_82D451;
    case 0x82D454u: goto L_82D454;
    case 0x82D456u: goto L_82D456;
    case 0x82D459u: goto L_82D459;
    case 0x82D45Cu: goto L_82D45C;
    case 0x82D45Eu: goto L_82D45E;
    case 0x82D461u: goto L_82D461;
    case 0x82D464u: goto L_82D464;
    case 0x82D467u: goto L_82D467;
    case 0x82D468u: goto L_82D468;
    case 0x82D46Bu: goto L_82D46B;
    case 0x82D46Du: goto L_82D46D;
    case 0x82D470u: goto L_82D470;
    case 0x82D471u: goto L_82D471;
    case 0x82D474u: goto L_82D474;
    case 0x82D476u: goto L_82D476;
    case 0x82D479u: goto L_82D479;
    case 0x82D47Cu: goto L_82D47C;
    case 0x82D47Eu: goto L_82D47E;
    case 0x82D480u: goto L_82D480;
    case 0x82D483u: goto L_82D483;
    case 0x82D486u: goto L_82D486;
    case 0x82D488u: goto L_82D488;
    case 0x82D48Bu: goto L_82D48B;
    case 0x82D48Eu: goto L_82D48E;
    case 0x82D48Fu: goto L_82D48F;
    case 0x82D490u: goto L_82D490;
    case 0x82D492u: goto L_82D492;
    case 0x82D494u: goto L_82D494;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82D3F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3F0u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3F0u, 5u, 3u, cpu.address("abs", 0x089Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3F0 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x89Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D3F3;
L_82D3F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3F3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3F3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3F3 BNE -> $82D449
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82D449; }
    goto L_82D3F5;
L_82D3F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3F5u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3F5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3F5 STZ
    hw.write(cpu.address("dp", 0x0u), 0, cpu.m8?8:16);
    goto L_82D3F7;
L_82D3F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3F7u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3F7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3F7 STZ
    hw.write(cpu.address("dp", 0x2u), 0, cpu.m8?8:16);
    goto L_82D3F9;
L_82D3F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3F9u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3F9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3F9 LDX
    cpu.setX(0x0u, 16);
    goto L_82D3FC;
L_82D3FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3FCu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3FCu, 5u + 1u, 3u, cpu.address("absx", 0x0884u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3FC LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x884u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D3FF;
L_82D3FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3FFu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3FFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3FF BMI -> $82D437
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82D437; }
    goto L_82D401;
L_82D401:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD401u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD401u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD401u, 5u + 1u, 3u, cpu.address("absx", 0x088Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D401 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x88Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D404;
L_82D404:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD404u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD404u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD404u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D404 INC
    cpu.inc('A');
    goto L_82D405;
L_82D405:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD405u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD405u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD405u, 6u, 3u, cpu.address("absx", 0x08A0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D405 STA
    hw.write(cpu.address("absx", 0x8A0u), cpu.a, cpu.m8?8:16);
    goto L_82D408;
L_82D408:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD408u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD408u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD408u, 5u + 1u, 3u, cpu.address("absx", 0x0894u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D408 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x894u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D40B;
L_82D40B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD40Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD40Bu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD40Bu, 6u, 3u, cpu.address("absx", 0x08A8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D40B STA
    hw.write(cpu.address("absx", 0x8A8u), cpu.a, cpu.m8?8:16);
    goto L_82D40E;
L_82D40E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD40Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD40Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD40Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D40E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D410;
L_82D410:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD410u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD410u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD410u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D410 BNE -> $82D435
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82D435; }
    goto L_82D412;
L_82D412:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD412u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD412u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD412u, 5u + 1u, 3u, cpu.address("absx", 0x0884u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D412 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x884u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D415;
L_82D415:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD415u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD415u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD415u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D415 PHX
    cpu.push("PHX", hw);
    goto L_82D416;
L_82D416:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD416u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD416u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD416u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D416 TAX
    cpu.transfer("TAX");
    goto L_82D417;
L_82D417:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD417u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD417u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD417u, 6u, 4u, ((0x9E95D6u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D417 LDA
    cpu.loadA(hw.readW(((0x9E95D6u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D41B;
L_82D41B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD41Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD41Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD41Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D41B AND
    cpu.logicAnd(0xFFu);
    goto L_82D41E;
L_82D41E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD41Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD41Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD41Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D41E STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_82D420;
L_82D420:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD420u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD420u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD420u, 6u, 4u, ((0x9E95EAu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D420 LDA
    cpu.loadA(hw.readW(((0x9E95EAu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D424;
L_82D424:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD424u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD424u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD424u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D424 AND
    cpu.logicAnd(0xFFu);
    goto L_82D427;
L_82D427:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD427u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD427u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD427u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D427 INC
    cpu.inc('A');
    goto L_82D428;
L_82D428:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD428u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD428u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD428u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D428 STA
    hw.write(cpu.address("dp", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_82D42A;
L_82D42A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD42Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD42Au,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD42Au, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D42A PLX
    cpu.pop("PLX", hw);
    goto L_82D42B;
L_82D42B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD42Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD42Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD42Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D42B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D42D;
L_82D42D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD42Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD42Du,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD42Du, 6u, 3u, cpu.address("absx", 0x08A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D42D STA
    hw.write(cpu.address("absx", 0x8A6u), cpu.a, cpu.m8?8:16);
    goto L_82D430;
L_82D430:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD430u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD430u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD430u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D430 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D432;
L_82D432:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD432u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD432u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD432u, 6u, 3u, cpu.address("absx", 0x089Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D432 STA
    hw.write(cpu.address("absx", 0x89Eu), cpu.a, cpu.m8?8:16);
    goto L_82D435;
L_82D435:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD435u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD435u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD435u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D435 INC
    cpu.incMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_82D437;
L_82D437:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD437u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD437u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD437u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D437 INX
    cpu.inc('X');
    goto L_82D438;
L_82D438:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD438u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD438u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD438u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D438 INX
    cpu.inc('X');
    goto L_82D439;
L_82D439:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD439u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD439u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD439u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D439 INC
    cpu.incMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_82D43B;
L_82D43B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD43Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD43Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD43Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D43B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D43D;
L_82D43D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD43Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD43Du,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD43Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D43D CMP
    cpu.compareA(0x3u);
    goto L_82D440;
L_82D440:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD440u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD440u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD440u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D440 BCC -> $82D3FC
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_82D3FC; }
    goto L_82D442;
L_82D442:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD442u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD442u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD442u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D442 BEQ -> $82D40E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82D40E; }
    goto L_82D444;
L_82D444:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD444u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD444u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD444u, 8u, 3u, cpu.address("abs", 0x089Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D444 INC
    cpu.incMem(hw, cpu.address("abs", 0x89Cu), cpu.m8?8:16);
    goto L_82D447;
L_82D447:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD447u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD447u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD447u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D447 BRA -> $82D494
    goto L_82D494;
L_82D449:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD449u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD449u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD449u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D449 LDX
    cpu.setX(0x0u, 16);
    goto L_82D44C;
L_82D44C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD44Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD44Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD44Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D44C LDA
    cpu.setA(0x3u, 16);
    goto L_82D44F;
L_82D44F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD44Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD44Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD44Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D44F STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82D451;
L_82D451:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD451u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD451u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD451u, 5u + 1u, 3u, cpu.address("absx", 0x0884u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D451 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x884u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D454;
L_82D454:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD454u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD454u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD454u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D454 BMI -> $82D48E
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82D48E; }
    goto L_82D456;
L_82D456:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD456u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD456u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD456u, 5u + 1u, 3u, cpu.address("absx", 0x088Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D456 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x88Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D459;
L_82D459:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD459u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD459u,cpu,0xDDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD459u, 5u + 1u, 3u, cpu.address("absx", 0x089Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D459 CMP
    cpu.compareA(hw.readW(cpu.address("absx", 0x89Eu), cpu.m8?8:16));
    goto L_82D45C;
L_82D45C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD45Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD45Cu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD45Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D45C BCC -> $82D464
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_82D464; }
    goto L_82D45E;
L_82D45E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD45Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD45Eu,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD45Eu, 9u, 3u, cpu.address("absx", 0x088Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D45E DEC
    cpu.decMem(hw, cpu.address("absx", 0x88Cu), cpu.m8?8:16);
    goto L_82D461;
L_82D461:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD461u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD461u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD461u, 9u, 3u, cpu.address("absx", 0x088Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D461 DEC
    cpu.decMem(hw, cpu.address("absx", 0x88Cu), cpu.m8?8:16);
    goto L_82D464;
L_82D464:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD464u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD464u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD464u, 5u + 1u, 3u, cpu.address("absx", 0x0894u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D464 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x894u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D467;
L_82D467:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD467u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD467u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD467u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D467 INC
    cpu.inc('A');
    goto L_82D468;
L_82D468:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD468u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD468u,cpu,0xDDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD468u, 5u + 1u, 3u, cpu.address("absx", 0x08A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D468 CMP
    cpu.compareA(hw.readW(cpu.address("absx", 0x8A6u), cpu.m8?8:16));
    goto L_82D46B;
L_82D46B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD46Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD46Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD46Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D46B BEQ -> $82D48E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82D48E; }
    goto L_82D46D;
L_82D46D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD46Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD46Du,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD46Du, 5u + 1u, 3u, cpu.address("absx", 0x0894u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D46D LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x894u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D470;
L_82D470:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD470u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD470u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD470u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D470 DEC
    cpu.decReg('A');
    goto L_82D471;
L_82D471:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD471u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD471u,cpu,0xDDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD471u, 5u + 1u, 3u, cpu.address("absx", 0x08A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D471 CMP
    cpu.compareA(hw.readW(cpu.address("absx", 0x8A6u), cpu.m8?8:16));
    goto L_82D474;
L_82D474:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD474u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD474u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD474u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D474 BEQ -> $82D48E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82D48E; }
    goto L_82D476;
L_82D476:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD476u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD476u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD476u, 5u + 1u, 3u, cpu.address("absx", 0x0894u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D476 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x894u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D479;
L_82D479:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD479u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD479u,cpu,0xDDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD479u, 5u + 1u, 3u, cpu.address("absx", 0x08A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D479 CMP
    cpu.compareA(hw.readW(cpu.address("absx", 0x8A6u), cpu.m8?8:16));
    goto L_82D47C;
L_82D47C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD47Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD47Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD47Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D47C BEQ -> $82D48E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82D48E; }
    goto L_82D47E;
L_82D47E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD47Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD47Eu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD47Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D47E BCS -> $82D488
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_82D488; }
    goto L_82D480;
L_82D480:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD480u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD480u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD480u, 9u, 3u, cpu.address("absx", 0x0894u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D480 INC
    cpu.incMem(hw, cpu.address("absx", 0x894u), cpu.m8?8:16);
    goto L_82D483;
L_82D483:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD483u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD483u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD483u, 9u, 3u, cpu.address("absx", 0x0894u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D483 INC
    cpu.incMem(hw, cpu.address("absx", 0x894u), cpu.m8?8:16);
    goto L_82D486;
L_82D486:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD486u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD486u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD486u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D486 BRA -> $82D48E
    goto L_82D48E;
L_82D488:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD488u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD488u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD488u, 9u, 3u, cpu.address("absx", 0x0894u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D488 DEC
    cpu.decMem(hw, cpu.address("absx", 0x894u), cpu.m8?8:16);
    goto L_82D48B;
L_82D48B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD48Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD48Bu,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD48Bu, 9u, 3u, cpu.address("absx", 0x0894u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D48B DEC
    cpu.decMem(hw, cpu.address("absx", 0x894u), cpu.m8?8:16);
    goto L_82D48E;
L_82D48E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD48Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD48Eu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD48Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D48E INX
    cpu.inc('X');
    goto L_82D48F;
L_82D48F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD48Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD48Fu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD48Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D48F INX
    cpu.inc('X');
    goto L_82D490;
L_82D490:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD490u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD490u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD490u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D490 DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_82D492;
L_82D492:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD492u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD492u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD492u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D492 BPL -> $82D451
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82D451; }
    goto L_82D494;
L_82D494:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD494u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD494u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD494u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D494 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82D494u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82D494u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82D4E4_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82D4E4u: goto L_82D4E4;
    case 0x82D4E6u: goto L_82D4E6;
    case 0x82D4E8u: goto L_82D4E8;
    case 0x82D4EBu: goto L_82D4EB;
    case 0x82D4EDu: goto L_82D4ED;
    case 0x82D4F0u: goto L_82D4F0;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82D4E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4E4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4E4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D4E4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D4E6;
L_82D4E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4E6u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4E6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D4E6 BNE -> $82D4F0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82D4F0; }
    goto L_82D4E8;
L_82D4E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4E8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4E8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D4E8 LDA
    cpu.setA(0x3u, 16);
    goto L_82D4EB;
L_82D4EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4EBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4EBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D4EB STA
    hw.write(cpu.address("dp", 0x6Fu), cpu.a, cpu.m8?8:16);
    goto L_82D4ED;
L_82D4ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4EDu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4EDu, 6u, 3u, cpu.address("abs", 0xD56Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D4ED JSR -> $82D56B stack real
    { cpu.push16Value(hw,0xD4EFu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD4F0u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD56Bu), 0x82D4EDu); }
    goto L_82D4F0;
L_82D4F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4F0u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4F0u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4F0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D4F0 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82D4F0u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82D4F0u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4F0u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4F0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D4F0 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82D4F0u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82D4F0u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD4F0u,0x82D4F0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_82DE01_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82DE01u: goto L_82DE01;
    case 0x82DE03u: goto L_82DE03;
    case 0x82DE06u: goto L_82DE06;
    case 0x82DE08u: goto L_82DE08;
    case 0x82DE0Au: goto L_82DE0A;
    case 0x82DE0Du: goto L_82DE0D;
    case 0x82DE0Eu: goto L_82DE0E;
    case 0x82DE11u: goto L_82DE11;
    case 0x82DE15u: goto L_82DE15;
    case 0x82DE17u: goto L_82DE17;
    case 0x82DE19u: goto L_82DE19;
    case 0x82DE1Bu: goto L_82DE1B;
    case 0x82DE1Du: goto L_82DE1D;
    case 0x82DE20u: goto L_82DE20;
    case 0x82DE21u: goto L_82DE21;
    case 0x82DE24u: goto L_82DE24;
    case 0x82DE25u: goto L_82DE25;
    case 0x82DE28u: goto L_82DE28;
    case 0x82DE2Bu: goto L_82DE2B;
    case 0x82DE2Eu: goto L_82DE2E;
    case 0x82DE31u: goto L_82DE31;
    case 0x82DE34u: goto L_82DE34;
    case 0x82DE37u: goto L_82DE37;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82DE01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE01u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE01u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DE01 STZ
    hw.write(cpu.address("dp", 0x0u), 0, cpu.m8?8:16);
    goto L_82DE03;
L_82DE03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE03u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE03u, 5u, 3u, cpu.address("abs", 0x015Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DE03 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x15Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82DE06;
L_82DE06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE06u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE06u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DE06 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_82DE08;
L_82DE08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE08u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE08u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DE08 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82DE0A;
L_82DE0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE0Au,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE0Au, 5u + 1u, 3u, cpu.address("absx", 0x015Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DE0A LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x15Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82DE0D;
L_82DE0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE0Du,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE0Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DE0D TAX
    cpu.transfer("TAX");
    goto L_82DE0E;
L_82DE0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE0Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE0Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DE0E LDA
    cpu.setA(0x0u, 16);
    goto L_82DE11;
L_82DE11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE11u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE11u, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DE11 STA
    hw.write(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_82DE15;
L_82DE15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE15u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE15u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DE15 INC
    cpu.incMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_82DE17;
L_82DE17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE17u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE17u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DE17 INC
    cpu.incMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_82DE19;
L_82DE19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE19u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE19u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DE19 DEC
    cpu.decMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_82DE1B;
L_82DE1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE1Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE1Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DE1B BNE -> $82DE08
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82DE08; }
    goto L_82DE1D;
L_82DE1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE1Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE1Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DE1D LDA
    cpu.setA(0x84u, 16);
    goto L_82DE20;
L_82DE20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE20u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE20u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DE20 CLC
    cpu.setFlag('C', false);
    goto L_82DE21;
L_82DE21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE21u,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE21u, 5u, 3u, cpu.address("abs", 0x013Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DE21 ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x13Fu), cpu.m8?8:16));
    goto L_82DE24;
L_82DE24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE24u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE24u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DE24 TAX
    cpu.transfer("TAX");
    goto L_82DE25;
L_82DE25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE25u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE25u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DE25 LDY
    cpu.setY(0x6u, 16);
    goto L_82DE28;
L_82DE28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE28u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE28u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DE28 LDA
    cpu.setA(0x0u, 16);
    goto L_82DE2B;
L_82DE2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE2Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE2Bu, 6u, 3u, cpu.address("abs", 0xABCFu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82DE2B JSR -> $82ABCF stack real
    { cpu.push16Value(hw,0xDE2Du); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDE2Eu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xABCFu), 0x82DE2Bu); }
    goto L_82DE2E;
L_82DE2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE2Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDE2Eu,0x82DE2Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE2Eu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE2Eu, 5u, 3u, cpu.address("abs", 0x015Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DE2E STZ
    hw.write(cpu.address("abs", 0x15Au), 0, cpu.m8?8:16);
    goto L_82DE31;
L_82DE31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE31u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE31u, 5u, 3u, cpu.address("abs", 0x013Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DE31 STZ
    hw.write(cpu.address("abs", 0x13Du), 0, cpu.m8?8:16);
    goto L_82DE34;
L_82DE34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE34u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE34u, 8u, 3u, cpu.address("abs", 0x013Bu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DE34 INC
    cpu.incMem(hw, cpu.address("abs", 0x13Bu), cpu.m8?8:16);
    goto L_82DE37;
L_82DE37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE37u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE37u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82DE37 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82DE37u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82DE37u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_8480F2_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8480F2u: goto L_8480F2;
    case 0x8480F4u: goto L_8480F4;
    case 0x8480F6u: goto L_8480F6;
    case 0x8480F8u: goto L_8480F8;
    case 0x8480FBu: goto L_8480FB;
    case 0x8480FDu: goto L_8480FD;
    case 0x8480FFu: goto L_8480FF;
    case 0x848101u: goto L_848101;
    case 0x848103u: goto L_848103;
    case 0x848104u: goto L_848104;
    case 0x848105u: goto L_848105;
    case 0x848106u: goto L_848106;
    case 0x848107u: goto L_848107;
    case 0x848109u: goto L_848109;
    case 0x84810Cu: goto L_84810C;
    case 0x84810Eu: goto L_84810E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8480F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F2u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8480F2 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x8u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_8480F4;
L_8480F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F4u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8480F4 STZ
    hw.write(cpu.address("dp", 0x4u), 0, cpu.m8?8:16);
    goto L_8480F6;
L_8480F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8480F6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8480F8;
L_8480F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F8u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8480F8 CMP
    cpu.compareA(0x5u);
    goto L_8480FB;
L_8480FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80FBu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80FBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8480FB BCS -> $84810E
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_84810E; }
    goto L_8480FD;
L_8480FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80FDu,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80FDu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $8480FD LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8480FF;
L_8480FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80FFu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80FFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8480FF BEQ -> $848103
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_848103; }
    goto L_848101;
L_848101:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8101u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8101u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8101u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848101 INC
    cpu.incMem(hw, cpu.address("dp", 0x4u), cpu.m8?8:16);
    goto L_848103;
L_848103:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8103u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8103u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8103u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848103 INY
    cpu.inc('Y');
    goto L_848104;
L_848104:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8104u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8104u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8104u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848104 INY
    cpu.inc('Y');
    goto L_848105;
L_848105:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8105u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8105u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8105u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848105 TYA
    cpu.transfer("TYA");
    goto L_848106;
L_848106:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8106u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8106u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8106u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848106 SEC
    cpu.setFlag('C', true);
    goto L_848107;
L_848107:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8107u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8107u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8107u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848107 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_848109;
L_848109:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8109u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8109u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8109u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848109 CMP
    cpu.compareA(0x13u);
    goto L_84810C;
L_84810C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x810Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x810Cu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x810Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84810C BCC -> $8480F6
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_8480F6; }
    goto L_84810E;
L_84810E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x810Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x810Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x810Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84810E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84810Eu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84810Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_848827_E0M1X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848827u: goto L_848827;
    case 0x848829u: goto L_848829;
    case 0x84882Bu: goto L_84882B;
    case 0x84882Eu: goto L_84882E;
    case 0x848830u: goto L_848830;
    case 0x848833u: goto L_848833;
    case 0x848835u: goto L_848835;
    case 0x848837u: goto L_848837;
    case 0x848839u: goto L_848839;
    case 0x84883Cu: goto L_84883C;
    case 0x84883Fu: goto L_84883F;
    case 0x848841u: goto L_848841;
    case 0x848843u: goto L_848843;
    case 0x848845u: goto L_848845;
    case 0x848848u: goto L_848848;
    case 0x84884Au: goto L_84884A;
    case 0x84884Cu: goto L_84884C;
    case 0x84884Fu: goto L_84884F;
    case 0x848852u: goto L_848852;
    case 0x848854u: goto L_848854;
    case 0x848857u: goto L_848857;
    case 0x848859u: goto L_848859;
    case 0x84885Bu: goto L_84885B;
    case 0x84885Eu: goto L_84885E;
    case 0x848861u: goto L_848861;
    case 0x848864u: goto L_848864;
    case 0x848868u: goto L_848868;
    case 0x848869u: goto L_848869;
    case 0x84886Bu: goto L_84886B;
    case 0x84886Cu: goto L_84886C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848827:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8827u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8827u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8827u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848827 REP
    cpu.rep(0x20u);
    goto L_848829;
L_848829:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8829u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8829u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8829u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848829 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84882B;
L_84882B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x882Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x882Bu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x882Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84882B BIT
    cpu.bit(0x400u, true);
    goto L_84882E;
L_84882E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x882Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x882Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x882Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84882E BNE -> $848837
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_848837; }
    goto L_848830;
L_848830:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8830u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8830u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8830u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848830 BIT
    cpu.bit(0x800u, true);
    goto L_848833;
L_848833:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8833u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8833u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8833u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848833 BNE -> $84884A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_84884A; }
    goto L_848835;
L_848835:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8835u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8835u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8835u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848835 BRA -> $84886B
    goto L_84886B;
L_848837:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8837u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8837u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8837u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848837 SEP
    cpu.sep(0x20u);
    goto L_848839;
L_848839:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8839u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8839u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8839u, 6u, 3u, cpu.address("abs", 0x0629u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848839 INC
    cpu.incMem(hw, cpu.address("abs", 0x629u), cpu.m8?8:16);
    goto L_84883C;
L_84883C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x883Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x883Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x883Cu, 4u, 3u, cpu.address("abs", 0x0629u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84883C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x629u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84883F;
L_84883F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x883Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x883Fu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x883Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84883F CMP
    cpu.compareA(0x3u);
    goto L_848841;
L_848841:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8841u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8841u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8841u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848841 BCC -> $848859
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_848859; }
    goto L_848843;
L_848843:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8843u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8843u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8843u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848843 LDA
    cpu.setA(0x2u, 8);
    goto L_848845;
L_848845:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8845u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8845u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8845u, 4u, 3u, cpu.address("abs", 0x0629u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848845 STA
    hw.write(cpu.address("abs", 0x629u), cpu.a, cpu.m8?8:16);
    goto L_848848;
L_848848:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8848u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8848u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8848u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848848 BRA -> $84886B
    goto L_84886B;
L_84884A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x884Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x884Au,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x884Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84884A SEP
    cpu.sep(0x20u);
    goto L_84884C;
L_84884C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x884Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x884Cu,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x884Cu, 6u, 3u, cpu.address("abs", 0x0629u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84884C DEC
    cpu.decMem(hw, cpu.address("abs", 0x629u), cpu.m8?8:16);
    goto L_84884F;
L_84884F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x884Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x884Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x884Fu, 4u, 3u, cpu.address("abs", 0x0629u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84884F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x629u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848852;
L_848852:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8852u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8852u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8852u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848852 BPL -> $848859
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_848859; }
    goto L_848854;
L_848854:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8854u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8854u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8854u, 4u, 3u, cpu.address("abs", 0x0629u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848854 STZ
    hw.write(cpu.address("abs", 0x629u), 0, cpu.m8?8:16);
    goto L_848857;
L_848857:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8857u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8857u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8857u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848857 BRA -> $84886B
    goto L_84886B;
L_848859:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8859u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8859u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8859u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848859 REP
    cpu.rep(0x20u);
    goto L_84885B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8859u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8859u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848859 REP
    cpu.rep(0x20u);
    goto L_84885B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8859u,0x848859u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84885B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x885Bu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x885Bu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x885Bu, 5u, 3u, cpu.address("abs", 0x065Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84885B STZ
    hw.write(cpu.address("abs", 0x65Eu), 0, cpu.m8?8:16);
    goto L_84885E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x885Bu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x885Bu, 5u, 3u, cpu.address("abs", 0x065Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84885B STZ
    hw.write(cpu.address("abs", 0x65Eu), 0, cpu.m8?8:16);
    goto L_84885E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x885Bu,0x84885Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84885E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x885Eu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x885Eu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x885Eu, 5u, 3u, cpu.address("abs", 0x06EBu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84885E STZ
    hw.write(cpu.address("abs", 0x6EBu), 0, cpu.m8?8:16);
    goto L_848861;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x885Eu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x885Eu, 5u, 3u, cpu.address("abs", 0x06EBu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84885E STZ
    hw.write(cpu.address("abs", 0x6EBu), 0, cpu.m8?8:16);
    goto L_848861;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x885Eu,0x84885Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848861:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8861u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8861u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8861u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848861 LDA
    cpu.setA(0x6u, 16);
    goto L_848864;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8861u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8861u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848861 LDA
    cpu.setA(0x6u, 16);
    goto L_848864;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8861u,0x848861u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848864:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8864u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8864u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8864u, 8u, 4u, 0x80A6FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848864 JSL -> $80A6FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8867u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8868u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6FBu, 0x848864u); }
    goto L_848868;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8864u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8864u, 8u, 4u, 0x80A6FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848864 JSL -> $80A6FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8867u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8868u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6FBu, 0x848864u); }
    goto L_848868;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8864u,0x848864u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848868:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8868u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8868u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8868u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848868 SEC
    cpu.setFlag('C', true);
    goto L_848869;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8868u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8868u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848868 SEC
    cpu.setFlag('C', true);
    goto L_848869;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8868u,0x848868u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848869:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8869u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8869u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8869u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848869 BRA -> $84886C
    goto L_84886C;
L_84886B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x886Bu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x886Bu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x886Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84886B CLC
    cpu.setFlag('C', false);
    goto L_84886C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x886Bu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x886Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84886B CLC
    cpu.setFlag('C', false);
    goto L_84886C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x886Bu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x886Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84886B CLC
    cpu.setFlag('C', false);
    goto L_84886C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x886Bu,0x84886Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84886C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x886Cu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x886Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x886Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84886C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84886Cu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84886Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x886Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x886Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84886C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84886Cu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84886Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x886Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x886Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84886C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84886Cu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84886Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x886Cu,0x84886Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_848827_E0M1X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848827u: goto L_848827;
    case 0x848829u: goto L_848829;
    case 0x84882Bu: goto L_84882B;
    case 0x84882Eu: goto L_84882E;
    case 0x848830u: goto L_848830;
    case 0x848833u: goto L_848833;
    case 0x848835u: goto L_848835;
    case 0x848837u: goto L_848837;
    case 0x848839u: goto L_848839;
    case 0x84883Cu: goto L_84883C;
    case 0x84883Fu: goto L_84883F;
    case 0x848841u: goto L_848841;
    case 0x848843u: goto L_848843;
    case 0x848845u: goto L_848845;
    case 0x848848u: goto L_848848;
    case 0x84884Au: goto L_84884A;
    case 0x84884Cu: goto L_84884C;
    case 0x84884Fu: goto L_84884F;
    case 0x848852u: goto L_848852;
    case 0x848854u: goto L_848854;
    case 0x848857u: goto L_848857;
    case 0x848859u: goto L_848859;
    case 0x84885Bu: goto L_84885B;
    case 0x84885Eu: goto L_84885E;
    case 0x848861u: goto L_848861;
    case 0x848864u: goto L_848864;
    case 0x848868u: goto L_848868;
    case 0x848869u: goto L_848869;
    case 0x84886Bu: goto L_84886B;
    case 0x84886Cu: goto L_84886C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848827:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8827u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8827u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8827u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848827 REP
    cpu.rep(0x20u);
    goto L_848829;
L_848829:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8829u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8829u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8829u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848829 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84882B;
L_84882B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x882Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x882Bu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x882Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84882B BIT
    cpu.bit(0x400u, true);
    goto L_84882E;
L_84882E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x882Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x882Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x882Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84882E BNE -> $848837
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_848837; }
    goto L_848830;
L_848830:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8830u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8830u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8830u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848830 BIT
    cpu.bit(0x800u, true);
    goto L_848833;
L_848833:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8833u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8833u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8833u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848833 BNE -> $84884A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_84884A; }
    goto L_848835;
L_848835:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8835u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8835u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8835u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848835 BRA -> $84886B
    goto L_84886B;
L_848837:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8837u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8837u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8837u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848837 SEP
    cpu.sep(0x20u);
    goto L_848839;
L_848839:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8839u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8839u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8839u, 6u, 3u, cpu.address("abs", 0x0629u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848839 INC
    cpu.incMem(hw, cpu.address("abs", 0x629u), cpu.m8?8:16);
    goto L_84883C;
L_84883C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x883Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x883Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x883Cu, 4u, 3u, cpu.address("abs", 0x0629u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84883C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x629u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84883F;
L_84883F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x883Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x883Fu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x883Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84883F CMP
    cpu.compareA(0x3u);
    goto L_848841;
L_848841:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8841u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8841u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8841u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848841 BCC -> $848859
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_848859; }
    goto L_848843;
L_848843:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8843u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8843u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8843u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848843 LDA
    cpu.setA(0x2u, 8);
    goto L_848845;
L_848845:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8845u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8845u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8845u, 4u, 3u, cpu.address("abs", 0x0629u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848845 STA
    hw.write(cpu.address("abs", 0x629u), cpu.a, cpu.m8?8:16);
    goto L_848848;
L_848848:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8848u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8848u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8848u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848848 BRA -> $84886B
    goto L_84886B;
L_84884A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x884Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x884Au,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x884Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84884A SEP
    cpu.sep(0x20u);
    goto L_84884C;
L_84884C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x884Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x884Cu,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x884Cu, 6u, 3u, cpu.address("abs", 0x0629u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84884C DEC
    cpu.decMem(hw, cpu.address("abs", 0x629u), cpu.m8?8:16);
    goto L_84884F;
L_84884F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x884Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x884Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x884Fu, 4u, 3u, cpu.address("abs", 0x0629u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84884F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x629u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848852;
L_848852:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8852u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8852u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8852u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848852 BPL -> $848859
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_848859; }
    goto L_848854;
L_848854:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8854u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8854u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8854u, 4u, 3u, cpu.address("abs", 0x0629u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848854 STZ
    hw.write(cpu.address("abs", 0x629u), 0, cpu.m8?8:16);
    goto L_848857;
L_848857:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8857u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8857u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8857u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848857 BRA -> $84886B
    goto L_84886B;
L_848859:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8859u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8859u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8859u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848859 REP
    cpu.rep(0x20u);
    goto L_84885B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8859u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8859u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848859 REP
    cpu.rep(0x20u);
    goto L_84885B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8859u,0x848859u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84885B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x885Bu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x885Bu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x885Bu, 5u, 3u, cpu.address("abs", 0x065Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84885B STZ
    hw.write(cpu.address("abs", 0x65Eu), 0, cpu.m8?8:16);
    goto L_84885E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x885Bu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x885Bu, 5u, 3u, cpu.address("abs", 0x065Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84885B STZ
    hw.write(cpu.address("abs", 0x65Eu), 0, cpu.m8?8:16);
    goto L_84885E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x885Bu,0x84885Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84885E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x885Eu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x885Eu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x885Eu, 5u, 3u, cpu.address("abs", 0x06EBu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84885E STZ
    hw.write(cpu.address("abs", 0x6EBu), 0, cpu.m8?8:16);
    goto L_848861;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x885Eu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x885Eu, 5u, 3u, cpu.address("abs", 0x06EBu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84885E STZ
    hw.write(cpu.address("abs", 0x6EBu), 0, cpu.m8?8:16);
    goto L_848861;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x885Eu,0x84885Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848861:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8861u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8861u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8861u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848861 LDA
    cpu.setA(0x6u, 16);
    goto L_848864;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8861u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8861u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848861 LDA
    cpu.setA(0x6u, 16);
    goto L_848864;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8861u,0x848861u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848864:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8864u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8864u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8864u, 8u, 4u, 0x80A6FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848864 JSL -> $80A6FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8867u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8868u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6FBu, 0x848864u); }
    goto L_848868;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8864u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8864u, 8u, 4u, 0x80A6FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848864 JSL -> $80A6FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8867u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8868u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6FBu, 0x848864u); }
    goto L_848868;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8864u,0x848864u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848868:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8868u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8868u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8868u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848868 SEC
    cpu.setFlag('C', true);
    goto L_848869;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8868u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8868u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848868 SEC
    cpu.setFlag('C', true);
    goto L_848869;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8868u,0x848868u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848869:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8869u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8869u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8869u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848869 BRA -> $84886C
    goto L_84886C;
L_84886B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x886Bu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x886Bu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x886Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84886B CLC
    cpu.setFlag('C', false);
    goto L_84886C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x886Bu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x886Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84886B CLC
    cpu.setFlag('C', false);
    goto L_84886C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x886Bu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x886Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84886B CLC
    cpu.setFlag('C', false);
    goto L_84886C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x886Bu,0x84886Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84886C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x886Cu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x886Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x886Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84886C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84886Cu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84886Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x886Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x886Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84886C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84886Cu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84886Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x886Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x886Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84886C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84886Cu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84886Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x886Cu,0x84886Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_848827_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848827u: goto L_848827;
    case 0x848829u: goto L_848829;
    case 0x84882Bu: goto L_84882B;
    case 0x84882Eu: goto L_84882E;
    case 0x848830u: goto L_848830;
    case 0x848833u: goto L_848833;
    case 0x848835u: goto L_848835;
    case 0x848837u: goto L_848837;
    case 0x848839u: goto L_848839;
    case 0x84883Cu: goto L_84883C;
    case 0x84883Fu: goto L_84883F;
    case 0x848841u: goto L_848841;
    case 0x848843u: goto L_848843;
    case 0x848845u: goto L_848845;
    case 0x848848u: goto L_848848;
    case 0x84884Au: goto L_84884A;
    case 0x84884Cu: goto L_84884C;
    case 0x84884Fu: goto L_84884F;
    case 0x848852u: goto L_848852;
    case 0x848854u: goto L_848854;
    case 0x848857u: goto L_848857;
    case 0x848859u: goto L_848859;
    case 0x84885Bu: goto L_84885B;
    case 0x84885Eu: goto L_84885E;
    case 0x848861u: goto L_848861;
    case 0x848864u: goto L_848864;
    case 0x848868u: goto L_848868;
    case 0x848869u: goto L_848869;
    case 0x84886Bu: goto L_84886B;
    case 0x84886Cu: goto L_84886C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848827:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8827u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8827u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8827u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848827 REP
    cpu.rep(0x20u);
    goto L_848829;
L_848829:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8829u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8829u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8829u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848829 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84882B;
L_84882B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x882Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x882Bu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x882Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84882B BIT
    cpu.bit(0x400u, true);
    goto L_84882E;
L_84882E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x882Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x882Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x882Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84882E BNE -> $848837
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_848837; }
    goto L_848830;
L_848830:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8830u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8830u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8830u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848830 BIT
    cpu.bit(0x800u, true);
    goto L_848833;
L_848833:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8833u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8833u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8833u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848833 BNE -> $84884A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_84884A; }
    goto L_848835;
L_848835:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8835u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8835u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8835u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848835 BRA -> $84886B
    goto L_84886B;
L_848837:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8837u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8837u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8837u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848837 SEP
    cpu.sep(0x20u);
    goto L_848839;
L_848839:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8839u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8839u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8839u, 6u, 3u, cpu.address("abs", 0x0629u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848839 INC
    cpu.incMem(hw, cpu.address("abs", 0x629u), cpu.m8?8:16);
    goto L_84883C;
L_84883C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x883Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x883Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x883Cu, 4u, 3u, cpu.address("abs", 0x0629u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84883C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x629u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84883F;
L_84883F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x883Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x883Fu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x883Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84883F CMP
    cpu.compareA(0x3u);
    goto L_848841;
L_848841:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8841u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8841u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8841u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848841 BCC -> $848859
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_848859; }
    goto L_848843;
L_848843:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8843u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8843u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8843u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848843 LDA
    cpu.setA(0x2u, 8);
    goto L_848845;
L_848845:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8845u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8845u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8845u, 4u, 3u, cpu.address("abs", 0x0629u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848845 STA
    hw.write(cpu.address("abs", 0x629u), cpu.a, cpu.m8?8:16);
    goto L_848848;
L_848848:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8848u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8848u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8848u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848848 BRA -> $84886B
    goto L_84886B;
L_84884A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x884Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x884Au,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x884Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84884A SEP
    cpu.sep(0x20u);
    goto L_84884C;
L_84884C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x884Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x884Cu,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x884Cu, 6u, 3u, cpu.address("abs", 0x0629u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84884C DEC
    cpu.decMem(hw, cpu.address("abs", 0x629u), cpu.m8?8:16);
    goto L_84884F;
L_84884F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x884Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x884Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x884Fu, 4u, 3u, cpu.address("abs", 0x0629u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84884F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x629u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848852;
L_848852:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8852u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8852u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8852u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848852 BPL -> $848859
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_848859; }
    goto L_848854;
L_848854:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8854u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8854u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8854u, 4u, 3u, cpu.address("abs", 0x0629u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848854 STZ
    hw.write(cpu.address("abs", 0x629u), 0, cpu.m8?8:16);
    goto L_848857;
L_848857:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8857u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8857u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8857u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848857 BRA -> $84886B
    goto L_84886B;
L_848859:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8859u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8859u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8859u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848859 REP
    cpu.rep(0x20u);
    goto L_84885B;
L_84885B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x885Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x885Bu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x885Bu, 5u, 3u, cpu.address("abs", 0x065Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84885B STZ
    hw.write(cpu.address("abs", 0x65Eu), 0, cpu.m8?8:16);
    goto L_84885E;
L_84885E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x885Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x885Eu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x885Eu, 5u, 3u, cpu.address("abs", 0x06EBu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84885E STZ
    hw.write(cpu.address("abs", 0x6EBu), 0, cpu.m8?8:16);
    goto L_848861;
L_848861:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8861u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8861u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8861u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848861 LDA
    cpu.setA(0x6u, 16);
    goto L_848864;
L_848864:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8864u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8864u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8864u, 8u, 4u, 0x80A6FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848864 JSL -> $80A6FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8867u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8868u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6FBu, 0x848864u); }
    goto L_848868;
L_848868:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8868u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8868u,0x848868u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8868u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8868u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848868 SEC
    cpu.setFlag('C', true);
    goto L_848869;
L_848869:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8869u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8869u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8869u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848869 BRA -> $84886C
    goto L_84886C;
L_84886B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x886Bu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x886Bu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x886Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84886B CLC
    cpu.setFlag('C', false);
    goto L_84886C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x886Bu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x886Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84886B CLC
    cpu.setFlag('C', false);
    goto L_84886C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x886Bu,0x84886Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84886C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x886Cu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x886Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x886Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84886C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84886Cu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84886Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x886Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x886Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84886C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84886Cu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84886Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x886Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x886Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84886C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84886Cu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84886Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x886Cu,0x84886Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_84973F_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84973Fu: goto L_84973F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84973F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x973Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x973Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x973Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84973F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84973Fu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84973Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_84977C_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84977Cu: goto L_84977C;
    case 0x84977Eu: goto L_84977E;
    case 0x849781u: goto L_849781;
    case 0x849784u: goto L_849784;
    case 0x849787u: goto L_849787;
    case 0x849789u: goto L_849789;
    case 0x84978Cu: goto L_84978C;
    case 0x84978Eu: goto L_84978E;
    case 0x849791u: goto L_849791;
    case 0x849793u: goto L_849793;
    case 0x849797u: goto L_849797;
    case 0x84979Au: goto L_84979A;
    case 0x84979Du: goto L_84979D;
    case 0x8497A0u: goto L_8497A0;
    case 0x8497A2u: goto L_8497A2;
    case 0x8497A5u: goto L_8497A5;
    case 0x8497A7u: goto L_8497A7;
    case 0x8497AAu: goto L_8497AA;
    case 0x8497ACu: goto L_8497AC;
    case 0x8497B0u: goto L_8497B0;
    case 0x8497B3u: goto L_8497B3;
    case 0x8497B6u: goto L_8497B6;
    case 0x8497B9u: goto L_8497B9;
    case 0x8497BBu: goto L_8497BB;
    case 0x8497BEu: goto L_8497BE;
    case 0x8497C0u: goto L_8497C0;
    case 0x8497C3u: goto L_8497C3;
    case 0x8497C5u: goto L_8497C5;
    case 0x8497C9u: goto L_8497C9;
    case 0x8497CBu: goto L_8497CB;
    case 0x8497CEu: goto L_8497CE;
    case 0x8497D0u: goto L_8497D0;
    case 0x8497D2u: goto L_8497D2;
    case 0x8497D5u: goto L_8497D5;
    case 0x8497D6u: goto L_8497D6;
    case 0x8497D7u: goto L_8497D7;
    case 0x8497DAu: goto L_8497DA;
    case 0x8497DDu: goto L_8497DD;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84977C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x977Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x977Cu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x977Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84977C REP
    cpu.rep(0x20u);
    goto L_84977E;
L_84977E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x977Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x977Eu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x977Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84977E LDX
    cpu.setX(0x2u, 16);
    goto L_849781;
L_849781:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9781u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9781u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9781u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849781 LDY
    cpu.setY(0x5u, 16);
    goto L_849784;
L_849784:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9784u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9784u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9784u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849784 LDA
    cpu.setA(0x2A88u, 16);
    goto L_849787;
L_849787:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9787u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9787u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9787u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849787 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_849789;
L_849789:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9789u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9789u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9789u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849789 LDA
    cpu.setA(0x7Eu, 16);
    goto L_84978C;
L_84978C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x978Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x978Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x978Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84978C STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_84978E;
L_84978E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x978Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x978Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x978Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84978E LDA
    cpu.setA(0xC00u, 16);
    goto L_849791;
L_849791:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9791u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9791u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9791u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849791 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_849793;
L_849793:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9793u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9793u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9793u, 8u, 4u, 0x80A839u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849793 JSL -> $80A839 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9796u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9797u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A839u, 0x849793u); }
    goto L_849797;
L_849797:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9797u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9797u,0x849797u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9797u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9797u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849797 LDX
    cpu.setX(0x2u, 16);
    goto L_84979A;
L_84979A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x979Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x979Au,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x979Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84979A LDY
    cpu.setY(0x5u, 16);
    goto L_84979D;
L_84979D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x979Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x979Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x979Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84979D LDA
    cpu.setA(0x2C48u, 16);
    goto L_8497A0;
L_8497A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97A0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97A0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497A0 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_8497A2;
L_8497A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97A2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97A2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497A2 LDA
    cpu.setA(0x7Eu, 16);
    goto L_8497A5;
L_8497A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97A5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97A5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497A5 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_8497A7;
L_8497A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97A7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97A7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497A7 LDA
    cpu.setA(0xC00u, 16);
    goto L_8497AA;
L_8497AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97AAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97AAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497AA STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_8497AC;
L_8497AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97ACu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97ACu, 8u, 4u, 0x80A839u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8497AC JSL -> $80A839 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x97AFu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x97B0u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A839u, 0x8497ACu); }
    goto L_8497B0;
L_8497B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97B0u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x97B0u,0x8497B0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97B0u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97B0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497B0 LDX
    cpu.setX(0x2u, 16);
    goto L_8497B3;
L_8497B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97B3u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97B3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497B3 LDY
    cpu.setY(0x5u, 16);
    goto L_8497B6;
L_8497B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97B6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97B6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497B6 LDA
    cpu.setA(0x2DC8u, 16);
    goto L_8497B9;
L_8497B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97B9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97B9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497B9 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_8497BB;
L_8497BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97BBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97BBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497BB LDA
    cpu.setA(0x7Eu, 16);
    goto L_8497BE;
L_8497BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97BEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97BEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497BE STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_8497C0;
L_8497C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97C0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97C0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497C0 LDA
    cpu.setA(0xC00u, 16);
    goto L_8497C3;
L_8497C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97C3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97C3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497C3 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_8497C5;
L_8497C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97C5u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97C5u, 8u, 4u, 0x80A839u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8497C5 JSL -> $80A839 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x97C8u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x97C9u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A839u, 0x8497C5u); }
    goto L_8497C9;
L_8497C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97C9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x97C9u,0x8497C9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97C9u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97C9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497C9 SEP
    cpu.sep(0x20u);
    goto L_8497CB;
L_8497CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97CBu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97CBu, 4u, 3u, cpu.address("abs", 0x062Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497CB LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8497CE;
L_8497CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97CEu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97CEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497CE AND
    cpu.logicAnd(0x3u);
    goto L_8497D0;
L_8497D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97D0u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97D0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497D0 REP
    cpu.rep(0x20u);
    goto L_8497D2;
L_8497D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97D2u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97D2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497D2 AND
    cpu.logicAnd(0xFFu);
    goto L_8497D5;
L_8497D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97D5u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97D5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497D5 ASL
    cpu.aslA();
    goto L_8497D6;
L_8497D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97D6u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97D6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497D6 TAX
    cpu.transfer("TAX");
    goto L_8497D7;
L_8497D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97D7u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97D7u, 5u, 3u, cpu.address("abs", 0x97DCu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8497D7 PEA
    cpu.push16Value(hw, 0x97DCu);
    goto L_8497DA;
L_8497DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97DAu,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97DAu, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x97DEu + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $8497DA JMP (97DE,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x97DEu+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x8497DAu); return; }
L_8497DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97DDu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x97DDu,0x8497DDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97DDu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97DDu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8497DD RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8497DDu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8497DDu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_84977C_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84977Cu: goto L_84977C;
    case 0x84977Eu: goto L_84977E;
    case 0x849781u: goto L_849781;
    case 0x849784u: goto L_849784;
    case 0x849787u: goto L_849787;
    case 0x849789u: goto L_849789;
    case 0x84978Cu: goto L_84978C;
    case 0x84978Eu: goto L_84978E;
    case 0x849791u: goto L_849791;
    case 0x849793u: goto L_849793;
    case 0x849797u: goto L_849797;
    case 0x84979Au: goto L_84979A;
    case 0x84979Du: goto L_84979D;
    case 0x8497A0u: goto L_8497A0;
    case 0x8497A2u: goto L_8497A2;
    case 0x8497A5u: goto L_8497A5;
    case 0x8497A7u: goto L_8497A7;
    case 0x8497AAu: goto L_8497AA;
    case 0x8497ACu: goto L_8497AC;
    case 0x8497B0u: goto L_8497B0;
    case 0x8497B3u: goto L_8497B3;
    case 0x8497B6u: goto L_8497B6;
    case 0x8497B9u: goto L_8497B9;
    case 0x8497BBu: goto L_8497BB;
    case 0x8497BEu: goto L_8497BE;
    case 0x8497C0u: goto L_8497C0;
    case 0x8497C3u: goto L_8497C3;
    case 0x8497C5u: goto L_8497C5;
    case 0x8497C9u: goto L_8497C9;
    case 0x8497CBu: goto L_8497CB;
    case 0x8497CEu: goto L_8497CE;
    case 0x8497D0u: goto L_8497D0;
    case 0x8497D2u: goto L_8497D2;
    case 0x8497D5u: goto L_8497D5;
    case 0x8497D6u: goto L_8497D6;
    case 0x8497D7u: goto L_8497D7;
    case 0x8497DAu: goto L_8497DA;
    case 0x8497DDu: goto L_8497DD;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84977C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x977Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x977Cu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x977Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84977C REP
    cpu.rep(0x20u);
    goto L_84977E;
L_84977E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x977Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x977Eu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x977Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84977E LDX
    cpu.setX(0x2u, 16);
    goto L_849781;
L_849781:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9781u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9781u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9781u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849781 LDY
    cpu.setY(0x5u, 16);
    goto L_849784;
L_849784:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9784u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9784u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9784u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849784 LDA
    cpu.setA(0x2A88u, 16);
    goto L_849787;
L_849787:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9787u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9787u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9787u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849787 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_849789;
L_849789:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9789u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9789u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9789u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849789 LDA
    cpu.setA(0x7Eu, 16);
    goto L_84978C;
L_84978C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x978Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x978Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x978Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84978C STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_84978E;
L_84978E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x978Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x978Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x978Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84978E LDA
    cpu.setA(0xC00u, 16);
    goto L_849791;
L_849791:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9791u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9791u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9791u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849791 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_849793;
L_849793:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9793u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9793u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9793u, 8u, 4u, 0x80A839u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849793 JSL -> $80A839 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9796u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9797u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A839u, 0x849793u); }
    goto L_849797;
L_849797:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9797u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9797u,0x849797u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9797u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9797u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849797 LDX
    cpu.setX(0x2u, 16);
    goto L_84979A;
L_84979A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x979Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x979Au,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x979Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84979A LDY
    cpu.setY(0x5u, 16);
    goto L_84979D;
L_84979D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x979Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x979Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x979Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84979D LDA
    cpu.setA(0x2C48u, 16);
    goto L_8497A0;
L_8497A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97A0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97A0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497A0 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_8497A2;
L_8497A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97A2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97A2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497A2 LDA
    cpu.setA(0x7Eu, 16);
    goto L_8497A5;
L_8497A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97A5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97A5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497A5 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_8497A7;
L_8497A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97A7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97A7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497A7 LDA
    cpu.setA(0xC00u, 16);
    goto L_8497AA;
L_8497AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97AAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97AAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497AA STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_8497AC;
L_8497AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97ACu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97ACu, 8u, 4u, 0x80A839u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8497AC JSL -> $80A839 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x97AFu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x97B0u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A839u, 0x8497ACu); }
    goto L_8497B0;
L_8497B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97B0u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x97B0u,0x8497B0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97B0u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97B0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497B0 LDX
    cpu.setX(0x2u, 16);
    goto L_8497B3;
L_8497B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97B3u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97B3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497B3 LDY
    cpu.setY(0x5u, 16);
    goto L_8497B6;
L_8497B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97B6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97B6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497B6 LDA
    cpu.setA(0x2DC8u, 16);
    goto L_8497B9;
L_8497B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97B9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97B9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497B9 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_8497BB;
L_8497BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97BBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97BBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497BB LDA
    cpu.setA(0x7Eu, 16);
    goto L_8497BE;
L_8497BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97BEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97BEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497BE STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_8497C0;
L_8497C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97C0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97C0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497C0 LDA
    cpu.setA(0xC00u, 16);
    goto L_8497C3;
L_8497C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97C3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97C3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497C3 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_8497C5;
L_8497C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97C5u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97C5u, 8u, 4u, 0x80A839u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8497C5 JSL -> $80A839 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x97C8u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x97C9u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A839u, 0x8497C5u); }
    goto L_8497C9;
L_8497C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97C9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x97C9u,0x8497C9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97C9u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97C9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497C9 SEP
    cpu.sep(0x20u);
    goto L_8497CB;
L_8497CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97CBu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97CBu, 4u, 3u, cpu.address("abs", 0x062Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497CB LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8497CE;
L_8497CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97CEu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97CEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497CE AND
    cpu.logicAnd(0x3u);
    goto L_8497D0;
L_8497D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97D0u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97D0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497D0 REP
    cpu.rep(0x20u);
    goto L_8497D2;
L_8497D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97D2u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97D2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497D2 AND
    cpu.logicAnd(0xFFu);
    goto L_8497D5;
L_8497D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97D5u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97D5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497D5 ASL
    cpu.aslA();
    goto L_8497D6;
L_8497D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97D6u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97D6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497D6 TAX
    cpu.transfer("TAX");
    goto L_8497D7;
L_8497D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97D7u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97D7u, 5u, 3u, cpu.address("abs", 0x97DCu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8497D7 PEA
    cpu.push16Value(hw, 0x97DCu);
    goto L_8497DA;
L_8497DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97DAu,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97DAu, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x97DEu + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $8497DA JMP (97DE,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x97DEu+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x8497DAu); return; }
L_8497DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97DDu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x97DDu,0x8497DDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97DDu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97DDu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8497DD RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8497DDu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8497DDu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_84977C_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84977Cu: goto L_84977C;
    case 0x84977Eu: goto L_84977E;
    case 0x849781u: goto L_849781;
    case 0x849784u: goto L_849784;
    case 0x849787u: goto L_849787;
    case 0x849789u: goto L_849789;
    case 0x84978Cu: goto L_84978C;
    case 0x84978Eu: goto L_84978E;
    case 0x849791u: goto L_849791;
    case 0x849793u: goto L_849793;
    case 0x849797u: goto L_849797;
    case 0x84979Au: goto L_84979A;
    case 0x84979Du: goto L_84979D;
    case 0x8497A0u: goto L_8497A0;
    case 0x8497A2u: goto L_8497A2;
    case 0x8497A5u: goto L_8497A5;
    case 0x8497A7u: goto L_8497A7;
    case 0x8497AAu: goto L_8497AA;
    case 0x8497ACu: goto L_8497AC;
    case 0x8497B0u: goto L_8497B0;
    case 0x8497B3u: goto L_8497B3;
    case 0x8497B6u: goto L_8497B6;
    case 0x8497B9u: goto L_8497B9;
    case 0x8497BBu: goto L_8497BB;
    case 0x8497BEu: goto L_8497BE;
    case 0x8497C0u: goto L_8497C0;
    case 0x8497C3u: goto L_8497C3;
    case 0x8497C5u: goto L_8497C5;
    case 0x8497C9u: goto L_8497C9;
    case 0x8497CBu: goto L_8497CB;
    case 0x8497CEu: goto L_8497CE;
    case 0x8497D0u: goto L_8497D0;
    case 0x8497D2u: goto L_8497D2;
    case 0x8497D5u: goto L_8497D5;
    case 0x8497D6u: goto L_8497D6;
    case 0x8497D7u: goto L_8497D7;
    case 0x8497DAu: goto L_8497DA;
    case 0x8497DDu: goto L_8497DD;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84977C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x977Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x977Cu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x977Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84977C REP
    cpu.rep(0x20u);
    goto L_84977E;
L_84977E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x977Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x977Eu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x977Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84977E LDX
    cpu.setX(0x2u, 16);
    goto L_849781;
L_849781:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9781u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9781u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9781u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849781 LDY
    cpu.setY(0x5u, 16);
    goto L_849784;
L_849784:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9784u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9784u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9784u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849784 LDA
    cpu.setA(0x2A88u, 16);
    goto L_849787;
L_849787:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9787u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9787u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9787u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849787 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_849789;
L_849789:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9789u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9789u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9789u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849789 LDA
    cpu.setA(0x7Eu, 16);
    goto L_84978C;
L_84978C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x978Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x978Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x978Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84978C STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_84978E;
L_84978E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x978Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x978Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x978Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84978E LDA
    cpu.setA(0xC00u, 16);
    goto L_849791;
L_849791:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9791u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9791u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9791u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849791 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_849793;
L_849793:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9793u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9793u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9793u, 8u, 4u, 0x80A839u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849793 JSL -> $80A839 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9796u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9797u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A839u, 0x849793u); }
    goto L_849797;
L_849797:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9797u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9797u,0x849797u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9797u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9797u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849797 LDX
    cpu.setX(0x2u, 16);
    goto L_84979A;
L_84979A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x979Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x979Au,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x979Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84979A LDY
    cpu.setY(0x5u, 16);
    goto L_84979D;
L_84979D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x979Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x979Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x979Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84979D LDA
    cpu.setA(0x2C48u, 16);
    goto L_8497A0;
L_8497A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97A0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97A0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497A0 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_8497A2;
L_8497A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97A2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97A2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497A2 LDA
    cpu.setA(0x7Eu, 16);
    goto L_8497A5;
L_8497A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97A5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97A5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497A5 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_8497A7;
L_8497A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97A7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97A7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497A7 LDA
    cpu.setA(0xC00u, 16);
    goto L_8497AA;
L_8497AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97AAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97AAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497AA STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_8497AC;
L_8497AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97ACu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97ACu, 8u, 4u, 0x80A839u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8497AC JSL -> $80A839 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x97AFu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x97B0u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A839u, 0x8497ACu); }
    goto L_8497B0;
L_8497B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97B0u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x97B0u,0x8497B0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97B0u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97B0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497B0 LDX
    cpu.setX(0x2u, 16);
    goto L_8497B3;
L_8497B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97B3u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97B3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497B3 LDY
    cpu.setY(0x5u, 16);
    goto L_8497B6;
L_8497B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97B6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97B6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497B6 LDA
    cpu.setA(0x2DC8u, 16);
    goto L_8497B9;
L_8497B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97B9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97B9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497B9 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_8497BB;
L_8497BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97BBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97BBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497BB LDA
    cpu.setA(0x7Eu, 16);
    goto L_8497BE;
L_8497BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97BEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97BEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497BE STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_8497C0;
L_8497C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97C0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97C0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497C0 LDA
    cpu.setA(0xC00u, 16);
    goto L_8497C3;
L_8497C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97C3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97C3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497C3 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_8497C5;
L_8497C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97C5u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97C5u, 8u, 4u, 0x80A839u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8497C5 JSL -> $80A839 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x97C8u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x97C9u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A839u, 0x8497C5u); }
    goto L_8497C9;
L_8497C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97C9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x97C9u,0x8497C9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97C9u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97C9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497C9 SEP
    cpu.sep(0x20u);
    goto L_8497CB;
L_8497CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97CBu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97CBu, 4u, 3u, cpu.address("abs", 0x062Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497CB LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8497CE;
L_8497CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97CEu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97CEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497CE AND
    cpu.logicAnd(0x3u);
    goto L_8497D0;
L_8497D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97D0u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97D0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497D0 REP
    cpu.rep(0x20u);
    goto L_8497D2;
L_8497D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97D2u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97D2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497D2 AND
    cpu.logicAnd(0xFFu);
    goto L_8497D5;
L_8497D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97D5u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97D5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497D5 ASL
    cpu.aslA();
    goto L_8497D6;
L_8497D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97D6u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97D6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8497D6 TAX
    cpu.transfer("TAX");
    goto L_8497D7;
L_8497D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97D7u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97D7u, 5u, 3u, cpu.address("abs", 0x97DCu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8497D7 PEA
    cpu.push16Value(hw, 0x97DCu);
    goto L_8497DA;
L_8497DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97DAu,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97DAu, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x97DEu + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $8497DA JMP (97DE,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x97DEu+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x8497DAu); return; }
L_8497DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97DDu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x97DDu,0x8497DDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97DDu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97DDu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8497DD RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8497DDu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8497DDu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_8498F9_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8498F9u: goto L_8498F9;
    case 0x8498FBu: goto L_8498FB;
    case 0x8498FDu: goto L_8498FD;
    case 0x849900u: goto L_849900;
    case 0x849902u: goto L_849902;
    case 0x849904u: goto L_849904;
    case 0x849907u: goto L_849907;
    case 0x849909u: goto L_849909;
    case 0x84990Cu: goto L_84990C;
    case 0x84990Eu: goto L_84990E;
    case 0x849910u: goto L_849910;
    case 0x849913u: goto L_849913;
    case 0x849915u: goto L_849915;
    case 0x849918u: goto L_849918;
    case 0x84991Au: goto L_84991A;
    case 0x84991Cu: goto L_84991C;
    case 0x84991Fu: goto L_84991F;
    case 0x849922u: goto L_849922;
    case 0x849924u: goto L_849924;
    case 0x849926u: goto L_849926;
    case 0x849928u: goto L_849928;
    case 0x84992Bu: goto L_84992B;
    case 0x84992Du: goto L_84992D;
    case 0x84992Fu: goto L_84992F;
    case 0x849932u: goto L_849932;
    case 0x849935u: goto L_849935;
    case 0x849938u: goto L_849938;
    case 0x84993Cu: goto L_84993C;
    case 0x84993Du: goto L_84993D;
    case 0x84993Fu: goto L_84993F;
    case 0x849941u: goto L_849941;
    case 0x849942u: goto L_849942;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8498F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98F9u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98F9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498F9 REP
    cpu.rep(0x20u);
    goto L_8498FB;
L_8498FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98FBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98FBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498FB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8498FD;
L_8498FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98FDu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98FDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498FD BIT
    cpu.bit(0x300u, true);
    goto L_849900;
L_849900:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9900u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9900u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9900u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849900 BNE -> $84993F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_84993F; }
    goto L_849902;
L_849902:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9902u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9902u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9902u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849902 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849904;
L_849904:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9904u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9904u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9904u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849904 BIT
    cpu.bit(0xC00u, true);
    goto L_849907;
L_849907:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9907u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9907u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9907u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849907 BEQ -> $84993F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_84993F; }
    goto L_849909;
L_849909:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9909u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9909u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9909u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849909 BIT
    cpu.bit(0x400u, true);
    goto L_84990C;
L_84990C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x990Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x990Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x990Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84990C BNE -> $84991A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_84991A; }
    goto L_84990E;
L_84990E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x990Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x990Eu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x990Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84990E SEP
    cpu.sep(0x20u);
    goto L_849910;
L_849910:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9910u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9910u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9910u, 6u, 3u, cpu.address("abs", 0x06FEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849910 DEC
    cpu.decMem(hw, cpu.address("abs", 0x6FEu), cpu.m8?8:16);
    goto L_849913;
L_849913:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9913u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9913u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9913u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849913 BPL -> $84992D
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_84992D; }
    goto L_849915;
L_849915:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9915u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9915u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9915u, 4u, 3u, cpu.address("abs", 0x06FEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849915 STZ
    hw.write(cpu.address("abs", 0x6FEu), 0, cpu.m8?8:16);
    goto L_849918;
L_849918:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9918u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9918u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9918u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849918 BRA -> $84993F
    goto L_84993F;
L_84991A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x991Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x991Au,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x991Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84991A SEP
    cpu.sep(0x20u);
    goto L_84991C;
L_84991C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x991Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x991Cu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x991Cu, 6u, 3u, cpu.address("abs", 0x06FEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84991C INC
    cpu.incMem(hw, cpu.address("abs", 0x6FEu), cpu.m8?8:16);
    goto L_84991F;
L_84991F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x991Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x991Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x991Fu, 4u, 3u, cpu.address("abs", 0x06FEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84991F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x6FEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849922;
L_849922:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9922u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9922u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9922u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849922 CMP
    cpu.compareA(0x2u);
    goto L_849924;
L_849924:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9924u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9924u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9924u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849924 BCC -> $84992D
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_84992D; }
    goto L_849926;
L_849926:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9926u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9926u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9926u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849926 LDA
    cpu.setA(0x1u, 8);
    goto L_849928;
L_849928:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9928u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9928u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9928u, 4u, 3u, cpu.address("abs", 0x06FEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849928 STA
    hw.write(cpu.address("abs", 0x6FEu), cpu.a, cpu.m8?8:16);
    goto L_84992B;
L_84992B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x992Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x992Bu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x992Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84992B BRA -> $84993F
    goto L_84993F;
L_84992D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x992Du))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x992Du,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x992Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84992D REP
    cpu.rep(0x20u);
    goto L_84992F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x992Du,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x992Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84992D REP
    cpu.rep(0x20u);
    goto L_84992F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x992Du,0x84992Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84992F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x992Fu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x992Fu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x992Fu, 5u, 3u, cpu.address("abs", 0x065Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84992F STZ
    hw.write(cpu.address("abs", 0x65Eu), 0, cpu.m8?8:16);
    goto L_849932;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x992Fu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x992Fu, 5u, 3u, cpu.address("abs", 0x065Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84992F STZ
    hw.write(cpu.address("abs", 0x65Eu), 0, cpu.m8?8:16);
    goto L_849932;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x992Fu,0x84992Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849932:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9932u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9932u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9932u, 5u, 3u, cpu.address("abs", 0x06EBu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849932 STZ
    hw.write(cpu.address("abs", 0x6EBu), 0, cpu.m8?8:16);
    goto L_849935;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9932u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9932u, 5u, 3u, cpu.address("abs", 0x06EBu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849932 STZ
    hw.write(cpu.address("abs", 0x6EBu), 0, cpu.m8?8:16);
    goto L_849935;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9932u,0x849932u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849935:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9935u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9935u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9935u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849935 LDA
    cpu.setA(0x6u, 16);
    goto L_849938;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9935u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9935u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849935 LDA
    cpu.setA(0x6u, 16);
    goto L_849938;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9935u,0x849935u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849938:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9938u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9938u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9938u, 8u, 4u, 0x80A6FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849938 JSL -> $80A6FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x993Bu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x993Cu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6FBu, 0x849938u); }
    goto L_84993C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9938u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9938u, 8u, 4u, 0x80A6FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849938 JSL -> $80A6FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x993Bu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x993Cu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6FBu, 0x849938u); }
    goto L_84993C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9938u,0x849938u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84993C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x993Cu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x993Cu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x993Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84993C SEC
    cpu.setFlag('C', true);
    goto L_84993D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x993Cu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x993Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84993C SEC
    cpu.setFlag('C', true);
    goto L_84993D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x993Cu,0x84993Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84993D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x993Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x993Du,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x993Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84993D BRA -> $849942
    goto L_849942;
L_84993F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x993Fu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x993Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x993Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84993F REP
    cpu.rep(0x20u);
    goto L_849941;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x993Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x993Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84993F REP
    cpu.rep(0x20u);
    goto L_849941;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x993Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x993Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84993F REP
    cpu.rep(0x20u);
    goto L_849941;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x993Fu,0x84993Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849941:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9941u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9941u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9941u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849941 CLC
    cpu.setFlag('C', false);
    goto L_849942;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9941u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9941u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849941 CLC
    cpu.setFlag('C', false);
    goto L_849942;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9941u,0x849941u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849942:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9942u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9942u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9942u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849942 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x849942u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x849942u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9942u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9942u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849942 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x849942u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x849942u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9942u,0x849942u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_8498F9_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8498F9u: goto L_8498F9;
    case 0x8498FBu: goto L_8498FB;
    case 0x8498FDu: goto L_8498FD;
    case 0x849900u: goto L_849900;
    case 0x849902u: goto L_849902;
    case 0x849904u: goto L_849904;
    case 0x849907u: goto L_849907;
    case 0x849909u: goto L_849909;
    case 0x84990Cu: goto L_84990C;
    case 0x84990Eu: goto L_84990E;
    case 0x849910u: goto L_849910;
    case 0x849913u: goto L_849913;
    case 0x849915u: goto L_849915;
    case 0x849918u: goto L_849918;
    case 0x84991Au: goto L_84991A;
    case 0x84991Cu: goto L_84991C;
    case 0x84991Fu: goto L_84991F;
    case 0x849922u: goto L_849922;
    case 0x849924u: goto L_849924;
    case 0x849926u: goto L_849926;
    case 0x849928u: goto L_849928;
    case 0x84992Bu: goto L_84992B;
    case 0x84992Du: goto L_84992D;
    case 0x84992Fu: goto L_84992F;
    case 0x849932u: goto L_849932;
    case 0x849935u: goto L_849935;
    case 0x849938u: goto L_849938;
    case 0x84993Cu: goto L_84993C;
    case 0x84993Du: goto L_84993D;
    case 0x84993Fu: goto L_84993F;
    case 0x849941u: goto L_849941;
    case 0x849942u: goto L_849942;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8498F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98F9u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98F9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498F9 REP
    cpu.rep(0x20u);
    goto L_8498FB;
L_8498FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98FBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98FBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498FB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8498FD;
L_8498FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98FDu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98FDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8498FD BIT
    cpu.bit(0x300u, true);
    goto L_849900;
L_849900:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9900u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9900u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9900u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849900 BNE -> $84993F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_84993F; }
    goto L_849902;
L_849902:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9902u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9902u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9902u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849902 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849904;
L_849904:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9904u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9904u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9904u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849904 BIT
    cpu.bit(0xC00u, true);
    goto L_849907;
L_849907:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9907u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9907u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9907u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849907 BEQ -> $84993F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_84993F; }
    goto L_849909;
L_849909:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9909u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9909u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9909u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849909 BIT
    cpu.bit(0x400u, true);
    goto L_84990C;
L_84990C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x990Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x990Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x990Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84990C BNE -> $84991A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_84991A; }
    goto L_84990E;
L_84990E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x990Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x990Eu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x990Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84990E SEP
    cpu.sep(0x20u);
    goto L_849910;
L_849910:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9910u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9910u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9910u, 6u, 3u, cpu.address("abs", 0x06FEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849910 DEC
    cpu.decMem(hw, cpu.address("abs", 0x6FEu), cpu.m8?8:16);
    goto L_849913;
L_849913:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9913u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9913u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9913u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849913 BPL -> $84992D
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_84992D; }
    goto L_849915;
L_849915:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9915u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9915u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9915u, 4u, 3u, cpu.address("abs", 0x06FEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849915 STZ
    hw.write(cpu.address("abs", 0x6FEu), 0, cpu.m8?8:16);
    goto L_849918;
L_849918:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9918u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9918u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9918u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849918 BRA -> $84993F
    goto L_84993F;
L_84991A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x991Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x991Au,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x991Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84991A SEP
    cpu.sep(0x20u);
    goto L_84991C;
L_84991C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x991Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x991Cu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x991Cu, 6u, 3u, cpu.address("abs", 0x06FEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84991C INC
    cpu.incMem(hw, cpu.address("abs", 0x6FEu), cpu.m8?8:16);
    goto L_84991F;
L_84991F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x991Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x991Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x991Fu, 4u, 3u, cpu.address("abs", 0x06FEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84991F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x6FEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849922;
L_849922:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9922u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9922u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9922u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849922 CMP
    cpu.compareA(0x2u);
    goto L_849924;
L_849924:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9924u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9924u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9924u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849924 BCC -> $84992D
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_84992D; }
    goto L_849926;
L_849926:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9926u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9926u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9926u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849926 LDA
    cpu.setA(0x1u, 8);
    goto L_849928;
L_849928:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9928u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9928u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9928u, 4u, 3u, cpu.address("abs", 0x06FEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849928 STA
    hw.write(cpu.address("abs", 0x6FEu), cpu.a, cpu.m8?8:16);
    goto L_84992B;
L_84992B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x992Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x992Bu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x992Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84992B BRA -> $84993F
    goto L_84993F;
L_84992D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x992Du))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x992Du,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x992Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84992D REP
    cpu.rep(0x20u);
    goto L_84992F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x992Du,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x992Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84992D REP
    cpu.rep(0x20u);
    goto L_84992F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x992Du,0x84992Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84992F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x992Fu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x992Fu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x992Fu, 5u, 3u, cpu.address("abs", 0x065Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84992F STZ
    hw.write(cpu.address("abs", 0x65Eu), 0, cpu.m8?8:16);
    goto L_849932;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x992Fu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x992Fu, 5u, 3u, cpu.address("abs", 0x065Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84992F STZ
    hw.write(cpu.address("abs", 0x65Eu), 0, cpu.m8?8:16);
    goto L_849932;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x992Fu,0x84992Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849932:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9932u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9932u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9932u, 5u, 3u, cpu.address("abs", 0x06EBu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849932 STZ
    hw.write(cpu.address("abs", 0x6EBu), 0, cpu.m8?8:16);
    goto L_849935;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9932u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9932u, 5u, 3u, cpu.address("abs", 0x06EBu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849932 STZ
    hw.write(cpu.address("abs", 0x6EBu), 0, cpu.m8?8:16);
    goto L_849935;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9932u,0x849932u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849935:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9935u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9935u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9935u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849935 LDA
    cpu.setA(0x6u, 16);
    goto L_849938;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9935u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9935u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849935 LDA
    cpu.setA(0x6u, 16);
    goto L_849938;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9935u,0x849935u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849938:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9938u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9938u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9938u, 8u, 4u, 0x80A6FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849938 JSL -> $80A6FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x993Bu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x993Cu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6FBu, 0x849938u); }
    goto L_84993C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9938u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9938u, 8u, 4u, 0x80A6FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849938 JSL -> $80A6FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x993Bu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x993Cu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6FBu, 0x849938u); }
    goto L_84993C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9938u,0x849938u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84993C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x993Cu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x993Cu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x993Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84993C SEC
    cpu.setFlag('C', true);
    goto L_84993D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x993Cu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x993Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84993C SEC
    cpu.setFlag('C', true);
    goto L_84993D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x993Cu,0x84993Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84993D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x993Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x993Du,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x993Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84993D BRA -> $849942
    goto L_849942;
L_84993F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x993Fu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x993Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x993Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84993F REP
    cpu.rep(0x20u);
    goto L_849941;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x993Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x993Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84993F REP
    cpu.rep(0x20u);
    goto L_849941;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x993Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x993Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84993F REP
    cpu.rep(0x20u);
    goto L_849941;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x993Fu,0x84993Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849941:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9941u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9941u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9941u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849941 CLC
    cpu.setFlag('C', false);
    goto L_849942;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9941u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9941u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849941 CLC
    cpu.setFlag('C', false);
    goto L_849942;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9941u,0x849941u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849942:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9942u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9942u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9942u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849942 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x849942u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x849942u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9942u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9942u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849942 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x849942u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x849942u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9942u,0x849942u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_849CE3_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x849CE3u: goto L_849CE3;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_849CE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CE3u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CE3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849CE3 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x849CE3u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x849CE3u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_84B509_E0M1X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84B509u: goto L_84B509;
    case 0x84B50Cu: goto L_84B50C;
    case 0x84B50Fu: goto L_84B50F;
    case 0x84B512u: goto L_84B512;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84B509:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB509u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB509u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB509u, 6u, 3u, cpu.address("abs", 0xB6B9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B509 JSR -> $84B6B9 stack real
    { cpu.push16Value(hw,0xB50Bu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB50Cu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB6B9u), 0x84B509u); }
    goto L_84B50C;
L_84B50C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB50Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB50Cu,0x84B50Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Cu, 6u, 3u, cpu.address("abs", 0xB855u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B50C JSR -> $84B855 stack real
    { cpu.push16Value(hw,0xB50Eu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB50Fu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB855u), 0x84B50Cu); }
    goto L_84B50F;
L_84B50F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB50Fu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB50Fu,0x84B50Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Fu, 6u, 3u, cpu.address("abs", 0xBBF7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B50F JSR -> $84BBF7 stack real
    { cpu.push16Value(hw,0xB511u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB512u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBBF7u), 0x84B50Fu); }
    goto L_84B512;
L_84B512:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB512u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB512u,0x84B512u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB512u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB512u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B512 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x84B512u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84B512u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_84B509_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84B509u: goto L_84B509;
    case 0x84B50Cu: goto L_84B50C;
    case 0x84B50Fu: goto L_84B50F;
    case 0x84B512u: goto L_84B512;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84B509:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB509u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB509u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB509u, 6u, 3u, cpu.address("abs", 0xB6B9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B509 JSR -> $84B6B9 stack real
    { cpu.push16Value(hw,0xB50Bu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB50Cu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB6B9u), 0x84B509u); }
    goto L_84B50C;
L_84B50C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB50Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB50Cu,0x84B50Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Cu, 6u, 3u, cpu.address("abs", 0xB855u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B50C JSR -> $84B855 stack real
    { cpu.push16Value(hw,0xB50Eu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB50Fu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB855u), 0x84B50Cu); }
    goto L_84B50F;
L_84B50F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB50Fu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB50Fu,0x84B50Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Fu, 6u, 3u, cpu.address("abs", 0xBBF7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B50F JSR -> $84BBF7 stack real
    { cpu.push16Value(hw,0xB511u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB512u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBBF7u), 0x84B50Fu); }
    goto L_84B512;
L_84B512:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB512u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB512u,0x84B512u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB512u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB512u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B512 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x84B512u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84B512u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_84C043_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84C043u: goto L_84C043;
    case 0x84C045u: goto L_84C045;
    case 0x84C048u: goto L_84C048;
    case 0x84C04Bu: goto L_84C04B;
    case 0x84C04Du: goto L_84C04D;
    case 0x84C04Fu: goto L_84C04F;
    case 0x84C051u: goto L_84C051;
    case 0x84C053u: goto L_84C053;
    case 0x84C055u: goto L_84C055;
    case 0x84C057u: goto L_84C057;
    case 0x84C05Au: goto L_84C05A;
    case 0x84C05Du: goto L_84C05D;
    case 0x84C061u: goto L_84C061;
    case 0x84C063u: goto L_84C063;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84C043:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC043u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC043u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC043u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C043 REP
    cpu.rep(0x20u);
    goto L_84C045;
L_84C045:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC045u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC045u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC045u, 6u, 3u, cpu.address("abs", 0xC1FCu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84C045 JSR -> $84C1FC stack real
    { cpu.push16Value(hw,0xC047u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC048u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC1FCu), 0x84C045u); }
    goto L_84C048;
L_84C048:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC048u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC048u,0x84C048u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC048u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC048u, 6u, 3u, cpu.address("abs", 0xC1B3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84C048 JSR -> $84C1B3 stack real
    { cpu.push16Value(hw,0xC04Au); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC04Bu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC1B3u), 0x84C048u); }
    goto L_84C04B;
L_84C04B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC04Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC04Bu,0x84C04Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC04Bu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC04Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C04B SEP
    cpu.sep(0x20u);
    goto L_84C04D;
L_84C04D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC04Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC04Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC04Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C04D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x75u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84C04F;
L_84C04F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC04Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC04Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC04Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C04F BNE -> $84C061
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_84C061; }
    goto L_84C051;
L_84C051:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC051u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC051u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC051u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C051 LDA
    cpu.setA(0xCu, 8);
    goto L_84C053;
L_84C053:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC053u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC053u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC053u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C053 STA
    hw.write(cpu.address("dp", 0x49u), cpu.a, cpu.m8?8:16);
    goto L_84C055;
L_84C055:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC055u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC055u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC055u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C055 REP
    cpu.rep(0x20u);
    goto L_84C057;
L_84C057:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC057u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC057u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC057u, 5u, 3u, cpu.address("abs", 0x060Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C057 STZ
    hw.write(cpu.address("abs", 0x60Fu), 0, cpu.m8?8:16);
    goto L_84C05A;
L_84C05A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC05Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC05Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC05Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C05A LDA
    cpu.setA(0x2Cu, 16);
    goto L_84C05D;
L_84C05D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC05Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC05Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC05Du, 8u, 4u, 0x80A6FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84C05D JSL -> $80A6FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC060u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC061u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6FBu, 0x84C05Du); }
    goto L_84C061;
L_84C061:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC061u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC061u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC061u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C061 REP
    cpu.rep(0x20u);
    goto L_84C063;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC061u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC061u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C061 REP
    cpu.rep(0x20u);
    goto L_84C063;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC061u,0x84C061u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84C063:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC063u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC063u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC063u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84C063 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84C063u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84C063u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_84C32C_E0M1X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84C32Cu: goto L_84C32C;
    case 0x84C32Eu: goto L_84C32E;
    case 0x84C331u: goto L_84C331;
    case 0x84C334u: goto L_84C334;
    case 0x84C337u: goto L_84C337;
    case 0x84C338u: goto L_84C338;
    case 0x84C339u: goto L_84C339;
    case 0x84C33Cu: goto L_84C33C;
    case 0x84C33Eu: goto L_84C33E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84C32C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC32Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC32Cu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC32Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C32C REP
    cpu.rep(0x20u);
    goto L_84C32E;
L_84C32E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC32Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC32Eu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC32Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C32E LDY
    cpu.setY(0x0u, 16);
    goto L_84C331;
L_84C331:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC331u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC331u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC331u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C331 LDA
    cpu.setA(0x7FFFu, 16);
    goto L_84C334;
L_84C334:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC334u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC334u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC334u, 6u, 3u, cpu.address("absy", 0x1B00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C334 STA
    hw.write(cpu.address("absy", 0x1B00u), cpu.a, cpu.m8?8:16);
    goto L_84C337;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC334u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC334u, 6u, 3u, cpu.address("absy", 0x1B00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C334 STA
    hw.write(cpu.address("absy", 0x1B00u), cpu.a, cpu.m8?8:16);
    goto L_84C337;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC334u,0x84C334u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84C337:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC337u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC337u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC337u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C337 INY
    cpu.inc('Y');
    goto L_84C338;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC337u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC337u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C337 INY
    cpu.inc('Y');
    goto L_84C338;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC337u,0x84C337u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84C338:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC338u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC338u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC338u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C338 INY
    cpu.inc('Y');
    goto L_84C339;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC338u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC338u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C338 INY
    cpu.inc('Y');
    goto L_84C339;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC338u,0x84C338u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84C339:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC339u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC339u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC339u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C339 CPY
    cpu.compareY(0x200u);
    goto L_84C33C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC339u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC339u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C339 CPY
    cpu.compareY(0x200u);
    goto L_84C33C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC339u,0x84C339u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84C33C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC33Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC33Cu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC33Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C33C BCC -> $84C334
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_84C334; }
    goto L_84C33E;
L_84C33E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC33Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC33Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC33Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84C33E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84C33Eu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84C33Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_84C32C_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84C32Cu: goto L_84C32C;
    case 0x84C32Eu: goto L_84C32E;
    case 0x84C331u: goto L_84C331;
    case 0x84C334u: goto L_84C334;
    case 0x84C337u: goto L_84C337;
    case 0x84C338u: goto L_84C338;
    case 0x84C339u: goto L_84C339;
    case 0x84C33Cu: goto L_84C33C;
    case 0x84C33Eu: goto L_84C33E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84C32C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC32Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC32Cu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC32Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C32C REP
    cpu.rep(0x20u);
    goto L_84C32E;
L_84C32E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC32Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC32Eu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC32Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C32E LDY
    cpu.setY(0x0u, 16);
    goto L_84C331;
L_84C331:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC331u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC331u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC331u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C331 LDA
    cpu.setA(0x7FFFu, 16);
    goto L_84C334;
L_84C334:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC334u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC334u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC334u, 6u, 3u, cpu.address("absy", 0x1B00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C334 STA
    hw.write(cpu.address("absy", 0x1B00u), cpu.a, cpu.m8?8:16);
    goto L_84C337;
L_84C337:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC337u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC337u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC337u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C337 INY
    cpu.inc('Y');
    goto L_84C338;
L_84C338:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC338u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC338u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC338u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C338 INY
    cpu.inc('Y');
    goto L_84C339;
L_84C339:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC339u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC339u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC339u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C339 CPY
    cpu.compareY(0x200u);
    goto L_84C33C;
L_84C33C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC33Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC33Cu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC33Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C33C BCC -> $84C334
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_84C334; }
    goto L_84C33E;
L_84C33E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC33Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC33Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC33Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84C33E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84C33Eu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84C33Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_84F790_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84F790u: goto L_84F790;
    case 0x84F792u: goto L_84F792;
    case 0x84F795u: goto L_84F795;
    case 0x84F797u: goto L_84F797;
    case 0x84F79Bu: goto L_84F79B;
    case 0x84F79Eu: goto L_84F79E;
    case 0x84F7A0u: goto L_84F7A0;
    case 0x84F7A2u: goto L_84F7A2;
    case 0x84F7A4u: goto L_84F7A4;
    case 0x84F7A7u: goto L_84F7A7;
    case 0x84F7AAu: goto L_84F7AA;
    case 0x84F7ACu: goto L_84F7AC;
    case 0x84F7AEu: goto L_84F7AE;
    case 0x84F7B0u: goto L_84F7B0;
    case 0x84F7B3u: goto L_84F7B3;
    case 0x84F7B4u: goto L_84F7B4;
    case 0x84F7B5u: goto L_84F7B5;
    case 0x84F7B7u: goto L_84F7B7;
    case 0x84F7B8u: goto L_84F7B8;
    case 0x84F7B9u: goto L_84F7B9;
    case 0x84F7BDu: goto L_84F7BD;
    case 0x84F7C0u: goto L_84F7C0;
    case 0x84F7C3u: goto L_84F7C3;
    case 0x84F7C6u: goto L_84F7C6;
    case 0x84F7C8u: goto L_84F7C8;
    case 0x84F7CBu: goto L_84F7CB;
    case 0x84F7CFu: goto L_84F7CF;
    case 0x84F7D3u: goto L_84F7D3;
    case 0x84F7D6u: goto L_84F7D6;
    case 0x84F7D9u: goto L_84F7D9;
    case 0x84F7DAu: goto L_84F7DA;
    case 0x84F7DCu: goto L_84F7DC;
    case 0x84F7DFu: goto L_84F7DF;
    case 0x84F7E1u: goto L_84F7E1;
    case 0x84F7E4u: goto L_84F7E4;
    case 0x84F7E6u: goto L_84F7E6;
    case 0x84F7E8u: goto L_84F7E8;
    case 0x84F7EBu: goto L_84F7EB;
    case 0x84F7ECu: goto L_84F7EC;
    case 0x84F7EDu: goto L_84F7ED;
    case 0x84F7F1u: goto L_84F7F1;
    case 0x84F7F4u: goto L_84F7F4;
    case 0x84F7F7u: goto L_84F7F7;
    case 0x84F7FAu: goto L_84F7FA;
    case 0x84F7FCu: goto L_84F7FC;
    case 0x84F7FFu: goto L_84F7FF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84F790:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF790u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF790u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF790u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F790 REP
    cpu.rep(0x20u);
    goto L_84F792;
L_84F792:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF792u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF792u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF792u, 5u, 3u, cpu.address("abs", 0x02CEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F792 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2CEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84F795;
L_84F795:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF795u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF795u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF795u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F795 STA
    hw.write(cpu.address("dp", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_84F797;
L_84F797:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF797u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF797u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF797u, 8u, 4u, 0x809315u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84F797 JSL -> $809315 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF79Au); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF79Bu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809315u, 0x84F797u); }
    goto L_84F79B;
L_84F79B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF79Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF79Bu,0x84F79Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF79Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF79Bu, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F79B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84F79E;
L_84F79E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF79Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF79Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF79Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F79E BNE -> $84F7DA
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_84F7DA; }
    goto L_84F7A0;
L_84F7A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7A0u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7A0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F7A0 STZ
    hw.write(cpu.address("dp", 0x10u), 0, cpu.m8?8:16);
    goto L_84F7A2;
L_84F7A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7A2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7A2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F7A2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84F7A4;
L_84F7A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7A4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7A4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F7A4 AND
    cpu.logicAnd(0xFFu);
    goto L_84F7A7;
L_84F7A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7A7u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7A7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F7A7 CMP
    cpu.compareA(0x5u);
    goto L_84F7AA;
L_84F7AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7AAu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7AAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F7AA BNE -> $84F7AE
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_84F7AE; }
    goto L_84F7AC;
L_84F7AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7ACu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7ACu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F7AC INC
    cpu.incMem(hw, cpu.address("dp", 0x10u), cpu.m8?8:16);
    goto L_84F7AE;
L_84F7AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7AEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7AEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F7AE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84F7B0;
L_84F7B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7B0u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7B0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F7B0 AND
    cpu.logicAnd(0xFFu);
    goto L_84F7B3;
L_84F7B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7B3u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7B3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F7B3 ASL
    cpu.aslA();
    goto L_84F7B4;
L_84F7B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7B4u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7B4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F7B4 CLC
    cpu.setFlag('C', false);
    goto L_84F7B5;
L_84F7B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7B5u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7B5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F7B5 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16));
    goto L_84F7B7;
L_84F7B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7B7u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7B7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F7B7 ASL
    cpu.aslA();
    goto L_84F7B8;
L_84F7B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7B8u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7B8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F7B8 TAX
    cpu.transfer("TAX");
    goto L_84F7B9;
L_84F7B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7B9u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7B9u, 6u, 4u, ((0x84F816u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F7B9 LDA
    cpu.loadA(hw.readW(((0x84F816u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84F7BD;
L_84F7BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7BDu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7BDu, 5u, 3u, cpu.address("abs", 0x0665u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F7BD STA
    hw.write(cpu.address("abs", 0x665u), cpu.a, cpu.m8?8:16);
    goto L_84F7C0;
L_84F7C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7C0u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7C0u, 5u, 3u, cpu.address("abs", 0x02CEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F7C0 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2CEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84F7C3;
L_84F7C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7C3u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7C3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F7C3 CMP
    cpu.compareA(0x50u);
    goto L_84F7C6;
L_84F7C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7C6u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7C6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F7C6 BNE -> $84F7D9
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_84F7D9; }
    goto L_84F7C8;
L_84F7C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7C8u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7C8u, 8u, 3u, cpu.address("abs", 0x02CEu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F7C8 DEC
    cpu.decMem(hw, cpu.address("abs", 0x2CEu), cpu.m8?8:16);
    goto L_84F7CB;
L_84F7CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7CBu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7CBu, 8u, 4u, 0x84B70Cu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84F7CB JSL -> $84B70C stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF7CEu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF7CFu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84B70Cu, 0x84F7CBu); }
    goto L_84F7CF;
L_84F7CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7CFu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF7CFu,0x84F7CFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7CFu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7CFu, 8u, 4u, 0x82BC35u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84F7CF JSL -> $82BC35 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF7D2u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF7D3u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82BC35u, 0x84F7CFu); }
    goto L_84F7D3;
L_84F7D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7D3u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF7D3u,0x84F7D3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7D3u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7D3u, 8u, 3u, cpu.address("abs", 0x02CEu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F7D3 INC
    cpu.incMem(hw, cpu.address("abs", 0x2CEu), cpu.m8?8:16);
    goto L_84F7D6;
L_84F7D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7D6u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7D6u, 8u, 3u, cpu.address("abs", 0x066Fu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F7D6 INC
    cpu.incMem(hw, cpu.address("abs", 0x66Fu), cpu.m8?8:16);
    goto L_84F7D9;
L_84F7D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7D9u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7D9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84F7D9 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84F7D9u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84F7D9u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_84F7DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7DAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7DAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F7DA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84F7DC;
L_84F7DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7DCu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7DCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F7DC AND
    cpu.logicAnd(0xFF00u);
    goto L_84F7DF;
L_84F7DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7DFu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7DFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F7DF BEQ -> $84F7E6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_84F7E6; }
    goto L_84F7E1;
L_84F7E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7E1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7E1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F7E1 LDA
    cpu.setA(0xAu, 16);
    goto L_84F7E4;
L_84F7E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7E4u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7E4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F7E4 BRA -> $84F7EB
    goto L_84F7EB;
L_84F7E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7E6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7E6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F7E6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84F7E8;
L_84F7E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7E8u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7E8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F7E8 AND
    cpu.logicAnd(0xFFu);
    goto L_84F7EB;
L_84F7EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7EBu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7EBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F7EB ASL
    cpu.aslA();
    goto L_84F7EC;
L_84F7EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7ECu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7ECu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F7EC TAX
    cpu.transfer("TAX");
    goto L_84F7ED;
L_84F7ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7EDu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7EDu, 6u, 4u, ((0x84F800u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F7ED LDA
    cpu.loadA(hw.readW(((0x84F800u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84F7F1;
L_84F7F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7F1u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7F1u, 5u, 3u, cpu.address("abs", 0x0665u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F7F1 STA
    hw.write(cpu.address("abs", 0x665u), cpu.a, cpu.m8?8:16);
    goto L_84F7F4;
L_84F7F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7F4u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7F4u, 5u, 3u, cpu.address("abs", 0x02CEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F7F4 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2CEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84F7F7;
L_84F7F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7F7u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7F7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F7F7 CMP
    cpu.compareA(0x64u);
    goto L_84F7FA;
L_84F7FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7FAu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7FAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F7FA BCC -> $84F7FF
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_84F7FF; }
    goto L_84F7FC;
L_84F7FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7FCu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7FCu, 8u, 3u, cpu.address("abs", 0x066Fu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84F7FC INC
    cpu.incMem(hw, cpu.address("abs", 0x66Fu), cpu.m8?8:16);
    goto L_84F7FF;
L_84F7FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7FFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7FFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84F7FF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84F7FFu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84F7FFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

