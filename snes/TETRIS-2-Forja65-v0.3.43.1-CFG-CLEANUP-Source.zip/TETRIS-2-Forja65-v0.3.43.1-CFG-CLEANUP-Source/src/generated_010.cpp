#include "generated.hpp"
void sub_0080B0_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0080B0u: goto L_0080B0;
    case 0x8080B4u: goto L_8080B4;
    case 0x8080B6u: goto L_8080B6;
    case 0x8080B7u: goto L_8080B7;
    case 0x8080B8u: goto L_8080B8;
    case 0x8080B9u: goto L_8080B9;
    case 0x8080BAu: goto L_8080BA;
    case 0x8080BBu: goto L_8080BB;
    case 0x8080BEu: goto L_8080BE;
    case 0x8080BFu: goto L_8080BF;
    case 0x8080C1u: goto L_8080C1;
    case 0x8080C2u: goto L_8080C2;
    case 0x8080C3u: goto L_8080C3;
    case 0x8080C6u: goto L_8080C6;
    case 0x8080C8u: goto L_8080C8;
    case 0x8080CAu: goto L_8080CA;
    case 0x8080CCu: goto L_8080CC;
    case 0x8080D0u: goto L_8080D0;
    case 0x8080D4u: goto L_8080D4;
    case 0x8080D7u: goto L_8080D7;
    case 0x8080DAu: goto L_8080DA;
    case 0x8080DCu: goto L_8080DC;
    case 0x8080DEu: goto L_8080DE;
    case 0x8080E1u: goto L_8080E1;
    case 0x8080E5u: goto L_8080E5;
    case 0x8080E9u: goto L_8080E9;
    case 0x8080EDu: goto L_8080ED;
    case 0x8080EFu: goto L_8080EF;
    case 0x8080F1u: goto L_8080F1;
    case 0x8080F2u: goto L_8080F2;
    case 0x8080F3u: goto L_8080F3;
    case 0x8080F4u: goto L_8080F4;
    case 0x8080F5u: goto L_8080F5;
    case 0x8080F6u: goto L_8080F6;
    case 0x808105u: goto L_808105;
    case 0x808109u: goto L_808109;
    case 0x80810Bu: goto L_80810B;
    case 0x80810Cu: goto L_80810C;
    case 0x80810Du: goto L_80810D;
    case 0x80810Eu: goto L_80810E;
    case 0x80810Fu: goto L_80810F;
    case 0x808110u: goto L_808110;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0080B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80B0u,cpu,0x5Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80B0u, 4u, 4u, 0x8080B4u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080B0 JML -> $8080B4
    cpu.pb=0x80u; // JML troca o Program Bank mesmo em goto local recompilado
    goto L_8080B4;
L_8080B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80B4u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80B4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080B4 REP
    cpu.rep(0x20u);
    goto L_8080B6;
L_8080B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80B6u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80B6u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8080B6 PHA
    cpu.push("PHA", hw);
    goto L_8080B7;
L_8080B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80B7u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80B7u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8080B7 PHX
    cpu.push("PHX", hw);
    goto L_8080B8;
L_8080B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80B8u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80B8u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8080B8 PHY
    cpu.push("PHY", hw);
    goto L_8080B9;
L_8080B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80B9u,cpu,0x0Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80B9u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8080B9 PHD
    cpu.push("PHD", hw);
    goto L_8080BA;
L_8080BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80BAu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80BAu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8080BA PHB
    cpu.push("PHB", hw);
    goto L_8080BB;
L_8080BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80BBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80BBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080BB LDA
    cpu.setA(0x0u, 16);
    goto L_8080BE;
L_8080BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80BEu,cpu,0x5Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80BEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080BE TCD
    cpu.tcd();
    goto L_8080BF;
L_8080BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80BFu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80BFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080BF SEP
    cpu.sep(0x20u);
    goto L_8080C1;
L_8080C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80C1u,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80C1u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8080C1 PHK
    cpu.push("PHK", hw);
    goto L_8080C2;
L_8080C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80C2u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80C2u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8080C2 PLB
    cpu.pop("PLB", hw);
    goto L_8080C3;
L_8080C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80C3u,cpu,0x2Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80C3u, 4u, 3u, cpu.address("abs", 0x4210u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080C3 BIT
    cpu.bit(hw.readW(cpu.address("abs", 0x4210u), cpu.m8?8:16), false);
    goto L_8080C6;
L_8080C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80C6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80C6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080C6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8080C8;
L_8080C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80C8u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80C8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080C8 BNE -> $808105
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_808105; }
    goto L_8080CA;
L_8080CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80CAu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80CAu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080CA INC
    cpu.incMem(hw, cpu.address("dp", 0x4Au), cpu.m8?8:16);
    goto L_8080CC;
L_8080CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80CCu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80CCu, 8u, 4u, 0x80864Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8080CC JSL -> $80864B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80CFu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80D0u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80864Bu, 0x8080CCu); }
    goto L_8080D0;
L_8080D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D0u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80D0u,0x8080D0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D0u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D0u, 8u, 4u, 0x808564u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8080D0 JSL -> $808564 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80D3u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80D4u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808564u, 0x8080D0u); }
    goto L_8080D4;
L_8080D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D4u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80D4u,0x8080D4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D4u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D4u, 6u, 3u, cpu.address("abs", 0x85ADu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8080D4 JSR -> $8085AD stack real
    { cpu.push16Value(hw,0x80D6u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80D7u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x85ADu), 0x8080D4u); }
    goto L_8080D7;
L_8080D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D7u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80D7u,0x8080D7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D7u, 6u, 3u, cpu.address("abs", 0x858Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8080D7 JSR -> $80858D stack real
    { cpu.push16Value(hw,0x80D9u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80DAu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x858Du), 0x8080D7u); }
    goto L_8080DA;
L_8080DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80DAu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80DAu,0x8080DAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80DAu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80DAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080DA STZ
    hw.write(cpu.address("dp", 0x96u), 0, cpu.m8?8:16);
    goto L_8080DC;
L_8080DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80DCu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80DCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x97u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080DC STZ
    hw.write(cpu.address("dp", 0x97u), 0, cpu.m8?8:16);
    goto L_8080DE;
L_8080DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80DEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80DEu, 6u, 3u, cpu.address("abs", 0x8444u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8080DE JSR -> $808444 stack real
    { cpu.push16Value(hw,0x80E0u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80E1u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8444u), 0x8080DEu); }
    goto L_8080E1;
L_8080E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E1u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80E1u,0x8080E1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E1u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E1u, 8u, 4u, 0x808ADEu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8080E1 JSL -> $808ADE stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80E4u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80E5u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808ADEu, 0x8080E1u); }
    goto L_8080E5;
L_8080E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E5u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80E5u,0x8080E5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E5u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E5u, 8u, 4u, 0x80A724u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8080E5 JSL -> $80A724 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80E8u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80E9u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A724u, 0x8080E5u); }
    goto L_8080E9;
L_8080E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80E9u,0x8080E9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E9u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E9u, 8u, 4u, 0x808BEAu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8080E9 JSL -> $808BEA stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80ECu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80EDu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808BEAu, 0x8080E9u); }
    goto L_8080ED;
L_8080ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80EDu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80EDu,0x8080EDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80EDu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80EDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080ED STZ
    hw.write(cpu.address("dp", 0x4Au), 0, cpu.m8?8:16);
    goto L_8080EF;
L_8080EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80EFu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80EFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080EF REP
    cpu.rep(0x20u);
    goto L_8080F1;
L_8080F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F1u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F1u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8080F1 PLB
    cpu.pop("PLB", hw);
    goto L_8080F2;
L_8080F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F2u,cpu,0x2Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F2u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8080F2 PLD
    cpu.pop("PLD", hw);
    goto L_8080F3;
L_8080F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F3u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F3u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8080F3 PLY
    cpu.pop("PLY", hw);
    goto L_8080F4;
L_8080F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F4u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F4u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8080F4 PLX
    cpu.pop("PLX", hw);
    goto L_8080F5;
L_8080F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F5u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F5u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8080F5 PLA
    cpu.pop("PLA", hw);
    goto L_8080F6;
L_8080F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F6u,cpu,0x40u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F6u, 7u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $8080F6 RTI stack real
    {auto dst=cpu.returnInterrupt(hw);hw.requestDispatch(dst,0x8080F6u);return;}
L_808105:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8105u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8105u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8105u, 8u, 4u, 0x808564u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808105 JSL -> $808564 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8108u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8109u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808564u, 0x808105u); }
    goto L_808109;
L_808109:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8109u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8109u,0x808109u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8109u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8109u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808109 REP
    cpu.rep(0x20u);
    goto L_80810B;
L_80810B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x810Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x810Bu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x810Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80810B PLB
    cpu.pop("PLB", hw);
    goto L_80810C;
L_80810C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x810Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x810Cu,cpu,0x2Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x810Cu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80810C PLD
    cpu.pop("PLD", hw);
    goto L_80810D;
L_80810D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x810Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x810Du,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x810Du, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80810D PLY
    cpu.pop("PLY", hw);
    goto L_80810E;
L_80810E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x810Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x810Eu,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x810Eu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80810E PLX
    cpu.pop("PLX", hw);
    goto L_80810F;
L_80810F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x810Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x810Fu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x810Fu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80810F PLA
    cpu.pop("PLA", hw);
    goto L_808110;
L_808110:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8110u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8110u,cpu,0x40u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8110u, 7u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $808110 RTI stack real
    {auto dst=cpu.returnInterrupt(hw);hw.requestDispatch(dst,0x808110u);return;}
}

void sub_80842B_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80842Bu: goto L_80842B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80842B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x842Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x842Bu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x842Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80842B RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80842Bu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80842Bu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80842B_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80842Bu: goto L_80842B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80842B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x842Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x842Bu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x842Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80842B RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80842Bu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80842Bu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_8084C3_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8084C3u: goto L_8084C3;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8084C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84C3u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84C3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8084C3 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8084C3u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8084C3u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80858D_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80858Du: goto L_80858D;
    case 0x80858Eu: goto L_80858E;
    case 0x808590u: goto L_808590;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80858D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x858Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x858Du,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x858Du, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80858D PHP
    cpu.push("PHP", hw);
    goto L_80858E;
L_80858E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x858Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x858Eu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x858Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80858E LDY
    cpu.setY(0x2u, 8);
    goto L_808590;
L_808590:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8590u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8590u,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8590u, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $808590 BRK
    hw.partial(0x808590u, "BRK"); return;
}

void sub_808D03_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808D03u: goto L_808D03;
    case 0x808D04u: goto L_808D04;
    case 0x808D06u: goto L_808D06;
    case 0x808D09u: goto L_808D09;
    case 0x808D0Au: goto L_808D0A;
    case 0x808D0Bu: goto L_808D0B;
    case 0x808D0Cu: goto L_808D0C;
    case 0x808D0Fu: goto L_808D0F;
    case 0x808D10u: goto L_808D10;
    case 0x808D13u: goto L_808D13;
    case 0x808D16u: goto L_808D16;
    case 0x808D17u: goto L_808D17;
    case 0x808D18u: goto L_808D18;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808D03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D03u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D03u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808D03 PHP
    cpu.push("PHP", hw);
    goto L_808D04;
L_808D04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D04u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D04u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D04 REP
    cpu.rep(0x20u);
    goto L_808D06;
L_808D06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D06u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D06u, 5u, 3u, cpu.address("abs", 0x0120u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D06 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x120u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808D09;
L_808D09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D09u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D09u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D09 ASL
    cpu.aslA();
    goto L_808D0A;
L_808D0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Au,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D0A ASL
    cpu.aslA();
    goto L_808D0B;
L_808D0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Bu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D0B CLC
    cpu.setFlag('C', false);
    goto L_808D0C;
L_808D0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Cu,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Cu, 5u, 3u, cpu.address("abs", 0x0120u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D0C ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x120u), cpu.m8?8:16));
    goto L_808D0F;
L_808D0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Fu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D0F CLC
    cpu.setFlag('C', false);
    goto L_808D10;
L_808D10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D10u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D10u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D10 ADC
    cpu.adc(0x3711u);
    goto L_808D13;
L_808D13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D13u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D13u, 5u, 3u, cpu.address("abs", 0x0120u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D13 STA
    hw.write(cpu.address("abs", 0x120u), cpu.a, cpu.m8?8:16);
    goto L_808D16;
L_808D16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D16u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D16u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D16 XBA
    cpu.xba();
    goto L_808D17;
L_808D17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D17u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D17u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808D17 PLP
    cpu.pop("PLP", hw);
    goto L_808D18;
L_808D18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D18u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D18u,0x808D18u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D18u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D18u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808D18 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808D18u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x808D18u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_808DBE_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808DBEu: goto L_808DBE;
    case 0x808DBFu: goto L_808DBF;
    case 0x808DC1u: goto L_808DC1;
    case 0x808DC2u: goto L_808DC2;
    case 0x808DC3u: goto L_808DC3;
    case 0x808DC4u: goto L_808DC4;
    case 0x808DC6u: goto L_808DC6;
    case 0x808DC9u: goto L_808DC9;
    case 0x808DCCu: goto L_808DCC;
    case 0x808DCFu: goto L_808DCF;
    case 0x808DD2u: goto L_808DD2;
    case 0x808DD5u: goto L_808DD5;
    case 0x808DD7u: goto L_808DD7;
    case 0x808DDAu: goto L_808DDA;
    case 0x808DDDu: goto L_808DDD;
    case 0x808DE0u: goto L_808DE0;
    case 0x808DE3u: goto L_808DE3;
    case 0x808DE6u: goto L_808DE6;
    case 0x808DE9u: goto L_808DE9;
    case 0x808DECu: goto L_808DEC;
    case 0x808DEFu: goto L_808DEF;
    case 0x808DF1u: goto L_808DF1;
    case 0x808DF2u: goto L_808DF2;
    case 0x808DF3u: goto L_808DF3;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808DBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DBEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DBEu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DBEu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808DBE PHP
    cpu.push("PHP", hw);
    goto L_808DBF;
L_808DBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DBFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DBFu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DBFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808DBF SEP
    cpu.sep(0x20u);
    goto L_808DC1;
L_808DC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC1u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC1u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808DC1 PHB
    cpu.push("PHB", hw);
    goto L_808DC2;
L_808DC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC2u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC2u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808DC2 PHA
    cpu.push("PHA", hw);
    goto L_808DC3;
L_808DC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC3u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC3u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808DC3 PLB
    cpu.pop("PLB", hw);
    goto L_808DC4;
L_808DC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808DC4 LDA
    cpu.setA(0x0u, 8);
    goto L_808DC6;
L_808DC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC6u, 4u, 3u, cpu.address("abs", 0x2133u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808DC6 STA
    hw.write(cpu.address("abs", 0x2133u), cpu.a, cpu.m8?8:16);
    goto L_808DC9;
L_808DC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC9u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC9u, 4u + 1u, 3u, cpu.address("absy", 0x0000u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808DC9 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808DCC;
L_808DCC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DCCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DCCu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DCCu, 4u, 3u, cpu.address("abs", 0x2105u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808DCC STA
    hw.write(cpu.address("abs", 0x2105u), cpu.a, cpu.m8?8:16);
    goto L_808DCF;
L_808DCF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DCFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DCFu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DCFu, 4u + 1u, 3u, cpu.address("absy", 0x0001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808DCF LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808DD2;
L_808DD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DD2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD2u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD2u, 4u, 3u, cpu.address("abs", 0x2101u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808DD2 STA
    hw.write(cpu.address("abs", 0x2101u), cpu.a, cpu.m8?8:16);
    goto L_808DD5;
L_808DD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD5u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808DD5 REP
    cpu.rep(0x20u);
    goto L_808DD7;
L_808DD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DD7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD7u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD7u, 5u + 1u, 3u, cpu.address("absy", 0x0002u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808DD7 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808DDA;
L_808DDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DDAu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DDAu, 5u, 3u, cpu.address("abs", 0x2107u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808DDA STA
    hw.write(cpu.address("abs", 0x2107u), cpu.a, cpu.m8?8:16);
    goto L_808DDD;
L_808DDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DDDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DDDu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DDDu, 5u + 1u, 3u, cpu.address("absy", 0x0004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808DDD LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808DE0;
L_808DE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE0u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE0u, 5u, 3u, cpu.address("abs", 0x2109u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808DE0 STA
    hw.write(cpu.address("abs", 0x2109u), cpu.a, cpu.m8?8:16);
    goto L_808DE3;
L_808DE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE3u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE3u, 5u + 1u, 3u, cpu.address("absy", 0x0006u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808DE3 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808DE6;
L_808DE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE6u, 5u, 3u, cpu.address("abs", 0x210Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808DE6 STA
    hw.write(cpu.address("abs", 0x210Bu), cpu.a, cpu.m8?8:16);
    goto L_808DE9;
L_808DE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE9u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE9u, 5u + 1u, 3u, cpu.address("absy", 0x0008u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808DE9 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808DEC;
L_808DEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DECu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DECu, 5u, 3u, cpu.address("abs", 0x212Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808DEC STA
    hw.write(cpu.address("abs", 0x212Cu), cpu.a, cpu.m8?8:16);
    goto L_808DEF;
L_808DEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DEFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DEFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808DEF STA
    hw.write(cpu.address("dp", 0x7Au), cpu.a, cpu.m8?8:16);
    goto L_808DF1;
L_808DF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF1u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF1u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808DF1 PLB
    cpu.pop("PLB", hw);
    goto L_808DF2;
L_808DF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF2u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF2u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808DF2 PLP
    cpu.pop("PLP", hw);
    goto L_808DF3;
L_808DF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DF3u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8DF3u,0x808DF3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF3u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808DF3 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808DF3u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x808DF3u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_809573_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809573u: goto L_809573;
    case 0x809574u: goto L_809574;
    case 0x809575u: goto L_809575;
    case 0x809576u: goto L_809576;
    case 0x809577u: goto L_809577;
    case 0x80957Bu: goto L_80957B;
    case 0x80957Du: goto L_80957D;
    case 0x809580u: goto L_809580;
    case 0x809582u: goto L_809582;
    case 0x809584u: goto L_809584;
    case 0x809585u: goto L_809585;
    case 0x809586u: goto L_809586;
    case 0x809587u: goto L_809587;
    case 0x809588u: goto L_809588;
    case 0x809589u: goto L_809589;
    case 0x80958Au: goto L_80958A;
    case 0x80958Du: goto L_80958D;
    case 0x80958Fu: goto L_80958F;
    case 0x809590u: goto L_809590;
    case 0x809591u: goto L_809591;
    case 0x809594u: goto L_809594;
    case 0x809596u: goto L_809596;
    case 0x809599u: goto L_809599;
    case 0x80959Bu: goto L_80959B;
    case 0x80959Cu: goto L_80959C;
    case 0x80959Du: goto L_80959D;
    case 0x8095A0u: goto L_8095A0;
    case 0x8095A2u: goto L_8095A2;
    case 0x8095A4u: goto L_8095A4;
    case 0x8095A7u: goto L_8095A7;
    case 0x8095A9u: goto L_8095A9;
    case 0x8095AAu: goto L_8095AA;
    case 0x8095ABu: goto L_8095AB;
    case 0x8095AFu: goto L_8095AF;
    case 0x8095B1u: goto L_8095B1;
    case 0x8095B4u: goto L_8095B4;
    case 0x8095B6u: goto L_8095B6;
    case 0x8095B8u: goto L_8095B8;
    case 0x8095BBu: goto L_8095BB;
    case 0x8095BCu: goto L_8095BC;
    case 0x8095BEu: goto L_8095BE;
    case 0x8095BFu: goto L_8095BF;
    case 0x8095C2u: goto L_8095C2;
    case 0x8095C4u: goto L_8095C4;
    case 0x8095C5u: goto L_8095C5;
    case 0x8095C7u: goto L_8095C7;
    case 0x8095C9u: goto L_8095C9;
    case 0x8095CBu: goto L_8095CB;
    case 0x8095CDu: goto L_8095CD;
    case 0x8095CFu: goto L_8095CF;
    case 0x8095D2u: goto L_8095D2;
    case 0x8095D4u: goto L_8095D4;
    case 0x8095D8u: goto L_8095D8;
    case 0x8095D9u: goto L_8095D9;
    case 0x8095DAu: goto L_8095DA;
    case 0x8095DBu: goto L_8095DB;
    case 0x8095DDu: goto L_8095DD;
    case 0x8095DFu: goto L_8095DF;
    case 0x8095E1u: goto L_8095E1;
    case 0x8095E3u: goto L_8095E3;
    case 0x8095E7u: goto L_8095E7;
    case 0x8095E9u: goto L_8095E9;
    case 0x8095EAu: goto L_8095EA;
    case 0x8095EEu: goto L_8095EE;
    case 0x8095F0u: goto L_8095F0;
    case 0x8095F3u: goto L_8095F3;
    case 0x8095F5u: goto L_8095F5;
    case 0x8095F8u: goto L_8095F8;
    case 0x8095FAu: goto L_8095FA;
    case 0x8095FCu: goto L_8095FC;
    case 0x8095FDu: goto L_8095FD;
    case 0x8095FEu: goto L_8095FE;
    case 0x8095FFu: goto L_8095FF;
    case 0x809601u: goto L_809601;
    case 0x809603u: goto L_809603;
    case 0x809606u: goto L_809606;
    case 0x809607u: goto L_809607;
    case 0x809609u: goto L_809609;
    case 0x80960Bu: goto L_80960B;
    case 0x80960Du: goto L_80960D;
    case 0x80960Fu: goto L_80960F;
    case 0x809611u: goto L_809611;
    case 0x809612u: goto L_809612;
    case 0x809614u: goto L_809614;
    case 0x809616u: goto L_809616;
    case 0x809617u: goto L_809617;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809573:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9573u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9573u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9573u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809573 PHP
    cpu.push("PHP", hw);
    goto L_809574;
L_809574:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9574u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9574u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9574u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809574 ASL
    cpu.aslA();
    goto L_809575;
L_809575:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9575u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9575u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9575u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809575 TAX
    cpu.transfer("TAX");
    goto L_809576;
L_809576:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9576u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9576u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9576u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809576 PHX
    cpu.push("PHX", hw);
    goto L_809577;
L_809577:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9577u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9577u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9577u, 6u, 4u, ((0x809618u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809577 LDA
    cpu.loadA(hw.readW(((0x809618u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80957B;
L_80957B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x957Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x957Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x957Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80957B STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80957D;
L_80957D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x957Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x957Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x957Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80957D LDA
    cpu.setA(0x80u, 16);
    goto L_809580;
L_809580:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9580u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9580u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9580u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809580 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_809582;
L_809582:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9582u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9582u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9582u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809582 STY
    hw.write(cpu.address("dp", 0x5Fu), cpu.y, cpu.x8?8:16);
    goto L_809584;
L_809584:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9584u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9584u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9584u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809584 TYA
    cpu.transfer("TYA");
    goto L_809585;
L_809585:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9585u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9585u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9585u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809585 ASL
    cpu.aslA();
    goto L_809586;
L_809586:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9586u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9586u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9586u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809586 ASL
    cpu.aslA();
    goto L_809587;
L_809587:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9587u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9587u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9587u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809587 ASL
    cpu.aslA();
    goto L_809588;
L_809588:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9588u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9588u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9588u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809588 ASL
    cpu.aslA();
    goto L_809589;
L_809589:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9589u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9589u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9589u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809589 TAX
    cpu.transfer("TAX");
    goto L_80958A;
L_80958A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x958Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x958Au,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x958Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80958A LDY
    cpu.setY(0x0u, 16);
    goto L_80958D;
L_80958D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x958Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x958Du,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x958Du, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $80958D LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80958F;
L_80958F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x958Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x958Fu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x958Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80958F INY
    cpu.inc('Y');
    goto L_809590;
L_809590:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9590u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9590u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9590u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809590 INY
    cpu.inc('Y');
    goto L_809591;
L_809591:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9591u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9591u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9591u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809591 CMP
    cpu.compareA(0xFFFFu);
    goto L_809594;
L_809594:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9594u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9594u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9594u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809594 BEQ -> $8095A9
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8095A9; }
    goto L_809596;
L_809596:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9596u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9596u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9596u, 6u, 3u, cpu.address("absx", 0x4300u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809596 STA
    hw.write(cpu.address("absx", 0x4300u), cpu.a, cpu.m8?8:16);
    goto L_809599;
L_809599:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9599u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9599u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9599u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $809599 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80959B;
L_80959B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x959Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x959Bu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x959Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80959B INY
    cpu.inc('Y');
    goto L_80959C;
L_80959C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x959Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x959Cu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x959Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80959C INY
    cpu.inc('Y');
    goto L_80959D;
L_80959D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x959Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x959Du,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x959Du, 6u, 3u, cpu.address("absx", 0x4302u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80959D STA
    hw.write(cpu.address("absx", 0x4302u), cpu.a, cpu.m8?8:16);
    goto L_8095A0;
L_8095A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95A0u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95A0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8095A0 SEP
    cpu.sep(0x20u);
    goto L_8095A2;
L_8095A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95A2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95A2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8095A2 LDA
    cpu.setA(0x7Eu, 8);
    goto L_8095A4;
L_8095A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95A4u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95A4u, 5u, 3u, cpu.address("absx", 0x4304u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8095A4 STA
    hw.write(cpu.address("absx", 0x4304u), cpu.a, cpu.m8?8:16);
    goto L_8095A7;
L_8095A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95A7u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95A7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8095A7 REP
    cpu.rep(0x20u);
    goto L_8095A9;
L_8095A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95A9u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95A9u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8095A9 PLX
    cpu.pop("PLX", hw);
    goto L_8095AA;
L_8095AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95AAu,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95AAu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8095AA PHX
    cpu.push("PHX", hw);
    goto L_8095AB;
L_8095AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95ABu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95ABu, 6u, 4u, ((0x809640u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8095AB LDA
    cpu.loadA(hw.readW(((0x809640u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8095AF;
L_8095AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95AFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95AFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8095AF STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_8095B1;
L_8095B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95B1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95B1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8095B1 LDA
    cpu.setA(0x80u, 16);
    goto L_8095B4;
L_8095B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95B4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95B4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8095B4 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_8095B6;
L_8095B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95B6u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95B6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8095B6 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Fu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_8095B8;
L_8095B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95B8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95B8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8095B8 LDA
    cpu.setA(0x0u, 16);
    goto L_8095BB;
L_8095BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95BBu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95BBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8095BB DEX
    cpu.decReg('X');
    goto L_8095BC;
L_8095BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95BCu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95BCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8095BC BMI -> $8095C4
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_8095C4; }
    goto L_8095BE;
L_8095BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95BEu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95BEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8095BE CLC
    cpu.setFlag('C', false);
    goto L_8095BF;
L_8095BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95BFu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95BFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8095BF ADC
    cpu.adc(0x400u);
    goto L_8095C2;
L_8095C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95C2u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95C2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8095C2 BPL -> $8095BB
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_8095BB; }
    goto L_8095C4;
L_8095C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95C4u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95C4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8095C4 TAX
    cpu.transfer("TAX");
    goto L_8095C5;
L_8095C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95C5u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95C5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8095C5 SEP
    cpu.sep(0x20u);
    goto L_8095C7;
L_8095C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95C7u,cpu,0xA7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95C7u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $8095C7 LDA
    cpu.loadA(hw.readW(cpu.addressDpLong(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8095C9;
L_8095C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95C9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95C9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8095C9 BEQ -> $8095E1
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8095E1; }
    goto L_8095CB;
L_8095CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95CBu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95CBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8095CB CMP
    cpu.compareA(0xFFu);
    goto L_8095CD;
L_8095CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95CDu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95CDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8095CD BEQ -> $8095E1
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8095E1; }
    goto L_8095CF;
L_8095CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95CFu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95CFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8095CF LDY
    cpu.setY(0x1u, 16);
    goto L_8095D2;
L_8095D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95D2u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95D2u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $8095D2 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8095D4;
L_8095D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95D4u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95D4u, 5u, 4u, ((0x7EE000u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8095D4 STA
    hw.write(((0x7EE000u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_8095D8;
L_8095D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95D8u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95D8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8095D8 INX
    cpu.inc('X');
    goto L_8095D9;
L_8095D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95D9u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95D9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8095D9 INY
    cpu.inc('Y');
    goto L_8095DA;
L_8095DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95DAu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95DAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8095DA TYA
    cpu.transfer("TYA");
    goto L_8095DB;
L_8095DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95DBu,cpu,0xC7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95DBu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $8095DB CMP
    cpu.compareA(hw.readW(cpu.addressDpLong(hw, 0x0u), cpu.m8?8:16));
    goto L_8095DD;
L_8095DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95DDu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95DDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8095DD BCC -> $8095D2
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_8095D2; }
    goto L_8095DF;
L_8095DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95DFu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95DFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8095DF SEP
    cpu.sep(0x20u);
    goto L_8095E1;
L_8095E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95E1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95E1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8095E1 LDA
    cpu.setA(0x0u, 8);
    goto L_8095E3;
L_8095E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95E3u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95E3u, 5u, 4u, ((0x7EE000u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8095E3 STA
    hw.write(((0x7EE000u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_8095E7;
L_8095E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95E7u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95E7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8095E7 REP
    cpu.rep(0x20u);
    goto L_8095E9;
L_8095E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95E9u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95E9u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8095E9 PLX
    cpu.pop("PLX", hw);
    goto L_8095EA;
L_8095EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95EAu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95EAu, 6u, 4u, ((0x80966Du + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8095EA LDA
    cpu.loadA(hw.readW(((0x80966Du + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8095EE;
L_8095EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95EEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95EEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8095EE STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_8095F0;
L_8095F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95F0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95F0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8095F0 LDA
    cpu.setA(0x80u, 16);
    goto L_8095F3;
L_8095F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95F3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95F3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8095F3 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_8095F5;
L_8095F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95F5u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95F5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8095F5 LDY
    cpu.setY(0x0u, 16);
    goto L_8095F8;
L_8095F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95F8u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95F8u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $8095F8 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8095FA;
L_8095FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95FAu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95FAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8095FA BMI -> $80960B
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_80960B; }
    goto L_8095FC;
L_8095FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95FCu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95FCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8095FC TAX
    cpu.transfer("TAX");
    goto L_8095FD;
L_8095FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95FDu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95FDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8095FD INY
    cpu.inc('Y');
    goto L_8095FE;
L_8095FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95FEu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95FEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8095FE INY
    cpu.inc('Y');
    goto L_8095FF;
L_8095FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95FFu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95FFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8095FF SEP
    cpu.sep(0x20u);
    goto L_809601;
L_809601:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9601u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9601u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9601u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $809601 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809603;
L_809603:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9603u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9603u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9603u, 5u, 3u, cpu.address("absx", 0x0000u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809603 STA
    hw.write(cpu.address("absx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_809606;
L_809606:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9606u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9606u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9606u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809606 INY
    cpu.inc('Y');
    goto L_809607;
L_809607:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9607u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9607u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9607u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809607 REP
    cpu.rep(0x20u);
    goto L_809609;
L_809609:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9609u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9609u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9609u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809609 BRA -> $8095F8
    goto L_8095F8;
L_80960B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x960Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x960Bu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x960Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80960B SEP
    cpu.sep(0x20u);
    goto L_80960D;
L_80960D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x960Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x960Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x960Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80960D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80960F;
L_80960F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x960Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x960Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x960Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80960F BEQ -> $809614
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_809614; }
    goto L_809611;
L_809611:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9611u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9611u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9611u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809611 INC
    cpu.inc('A');
    goto L_809612;
L_809612:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9612u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9612u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9612u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xB4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809612 STA
    hw.write(cpu.address("dp", 0xB4u), cpu.a, cpu.m8?8:16);
    goto L_809614;
L_809614:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9614u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9614u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9614u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809614 REP
    cpu.rep(0x20u);
    goto L_809616;
L_809616:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9616u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9616u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9616u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809616 PLP
    cpu.pop("PLP", hw);
    goto L_809617;
L_809617:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9617u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9617u,0x809617u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9617u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9617u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $809617 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x809617u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x809617u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80AB5E_E0M1X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80AB5Eu: goto L_80AB5E;
    case 0x80AB60u: goto L_80AB60;
    case 0x80AB64u: goto L_80AB64;
    case 0x80AB66u: goto L_80AB66;
    case 0x80AB68u: goto L_80AB68;
    case 0x80AB6Au: goto L_80AB6A;
    case 0x80AB6Cu: goto L_80AB6C;
    case 0x80AB6Eu: goto L_80AB6E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80AB5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB5Eu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB5Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xABu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB5E STZ
    hw.write(cpu.address("dp", 0xABu), 0, cpu.m8?8:16);
    goto L_80AB60;
L_80AB60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB60u,cpu,0x6Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB60u, 5u, 4u, 0xAB7DABu, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB60 ADC
    cpu.adc(hw.readW(0xAB7DABu, cpu.m8?8:16));
    goto L_80AB64;
L_80AB64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB64u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB64u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB64 SEP
    cpu.sep(0x20u);
    goto L_80AB66;
L_80AB66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB66u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB66u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB66u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB66 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x75u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AB68;
L_80AB68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB68u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB68u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB68 BNE -> $80AB6E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AB6E; }
    goto L_80AB6A;
L_80AB6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB6Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB6Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB6Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB6A LDA
    cpu.setA(0x80u, 8);
    goto L_80AB6C;
L_80AB6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB6Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB6Cu,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB6Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x47u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB6C TSB
    cpu.tsb(hw, cpu.address("dp", 0x47u), cpu.m8?8:16);
    goto L_80AB6E;
L_80AB6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB6Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB6Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AB6E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80AB6Eu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80AB6Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80AB5E_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80AB5Eu: goto L_80AB5E;
    case 0x80AB60u: goto L_80AB60;
    case 0x80AB64u: goto L_80AB64;
    case 0x80AB66u: goto L_80AB66;
    case 0x80AB68u: goto L_80AB68;
    case 0x80AB6Au: goto L_80AB6A;
    case 0x80AB6Cu: goto L_80AB6C;
    case 0x80AB6Eu: goto L_80AB6E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80AB5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB5Eu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB5Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xABu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB5E STZ
    hw.write(cpu.address("dp", 0xABu), 0, cpu.m8?8:16);
    goto L_80AB60;
L_80AB60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB60u,cpu,0x6Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB60u, 5u, 4u, 0xAB7DABu, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB60 ADC
    cpu.adc(hw.readW(0xAB7DABu, cpu.m8?8:16));
    goto L_80AB64;
L_80AB64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB64u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB64u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB64 SEP
    cpu.sep(0x20u);
    goto L_80AB66;
L_80AB66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB66u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB66u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB66u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB66 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x75u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AB68;
L_80AB68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB68u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB68u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB68 BNE -> $80AB6E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AB6E; }
    goto L_80AB6A;
L_80AB6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB6Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB6Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB6Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB6A LDA
    cpu.setA(0x80u, 8);
    goto L_80AB6C;
L_80AB6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB6Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB6Cu,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB6Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x47u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB6C TSB
    cpu.tsb(hw, cpu.address("dp", 0x47u), cpu.m8?8:16);
    goto L_80AB6E;
L_80AB6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB6Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB6Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AB6E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80AB6Eu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80AB6Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80AFC2_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80AFC2u: goto L_80AFC2;
    case 0x80AFC5u: goto L_80AFC5;
    case 0x80AFC7u: goto L_80AFC7;
    case 0x80AFCAu: goto L_80AFCA;
    case 0x80AFCDu: goto L_80AFCD;
    case 0x80AFD0u: goto L_80AFD0;
    case 0x80AFD3u: goto L_80AFD3;
    case 0x80AFD6u: goto L_80AFD6;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80AFC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC2u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC2u, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFC2 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x958u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AFC5;
L_80AFC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC5u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFC5 BEQ -> $80AFD0
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AFD0; }
    goto L_80AFC7;
L_80AFC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC7u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC7u, 8u, 3u, cpu.address("abs", 0x0986u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFC7 INC
    cpu.incMem(hw, cpu.address("abs", 0x986u), cpu.m8?8:16);
    goto L_80AFCA;
L_80AFCA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFCAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFCAu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFCAu, 6u, 3u, cpu.address("abs", 0xC53Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AFCA JSR -> $80C53B stack real
    { cpu.push16Value(hw,0xAFCCu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAFCDu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC53Bu), 0x80AFCAu); }
    goto L_80AFCD;
L_80AFCD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFCDu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAFCDu,0x80AFCDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFCDu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFCDu, 6u, 3u, cpu.address("abs", 0xC404u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AFCD JSR -> $80C404 stack real
    { cpu.push16Value(hw,0xAFCFu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAFD0u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC404u), 0x80AFCDu); }
    goto L_80AFD0;
L_80AFD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFD0u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFD0u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFD0u, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFD0 STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80AFD3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFD0u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFD0u, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFD0 STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80AFD3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFD0u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFD0u, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFD0 STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80AFD3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAFD0u,0x80AFD0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AFD3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFD3u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFD3u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFD3u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFD3 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80AFD6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFD3u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFD3u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFD3 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80AFD6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFD3u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFD3u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFD3 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80AFD6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAFD3u,0x80AFD3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AFD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFD6u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFD6u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFD6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AFD6 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80AFD6u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80AFD6u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFD6u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFD6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AFD6 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80AFD6u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80AFD6u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFD6u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFD6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AFD6 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80AFD6u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80AFD6u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAFD6u,0x80AFD6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_829403_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x829403u: goto L_829403;
    case 0x829406u: goto L_829406;
    case 0x829408u: goto L_829408;
    case 0x82940Au: goto L_82940A;
    case 0x82940Du: goto L_82940D;
    case 0x82940Fu: goto L_82940F;
    case 0x829411u: goto L_829411;
    case 0x829413u: goto L_829413;
    case 0x829415u: goto L_829415;
    case 0x829417u: goto L_829417;
    case 0x829419u: goto L_829419;
    case 0x82941Bu: goto L_82941B;
    case 0x82941Eu: goto L_82941E;
    case 0x829420u: goto L_829420;
    case 0x829422u: goto L_829422;
    case 0x829424u: goto L_829424;
    case 0x829426u: goto L_829426;
    case 0x829428u: goto L_829428;
    case 0x82942Au: goto L_82942A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_829403:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9403u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9403u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9403u, 8u, 3u, cpu.address("abs", 0x014Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829403 INC
    cpu.incMem(hw, cpu.address("abs", 0x14Au), cpu.m8?8:16);
    goto L_829406;
L_829406:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9406u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9406u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9406u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829406 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x75u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829408;
L_829408:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9408u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9408u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9408u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829408 BNE -> $82942A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82942A; }
    goto L_82940A;
L_82940A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x940Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x940Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x940Au, 5u, 3u, cpu.address("abs", 0x0177u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82940A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x177u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82940D;
L_82940D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x940Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x940Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x940Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82940D BNE -> $829419
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_829419; }
    goto L_82940F;
L_82940F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x940Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x940Fu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x940Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82940F SEP
    cpu.sep(0x20u);
    goto L_829411;
L_829411:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9411u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9411u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9411u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829411 LDA
    cpu.setA(0x82u, 8);
    goto L_829413;
L_829413:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9413u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9413u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9413u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x46u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829413 STA
    hw.write(cpu.address("dp", 0x46u), cpu.a, cpu.m8?8:16);
    goto L_829415;
L_829415:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9415u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9415u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9415u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829415 REP
    cpu.rep(0x20u);
    goto L_829417;
L_829417:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9417u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9417u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9417u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829417 BRA -> $82942A
    goto L_82942A;
L_829419:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9419u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9419u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9419u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829419 SEP
    cpu.sep(0x20u);
    goto L_82941B;
L_82941B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x941Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x941Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x941Bu, 4u, 3u, cpu.address("abs", 0x0135u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82941B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82941E;
L_82941E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x941Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x941Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x941Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82941E BNE -> $829424
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_829424; }
    goto L_829420;
L_829420:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9420u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9420u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9420u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829420 LDA
    cpu.setA(0x8Cu, 8);
    goto L_829422;
L_829422:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9422u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9422u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9422u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829422 BRA -> $829426
    goto L_829426;
L_829424:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9424u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9424u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9424u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829424 LDA
    cpu.setA(0x94u, 8);
    goto L_829426;
L_829426:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9426u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9426u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9426u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x46u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829426 STA
    hw.write(cpu.address("dp", 0x46u), cpu.a, cpu.m8?8:16);
    goto L_829428;
L_829428:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9428u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9428u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9428u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829428 REP
    cpu.rep(0x20u);
    goto L_82942A;
L_82942A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x942Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x942Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x942Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82942A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82942Au);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82942Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82970C_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82970Cu: goto L_82970C;
    case 0x82970Eu: goto L_82970E;
    case 0x829710u: goto L_829710;
    case 0x829713u: goto L_829713;
    case 0x829715u: goto L_829715;
    case 0x829718u: goto L_829718;
    case 0x82971Bu: goto L_82971B;
    case 0x82971Du: goto L_82971D;
    case 0x829720u: goto L_829720;
    case 0x829723u: goto L_829723;
    case 0x829726u: goto L_829726;
    case 0x829728u: goto L_829728;
    case 0x82972Bu: goto L_82972B;
    case 0x82972Eu: goto L_82972E;
    case 0x829730u: goto L_829730;
    case 0x829732u: goto L_829732;
    case 0x829735u: goto L_829735;
    case 0x829737u: goto L_829737;
    case 0x82973Au: goto L_82973A;
    case 0x82973Du: goto L_82973D;
    case 0x829741u: goto L_829741;
    case 0x829743u: goto L_829743;
    case 0x829746u: goto L_829746;
    case 0x829747u: goto L_829747;
    case 0x82974Au: goto L_82974A;
    case 0x82974Cu: goto L_82974C;
    case 0x82974Fu: goto L_82974F;
    case 0x829751u: goto L_829751;
    case 0x829754u: goto L_829754;
    case 0x829757u: goto L_829757;
    case 0x829759u: goto L_829759;
    case 0x82975Cu: goto L_82975C;
    case 0x82975Fu: goto L_82975F;
    case 0x829762u: goto L_829762;
    case 0x829765u: goto L_829765;
    case 0x829767u: goto L_829767;
    case 0x829769u: goto L_829769;
    case 0x82976Cu: goto L_82976C;
    case 0x82976Fu: goto L_82976F;
    case 0x829772u: goto L_829772;
    case 0x829773u: goto L_829773;
    case 0x829776u: goto L_829776;
    case 0x829778u: goto L_829778;
    case 0x829779u: goto L_829779;
    case 0x82977Bu: goto L_82977B;
    case 0x82977Eu: goto L_82977E;
    case 0x82977Fu: goto L_82977F;
    case 0x829782u: goto L_829782;
    case 0x829784u: goto L_829784;
    case 0x829787u: goto L_829787;
    case 0x829788u: goto L_829788;
    case 0x82978Bu: goto L_82978B;
    case 0x82978Eu: goto L_82978E;
    case 0x82978Fu: goto L_82978F;
    case 0x829790u: goto L_829790;
    case 0x829791u: goto L_829791;
    case 0x829792u: goto L_829792;
    case 0x829793u: goto L_829793;
    case 0x829794u: goto L_829794;
    case 0x829795u: goto L_829795;
    case 0x829796u: goto L_829796;
    case 0x829797u: goto L_829797;
    case 0x82979Au: goto L_82979A;
    case 0x82979Du: goto L_82979D;
    case 0x82979Fu: goto L_82979F;
    case 0x8297A2u: goto L_8297A2;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82970C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x970Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x970Cu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x970Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82970C LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82970E;
L_82970E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x970Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x970Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x970Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xAAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82970E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829710;
L_829710:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9710u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9710u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9710u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829710 BIT
    cpu.bit(0x400u, true);
    goto L_829713;
L_829713:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9713u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9713u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9713u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829713 BEQ -> $829723
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_829723; }
    goto L_829715;
L_829715:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9715u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9715u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9715u, 5u + 1u, 3u, cpu.address("absx", 0x029Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829715 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x29Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829718;
L_829718:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9718u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9718u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9718u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829718 CMP
    cpu.compareA(0x2u);
    goto L_82971B;
L_82971B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x971Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x971Bu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x971Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82971B BCC -> $829723
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_829723; }
    goto L_82971D;
L_82971D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x971Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x971Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x971Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82971D LDA
    cpu.setA(0x1u, 16);
    goto L_829720;
L_829720:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9720u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9720u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9720u, 6u, 3u, cpu.address("absx", 0x029Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829720 STA
    hw.write(cpu.address("absx", 0x29Eu), cpu.a, cpu.m8?8:16);
    goto L_829723;
L_829723:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9723u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9723u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9723u, 9u, 3u, cpu.address("absx", 0x029Eu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829723 DEC
    cpu.decMem(hw, cpu.address("absx", 0x29Eu), cpu.m8?8:16);
    goto L_829726;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9723u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9723u, 9u, 3u, cpu.address("absx", 0x029Eu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829723 DEC
    cpu.decMem(hw, cpu.address("absx", 0x29Eu), cpu.m8?8:16);
    goto L_829726;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9723u,0x829723u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829726:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9726u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9726u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9726u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829726 BMI -> $829747
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_829747; }
    goto L_829728;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9726u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9726u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829726 BMI -> $829747
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_829747; }
    goto L_829728;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9726u,0x829726u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829728:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9728u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9728u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9728u, 6u, 3u, cpu.address("abs", 0xA098u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829728 JSR -> $82A098 stack real
    { cpu.push16Value(hw,0x972Au); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x972Bu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA098u), 0x829728u); }
    goto L_82972B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9728u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9728u, 6u, 3u, cpu.address("abs", 0xA098u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829728 JSR -> $82A098 stack real
    { cpu.push16Value(hw,0x972Au); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x972Bu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA098u), 0x829728u); }
    goto L_82972B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9728u,0x829728u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82972B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x972Bu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x972Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x972Bu, 6u, 3u, cpu.address("abs", 0xA043u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82972B JSR -> $82A043 stack real
    { cpu.push16Value(hw,0x972Du); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x972Eu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA043u), 0x82972Bu); }
    goto L_82972E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x972Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x972Bu, 6u, 3u, cpu.address("abs", 0xA043u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82972B JSR -> $82A043 stack real
    { cpu.push16Value(hw,0x972Du); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x972Eu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA043u), 0x82972Bu); }
    goto L_82972E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x972Bu,0x82972Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82972E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x972Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x972Eu,0x82972Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x972Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x972Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82972E BEQ -> $829743
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_829743; }
    goto L_829730;
L_829730:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9730u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9730u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9730u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829730 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_829732;
L_829732:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9732u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9732u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9732u, 5u + 1u, 3u, cpu.address("absx", 0x043Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829732 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x43Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829735;
L_829735:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9735u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9735u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9735u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829735 BNE -> $829746
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_829746; }
    goto L_829737;
L_829737:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9737u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9737u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9737u, 9u, 3u, cpu.address("absx", 0x043Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829737 INC
    cpu.incMem(hw, cpu.address("absx", 0x43Cu), cpu.m8?8:16);
    goto L_82973A;
L_82973A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x973Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x973Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x973Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82973A LDA
    cpu.setA(0x25u, 16);
    goto L_82973D;
L_82973D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x973Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x973Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x973Du, 8u, 4u, 0x80A6FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82973D JSL -> $80A6FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9740u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9741u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6FBu, 0x82973Du); }
    goto L_829741;
L_829741:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9741u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9741u,0x829741u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9741u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9741u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829741 BRA -> $829746
    goto L_829746;
L_829743:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9743u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9743u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9743u, 6u, 3u, cpu.address("absx", 0x043Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829743 STZ
    hw.write(cpu.address("absx", 0x43Cu), 0, cpu.m8?8:16);
    goto L_829746;
L_829746:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9746u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9746u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9746u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829746 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x829746u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829746u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_829747:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9747u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9747u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9747u, 6u, 3u, cpu.address("absx", 0x043Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829747 STZ
    hw.write(cpu.address("absx", 0x43Cu), 0, cpu.m8?8:16);
    goto L_82974A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9747u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9747u, 6u, 3u, cpu.address("absx", 0x043Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829747 STZ
    hw.write(cpu.address("absx", 0x43Cu), 0, cpu.m8?8:16);
    goto L_82974A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9747u,0x829747u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82974A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x974Au))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x974Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x974Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xAAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82974A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82974C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x974Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x974Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xAAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82974A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82974C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x974Au,0x82974Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82974C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x974Cu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x974Cu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x974Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82974C BIT
    cpu.bit(0x400u, true);
    goto L_82974F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x974Cu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x974Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82974C BIT
    cpu.bit(0x400u, true);
    goto L_82974F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x974Cu,0x82974Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82974F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x974Fu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x974Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x974Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82974F BNE -> $829759
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_829759; }
    goto L_829751;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x974Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x974Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82974F BNE -> $829759
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_829759; }
    goto L_829751;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x974Fu,0x82974Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829751:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9751u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9751u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9751u, 5u + 1u, 3u, cpu.address("absx", 0x029Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829751 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x29Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829754;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9751u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9751u, 5u + 1u, 3u, cpu.address("absx", 0x029Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829751 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x29Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829754;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9751u,0x829751u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829754:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9754u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9754u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9754u, 6u, 3u, cpu.address("absx", 0x029Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829754 STA
    hw.write(cpu.address("absx", 0x29Eu), cpu.a, cpu.m8?8:16);
    goto L_829757;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9754u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9754u, 6u, 3u, cpu.address("absx", 0x029Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829754 STA
    hw.write(cpu.address("absx", 0x29Eu), cpu.a, cpu.m8?8:16);
    goto L_829757;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9754u,0x829754u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829757:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9757u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9757u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9757u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829757 BRA -> $82975F
    goto L_82975F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9757u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9757u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829757 BRA -> $82975F
    goto L_82975F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9757u,0x829757u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829759:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9759u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9759u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9759u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829759 LDA
    cpu.setA(0x1u, 16);
    goto L_82975C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9759u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9759u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829759 LDA
    cpu.setA(0x1u, 16);
    goto L_82975C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9759u,0x829759u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82975C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x975Cu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x975Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x975Cu, 6u, 3u, cpu.address("absx", 0x029Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82975C STA
    hw.write(cpu.address("absx", 0x29Eu), cpu.a, cpu.m8?8:16);
    goto L_82975F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x975Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x975Cu, 6u, 3u, cpu.address("absx", 0x029Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82975C STA
    hw.write(cpu.address("absx", 0x29Eu), cpu.a, cpu.m8?8:16);
    goto L_82975F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x975Cu,0x82975Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82975F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x975Fu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x975Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x975Fu, 6u, 3u, cpu.address("abs", 0xA098u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82975F JSR -> $82A098 stack real
    { cpu.push16Value(hw,0x9761u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9762u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA098u), 0x82975Fu); }
    goto L_829762;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x975Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x975Fu, 6u, 3u, cpu.address("abs", 0xA098u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82975F JSR -> $82A098 stack real
    { cpu.push16Value(hw,0x9761u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9762u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA098u), 0x82975Fu); }
    goto L_829762;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x975Fu,0x82975Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829762:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9762u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9762u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9762u, 6u, 3u, cpu.address("abs", 0xA043u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829762 JSR -> $82A043 stack real
    { cpu.push16Value(hw,0x9764u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9765u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA043u), 0x829762u); }
    goto L_829765;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9762u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9762u, 6u, 3u, cpu.address("abs", 0xA043u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829762 JSR -> $82A043 stack real
    { cpu.push16Value(hw,0x9764u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9765u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA043u), 0x829762u); }
    goto L_829765;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9762u,0x829762u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829765:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9765u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9765u,0x829765u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9765u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9765u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829765 BEQ -> $829773
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_829773; }
    goto L_829767;
L_829767:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9767u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9767u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9767u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829767 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_829769;
L_829769:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9769u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9769u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9769u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829769 LDA
    cpu.setA(0x10u, 16);
    goto L_82976C;
L_82976C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x976Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x976Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x976Cu, 6u, 3u, cpu.address("absx", 0x02A8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82976C STA
    hw.write(cpu.address("absx", 0x2A8u), cpu.a, cpu.m8?8:16);
    goto L_82976F;
L_82976F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x976Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x976Fu,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x976Fu, 9u, 3u, cpu.address("absx", 0x0200u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82976F INC
    cpu.incMem(hw, cpu.address("absx", 0x200u), cpu.m8?8:16);
    goto L_829772;
L_829772:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9772u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9772u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9772u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829772 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x829772u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829772u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_829773:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9773u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9773u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9773u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829773 LDA
    cpu.setA(0x6u, 16);
    goto L_829776;
L_829776:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9776u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9776u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9776u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829776 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x5Bu), cpu.m8?8:16));
    goto L_829778;
L_829778:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9778u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9778u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9778u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829778 TAY
    cpu.transfer("TAY");
    goto L_829779;
L_829779:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9779u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9779u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9779u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829779 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82977B;
L_82977B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x977Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x977Bu,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x977Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82977B ORA
    cpu.logicOr(0x12u);
    goto L_82977E;
L_82977E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x977Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x977Eu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x977Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82977E TAX
    cpu.transfer("TAX");
    goto L_82977F;
L_82977F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x977Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x977Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x977Fu, 5u + 1u, 3u, cpu.address("absx", 0x0208u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82977F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x208u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829782;
L_829782:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9782u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9782u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9782u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829782 BMI -> $82978E
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82978E; }
    goto L_829784;
L_829784:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9784u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9784u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9784u, 5u + 1u, 3u, cpu.address("absy", 0x027Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829784 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x27Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829787;
L_829787:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9787u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9787u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9787u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829787 CLC
    cpu.setFlag('C', false);
    goto L_829788;
L_829788:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9788u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9788u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9788u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829788 ADC
    cpu.adc(0x8u);
    goto L_82978B;
L_82978B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x978Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x978Bu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x978Bu, 6u, 3u, cpu.address("absy", 0x027Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82978B STA
    hw.write(cpu.address("absy", 0x27Eu), cpu.a, cpu.m8?8:16);
    goto L_82978E;
L_82978E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x978Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x978Eu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x978Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82978E DEX
    cpu.decReg('X');
    goto L_82978F;
L_82978F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x978Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x978Fu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x978Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82978F DEX
    cpu.decReg('X');
    goto L_829790;
L_829790:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9790u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9790u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9790u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829790 DEX
    cpu.decReg('X');
    goto L_829791;
L_829791:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9791u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9791u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9791u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829791 DEX
    cpu.decReg('X');
    goto L_829792;
L_829792:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9792u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9792u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9792u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829792 DEX
    cpu.decReg('X');
    goto L_829793;
L_829793:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9793u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9793u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9793u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829793 DEX
    cpu.decReg('X');
    goto L_829794;
L_829794:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9794u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9794u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9794u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829794 DEY
    cpu.decReg('Y');
    goto L_829795;
L_829795:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9795u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9795u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9795u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829795 DEY
    cpu.decReg('Y');
    goto L_829796;
L_829796:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9796u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9796u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9796u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829796 TYA
    cpu.transfer("TYA");
    goto L_829797;
L_829797:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9797u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9797u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9797u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829797 AND
    cpu.logicAnd(0xFFu);
    goto L_82979A;
L_82979A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x979Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x979Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x979Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82979A CMP
    cpu.compareA(0xFEu);
    goto L_82979D;
L_82979D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x979Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x979Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x979Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82979D BNE -> $82977F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82977F; }
    goto L_82979F;
L_82979F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x979Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x979Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x979Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82979F LDA
    cpu.setA(0x0u, 16);
    goto L_8297A2;
L_8297A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97A2u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97A2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8297A2 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8297A2u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8297A2u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_8299B9_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8299B9u: goto L_8299B9;
    case 0x8299BCu: goto L_8299BC;
    case 0x8299BEu: goto L_8299BE;
    case 0x8299BFu: goto L_8299BF;
    case 0x8299C2u: goto L_8299C2;
    case 0x8299C5u: goto L_8299C5;
    case 0x8299C6u: goto L_8299C6;
    case 0x8299C8u: goto L_8299C8;
    case 0x8299CBu: goto L_8299CB;
    case 0x8299CEu: goto L_8299CE;
    case 0x8299D0u: goto L_8299D0;
    case 0x8299D2u: goto L_8299D2;
    case 0x8299D5u: goto L_8299D5;
    case 0x8299D8u: goto L_8299D8;
    case 0x8299DAu: goto L_8299DA;
    case 0x8299DDu: goto L_8299DD;
    case 0x8299E0u: goto L_8299E0;
    case 0x8299E1u: goto L_8299E1;
    case 0x8299E4u: goto L_8299E4;
    case 0x8299E6u: goto L_8299E6;
    case 0x8299E9u: goto L_8299E9;
    case 0x8299ECu: goto L_8299EC;
    case 0x8299EEu: goto L_8299EE;
    case 0x8299F1u: goto L_8299F1;
    case 0x8299F2u: goto L_8299F2;
    case 0x8299F3u: goto L_8299F3;
    case 0x8299F4u: goto L_8299F4;
    case 0x8299F5u: goto L_8299F5;
    case 0x8299F6u: goto L_8299F6;
    case 0x8299F7u: goto L_8299F7;
    case 0x8299F8u: goto L_8299F8;
    case 0x8299FBu: goto L_8299FB;
    case 0x8299FEu: goto L_8299FE;
    case 0x829A00u: goto L_829A00;
    case 0x829A03u: goto L_829A03;
    case 0x829A06u: goto L_829A06;
    case 0x829A09u: goto L_829A09;
    case 0x829A0Cu: goto L_829A0C;
    case 0x829A0Eu: goto L_829A0E;
    case 0x829A11u: goto L_829A11;
    case 0x829A13u: goto L_829A13;
    case 0x829A15u: goto L_829A15;
    case 0x829A18u: goto L_829A18;
    case 0x829A1Bu: goto L_829A1B;
    case 0x829A1Du: goto L_829A1D;
    case 0x829A20u: goto L_829A20;
    case 0x829A23u: goto L_829A23;
    case 0x829A24u: goto L_829A24;
    case 0x829A26u: goto L_829A26;
    case 0x829A29u: goto L_829A29;
    case 0x829A2Bu: goto L_829A2B;
    case 0x829A2Eu: goto L_829A2E;
    case 0x829A2Fu: goto L_829A2F;
    case 0x829A30u: goto L_829A30;
    case 0x829A31u: goto L_829A31;
    case 0x829A32u: goto L_829A32;
    case 0x829A33u: goto L_829A33;
    case 0x829A34u: goto L_829A34;
    case 0x829A35u: goto L_829A35;
    case 0x829A38u: goto L_829A38;
    case 0x829A3Bu: goto L_829A3B;
    case 0x829A3Du: goto L_829A3D;
    case 0x829A40u: goto L_829A40;
    case 0x829A43u: goto L_829A43;
    case 0x829A46u: goto L_829A46;
    case 0x829A49u: goto L_829A49;
    case 0x829A4Bu: goto L_829A4B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8299B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99B9u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99B9u, 9u, 3u, cpu.address("absx", 0x0408u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8299B9 DEC
    cpu.decMem(hw, cpu.address("absx", 0x408u), cpu.m8?8:16);
    goto L_8299BC;
L_8299BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99BCu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99BCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8299BC BMI -> $8299BF
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_8299BF; }
    goto L_8299BE;
L_8299BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99BEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99BEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8299BE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8299BEu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8299BEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_8299BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99BFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99BFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8299BF LDA
    cpu.setA(0x2u, 16);
    goto L_8299C2;
L_8299C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99C2u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99C2u, 6u, 3u, cpu.address("absx", 0x0408u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8299C2 STA
    hw.write(cpu.address("absx", 0x408u), cpu.a, cpu.m8?8:16);
    goto L_8299C5;
L_8299C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99C5u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99C5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8299C5 TXA
    cpu.transfer("TXA");
    goto L_8299C6;
L_8299C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99C6u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99C6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8299C6 BNE -> $829A0E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_829A0E; }
    goto L_8299C8;
L_8299C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99C8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99C8u, 6u, 3u, cpu.address("abs", 0x9A4Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8299C8 JSR -> $829A4C stack real
    { cpu.push16Value(hw,0x99CAu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x99CBu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9A4Cu), 0x8299C8u); }
    goto L_8299CB;
L_8299CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99CBu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x99CBu,0x8299CBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99CBu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99CBu, 6u, 3u, cpu.address("abs", 0x9A7Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8299CB JSR -> $829A7C stack real
    { cpu.push16Value(hw,0x99CDu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x99CEu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9A7Cu), 0x8299CBu); }
    goto L_8299CE;
L_8299CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99CEu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x99CEu,0x8299CEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99CEu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99CEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8299CE REP
    cpu.rep(0x20u);
    goto L_8299D0;
L_8299D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99D0u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99D0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8299D0 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_8299D2;
L_8299D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99D2u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99D2u, 5u + 1u, 3u, cpu.address("absx", 0x0244u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8299D2 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x244u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8299D5;
L_8299D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99D5u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99D5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8299D5 AND
    cpu.logicAnd(0xFFF0u);
    goto L_8299D8;
L_8299D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99D8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99D8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8299D8 STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_8299DA;
L_8299DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99DAu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99DAu, 5u + 1u, 3u, cpu.address("absx", 0x0244u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8299DA LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x244u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8299DD;
L_8299DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99DDu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99DDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8299DD AND
    cpu.logicAnd(0xFu);
    goto L_8299E0;
L_8299E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99E0u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99E0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8299E0 ASL
    cpu.aslA();
    goto L_8299E1;
L_8299E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99E1u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99E1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8299E1 BIT
    cpu.bit(0x10u, true);
    goto L_8299E4;
L_8299E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99E4u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99E4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8299E4 BEQ -> $8299EC
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8299EC; }
    goto L_8299E6;
L_8299E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99E6u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99E6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8299E6 AND
    cpu.logicAnd(0xFu);
    goto L_8299E9;
L_8299E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99E9u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99E9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8299E9 ORA
    cpu.logicOr(0x1u);
    goto L_8299EC;
L_8299EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99ECu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99ECu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8299EC ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16));
    goto L_8299EE;
L_8299EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99EEu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99EEu, 6u, 3u, cpu.address("absx", 0x0244u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8299EE STA
    hw.write(cpu.address("absx", 0x244u), cpu.a, cpu.m8?8:16);
    goto L_8299F1;
L_8299F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99F1u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99F1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8299F1 INX
    cpu.inc('X');
    goto L_8299F2;
L_8299F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99F2u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99F2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8299F2 INX
    cpu.inc('X');
    goto L_8299F3;
L_8299F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99F3u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99F3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8299F3 INX
    cpu.inc('X');
    goto L_8299F4;
L_8299F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99F4u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99F4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8299F4 INX
    cpu.inc('X');
    goto L_8299F5;
L_8299F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99F5u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99F5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8299F5 INX
    cpu.inc('X');
    goto L_8299F6;
L_8299F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99F6u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99F6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8299F6 INX
    cpu.inc('X');
    goto L_8299F7;
L_8299F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99F7u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99F7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8299F7 TXA
    cpu.transfer("TXA");
    goto L_8299F8;
L_8299F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99F8u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99F8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8299F8 AND
    cpu.logicAnd(0xFFu);
    goto L_8299FB;
L_8299FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99FBu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99FBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8299FB CMP
    cpu.compareA(0x18u);
    goto L_8299FE;
L_8299FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99FEu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99FEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8299FE BCC -> $8299D2
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_8299D2; }
    goto L_829A00;
L_829A00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A00u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A00u, 8u, 3u, cpu.address("abs", 0x029Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829A00 DEC
    cpu.decMem(hw, cpu.address("abs", 0x29Au), cpu.m8?8:16);
    goto L_829A03;
L_829A03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A03u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A03u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829A03 LDA
    cpu.setA(0xFFFCu, 16);
    goto L_829A06;
L_829A06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A06u,cpu,0x1Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A06u, 8u, 3u, cpu.address("abs", 0x029Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829A06 TRB
    cpu.trb(hw, cpu.address("abs", 0x29Au), cpu.m8?8:16);
    goto L_829A09;
L_829A09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A09u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A09u, 8u, 3u, cpu.address("abs", 0x025Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829A09 INC
    cpu.incMem(hw, cpu.address("abs", 0x25Au), cpu.m8?8:16);
    goto L_829A0C;
L_829A0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A0Cu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A0Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829A0C BRA -> $829A49
    goto L_829A49;
L_829A0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A0Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A0Eu, 6u, 3u, cpu.address("abs", 0x9AAAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829A0E JSR -> $829AAA stack real
    { cpu.push16Value(hw,0x9A10u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9A11u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9AAAu), 0x829A0Eu); }
    goto L_829A11;
L_829A11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A11u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9A11u,0x829A11u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A11u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A11u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829A11 REP
    cpu.rep(0x20u);
    goto L_829A13;
L_829A13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A13u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A13u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829A13 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_829A15;
L_829A15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A15u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A15u, 5u + 1u, 3u, cpu.address("absx", 0x0244u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829A15 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x244u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829A18;
L_829A18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A18u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A18u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829A18 AND
    cpu.logicAnd(0xFFF0u);
    goto L_829A1B;
L_829A1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A1Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A1Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829A1B STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_829A1D;
L_829A1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A1Du,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A1Du, 5u + 1u, 3u, cpu.address("absx", 0x0244u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829A1D LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x244u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829A20;
L_829A20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A20u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A20u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829A20 AND
    cpu.logicAnd(0xFu);
    goto L_829A23;
L_829A23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A23u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A23u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829A23 LSR
    cpu.lsrA();
    goto L_829A24;
L_829A24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A24u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A24u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829A24 BCC -> $829A29
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_829A29; }
    goto L_829A26;
L_829A26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A26u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A26u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829A26 ORA
    cpu.logicOr(0x8u);
    goto L_829A29;
L_829A29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A29u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A29u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829A29 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16));
    goto L_829A2B;
L_829A2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A2Bu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A2Bu, 6u, 3u, cpu.address("absx", 0x0244u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829A2B STA
    hw.write(cpu.address("absx", 0x244u), cpu.a, cpu.m8?8:16);
    goto L_829A2E;
L_829A2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A2Eu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A2Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829A2E INX
    cpu.inc('X');
    goto L_829A2F;
L_829A2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A2Fu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A2Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829A2F INX
    cpu.inc('X');
    goto L_829A30;
L_829A30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A30u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A30u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829A30 INX
    cpu.inc('X');
    goto L_829A31;
L_829A31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A31u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A31u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829A31 INX
    cpu.inc('X');
    goto L_829A32;
L_829A32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A32u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A32u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829A32 INX
    cpu.inc('X');
    goto L_829A33;
L_829A33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A33u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A33u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829A33 INX
    cpu.inc('X');
    goto L_829A34;
L_829A34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A34u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A34u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829A34 TXA
    cpu.transfer("TXA");
    goto L_829A35;
L_829A35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A35u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A35u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829A35 AND
    cpu.logicAnd(0xFFu);
    goto L_829A38;
L_829A38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A38u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A38u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829A38 CMP
    cpu.compareA(0x18u);
    goto L_829A3B;
L_829A3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A3Bu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A3Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829A3B BCC -> $829A15
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_829A15; }
    goto L_829A3D;
L_829A3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A3Du,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A3Du, 8u, 3u, cpu.address("abs", 0x039Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829A3D INC
    cpu.incMem(hw, cpu.address("abs", 0x39Au), cpu.m8?8:16);
    goto L_829A40;
L_829A40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A40u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A40u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829A40 LDA
    cpu.setA(0xFFFCu, 16);
    goto L_829A43;
L_829A43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A43u,cpu,0x1Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A43u, 8u, 3u, cpu.address("abs", 0x039Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829A43 TRB
    cpu.trb(hw, cpu.address("abs", 0x39Au), cpu.m8?8:16);
    goto L_829A46;
L_829A46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A46u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A46u, 8u, 3u, cpu.address("abs", 0x035Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829A46 INC
    cpu.incMem(hw, cpu.address("abs", 0x35Au), cpu.m8?8:16);
    goto L_829A49;
L_829A49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A49u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A49u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829A49 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_829A4B;
L_829A4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A4Bu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A4Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829A4B RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x829A4Bu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829A4Bu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82A660_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82A660u: goto L_82A660;
    case 0x82A662u: goto L_82A662;
    case 0x82A665u: goto L_82A665;
    case 0x82A667u: goto L_82A667;
    case 0x82A66Bu: goto L_82A66B;
    case 0x82A66Eu: goto L_82A66E;
    case 0x82A671u: goto L_82A671;
    case 0x82A673u: goto L_82A673;
    case 0x82A674u: goto L_82A674;
    case 0x82A677u: goto L_82A677;
    case 0x82A679u: goto L_82A679;
    case 0x82A67Cu: goto L_82A67C;
    case 0x82A67Eu: goto L_82A67E;
    case 0x82A681u: goto L_82A681;
    case 0x82A684u: goto L_82A684;
    case 0x82A686u: goto L_82A686;
    case 0x82A689u: goto L_82A689;
    case 0x82A68Bu: goto L_82A68B;
    case 0x82A68Eu: goto L_82A68E;
    case 0x82A690u: goto L_82A690;
    case 0x82A694u: goto L_82A694;
    case 0x82A697u: goto L_82A697;
    case 0x82A699u: goto L_82A699;
    case 0x82A69Bu: goto L_82A69B;
    case 0x82A69Cu: goto L_82A69C;
    case 0x82A69Fu: goto L_82A69F;
    case 0x82A6A1u: goto L_82A6A1;
    case 0x82A6A4u: goto L_82A6A4;
    case 0x82A6A7u: goto L_82A6A7;
    case 0x82A6A9u: goto L_82A6A9;
    case 0x82A6ACu: goto L_82A6AC;
    case 0x82A6AEu: goto L_82A6AE;
    case 0x82A6B1u: goto L_82A6B1;
    case 0x82A6B3u: goto L_82A6B3;
    case 0x82A6B7u: goto L_82A6B7;
    case 0x82A6B9u: goto L_82A6B9;
    case 0x82A6BCu: goto L_82A6BC;
    case 0x82A6BFu: goto L_82A6BF;
    case 0x82A6C1u: goto L_82A6C1;
    case 0x82A6C3u: goto L_82A6C3;
    case 0x82A6C5u: goto L_82A6C5;
    case 0x82A6C9u: goto L_82A6C9;
    case 0x82A6CCu: goto L_82A6CC;
    case 0x82A6CFu: goto L_82A6CF;
    case 0x82A6D1u: goto L_82A6D1;
    case 0x82A6D2u: goto L_82A6D2;
    case 0x82A6D5u: goto L_82A6D5;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82A660:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA660u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA660u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA660u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A660 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A662;
L_82A662:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA662u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA662u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA662u, 5u + 1u, 3u, cpu.address("absy", 0x02E4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A662 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x2E4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A665;
L_82A665:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA665u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA665u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA665u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A665 BEQ -> $82A679
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A679; }
    goto L_82A667;
L_82A667:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA667u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA667u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA667u, 8u, 4u, 0x8096A3u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82A667 JSL -> $8096A3 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA66Au); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA66Bu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8096A3u, 0x82A667u); }
    goto L_82A66B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA667u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA667u, 8u, 4u, 0x8096A3u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82A667 JSL -> $8096A3 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA66Au); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA66Bu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8096A3u, 0x82A667u); }
    goto L_82A66B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA667u,0x82A667u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82A66B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA66Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA66Bu,0x82A66Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA66Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA66Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A66B AND
    cpu.logicAnd(0x3u);
    goto L_82A66E;
L_82A66E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA66Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA66Eu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA66Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A66E CMP
    cpu.compareA(0x3u);
    goto L_82A671;
L_82A671:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA671u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA671u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA671u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A671 BEQ -> $82A667
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A667; }
    goto L_82A673;
L_82A673:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA673u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA673u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA673u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A673 CLC
    cpu.setFlag('C', false);
    goto L_82A674;
L_82A674:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA674u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA674u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA674u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A674 ADC
    cpu.adc(0x9Cu);
    goto L_82A677;
L_82A677:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA677u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA677u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA677u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A677 BRA -> $82A6D5
    goto L_82A6D5;
L_82A679:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA679u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA679u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA679u, 5u + 1u, 3u, cpu.address("absy", 0x02E2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A679 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x2E2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A67C;
L_82A67C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA67Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA67Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA67Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A67C BNE -> $82A6A1
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A6A1; }
    goto L_82A67E;
L_82A67E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA67Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA67Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA67Eu, 5u, 3u, cpu.address("abs", 0x01CEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A67E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1CEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A681;
L_82A681:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA681u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA681u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA681u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A681 AND
    cpu.logicAnd(0xFFu);
    goto L_82A684;
L_82A684:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA684u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA684u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA684u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A684 BNE -> $82A68B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A68B; }
    goto L_82A686;
L_82A686:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA686u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA686u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA686u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A686 LDA
    cpu.setA(0x1Bu, 16);
    goto L_82A689;
L_82A689:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA689u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA689u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA689u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A689 BRA -> $82A68E
    goto L_82A68E;
L_82A68B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA68Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA68Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA68Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A68B LDA
    cpu.setA(0x1Eu, 16);
    goto L_82A68E;
L_82A68E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA68Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA68Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA68Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A68E STA
    hw.write(cpu.address("dp", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_82A690;
L_82A690:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA690u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA690u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA690u, 8u, 4u, 0x8096A3u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82A690 JSL -> $8096A3 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA693u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA694u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8096A3u, 0x82A690u); }
    goto L_82A694;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA690u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA690u, 8u, 4u, 0x8096A3u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82A690 JSL -> $8096A3 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA693u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA694u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8096A3u, 0x82A690u); }
    goto L_82A694;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA690u,0x82A690u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82A694:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA694u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA694u,0x82A694u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA694u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA694u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A694 AND
    cpu.logicAnd(0x1Fu);
    goto L_82A697;
L_82A697:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA697u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA697u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA697u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A697 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0xEu), cpu.m8?8:16));
    goto L_82A699;
L_82A699:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA699u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA699u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA699u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A699 BCS -> $82A690
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_82A690; }
    goto L_82A69B;
L_82A69B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA69Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA69Bu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA69Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A69B CLC
    cpu.setFlag('C', false);
    goto L_82A69C;
L_82A69C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA69Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA69Cu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA69Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A69C ADC
    cpu.adc(0x7Eu);
    goto L_82A69F;
L_82A69F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA69Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA69Fu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA69Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A69F BRA -> $82A6D5
    goto L_82A6D5;
L_82A6A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A1u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A1u, 5u, 3u, cpu.address("abs", 0x01CEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A6A1 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1CEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A6A4;
L_82A6A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A6A4 AND
    cpu.logicAnd(0xFFu);
    goto L_82A6A7;
L_82A6A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A7u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A6A7 BNE -> $82A6AE
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A6AE; }
    goto L_82A6A9;
L_82A6A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A6A9 LDA
    cpu.setA(0x78u, 16);
    goto L_82A6AC;
L_82A6AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6ACu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6ACu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A6AC BRA -> $82A6B1
    goto L_82A6B1;
L_82A6AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6AEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6AEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A6AE LDA
    cpu.setA(0x7Du, 16);
    goto L_82A6B1;
L_82A6B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A6B1 STA
    hw.write(cpu.address("dp", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_82A6B3;
L_82A6B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6B3u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B3u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B3u, 8u, 4u, 0x8096BAu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82A6B3 JSL -> $8096BA stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA6B6u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA6B7u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8096BAu, 0x82A6B3u); }
    goto L_82A6B7;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B3u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B3u, 8u, 4u, 0x8096BAu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82A6B3 JSL -> $8096BA stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA6B6u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA6B7u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8096BAu, 0x82A6B3u); }
    goto L_82A6B7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA6B3u,0x82A6B3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82A6B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6B7u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA6B7u,0x82A6B7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x55u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A6B7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x55u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A6B9;
L_82A6B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B9u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A6B9 AND
    cpu.logicAnd(0x7Fu);
    goto L_82A6BC;
L_82A6BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6BCu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6BCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A6BC CMP
    cpu.compareA(0x7Du);
    goto L_82A6BF;
L_82A6BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6BFu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6BFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A6BF BCS -> $82A6B3
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_82A6B3; }
    goto L_82A6C1;
L_82A6C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C1u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A6C1 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0xEu), cpu.m8?8:16));
    goto L_82A6C3;
L_82A6C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C3u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A6C3 BCC -> $82A6D5
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_82A6D5; }
    goto L_82A6C5;
L_82A6C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C5u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C5u, 8u, 4u, 0x8096A3u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82A6C5 JSL -> $8096A3 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA6C8u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA6C9u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8096A3u, 0x82A6C5u); }
    goto L_82A6C9;
L_82A6C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6C9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA6C9u,0x82A6C9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C9u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A6C9 AND
    cpu.logicAnd(0x3Fu);
    goto L_82A6CC;
L_82A6CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6CCu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6CCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A6CC CMP
    cpu.compareA(0x24u);
    goto L_82A6CF;
L_82A6CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6CFu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6CFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A6CF BCS -> $82A6C5
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_82A6C5; }
    goto L_82A6D1;
L_82A6D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D1u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A6D1 CLC
    cpu.setFlag('C', false);
    goto L_82A6D2;
L_82A6D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D2u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A6D2 ADC
    cpu.adc(0x54u);
    goto L_82A6D5;
L_82A6D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D5u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A6D5 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82A6D5u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82A6D5u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82B6C9_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B6C9u: goto L_82B6C9;
    case 0x82B6CBu: goto L_82B6CB;
    case 0x82B6CDu: goto L_82B6CD;
    case 0x82B6CFu: goto L_82B6CF;
    case 0x82B6D1u: goto L_82B6D1;
    case 0x82B6D4u: goto L_82B6D4;
    case 0x82B6D5u: goto L_82B6D5;
    case 0x82B6D6u: goto L_82B6D6;
    case 0x82B6D7u: goto L_82B6D7;
    case 0x82B6D9u: goto L_82B6D9;
    case 0x82B6DBu: goto L_82B6DB;
    case 0x82B6DDu: goto L_82B6DD;
    case 0x82B6DEu: goto L_82B6DE;
    case 0x82B6DFu: goto L_82B6DF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B6C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6C9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6C9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6C9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B6CB;
L_82B6CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6CBu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6CBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6CB BMI -> $82B6D7
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82B6D7; }
    goto L_82B6CD;
L_82B6CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6CDu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6CDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6CD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B6CF;
L_82B6CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6CFu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6CFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6CF BMI -> $82B6D5
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82B6D5; }
    goto L_82B6D1;
L_82B6D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D1u,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D1u, 4u, 3u, cpu.address("abs", 0x000Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6D1 CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0xEu), cpu.m8?8:16));
    goto L_82B6D4;
L_82B6D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D4u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B6D4 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B6D4u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B6D4u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82B6D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D5u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6D5 CLC
    cpu.setFlag('C', false);
    goto L_82B6D6;
L_82B6D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D6u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B6D6 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B6D6u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B6D6u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82B6D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6D7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B6D9;
L_82B6D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D9u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6D9 BPL -> $82B6DE
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82B6DE; }
    goto L_82B6DB;
L_82B6DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DBu,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6DB CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0xEu), cpu.m8?8:16));
    goto L_82B6DD;
L_82B6DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DDu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DDu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B6DD RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B6DDu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B6DDu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82B6DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DEu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6DE SEC
    cpu.setFlag('C', true);
    goto L_82B6DF;
L_82B6DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B6DF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B6DFu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B6DFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82B6F6_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B6F6u: goto L_82B6F6;
    case 0x82B6F8u: goto L_82B6F8;
    case 0x82B6FBu: goto L_82B6FB;
    case 0x82B6FEu: goto L_82B6FE;
    case 0x82B701u: goto L_82B701;
    case 0x82B704u: goto L_82B704;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B6F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F6u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6F6 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B6F8;
L_82B6F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F8u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F8u, 9u, 3u, cpu.address("absx", 0x02C8u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6F8 INC
    cpu.incMem(hw, cpu.address("absx", 0x2C8u), cpu.m8?8:16);
    goto L_82B6FB;
L_82B6FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6FBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6FBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6FB LDA
    cpu.setA(0x3u, 16);
    goto L_82B6FE;
L_82B6FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6FEu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6FEu, 6u, 3u, cpu.address("absx", 0x02CAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6FE STA
    hw.write(cpu.address("absx", 0x2CAu), cpu.a, cpu.m8?8:16);
    goto L_82B701;
L_82B701:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB701u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB701u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB701u, 6u, 3u, cpu.address("abs", 0xBA5Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B701 JSR -> $82BA5D stack real
    { cpu.push16Value(hw,0xB703u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB704u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBA5Du), 0x82B701u); }
    goto L_82B704;
L_82B704:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB704u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB704u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB704u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B704 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B704u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B704u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB704u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB704u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B704 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B704u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B704u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB704u,0x82B704u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_82B6F6_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B6F6u: goto L_82B6F6;
    case 0x82B6F8u: goto L_82B6F8;
    case 0x82B6FBu: goto L_82B6FB;
    case 0x82B6FEu: goto L_82B6FE;
    case 0x82B701u: goto L_82B701;
    case 0x82B704u: goto L_82B704;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B6F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F6u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6F6 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B6F8;
L_82B6F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F8u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F8u, 9u, 3u, cpu.address("absx", 0x02C8u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6F8 INC
    cpu.incMem(hw, cpu.address("absx", 0x2C8u), cpu.m8?8:16);
    goto L_82B6FB;
L_82B6FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6FBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6FBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6FB LDA
    cpu.setA(0x3u, 16);
    goto L_82B6FE;
L_82B6FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6FEu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6FEu, 6u, 3u, cpu.address("absx", 0x02CAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6FE STA
    hw.write(cpu.address("absx", 0x2CAu), cpu.a, cpu.m8?8:16);
    goto L_82B701;
L_82B701:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB701u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB701u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB701u, 6u, 3u, cpu.address("abs", 0xBA5Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B701 JSR -> $82BA5D stack real
    { cpu.push16Value(hw,0xB703u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB704u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBA5Du), 0x82B701u); }
    goto L_82B704;
L_82B704:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB704u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB704u,0x82B704u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB704u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB704u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B704 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B704u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B704u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82B910_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B910u: goto L_82B910;
    case 0x82B913u: goto L_82B913;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B910:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB910u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB910u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB910u, 6u, 3u, cpu.address("abs", 0xB9A2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B910 JSR -> $82B9A2 stack real
    { cpu.push16Value(hw,0xB912u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB913u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB9A2u), 0x82B910u); }
    goto L_82B913;
L_82B913:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB913u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB913u,0x82B913u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB913u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB913u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B913 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B913u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B913u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82B92E_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B92Eu: goto L_82B92E;
    case 0x82B931u: goto L_82B931;
    case 0x82B933u: goto L_82B933;
    case 0x82B936u: goto L_82B936;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B92E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB92Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB92Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB92Eu, 6u, 3u, cpu.address("abs", 0xB9B0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B92E JSR -> $82B9B0 stack real
    { cpu.push16Value(hw,0xB930u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB931u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB9B0u), 0x82B92Eu); }
    goto L_82B931;
L_82B931:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB931u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB931u,0x82B931u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB931u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB931u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B931 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x61u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B933;
L_82B933:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB933u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB933u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB933u, 6u, 3u, cpu.address("abs", 0xB998u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B933 JSR -> $82B998 stack real
    { cpu.push16Value(hw,0xB935u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB936u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB998u), 0x82B933u); }
    goto L_82B936;
L_82B936:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB936u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB936u,0x82B936u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB936u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB936u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B936 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B936u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B936u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82BB49_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82BB49u: goto L_82BB49;
    case 0x82BB4Cu: goto L_82BB4C;
    case 0x82BB4Eu: goto L_82BB4E;
    case 0x82BB50u: goto L_82BB50;
    case 0x82BB52u: goto L_82BB52;
    case 0x82BB53u: goto L_82BB53;
    case 0x82BB54u: goto L_82BB54;
    case 0x82BB55u: goto L_82BB55;
    case 0x82BB56u: goto L_82BB56;
    case 0x82BB58u: goto L_82BB58;
    case 0x82BB5Au: goto L_82BB5A;
    case 0x82BB5Bu: goto L_82BB5B;
    case 0x82BB5Cu: goto L_82BB5C;
    case 0x82BB5Eu: goto L_82BB5E;
    case 0x82BB60u: goto L_82BB60;
    case 0x82BB61u: goto L_82BB61;
    case 0x82BB62u: goto L_82BB62;
    case 0x82BB65u: goto L_82BB65;
    case 0x82BB67u: goto L_82BB67;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82BB49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB49u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB49u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB49 LDY
    cpu.setY(0x0u, 16);
    goto L_82BB4C;
L_82BB4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB4Cu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB4Cu,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB4Cu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 2u, 0u);
    // $82BB4C LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BB4E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB4Cu,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB4Cu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 2u, 0u);
    // $82BB4C LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BB4E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBB4Cu,0x82BB4Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82BB4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB4Eu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB4Eu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB4Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB4E BMI -> $82BB67
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82BB67; }
    goto L_82BB50;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB4Eu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB4Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB4E BMI -> $82BB67
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82BB67; }
    goto L_82BB50;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBB4Eu,0x82BB4Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82BB50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB50u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB50u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB50u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB50 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_82BB52;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB50u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB50u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB50 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_82BB52;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBB50u,0x82BB50u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82BB52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB52u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB52u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB52u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB52 INY
    cpu.inc('Y');
    goto L_82BB53;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB52u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB52u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB52 INY
    cpu.inc('Y');
    goto L_82BB53;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBB52u,0x82BB52u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82BB53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB53u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB53u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB53u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB53 INY
    cpu.inc('Y');
    goto L_82BB54;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB53u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB53u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB53 INY
    cpu.inc('Y');
    goto L_82BB54;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBB53u,0x82BB53u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82BB54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB54u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB54u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB54u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB54 INY
    cpu.inc('Y');
    goto L_82BB55;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB54u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB54u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB54 INY
    cpu.inc('Y');
    goto L_82BB55;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBB54u,0x82BB54u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82BB55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB55u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB55u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB55u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB55 INY
    cpu.inc('Y');
    goto L_82BB56;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB55u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB55u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB55 INY
    cpu.inc('Y');
    goto L_82BB56;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBB55u,0x82BB55u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82BB56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB56u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB56u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB56u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 2u, 0u);
    // $82BB56 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BB58;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB56u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB56u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 2u, 0u);
    // $82BB56 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BB58;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBB56u,0x82BB56u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82BB58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB58u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB58u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB58u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB58 STA
    hw.write(cpu.address("dp", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_82BB5A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB58u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB58u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB58 STA
    hw.write(cpu.address("dp", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_82BB5A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBB58u,0x82BB58u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82BB5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB5Au))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB5Au,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB5Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB5A INY
    cpu.inc('Y');
    goto L_82BB5B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB5Au,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB5Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB5A INY
    cpu.inc('Y');
    goto L_82BB5B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBB5Au,0x82BB5Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82BB5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB5Bu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB5Bu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB5Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB5B INY
    cpu.inc('Y');
    goto L_82BB5C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB5Bu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB5Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB5B INY
    cpu.inc('Y');
    goto L_82BB5C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBB5Bu,0x82BB5Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82BB5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB5Cu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB5Cu,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB5Cu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 2u, 0u);
    // $82BB5C LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BB5E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB5Cu,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB5Cu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 2u, 0u);
    // $82BB5C LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BB5E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBB5Cu,0x82BB5Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82BB5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB5Eu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB5Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB5Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB5E STA
    hw.write(cpu.address("dp", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_82BB60;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB5Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB5Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB5E STA
    hw.write(cpu.address("dp", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_82BB60;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBB5Eu,0x82BB5Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82BB60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB60u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB60u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB60u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB60 INY
    cpu.inc('Y');
    goto L_82BB61;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB60u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB60u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB60 INY
    cpu.inc('Y');
    goto L_82BB61;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBB60u,0x82BB60u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82BB61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB61u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB61u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB61u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB61 INY
    cpu.inc('Y');
    goto L_82BB62;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB61u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB61u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB61 INY
    cpu.inc('Y');
    goto L_82BB62;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBB61u,0x82BB61u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82BB62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB62u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB62u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB62u, 6u, 3u, cpu.address("abs", 0xBB68u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82BB62 JSR -> $82BB68 stack real
    { cpu.push16Value(hw,0xBB64u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBB65u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBB68u), 0x82BB62u); }
    goto L_82BB65;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB62u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB62u, 6u, 3u, cpu.address("abs", 0xBB68u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82BB62 JSR -> $82BB68 stack real
    { cpu.push16Value(hw,0xBB64u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBB65u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBB68u), 0x82BB62u); }
    goto L_82BB65;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBB62u,0x82BB62u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82BB65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB65u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBB65u,0x82BB65u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB65u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB65u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB65 BRA -> $82BB4C
    goto L_82BB4C;
L_82BB67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB67u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB67u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB67u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82BB67 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82BB67u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82BB67u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB67u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB67u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82BB67 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82BB67u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82BB67u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBB67u,0x82BB67u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_82D2E6_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82D2E6u: goto L_82D2E6;
    case 0x82D2E9u: goto L_82D2E9;
    case 0x82D2ECu: goto L_82D2EC;
    case 0x82D2EEu: goto L_82D2EE;
    case 0x82D2EFu: goto L_82D2EF;
    case 0x82D2F2u: goto L_82D2F2;
    case 0x82D2F5u: goto L_82D2F5;
    case 0x82D2F7u: goto L_82D2F7;
    case 0x82D2FAu: goto L_82D2FA;
    case 0x82D2FBu: goto L_82D2FB;
    case 0x82D2FCu: goto L_82D2FC;
    case 0x82D2FFu: goto L_82D2FF;
    case 0x82D301u: goto L_82D301;
    case 0x82D303u: goto L_82D303;
    case 0x82D304u: goto L_82D304;
    case 0x82D308u: goto L_82D308;
    case 0x82D30Bu: goto L_82D30B;
    case 0x82D30Du: goto L_82D30D;
    case 0x82D310u: goto L_82D310;
    case 0x82D313u: goto L_82D313;
    case 0x82D316u: goto L_82D316;
    case 0x82D317u: goto L_82D317;
    case 0x82D319u: goto L_82D319;
    case 0x82D31Cu: goto L_82D31C;
    case 0x82D31Du: goto L_82D31D;
    case 0x82D31Fu: goto L_82D31F;
    case 0x82D320u: goto L_82D320;
    case 0x82D323u: goto L_82D323;
    case 0x82D325u: goto L_82D325;
    case 0x82D326u: goto L_82D326;
    case 0x82D329u: goto L_82D329;
    case 0x82D32Au: goto L_82D32A;
    case 0x82D32Cu: goto L_82D32C;
    case 0x82D32Fu: goto L_82D32F;
    case 0x82D332u: goto L_82D332;
    case 0x82D335u: goto L_82D335;
    case 0x82D336u: goto L_82D336;
    case 0x82D337u: goto L_82D337;
    case 0x82D338u: goto L_82D338;
    case 0x82D339u: goto L_82D339;
    case 0x82D33Bu: goto L_82D33B;
    case 0x82D33Du: goto L_82D33D;
    case 0x82D340u: goto L_82D340;
    case 0x82D342u: goto L_82D342;
    case 0x82D344u: goto L_82D344;
    case 0x82D346u: goto L_82D346;
    case 0x82D349u: goto L_82D349;
    case 0x82D34Cu: goto L_82D34C;
    case 0x82D34Eu: goto L_82D34E;
    case 0x82D34Fu: goto L_82D34F;
    case 0x82D351u: goto L_82D351;
    case 0x82D354u: goto L_82D354;
    case 0x82D355u: goto L_82D355;
    case 0x82D357u: goto L_82D357;
    case 0x82D358u: goto L_82D358;
    case 0x82D35Bu: goto L_82D35B;
    case 0x82D35Du: goto L_82D35D;
    case 0x82D35Eu: goto L_82D35E;
    case 0x82D361u: goto L_82D361;
    case 0x82D364u: goto L_82D364;
    case 0x82D367u: goto L_82D367;
    case 0x82D36Au: goto L_82D36A;
    case 0x82D36Du: goto L_82D36D;
    case 0x82D36Fu: goto L_82D36F;
    case 0x82D372u: goto L_82D372;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82D2E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2E6u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2E6u, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D2E6 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D2E9;
L_82D2E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2E9u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2E9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D2E9 CMP
    cpu.compareA(0x1u);
    goto L_82D2EC;
L_82D2EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2ECu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2ECu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D2EC BEQ -> $82D2EF
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82D2EF; }
    goto L_82D2EE;
L_82D2EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2EEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2EEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D2EE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82D2EEu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82D2EEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82D2EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2EFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2EFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D2EF LDA
    cpu.setA(0x1u, 16);
    goto L_82D2F2;
L_82D2F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2F2u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2F2u, 5u, 3u, cpu.address("abs", 0x081Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D2F2 STA
    hw.write(cpu.address("abs", 0x81Au), cpu.a, cpu.m8?8:16);
    goto L_82D2F5;
L_82D2F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2F5u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2F5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D2F5 STZ
    hw.write(cpu.address("dp", 0x63u), 0, cpu.m8?8:16);
    goto L_82D2F7;
L_82D2F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2F7u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2F7u, 5u, 3u, cpu.address("abs", 0x081Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D2F7 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x81Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D2FA;
L_82D2FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2FAu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2FAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D2FA ASL
    cpu.aslA();
    goto L_82D2FB;
L_82D2FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2FBu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2FBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D2FB TAX
    cpu.transfer("TAX");
    goto L_82D2FC;
L_82D2FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2FCu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2FCu, 5u + 1u, 3u, cpu.address("absx", 0x0806u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D2FC LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x806u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D2FF;
L_82D2FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2FFu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2FFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D2FF BMI -> $82D346
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82D346; }
    goto L_82D301;
L_82D301:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD301u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD301u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD301u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D301 STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_82D303;
L_82D303:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD303u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD303u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD303u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D303 TAX
    cpu.transfer("TAX");
    goto L_82D304;
L_82D304:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD304u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD304u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD304u, 6u, 4u, ((0x9E94C5u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D304 LDA
    cpu.loadA(hw.readW(((0x9E94C5u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D308;
L_82D308:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD308u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD308u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD308u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D308 AND
    cpu.logicAnd(0xFFu);
    goto L_82D30B;
L_82D30B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD30Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD30Bu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD30Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D30B LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82D30D;
L_82D30D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD30Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD30Du,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD30Du, 6u, 3u, cpu.address("absy", 0x0884u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D30D STA
    hw.write(cpu.address("absy", 0x884u), cpu.a, cpu.m8?8:16);
    goto L_82D310;
L_82D310:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD310u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD310u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD310u, 6u, 3u, cpu.address("abs", 0xA6D6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D310 JSR -> $82A6D6 stack real
    { cpu.push16Value(hw,0xD312u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD313u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6D6u), 0x82D310u); }
    goto L_82D313;
L_82D313:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD313u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD313u,0x82D313u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD313u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD313u, 5u, 3u, cpu.address("abs", 0x081Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D313 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x81Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82D316;
L_82D316:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD316u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD316u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD316u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D316 DEX
    cpu.decReg('X');
    goto L_82D317;
L_82D317:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD317u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD317u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD317u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D317 BEQ -> $82D326
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82D326; }
    goto L_82D319;
L_82D319:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD319u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD319u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD319u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D319 LDA
    cpu.setA(0x1Au, 16);
    goto L_82D31C;
L_82D31C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD31Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD31Cu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD31Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D31C DEX
    cpu.decReg('X');
    goto L_82D31D;
L_82D31D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD31Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD31Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD31Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D31D BEQ -> $82D325
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82D325; }
    goto L_82D31F;
L_82D31F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD31Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD31Fu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD31Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D31F CLC
    cpu.setFlag('C', false);
    goto L_82D320;
L_82D320:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD320u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD320u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD320u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D320 ADC
    cpu.adc(0x1Au);
    goto L_82D323;
L_82D323:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD323u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD323u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD323u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D323 BRA -> $82D31C
    goto L_82D31C;
L_82D325:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD325u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD325u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD325u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D325 TAX
    cpu.transfer("TAX");
    goto L_82D326;
L_82D326:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD326u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD326u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD326u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D326 LDA
    cpu.setA(0x1Au, 16);
    goto L_82D329;
L_82D329:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD329u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD329u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD329u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D329 LSR
    cpu.lsrA();
    goto L_82D32A;
L_82D32A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD32Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD32Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD32Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D32A STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82D32C;
L_82D32C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD32Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD32Cu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD32Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D32C LDY
    cpu.setY(0x0u, 16);
    goto L_82D32F;
L_82D32F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD32Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD32Fu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD32Fu, 5u + 1u, 3u, cpu.address("absy", 0x0240u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D32F LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x240u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D332;
L_82D332:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD332u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD332u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD332u, 6u, 3u, cpu.address("absx", 0x081Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D332 STA
    hw.write(cpu.address("absx", 0x81Cu), cpu.a, cpu.m8?8:16);
    goto L_82D335;
L_82D335:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD335u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD335u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD335u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D335 INX
    cpu.inc('X');
    goto L_82D336;
L_82D336:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD336u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD336u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD336u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D336 INX
    cpu.inc('X');
    goto L_82D337;
L_82D337:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD337u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD337u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD337u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D337 INY
    cpu.inc('Y');
    goto L_82D338;
L_82D338:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD338u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD338u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD338u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D338 INY
    cpu.inc('Y');
    goto L_82D339;
L_82D339:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD339u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD339u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD339u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D339 DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_82D33B;
L_82D33B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD33Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD33Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD33Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D33B BNE -> $82D32F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82D32F; }
    goto L_82D33D;
L_82D33D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD33Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD33Du,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD33Du, 8u, 3u, cpu.address("abs", 0x081Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D33D INC
    cpu.incMem(hw, cpu.address("abs", 0x81Au), cpu.m8?8:16);
    goto L_82D340;
L_82D340:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD340u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD340u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD340u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D340 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_82D342;
L_82D342:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD342u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD342u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD342u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D342 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_82D344;
L_82D344:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD344u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD344u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD344u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D344 BRA -> $82D2F7
    goto L_82D2F7;
L_82D346:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD346u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD346u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD346u, 5u, 3u, cpu.address("abs", 0x081Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D346 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x81Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82D349;
L_82D349:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD349u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD349u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD349u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D349 CPX
    cpu.compareX(0x5u);
    goto L_82D34C;
L_82D34C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD34Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD34Cu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD34Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D34C BCS -> $82D36F
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_82D36F; }
    goto L_82D34E;
L_82D34E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD34Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD34Eu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD34Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D34E DEX
    cpu.decReg('X');
    goto L_82D34F;
L_82D34F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD34Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD34Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD34Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D34F BEQ -> $82D35E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82D35E; }
    goto L_82D351;
L_82D351:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD351u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD351u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD351u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D351 LDA
    cpu.setA(0x1Au, 16);
    goto L_82D354;
L_82D354:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD354u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD354u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD354u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D354 DEX
    cpu.decReg('X');
    goto L_82D355;
L_82D355:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD355u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD355u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD355u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D355 BEQ -> $82D35D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82D35D; }
    goto L_82D357;
L_82D357:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD357u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD357u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD357u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D357 CLC
    cpu.setFlag('C', false);
    goto L_82D358;
L_82D358:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD358u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD358u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD358u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D358 ADC
    cpu.adc(0x1Au);
    goto L_82D35B;
L_82D35B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD35Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD35Bu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD35Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D35B BRA -> $82D354
    goto L_82D354;
L_82D35D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD35Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD35Du,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD35Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D35D TAX
    cpu.transfer("TAX");
    goto L_82D35E;
L_82D35E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD35Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD35Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD35Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D35E LDA
    cpu.setA(0xFFFFu, 16);
    goto L_82D361;
L_82D361:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD361u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD361u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD361u, 6u, 3u, cpu.address("absx", 0x081Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D361 STA
    hw.write(cpu.address("absx", 0x81Cu), cpu.a, cpu.m8?8:16);
    goto L_82D364;
L_82D364:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD364u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD364u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD364u, 8u, 3u, cpu.address("abs", 0x081Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D364 INC
    cpu.incMem(hw, cpu.address("abs", 0x81Au), cpu.m8?8:16);
    goto L_82D367;
L_82D367:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD367u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD367u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD367u, 5u, 3u, cpu.address("abs", 0x081Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D367 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x81Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D36A;
L_82D36A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD36Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD36Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD36Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D36A CMP
    cpu.compareA(0x5u);
    goto L_82D36D;
L_82D36D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD36Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD36Du,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD36Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D36D BCC -> $82D346
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_82D346; }
    goto L_82D36F;
L_82D36F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD36Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD36Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD36Fu, 6u, 3u, cpu.address("abs", 0xD373u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D36F JSR -> $82D373 stack real
    { cpu.push16Value(hw,0xD371u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD372u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD373u), 0x82D36Fu); }
    goto L_82D372;
L_82D372:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD372u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD372u,0x82D372u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD372u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD372u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D372 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82D372u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82D372u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82D2E6_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82D2E6u: goto L_82D2E6;
    case 0x82D2E9u: goto L_82D2E9;
    case 0x82D2ECu: goto L_82D2EC;
    case 0x82D2EEu: goto L_82D2EE;
    case 0x82D2EFu: goto L_82D2EF;
    case 0x82D2F2u: goto L_82D2F2;
    case 0x82D2F5u: goto L_82D2F5;
    case 0x82D2F7u: goto L_82D2F7;
    case 0x82D2FAu: goto L_82D2FA;
    case 0x82D2FBu: goto L_82D2FB;
    case 0x82D2FCu: goto L_82D2FC;
    case 0x82D2FFu: goto L_82D2FF;
    case 0x82D301u: goto L_82D301;
    case 0x82D303u: goto L_82D303;
    case 0x82D304u: goto L_82D304;
    case 0x82D308u: goto L_82D308;
    case 0x82D30Bu: goto L_82D30B;
    case 0x82D30Du: goto L_82D30D;
    case 0x82D310u: goto L_82D310;
    case 0x82D313u: goto L_82D313;
    case 0x82D316u: goto L_82D316;
    case 0x82D317u: goto L_82D317;
    case 0x82D319u: goto L_82D319;
    case 0x82D31Cu: goto L_82D31C;
    case 0x82D31Du: goto L_82D31D;
    case 0x82D31Fu: goto L_82D31F;
    case 0x82D320u: goto L_82D320;
    case 0x82D323u: goto L_82D323;
    case 0x82D325u: goto L_82D325;
    case 0x82D326u: goto L_82D326;
    case 0x82D329u: goto L_82D329;
    case 0x82D32Au: goto L_82D32A;
    case 0x82D32Cu: goto L_82D32C;
    case 0x82D32Fu: goto L_82D32F;
    case 0x82D332u: goto L_82D332;
    case 0x82D335u: goto L_82D335;
    case 0x82D336u: goto L_82D336;
    case 0x82D337u: goto L_82D337;
    case 0x82D338u: goto L_82D338;
    case 0x82D339u: goto L_82D339;
    case 0x82D33Bu: goto L_82D33B;
    case 0x82D33Du: goto L_82D33D;
    case 0x82D340u: goto L_82D340;
    case 0x82D342u: goto L_82D342;
    case 0x82D344u: goto L_82D344;
    case 0x82D346u: goto L_82D346;
    case 0x82D349u: goto L_82D349;
    case 0x82D34Cu: goto L_82D34C;
    case 0x82D34Eu: goto L_82D34E;
    case 0x82D34Fu: goto L_82D34F;
    case 0x82D351u: goto L_82D351;
    case 0x82D354u: goto L_82D354;
    case 0x82D355u: goto L_82D355;
    case 0x82D357u: goto L_82D357;
    case 0x82D358u: goto L_82D358;
    case 0x82D35Bu: goto L_82D35B;
    case 0x82D35Du: goto L_82D35D;
    case 0x82D35Eu: goto L_82D35E;
    case 0x82D361u: goto L_82D361;
    case 0x82D364u: goto L_82D364;
    case 0x82D367u: goto L_82D367;
    case 0x82D36Au: goto L_82D36A;
    case 0x82D36Du: goto L_82D36D;
    case 0x82D36Fu: goto L_82D36F;
    case 0x82D372u: goto L_82D372;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82D2E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2E6u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2E6u, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D2E6 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D2E9;
L_82D2E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2E9u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2E9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D2E9 CMP
    cpu.compareA(0x1u);
    goto L_82D2EC;
L_82D2EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2ECu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2ECu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D2EC BEQ -> $82D2EF
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82D2EF; }
    goto L_82D2EE;
L_82D2EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2EEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2EEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D2EE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82D2EEu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82D2EEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82D2EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2EFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2EFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D2EF LDA
    cpu.setA(0x1u, 16);
    goto L_82D2F2;
L_82D2F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2F2u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2F2u, 5u, 3u, cpu.address("abs", 0x081Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D2F2 STA
    hw.write(cpu.address("abs", 0x81Au), cpu.a, cpu.m8?8:16);
    goto L_82D2F5;
L_82D2F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2F5u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2F5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D2F5 STZ
    hw.write(cpu.address("dp", 0x63u), 0, cpu.m8?8:16);
    goto L_82D2F7;
L_82D2F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2F7u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2F7u, 5u, 3u, cpu.address("abs", 0x081Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D2F7 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x81Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D2FA;
L_82D2FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2FAu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2FAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D2FA ASL
    cpu.aslA();
    goto L_82D2FB;
L_82D2FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2FBu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2FBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D2FB TAX
    cpu.transfer("TAX");
    goto L_82D2FC;
L_82D2FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2FCu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2FCu, 5u + 1u, 3u, cpu.address("absx", 0x0806u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D2FC LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x806u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D2FF;
L_82D2FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2FFu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2FFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D2FF BMI -> $82D346
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82D346; }
    goto L_82D301;
L_82D301:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD301u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD301u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD301u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D301 STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_82D303;
L_82D303:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD303u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD303u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD303u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D303 TAX
    cpu.transfer("TAX");
    goto L_82D304;
L_82D304:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD304u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD304u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD304u, 6u, 4u, ((0x9E94C5u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D304 LDA
    cpu.loadA(hw.readW(((0x9E94C5u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D308;
L_82D308:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD308u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD308u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD308u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D308 AND
    cpu.logicAnd(0xFFu);
    goto L_82D30B;
L_82D30B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD30Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD30Bu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD30Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D30B LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82D30D;
L_82D30D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD30Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD30Du,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD30Du, 6u, 3u, cpu.address("absy", 0x0884u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D30D STA
    hw.write(cpu.address("absy", 0x884u), cpu.a, cpu.m8?8:16);
    goto L_82D310;
L_82D310:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD310u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD310u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD310u, 6u, 3u, cpu.address("abs", 0xA6D6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D310 JSR -> $82A6D6 stack real
    { cpu.push16Value(hw,0xD312u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD313u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6D6u), 0x82D310u); }
    goto L_82D313;
L_82D313:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD313u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD313u,0x82D313u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD313u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD313u, 5u, 3u, cpu.address("abs", 0x081Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D313 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x81Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82D316;
L_82D316:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD316u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD316u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD316u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D316 DEX
    cpu.decReg('X');
    goto L_82D317;
L_82D317:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD317u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD317u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD317u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D317 BEQ -> $82D326
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82D326; }
    goto L_82D319;
L_82D319:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD319u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD319u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD319u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D319 LDA
    cpu.setA(0x1Au, 16);
    goto L_82D31C;
L_82D31C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD31Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD31Cu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD31Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D31C DEX
    cpu.decReg('X');
    goto L_82D31D;
L_82D31D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD31Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD31Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD31Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D31D BEQ -> $82D325
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82D325; }
    goto L_82D31F;
L_82D31F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD31Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD31Fu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD31Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D31F CLC
    cpu.setFlag('C', false);
    goto L_82D320;
L_82D320:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD320u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD320u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD320u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D320 ADC
    cpu.adc(0x1Au);
    goto L_82D323;
L_82D323:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD323u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD323u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD323u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D323 BRA -> $82D31C
    goto L_82D31C;
L_82D325:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD325u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD325u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD325u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D325 TAX
    cpu.transfer("TAX");
    goto L_82D326;
L_82D326:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD326u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD326u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD326u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D326 LDA
    cpu.setA(0x1Au, 16);
    goto L_82D329;
L_82D329:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD329u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD329u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD329u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D329 LSR
    cpu.lsrA();
    goto L_82D32A;
L_82D32A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD32Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD32Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD32Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D32A STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82D32C;
L_82D32C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD32Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD32Cu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD32Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D32C LDY
    cpu.setY(0x0u, 16);
    goto L_82D32F;
L_82D32F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD32Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD32Fu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD32Fu, 5u + 1u, 3u, cpu.address("absy", 0x0240u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D32F LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x240u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D332;
L_82D332:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD332u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD332u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD332u, 6u, 3u, cpu.address("absx", 0x081Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D332 STA
    hw.write(cpu.address("absx", 0x81Cu), cpu.a, cpu.m8?8:16);
    goto L_82D335;
L_82D335:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD335u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD335u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD335u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D335 INX
    cpu.inc('X');
    goto L_82D336;
L_82D336:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD336u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD336u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD336u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D336 INX
    cpu.inc('X');
    goto L_82D337;
L_82D337:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD337u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD337u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD337u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D337 INY
    cpu.inc('Y');
    goto L_82D338;
L_82D338:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD338u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD338u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD338u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D338 INY
    cpu.inc('Y');
    goto L_82D339;
L_82D339:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD339u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD339u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD339u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D339 DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_82D33B;
L_82D33B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD33Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD33Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD33Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D33B BNE -> $82D32F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82D32F; }
    goto L_82D33D;
L_82D33D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD33Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD33Du,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD33Du, 8u, 3u, cpu.address("abs", 0x081Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D33D INC
    cpu.incMem(hw, cpu.address("abs", 0x81Au), cpu.m8?8:16);
    goto L_82D340;
L_82D340:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD340u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD340u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD340u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D340 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_82D342;
L_82D342:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD342u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD342u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD342u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D342 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_82D344;
L_82D344:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD344u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD344u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD344u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D344 BRA -> $82D2F7
    goto L_82D2F7;
L_82D346:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD346u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD346u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD346u, 5u, 3u, cpu.address("abs", 0x081Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D346 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x81Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82D349;
L_82D349:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD349u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD349u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD349u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D349 CPX
    cpu.compareX(0x5u);
    goto L_82D34C;
L_82D34C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD34Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD34Cu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD34Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D34C BCS -> $82D36F
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_82D36F; }
    goto L_82D34E;
L_82D34E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD34Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD34Eu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD34Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D34E DEX
    cpu.decReg('X');
    goto L_82D34F;
L_82D34F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD34Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD34Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD34Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D34F BEQ -> $82D35E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82D35E; }
    goto L_82D351;
L_82D351:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD351u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD351u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD351u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D351 LDA
    cpu.setA(0x1Au, 16);
    goto L_82D354;
L_82D354:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD354u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD354u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD354u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D354 DEX
    cpu.decReg('X');
    goto L_82D355;
L_82D355:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD355u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD355u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD355u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D355 BEQ -> $82D35D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82D35D; }
    goto L_82D357;
L_82D357:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD357u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD357u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD357u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D357 CLC
    cpu.setFlag('C', false);
    goto L_82D358;
L_82D358:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD358u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD358u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD358u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D358 ADC
    cpu.adc(0x1Au);
    goto L_82D35B;
L_82D35B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD35Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD35Bu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD35Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D35B BRA -> $82D354
    goto L_82D354;
L_82D35D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD35Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD35Du,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD35Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D35D TAX
    cpu.transfer("TAX");
    goto L_82D35E;
L_82D35E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD35Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD35Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD35Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D35E LDA
    cpu.setA(0xFFFFu, 16);
    goto L_82D361;
L_82D361:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD361u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD361u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD361u, 6u, 3u, cpu.address("absx", 0x081Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D361 STA
    hw.write(cpu.address("absx", 0x81Cu), cpu.a, cpu.m8?8:16);
    goto L_82D364;
L_82D364:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD364u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD364u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD364u, 8u, 3u, cpu.address("abs", 0x081Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D364 INC
    cpu.incMem(hw, cpu.address("abs", 0x81Au), cpu.m8?8:16);
    goto L_82D367;
L_82D367:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD367u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD367u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD367u, 5u, 3u, cpu.address("abs", 0x081Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D367 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x81Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D36A;
L_82D36A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD36Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD36Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD36Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D36A CMP
    cpu.compareA(0x5u);
    goto L_82D36D;
L_82D36D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD36Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD36Du,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD36Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D36D BCC -> $82D346
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_82D346; }
    goto L_82D36F;
L_82D36F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD36Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD36Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD36Fu, 6u, 3u, cpu.address("abs", 0xD373u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D36F JSR -> $82D373 stack real
    { cpu.push16Value(hw,0xD371u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD372u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD373u), 0x82D36Fu); }
    goto L_82D372;
L_82D372:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD372u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD372u,0x82D372u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD372u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD372u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D372 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82D372u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82D372u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82D399_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82D399u: goto L_82D399;
    case 0x82D39Cu: goto L_82D39C;
    case 0x82D39Fu: goto L_82D39F;
    case 0x82D3A1u: goto L_82D3A1;
    case 0x82D3A2u: goto L_82D3A2;
    case 0x82D3A4u: goto L_82D3A4;
    case 0x82D3A6u: goto L_82D3A6;
    case 0x82D3A8u: goto L_82D3A8;
    case 0x82D3ABu: goto L_82D3AB;
    case 0x82D3ADu: goto L_82D3AD;
    case 0x82D3AFu: goto L_82D3AF;
    case 0x82D3B2u: goto L_82D3B2;
    case 0x82D3B4u: goto L_82D3B4;
    case 0x82D3B6u: goto L_82D3B6;
    case 0x82D3B9u: goto L_82D3B9;
    case 0x82D3BBu: goto L_82D3BB;
    case 0x82D3BEu: goto L_82D3BE;
    case 0x82D3BFu: goto L_82D3BF;
    case 0x82D3C1u: goto L_82D3C1;
    case 0x82D3C3u: goto L_82D3C3;
    case 0x82D3C5u: goto L_82D3C5;
    case 0x82D3C8u: goto L_82D3C8;
    case 0x82D3CAu: goto L_82D3CA;
    case 0x82D3CCu: goto L_82D3CC;
    case 0x82D3CFu: goto L_82D3CF;
    case 0x82D3D1u: goto L_82D3D1;
    case 0x82D3D4u: goto L_82D3D4;
    case 0x82D3D6u: goto L_82D3D6;
    case 0x82D3D7u: goto L_82D3D7;
    case 0x82D3D9u: goto L_82D3D9;
    case 0x82D3DBu: goto L_82D3DB;
    case 0x82D3DDu: goto L_82D3DD;
    case 0x82D3E1u: goto L_82D3E1;
    case 0x82D3E4u: goto L_82D3E4;
    case 0x82D3E5u: goto L_82D3E5;
    case 0x82D3E7u: goto L_82D3E7;
    case 0x82D3E9u: goto L_82D3E9;
    case 0x82D3EBu: goto L_82D3EB;
    case 0x82D3EDu: goto L_82D3ED;
    case 0x82D3EFu: goto L_82D3EF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82D399:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD399u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD399u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD399u, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D399 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D39C;
L_82D39C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD39Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD39Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD39Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D39C CMP
    cpu.compareA(0x1u);
    goto L_82D39F;
L_82D39F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD39Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD39Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD39Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D39F BEQ -> $82D3A2
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82D3A2; }
    goto L_82D3A1;
L_82D3A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3A1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3A1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D3A1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82D3A1u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82D3A1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82D3A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3A2u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3A2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3A2 STZ
    hw.write(cpu.address("dp", 0x61u), 0, cpu.m8?8:16);
    goto L_82D3A4;
L_82D3A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3A4u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3A4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3A4 STZ
    hw.write(cpu.address("dp", 0x63u), 0, cpu.m8?8:16);
    goto L_82D3A6;
L_82D3A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3A6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3A6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3A6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x63u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D3A8;
L_82D3A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3A8u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3A8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3A8 CMP
    cpu.compareA(0x8u);
    goto L_82D3AB;
L_82D3AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3ABu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3ABu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3AB BCS -> $82D3EF
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_82D3EF; }
    goto L_82D3AD;
L_82D3AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3ADu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3ADu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3AD LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x61u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82D3AF;
L_82D3AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3AFu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3AFu, 5u + 1u, 3u, cpu.address("absx", 0x081Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3AF LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x81Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D3B2;
L_82D3B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3B2u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3B2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3B2 BMI -> $82D3EF
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82D3EF; }
    goto L_82D3B4;
L_82D3B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3B4u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3B4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3B4 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82D3B6;
L_82D3B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3B6u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3B6u, 5u + 1u, 3u, cpu.address("absy", 0x0884u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3B6 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x884u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D3B9;
L_82D3B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3B9u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3B9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3B9 BMI -> $82D3E1
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82D3E1; }
    goto L_82D3BB;
L_82D3BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3BBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3BBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3BB LDA
    cpu.setA(0x81Cu, 16);
    goto L_82D3BE;
L_82D3BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3BEu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3BEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3BE CLC
    cpu.setFlag('C', false);
    goto L_82D3BF;
L_82D3BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3BFu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3BFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3BF ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x61u), cpu.m8?8:16));
    goto L_82D3C1;
L_82D3C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3C1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3C1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3C1 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82D3C3;
L_82D3C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3C3u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3C3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3C3 STZ
    hw.write(cpu.address("dp", 0x2u), 0, cpu.m8?8:16);
    goto L_82D3C5;
L_82D3C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3C5u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3C5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3C5 LDX
    cpu.setX(0x3u, 16);
    goto L_82D3C8;
L_82D3C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3C8u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3C8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3C8 SEP
    cpu.sep(0x20u);
    goto L_82D3CA;
L_82D3CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3CAu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3CAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3CA LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82D3CC;
L_82D3CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3CCu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3CCu, 4u + 1u, 3u, cpu.address("absy", 0x0894u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3CC LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x894u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D3CF;
L_82D3CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3CFu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3CFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3CF STA
    hw.write(cpu.address("dpx", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_82D3D1;
L_82D3D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3D1u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3D1u, 4u + 1u, 3u, cpu.address("absy", 0x088Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3D1 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x88Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D3D4;
L_82D3D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3D4u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3D4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x10u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3D4 STA
    hw.write(cpu.address("dpx", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_82D3D6;
L_82D3D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3D6u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3D6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3D6 DEX
    cpu.decReg('X');
    goto L_82D3D7;
L_82D3D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3D7u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3D7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3D7 BPL -> $82D3CA
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82D3CA; }
    goto L_82D3D9;
L_82D3D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3D9u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3D9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3D9 REP
    cpu.rep(0x20u);
    goto L_82D3DB;
L_82D3DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3DBu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3DBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3DB STZ
    hw.write(cpu.address("dp", 0xEu), 0, cpu.m8?8:16);
    goto L_82D3DD;
L_82D3DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3DDu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3DDu, 8u, 4u, 0x808915u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82D3DD JSL -> $808915 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD3E0u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD3E1u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808915u, 0x82D3DDu); }
    goto L_82D3E1;
L_82D3E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3E1u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD3E1u,0x82D3E1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3E1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3E1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3E1 LDA
    cpu.setA(0x1Au, 16);
    goto L_82D3E4;
L_82D3E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3E4u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3E4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3E4 CLC
    cpu.setFlag('C', false);
    goto L_82D3E5;
L_82D3E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3E5u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3E5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3E5 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x61u), cpu.m8?8:16));
    goto L_82D3E7;
L_82D3E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3E7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3E7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3E7 STA
    hw.write(cpu.address("dp", 0x61u), cpu.a, cpu.m8?8:16);
    goto L_82D3E9;
L_82D3E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3E9u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3E9u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3E9 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_82D3EB;
L_82D3EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3EBu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3EBu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3EB INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_82D3ED;
L_82D3ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3EDu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3EDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3ED BRA -> $82D3A6
    goto L_82D3A6;
L_82D3EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3EFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3EFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D3EF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82D3EFu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82D3EFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82D399_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82D399u: goto L_82D399;
    case 0x82D39Cu: goto L_82D39C;
    case 0x82D39Fu: goto L_82D39F;
    case 0x82D3A1u: goto L_82D3A1;
    case 0x82D3A2u: goto L_82D3A2;
    case 0x82D3A4u: goto L_82D3A4;
    case 0x82D3A6u: goto L_82D3A6;
    case 0x82D3A8u: goto L_82D3A8;
    case 0x82D3ABu: goto L_82D3AB;
    case 0x82D3ADu: goto L_82D3AD;
    case 0x82D3AFu: goto L_82D3AF;
    case 0x82D3B2u: goto L_82D3B2;
    case 0x82D3B4u: goto L_82D3B4;
    case 0x82D3B6u: goto L_82D3B6;
    case 0x82D3B9u: goto L_82D3B9;
    case 0x82D3BBu: goto L_82D3BB;
    case 0x82D3BEu: goto L_82D3BE;
    case 0x82D3BFu: goto L_82D3BF;
    case 0x82D3C1u: goto L_82D3C1;
    case 0x82D3C3u: goto L_82D3C3;
    case 0x82D3C5u: goto L_82D3C5;
    case 0x82D3C8u: goto L_82D3C8;
    case 0x82D3CAu: goto L_82D3CA;
    case 0x82D3CCu: goto L_82D3CC;
    case 0x82D3CFu: goto L_82D3CF;
    case 0x82D3D1u: goto L_82D3D1;
    case 0x82D3D4u: goto L_82D3D4;
    case 0x82D3D6u: goto L_82D3D6;
    case 0x82D3D7u: goto L_82D3D7;
    case 0x82D3D9u: goto L_82D3D9;
    case 0x82D3DBu: goto L_82D3DB;
    case 0x82D3DDu: goto L_82D3DD;
    case 0x82D3E1u: goto L_82D3E1;
    case 0x82D3E4u: goto L_82D3E4;
    case 0x82D3E5u: goto L_82D3E5;
    case 0x82D3E7u: goto L_82D3E7;
    case 0x82D3E9u: goto L_82D3E9;
    case 0x82D3EBu: goto L_82D3EB;
    case 0x82D3EDu: goto L_82D3ED;
    case 0x82D3EFu: goto L_82D3EF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82D399:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD399u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD399u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD399u, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D399 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D39C;
L_82D39C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD39Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD39Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD39Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D39C CMP
    cpu.compareA(0x1u);
    goto L_82D39F;
L_82D39F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD39Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD39Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD39Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D39F BEQ -> $82D3A2
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82D3A2; }
    goto L_82D3A1;
L_82D3A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3A1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3A1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D3A1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82D3A1u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82D3A1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82D3A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3A2u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3A2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3A2 STZ
    hw.write(cpu.address("dp", 0x61u), 0, cpu.m8?8:16);
    goto L_82D3A4;
L_82D3A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3A4u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3A4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3A4 STZ
    hw.write(cpu.address("dp", 0x63u), 0, cpu.m8?8:16);
    goto L_82D3A6;
L_82D3A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3A6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3A6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3A6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x63u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D3A8;
L_82D3A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3A8u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3A8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3A8 CMP
    cpu.compareA(0x8u);
    goto L_82D3AB;
L_82D3AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3ABu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3ABu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3AB BCS -> $82D3EF
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_82D3EF; }
    goto L_82D3AD;
L_82D3AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3ADu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3ADu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3AD LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x61u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82D3AF;
L_82D3AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3AFu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3AFu, 5u + 1u, 3u, cpu.address("absx", 0x081Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3AF LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x81Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D3B2;
L_82D3B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3B2u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3B2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3B2 BMI -> $82D3EF
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82D3EF; }
    goto L_82D3B4;
L_82D3B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3B4u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3B4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3B4 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82D3B6;
L_82D3B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3B6u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3B6u, 5u + 1u, 3u, cpu.address("absy", 0x0884u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3B6 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x884u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D3B9;
L_82D3B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3B9u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3B9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3B9 BMI -> $82D3E1
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82D3E1; }
    goto L_82D3BB;
L_82D3BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3BBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3BBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3BB LDA
    cpu.setA(0x81Cu, 16);
    goto L_82D3BE;
L_82D3BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3BEu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3BEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3BE CLC
    cpu.setFlag('C', false);
    goto L_82D3BF;
L_82D3BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3BFu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3BFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3BF ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x61u), cpu.m8?8:16));
    goto L_82D3C1;
L_82D3C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3C1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3C1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3C1 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82D3C3;
L_82D3C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3C3u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3C3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3C3 STZ
    hw.write(cpu.address("dp", 0x2u), 0, cpu.m8?8:16);
    goto L_82D3C5;
L_82D3C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3C5u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3C5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3C5 LDX
    cpu.setX(0x3u, 16);
    goto L_82D3C8;
L_82D3C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3C8u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3C8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3C8 SEP
    cpu.sep(0x20u);
    goto L_82D3CA;
L_82D3CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3CAu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3CAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3CA LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82D3CC;
L_82D3CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3CCu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3CCu, 4u + 1u, 3u, cpu.address("absy", 0x0894u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3CC LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x894u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D3CF;
L_82D3CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3CFu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3CFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3CF STA
    hw.write(cpu.address("dpx", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_82D3D1;
L_82D3D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3D1u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3D1u, 4u + 1u, 3u, cpu.address("absy", 0x088Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3D1 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x88Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D3D4;
L_82D3D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3D4u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3D4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x10u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3D4 STA
    hw.write(cpu.address("dpx", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_82D3D6;
L_82D3D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3D6u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3D6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3D6 DEX
    cpu.decReg('X');
    goto L_82D3D7;
L_82D3D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3D7u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3D7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3D7 BPL -> $82D3CA
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82D3CA; }
    goto L_82D3D9;
L_82D3D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3D9u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3D9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3D9 REP
    cpu.rep(0x20u);
    goto L_82D3DB;
L_82D3DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3DBu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3DBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3DB STZ
    hw.write(cpu.address("dp", 0xEu), 0, cpu.m8?8:16);
    goto L_82D3DD;
L_82D3DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3DDu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3DDu, 8u, 4u, 0x808915u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82D3DD JSL -> $808915 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD3E0u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD3E1u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808915u, 0x82D3DDu); }
    goto L_82D3E1;
L_82D3E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3E1u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD3E1u,0x82D3E1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3E1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3E1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3E1 LDA
    cpu.setA(0x1Au, 16);
    goto L_82D3E4;
L_82D3E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3E4u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3E4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3E4 CLC
    cpu.setFlag('C', false);
    goto L_82D3E5;
L_82D3E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3E5u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3E5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3E5 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x61u), cpu.m8?8:16));
    goto L_82D3E7;
L_82D3E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3E7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3E7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3E7 STA
    hw.write(cpu.address("dp", 0x61u), cpu.a, cpu.m8?8:16);
    goto L_82D3E9;
L_82D3E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3E9u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3E9u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3E9 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_82D3EB;
L_82D3EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3EBu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3EBu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3EB INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_82D3ED;
L_82D3ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3EDu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3EDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D3ED BRA -> $82D3A6
    goto L_82D3A6;
L_82D3EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD3EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD3EFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD3EFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D3EF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82D3EFu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82D3EFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_848453_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848453u: goto L_848453;
    case 0x848455u: goto L_848455;
    case 0x848458u: goto L_848458;
    case 0x84845Au: goto L_84845A;
    case 0x84845Cu: goto L_84845C;
    case 0x84845Fu: goto L_84845F;
    case 0x848460u: goto L_848460;
    case 0x848461u: goto L_848461;
    case 0x848464u: goto L_848464;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848453:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8453u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8453u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8453u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848453 SEP
    cpu.sep(0x20u);
    goto L_848455;
L_848455:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8455u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8455u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8455u, 4u, 3u, cpu.address("abs", 0x062Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848455 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848458;
L_848458:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8458u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8458u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8458u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848458 AND
    cpu.logicAnd(0x1u);
    goto L_84845A;
L_84845A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x845Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x845Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x845Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84845A REP
    cpu.rep(0x20u);
    goto L_84845C;
L_84845C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x845Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x845Cu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x845Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84845C AND
    cpu.logicAnd(0xFFu);
    goto L_84845F;
L_84845F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x845Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x845Fu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x845Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84845F ASL
    cpu.aslA();
    goto L_848460;
L_848460:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8460u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8460u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8460u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848460 TAX
    cpu.transfer("TAX");
    goto L_848461;
L_848461:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8461u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8461u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8461u, 5u, 3u, cpu.address("abs", 0x8466u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848461 PEA
    cpu.push16Value(hw, 0x8466u);
    goto L_848464;
L_848464:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8464u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8464u,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8464u, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x8477u + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $848464 JMP (8477,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x8477u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x848464u); return; }
}

void sub_848453_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848453u: goto L_848453;
    case 0x848455u: goto L_848455;
    case 0x848458u: goto L_848458;
    case 0x84845Au: goto L_84845A;
    case 0x84845Cu: goto L_84845C;
    case 0x84845Fu: goto L_84845F;
    case 0x848460u: goto L_848460;
    case 0x848461u: goto L_848461;
    case 0x848464u: goto L_848464;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848453:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8453u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8453u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8453u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848453 SEP
    cpu.sep(0x20u);
    goto L_848455;
L_848455:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8455u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8455u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8455u, 4u, 3u, cpu.address("abs", 0x062Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848455 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848458;
L_848458:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8458u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8458u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8458u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848458 AND
    cpu.logicAnd(0x1u);
    goto L_84845A;
L_84845A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x845Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x845Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x845Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84845A REP
    cpu.rep(0x20u);
    goto L_84845C;
L_84845C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x845Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x845Cu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x845Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84845C AND
    cpu.logicAnd(0xFFu);
    goto L_84845F;
L_84845F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x845Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x845Fu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x845Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84845F ASL
    cpu.aslA();
    goto L_848460;
L_848460:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8460u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8460u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8460u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848460 TAX
    cpu.transfer("TAX");
    goto L_848461;
L_848461:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8461u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8461u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8461u, 5u, 3u, cpu.address("abs", 0x8466u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848461 PEA
    cpu.push16Value(hw, 0x8466u);
    goto L_848464;
L_848464:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8464u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8464u,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8464u, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x8477u + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $848464 JMP (8477,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x8477u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x848464u); return; }
}

void sub_84886D_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84886Du: goto L_84886D;
    case 0x84886Fu: goto L_84886F;
    case 0x848872u: goto L_848872;
    case 0x848875u: goto L_848875;
    case 0x848878u: goto L_848878;
    case 0x84887Au: goto L_84887A;
    case 0x84887Du: goto L_84887D;
    case 0x84887Fu: goto L_84887F;
    case 0x848882u: goto L_848882;
    case 0x848884u: goto L_848884;
    case 0x848888u: goto L_848888;
    case 0x84888Bu: goto L_84888B;
    case 0x84888Eu: goto L_84888E;
    case 0x848891u: goto L_848891;
    case 0x848893u: goto L_848893;
    case 0x848896u: goto L_848896;
    case 0x848898u: goto L_848898;
    case 0x84889Bu: goto L_84889B;
    case 0x84889Du: goto L_84889D;
    case 0x8488A1u: goto L_8488A1;
    case 0x8488A4u: goto L_8488A4;
    case 0x8488A7u: goto L_8488A7;
    case 0x8488AAu: goto L_8488AA;
    case 0x8488ACu: goto L_8488AC;
    case 0x8488AFu: goto L_8488AF;
    case 0x8488B1u: goto L_8488B1;
    case 0x8488B4u: goto L_8488B4;
    case 0x8488B6u: goto L_8488B6;
    case 0x8488BAu: goto L_8488BA;
    case 0x8488BCu: goto L_8488BC;
    case 0x8488BFu: goto L_8488BF;
    case 0x8488C1u: goto L_8488C1;
    case 0x8488C3u: goto L_8488C3;
    case 0x8488C6u: goto L_8488C6;
    case 0x8488C7u: goto L_8488C7;
    case 0x8488C8u: goto L_8488C8;
    case 0x8488CBu: goto L_8488CB;
    case 0x8488CEu: goto L_8488CE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84886D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x886Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x886Du,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x886Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84886D REP
    cpu.rep(0x20u);
    goto L_84886F;
L_84886F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x886Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x886Fu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x886Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84886F LDX
    cpu.setX(0x2u, 16);
    goto L_848872;
L_848872:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8872u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8872u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8872u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848872 LDY
    cpu.setY(0x7u, 16);
    goto L_848875;
L_848875:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8875u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8875u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8875u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848875 LDA
    cpu.setA(0x2A86u, 16);
    goto L_848878;
L_848878:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8878u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8878u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8878u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848878 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_84887A;
L_84887A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x887Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x887Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x887Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84887A LDA
    cpu.setA(0x7Eu, 16);
    goto L_84887D;
L_84887D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x887Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x887Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x887Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84887D STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_84887F;
L_84887F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x887Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x887Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x887Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84887F LDA
    cpu.setA(0xC00u, 16);
    goto L_848882;
L_848882:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8882u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8882u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8882u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848882 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_848884;
L_848884:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8884u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8884u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8884u, 8u, 4u, 0x80A839u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848884 JSL -> $80A839 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8887u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8888u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A839u, 0x848884u); }
    goto L_848888;
L_848888:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8888u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8888u,0x848888u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8888u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8888u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848888 LDX
    cpu.setX(0x2u, 16);
    goto L_84888B;
L_84888B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x888Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x888Bu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x888Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84888B LDY
    cpu.setY(0x6u, 16);
    goto L_84888E;
L_84888E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x888Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x888Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x888Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84888E LDA
    cpu.setA(0x2C06u, 16);
    goto L_848891;
L_848891:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8891u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8891u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8891u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848891 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_848893;
L_848893:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8893u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8893u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8893u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848893 LDA
    cpu.setA(0x7Eu, 16);
    goto L_848896;
L_848896:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8896u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8896u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8896u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848896 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_848898;
L_848898:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8898u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8898u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8898u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848898 LDA
    cpu.setA(0x1000u, 16);
    goto L_84889B;
L_84889B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x889Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x889Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x889Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84889B STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_84889D;
L_84889D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x889Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x889Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x889Du, 8u, 4u, 0x80A839u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84889D JSL -> $80A839 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x88A0u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x88A1u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A839u, 0x84889Du); }
    goto L_8488A1;
L_8488A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88A1u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88A1u,0x8488A1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88A1u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88A1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8488A1 LDX
    cpu.setX(0x2u, 16);
    goto L_8488A4;
L_8488A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88A4u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88A4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8488A4 LDY
    cpu.setY(0x6u, 16);
    goto L_8488A7;
L_8488A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88A7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88A7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8488A7 LDA
    cpu.setA(0x2D86u, 16);
    goto L_8488AA;
L_8488AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88AAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88AAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8488AA STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_8488AC;
L_8488AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88ACu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88ACu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8488AC LDA
    cpu.setA(0x7Eu, 16);
    goto L_8488AF;
L_8488AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88AFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88AFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8488AF STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_8488B1;
L_8488B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88B1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88B1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8488B1 LDA
    cpu.setA(0x1000u, 16);
    goto L_8488B4;
L_8488B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88B4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88B4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8488B4 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_8488B6;
L_8488B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88B6u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88B6u, 8u, 4u, 0x80A839u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8488B6 JSL -> $80A839 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x88B9u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x88BAu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A839u, 0x8488B6u); }
    goto L_8488BA;
L_8488BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88BAu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88BAu,0x8488BAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88BAu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88BAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8488BA SEP
    cpu.sep(0x20u);
    goto L_8488BC;
L_8488BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88BCu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88BCu, 4u, 3u, cpu.address("abs", 0x0629u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8488BC LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x629u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8488BF;
L_8488BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88BFu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88BFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8488BF AND
    cpu.logicAnd(0x3u);
    goto L_8488C1;
L_8488C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88C1u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88C1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8488C1 REP
    cpu.rep(0x20u);
    goto L_8488C3;
L_8488C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88C3u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88C3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8488C3 AND
    cpu.logicAnd(0xFFu);
    goto L_8488C6;
L_8488C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88C6u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88C6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8488C6 ASL
    cpu.aslA();
    goto L_8488C7;
L_8488C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88C7u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88C7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8488C7 TAX
    cpu.transfer("TAX");
    goto L_8488C8;
L_8488C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88C8u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88C8u, 5u, 3u, cpu.address("abs", 0x88CDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8488C8 PEA
    cpu.push16Value(hw, 0x88CDu);
    goto L_8488CB;
L_8488CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88CBu,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88CBu, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x88CFu + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $8488CB JMP (88CF,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x88CFu+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x8488CBu); return; }
L_8488CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88CEu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88CEu,0x8488CEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88CEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88CEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8488CE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8488CEu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8488CEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_84886D_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84886Du: goto L_84886D;
    case 0x84886Fu: goto L_84886F;
    case 0x848872u: goto L_848872;
    case 0x848875u: goto L_848875;
    case 0x848878u: goto L_848878;
    case 0x84887Au: goto L_84887A;
    case 0x84887Du: goto L_84887D;
    case 0x84887Fu: goto L_84887F;
    case 0x848882u: goto L_848882;
    case 0x848884u: goto L_848884;
    case 0x848888u: goto L_848888;
    case 0x84888Bu: goto L_84888B;
    case 0x84888Eu: goto L_84888E;
    case 0x848891u: goto L_848891;
    case 0x848893u: goto L_848893;
    case 0x848896u: goto L_848896;
    case 0x848898u: goto L_848898;
    case 0x84889Bu: goto L_84889B;
    case 0x84889Du: goto L_84889D;
    case 0x8488A1u: goto L_8488A1;
    case 0x8488A4u: goto L_8488A4;
    case 0x8488A7u: goto L_8488A7;
    case 0x8488AAu: goto L_8488AA;
    case 0x8488ACu: goto L_8488AC;
    case 0x8488AFu: goto L_8488AF;
    case 0x8488B1u: goto L_8488B1;
    case 0x8488B4u: goto L_8488B4;
    case 0x8488B6u: goto L_8488B6;
    case 0x8488BAu: goto L_8488BA;
    case 0x8488BCu: goto L_8488BC;
    case 0x8488BFu: goto L_8488BF;
    case 0x8488C1u: goto L_8488C1;
    case 0x8488C3u: goto L_8488C3;
    case 0x8488C6u: goto L_8488C6;
    case 0x8488C7u: goto L_8488C7;
    case 0x8488C8u: goto L_8488C8;
    case 0x8488CBu: goto L_8488CB;
    case 0x8488CEu: goto L_8488CE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84886D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x886Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x886Du,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x886Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84886D REP
    cpu.rep(0x20u);
    goto L_84886F;
L_84886F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x886Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x886Fu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x886Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84886F LDX
    cpu.setX(0x2u, 16);
    goto L_848872;
L_848872:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8872u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8872u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8872u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848872 LDY
    cpu.setY(0x7u, 16);
    goto L_848875;
L_848875:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8875u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8875u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8875u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848875 LDA
    cpu.setA(0x2A86u, 16);
    goto L_848878;
L_848878:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8878u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8878u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8878u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848878 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_84887A;
L_84887A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x887Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x887Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x887Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84887A LDA
    cpu.setA(0x7Eu, 16);
    goto L_84887D;
L_84887D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x887Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x887Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x887Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84887D STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_84887F;
L_84887F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x887Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x887Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x887Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84887F LDA
    cpu.setA(0xC00u, 16);
    goto L_848882;
L_848882:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8882u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8882u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8882u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848882 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_848884;
L_848884:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8884u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8884u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8884u, 8u, 4u, 0x80A839u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848884 JSL -> $80A839 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8887u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8888u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A839u, 0x848884u); }
    goto L_848888;
L_848888:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8888u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8888u,0x848888u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8888u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8888u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848888 LDX
    cpu.setX(0x2u, 16);
    goto L_84888B;
L_84888B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x888Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x888Bu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x888Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84888B LDY
    cpu.setY(0x6u, 16);
    goto L_84888E;
L_84888E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x888Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x888Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x888Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84888E LDA
    cpu.setA(0x2C06u, 16);
    goto L_848891;
L_848891:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8891u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8891u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8891u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848891 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_848893;
L_848893:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8893u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8893u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8893u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848893 LDA
    cpu.setA(0x7Eu, 16);
    goto L_848896;
L_848896:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8896u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8896u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8896u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848896 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_848898;
L_848898:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8898u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8898u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8898u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848898 LDA
    cpu.setA(0x1000u, 16);
    goto L_84889B;
L_84889B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x889Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x889Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x889Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84889B STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_84889D;
L_84889D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x889Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x889Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x889Du, 8u, 4u, 0x80A839u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84889D JSL -> $80A839 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x88A0u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x88A1u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A839u, 0x84889Du); }
    goto L_8488A1;
L_8488A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88A1u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88A1u,0x8488A1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88A1u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88A1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8488A1 LDX
    cpu.setX(0x2u, 16);
    goto L_8488A4;
L_8488A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88A4u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88A4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8488A4 LDY
    cpu.setY(0x6u, 16);
    goto L_8488A7;
L_8488A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88A7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88A7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8488A7 LDA
    cpu.setA(0x2D86u, 16);
    goto L_8488AA;
L_8488AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88AAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88AAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8488AA STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_8488AC;
L_8488AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88ACu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88ACu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8488AC LDA
    cpu.setA(0x7Eu, 16);
    goto L_8488AF;
L_8488AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88AFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88AFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8488AF STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_8488B1;
L_8488B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88B1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88B1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8488B1 LDA
    cpu.setA(0x1000u, 16);
    goto L_8488B4;
L_8488B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88B4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88B4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8488B4 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_8488B6;
L_8488B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88B6u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88B6u, 8u, 4u, 0x80A839u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8488B6 JSL -> $80A839 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x88B9u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x88BAu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A839u, 0x8488B6u); }
    goto L_8488BA;
L_8488BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88BAu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88BAu,0x8488BAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88BAu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88BAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8488BA SEP
    cpu.sep(0x20u);
    goto L_8488BC;
L_8488BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88BCu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88BCu, 4u, 3u, cpu.address("abs", 0x0629u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8488BC LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x629u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8488BF;
L_8488BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88BFu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88BFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8488BF AND
    cpu.logicAnd(0x3u);
    goto L_8488C1;
L_8488C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88C1u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88C1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8488C1 REP
    cpu.rep(0x20u);
    goto L_8488C3;
L_8488C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88C3u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88C3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8488C3 AND
    cpu.logicAnd(0xFFu);
    goto L_8488C6;
L_8488C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88C6u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88C6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8488C6 ASL
    cpu.aslA();
    goto L_8488C7;
L_8488C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88C7u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88C7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8488C7 TAX
    cpu.transfer("TAX");
    goto L_8488C8;
L_8488C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88C8u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88C8u, 5u, 3u, cpu.address("abs", 0x88CDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8488C8 PEA
    cpu.push16Value(hw, 0x88CDu);
    goto L_8488CB;
L_8488CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88CBu,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88CBu, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x88CFu + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $8488CB JMP (88CF,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x88CFu+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x8488CBu); return; }
L_8488CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88CEu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88CEu,0x8488CEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88CEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88CEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8488CE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8488CEu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8488CEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_84886D_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84886Du: goto L_84886D;
    case 0x84886Fu: goto L_84886F;
    case 0x848872u: goto L_848872;
    case 0x848875u: goto L_848875;
    case 0x848878u: goto L_848878;
    case 0x84887Au: goto L_84887A;
    case 0x84887Du: goto L_84887D;
    case 0x84887Fu: goto L_84887F;
    case 0x848882u: goto L_848882;
    case 0x848884u: goto L_848884;
    case 0x848888u: goto L_848888;
    case 0x84888Bu: goto L_84888B;
    case 0x84888Eu: goto L_84888E;
    case 0x848891u: goto L_848891;
    case 0x848893u: goto L_848893;
    case 0x848896u: goto L_848896;
    case 0x848898u: goto L_848898;
    case 0x84889Bu: goto L_84889B;
    case 0x84889Du: goto L_84889D;
    case 0x8488A1u: goto L_8488A1;
    case 0x8488A4u: goto L_8488A4;
    case 0x8488A7u: goto L_8488A7;
    case 0x8488AAu: goto L_8488AA;
    case 0x8488ACu: goto L_8488AC;
    case 0x8488AFu: goto L_8488AF;
    case 0x8488B1u: goto L_8488B1;
    case 0x8488B4u: goto L_8488B4;
    case 0x8488B6u: goto L_8488B6;
    case 0x8488BAu: goto L_8488BA;
    case 0x8488BCu: goto L_8488BC;
    case 0x8488BFu: goto L_8488BF;
    case 0x8488C1u: goto L_8488C1;
    case 0x8488C3u: goto L_8488C3;
    case 0x8488C6u: goto L_8488C6;
    case 0x8488C7u: goto L_8488C7;
    case 0x8488C8u: goto L_8488C8;
    case 0x8488CBu: goto L_8488CB;
    case 0x8488CEu: goto L_8488CE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84886D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x886Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x886Du,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x886Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84886D REP
    cpu.rep(0x20u);
    goto L_84886F;
L_84886F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x886Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x886Fu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x886Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84886F LDX
    cpu.setX(0x2u, 16);
    goto L_848872;
L_848872:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8872u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8872u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8872u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848872 LDY
    cpu.setY(0x7u, 16);
    goto L_848875;
L_848875:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8875u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8875u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8875u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848875 LDA
    cpu.setA(0x2A86u, 16);
    goto L_848878;
L_848878:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8878u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8878u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8878u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848878 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_84887A;
L_84887A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x887Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x887Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x887Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84887A LDA
    cpu.setA(0x7Eu, 16);
    goto L_84887D;
L_84887D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x887Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x887Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x887Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84887D STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_84887F;
L_84887F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x887Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x887Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x887Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84887F LDA
    cpu.setA(0xC00u, 16);
    goto L_848882;
L_848882:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8882u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8882u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8882u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848882 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_848884;
L_848884:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8884u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8884u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8884u, 8u, 4u, 0x80A839u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848884 JSL -> $80A839 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8887u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8888u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A839u, 0x848884u); }
    goto L_848888;
L_848888:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8888u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8888u,0x848888u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8888u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8888u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848888 LDX
    cpu.setX(0x2u, 16);
    goto L_84888B;
L_84888B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x888Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x888Bu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x888Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84888B LDY
    cpu.setY(0x6u, 16);
    goto L_84888E;
L_84888E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x888Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x888Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x888Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84888E LDA
    cpu.setA(0x2C06u, 16);
    goto L_848891;
L_848891:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8891u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8891u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8891u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848891 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_848893;
L_848893:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8893u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8893u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8893u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848893 LDA
    cpu.setA(0x7Eu, 16);
    goto L_848896;
L_848896:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8896u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8896u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8896u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848896 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_848898;
L_848898:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8898u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8898u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8898u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848898 LDA
    cpu.setA(0x1000u, 16);
    goto L_84889B;
L_84889B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x889Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x889Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x889Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84889B STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_84889D;
L_84889D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x889Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x889Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x889Du, 8u, 4u, 0x80A839u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84889D JSL -> $80A839 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x88A0u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x88A1u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A839u, 0x84889Du); }
    goto L_8488A1;
L_8488A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88A1u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88A1u,0x8488A1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88A1u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88A1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8488A1 LDX
    cpu.setX(0x2u, 16);
    goto L_8488A4;
L_8488A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88A4u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88A4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8488A4 LDY
    cpu.setY(0x6u, 16);
    goto L_8488A7;
L_8488A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88A7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88A7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8488A7 LDA
    cpu.setA(0x2D86u, 16);
    goto L_8488AA;
L_8488AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88AAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88AAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8488AA STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_8488AC;
L_8488AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88ACu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88ACu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8488AC LDA
    cpu.setA(0x7Eu, 16);
    goto L_8488AF;
L_8488AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88AFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88AFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8488AF STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_8488B1;
L_8488B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88B1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88B1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8488B1 LDA
    cpu.setA(0x1000u, 16);
    goto L_8488B4;
L_8488B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88B4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88B4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8488B4 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_8488B6;
L_8488B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88B6u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88B6u, 8u, 4u, 0x80A839u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8488B6 JSL -> $80A839 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x88B9u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x88BAu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A839u, 0x8488B6u); }
    goto L_8488BA;
L_8488BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88BAu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88BAu,0x8488BAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88BAu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88BAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8488BA SEP
    cpu.sep(0x20u);
    goto L_8488BC;
L_8488BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88BCu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88BCu, 4u, 3u, cpu.address("abs", 0x0629u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8488BC LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x629u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8488BF;
L_8488BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88BFu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88BFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8488BF AND
    cpu.logicAnd(0x3u);
    goto L_8488C1;
L_8488C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88C1u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88C1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8488C1 REP
    cpu.rep(0x20u);
    goto L_8488C3;
L_8488C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88C3u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88C3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8488C3 AND
    cpu.logicAnd(0xFFu);
    goto L_8488C6;
L_8488C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88C6u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88C6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8488C6 ASL
    cpu.aslA();
    goto L_8488C7;
L_8488C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88C7u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88C7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8488C7 TAX
    cpu.transfer("TAX");
    goto L_8488C8;
L_8488C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88C8u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88C8u, 5u, 3u, cpu.address("abs", 0x88CDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8488C8 PEA
    cpu.push16Value(hw, 0x88CDu);
    goto L_8488CB;
L_8488CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88CBu,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88CBu, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x88CFu + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $8488CB JMP (88CF,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x88CFu+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x8488CBu); return; }
L_8488CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88CEu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88CEu,0x8488CEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88CEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88CEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8488CE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8488CEu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8488CEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_849145_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x849145u: goto L_849145;
    case 0x849147u: goto L_849147;
    case 0x84914Au: goto L_84914A;
    case 0x84914Du: goto L_84914D;
    case 0x849150u: goto L_849150;
    case 0x849153u: goto L_849153;
    case 0x849156u: goto L_849156;
    case 0x849159u: goto L_849159;
    case 0x84915Cu: goto L_84915C;
    case 0x84915Fu: goto L_84915F;
    case 0x849162u: goto L_849162;
    case 0x849165u: goto L_849165;
    case 0x849167u: goto L_849167;
    case 0x84916Au: goto L_84916A;
    case 0x84916Du: goto L_84916D;
    case 0x84916Fu: goto L_84916F;
    case 0x849172u: goto L_849172;
    case 0x849175u: goto L_849175;
    case 0x849177u: goto L_849177;
    case 0x849179u: goto L_849179;
    case 0x84917Cu: goto L_84917C;
    case 0x84917Fu: goto L_84917F;
    case 0x849181u: goto L_849181;
    case 0x849184u: goto L_849184;
    case 0x849186u: goto L_849186;
    case 0x849188u: goto L_849188;
    case 0x84918Bu: goto L_84918B;
    case 0x84918Eu: goto L_84918E;
    case 0x849191u: goto L_849191;
    case 0x849194u: goto L_849194;
    case 0x849196u: goto L_849196;
    case 0x849199u: goto L_849199;
    case 0x84919Cu: goto L_84919C;
    case 0x84919Fu: goto L_84919F;
    case 0x8491A2u: goto L_8491A2;
    case 0x8491A5u: goto L_8491A5;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_849145:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9145u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9145u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9145u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849145 REP
    cpu.rep(0x20u);
    goto L_849147;
L_849147:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9147u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9147u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9147u, 5u, 3u, cpu.address("abs", 0x1962u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849147 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1962u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84914A;
L_84914A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x914Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x914Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x914Au, 5u, 3u, cpu.address("abs", 0x1982u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84914A STA
    hw.write(cpu.address("abs", 0x1982u), cpu.a, cpu.m8?8:16);
    goto L_84914D;
L_84914D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x914Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x914Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x914Du, 5u, 3u, cpu.address("abs", 0x1964u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84914D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1964u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849150;
L_849150:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9150u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9150u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9150u, 5u, 3u, cpu.address("abs", 0x1984u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849150 STA
    hw.write(cpu.address("abs", 0x1984u), cpu.a, cpu.m8?8:16);
    goto L_849153;
L_849153:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9153u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9153u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9153u, 5u, 3u, cpu.address("abs", 0x1962u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849153 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1962u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849156;
L_849156:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9156u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9156u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9156u, 5u, 3u, cpu.address("abs", 0x19A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849156 STA
    hw.write(cpu.address("abs", 0x19A2u), cpu.a, cpu.m8?8:16);
    goto L_849159;
L_849159:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9159u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9159u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9159u, 5u, 3u, cpu.address("abs", 0x1964u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849159 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1964u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84915C;
L_84915C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x915Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x915Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x915Cu, 5u, 3u, cpu.address("abs", 0x19A4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84915C STA
    hw.write(cpu.address("abs", 0x19A4u), cpu.a, cpu.m8?8:16);
    goto L_84915F;
L_84915F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x915Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x915Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x915Fu, 5u, 3u, cpu.address("abs", 0x062Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84915F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849162;
L_849162:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9162u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9162u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9162u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849162 BIT
    cpu.bit(0x1u, true);
    goto L_849165;
L_849165:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9165u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9165u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9165u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849165 BEQ -> $849179
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_849179; }
    goto L_849167;
L_849167:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9167u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9167u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9167u, 5u, 3u, cpu.address("abs", 0x06FDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849167 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x6FDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84916A;
L_84916A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x916Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x916Au,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x916Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84916A BIT
    cpu.bit(0x1u, true);
    goto L_84916D;
L_84916D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x916Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x916Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x916Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84916D BEQ -> $849179
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_849179; }
    goto L_84916F;
L_84916F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x916Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x916Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x916Fu, 5u, 3u, cpu.address("abs", 0x06FEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84916F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x6FEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849172;
L_849172:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9172u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9172u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9172u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849172 BIT
    cpu.bit(0x1u, true);
    goto L_849175;
L_849175:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9175u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9175u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9175u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849175 BEQ -> $849188
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_849188; }
    goto L_849177;
L_849177:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9177u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9177u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9177u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849177 BRA -> $849196
    goto L_849196;
L_849179:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9179u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9179u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9179u, 5u, 3u, cpu.address("abs", 0x062Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849179 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84917C;
L_84917C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x917Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x917Cu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x917Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84917C AND
    cpu.logicAnd(0xFFu);
    goto L_84917F;
L_84917F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x917Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x917Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x917Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84917F BEQ -> $849188
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_849188; }
    goto L_849181;
L_849181:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9181u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9181u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9181u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849181 CMP
    cpu.compareA(0x2u);
    goto L_849184;
L_849184:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9184u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9184u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9184u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849184 BEQ -> $849196
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_849196; }
    goto L_849186;
L_849186:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9186u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9186u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9186u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849186 BRA -> $8491A2
    goto L_8491A2;
L_849188:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9188u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9188u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9188u, 5u, 3u, cpu.address("abs", 0x1942u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849188 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1942u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84918B;
L_84918B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x918Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x918Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x918Bu, 5u, 3u, cpu.address("abs", 0x1982u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84918B STA
    hw.write(cpu.address("abs", 0x1982u), cpu.a, cpu.m8?8:16);
    goto L_84918E;
L_84918E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x918Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x918Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x918Eu, 5u, 3u, cpu.address("abs", 0x1944u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84918E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1944u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849191;
L_849191:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9191u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9191u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9191u, 5u, 3u, cpu.address("abs", 0x1984u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849191 STA
    hw.write(cpu.address("abs", 0x1984u), cpu.a, cpu.m8?8:16);
    goto L_849194;
L_849194:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9194u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9194u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9194u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849194 BRA -> $8491A2
    goto L_8491A2;
L_849196:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9196u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9196u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9196u, 5u, 3u, cpu.address("abs", 0x1942u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849196 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1942u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849199;
L_849199:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9199u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9199u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9199u, 5u, 3u, cpu.address("abs", 0x19A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849199 STA
    hw.write(cpu.address("abs", 0x19A2u), cpu.a, cpu.m8?8:16);
    goto L_84919C;
L_84919C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x919Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x919Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x919Cu, 5u, 3u, cpu.address("abs", 0x1944u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84919C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1944u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84919F;
L_84919F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x919Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x919Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x919Fu, 5u, 3u, cpu.address("abs", 0x19A4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84919F STA
    hw.write(cpu.address("abs", 0x19A4u), cpu.a, cpu.m8?8:16);
    goto L_8491A2;
L_8491A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91A2u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91A2u, 8u, 3u, cpu.address("abs", 0x0122u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491A2 INC
    cpu.incMem(hw, cpu.address("abs", 0x122u), cpu.m8?8:16);
    goto L_8491A5;
L_8491A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91A5u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91A5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8491A5 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8491A5u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8491A5u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_90F800_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x90F800u: goto L_90F800;
    case 0x90F804u: goto L_90F804;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_90F800:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF800u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF800u,cpu,0x1Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF800u, 6u, 4u, ((0x1F0000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $90F800 ORA
    cpu.logicOr(hw.readW(((0x1F0000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_90F804;
L_90F804:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF804u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF804u,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF804u, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $90F804 BRK
    hw.partial(0x90F804u, "BRK"); return;
}

